from typing import Optional

MILODB_VERSION: Optional[str] = '1.7.1'
MILODB_DATE: Optional[str] = '2022-11-02'
