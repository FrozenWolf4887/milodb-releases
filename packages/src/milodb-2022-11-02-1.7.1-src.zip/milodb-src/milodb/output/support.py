import milodb.query as query
from milodb.tease import TeaseProperty, TeaseStrListProperty
from enum import Enum
from typing import Callable, List, Optional

class EllipsisLocation(Enum):
    LEFT = 0
    MIDDLE = 1
    RIGHT = 2

    @classmethod
    def from_position(cls, is_first_item: bool, is_last_item: bool) -> 'EllipsisLocation':
        if is_first_item:
            if is_last_item:
                return EllipsisLocation.MIDDLE
            else:
                return EllipsisLocation.LEFT
        else:
            if is_last_item:
                return EllipsisLocation.RIGHT
            else:
                return EllipsisLocation.MIDDLE

def get_url_of_tease(tease_id: int) -> str:
    return f"https://milovana.com/webteases/showtease.php?id={tease_id}"

def get_url_of_author(author_id: int) -> str:
    return f"https://milovana.com/forum/memberlist.php?mode=viewprofile&u={author_id}"

def get_list_of_metadata_matches(tease_property: TeaseProperty, list_of_query_matches: List[query.QueryMatch]) -> List[query.MatchDetails]:
    list_of_matches: List[query.MatchDetails] = []

    query_match: query.QueryMatch
    for query_match in list_of_query_matches:
        if isinstance(query_match, query.FieldQueryMatch) and query_match.tease_property == tease_property:
            list_of_matches.extend(query_match.list_of_matches)

    return list_of_matches

def get_list_of_indexed_metadata_matches(tease_property: TeaseStrListProperty, index: int, list_of_query_matches: List[query.QueryMatch]) -> List[query.MatchDetails]:
    list_of_matches: List[query.MatchDetails] = []

    query_match: query.QueryMatch
    for query_match in list_of_query_matches:
        if isinstance(query_match, query.FieldStrListQueryMatch) and query_match.tease_property == tease_property and query_match.index_of_block == index:
            list_of_matches.extend(query_match.list_of_matches)

    return list_of_matches

def abbrev_text_with_ellipsis(text: str, max_length: int, ellipsis_location: EllipsisLocation, ellipsis_text: str):
    if len(text) > max_length:
        if ellipsis_location == EllipsisLocation.RIGHT:
            text = ellipsis_text + text[len(text) - max_length + 1:]
        elif ellipsis_location == EllipsisLocation.MIDDLE:
            text = text[:max_length // 2] + ellipsis_text + text[len(text) - (max_length - 1) // 2:]
        else:
            text = text[:max_length - 1] + ellipsis_text

    return text

class EllipsifyText:
    def __init__(self, text: str, max_length: int, ellipsis_location: EllipsisLocation, callback_normal_text: Callable[[str], None], callback_ellipsis: Callable[[], None]):
        if ellipsis_location == EllipsisLocation.MIDDLE:
            max_length *= 2
        if len(text) > max_length:
            if ellipsis_location == EllipsisLocation.LEFT:
                callback_ellipsis()
                callback_normal_text(text[len(text) - max_length + 1:])
            elif ellipsis_location == EllipsisLocation.MIDDLE:
                callback_normal_text(text[:max_length // 2])
                callback_ellipsis()
                callback_normal_text(text[len(text) - (max_length - 1) // 2:])
            else:
                callback_normal_text(text[:max_length - 1])
                callback_ellipsis()
        else:
            callback_normal_text(text)

class IterateThroughMatches:
    def __init__(self, text: str, list_of_matches: List[query.MatchDetails], callback_normal_text: Callable[[str, bool, bool], None], callback_matched_text: Callable[[str, bool, bool], None]) -> None:
        if not list_of_matches:
            callback_normal_text(text, True, True)
            return

        if self._is_whole_match(list_of_matches):
            callback_matched_text(text, True, True)
            return

        list_of_index_match_toggles: List[int] = self._create_indices_of_match_toggles(list_of_matches)
        list_of_text_slices: List[str] = self._create_text_slices_from_match_toggles(text, list_of_index_match_toggles)
        self._callback_with_text_slices(list_of_text_slices, callback_normal_text, callback_matched_text)

    @staticmethod
    def _is_whole_match(list_of_matches: List[query.MatchDetails]) -> bool:
        match: query.MatchDetails
        for match in list_of_matches:
            if match.is_whole_match:
                return True
        return False

    @staticmethod
    def _create_indices_of_match_toggles(list_of_matches: List[query.MatchDetails]) -> List[int]:
        list_of_index_match_toggles: List[int] = []

        current_start_index: Optional[int] = None
        current_end_index: int = 0
        for match in IterateThroughMatches._sort_and_prune_matches(list_of_matches):
            if current_start_index is None:
                list_of_index_match_toggles.append(match.start_index)
                current_start_index = match.start_index
                current_end_index = match.end_index
            else:
                if current_end_index < match.start_index:
                    list_of_index_match_toggles.append(current_end_index)
                    list_of_index_match_toggles.append(match.start_index)
                    current_start_index = match.start_index
                    current_end_index = match.end_index
                elif current_end_index < match.end_index:
                    current_end_index = match.end_index

        list_of_index_match_toggles.append(current_end_index)

        return list_of_index_match_toggles

    @staticmethod
    def _sort_and_prune_matches(list_of_matches: List[query.MatchDetails]) -> List[query.MatchDetails]:
        list_of_pruned_matches: List[query.MatchDetails] = []

        list_of_sorted_matches: List[query.MatchDetails] = sorted(list_of_matches, key=lambda match: (match.start_index, -match.end_index))

        current_start_index: Optional[int] = None
        for match in list_of_sorted_matches:
            if current_start_index is None or (current_start_index != match.start_index):
                list_of_pruned_matches.append(match)
                current_start_index = match.start_index

        return list_of_pruned_matches

    @staticmethod
    def _create_text_slices_from_match_toggles(text: str, list_of_index_match_toggles: List[int]) -> List[str]:
        list_of_text_slices: List[str] = []

        previous_index_of_toggle: int = 0
        for index_of_toggle in list_of_index_match_toggles:
            list_of_text_slices.append(text[previous_index_of_toggle:index_of_toggle])
            previous_index_of_toggle = index_of_toggle
        if previous_index_of_toggle < len(text):
            list_of_text_slices.append(text[previous_index_of_toggle:])

        return list_of_text_slices

    @staticmethod
    def _callback_with_text_slices(list_of_text_slices: List[str], callback_normal_text: Callable[[str, bool, bool], None], callback_matched_text: Callable[[str, bool, bool], None]) -> None:
        is_first_slice: bool = True
        is_currently_in_match: bool = False
        index: int
        text_slice: str
        for index, text_slice in enumerate(list_of_text_slices):
            if text_slice:
                is_last_slice: bool = index == len(list_of_text_slices) - 1
                if is_currently_in_match:
                    callback_matched_text(text_slice, is_first_slice, is_last_slice)
                else:
                    callback_normal_text(text_slice, is_first_slice, is_last_slice)
                is_first_slice = False
            is_currently_in_match = not is_currently_in_match

def iterate_through_lines(text: str, callback_text: Callable[[str], None], callback_line_ending: Callable[[str], None]) -> None: #NOSONAR
    previous_index: int = 0
    is_in_line_ending: bool = False

    index: int
    c: str
    for index, c in enumerate(text):
        if c == '\n':
            if not is_in_line_ending:
                if previous_index < index:
                    callback_text(text[previous_index:index])
                is_in_line_ending = True
                previous_index = index
        else:
            if is_in_line_ending:
                if previous_index < index:
                    callback_line_ending(text[previous_index:index])
                is_in_line_ending = False
                previous_index = index

    if is_in_line_ending:
        callback_line_ending(text[previous_index:])
    else:
        callback_text(text[previous_index:])
