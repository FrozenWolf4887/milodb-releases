import milodb.query as query
from milodb.commands.argument_stream import ArgumentStream
from milodb.commands.command import Command, CommandContext
from milodb.commands.database_support import try_create_list_of_tease_matches_from_ref_ids
from milodb.ref_id import RefId
from typing import List, Optional

class ListCommand(Command):
    def __init__(self, context: CommandContext) -> None:
        self._context = context
        self._list_of_ref_ids: Optional[List[RefId]] = None

    def load(self, argument_stream: ArgumentStream) -> Optional[List[str]]:
        while not argument_stream.is_empty():
            if not self._list_of_ref_ids:
                self._list_of_ref_ids = []
            self._list_of_ref_ids.append(argument_stream.pop_ref_id())
        return None

    def execute(self) -> None:
        list_of_tease_matches: Optional[List[query.TeaseMatch]] = None
        if self._list_of_ref_ids:
            list_of_tease_matches = try_create_list_of_tease_matches_from_ref_ids(self._context, self._list_of_ref_ids)
        else:
            list_of_tease_matches = self._context.list_of_tease_matches

        if list_of_tease_matches:
            self._context.current_outputter.print_list_of_teases(list_of_tease_matches)
        else:
            self._context.user_config.stream_writer.writeln_error("No teases available to list")

    @classmethod
    def get_one_line_summary(cls) -> str:
        return "Lists the current results, one per line"

    @classmethod
    def get_detailed_summary(cls, context: CommandContext) -> str:
        return (
            "Arguments: [list of RefIds]\n"
            "The formatting used in the list can be controlled with the format command.\n"
            "When used without arguments, all teases that were found from the last query are"
            " included. When one or more RefIds are specified, only those teases are included.\n"
            "RefIds can be an index into the list of matches such as '3', a teaseId such as"
            " '#38664', or an authorId such as '@43937'.\n"
            "The field shown as *n (e.g. *12) indicates how many field matches were made with"
            " the query to provide a guide to the possible relevance of that tease.\n"
            "Matching fields may be highlighted which can be controlled with the highlight"
            " command.\n"
            "Example:\r"
            "  \tList the results of the last query\r"
            "  > \tlist\r"
            "Example:\r"
            "  \tList some matched teases by index\r"
            "  > \tlist 3 7\r"
            "Example:\r"
            "  \tList some specific teaseIds\r"
            "  > \tlist #16830 #1465 #38664\r"
            "Example:\r"
            "  \tList teases for a specific authorId\r"
            "  > \tlist @43937\n"
            "See also:\r"
            "  \tformat, highlight, summary, show, sort\n"
        )
