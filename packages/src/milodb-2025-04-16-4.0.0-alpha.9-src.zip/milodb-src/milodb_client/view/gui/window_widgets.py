# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
# spell-checker: ignore borderwidth padx pady
import tkinter as tk
from collections.abc import Callable
from milodb_client.view.gui import general_colours, general_layout

_COL_PANEL_BACK: str = general_colours.PANEL_BACK
_COL_BUTTON_BACK: str = general_colours.BUTTON_BACK
_COL_BUTTON_FORE: str = general_colours.BUTTON_FORE
_LAYOUT_RELIEF: general_layout.Relief = general_layout.PANEL_RELIEF
_LAYOUT_BORDER_WIDTH: int = general_layout.PANEL_BORDER_WIDTH
_LAYOUT_PADDING_X: int = general_layout.PANEL_PADDING_X
_LAYOUT_PADDING_Y: int = general_layout.PANEL_PADDING_Y

class ModalDialog:
    def __init__(self, master: tk.Tk | tk.Toplevel, width: int=640, height: int=480, title: str | None=None, *, resizeable: bool=True, closeable: bool=True) -> None:
        self._window: tk.Toplevel = tk.Toplevel(master, background=_COL_PANEL_BACK, relief=_LAYOUT_RELIEF, padx=_LAYOUT_PADDING_X, pady=_LAYOUT_PADDING_Y, borderwidth=_LAYOUT_BORDER_WIDTH)
        left: int = master.winfo_x() + (master.winfo_width() - width) // 2
        top: int = master.winfo_y() + (master.winfo_height() - height) // 3
        self._window.geometry(f'{width}x{height}+{left}+{top}')
        self._window.transient(master)
        if title:
            self._window.title(title)
        if not resizeable:
            self._window.resizable(width=False, height=False)
        if not closeable:
            self._window.protocol("WM_DELETE_WINDOW", self._window.update)

        self._content_frame: tk.Frame = tk.Frame(self._window, background=_COL_PANEL_BACK)
        self._content_frame.grid(row=0, column=0, sticky=tk.NSEW)
        self._button_back_frame: tk.Frame = tk.Frame(self._window, background=_COL_PANEL_BACK)
        self._button_back_frame.grid(row=1, column=0, sticky=tk.EW)
        self._button_frame: tk.Frame = tk.Frame(self._button_back_frame, background=_COL_PANEL_BACK)
        self._button_frame.pack(anchor=tk.CENTER)

        self._is_destroyed: bool = False
        self._map_of_column_to_list_of_buttons: dict[int, list[tk.Button]] = {}

        self._window.rowconfigure(0, weight=1)
        self._window.columnconfigure(0, weight=1)

        self._window.wait_visibility()
        self._window.grab_set()

    @property
    def content_frame(self) -> tk.Frame:
        return self._content_frame

    def add_button(self, text: str, *, column: int, command: Callable[[], None], is_hidden: bool=False) -> None:
        if not self._map_of_column_to_list_of_buttons:
            self._button_back_frame.columnconfigure(0, weight=1)
        button: tk.Button = tk.Button(self._button_frame, text=text, foreground=_COL_BUTTON_FORE, background=_COL_BUTTON_BACK, command=command, state=tk.NORMAL)
        if not is_hidden:
            button.grid(row=0, column=column)
        self._map_of_column_to_list_of_buttons.setdefault(column, []).append(button)

    def hide_button(self, column: int) -> None:
        list_of_buttons: list[tk.Button] | None = self._map_of_column_to_list_of_buttons.get(column)
        if list_of_buttons:
            button: tk.Button
            for button in list_of_buttons:
                button.grid_forget()

    def show_button(self, column: int) -> None:
        list_of_buttons: list[tk.Button] | None = self._map_of_column_to_list_of_buttons.get(column)
        if list_of_buttons:
            button: tk.Button
            for button in list_of_buttons:
                button.grid(row=0, column=column)

    def focus_button(self, column: int) -> None:
        list_of_buttons: list[tk.Button] | None = self._map_of_column_to_list_of_buttons.get(column)
        if list_of_buttons:
            list_of_buttons[0].focus()

    def destroy(self) -> None:
        if not self._is_destroyed:
            self._is_destroyed = True
            self._window.grab_release()
            self._window.destroy()
