#!/bin/bash
# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/

LIST_OF_ICON_SIZES='256,128,96,64,48,32,24,16'

function show_syntax() # (app_name: str) -> None
{
    app_name="$1"

    echo "Syntax: $app_name input-file.png output-file.ico"
    echo '    Converts the specified PNG input file into an icon file that is'
    echo '    suitable for use with a Windows executable. The result is written to'
    echo '    the specified output file.'
    echo 'Note:'
    echo "    The output icon file includes the image sizes $LIST_OF_ICON_SIZES."
    echo "    This tool depends on 'convert' from ImageMagick (https://imagemagick.org)."
    echo 'Options:'
    echo '    -h  --help  Show this help'
}

function translate_file() # (input_filepath: str, output_filepath: str) -> int
{
    input_filepath="$1"
    output_filepath="$2"

    if convert_exe="$(command -v convert)"
    then
        echo "Converting '$input_filepath' to '$output_filepath' with '$convert_exe'"
        "$convert_exe" -define icon:auto-resize=$LIST_OF_ICON_SIZES -background none "$input_filepath" "$output_filepath"
        return $?
    else
        echo "Error: Command 'convert' is not installed or not available"
        return 1
    fi
}

function main() # (app_name: str, list_of_args: list[str]) -> int
{
    app_name="$1"
    shift

    if [ $# -eq 0 ]
    then
        show_syntax "$app_name"
        return 0
    fi

    for arg in "$@"
    do
        if [ "$arg" == '-h' ] || [ "$arg" == '--help' ]
        then
            show_syntax "$app_name"
            return 0
        fi
    done

    if [ $# -le 1 ]
    then
        echo 'Error: Insufficient parameters'
        show_syntax "$app_name"
        return 1
    fi

    if [ $# -gt 2 ]
    then
        echo 'Error: Excessive parameters'
        show_syntax "$app_name"
        return 1
    fi

    translate_file "$1" "$2"
}

main "$(basename "$0")" "$@"
exit $?
