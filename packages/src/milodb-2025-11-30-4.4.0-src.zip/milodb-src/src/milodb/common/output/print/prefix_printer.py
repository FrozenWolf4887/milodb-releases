# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from typing import override
from milodb.common.output.print.i_printer import IPrinter
from milodb.common.output.print.redirectable_printer import RedirectablePrinter

class PrefixPrinter(RedirectablePrinter):
    def __init__(self, prefix: str, target_printer: IPrinter) -> None:
        super().__init__(target_printer)
        self._prefix: str = prefix

    @override
    def write(self, text: str) -> None:
        if not self._target_printer.is_on_new_line:
            self._target_printer.writeln()
        self._target_printer.write(f'{self._prefix}{text}')

    @override
    def writeln(self, text: str | None = None) -> None:
        if not self._target_printer.is_on_new_line:
            self._target_printer.writeln()
        if text:
            self._target_printer.writeln(f'{self._prefix}{text}')
        else:
            self._target_printer.writeln()

    @property
    @override
    def is_on_new_line(self) -> bool:
        return self._target_printer.is_on_new_line
