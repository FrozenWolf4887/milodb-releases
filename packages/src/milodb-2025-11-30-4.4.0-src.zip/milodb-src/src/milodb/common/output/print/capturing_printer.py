# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from typing import override
from milodb.common.output.print.i_printer import IPrinter
from milodb.common.util.string_builder import StringBuilder

class CapturingPrinter(IPrinter):
    def __init__(self) -> None:
        self._text: StringBuilder = StringBuilder()
        self._is_on_new_line: bool = True

    @override
    def write(self, text: str) -> None:
        if text:
            self._text.put(text)
            self._is_on_new_line = text[-1] == '\n'

    @override
    def writeln(self, text: str | None = None) -> None:
        if text:
            self._text.put(text)
        self._text.put('\n')
        self._is_on_new_line = True

    @property
    @override
    def is_on_new_line(self) -> bool:
        return self._is_on_new_line

    def clear(self) -> None:
        self._text.clear()

    @override
    def __str__(self) -> str:
        return self.text

    @property
    def text(self) -> str:
        return self._text.get_text()
