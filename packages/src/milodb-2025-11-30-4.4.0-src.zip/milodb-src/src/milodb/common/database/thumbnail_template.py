# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from __future__ import annotations
import re
from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, override
if TYPE_CHECKING:
    from collections.abc import Callable, Mapping, Sequence

class IValidThumbnailKey(ABC):
    @property
    @abstractmethod
    def key_value(self) -> str:
        pass

    @property
    @abstractmethod
    def type_extension(self) -> str:
        pass

    @abstractmethod
    def to_url(self) -> str:
        pass

class IInvalidThumbnailKey:
    pass

def encode_thumbnail(thumbnail_url: str) -> IValidThumbnailKey | IInvalidThumbnailKey | None:
    parser: Callable[[str], IValidThumbnailKey | IInvalidThumbnailKey | None]
    for parser in _LIST_OF_THUMBNAIL_URL_PARSERS:
        template: IValidThumbnailKey | IInvalidThumbnailKey | None = parser(thumbnail_url)
        if template is not None:
            return template
    return None

def decode_thumbnail(thumbnail_key: str) -> IValidThumbnailKey | None:
    list_of_pieces: list[str] = thumbnail_key.split(_KEY_SPLIT_CHAR, maxsplit=1)
    if len(list_of_pieces) != _TWO_PIECES:
        return None
    template_key: str = list_of_pieces[0]
    thumbnail_key = list_of_pieces[1]
    parser: Callable[[str], IValidThumbnailKey | None] | None = _MAP_OF_THUMBNAIL_KEY_PARSERS.get(template_key)
    if parser:
        return parser(thumbnail_key)
    return None

# https://media.milovana.com/timg/tb_s/b07c279d51822e0abd55e275d817fe52f027994d.jpg
class _ThumbnailTemplateA(IValidThumbnailKey):
    TEMPLATE_KEY: str = 'A'
    _PREFIX: str = 'https://media.milovana.com/timg/tb_s/'
    _SUFFIX: str = '.jpg'
    _PATTERN: re.Pattern[str] = re.compile(rf'{re.escape(_PREFIX)}([a-z0-9]+){re.escape(_SUFFIX)}')

    @classmethod
    def try_parse_from_url(cls, url: str) -> IValidThumbnailKey | None:
        match: re.Match[str] | None = cls._PATTERN.fullmatch(url)
        if match is None:
            return None
        return cls(match.group(1))

    @override
    def __init__(self, key_part: str) -> None:
        self._key_part: str = key_part

    @property
    @override
    def key_value(self) -> str:
        return f'{self.TEMPLATE_KEY}{_KEY_SPLIT_CHAR}{self._key_part}'

    @property
    @override
    def type_extension(self) -> str:
        return self._SUFFIX

    @override
    def to_url(self) -> str:
        return f'{self._PREFIX}{self._key_part}{self._SUFFIX}'

# https://media.milovana.com/timg/8744/6475/tb_s/1.jpg
class _ThumbnailTemplateB(IValidThumbnailKey):
    TEMPLATE_KEY: str = 'B'
    _PREFIX: str = 'https://media.milovana.com/timg/'
    _SUFFIX: str = '.jpg'
    _PATTERN: re.Pattern[str] = re.compile(rf'{re.escape(_PREFIX)}([0-9]+/[0-9]+/tb_s/[^/]+){re.escape(_SUFFIX)}')

    @classmethod
    def try_parse_from_url(cls, url: str) -> IValidThumbnailKey | None:
        match: re.Match[str] | None = cls._PATTERN.fullmatch(url)
        if match is None:
            return None
        return cls(match.group(1))

    @override
    def __init__(self, key_part: str) -> None:
        self._key_part: str = key_part

    @property
    @override
    def key_value(self) -> str:
        return f'{self.TEMPLATE_KEY}{_KEY_SPLIT_CHAR}{self._key_part}'

    @property
    @override
    def type_extension(self) -> str:
        return self._SUFFIX

    @override
    def to_url(self) -> str:
        return f'{self._PREFIX}{self._key_part}{self._SUFFIX}'

# https://milovana.com/gx/unknown_s.gif?33
class _ThumbnailTemplateC(IValidThumbnailKey):
    TEMPLATE_KEY: str = 'C'
    _PREFIX: str = 'https://milovana.com/gx/'
    _SUFFIX: str = '.gif'
    _QUERY: str = '?33'
    _PATTERN: re.Pattern[str] = re.compile(rf'{re.escape(_PREFIX)}([^/\?]+){re.escape(_SUFFIX)}{re.escape(_QUERY)}')

    @classmethod
    def try_parse_from_url(cls, url: str) -> IValidThumbnailKey | None:
        match: re.Match[str] | None = cls._PATTERN.fullmatch(url)
        if match is None:
            return None
        return cls(match.group(1))

    @override
    def __init__(self, key_part: str) -> None:
        self._key_part: str = key_part

    @property
    @override
    def key_value(self) -> str:
        return f'{self.TEMPLATE_KEY}{_KEY_SPLIT_CHAR}{self._key_part}'

    @property
    @override
    def type_extension(self) -> str:
        return self._SUFFIX

    @override
    def to_url(self) -> str:
        return f'{self._PREFIX}{self._key_part}{self._SUFFIX}{self._QUERY}'

# https://milovana.com/gx/u_audio_s.png?33
class _ThumbnailTemplateD(IValidThumbnailKey):
    TEMPLATE_KEY: str = 'D'
    _PREFIX: str = 'https://milovana.com/gx/'
    _SUFFIX: str = '.png'
    _QUERY: str = '?33'
    _PATTERN: re.Pattern[str] = re.compile(rf'{re.escape(_PREFIX)}([^/\?]+){re.escape(_SUFFIX)}{re.escape(_QUERY)}')

    @classmethod
    def try_parse_from_url(cls, url: str) -> IValidThumbnailKey | None:
        match: re.Match[str] | None = cls._PATTERN.fullmatch(url)
        if match is None:
            return None
        return cls(match.group(1))

    @override
    def __init__(self, key_part: str) -> None:
        self._key_part: str = key_part

    @property
    @override
    def key_value(self) -> str:
        return f'{self.TEMPLATE_KEY}{_KEY_SPLIT_CHAR}{self._key_part}'

    @property
    @override
    def type_extension(self) -> str:
        return self._SUFFIX

    @override
    def to_url(self) -> str:
        return f'{self._PREFIX}{self._key_part}{self._SUFFIX}{self._QUERY}'

# https://media.milovana.com/timg/13488/11124/tb_s/100bpm.mp3
class _InvalidThumbnailTemplate(IInvalidThumbnailKey):
    _PATTERN: re.Pattern[str] = re.compile(r'.*\.mp3')

    @classmethod
    def try_parse_from_url(cls, url: str) -> IInvalidThumbnailKey | None:
        match: re.Match[str] | None = cls._PATTERN.fullmatch(url)
        if match is None:
            return None
        return cls()

_KEY_SPLIT_CHAR: str = ':'
_TWO_PIECES: int = 2

_LIST_OF_THUMBNAIL_URL_PARSERS: Sequence[Callable[[str], IValidThumbnailKey | IInvalidThumbnailKey | None]] = [
    _ThumbnailTemplateA.try_parse_from_url,
    _ThumbnailTemplateB.try_parse_from_url,
    _ThumbnailTemplateC.try_parse_from_url,
    _ThumbnailTemplateD.try_parse_from_url,
    _InvalidThumbnailTemplate.try_parse_from_url,
]

_MAP_OF_THUMBNAIL_KEY_PARSERS: Mapping[str, Callable[[str], IValidThumbnailKey | None]] = {
    _ThumbnailTemplateA.TEMPLATE_KEY: _ThumbnailTemplateA,
    _ThumbnailTemplateB.TEMPLATE_KEY: _ThumbnailTemplateB,
    _ThumbnailTemplateC.TEMPLATE_KEY: _ThumbnailTemplateC,
    _ThumbnailTemplateD.TEMPLATE_KEY: _ThumbnailTemplateD,
}
