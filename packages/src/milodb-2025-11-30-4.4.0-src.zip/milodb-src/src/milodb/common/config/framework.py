# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from __future__ import annotations
from abc import ABC, abstractmethod
from collections.abc import Iterator, Mapping, MutableMapping, Sequence
from enum import Enum
from typing import TYPE_CHECKING, override
from milodb.common.util import enums
if TYPE_CHECKING:
    from milodb.common.output.print.i_printer import IPrinter

class IConfig(ABC):
    @property
    @abstractmethod
    def dictionary(self) -> MutableMapping[object, object]:
        pass

class IPersistentConfig(IConfig):
    @abstractmethod
    def load(self, normal_printer: IPrinter, warning_printer: IPrinter, error_printer: IPrinter) -> None:
        pass

    @abstractmethod
    def save(self, normal_printer: IPrinter, warning_printer: IPrinter, error_printer: IPrinter) -> None:
        pass

    @abstractmethod
    def try_purge(self, normal_printer: IPrinter) -> bool:
        pass

class IConfigItem(ABC):
    @property
    @abstractmethod
    def key_name(self) -> str:
        pass

    @property
    @abstractmethod
    def default_value(self) -> str | Mapping[object, object]:
        pass

    @property
    @abstractmethod
    def parent(self) -> IConfigGroup | None:
        pass

    @property
    @abstractmethod
    def full_path(self) -> str:
        pass

    @abstractmethod
    def validate_existing(self, unknown: object, error_printer: IPrinter) -> None:
        pass

    @abstractmethod
    def report_redundancy(self, unknown: object, warning_printer: IPrinter) -> None:
        pass

    @abstractmethod
    def try_remove_redundancy(self, unknown: object, normal_printer: IPrinter) -> bool:
        pass

    @abstractmethod
    def try_add_missing(self, unknown: object, normal_printer: IPrinter) -> bool:
        pass

class IConfigLeaf(IConfigItem):
    @property
    @abstractmethod
    @override
    def default_value(self) -> str:
        pass

    @property
    @abstractmethod
    def is_protected(self) -> bool:
        pass

    @abstractmethod
    def fetch_value_or_default(self, config: IConfig) -> str:
        pass

    @abstractmethod
    def try_set_value(self, config: IConfig, value: str) -> bool:
        pass

class IConfigSetLeaf(IConfigLeaf):
    @property
    @abstractmethod
    def list_of_values(self) -> Sequence[str]:
        pass

class IConfigEnumLeaf[E: Enum](IConfigSetLeaf):
    @property
    @abstractmethod
    def default_enum_value(self) -> E:
        pass

    @property
    @abstractmethod
    def enum_class(self) -> type[E]:
        pass

    @abstractmethod
    def fetch_enum_value_or_default(self, config: IConfig) -> E:
        pass

class IConfigGroup(IConfigItem):
    @property
    @abstractmethod
    @override
    def default_value(self) -> Mapping[object, object]:
        pass

    @abstractmethod
    def add_child(self, child: IConfigItem) -> None:
        pass

    @property
    @abstractmethod
    def list_of_child_names(self) -> Iterator[str]:
        pass

    @property
    @abstractmethod
    def list_of_child_groups(self) -> Iterator[IConfigGroup]:
        pass

    @property
    @abstractmethod
    def list_of_child_leaves(self) -> Iterator[IConfigLeaf]:
        pass

    @abstractmethod
    def try_find_child(self, key_name: str) -> IConfigItem | None:
        pass

    @abstractmethod
    def try_find_child_group(self, key_name: str) -> IConfigGroup | None:
        pass

    @abstractmethod
    def try_find_child_leaf(self, key_name: str) -> IConfigLeaf | None:
        pass

class ConfigLeaf(IConfigLeaf):
    def __init__(self, parent: IConfigGroup, key_name: str, *, is_protected: bool) -> None:
        self._parent: IConfigGroup = parent
        self._key_name: str = key_name
        self._is_protected: bool = is_protected
        parent.add_child(self)

    @property
    @override
    def parent(self) -> IConfigGroup:
        return self._parent

    @property
    @override
    def key_name(self) -> str:
        return self._key_name

    @property
    @override
    def is_protected(self) -> bool:
        return self._is_protected

    @property
    @override
    def full_path(self) -> str:
        parent_path: str = self._parent.full_path
        if parent_path:
            return f'{parent_path}/{self._key_name}'
        return self._key_name

    @override
    def report_redundancy(self, unknown: object, warning_printer: IPrinter) -> None:
        """Single item cannot have redundancy."""

    @override
    def try_remove_redundancy(self, unknown: object, normal_printer: IPrinter) -> bool:
        """Single item cannot have redundancy."""
        return False

    @override
    def try_add_missing(self, unknown: object, normal_printer: IPrinter) -> bool:
        """Single item cannot add children."""
        return False

    def _seek_group_dict(self, root: MutableMapping[object, object]) -> MutableMapping[object, object] | None:
        group_dict: MutableMapping[object, object] | None = None

        hierarchy: list[IConfigGroup] = []
        temp_parent: IConfigGroup | None = self._parent
        while temp_parent is not None and temp_parent.key_name:
            hierarchy.append(temp_parent)
            temp_parent = temp_parent.parent

        unknown: object = root
        while hierarchy and isinstance(unknown, MutableMapping):
            group_dict = unknown
            key_name: str = hierarchy.pop().key_name
            unknown = group_dict.get(key_name)

        if not hierarchy and isinstance(unknown, MutableMapping):
            group_dict = unknown

        return group_dict

class ConfigTextLeaf(ConfigLeaf):
    def __init__(self, parent: IConfigGroup, key_name: str, default_value: str, *, is_protected: bool=False) -> None:
        super().__init__(parent, key_name, is_protected=is_protected)
        self._default_value: str = default_value

    @property
    @override
    def default_value(self) -> str:
        return self._default_value

    @override
    def validate_existing(self, unknown: object, error_printer: IPrinter) -> None:
        if not isinstance(unknown, str):
            error_printer.writeln(f"Config entry '{self.full_path}' is not text")

    @override
    def fetch_value_or_default(self, config: IConfig) -> str:
        group_dict: Mapping[object, object] | None = self._seek_group_dict(config.dictionary)
        if group_dict:
            value: object = group_dict.get(self._key_name)
            if isinstance(value, str):
                return value
        return self._default_value

    @override
    def try_set_value(self, config: IConfig, value: str) -> bool:
        group_dict: MutableMapping[object, object] | None = self._seek_group_dict(config.dictionary)
        if group_dict:
            group_dict[self.key_name] = value
            return True
        return False

class ConfigEnumLeaf[E: Enum](ConfigLeaf, IConfigEnumLeaf[E]):
    def __init__(self, parent: IConfigGroup, key_name: str, enum_class: type[E], default_value: E, *, is_protected: bool=False) -> None:
        super().__init__(parent, key_name, is_protected=is_protected)
        self._enum_class: type[E] = enum_class
        self._default_value: E = default_value

    @property
    @override
    def default_value(self) -> str:
        return self._default_value.name.lower()

    @property
    @override
    def list_of_values(self) -> Sequence[str]:
        return enums.lowercase_names(self._enum_class)

    @property
    @override
    def default_enum_value(self) -> E:
        return self._default_value

    @property
    @override
    def enum_class(self) -> type[E]:
        return self._enum_class

    @override
    def validate_existing(self, unknown: object, error_printer: IPrinter) -> None:
        if not isinstance(unknown, str):
            error_printer.writeln(f"Config entry '{self.full_path}' is not text")
        elif enums.try_lookup_name(self._enum_class, unknown, case_sensitive=False) is None:
            error_printer.writeln(f"Config entry '{self.full_path}' value '{unknown}' is not one of {enums.lowercase_names(self._enum_class)}")

    @override
    def fetch_value_or_default(self, config: IConfig) -> str:
        group_dict: Mapping[object, object] | None = self._seek_group_dict(config.dictionary)
        if group_dict:
            value: object = group_dict.get(self._key_name)
            if isinstance(value, str):
                enum: Enum | None = enums.try_lookup_name(self._enum_class, value, case_sensitive=False)
                if enum:
                    return enum.name.lower()
        return self._default_value.name.lower()

    @override
    def fetch_enum_value_or_default(self, config: IConfig) -> E:
        group_dict: Mapping[object, object] | None = self._seek_group_dict(config.dictionary)
        if group_dict:
            value: object = group_dict.get(self._key_name)
            if isinstance(value, str):
                enum: E | None = enums.try_lookup_name(self._enum_class, value, case_sensitive=False)
                if enum:
                    return enum
        return self._default_value

    @override
    def try_set_value(self, config: IConfig, value: str) -> bool:
        if value in enums.lowercase_names(self._enum_class):
            group_dict: MutableMapping[object, object] | None = self._seek_group_dict(config.dictionary)
            if group_dict:
                group_dict[self.key_name] = value
                return True
        return False

class ConfigGroup(IConfigGroup):
    def __init__(self, parent: IConfigGroup | None, key_name: str) -> None:
        self._parent: IConfigGroup | None = parent
        self._key_name: str = key_name
        self._list_of_children: list[IConfigItem] = []
        if parent is not None:
            parent.add_child(self)

    @property
    @override
    def parent(self) -> IConfigGroup | None:
        return self._parent

    @property
    @override
    def key_name(self) -> str:
        return self._key_name

    @property
    @override
    def default_value(self) -> Mapping[object, object]:
        group_dict: dict[object, object] = {}
        child: IConfigItem
        for child in self._list_of_children:
            group_dict[child.key_name] = child.default_value
        return group_dict

    @property
    @override
    def full_path(self) -> str:
        if self._parent is not None:
            parent_path: str = self._parent.full_path
            if parent_path:
                return f'{parent_path}/{self._key_name}'
        return self._key_name

    @override
    def validate_existing(self, unknown: object, error_printer: IPrinter) -> None:
        if isinstance(unknown, dict):
            group_dict: Mapping[object, object] = unknown
            child: IConfigItem
            for child in self._list_of_children:
                child_value: object = group_dict.get(child.key_name)
                if child_value is not None:
                    child.validate_existing(child_value, error_printer)
        else:
            error_printer.writeln(f"Config entry '{self.full_path}' is not a group")

    @override
    def report_redundancy(self, unknown: object, warning_printer: IPrinter) -> None:
        if isinstance(unknown, dict):
            group_dict: Mapping[object, object] = unknown
            key_name: object
            value: object
            for key_name, value in group_dict.items():
                was_found_in_schema: bool = False
                child: IConfigItem
                for child in self._list_of_children:
                    if key_name == child.key_name:
                        was_found_in_schema = True
                        child.report_redundancy(value, warning_printer)
                        break
                if not was_found_in_schema:
                    warning_printer.writeln(f"Config entry '{self._path_of_key_name(str(key_name))}' is not recognised")

    @override
    def try_remove_redundancy(self, unknown: object, normal_printer: IPrinter) -> bool: # NOSONAR
        has_any_redundancy: bool = False

        if isinstance(unknown, dict):
            group_dict: MutableMapping[object, object] = unknown
            key_name: object
            value: object
            list_of_redundant_key_names: list[object] = []
            for key_name, value in group_dict.items():
                was_found_in_schema: bool = False
                child: IConfigItem
                for child in self._list_of_children:
                    if key_name == child.key_name:
                        was_found_in_schema = True
                        has_any_redundancy = child.try_remove_redundancy(value, normal_printer) or has_any_redundancy
                        break
                if not was_found_in_schema:
                    has_any_redundancy = True
                    list_of_redundant_key_names.append(key_name)

            for key_name in list_of_redundant_key_names:
                del group_dict[key_name]
                normal_printer.writeln(f"Removed unrecognised config entry '{self._path_of_key_name(str(key_name))}'")

        return has_any_redundancy

    @override
    def try_add_missing(self, unknown: object, normal_printer: IPrinter) -> bool:
        was_anything_added: bool = False
        if isinstance(unknown, dict):
            group_dict: dict[object, object] = unknown
            child: IConfigItem
            for child in self._list_of_children:
                value: object = group_dict.get(child.key_name)
                if value is None:
                    normal_printer.writeln(f"Added config entry '{child.full_path}'")
                    group_dict[child.key_name] = child.default_value
                    was_anything_added = True
                else:
                    was_anything_added = child.try_add_missing(value, normal_printer) or was_anything_added
        return was_anything_added

    @override
    def add_child(self, child: IConfigItem) -> None:
        self._list_of_children.append(child)

    @property
    @override
    def list_of_child_names(self) -> Iterator[str]:
        child: IConfigItem
        for child in self._list_of_children:
            yield child.key_name

    @property
    @override
    def list_of_child_groups(self) -> Iterator[IConfigGroup]:
        child: IConfigItem
        for child in self._list_of_children:
            if isinstance(child, IConfigGroup):
                yield child

    @property
    @override
    def list_of_child_leaves(self) -> Iterator[IConfigLeaf]:
        child: IConfigItem
        for child in self._list_of_children:
            if isinstance(child, IConfigLeaf):
                yield child

    @override
    def try_find_child(self, key_name: str) -> IConfigItem | None:
        child: IConfigItem
        for child in self._list_of_children:
            if child.key_name == key_name:
                return child
        return None

    @override
    def try_find_child_group(self, key_name: str) -> IConfigGroup | None:
        child: IConfigItem | None = self.try_find_child(key_name)
        if isinstance(child, IConfigGroup):
            return child
        return None

    @override
    def try_find_child_leaf(self, key_name: str) -> IConfigLeaf | None:
        child: IConfigItem | None = self.try_find_child(key_name)
        if isinstance(child, IConfigLeaf):
            return child
        return None

    def _path_of_key_name(self, key_name: str) -> str:
        if self._parent:
            return f'{self.full_path}/{key_name}'
        return key_name
