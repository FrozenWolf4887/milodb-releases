# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from abc import ABC, abstractmethod
from enum import Enum

class LaunchOption(Enum):
    DEFAULT = 1
    NONE = 2
    CUSTOM = 3

class ILaunchConfig(ABC):
    @property
    @abstractmethod
    def launch_option(self) -> LaunchOption:
        pass

    @property
    @abstractmethod
    def custom_launch_command(self) -> str:
        pass

    @property
    @abstractmethod
    def custom_launch_as_shell(self) -> bool:
        pass
