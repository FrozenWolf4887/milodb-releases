# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from enum import Enum

class ArgType(Enum):
    ARG_UNKNOWN = 0
    ARG_FIELD = 1
    ARG_VERB = 2
    ARG_TEXT = 3
    ARG_REGEX = 4
    ARG_ENUM = 5
    ARG_INT = 6
    ARG_FLOAT = 7
    ARG_DATE = 8
    ARG_PATH = 9
    ARG_VARIABLE = 10
    ARG_REFID = 11
    ARG_KEYWORD = 12
    ARG_OPERATOR = 13
