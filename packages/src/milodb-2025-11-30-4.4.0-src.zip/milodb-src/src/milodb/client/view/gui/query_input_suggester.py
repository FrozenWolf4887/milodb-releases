# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from collections.abc import Sequence
from milodb.client.query.infix_query_parser import IInfixQueryParser, InfixError, PostfixQuery
from milodb.common.parser.arg import ArgumentError
from milodb.common.parser.arg_token_stream import ArgTokenStream
from milodb.common.parser.candidate_text import CandidateText
from milodb.common.parser.expanding_token_stream import ExpandedToken
from milodb.common.parser.token import Token
from milodb.common.parser.token_stream import TokenStreamError
from milodb.common.variables.i_user_variables import IUserVariables

class QueryInputSuggester:
    def __init__(self, user_variables: IUserVariables, infix_query_parser: IInfixQueryParser) -> None:
        self._user_variables = user_variables
        self._infix_parser: IInfixQueryParser = infix_query_parser

        self._list_of_suggestions: Sequence[CandidateText] = []
        self._suggestion_starting_index: int = 0

    @property
    def list_of_suggestions(self) -> Sequence[CandidateText]:
        return self._list_of_suggestions

    @property
    def suggestion_starting_index(self) -> int:
        return self._suggestion_starting_index

    def update(self, text: str, cursor_index: int) -> None:
        self._list_of_suggestions = []
        self._suggestion_starting_index = 0

        list_of_candidate_text: Sequence[CandidateText] = []

        text_of_tokens_before_cursor: str = text[:cursor_index]
        arg_token_stream: ArgTokenStream = ArgTokenStream(text_of_tokens_before_cursor, self._user_variables, None, None, stop_before_character_index=cursor_index)
        arg_token_stream.set_keep_delimiters('()')

        fault_token: Token | None = None
        try:
            postfix_query: PostfixQuery = self._infix_parser.convert_to_postfix(arg_token_stream)
        except (ArgumentError, InfixError, TokenStreamError) as ex:
            fault_token = ex.fault_token
            list_of_candidate_text = ex.list_of_candidate_text
        else:
            list_of_candidate_text = postfix_query.list_of_candidate_text

        if fault_token:
            self._generate_suggestions_from_fault(fault_token, list_of_candidate_text, cursor_index)
        else:
            self._generate_suggestions_from_end(arg_token_stream.get_stopped_on_token(), list_of_candidate_text)

    def _generate_suggestions_from_fault(self, fault_token: Token, list_of_candidate_text: Sequence[CandidateText], cursor_index: int) -> None:
        if isinstance(fault_token, ExpandedToken):
            fault_token = fault_token.topmost_token

        if fault_token.inner_indices.end >= cursor_index:
            if fault_token.text.startswith('$'):
                self._list_of_suggestions = CandidateText.space_delimited_list([
                    f'${name}' for name in self._user_variables.get_list_of_names() if name.startswith(fault_token.text[1:])
                ])
            else:
                self._list_of_suggestions = [
                    candidate_text for candidate_text in list_of_candidate_text if candidate_text.text.startswith(fault_token.text)
                ]
            self._suggestion_starting_index = len(fault_token.text)

    def _generate_suggestions_from_end(self, stopped_on_token: Token | None, list_of_candidate_text: Sequence[CandidateText]) -> None:
        if stopped_on_token:
            if stopped_on_token.text.startswith('$'):
                self._list_of_suggestions = CandidateText.space_delimited_list([
                    f'${name}' for name in self._user_variables.get_list_of_names() if name.startswith(stopped_on_token.text[1:])
                ])
            else:
                self._list_of_suggestions = [
                    candidate_text for candidate_text in list_of_candidate_text if candidate_text.text.startswith(stopped_on_token.text)
                ]
            self._suggestion_starting_index = len(stopped_on_token.text)
        else:
            self._list_of_suggestions = list_of_candidate_text
            self._suggestion_starting_index = 0
