# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from __future__ import annotations
import tkinter as tk
from enum import Enum
from tkinter import ttk
from typing import override
from PIL import ImageTk
from milodb.client.view.gui import generated_images
from milodb.client.view.gui.frame_widgets import WrappingLabel
from milodb.client.view.gui.modal_dialog import ModalDialog
from milodb.client.view.gui.theme import Style
from milodb.common.view.gui.metrics import Padding

_ICON_HEIGHT: int = 48
_ICON_PADDING: Padding = Padding(8, 8, 0, 0)
_HEADING_PADDING: Padding = Padding(8, 8, 8, 0)
_DETAIL_PADDING: Padding = Padding(8, 8, 8, 8)

class PromptDialog(ModalDialog):
    class Icon(Enum):
        WARNING = 0
        ERROR = 1

    class Buttons(Enum):
        OKAY = 0
        YES_NO = 1
        CANCEL = 2
        OKAY_CANCEL = 3

    class Response(Enum):
        OKAY = 0
        YES = 1
        NO = 2
        CANCEL = 3

    def __init__(self, master: tk.Toplevel | tk.Tk, *, icon: Icon, headline_text: str, detail_text: str, title: str, buttons: Buttons=Buttons.OKAY, width: int=400, height: int=160) -> None:
        super().__init__(master, width=width, height=height, title=title, closeable=buttons==PromptDialog.Buttons.OKAY)

        self._icon_image: ImageTk.PhotoImage
        match icon:
            case PromptDialog.Icon.WARNING:
                self._icon_image = ImageTk.PhotoImage(generated_images.render_warning_image(image_height=_ICON_HEIGHT))
            case PromptDialog.Icon.ERROR:
                self._icon_image = ImageTk.PhotoImage(generated_images.render_error_image(image_height=_ICON_HEIGHT))

        ttk.Label(self.content_frame, image=self._icon_image).grid(row=0, column=0, padx=(_ICON_PADDING.left, _ICON_PADDING.right), pady=(_ICON_PADDING.top, _ICON_PADDING.bottom), sticky=tk.NS)
        WrappingLabel(self.content_frame, text=headline_text, style=Style.OnDialog.HeadingLabel.STYLE_NAME).grid(row=0, column=1, padx=(_HEADING_PADDING.left, _HEADING_PADDING.right), pady=(_HEADING_PADDING.top, _HEADING_PADDING.bottom), sticky=tk.NSEW)
        WrappingLabel(self.content_frame, text=detail_text, style=Style.OnDialog.DetailLabel.STYLE_NAME).grid(row=1, column=0, columnspan=2, padx=(_DETAIL_PADDING.left, _DETAIL_PADDING.right), pady=(_DETAIL_PADDING.top, _DETAIL_PADDING.bottom), sticky=tk.NSEW)

        self.content_frame.columnconfigure(1, weight=1)

        match buttons:
            case PromptDialog.Buttons.OKAY:
                self.add_button('Okay', column=0, command=lambda: self._on_button(PromptDialog.Response.OKAY))
            case PromptDialog.Buttons.YES_NO:
                self.add_button('Yes', column=0, command=lambda: self._on_button(PromptDialog.Response.YES))
                self.add_button('No', column=1, command=lambda: self._on_button(PromptDialog.Response.NO))
            case PromptDialog.Buttons.CANCEL:
                self.add_button('Okay', column=0, command=lambda: self._on_button(PromptDialog.Response.OKAY))
                self.add_button('Cancel', column=1, command=lambda: self._on_button(PromptDialog.Response.CANCEL))
            case PromptDialog.Buttons.OKAY_CANCEL:
                self.add_button('Okay', column=0, command=lambda: self._on_button(PromptDialog.Response.OKAY))
                self.add_button('Cancel', column=1, command=lambda: self._on_button(PromptDialog.Response.CANCEL))

        self._response_variable = tk.Variable(self)

    @override
    def destroy(self) -> None:
        if not self._response_variable.get():
            self._response_variable.set(self.Response.CANCEL)
        super().destroy()

    def wait_response(self) -> Response:
        self.wait_variable(self._response_variable)
        return self._response_variable.get() or self.Response.CANCEL

    def _on_button(self, response: Response) -> None:
        self._response_variable.set(response)
        self.destroy()
