# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from __future__ import annotations
import tkinter as tk
from milodb.client.view.gui.log_text import LogText
from milodb.client.view.gui.modal_dialog import ModalDialog

class LogDialog(ModalDialog):
    def __init__(self, master: tk.Toplevel | tk.Tk, *, title:str, debug_enabled: bool=False) -> None:
        super().__init__(master, width=480, height=400, title=title)

        self._log_text: LogText = LogText(self.content_frame)
        self._log_text.debug_printer.enabled = debug_enabled
        self._log_text.pack(fill=tk.BOTH, expand=True)

    @property
    def log_text(self) -> LogText:
        return self._log_text

    def show_okay_button(self) -> None:
        self.add_button('Okay', column=0, command=self.destroy)
