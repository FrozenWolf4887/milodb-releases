# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import tkinter as tk
from tkinter import ttk
from types import TracebackType
from typing import Self
from milodb.client.view.gui import  general_layout
from milodb.client.view.gui.modal_dialog import ModalDialog

_LAYOUT_PADDING_X: int = general_layout.PANEL_PADDING_X
_LAYOUT_PADDING_Y: int = general_layout.PANEL_PADDING_Y

class QueryProgressDialog(ModalDialog):
    def __init__(self, master: tk.Toplevel | tk.Tk, number_of_teases: int) -> None:
        super().__init__(master, width=200, height=100, title='Searching...', resizeable=False, closeable=False)

        self._progress_value: tk.IntVar = tk.IntVar(self.content_frame)
        self._progress_text: tk.StringVar = tk.StringVar(self.content_frame)

        ttk.Label(self.content_frame, textvariable=self._progress_text, anchor=tk.CENTER, justify=tk.CENTER).grid(row=0, column=0, pady=_LAYOUT_PADDING_Y, sticky=tk.N)
        progress_bar: ttk.Progressbar = ttk.Progressbar(self.content_frame, variable=self._progress_value)
        progress_bar.grid(row=1, column=0, padx=_LAYOUT_PADDING_X, pady=_LAYOUT_PADDING_Y, sticky=tk.EW)
        ttk.Label(self.content_frame, text=f'Searching {number_of_teases:,} teases', anchor=tk.CENTER, justify=tk.CENTER).grid(row=2, column=0, padx=_LAYOUT_PADDING_X, pady=_LAYOUT_PADDING_Y, sticky=tk.N)

        self.content_frame.columnconfigure(0, weight=1)

    def show_progress(self, *, percentage_complete: int) -> None:
        self._progress_text.set(f'{percentage_complete}%')
        self._progress_value.set(percentage_complete)
        self.content_frame.update()

    def __enter__(self) -> Self:
        return self

    def __exit__(self, exc_type: type[BaseException] | None, exc_value: BaseException | None, traceback: TracebackType | None) -> None:
        self.destroy()
