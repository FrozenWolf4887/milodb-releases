# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from __future__ import annotations
from enum import Enum
from math import floor, hypot
from typing import TYPE_CHECKING
from milodb.client.view.gui.geometric_shapes import make_bezier_points
from milodb.common.view.gui.metrics import Point, RelPoint
if TYPE_CHECKING:
    from collections.abc import Iterable

class Alignment(Enum):
    NORTH = 1
    NORTH_EAST = 2
    EAST = 3
    SOUTH_EAST = 4
    SOUTH = 5
    SOUTH_WEST = 6
    WEST = 7
    NORTH_WEST = 8
    CENTER = 9

class Flip(Enum):
    HORIZONTAL_AT_LEFT = 1
    HORIZONTAL_AT_RIGHT = 2
    HORIZONTAL_AT_MIDDLE = 3
    VERTICAL_AT_TOP = 4
    VERTICAL_AT_BOTTOM = 5
    VERTICAL_AT_MIDDLE = 6

class Turtle:
    def __init__(self) -> None:
        self._list_of_shapes: list[TurtleShape] = []

    def add_shape(self, shape: TurtleShape) -> None:
        self._list_of_shapes.append(shape)

    def raise_to_top(self, shape: TurtleShape) -> None:
        self._list_of_shapes.remove(shape)
        self._list_of_shapes.append(shape)

    def lower_to_bottom(self, shape: TurtleShape) -> None:
        self._list_of_shapes.remove(shape)
        self._list_of_shapes.insert(0, shape)

    @property
    def list_of_shapes(self) -> Iterable[TurtleShape]:
        return self._list_of_shapes

    def calc_width(self) -> float:
        return self.calc_max_x() - self.calc_min_x()

    def calc_height(self) -> float:
        return self.calc_max_y() - self.calc_min_y()

    def calc_min_x(self) -> float:
        if self._list_of_shapes:
            return min(shape.calc_min_x() for shape in self._list_of_shapes)
        return 0

    def calc_max_x(self) -> float:
        if self._list_of_shapes:
            return max(shape.calc_max_x() for shape in self._list_of_shapes)
        return 0

    def calc_min_y(self) -> float:
        if self._list_of_shapes:
            return min(shape.calc_min_y() for shape in self._list_of_shapes)
        return 0

    def calc_max_y(self) -> float:
        if self._list_of_shapes:
            return max(shape.calc_max_y() for shape in self._list_of_shapes)
        return 0

    def calc_middle_x(self) -> float:
        return (self.calc_min_x() + self.calc_max_x()) / 2

    def calc_middle_y(self) -> float:
        return (self.calc_min_y() + self.calc_max_y()) / 2

    def calc_top_left(self) -> Point:
        return Point(self.calc_min_x(), self.calc_min_y())

    def calc_top_middle(self) -> Point:
        return Point(self.calc_middle_x(), self.calc_min_y())

    def calc_top_right(self) -> Point:
        return Point(self.calc_max_x(), self.calc_min_y())

    def calc_right_middle(self) -> Point:
        return Point(self.calc_max_x(), self.calc_middle_y())

    def calc_bottom_right(self) -> Point:
        return Point(self.calc_max_x(), self.calc_max_y())

    def calc_bottom_middle(self) -> Point:
        return Point(self.calc_middle_x(), self.calc_max_y())

    def calc_bottom_left(self) -> Point:
        return Point(self.calc_min_x(), self.calc_max_y())

    def calc_left_middle(self) -> Point:
        return Point(self.calc_min_x(), self.calc_middle_y())

    def calc_middle(self) -> Point:
        return Point(self.calc_middle_x(), self.calc_middle_y())

class TurtleShape:
    def __init__(self, turtle: Turtle, origin: Point | None = None, initial_list_of_points: Iterable[Point] | None = None) -> None:
        self._turtle: Turtle = turtle
        self._origin: Point = origin or Point(0, 0)
        self._point: Point = self._origin
        self._list_of_points: list[Point] = list(initial_list_of_points) if initial_list_of_points else [ self._origin ]

        self._turtle.add_shape(self)

    def line(self, point: Point | RelPoint) -> TurtleShape:
        if isinstance(point, RelPoint):
            point = point.relative_to(self._point)
        self._list_of_points.append(point)
        self._point = point
        return self

    def bezier(self, point1: Point | RelPoint, point2: Point | RelPoint, point3: Point | RelPoint | None = None) -> TurtleShape:
        if isinstance(point1, RelPoint):
            point1 = point1.relative_to(self._point)
        if isinstance(point2, RelPoint):
            point2 = point2.relative_to(self._point)
        if isinstance(point3, RelPoint):
            point3 = point3.relative_to(self._point)

        length_ish: float = hypot(point1.x - self._point.x, point1.y - self._point.y) + hypot(point2.x - point1.x, point2.y - point1.y)
        if point3 is not None:
            length_ish += hypot(point3.x - point2.x, point3.y - point2.y)

        number_of_segments: int = max(floor(length_ish / 10), 1)
        self._list_of_points.extend(
            make_bezier_points(
                number_of_segments,
                self._point,
                point1,
                point2,
                point3,
                include_first_point = False,
            ),
        )
        self._point = self._list_of_points[-1]
        return self

    def curve(self, point: Point | RelPoint, *, extent: int) -> TurtleShape:
        if isinstance(point, RelPoint):
            point = point.relative_to(self._point)
        corner_point: Point = self._point
        start_point: Point = _move_along_line(self._list_of_points[-2], self._point, -extent)
        self._list_of_points[-1] = start_point
        end_point: Point = _move_along_line(point, corner_point, -extent)
        self._point = start_point
        self.bezier(corner_point, end_point)
        self.line(point)
        return self

    def scale(self, *, width: float = 1.0, height: float = 1.0) -> TurtleShape:
        self._list_of_points = [
            Point(point.x * width, point.y * height) for point in self._list_of_points
        ]
        self._point = self._list_of_points[-1]
        return self

    def flip(self, flip_option: Flip) -> TurtleShape:
        match flip_option:
            case Flip.HORIZONTAL_AT_LEFT:
                self._flip_horizontally(2 * self.calc_min_x())
            case Flip.HORIZONTAL_AT_RIGHT:
                self._flip_horizontally(2 * self.calc_max_x())
            case Flip.HORIZONTAL_AT_MIDDLE:
                self._flip_horizontally(self.calc_middle_x())
            case Flip.VERTICAL_AT_TOP:
                self._flip_vertically(2 * self.calc_min_y())
            case Flip.VERTICAL_AT_BOTTOM:
                self._flip_vertically(2 * self.calc_max_y())
            case Flip.VERTICAL_AT_MIDDLE:
                self._flip_vertically(2 * self.calc_middle_y())
        self._point = self._list_of_points[-1]
        return self

    def translate(self, *, left: float = 0, right: float = 0, up: float = 0, down: float = 0) -> TurtleShape:
        horizontal: float = right - left
        vertical: float = down - up
        self._list_of_points = [
            Point(point.x + horizontal, point.y + vertical) for point in self._list_of_points
        ]
        return self

    def align(self, alignment: Alignment, point: Point | RelPoint) -> TurtleShape: # noqa: C901 too complex # pylint: disable=too-complex
        if isinstance(point, RelPoint):
            point = point.relative_to(self._point)

        match alignment:
            case Alignment.NORTH_WEST:
                self.translate(
                    left = self.calc_min_x() - point.x,
                    up = self.calc_min_y() - point.y,
                )
            case Alignment.NORTH:
                self.translate(
                    up = self.calc_min_y() - point.y,
                )
            case Alignment.NORTH_EAST:
                self.translate(
                    left = self.calc_max_x() - point.x,
                    up = self.calc_min_y() - point.y,
                )
            case Alignment.EAST:
                self.translate(
                    left = self.calc_max_x() - point.x,
                )
            case Alignment.SOUTH_EAST:
                self.translate(
                    left = self.calc_max_x() - point.x,
                    up = self.calc_max_y() - point.y,
                )
            case Alignment.SOUTH:
                self.translate(
                    up = self.calc_max_y() - point.y,
                )
            case Alignment.SOUTH_WEST:
                self.translate(
                    left = self.calc_min_x() - point.x,
                    up = self.calc_max_y() - point.y,
                )
            case Alignment.WEST:
                self.translate(
                    left = self.calc_min_x() - point.x,
                )
            case Alignment.CENTER:
                self.translate(
                    left = self.calc_middle_x() - point.x,
                    up = self.calc_middle_y() - point.y,
                )

        return self

    def raise_to_top(self) -> TurtleShape:
        self._turtle.raise_to_top(self)
        return self

    def lower_to_bottom(self) -> TurtleShape:
        self._turtle.lower_to_bottom(self)
        return self

    def copy(self) -> TurtleShape:
        return TurtleShape(self._turtle, self._origin, self._list_of_points)

    @property
    def origin(self) -> Point:
        return self._origin

    def calc_points(self, alignment: Alignment | None, *, align_x: float=0, align_y: float=0) -> list[Point]: # noqa: C901 too complex # pylint: disable=too-complex
        offset_x: float
        offset_y: float
        match alignment:
            case Alignment.NORTH:
                offset_x = self.calc_middle_x()
                offset_y = self.calc_min_y()
            case Alignment.NORTH_EAST:
                offset_x = self.calc_max_x()
                offset_y = self.calc_min_y()
            case Alignment.EAST:
                offset_x = self.calc_max_x()
                offset_y = self.calc_middle_y()
            case Alignment.SOUTH_EAST:
                offset_x = self.calc_max_x()
                offset_y = self.calc_max_y()
            case Alignment.SOUTH:
                offset_x = self.calc_middle_x()
                offset_y = self.calc_max_y()
            case Alignment.SOUTH_WEST:
                offset_x = self.calc_min_x()
                offset_y = self.calc_max_y()
            case Alignment.WEST:
                offset_x = self.calc_min_x()
                offset_y = self.calc_middle_y()
            case Alignment.NORTH_WEST:
                offset_x = self._turtle.calc_min_x()
                offset_y = self._turtle.calc_min_y()
            case Alignment.CENTER:
                offset_x = self.calc_middle_x()
                offset_y = self.calc_middle_y()
            case None:
                offset_x = 0.0
                offset_y = 0.0

        offset_x -= align_x
        offset_y -= align_y
        return [ Point(point.x - offset_x, point.y - offset_y) for point in self._list_of_points ]

    def calc_width(self) -> float:
        return self.calc_max_x() - self.calc_min_x()

    def calc_height(self) -> float:
        return self.calc_max_y() - self.calc_min_y()

    def calc_min_x(self) -> float:
        return min(point.x for point in self._list_of_points)

    def calc_max_x(self) -> float:
        return max(point.x for point in self._list_of_points)

    def calc_min_y(self) -> float:
        return min(point.y for point in self._list_of_points)

    def calc_max_y(self) -> float:
        return max(point.y for point in self._list_of_points)

    def calc_middle_x(self) -> float:
        return (self.calc_min_x() + self.calc_max_x()) / 2

    def calc_middle_y(self) -> float:
        return (self.calc_min_y() + self.calc_max_y()) / 2

    def calc_top_left(self) -> Point:
        return Point(self.calc_min_x(), self.calc_min_y())

    def calc_top_middle(self) -> Point:
        return Point(self.calc_middle_x(), self.calc_min_y())

    def calc_top_right(self) -> Point:
        return Point(self.calc_max_x(), self.calc_min_y())

    def calc_right_middle(self) -> Point:
        return Point(self.calc_max_x(), self.calc_middle_y())

    def calc_bottom_right(self) -> Point:
        return Point(self.calc_max_x(), self.calc_max_y())

    def calc_bottom_middle(self) -> Point:
        return Point(self.calc_middle_x(), self.calc_max_y())

    def calc_bottom_left(self) -> Point:
        return Point(self.calc_min_x(), self.calc_max_y())

    def calc_left_middle(self) -> Point:
        return Point(self.calc_min_x(), self.calc_middle_y())

    def calc_middle(self) -> Point:
        return Point(self.calc_middle_x(), self.calc_middle_y())

    def _flip_horizontally(self, offset: float) -> None:
        self._list_of_points = [
            Point(offset - point.x, point.y) for point in self._list_of_points
        ]

    def _flip_vertically(self, offset: float) -> None:
        self._list_of_points = [
            Point(point.x, offset - point.y) for point in self._list_of_points
        ]

def _move_along_line(point1: Point, point2: Point, extent: float) -> Point:
    vector_x: float
    vector_y: float
    vector_x, vector_y = _unit_vector(point1, point2)
    return Point(point2.x + extent * vector_x, point2.y + extent * vector_y)

def _unit_vector(point1: Point, point2: Point) -> tuple[float, float]:
    width: float = point2.x - point1.x
    height: float = point2.y - point1.y
    magnitude: float = hypot(width, height)
    return width / magnitude, height / magnitude
