# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import tkinter as tk
from collections.abc import Callable
from tkinter import ttk
from typing import override
from milodb.client.view.gui import general_layout, tk_type
from milodb.client.view.gui.styled_frame import StyledFrame
from milodb.client.view.gui.theme import Colour

_LAYOUT_RELIEF: tk_type.Relief = general_layout.PANEL_RELIEF
_LAYOUT_BORDER_WIDTH: int = general_layout.PANEL_BORDER_WIDTH
_LAYOUT_PADDING_X: int = general_layout.PANEL_PADDING_X
_LAYOUT_PADDING_Y: int = general_layout.PANEL_PADDING_Y

class ModalDialog(tk.Toplevel):
    def __init__(self, master: tk.Toplevel | tk.Tk, width: int=640, height: int=480, *, title: str, resizeable: bool=True, closeable: bool=True) -> None:
        super().__init__(master, background=Colour.TopLevel.DIALOG_BACK, relief=_LAYOUT_RELIEF, padx=_LAYOUT_PADDING_X, pady=_LAYOUT_PADDING_Y, borderwidth=_LAYOUT_BORDER_WIDTH)

        left: int = master.winfo_x() + (master.winfo_width() - width) // 2
        top: int = master.winfo_y() + (master.winfo_height() - height) // 3
        self.geometry(f'{width}x{height}+{left}+{top}')
        self.transient(master)
        if title:
            self.title(title)
        if not resizeable:
            self.resizable(width=False, height=False)
        if not closeable:
            self.protocol("WM_DELETE_WINDOW", self.update)

        self._content_frame: StyledFrame = StyledFrame(self)
        self._content_frame.grid(row=0, column=0, sticky=tk.NSEW)
        self._button_back_frame: StyledFrame = StyledFrame(self)
        self._button_back_frame.grid(row=1, column=0, sticky=tk.EW)
        self._button_frame: StyledFrame = StyledFrame(self._button_back_frame)
        self._button_frame.pack(anchor=tk.CENTER)

        self._is_destroyed: bool = False
        self._map_of_column_to_list_of_buttons: dict[int, list[ttk.Button]] = {}

        self.rowconfigure(0, weight=1)
        self.columnconfigure(0, weight=1)

        self.wait_visibility()
        self.focus()
        self.grab_set()

    @override
    def destroy(self) -> None:
        self.grab_release()
        super().destroy()

    @property
    def content_frame(self) -> StyledFrame:
        return self._content_frame

    def add_button(self, text: str, *, column: int, command: Callable[[], None], is_hidden: bool=False) -> None:
        if not self._map_of_column_to_list_of_buttons:
            self._button_back_frame.columnconfigure(0, weight=1)
        button: ttk.Button = ttk.Button(self._button_frame, text=text, command=command, state=tk.NORMAL)
        if not is_hidden:
            button.grid(row=0, column=column, padx=_LAYOUT_PADDING_X, pady=_LAYOUT_PADDING_Y)
        self._map_of_column_to_list_of_buttons.setdefault(column, []).append(button)

    def hide_button(self, column: int) -> None:
        list_of_buttons: list[ttk.Button] | None = self._map_of_column_to_list_of_buttons.get(column)
        if list_of_buttons:
            button: ttk.Button
            for button in list_of_buttons:
                button.grid_forget()

    def show_button(self, column: int) -> None:
        list_of_buttons: list[ttk.Button] | None = self._map_of_column_to_list_of_buttons.get(column)
        if list_of_buttons:
            button: ttk.Button
            for button in list_of_buttons:
                button.grid(row=0, column=column, padx=_LAYOUT_PADDING_X, pady=_LAYOUT_PADDING_Y)

    def focus_button(self, column: int) -> None:
        list_of_buttons: list[ttk.Button] | None = self._map_of_column_to_list_of_buttons.get(column)
        if list_of_buttons:
            list_of_buttons[0].focus()
