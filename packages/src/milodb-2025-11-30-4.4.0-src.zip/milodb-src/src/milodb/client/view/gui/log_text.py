# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import tkinter as tk
from tkinter import ttk
from typing import override
from milodb.client.view.gui.styled_frame import StyledFrame
from milodb.client.view.gui.styled_text import StyledText
from milodb.client.view.gui.theme import Colour, Style
from milodb.client.view.gui.tk_interceptor import TkInterceptor
from milodb.common.output.print.debug_printer import DebugPrinter
from milodb.common.output.print.i_printer import IPrinter

_TAG_WARNING: str = 'wrn'
_TAG_ERROR: str = 'err'
_TAG_FATAL: str = 'fat'

class LogText(StyledFrame):
    def __init__(self, master: tk.Misc, line_count: int=3) -> None:
        super().__init__(master, style=Style.Generic.LogFrame.STYLE_NAME)
        self._scrollbar: ttk.Scrollbar = ttk.Scrollbar(self, orient=tk.VERTICAL)
        self._textbox: StyledText = StyledText(self, line_count=line_count, style=Style.OnDialog.LogText.STYLE_NAME, yscrollcommand=self._scrollbar.set)
        self._scrollbar.config(command=self._textbox.yview)

        self._scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self._textbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        self._textbox.tag_config(_TAG_WARNING, background=Colour.LogText.WARNING_BACK, foreground=Colour.LogText.WARNING_FORE)
        self._textbox.tag_config(_TAG_ERROR, background=Colour.LogText.ERROR_BACK, foreground=Colour.LogText.ERROR_FORE)
        self._textbox.tag_config(_TAG_FATAL, background=Colour.LogText.FATAL_BACK, foreground=Colour.LogText.FATAL_FORE)
        _set_text_readonly(self._textbox)

        self._text_widget_printer: _TextWidgetPrinter = _TextWidgetPrinter(self._textbox)
        self._warning_printer: _CountingPrinter = _CountingPrinter(_ColouredPrefixPrinter('Warning', ': ', self._text_widget_printer, _TAG_WARNING))
        self._error_printer: _CountingPrinter = _CountingPrinter(_ColouredPrefixPrinter('Error', ':' , self._text_widget_printer, _TAG_ERROR))
        self._fatal_printer: _CountingPrinter = _CountingPrinter(_ColouredPrefixPrinter('FATAL', ': ', self._text_widget_printer, _TAG_FATAL))
        self._debug_printer: DebugPrinter = DebugPrinter(self._text_widget_printer)

    @property
    def textbox(self) -> StyledText:
        return self._textbox

    @property
    def normal_printer(self) -> IPrinter:
        return self._text_widget_printer

    @property
    def warning_printer(self) -> IPrinter:
        return self._warning_printer

    @property
    def error_printer(self) -> IPrinter:
        return self._error_printer

    @property
    def fatal_printer(self) -> IPrinter:
        return self._fatal_printer

    @property
    def debug_printer(self) -> DebugPrinter:
        return self._debug_printer

    @property
    def any_warnings_or_errors(self) -> bool:
        return any([self._warning_printer.count, self._error_printer.count, self._fatal_printer.count])

class _CountingPrinter(IPrinter):
    def __init__(self, delegate: IPrinter) -> None:
        self._delegate: IPrinter = delegate
        self._count: int = 0

    @property
    def count(self) -> int:
        return self._count

    @override
    def write(self, text: str) -> None:
        self._count += 1
        self._delegate.write(text)

    @override
    def writeln(self, text: str | None = None) -> None:
        self._count += 1
        self._delegate.writeln(text)

    @property
    @override
    def is_on_new_line(self) -> bool:
        return self._delegate.is_on_new_line

class _TextWidgetPrinter(IPrinter):
    def __init__(self, textbox: tk.Text) -> None:
        self._textbox: tk.Text = textbox
        self._is_on_newline: bool = True

    @override
    def write(self, text: str) -> None:
        if text:
            self._textbox.insert(tk.END, text)
            self._is_on_newline = text[-1] == '\n'
            self._textbox.see(tk.END)
            self._textbox.update()

    @override
    def writeln(self, text: str | None = None) -> None:
        if text:
            self._textbox.insert(tk.END, text + '\n')
        else:
            self._textbox.insert(tk.END, '\n')
        self._is_on_newline = True
        self._textbox.see(tk.END)
        self._textbox.update()

    @property
    @override
    def is_on_new_line(self) -> bool:
        return self._is_on_newline

    def write_with_tag(self, text: str, tag_name: str) -> None:
        if text:
            self._textbox.insert(tk.END, text, tag_name)
            self._is_on_newline = text[-1] == '\n'
            self._textbox.see(tk.END)
            self._textbox.update()

class _ColouredPrefixPrinter(IPrinter):
    def __init__(self, prefix: str, infix: str, widget: _TextWidgetPrinter, tag_name: str) -> None:
        self._prefix: str = prefix
        self._infix: str = infix
        self._widget: _TextWidgetPrinter = widget
        self._tag_name: str = tag_name

    @override
    def write(self, text: str) -> None:
        self._widget.write_with_tag(self._prefix, self._tag_name)
        self._widget.write(self._infix)
        self._widget.write(text)

    @override
    def writeln(self, text: str | None = None) -> None:
        if text:
            self.write(text + '\n')
        else:
            self.write('\n')

    @property
    @override
    def is_on_new_line(self) -> bool:
        return self._widget.is_on_new_line

def _set_text_readonly(widget: tk.Widget) -> None:
    def do_nothing(*_args: object) -> None:
        ...
    def on_tk_insert_call(*args: object) -> object:
        return original_tk_insert(*args)
    def on_tk_delete_call(*args: object) -> object:
        return original_tk_delete(*args)
    interceptor: TkInterceptor = TkInterceptor(widget)
    original_tk_insert: TkInterceptor.Handler = interceptor.intercept('insert', do_nothing, on_tk_insert_call)
    original_tk_delete: TkInterceptor.Handler = interceptor.intercept('delete', do_nothing, on_tk_delete_call)
