# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import tkinter as tk
from types import TracebackType

class WaitCursor:
    def __init__(self, master: tk.Toplevel | tk.Tk) -> None:
        self._master: tk.Toplevel | tk.Tk = master

    def __enter__(self) -> None:
        self._master.configure(cursor='watch')

    def __exit__(self, exc_type: type[BaseException] | None, exc_value: BaseException | None, traceback: TracebackType | None) -> None:
        self._master.configure(cursor='')
