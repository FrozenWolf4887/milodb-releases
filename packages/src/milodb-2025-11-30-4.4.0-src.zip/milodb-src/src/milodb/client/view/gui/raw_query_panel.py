# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import tkinter as tk
from collections.abc import Iterable, Mapping, Sequence
from dataclasses import dataclass
from tkinter import ttk
from typing import override
from PIL import ImageTk
from milodb.client.database.tease import Tease
from milodb.client.query.infix_query_parser import InfixError, InfixQueryParser, PostfixQuery
from milodb.client.query.postfix_query_executor import PostfixError, PostfixQueryExecutor, PostfixQueryResult
from milodb.client.query.query import IQuery
from milodb.client.query.tease_match import TeaseMatch
from milodb.client.util.sort_keys import OrderedSortKey
from milodb.client.util.tease_match_sorter import ITeaseMatchSorter
from milodb.client.view.gui import generated_images
from milodb.client.view.gui.prompt_dialog import PromptDialog
from milodb.client.view.gui.query_input_suggester import QueryInputSuggester
from milodb.client.view.gui.query_progress_dialog import QueryProgressDialog
from milodb.client.view.gui.styled_frame import StyledFrame
from milodb.client.view.gui.text_ex import TextEx
from milodb.client.view.gui.theme import Colour, Style, get_font_of_themed_widget
from milodb.client.view.gui.util.datum import IDatum
from milodb.client.view.gui.util.tk_index import TkIndex
from milodb.client.view.gui.wait_cursor import WaitCursor
from milodb.client.view.gui.wrapped_text import WrappedText
from milodb.common.parser.arg import ArgumentError
from milodb.common.parser.arg_token_stream import ArgTokenStream
from milodb.common.parser.arg_type import ArgType
from milodb.common.parser.candidate_text import CandidateText
from milodb.common.parser.expanding_token_stream import ExpandedToken
from milodb.common.parser.token import Token
from milodb.common.parser.token_stream import TokenStreamError
from milodb.common.util.ref import IRef
from milodb.common.variables.i_user_variables import IUserVariables

@dataclass
class _ArgTagDetails:
    tag_name: str
    colour: str

_MAP_OF_ARG_TYPE_TO_TAG_DETAILS: Mapping[ArgType, _ArgTagDetails] = {
    ArgType.ARG_FIELD: _ArgTagDetails('fld', Colour.QueryPanel.ARG_FIELD_FORE),
    ArgType.ARG_VERB: _ArgTagDetails('vrb', Colour.QueryPanel.ARG_VERB_FORE),
    ArgType.ARG_TEXT: _ArgTagDetails('text', Colour.QueryPanel.ARG_TEXT_FORE),
    ArgType.ARG_REGEX: _ArgTagDetails('rgx', Colour.QueryPanel.ARG_REGEX_FORE),
    ArgType.ARG_ENUM: _ArgTagDetails('enm', Colour.QueryPanel.ARG_ENUM_FORE),
    ArgType.ARG_INT: _ArgTagDetails('int', Colour.QueryPanel.ARG_INT_FORE),
    ArgType.ARG_FLOAT: _ArgTagDetails('flt', Colour.QueryPanel.ARG_FLOAT_FORE),
    ArgType.ARG_DATE: _ArgTagDetails('dat', Colour.QueryPanel.ARG_DATE_FORE),
    ArgType.ARG_VARIABLE : _ArgTagDetails('var', Colour.QueryPanel.ARG_VARIABLE_FORE),
    ArgType.ARG_OPERATOR : _ArgTagDetails('key', Colour.QueryPanel.ARG_OPERATOR_FORE),
}
_MAP_OF_ARG_TYPE_TO_TAG_NAME: Mapping[ArgType, str] = {
    arg_type: details.tag_name for arg_type, details in _MAP_OF_ARG_TYPE_TO_TAG_DETAILS.items()
}
_LIST_OF_ARG_TAG_NAMES: Sequence[str] = list(_MAP_OF_ARG_TYPE_TO_TAG_NAME.values())
_ERROR_TAG: str = 'err'

class RawQueryPanel(StyledFrame):
    def __init__(self, master: tk.Misc, list_of_teases: Sequence[Tease], user_variables: IUserVariables, list_of_tease_matches: IRef[Sequence[TeaseMatch]], selected_tease_index: IRef[int | None], tease_match_sorter: ITeaseMatchSorter, list_of_active_sort_keys: IRef[Sequence[OrderedSortKey]], variables_changed_event: IDatum) -> None:
        super().__init__(master, style=Style.Generic.PanelFrame.STYLE_NAME)

        self._list_of_teases: Sequence[Tease] = list_of_teases
        self._user_variables: IUserVariables = user_variables
        self._list_of_tease_matches: IRef[Sequence[TeaseMatch]] = list_of_tease_matches
        self._selected_tease_index: IRef[int | None] = selected_tease_index
        self._tease_match_sorter: ITeaseMatchSorter = tease_match_sorter
        self._list_of_active_sort_keys: IRef[Sequence[OrderedSortKey]] = list_of_active_sort_keys
        self._variables_changed_event: IDatum = variables_changed_event

        self._infix_parser: InfixQueryParser = InfixQueryParser()
        self._postfix_executor: PostfixQueryExecutor = PostfixQueryExecutor()
        self._query_input_suggester: QueryInputSuggester = QueryInputSuggester(self._user_variables, self._infix_parser)
        self._last_postfix_query: PostfixQuery | None = None

        table_frame: StyledFrame = StyledFrame(self, style=Style.Generic.TableFrame.STYLE_NAME)
        table_frame.pack(anchor=tk.NW, fill=tk.X, expand=True)

        ttk.Label(table_frame, text='Query', anchor=tk.NW, justify=tk.LEFT, style=Style.InTable.HeaderLabel.STYLE_NAME).grid(row=0, column=0, sticky=tk.NSEW, padx=(0,2), pady=(0,2))
        ttk.Label(table_frame, text='Suggestion', anchor=tk.NW, justify=tk.LEFT, style=Style.InTable.HeaderLabel.STYLE_NAME).grid(row=1, column=0, sticky=tk.NSEW, padx=(0,2), pady=(0,2))
        ttk.Label(table_frame, text='Expansion', anchor=tk.NW, justify=tk.LEFT, style=Style.InTable.HeaderLabel.STYLE_NAME).grid(row=2, column=0, sticky=tk.NSEW, padx=(0,2), pady=(0,2))
        ttk.Label(table_frame, text='Status', anchor=tk.NW, justify=tk.LEFT, style=Style.InTable.HeaderLabel.STYLE_NAME).grid(row=3, column=0, sticky=tk.NSEW, padx=(0,2), pady=(0,2))
        ttk.Label(table_frame, text='Expected', anchor=tk.NW, justify=tk.LEFT, style=Style.InTable.HeaderLabel.STYLE_NAME).grid(row=4, column=0, sticky=tk.NSEW, padx=(0,2), pady=0)

        self._query_entry: TextEx = TextEx(table_frame, style=Style.InTable.EditableText.STYLE_NAME)
        self._query_entry.tag_config(_ERROR_TAG, foreground=Colour.QueryPanel.ERROR_FORE, background=Colour.QueryPanel.ERROR_BACK, selectforeground=Colour.QueryPanel.ERROR_SELECTED_FORE, selectbackground=Colour.QueryPanel.ERROR_SELECTED_BACK, underline=True, underlinefg=Colour.QueryPanel.ERROR_UNDERLINE)
        self._query_entry.grid(row=0, column=2, sticky=tk.NSEW, pady=(0,2))
        self._query_entry.bind(TextEx.CARET_MOVED_BINDING, self._on_caret_moved)
        self._query_entry.bind(TextEx.TEXT_CHANGED_BINDING, self._on_text_changed)
        self._query_entry.bind('<Return>', self._on_return_pressed)
        self._query_entry.bind('<Tab>', self._on_tab_pressed)

        font_line_height: int = get_font_of_themed_widget(self, self._query_entry).metrics('linespace')

        self._input_valid_image: ImageTk.PhotoImage = ImageTk.PhotoImage(generated_images.render_input_valid_image(image_height=font_line_height))
        self._input_invalid_image: ImageTk.PhotoImage = ImageTk.PhotoImage(generated_images.render_input_invalid_image(image_height=font_line_height))

        self._query_icon: ttk.Label = ttk.Label(table_frame, image=self._input_invalid_image, style=Style.InTable.ValueLabel.STYLE_NAME)
        self._query_icon.grid(row=0, column=1, sticky=tk.NSEW, padx=(0,2), pady=(0,2))

        self._suggestions_label: ttk.Label = ttk.Label(table_frame, anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME)
        self._suggestions_label.grid(row=1, column=1, columnspan=2, sticky=tk.NSEW, pady=(0,2))

        self._expansion_text: WrappedText = WrappedText(table_frame, is_readonly=True, style=Style.InTable.ReadonlyText.STYLE_NAME)
        self._expansion_text.grid(row=2, column=1, columnspan=2, sticky=tk.NSEW, pady=(0,2))
        self._expansion_text.tag_config(_ERROR_TAG, foreground=Colour.QueryPanel.ERROR_FORE, background=Colour.QueryPanel.ERROR_BACK, selectforeground=Colour.QueryPanel.ERROR_SELECTED_FORE, selectbackground=Colour.QueryPanel.ERROR_SELECTED_BACK, underline=True, underlinefg=Colour.QueryPanel.ERROR_UNDERLINE)

        self._status_label: ttk.Label = ttk.Label(table_frame, anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME)
        self._status_label.grid(row=3, column=1, columnspan=2, sticky=tk.NSEW, pady=(0,2))

        self._expected_label: ttk.Label = ttk.Label(table_frame, anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME)
        self._expected_label.grid(row=4, column=1, columnspan=2, sticky=tk.NSEW)

        arg_tag_details: _ArgTagDetails
        for arg_tag_details in _MAP_OF_ARG_TYPE_TO_TAG_DETAILS.values():
            self._query_entry.tag_configure(arg_tag_details.tag_name, foreground=arg_tag_details.colour)
            self._query_entry.tag_lower(arg_tag_details.tag_name)
            self._expansion_text.tag_configure(arg_tag_details.tag_name, foreground=arg_tag_details.colour)
            self._expansion_text.tag_lower(arg_tag_details.tag_name)

        table_frame.columnconfigure(2, weight=1)

        self._variables_changed_event.add_listener(self._on_variables_changed)

        self._provide_input_suggestions('', 0)
        self._validate_input()

    @override
    def destroy(self) -> None:
        self._variables_changed_event.remove_listener(self._on_variables_changed)

    def set_focus(self) -> None:
        self._query_entry.focus()

    def _on_caret_moved(self, _: object) -> None:
        caret_index: int = self._query_entry.get_caret_index()
        user_input: str = self._query_entry.get_text()
        self._provide_input_suggestions(user_input, caret_index)

    def _on_text_changed(self, _: object) -> None:
        self._validate_input()

    def _on_return_pressed(self, _: object) -> str:
        if self._last_postfix_query:
            self._execute_query(self._last_postfix_query.query_chain)
        return 'break'

    def _on_tab_pressed(self, _: object) -> str | None:
        if self._query_input_suggester.list_of_suggestions:
            list_of_completion_text: list[str] = [
                f'{candidate.text}{candidate.following_delimiter}'[self._query_input_suggester.suggestion_starting_index:]
                for candidate in self._query_input_suggester.list_of_suggestions
            ]

            completion_text: str
            if len(list_of_completion_text) > 1:
                length_of_shortest_completion_text: int = min(len(text) for text in list_of_completion_text)
                completion_length: int = 0
                for completion_length in range(length_of_shortest_completion_text):
                    if len({text[completion_length] for text in list_of_completion_text}) != 1:
                        break
                completion_text = list_of_completion_text[0][:completion_length]
            else:
                completion_text = list_of_completion_text[0]

            self._query_entry.selection_clear()
            self._query_entry.insert(tk.INSERT, completion_text)
        return 'break'

    def _execute_query(self, postfix_query_chain: Sequence[IQuery]) -> None:
        with WaitCursor(self.winfo_toplevel()), QueryProgressDialog(self.winfo_toplevel(), len(self._list_of_teases)) as query_progress_dialog:
            try:
                result: PostfixQueryResult = self._postfix_executor.execute(self._list_of_teases, postfix_query_chain, 10_000_000, query_progress_dialog.show_progress)
            except PostfixError as ex:
                PromptDialog(
                    self.winfo_toplevel(),
                    icon = PromptDialog.Icon.ERROR,
                    title = 'Unexpected error',
                    headline_text = 'Unexpected fault in postfix query chain',
                    detail_text = ex.message,
                )
                return

        self._selected_tease_index.set(None)
        self._list_of_tease_matches.set(self._tease_match_sorter.sort(result.list_of_tease_matches, self._list_of_active_sort_keys.get()))
        if result.list_of_tease_matches:
            self._selected_tease_index.set(0)

        if result.was_max_match_count_reached:
            percentage_searched: float = 0.0
            if result.queried_tease_count != 0:
                percentage_searched = 100.0 * result.queried_tease_count / result.total_tease_count
            PromptDialog(
                self.winfo_toplevel(),
                icon = PromptDialog.Icon.WARNING,
                title = 'Limit reached',
                headline_text = f'Limit of {result.max_match_count:,} matching items was reached.',
                detail_text = (
                    f'Search stopped with {result.total_match_count:,} matching items.\n'
                    f'Searched {result.queried_tease_count:,} of {result.total_tease_count:,} teases ({percentage_searched:.1f}%).'
                ),
            )

    def _validate_input(self) -> None:
        text: str = self._query_entry.get_text()

        arg_token_stream: ArgTokenStream = ArgTokenStream(text, self._user_variables)
        arg_token_stream.set_keep_delimiters('()')

        fault_token: Token | None = None

        self._last_postfix_query = None
        try:
            self._last_postfix_query = self._infix_parser.convert_to_postfix(arg_token_stream)
        except TokenStreamError as ex:
            self._status_label.config(text=f'Token Error: {ex.cause_of_fault_text}')
            fault_token = ex.fault_token
            self._expected_label.config(text=_get_expected_text(ex.list_of_candidate_text))
        except ArgumentError as ex:
            self._status_label.config(text=f"Argument Error: {ex.message}")
            fault_token = ex.fault_token
            self._expected_label.config(text=_get_expected_text(ex.list_of_candidate_text))
        except InfixError as ex:
            self._status_label.config(text=f'Infix Error: {ex.message}')
            fault_token = ex.fault_token
            self._expected_label.config(text=_get_expected_text(ex.list_of_candidate_text))
        else:
            self._status_label.config(text='Okay')
            self._expected_label.config(text=_get_expected_text(self._last_postfix_query.list_of_candidate_text))

        self._highlight_query_text(text, arg_token_stream)
        self._highlight_query_error(text, fault_token)
        expanded_text: str = arg_token_stream.get_expanded_raw_text() + arg_token_stream.get_remaining_raw_text()
        self._update_expansion_text(expanded_text)
        self._highlight_expansion_text(expanded_text, arg_token_stream)
        self._highlight_expansion_error(expanded_text, fault_token)

        self._query_icon.config(image=self._input_valid_image if self._last_postfix_query else self._input_invalid_image)

    def _highlight_query_text(self, text: str, arg_token_stream: ArgTokenStream) -> None:
        tag_name: str | None
        for tag_name in _LIST_OF_ARG_TAG_NAMES:
            self._query_entry.tag_remove(tag_name, '1.0', tk.END)

        last_token_end_index: int = 0
        tk_index = TkIndex()
        token: ExpandedToken
        for token in arg_token_stream.list_of_popped_tokens:
            if token.variable_depth == 0:
                topmost_token: Token = token.topmost_token
                arg_type: ArgType | None = arg_token_stream.map_of_token_number_to_arg_type.get(topmost_token.token_number)
                if arg_type:
                    tag_name = _MAP_OF_ARG_TYPE_TO_TAG_NAME.get(arg_type)
                    if tag_name:
                        tk_index.move_with_text(text[last_token_end_index:topmost_token.inner_indices.start])
                        start_tk_index: TkIndex = tk_index.copy()
                        tk_index.move_with_text(text[topmost_token.inner_indices.start:topmost_token.inner_indices.end])
                        self._query_entry.tag_add(tag_name, str(start_tk_index), str(tk_index))
                        last_token_end_index = topmost_token.inner_indices.end

    def _highlight_query_error(self, text: str, fault_token: Token | None) -> None:
        if isinstance(fault_token, ExpandedToken):
            fault_token = fault_token.topmost_token
        self._query_entry.tag_remove(_ERROR_TAG, '1.0', tk.END)
        if fault_token:
            topmost_fault_token: Token = fault_token.topmost_token if isinstance(fault_token, ExpandedToken) else fault_token
            start_offset: int = topmost_fault_token.inner_indices.start
            end_offset: int = topmost_fault_token.inner_indices.end
            if end_offset <= start_offset:
                end_offset = start_offset + 1
            start_tk_index: TkIndex = TkIndex.from_text(text[:start_offset])
            end_tk_index: TkIndex = start_tk_index.copy().move_with_text(text[start_offset:end_offset])
            self._query_entry.tag_add(_ERROR_TAG, str(start_tk_index), str(end_tk_index))

    def _update_expansion_text(self, text: str) -> None:
        self._expansion_text.delete('1.0', tk.END)
        self._expansion_text.insert('1.0', text)

    def _highlight_expansion_text(self, text: str, arg_token_stream: ArgTokenStream) -> None:
        tag_name: str | None
        for tag_name in _LIST_OF_ARG_TAG_NAMES:
            self._expansion_text.tag_remove(tag_name, '1.0', tk.END)

        last_token_end_index: int = 0
        tk_index = TkIndex()
        token: ExpandedToken
        for token in arg_token_stream.list_of_popped_tokens:
            arg_type: ArgType | None = arg_token_stream.map_of_token_number_to_arg_type.get(token.token_number)
            if arg_type:
                tag_name = _MAP_OF_ARG_TYPE_TO_TAG_NAME.get(arg_type)
                if tag_name:
                    tk_index.move_with_text(text[last_token_end_index:token.inner_indices.start])
                    start_tk_index: TkIndex = tk_index.copy()
                    tk_index.move_with_text(text[token.inner_indices.start:token.inner_indices.end])
                    self._expansion_text.tag_add(tag_name, str(start_tk_index), str(tk_index))
                    last_token_end_index = token.inner_indices.end

    def _highlight_expansion_error(self, text: str, fault_token: Token | None) -> None:
        self._expansion_text.tag_remove('err', '1.0', tk.END)
        if isinstance(fault_token, ExpandedToken):
            start_offset: int = fault_token.inner_indices.start
            end_offset: int = fault_token.inner_indices.end
            if end_offset <= start_offset:
                end_offset = start_offset + 1
            start_tk_index: TkIndex = TkIndex.from_text(text[:start_offset])
            end_tk_index: TkIndex = start_tk_index.copy().move_with_text(text[start_offset:end_offset])
            self._expansion_text.tag_add('err', str(start_tk_index), str(end_tk_index))

    def _provide_input_suggestions(self, text: str, cursor_index: int) -> None:
        self._query_input_suggester.update(text, cursor_index)
        self._suggestions_label.config(text=_get_expected_text(self._query_input_suggester.list_of_suggestions))

    def _on_variables_changed(self) -> None:
        self._validate_input()

def _get_expected_text(list_of_candidate_text: Iterable[CandidateText]) -> str:
    return ', '.join([
        f'{candidate_text.text}{candidate_text.following_delimiter}' for candidate_text in sorted(list_of_candidate_text, key=lambda ct: ct.text)
    ])
