# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from abc import ABC, abstractmethod
from collections.abc import Callable
from types import TracebackType
from typing import Self
from milodb.common.output.print.i_printer import IPrinter

class IProgressDisplay(ABC):
    @abstractmethod
    def set_subtitle_text(self, text: str) -> None:
        pass

    @abstractmethod
    def set_action_text(self, text: str) -> None:
        pass

    @abstractmethod
    def set_activity_text(self, text: str) -> None:
        pass

    @abstractmethod
    def set_progress_percentage(self, percentage: int) -> None:
        pass

    @property
    @abstractmethod
    def normal_printer(self) -> IPrinter:
        pass

    @property
    @abstractmethod
    def warning_printer(self) -> IPrinter:
        pass

    @property
    @abstractmethod
    def error_printer(self) -> IPrinter:
        pass

    @abstractmethod
    def prompt_on_exit(self, *, show_log: bool=True) -> None:
        pass

    @abstractmethod
    def print_warning_and_prompt_on_exit(self, message: str) -> None:
        pass

    @abstractmethod
    def print_fatal_and_prompt_on_exit(self, message: str) -> None:
        pass

    @abstractmethod
    def __enter__(self) -> Self:
        pass

    @abstractmethod
    def __exit__(self, exc_type: type[BaseException] | None, exc_value: BaseException | None, traceback: TracebackType | None) -> None:
        pass

class PercentageSlice:
    def __init__(self, min_percentage: int, max_percentage: int, call_set_percentage: Callable[[int], None]) -> None:
        self._min_percentage: int = min_percentage
        self._max_percentage: int = max_percentage
        self._call_set_percentage: Callable[[int], None] = call_set_percentage

    def set_progress_percentage(self, percentage: int) -> None:
        self._call_set_percentage(self._min_percentage + percentage * (self._max_percentage - self._min_percentage) // 100 )
