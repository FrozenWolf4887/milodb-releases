# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from milodb.client.config.config_schema import CONFIG_SCHEMA
from milodb.common.config.framework import IConfig

class AnsiConfig:
    def __init__(self, config: IConfig) -> None:
        self._config = config

    @property
    def index_heading_colour(self) -> str:
        return CONFIG_SCHEMA.format.ansi.colour.index_heading.fetch_value_or_default(self._config)

    @property
    def hits_heading_colour(self) -> str:
        return CONFIG_SCHEMA.format.ansi.colour.hits_heading.fetch_value_or_default(self._config)

    @property
    def tease_heading_colour(self) -> str:
        return CONFIG_SCHEMA.format.ansi.colour.tease_heading.fetch_value_or_default(self._config)

    @property
    def author_heading_colour(self) -> str:
        return CONFIG_SCHEMA.format.ansi.colour.author_heading.fetch_value_or_default(self._config)

    @property
    def type_heading_colour(self) -> str:
        return CONFIG_SCHEMA.format.ansi.colour.type_heading.fetch_value_or_default(self._config)

    @property
    def date_heading_colour(self) -> str:
        return CONFIG_SCHEMA.format.ansi.colour.date_heading.fetch_value_or_default(self._config)

    @property
    def rating_heading_colour(self) -> str:
        return CONFIG_SCHEMA.format.ansi.colour.rating_heading.fetch_value_or_default(self._config)

    @property
    def tags_heading_colour(self) -> str:
        return CONFIG_SCHEMA.format.ansi.colour.tags_heading.fetch_value_or_default(self._config)

    @property
    def summary_heading_colour(self) -> str:
        return CONFIG_SCHEMA.format.ansi.colour.summary_heading.fetch_value_or_default(self._config)

    @property
    def deleted_heading_colour(self) -> str:
        return CONFIG_SCHEMA.format.ansi.colour.deleted_heading.fetch_value_or_default(self._config)

    @property
    def author_gone_heading_colour(self) -> str:
        return CONFIG_SCHEMA.format.ansi.colour.author_gone_heading.fetch_value_or_default(self._config)

    @property
    def page_heading_colour(self) -> str:
        return CONFIG_SCHEMA.format.ansi.colour.page_heading.fetch_value_or_default(self._config)

    @property
    def page_name_colour(self) -> str:
        return CONFIG_SCHEMA.format.ansi.colour.page_name.fetch_value_or_default(self._config)

    @property
    def matching_text_heading_colour(self) -> str:
        return CONFIG_SCHEMA.format.ansi.colour.matching_text_heading.fetch_value_or_default(self._config)

    @property
    def matching_text_colour(self) -> str:
        return CONFIG_SCHEMA.format.ansi.colour.matching_text.fetch_value_or_default(self._config)

    @property
    def ellipsis_colour(self) -> str:
        return CONFIG_SCHEMA.format.ansi.colour.ellipsis.fetch_value_or_default(self._config)
