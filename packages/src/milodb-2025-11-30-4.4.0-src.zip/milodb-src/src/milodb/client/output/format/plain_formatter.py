# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from collections.abc import Iterable, Mapping
from typing import override
from milodb.client.database.tease import TotmStatus
from milodb.client.database.tease_page import TeasePage
from milodb.client.output.format.i_formatter import IFormatter
from milodb.client.output.support import EllipsisLocation, ellipsify_text, get_matching_indices_for_page, iterate_through_indices
from milodb.client.query.field_match import IFieldMatch
from milodb.client.query.tease_match import TeaseMatch
from milodb.common.output.print.i_printer import IPrinter
from milodb.common.util.get_url import get_url_of_author, get_url_of_tease

_MAP_OF_TOTM_STATUS_TO_TEXT: Mapping[TotmStatus, str] = {
    TotmStatus.NONE: ' ',
    TotmStatus.NOMINEE: 'n',
    TotmStatus.WINNER: 'w',
}

_TEXT_SEPARATOR_LINE: str = 40 * '-'

class PlainFormatter(IFormatter):
    def __init__(self, printer: IPrinter, *, ellipsis_max_width: int | None, show_pagerefs: bool) -> None:
        self._printer: IPrinter = printer
        self._ellipsis_max_width: int | None = ellipsis_max_width
        self._show_pagerefs: bool = show_pagerefs

    @override
    def print_list_of_teases(self, list_of_tease_matches: Iterable[TeaseMatch]) -> None:
        tease_match: TeaseMatch
        for tease_match in list_of_tease_matches:
            self._print_oneline_of_tease(tease_match)

    @override
    def print_summary_of_tease(self, tease_match: TeaseMatch) -> None:
        match_index: str = str(tease_match.index_of_match) if tease_match.index_of_match else 'none'
        tease_id: int = tease_match.tease.tease_id
        author_id: int = tease_match.tease.author.author_id
        tease_id_text: str = f'#{tease_id}'
        tease_type: str = tease_match.tease.tease_type.value
        tease_rating: float = tease_match.tease.rating_value
        tease_tags: str = ', '.join(tease_match.tease.list_of_tags)
        tease_date: str = tease_match.tease.date.isoformat()
        tease_title: str = tease_match.tease.title
        author_name: str = f"'{tease_match.tease.author.name}'" if tease_match.tease.author.has_author else 'unknown'
        author_id_text: str = f'@{author_id}' if tease_match.tease.author.has_author else 'unknown'
        summary: str = tease_match.tease.summary
        deleted_text: str = '[DELETED] ' if tease_match.tease.is_deleted else ''
        author_gone_text: str = '[GONE] ' if tease_match.tease.author.has_gone else ''
        url_of_tease: str = get_url_of_tease(tease_id)
        url_of_author: str = get_url_of_author(author_id)
        self._printer.writeln(f"Index   {match_index:>7}   Hits   {tease_match.get_match_count()}")
        self._printer.writeln(f"Tease   {tease_id_text:>7}   Title  {deleted_text}'{tease_title}'")
        self._printer.writeln(f"Author  {author_id_text:>7}   Name   {author_gone_text}{author_name}")
        self._printer.writeln(f"Type    {tease_type:>7}   Date   {tease_date}")
        self._printer.writeln(f"Rating  {tease_rating:>7}   Tags   {tease_tags}")
        self._printer.writeln(f"Tease   {url_of_tease}")
        if tease_match.tease.author.has_author:
            self._printer.writeln(f"Author  {url_of_author}")
        self._printer.writeln("Summary")
        self._printer.writeln(summary or 'None')

    @override
    def print_text_of_page(self, tease_match: TeaseMatch, page: TeasePage) -> None:
        if self._show_pagerefs:
            self._printer.writeln(_page_separator(page))
        if self._ellipsis_max_width:
            list_of_indices: Iterable[IFieldMatch.Indices] = get_matching_indices_for_page(page, tease_match.list_of_field_matches)
            ellipsified_text_block: str = _ellipsify_text(page.text, list_of_indices, self._ellipsis_max_width)
            self._printer.writeln(ellipsified_text_block)
        else:
            self._printer.writeln(page.text)

    @override
    def print_all_text_of_list_of_teases(self, list_of_tease_matches: Iterable[TeaseMatch]) -> None:
        index: int
        tease_match: TeaseMatch
        for index, tease_match in enumerate(list_of_tease_matches):
            if index > 0:
                self._printer.writeln()
            self.print_summary_of_tease(tease_match)
            self.print_all_text_of_tease(tease_match, include_header_and_footer=True)

    @override
    def print_matching_text_of_list_of_teases(self, list_of_tease_matches: Iterable[TeaseMatch]) -> None:
        index: int
        tease_match: TeaseMatch
        for index, tease_match in enumerate(list_of_tease_matches):
            if index > 0:
                self._printer.writeln()
            self.print_summary_of_tease(tease_match)
            self.print_matching_text_of_tease(tease_match, include_header_and_footer=True)

    @override
    def print_all_text_of_tease(self, tease_match: TeaseMatch, *, include_header_and_footer: bool) -> None:
        index: int
        page: TeasePage | None = None
        for index, page in enumerate(tease_match.tease.list_of_pages):
            if not index and include_header_and_footer:
                self._printer.writeln('Text')
            self._printer.writeln(_page_separator(page if self._show_pagerefs else None))
            self._printer.writeln(page.text)
        if page and include_header_and_footer:
            self._printer.writeln(_page_separator(None))

    @override
    def print_matching_text_of_tease(self, tease_match: TeaseMatch, *, include_header_and_footer: bool) -> None:
        is_first_match: bool = True
        page: TeasePage | None = None
        for page in tease_match.tease.list_of_pages:
            list_of_indices: Iterable[IFieldMatch.Indices] = get_matching_indices_for_page(page, tease_match.list_of_field_matches)
            if list_of_indices:
                if is_first_match:
                    is_first_match = False
                    if include_header_and_footer:
                        self._printer.writeln('Matching text')
                self._printer.writeln(_page_separator(page if self._show_pagerefs else None))
                if self._ellipsis_max_width:
                    ellipsified_text_block: str = _ellipsify_text(page.text, list_of_indices, self._ellipsis_max_width)
                    self._printer.writeln(ellipsified_text_block)
                else:
                    self._printer.writeln(page.text)
        if page and include_header_and_footer:
            self._printer.writeln(_page_separator(None))

    def _print_oneline_of_tease(self, tease_match: TeaseMatch) -> None:
        match_index: str = str(tease_match.index_of_match) if tease_match.index_of_match else '-'
        hits: str = '*' + str(tease_match.get_match_count())
        tease_id: str = '#' + str(tease_match.tease.tease_id)
        tease_type: str = tease_match.tease.tease_type.value
        tease_rating: float = tease_match.tease.rating_value
        tease_date: str = tease_match.tease.date.isoformat()
        tease_title: str = tease_match.tease.title
        author_text: str = 'unknown author'
        if tease_match.tease.author.has_author:
            author_text = f"{tease_match.tease.author.name}, @{tease_match.tease.author.author_id}"
        author_gone_text: str = '[GONE] ' if tease_match.tease.author.has_gone else ''
        totm_text: str = _MAP_OF_TOTM_STATUS_TO_TEXT.get(tease_match.tease.totm_status, ' ')
        deleted_text: str = '[DELETED] ' if tease_match.tease.is_deleted else ''
        self._printer.writeln(
            f'{match_index:>3}:'
            f' {hits:>4}'
            f'  {tease_id:>6}'
            f'  {tease_type}'
            f'  {tease_rating:>3}'
            f'  {totm_text}'
            f'  {tease_date}'
            f'  {deleted_text}{tease_title}'
            f' : {author_gone_text}<{author_text}>')

def _page_separator(page: TeasePage | None) -> str:
    return f"-- Page: '{page.page_ref}' {_TEXT_SEPARATOR_LINE}"[:len(_TEXT_SEPARATOR_LINE)] if page else _TEXT_SEPARATOR_LINE

def _ellipsify_text(text: str, list_of_indices: Iterable[IFieldMatch.Indices], ellipsis_max_width: int) -> str:
    formatted_text = ''

    def on_normal_text(text: str, *, is_first_item: bool, is_last_item: bool) -> None:
        nonlocal formatted_text
        formatted_text += _ellipsify_text_item(text, is_first_item=is_first_item, is_last_item=is_last_item, ellipsis_max_width=ellipsis_max_width)

    def on_matched_text(text: str, *, is_first_item: bool, is_last_item: bool) -> None: # pylint: disable=W0613:unused-argument # noqa: ARG001 Unused function argument
        nonlocal formatted_text
        formatted_text += text

    iterate_through_indices(text, list_of_indices, on_normal_text, on_matched_text)

    return formatted_text

def _ellipsify_text_item(text: str, *, is_first_item: bool, is_last_item: bool, ellipsis_max_width: int) -> str:
    formatted_text: str = ''

    def on_text(text: str) -> None:
        nonlocal formatted_text
        formatted_text += text

    def on_ellipsis() -> None:
        nonlocal formatted_text
        formatted_text += '\u2026'

    ellipsify_text(text, ellipsis_max_width, EllipsisLocation.from_position(is_first_item=is_first_item, is_last_item=is_last_item), on_text, on_ellipsis)

    return formatted_text
