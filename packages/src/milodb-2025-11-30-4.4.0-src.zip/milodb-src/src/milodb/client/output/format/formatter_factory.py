# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass
from typing import override
from milodb.client.output.format.i_formatter import IFormatter
from milodb.client.output.format.i_formatter_factory import IFormatterCreator, IFormatterFactory
from milodb.common.output.print.i_printer import IPrinter

@dataclass
class FormatterCreator(IFormatterCreator):
    _name: str
    _constructor: Callable[[IPrinter], IFormatter]

    @override
    def get_name(self) -> str:
        return self._name

    @override
    def create(self, printer: IPrinter) -> IFormatter:
        return self._constructor(printer)

class FormatterFactory(IFormatterFactory):
    def __init__(self) -> None:
        self._map_of_name_to_formatter_creator: dict[str, IFormatterCreator] = {}

    @override
    def get_list_of_formatter_names(self) -> Sequence[str]:
        return list(self._map_of_name_to_formatter_creator)

    @property
    @override
    def map_of_name_to_formatter_creator(self) -> Mapping[str, IFormatterCreator]:
        return self._map_of_name_to_formatter_creator

    def register_formatter(self, formatter_creator: IFormatterCreator) -> None:
        self._map_of_name_to_formatter_creator[formatter_creator.get_name()] = formatter_creator
