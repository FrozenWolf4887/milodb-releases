# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import datetime
from collections.abc import Iterator, Mapping, Sequence
from dataclasses import dataclass
from milodb.client.database.database import try_get_newest_tease_date, try_get_oldest_tease_date
from milodb.client.database.tease import Tease, TotmStatus

@dataclass
class TotmStats:
    author_name: str
    wins: int
    nominations: int

class DatabaseStats:
    def __init__(self, list_of_teases: Sequence[Tease]) -> None:
        self._list_of_teases: Sequence[Tease] = list_of_teases
        self._newest_tease_date: datetime.date | None = None
        self._oldest_tease_date: datetime.date | None = None
        self._count_of_deleted_teases: int | None = None
        self._map_of_tag_to_occurrence_count: dict[str, int] | None = None
        self._map_of_author_to_tease_count: dict[str, int] | None = None
        self._count_of_missing_authors: int | None = None
        self._total_count_of_words: int | None = None
        self._map_of_author_to_word_count: dict[str, int] | None = None
        self._map_of_author_to_totm_stats: dict[str, TotmStats] | None = None
        self._count_of_totm_winners: int | None = None
        self._count_of_totm_nominees: int | None = None
        self._list_of_teases_by_descending_image_count: list[Tease] | None = None
        self._list_of_teases_by_descending_audio_count: list[Tease] | None = None

    @property
    def number_of_teases(self) -> int:
        return len(self._list_of_teases)

    @property
    def list_of_teases(self) -> Sequence[Tease]:
        return self._list_of_teases

    @property
    def newest_tease_date(self) -> datetime.date | None:
        if self._newest_tease_date is None:
            self._newest_tease_date = try_get_newest_tease_date(self._list_of_teases)
        return self._newest_tease_date

    @property
    def oldest_tease_date(self) -> datetime.date | None:
        if self._oldest_tease_date is None:
            self._oldest_tease_date = try_get_oldest_tease_date(self._list_of_teases)
        return self._oldest_tease_date

    @property
    def count_of_deleted_teases(self) -> int:
        if self._count_of_deleted_teases is None:
            self._gather_deleted_stats()
        return self._count_of_deleted_teases or 0

    @property
    def map_of_tag_to_occurrence_count(self) -> Mapping[str, int]:
        if self._map_of_tag_to_occurrence_count is None:
            self._gather_tag_stats()
        return self._map_of_tag_to_occurrence_count or {}

    @property
    def map_of_author_to_tease_count(self) -> Mapping[str, int]:
        if self._map_of_author_to_tease_count is None:
            self._gather_author_stats()
        return self._map_of_author_to_tease_count or {}

    @property
    def count_of_missing_authors(self) -> int:
        if self._count_of_missing_authors is None:
            self._gather_author_stats()
        return self._count_of_missing_authors or 0

    @property
    def total_count_of_words(self) -> int:
        if self._total_count_of_words is None:
            self._gather_content_stats()
        return self._total_count_of_words or 0

    @property
    def map_of_author_to_word_count(self) -> Mapping[str, int]:
        if self._map_of_author_to_word_count is None:
            self._gather_content_stats()
        return self._map_of_author_to_word_count or {}

    @property
    def map_of_author_to_totm_stats(self) -> Mapping[str, TotmStats]:
        if self._map_of_author_to_totm_stats is None:
            self._gather_totm_stats()
        return self._map_of_author_to_totm_stats or {}

    @property
    def count_of_totm_winners(self) -> int:
        if self._count_of_totm_winners is None:
            self._gather_totm_stats()
        return self._count_of_totm_winners or 0

    @property
    def count_of_totm_nominees(self) -> int:
        if self._count_of_totm_nominees is None:
            self._gather_totm_stats()
        return self._count_of_totm_nominees or 0

    @property
    def list_of_teases_by_decreasing_image_count(self) -> Sequence[Tease]:
        if self._list_of_teases_by_descending_image_count is None:
            self._gather_image_stats()
        return self._list_of_teases_by_descending_image_count or []

    @property
    def list_of_teases_by_decreasing_audio_count(self) -> Sequence[Tease]:
        if self._list_of_teases_by_descending_audio_count is None:
            self._gather_audio_stats()
        return self._list_of_teases_by_descending_audio_count or []

    def _gather_deleted_stats(self) -> None:
        count_of_deleted_teases: int = 0
        tease: Tease
        for tease in self._list_of_teases:
            if tease.is_deleted:
                count_of_deleted_teases += 1
        self._count_of_deleted_teases = count_of_deleted_teases

    def _gather_tag_stats(self) -> None:
        self._map_of_tag_to_occurrence_count = {}
        tease: Tease
        for tease in self._iter_non_deleted_teases():
            tag: str
            for tag in tease.list_of_tags:
                try:
                    value: int = self._map_of_tag_to_occurrence_count[tag]
                except KeyError:
                    self._map_of_tag_to_occurrence_count[tag] = 1
                else:
                    self._map_of_tag_to_occurrence_count[tag] = value + 1

    def _iter_non_deleted_teases(self) -> Iterator[Tease]:
        tease: Tease
        for tease in self._list_of_teases:
            if not tease.is_deleted:
                yield tease

    def _gather_author_stats(self) -> None:
        map_of_author_to_tease_count: dict[str, int] = {}
        count_of_missing_authors: int = 0

        tease: Tease
        for tease in self._iter_non_deleted_teases():
            if not tease.author.has_author:
                count_of_missing_authors += 1
            else:
                try:
                    value: int = map_of_author_to_tease_count[tease.author.name]
                except KeyError:
                    map_of_author_to_tease_count[tease.author.name] = 1
                else:
                    map_of_author_to_tease_count[tease.author.name] = value + 1

        self._map_of_author_to_tease_count = map_of_author_to_tease_count
        self._count_of_missing_authors = count_of_missing_authors

    def _gather_content_stats(self) -> None:
        map_of_author_to_word_count: dict[str, int] = {}
        total_count_of_words: int = 0

        tease: Tease
        for tease in self._iter_non_deleted_teases():
            tease_count_of_words: int = tease.word_count
            total_count_of_words += tease_count_of_words
            if tease.author.has_author:
                try:
                    value: int = map_of_author_to_word_count[tease.author.name]
                except KeyError:
                    map_of_author_to_word_count[tease.author.name] = tease_count_of_words
                else:
                    map_of_author_to_word_count[tease.author.name] = value + tease_count_of_words

        self._map_of_author_to_word_count = map_of_author_to_word_count
        self._total_count_of_words = total_count_of_words

    def _gather_totm_stats(self) -> None:
        map_of_author_to_totm_stats: dict[str, TotmStats] = {}
        count_of_totm_winners: int = 0
        count_of_totm_nominees: int = 0

        tease: Tease
        for tease in self._iter_non_deleted_teases():
            delta_wins: int = 0
            delta_nominations: int = 0
            if tease.totm_status == TotmStatus.WINNER:
                delta_wins = 1
            elif tease.totm_status == TotmStatus.NOMINEE:
                delta_nominations = 1

            count_of_totm_winners += delta_wins
            count_of_totm_nominees += delta_nominations

            if tease.author.has_author and (delta_wins or delta_nominations):
                try:
                    stats: TotmStats = map_of_author_to_totm_stats[tease.author.name]
                except KeyError:
                    map_of_author_to_totm_stats[tease.author.name] = TotmStats(tease.author.name, delta_wins, delta_nominations)
                else:
                    stats.wins += delta_wins
                    stats.nominations += delta_nominations

        self._map_of_author_to_totm_stats = map_of_author_to_totm_stats
        self._count_of_totm_winners = count_of_totm_winners
        self._count_of_totm_nominees = count_of_totm_nominees

    def _gather_image_stats(self) -> None:
        self._list_of_teases_by_descending_image_count = sorted(self._iter_non_deleted_teases(), key=lambda tease: (tease.count_of_unique_images, tease.count_of_images), reverse=True)

    def _gather_audio_stats(self) -> None:
        self._list_of_teases_by_descending_audio_count = sorted(self._iter_non_deleted_teases(), key=lambda tease: (tease.count_of_unique_audio, tease.count_of_audio), reverse=True)
