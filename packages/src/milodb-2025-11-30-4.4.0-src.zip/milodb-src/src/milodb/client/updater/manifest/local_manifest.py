# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import datetime
from abc import ABC, abstractmethod
from collections.abc import Mapping, Sequence
from pathlib import Path
from milodb.client.updater.manifest.common_manifest import IConfigFile, IVersionNumber

class ILocalManifest(ABC):
    @property
    @abstractmethod
    def format(self) -> int:
        pass

    @property
    @abstractmethod
    def variant_name(self) -> str:
        pass

    @property
    @abstractmethod
    def version_number(self) -> IVersionNumber:
        pass

    @property
    @abstractmethod
    def date(self) -> datetime.date:
        pass

    @property
    @abstractmethod
    def core_files(self) -> Sequence[Path]:
        pass

    @property
    @abstractmethod
    def config_files(self) -> Mapping[int, IConfigFile]:
        pass
