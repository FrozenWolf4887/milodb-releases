# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from abc import ABC, abstractmethod
from pathlib import Path

class ITempDirectory(ABC):
    @property
    @abstractmethod
    def path(self) -> Path:
        pass

    @abstractmethod
    def path_of(self, filename: Path) -> Path:
        pass

    @abstractmethod
    def store_file(self, filename: Path, data: bytes, *, is_executable: bool = False) -> None:
        """Store the file into the temporary directory.

        ### Raises
        - TempDirectoryError
            - If the file can't be stored
        """

    @abstractmethod
    def destroy(self) -> None:
        """Destroy all files in the temporary directory and the directory itself.

        ### Raises
        - TempDirectoryError
            - If the directory cannot be removed
        """

class ITempDirectoryCreator(ABC):
    @abstractmethod
    def create(self) -> ITempDirectory:
        """Create a new temporary directory.

        ### Raises
        - TempDirectoryError
            - If the directory can't be created
        """

class TempDirectoryError(Exception):
    pass
