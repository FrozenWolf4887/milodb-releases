# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
class ErrorMessage:
    EXPECTING_PLAIN_TEXT: str = 'expecting plain text'
    EXPECTING_FIXED_TEXT: str = "expecting fixed text '{}'"
    EXPECTING_REGEX: str = 'expecting regular expression'
    EXPECTING_DECIMAL: str = 'expecting integer or decimal value'
    EXPECTING_UNSIGNED_DECIMAL: str = 'expecting unsigned integer or decimal value'
    EXPECTING_DATE: str = 'expecting date'
    EXPECTING_PARTIAL_DATE: str = 'expecting date or partial date'
    EXPECTING_REFID: str = 'expecting a RefId'
    EXPECTING_SOME_REFID: str = 'expecting at least 1 RefId'
    EXPECTING_VARIABLE: str = 'expecting variable name'
    EXPECTING_FIELD_VERB: str = 'expecting field verb'
    EXPECTING_DATA_TYPE: str = 'expecting data type'

    INSUFFICIENT: str = 'Insufficient parameters'
    INSUFFICIENT_EXPECTING_PLAIN_TEXT: str = f'{INSUFFICIENT}, {EXPECTING_PLAIN_TEXT}'
    INSUFFICIENT_EXPECTING_FIXED_TEXT: str = f'{INSUFFICIENT}, {EXPECTING_FIXED_TEXT}'
    INSUFFICIENT_EXPECTING_REGEX: str = f'{INSUFFICIENT}, {EXPECTING_REGEX}'
    INSUFFICIENT_EXPECTING_DECIMAL: str = f'{INSUFFICIENT}, {EXPECTING_DECIMAL}'
    INSUFFICIENT_EXPECTING_UNSIGNED_DECIMAL: str = f'{INSUFFICIENT}, {EXPECTING_UNSIGNED_DECIMAL}'
    INSUFFICIENT_EXPECTING_DATE: str = f'{INSUFFICIENT}, {EXPECTING_DATE}'
    INSUFFICIENT_EXPECTING_PARTIAL_DATE: str = f'{INSUFFICIENT}, {EXPECTING_PARTIAL_DATE}'
    INSUFFICIENT_EXPECTING_REFID: str = f'{INSUFFICIENT}, {EXPECTING_REFID}'
    INSUFFICIENT_EXPECTING_SOME_REFID: str = f'{INSUFFICIENT}, {EXPECTING_SOME_REFID}'
    INSUFFICIENT_EXPECTING_VARIABLE: str = f'{INSUFFICIENT}, {EXPECTING_VARIABLE}'
    INSUFFICIENT_EXPECTING_FIELD_VERB: str = f'{INSUFFICIENT}, {EXPECTING_FIELD_VERB}'
    INSUFFICIENT_EXPECTING_DATA_TYPE: str = f'{INSUFFICIENT}, {EXPECTING_DATA_TYPE}'

    INVALID_VALUE: str = 'Invalid value'
    INVALID_SUBCOMMAND: str = 'Invalid subcommand'
    INVALID_FORMATTER: str = 'Invalid formatter'
    INVALID_DATA_TYPE: str = 'Invalid data type'
    INVALID_EXPECTING_FIXED_TEXT: str = f'{INVALID_VALUE}, {EXPECTING_FIXED_TEXT}'
    INVALID_EXPECTING_DATE: str = "Invalid date, expected format 'yyyy-mm-dd'"
    INVALID_EXPECTING_PARTIAL_DATE: str = "Invalid date or partial date, expected format 'yyyy' or 'yyyy-mm' or 'yyyy-mm-dd'"
    INVALID_EXPECTING_REFID: str = "Invalid RefId, expecting 'value', '#value', or '@value'"
    INVALID_EXPECTING_TEASEID: str = f'{INVALID_VALUE}, expecting TeaseId as a positive integer'
    INVALID_EXPECTING_AUTHORID: str = f'{INVALID_VALUE}, expecting AuthorId as a positive integer'
    INVALID_EXPECTING_UNSIGNED_DECIMAL: str = f'{INVALID_VALUE}, {EXPECTING_UNSIGNED_DECIMAL}'
    INVALID_EXPECTING_ENUM: str = 'Unknown keyword or value'
    INVALID_EXPECTING_COMMAND: str = 'Unrecognised command name'
    INVALID_EXPECTING_VARIABLE_NAME: str = r"Invalid variable name, expecting pattern '[\w\-\+]+'"

    UNEXPECTED: str = 'Unexpected additional parameter'
