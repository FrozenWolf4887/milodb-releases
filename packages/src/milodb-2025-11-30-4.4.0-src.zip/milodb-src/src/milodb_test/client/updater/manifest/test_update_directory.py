# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import unittest
from typing import TYPE_CHECKING
from milodb.client.updater.manifest.i_schema_types import SchemaLoadError
from milodb.client.updater.manifest.update_directory_schema import UpdateDirectorySchema
from milodb_test.client.test import json_tools
from milodb_test.client.test.fake_data import FAKE_HEXDIGEST_A, FAKE_HEXDIGEST_B, FAKE_HEXDIGEST_C
if TYPE_CHECKING:
    from collections.abc import Mapping, MutableMapping

FAKE_DIRECTORY_HOST: str = 'https://example.com'
FAKE_DIRECTORY_PATH: str = 'apple/mango'
FAKE_DIRECTORY_FILE: str = 'directory.json'
FAKE_DIRECTORY_URL: str = f'{FAKE_DIRECTORY_HOST}/{FAKE_DIRECTORY_PATH}/{FAKE_DIRECTORY_FILE}'

SAMPLE_UPDATE_DIRECTORY: str = (
    r'{'
    r'    "format": 2,'
    r'    "versionManifestUri": "https://example.com/version-manifect.json",'
    r'    "assetRegister": {'
    r'        "templateAssetUri": "file:///directory/test/<>",'
    r'        "assets": {'
    rf'           "{FAKE_HEXDIGEST_A}":{{'
    r'                "uri": "file:///directory/test/abcd",'
    r'                "size": 642354'
    r'            },'
    rf'           "{FAKE_HEXDIGEST_B}":{{'
    r'                "id": "pear",'
    r'                "size": 45208'
    r'            },'
    rf'           "{FAKE_HEXDIGEST_C}":{{'
    r'                "size": 2345'
    r'            }'
    r'        }'
    r'    }'
    r'}')

class TestUpdateDirectory(unittest.TestCase):
    def test_throws_when_root_is_invalid(self) -> None:
        with self.assertRaises(SchemaLoadError) as capture:
            UpdateDirectorySchema().load('hello')
        self.assertEqual("Schema of update directory has invalid root type of 'str'", str(capture.exception))

    def test_throws_when_format_is_missing(self) -> None:
        json_root: Mapping[object, object] = json_tools.load_and_prune_json_key(SAMPLE_UPDATE_DIRECTORY, 'format')
        with self.assertRaises(SchemaLoadError) as capture:
            UpdateDirectorySchema().load(json_root)
        self.assertEqual("Format field of update directory is missing", str(capture.exception))

    def test_throws_when_format_is_unexpected_value(self) -> None:
        json_root: Mapping[object, object] = json_tools.load_and_change_json_value(SAMPLE_UPDATE_DIRECTORY, 'format', 24)
        with self.assertRaises(SchemaLoadError) as capture:
            UpdateDirectorySchema().load(json_root)
        self.assertEqual("Unsupported update directory format of '24'; expected to be '2'", str(capture.exception))

    def test_throws_when_format_is_unexpected_type(self) -> None:
        json_root: Mapping[object, object] = json_tools.load_and_change_json_value(SAMPLE_UPDATE_DIRECTORY, 'format', '1')
        with self.assertRaises(SchemaLoadError) as capture:
            UpdateDirectorySchema().load(json_root)
        self.assertEqual("Format field of update directory is of type 'str'; expected to be 'int'", str(capture.exception))

    def test_throws_when_entries_missing(self) -> None:
        list_of_paths_to_remove: tuple[str, ...] = (
            'versionManifestUri',
            'assetRegister',
            'assetRegister/assets',
            f'assetRegister/assets/{FAKE_HEXDIGEST_A}/size',
        )
        path_to_remove: str
        for path_to_remove in list_of_paths_to_remove:
            with self.subTest(missing_entry=path_to_remove):
                json_root: Mapping[object, object] = json_tools.load_and_prune_json_key(SAMPLE_UPDATE_DIRECTORY, path_to_remove)
                with self.assertRaises(SchemaLoadError) as capture:
                    UpdateDirectorySchema().load(json_root)
                self.assertEqual(f"Key '{path_to_remove}' is missing", str(capture.exception))

    def test_throws_when_entries_are_of_incorrect_basic_type(self) -> None:
        list_of_paths_to_change: tuple[tuple[str, object, str], ...] = (
            ('versionManifestUri', 1234, 'text'),
            ('assetRegister', 1234, 'a group'),
            ('assetRegister/templateAssetUri', 1234, 'text'),
            ('assetRegister/assets', [], 'a group'),
            (f'assetRegister/assets/{FAKE_HEXDIGEST_A}', 'something', 'a group'),
            (f'assetRegister/assets/{FAKE_HEXDIGEST_A}/uri', 1234, 'text'),
            (f'assetRegister/assets/{FAKE_HEXDIGEST_B}/id', 1234, 'text'),
            (f'assetRegister/assets/{FAKE_HEXDIGEST_C}/size', 'something', 'an integer'),
        )
        path_to_change: str
        new_value: object
        error_message_suffix: str
        for path_to_change, new_value, error_message_suffix in list_of_paths_to_change:
            with self.subTest(changed_entry=path_to_change, new_value=new_value):
                json_root: Mapping[object, object] = json_tools.load_and_change_json_value(SAMPLE_UPDATE_DIRECTORY, path_to_change, new_value)
                with self.assertRaises(SchemaLoadError) as capture:
                    UpdateDirectorySchema().load(json_root)
                self.assertEqual(f"Key '{path_to_change}' value is not {error_message_suffix}", str(capture.exception))

    def test_access_to_properties(self) -> None:
        json_root: Mapping[object, object] = json_tools.load_json(SAMPLE_UPDATE_DIRECTORY)
        update_directory = UpdateDirectorySchema()
        update_directory.load(json_root)

        self.assertEqual(2, update_directory.format)
        self.assertEqual('https://example.com/version-manifect.json', update_directory.version_manifest_url)
        self.assertEqual('file:///directory/test/<>', update_directory.asset_register.template_asset_url)
        self.assertEqual('file:///directory/test/abcd', update_directory.asset_register.assets[FAKE_HEXDIGEST_A].url)
        self.assertEqual('pear', update_directory.asset_register.assets[FAKE_HEXDIGEST_B].identifier)
        self.assertEqual(2345, update_directory.asset_register.assets[FAKE_HEXDIGEST_C].size)

    def test_throws_when_no_template_asset_url_and_asset_url_is_empty(self) -> None:
        json_root: MutableMapping[object, object] = json_tools.load_json(SAMPLE_UPDATE_DIRECTORY)
        json_tools.prune_json_key(json_root, 'assetRegister/templateAssetUri')
        with self.assertRaises(SchemaLoadError) as capture:
            UpdateDirectorySchema().load(json_root)
        self.assertEqual(f"Asset '{FAKE_HEXDIGEST_B}' must specify a URL when there is no template URL", str(capture.exception))

    def test_throws_when_template_asset_url_does_not_include_placeholder(self) -> None:
        json_root: MutableMapping[object, object] = json_tools.load_json(SAMPLE_UPDATE_DIRECTORY)
        json_tools.change_json_value(json_root, 'assetRegister/templateAssetUri', 'file:///directory/test/<')
        with self.assertRaises(SchemaLoadError) as capture:
            UpdateDirectorySchema().load(json_root)
        self.assertEqual("'assetRegister/templateAssetUri' value 'file:///directory/test/<' does not include the '<>' placeholder", str(capture.exception))

    def test_throws_when_asset_includes_both_id_and_url(self) -> None:
        json_root: MutableMapping[object, object] = json_tools.load_json(SAMPLE_UPDATE_DIRECTORY)
        json_tools.add_json_key(json_root, f'assetRegister/assets/{FAKE_HEXDIGEST_B}/uri', 'abcd')
        with self.assertRaises(SchemaLoadError) as capture:
            UpdateDirectorySchema().load(json_root)
        self.assertEqual(f"Asset '{FAKE_HEXDIGEST_B}' cannot specify both 'id' and 'uri' fields", str(capture.exception))

    def test_resolve_returns_none_if_digest_not_found(self) -> None:
        json_root: MutableMapping[object, object] = json_tools.load_json(SAMPLE_UPDATE_DIRECTORY)
        json_tools.prune_json_key(json_root, f'assetRegister/assets/{FAKE_HEXDIGEST_B}')

        update_directory = UpdateDirectorySchema()
        update_directory.load(json_root)

        url: str | None = update_directory.asset_register.resolve_asset_url(FAKE_DIRECTORY_URL, FAKE_HEXDIGEST_B)

        self.assertIsNone(url)

    def test_resolve_returns_absolute_asset_url_if_specified_ignoring_specified_template(self) -> None:
        json_root: MutableMapping[object, object] = json_tools.load_json(SAMPLE_UPDATE_DIRECTORY)
        json_tools.change_json_value(json_root, 'assetRegister/templateAssetUri', 'file:///directory/test/<>')
        json_tools.change_json_value(json_root, f'assetRegister/assets/{FAKE_HEXDIGEST_A}/uri', 'file:///something')

        update_directory = UpdateDirectorySchema()
        update_directory.load(json_root)

        url: str | None = update_directory.asset_register.resolve_asset_url(FAKE_DIRECTORY_URL, FAKE_HEXDIGEST_A)

        self.assertEqual('file:///something', url)

    def test_resolve_returns_host_relative_asset_url_if_specified_ignoring_specified_template(self) -> None:
        json_root: MutableMapping[object, object] = json_tools.load_json(SAMPLE_UPDATE_DIRECTORY)
        json_tools.change_json_value(json_root, 'assetRegister/templateAssetUri', 'file:///directory/test/<>')
        json_tools.change_json_value(json_root, f'assetRegister/assets/{FAKE_HEXDIGEST_A}/uri', '/orange/pear')

        update_directory = UpdateDirectorySchema()
        update_directory.load(json_root)

        url: str | None = update_directory.asset_register.resolve_asset_url(FAKE_DIRECTORY_URL, FAKE_HEXDIGEST_A)

        self.assertEqual(f'{FAKE_DIRECTORY_HOST}/orange/pear', url)

    def test_resolve_returns_file_relative_asset_url_if_specified_ignoring_specified_template(self) -> None:
        json_root: MutableMapping[object, object] = json_tools.load_json(SAMPLE_UPDATE_DIRECTORY)
        json_tools.change_json_value(json_root, 'assetRegister/templateAssetUri', 'file:///directory/test/<>')
        json_tools.change_json_value(json_root, f'assetRegister/assets/{FAKE_HEXDIGEST_A}/uri', 'orange/pear')

        update_directory = UpdateDirectorySchema()
        update_directory.load(json_root)

        url: str | None = update_directory.asset_register.resolve_asset_url(FAKE_DIRECTORY_URL, FAKE_HEXDIGEST_A)

        self.assertEqual(f'{FAKE_DIRECTORY_HOST}/{FAKE_DIRECTORY_PATH}/orange/pear', url)

    def test_resolve_returns_absolute_asset_url_if_specified_ignoring_no_template(self) -> None:
        json_root: MutableMapping[object, object] = json_tools.load_json(SAMPLE_UPDATE_DIRECTORY)
        json_tools.prune_json_key(json_root, 'assetRegister/templateAssetUri')
        json_tools.change_json_value(json_root, f'assetRegister/assets/{FAKE_HEXDIGEST_A}/uri', 'file:///something')
        json_tools.prune_json_key(json_root, f'assetRegister/assets/{FAKE_HEXDIGEST_B}')
        json_tools.prune_json_key(json_root, f'assetRegister/assets/{FAKE_HEXDIGEST_C}')

        update_directory = UpdateDirectorySchema()
        update_directory.load(json_root)

        url: str | None = update_directory.asset_register.resolve_asset_url(FAKE_DIRECTORY_URL, FAKE_HEXDIGEST_A)

        self.assertEqual('file:///something', url)

    def test_resolve_returns_host_relative_asset_url_if_specified_ignoring_no_template(self) -> None:
        json_root: MutableMapping[object, object] = json_tools.load_json(SAMPLE_UPDATE_DIRECTORY)
        json_tools.prune_json_key(json_root, 'assetRegister/templateAssetUri')
        json_tools.change_json_value(json_root, f'assetRegister/assets/{FAKE_HEXDIGEST_A}/uri', '/orange/pear')
        json_tools.prune_json_key(json_root, f'assetRegister/assets/{FAKE_HEXDIGEST_B}')
        json_tools.prune_json_key(json_root, f'assetRegister/assets/{FAKE_HEXDIGEST_C}')

        update_directory = UpdateDirectorySchema()
        update_directory.load(json_root)

        url: str | None = update_directory.asset_register.resolve_asset_url(FAKE_DIRECTORY_URL, FAKE_HEXDIGEST_A)

        self.assertEqual(f'{FAKE_DIRECTORY_HOST}/orange/pear', url)

    def test_resolve_returns_file_relative_asset_url_if_specified_ignoring_no_template(self) -> None:
        json_root: MutableMapping[object, object] = json_tools.load_json(SAMPLE_UPDATE_DIRECTORY)
        json_tools.prune_json_key(json_root, 'assetRegister/templateAssetUri')
        json_tools.change_json_value(json_root, f'assetRegister/assets/{FAKE_HEXDIGEST_A}/uri', 'orange/pear')
        json_tools.prune_json_key(json_root, f'assetRegister/assets/{FAKE_HEXDIGEST_B}')
        json_tools.prune_json_key(json_root, f'assetRegister/assets/{FAKE_HEXDIGEST_C}')

        update_directory = UpdateDirectorySchema()
        update_directory.load(json_root)

        url: str | None = update_directory.asset_register.resolve_asset_url(FAKE_DIRECTORY_URL, FAKE_HEXDIGEST_A)

        self.assertEqual(f'{FAKE_DIRECTORY_HOST}/{FAKE_DIRECTORY_PATH}/orange/pear', url)

    def test_resolve_returns_identifier_substituted_into_absolute_template_if_no_asset_url(self) -> None:
        json_root: MutableMapping[object, object] = json_tools.load_json(SAMPLE_UPDATE_DIRECTORY)
        json_tools.change_json_value(json_root, 'assetRegister/templateAssetUri', 'file:///directory/test/<>')
        json_tools.change_json_value(json_root, f'assetRegister/assets/{FAKE_HEXDIGEST_B}/id', '1234abcd')

        update_directory = UpdateDirectorySchema()
        update_directory.load(json_root)

        url: str | None = update_directory.asset_register.resolve_asset_url(FAKE_DIRECTORY_URL, FAKE_HEXDIGEST_B)

        self.assertEqual('file:///directory/test/1234abcd', url)

    def test_resolve_returns_identifier_substituted_into_host_relative_template_if_no_asset_url(self) -> None:
        json_root: MutableMapping[object, object] = json_tools.load_json(SAMPLE_UPDATE_DIRECTORY)
        json_tools.change_json_value(json_root, 'assetRegister/templateAssetUri', '/directory/test/<>')
        json_tools.change_json_value(json_root, f'assetRegister/assets/{FAKE_HEXDIGEST_B}/id', '1234abcd')

        update_directory = UpdateDirectorySchema()
        update_directory.load(json_root)

        url: str | None = update_directory.asset_register.resolve_asset_url(FAKE_DIRECTORY_URL, FAKE_HEXDIGEST_B)

        self.assertEqual(f'{FAKE_DIRECTORY_HOST}/directory/test/1234abcd', url)

    def test_resolve_returns_identifier_substituted_into_file_relative_template_if_no_asset_url(self) -> None:
        json_root: MutableMapping[object, object] = json_tools.load_json(SAMPLE_UPDATE_DIRECTORY)
        json_tools.change_json_value(json_root, 'assetRegister/templateAssetUri', 'directory/test/<>')
        json_tools.change_json_value(json_root, f'assetRegister/assets/{FAKE_HEXDIGEST_B}/id', '1234abcd')

        update_directory = UpdateDirectorySchema()
        update_directory.load(json_root)

        url: str | None = update_directory.asset_register.resolve_asset_url(FAKE_DIRECTORY_URL, FAKE_HEXDIGEST_B)

        self.assertEqual(f'{FAKE_DIRECTORY_HOST}/{FAKE_DIRECTORY_PATH}/directory/test/1234abcd', url)

    def test_resolve_returns_digest_substituted_into_absolute_template_if_no_asset_url_and_no_identifer(self) -> None:
        json_root: MutableMapping[object, object] = json_tools.load_json(SAMPLE_UPDATE_DIRECTORY)
        json_tools.change_json_value(json_root, 'assetRegister/templateAssetUri', 'file:///directory/test/<>')

        update_directory = UpdateDirectorySchema()
        update_directory.load(json_root)

        url: str | None = update_directory.asset_register.resolve_asset_url(FAKE_DIRECTORY_URL, FAKE_HEXDIGEST_C)

        self.assertEqual(f'file:///directory/test/{FAKE_HEXDIGEST_C}', url)

    def test_resolve_returns_digest_substituted_into_host_relative_template_if_no_asset_url_and_no_identifer(self) -> None:
        json_root: MutableMapping[object, object] = json_tools.load_json(SAMPLE_UPDATE_DIRECTORY)
        json_tools.change_json_value(json_root, 'assetRegister/templateAssetUri', '/directory/test/<>')

        update_directory = UpdateDirectorySchema()
        update_directory.load(json_root)

        url: str | None = update_directory.asset_register.resolve_asset_url(FAKE_DIRECTORY_URL, FAKE_HEXDIGEST_C)

        self.assertEqual(f'{FAKE_DIRECTORY_HOST}/directory/test/{FAKE_HEXDIGEST_C}', url)

    def test_resolve_returns_digest_substituted_into_file_relative_template_if_no_asset_url_and_no_identifer(self) -> None:
        json_root: MutableMapping[object, object] = json_tools.load_json(SAMPLE_UPDATE_DIRECTORY)
        json_tools.change_json_value(json_root, 'assetRegister/templateAssetUri', 'directory/test/<>')

        update_directory = UpdateDirectorySchema()
        update_directory.load(json_root)

        url: str | None = update_directory.asset_register.resolve_asset_url(FAKE_DIRECTORY_URL, FAKE_HEXDIGEST_C)

        self.assertEqual(f'{FAKE_DIRECTORY_HOST}/{FAKE_DIRECTORY_PATH}/directory/test/{FAKE_HEXDIGEST_C}', url)
