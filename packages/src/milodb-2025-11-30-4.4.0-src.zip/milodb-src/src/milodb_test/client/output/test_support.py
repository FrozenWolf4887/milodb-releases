# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from __future__ import annotations
import unittest
from dataclasses import dataclass
from enum import Enum
from typing import TYPE_CHECKING, override
from milodb.client.output.support import iterate_through_indices, iterate_through_lines
from milodb.client.query.field_match import IFieldMatch
if TYPE_CHECKING:
    from collections.abc import Iterable

TEXT: str = ("Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
             " Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.")
TEXT_LEN: int = len(TEXT)

MULTILINE_TEXT: str = TEXT.replace(', ', '\n')
INDEX_OF_FIRST_EOL: int = MULTILINE_TEXT.find('\n')
INDEX_OF_FIRST_EOL_END: int = INDEX_OF_FIRST_EOL + 1
INDEX_OF_SECOND_EOL: int = MULTILINE_TEXT.find('\n', INDEX_OF_FIRST_EOL_END)
INDEX_OF_SECOND_EOL_END: int = INDEX_OF_SECOND_EOL + 1
INDEX_OF_THIRD_EOL: int = MULTILINE_TEXT.find('\n', INDEX_OF_SECOND_EOL_END)
INDEX_OF_THIRD_EOL_END: int = INDEX_OF_THIRD_EOL + 1

MULTI_EOL_TEXT: str = 'Hello\n\n\n\nWorld'
INDEX_OF_MULTI_EOL: int = MULTI_EOL_TEXT.find('\n')
INDEX_OF_MULTI_EOL_END: int = MULTI_EOL_TEXT.rfind('\n') + 1

@dataclass
class NormalText:
    text: str
    is_first_item: bool
    is_last_item: bool

@dataclass
class MatchedText:
    text: str
    is_first_item: bool
    is_last_item: bool

class TextType(Enum):
    NORMAL_TEXT = NormalText
    MATCHED_TEXT = MatchedText

    def toggle(self) -> TextType:
        if self.value == NormalText:
            return TextType.MATCHED_TEXT
        return TextType.NORMAL_TEXT

class TestSupportIterateThroughMatches(unittest.TestCase):
    @override
    def setUp(self) -> None:
        self.list_of_captured_text: list[NormalText | MatchedText] = []

    def on_normal_text(self, text: str, *, is_first_item: bool, is_last_item: bool) -> None:
        self.list_of_captured_text.append(NormalText(text, is_first_item, is_last_item))

    def on_matched_text(self, text: str, *, is_first_item: bool, is_last_item: bool) -> None:
        self.list_of_captured_text.append(MatchedText(text, is_first_item, is_last_item))

    def execute(self, text: str, list_of_indices: Iterable[IFieldMatch.Indices], starts_with_type: TextType, *list_of_expected_text: str) -> None:
        iterate_through_indices(text, list_of_indices, self.on_normal_text, self.on_matched_text)

        message_on_failure: str = f'\nExpected: {list_of_expected_text}\nReceived: {[match.text for match in self.list_of_captured_text]}\nDetails: {self.list_of_captured_text}'

        self.assertEqual(len(list_of_expected_text), len(self.list_of_captured_text),
                         f'Expected {len(list_of_expected_text)} text items, got {len(self.list_of_captured_text)}{message_on_failure}')
        text_type: TextType = starts_with_type
        index: int
        captured_text: NormalText | MatchedText
        for index, captured_text in enumerate(self.list_of_captured_text):
            self.assertEqual(index == 0, captured_text.is_first_item,
                             f'is_first_item should be {index==0} at index {index}{message_on_failure}')
            self.assertEqual(index == len(list_of_expected_text) - 1, captured_text.is_last_item,
                             f'is_last_item should be {index == len(list_of_expected_text) - 1} at index {index}{message_on_failure}')
            self.assertIsInstance(captured_text, text_type.value,
                                  f'text "{captured_text.text}" should of be of type {text_type.value.__name__} at index {index}{message_on_failure}')
            self.assertEqual(list_of_expected_text[index], captured_text.text,
                             f'text mismatch at index {index}{message_on_failure}')
            text_type = text_type.toggle()

    def test_empty_matches(self) -> None:
        self.execute(
            TEXT,
            [],
            TextType.NORMAL_TEXT,
            TEXT)

    def test_single_match_at_start(self) -> None:
        self.execute(
            TEXT,
            [IFieldMatch.Indices(0, 5)],
            TextType.MATCHED_TEXT,
            TEXT[:5],
            TEXT[5:])

    def test_single_match_of_one_character_at_start(self) -> None:
        self.execute(
            TEXT,
            [IFieldMatch.Indices(0, 1)],
            TextType.MATCHED_TEXT,
            TEXT[:1],
            TEXT[1:])

    def test_single_match_at_end(self) -> None:
        self.execute(
            TEXT,
            [IFieldMatch.Indices(TEXT_LEN - 5, TEXT_LEN)],
            TextType.NORMAL_TEXT,
            TEXT[:-5],
            TEXT[-5:])

    def test_single_match_of_one_character_at_end(self) -> None:
        self.execute(
            TEXT,
            [IFieldMatch.Indices(TEXT_LEN - 1, TEXT_LEN)],
            TextType.NORMAL_TEXT,
            TEXT[:-1],
            TEXT[-1:])

    def test_single_match_in_middle(self) -> None:
        self.execute(
            TEXT,
            [IFieldMatch.Indices(40, 45)],
            TextType.NORMAL_TEXT,
            TEXT[:40],
            TEXT[40:45],
            TEXT[45:])

    def test_single_match_of_one_character_in_middle(self) -> None:
        self.execute(
            TEXT,
            [IFieldMatch.Indices(40, 41)],
            TextType.NORMAL_TEXT,
            TEXT[:40],
            TEXT[40:41],
            TEXT[41:])

    def test_two_matches_in_order_at_start_and_end(self) -> None:
        self.execute(
            TEXT,
            [IFieldMatch.Indices(0, 10), IFieldMatch.Indices(TEXT_LEN - 10, TEXT_LEN)],
            TextType.MATCHED_TEXT,
            TEXT[:10],
            TEXT[10:-10],
            TEXT[-10:])

    def test_two_matches_in_order_in_middle(self) -> None:
        self.execute(
            TEXT,
            [IFieldMatch.Indices(20, 25), IFieldMatch.Indices(TEXT_LEN - 20, TEXT_LEN - 15)],
            TextType.NORMAL_TEXT,
            TEXT[:20],
            TEXT[20:25],
            TEXT[25:-20],
            TEXT[-20:-15],
            TEXT[-15:])

    def test_two_matches_out_of_order_at_start_and_end(self) -> None:
        self.execute(
            TEXT,
            [IFieldMatch.Indices(TEXT_LEN - 10, TEXT_LEN), IFieldMatch.Indices(0, 10)],
            TextType.MATCHED_TEXT,
            TEXT[:10],
            TEXT[10:-10],
            TEXT[-10:])

    def test_two_matches_out_of_order_in_middle(self) -> None:
        self.execute(
            TEXT,
            [IFieldMatch.Indices(TEXT_LEN - 20, TEXT_LEN - 15), IFieldMatch.Indices(20, 25)],
            TextType.NORMAL_TEXT,
            TEXT[:20],
            TEXT[20:25],
            TEXT[25:-20],
            TEXT[-20:-15],
            TEXT[-15:])

    def test_two_consecutive_matches_in_order(self) -> None:
        self.execute(
            TEXT,
            [IFieldMatch.Indices(20, 25), IFieldMatch.Indices(25, 35)],
            TextType.NORMAL_TEXT,
            TEXT[:20],
            TEXT[20:35],
            TEXT[35:])

    def test_two_consecutive_matches_out_of_order(self) -> None:
        self.execute(
            TEXT,
            [IFieldMatch.Indices(25, 35), IFieldMatch.Indices(20, 25)],
            TextType.NORMAL_TEXT,
            TEXT[:20],
            TEXT[20:35],
            TEXT[35:])

    def test_two_overlapping_matches_in_order(self) -> None:
        self.execute(
            TEXT,
            [IFieldMatch.Indices(20, 25), IFieldMatch.Indices(23, 33)],
            TextType.NORMAL_TEXT,
            TEXT[:20],
            TEXT[20:33],
            TEXT[33:])

    def test_two_overlapping_matches_out_of_order(self) -> None:
        self.execute(
            TEXT,
            [IFieldMatch.Indices(23, 33), IFieldMatch.Indices(20, 25)],
            TextType.NORMAL_TEXT,
            TEXT[:20],
            TEXT[20:33],
            TEXT[33:])

    def test_two_completely_overlapping_matches_in_order(self) -> None:
        self.execute(
            TEXT,
            [IFieldMatch.Indices(20, 40), IFieldMatch.Indices(25, 35)],
            TextType.NORMAL_TEXT,
            TEXT[:20],
            TEXT[20:40],
            TEXT[40:])

    def test_two_completely_overlapping_matches_out_of_order(self) -> None:
        self.execute(
            TEXT,
            [IFieldMatch.Indices(25, 35), IFieldMatch.Indices(20, 40)],
            TextType.NORMAL_TEXT,
            TEXT[:20],
            TEXT[20:40],
            TEXT[40:])

    def test_single_match_extending_after_end(self) -> None:
        self.execute(
            TEXT,
            [IFieldMatch.Indices(TEXT_LEN - 10, TEXT_LEN + 5)],
            TextType.NORMAL_TEXT,
            TEXT[:-10],
            TEXT[-10:])

    def test_three_matches_where_one_match_completely_overlaps_the_others(self) -> None:
        self.execute(
            TEXT,
            [IFieldMatch.Indices(20, 25), IFieldMatch.Indices(15, 40), IFieldMatch.Indices(30, 35)],
            TextType.NORMAL_TEXT,
            TEXT[:15],
            TEXT[15:40],
            TEXT[40:])

    def test_single_whole_match_matches_all_text(self) -> None:
        self.execute(
            TEXT,
            [IFieldMatch.Indices.whole_match()],
            TextType.MATCHED_TEXT,
            TEXT)

    def test_single_whole_match_embedded_within_matches_matches_all_text(self) -> None:
        self.execute(
            TEXT,
            [IFieldMatch.Indices(20, 25), IFieldMatch.Indices.whole_match(), IFieldMatch.Indices(30, 35)],
            TextType.MATCHED_TEXT,
            TEXT)

    def test_single_match_spanning_eol_includes_eol(self) -> None:
        self.execute(
            MULTILINE_TEXT,
            [IFieldMatch.Indices(INDEX_OF_FIRST_EOL - 5, INDEX_OF_FIRST_EOL + 5)],
            TextType.NORMAL_TEXT,
            MULTILINE_TEXT[:INDEX_OF_FIRST_EOL - 5],
            MULTILINE_TEXT[INDEX_OF_FIRST_EOL - 5:INDEX_OF_FIRST_EOL + 5],
            MULTILINE_TEXT[INDEX_OF_FIRST_EOL + 5:])

@dataclass
class NonEndOfLineText:
    text: str

@dataclass
class EndOfLineText:
    text: str

class EndOfLineType(Enum):
    NOT_END_OF_LINE_TEXT = NonEndOfLineText
    END_OF_LINE_TEXT = EndOfLineText

    def toggle(self) -> EndOfLineType:
        if self.value == NonEndOfLineText:
            return EndOfLineType.END_OF_LINE_TEXT
        return EndOfLineType.NOT_END_OF_LINE_TEXT

class TestSupportIterateThroughLines(unittest.TestCase):
    @override
    def setUp(self) -> None:
        self.list_of_captured_text: list[NonEndOfLineText | EndOfLineText] = []

    def on_text(self, text: str) -> None:
        self.list_of_captured_text.append(NonEndOfLineText(text))

    def on_end_of_line_text(self, text: str) -> None:
        self.list_of_captured_text.append(EndOfLineText(text))

    def execute(self, text: str, starts_with_type: EndOfLineType, *list_of_expected_text: str) -> None:
        iterate_through_lines(text, self.on_text, self.on_end_of_line_text)

        message_on_failure: str = f'\nExpected: {list_of_expected_text}\nReceived: {[capture.text for capture in self.list_of_captured_text]}'

        self.assertEqual(len(list_of_expected_text), len(self.list_of_captured_text),
                         f'Expected {len(list_of_expected_text)} text items, got {len(self.list_of_captured_text)}{message_on_failure}')
        text_type: EndOfLineType = starts_with_type
        index: int
        captured_text: NonEndOfLineText | EndOfLineText
        for index, captured_text in enumerate(self.list_of_captured_text):
            self.assertIsInstance(captured_text, text_type.value,
                                  f'text "{captured_text.text}" should of be of type {text_type.value.__name__} at index {index}{message_on_failure}')
            self.assertEqual(list_of_expected_text[index], captured_text.text,
                             f'text mismatch at index {index}{message_on_failure}')
            text_type = text_type.toggle()

    def test_middle_end_of_lines_are_returned(self) -> None:
        self.execute(
            MULTILINE_TEXT,
            EndOfLineType.NOT_END_OF_LINE_TEXT,
            MULTILINE_TEXT[:INDEX_OF_FIRST_EOL],
            MULTILINE_TEXT[INDEX_OF_FIRST_EOL:INDEX_OF_FIRST_EOL_END],
            MULTILINE_TEXT[INDEX_OF_FIRST_EOL_END:INDEX_OF_SECOND_EOL],
            MULTILINE_TEXT[INDEX_OF_SECOND_EOL:INDEX_OF_SECOND_EOL_END],
            MULTILINE_TEXT[INDEX_OF_SECOND_EOL_END:INDEX_OF_THIRD_EOL],
            MULTILINE_TEXT[INDEX_OF_THIRD_EOL:INDEX_OF_THIRD_EOL_END],
            MULTILINE_TEXT[INDEX_OF_THIRD_EOL_END:])

    def test_starting_end_of_line_is_returned(self) -> None:
        self.execute(
            MULTILINE_TEXT[INDEX_OF_FIRST_EOL:],
            EndOfLineType.END_OF_LINE_TEXT,
            MULTILINE_TEXT[INDEX_OF_FIRST_EOL:INDEX_OF_FIRST_EOL_END],
            MULTILINE_TEXT[INDEX_OF_FIRST_EOL_END:INDEX_OF_SECOND_EOL],
            MULTILINE_TEXT[INDEX_OF_SECOND_EOL:INDEX_OF_SECOND_EOL_END],
            MULTILINE_TEXT[INDEX_OF_SECOND_EOL_END:INDEX_OF_THIRD_EOL],
            MULTILINE_TEXT[INDEX_OF_THIRD_EOL:INDEX_OF_THIRD_EOL_END],
            MULTILINE_TEXT[INDEX_OF_THIRD_EOL_END:])

    def test_ending_end_of_line_is_returned(self) -> None:
        self.execute(
            MULTILINE_TEXT[:INDEX_OF_THIRD_EOL_END],
            EndOfLineType.NOT_END_OF_LINE_TEXT,
            MULTILINE_TEXT[:INDEX_OF_FIRST_EOL],
            MULTILINE_TEXT[INDEX_OF_FIRST_EOL:INDEX_OF_FIRST_EOL_END],
            MULTILINE_TEXT[INDEX_OF_FIRST_EOL_END:INDEX_OF_SECOND_EOL],
            MULTILINE_TEXT[INDEX_OF_SECOND_EOL:INDEX_OF_SECOND_EOL_END],
            MULTILINE_TEXT[INDEX_OF_SECOND_EOL_END:INDEX_OF_THIRD_EOL],
            MULTILINE_TEXT[INDEX_OF_THIRD_EOL:INDEX_OF_THIRD_EOL_END])

    def test_no_end_of_lines_returns_plain_text(self) -> None:
        self.execute(
            MULTILINE_TEXT[:INDEX_OF_FIRST_EOL],
            EndOfLineType.NOT_END_OF_LINE_TEXT,
            MULTILINE_TEXT[:INDEX_OF_FIRST_EOL])

    def test_only_end_of_line_returns_end_of_line(self) -> None:
        self.execute(
            MULTILINE_TEXT[INDEX_OF_FIRST_EOL:INDEX_OF_FIRST_EOL_END],
            EndOfLineType.END_OF_LINE_TEXT,
            MULTILINE_TEXT[INDEX_OF_FIRST_EOL:INDEX_OF_FIRST_EOL_END])

    def test_multiple_end_of_lines_returns_lump_of_end_of_lines(self) -> None:
        self.execute(
            MULTI_EOL_TEXT,
            EndOfLineType.NOT_END_OF_LINE_TEXT,
            MULTI_EOL_TEXT[:INDEX_OF_MULTI_EOL],
            MULTI_EOL_TEXT[INDEX_OF_MULTI_EOL:INDEX_OF_MULTI_EOL_END],
            MULTI_EOL_TEXT[INDEX_OF_MULTI_EOL_END:])
