# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import unittest
from typing import TypeGuard
from milodb.client.view.gui.util.tk_index import TkIndex

class TestTkIndex_MoveWithText(unittest.TestCase):
    def test_after_construction_returns_first_character(self) -> None:
        self.assertEqual('1.0', str(TkIndex()))

    def test_empty_string_move_returns_second_character(self) -> None:
        tk_index = TkIndex()
        tk_index.move_with_text('')
        self.assertEqual('1.0', str(tk_index))

    def test_one_character_move_returns_second_character(self) -> None:
        tk_index = TkIndex()
        tk_index.move_with_text('a')
        self.assertEqual('1.1', str(tk_index))

    def test_two_character_move_returns_third_character(self) -> None:
        tk_index = TkIndex()
        tk_index.move_with_text('ab')
        self.assertEqual('1.2', str(tk_index))

    def test_double_one_character_move_returns_second_character(self) -> None:
        tk_index = TkIndex()
        tk_index.move_with_text('a')
        tk_index.move_with_text('b')
        self.assertEqual('1.2', str(tk_index))

    def test_simple_line_move_returns_first_character_on_second_line(self) -> None:
        tk_index = TkIndex()
        tk_index.move_with_text('\n')
        self.assertEqual('2.0', str(tk_index))

    def test_worded_line_move_returns_first_character_on_second_line(self) -> None:
        tk_index = TkIndex()
        tk_index.move_with_text('ab\n')
        self.assertEqual('2.0', str(tk_index))

    def test_double_line_move_returns_first_character_on_third_line(self) -> None:
        tk_index = TkIndex()
        tk_index.move_with_text('\n\n')
        self.assertEqual('3.0', str(tk_index))

    def test_double_worded_line_move_returns_first_character_on_third_line(self) -> None:
        tk_index = TkIndex()
        tk_index.move_with_text('ab\ncd\n')
        self.assertEqual('3.0', str(tk_index))

    def test_line_and_text_move_returns_third_character_on_second_line(self) -> None:
        tk_index = TkIndex()
        tk_index.move_with_text('\ncdef')
        self.assertEqual('2.4', str(tk_index))

    def test_unicode_text_is_counted_as_one_code_point(self) -> None:
        tk_index = TkIndex()
        tk_index.move_with_text('欢')
        self.assertEqual('1.1', str(tk_index))

    def test_emoji_text_is_counted_as_two_code_points(self) -> None:
        tk_index = TkIndex()
        tk_index.move_with_text('🦂')
        self.assertEqual('1.2', str(tk_index))

    def test_embedded_emoji_text_is_counted_as_two_code_points(self) -> None:
        tk_index = TkIndex()
        tk_index.move_with_text('a🦂b')
        self.assertEqual('1.4', str(tk_index))

class TestTkIndex_Copy(unittest.TestCase):
    def test_returns_new_object(self) -> None:
        tk_index = TkIndex(row=12, column=34)
        new_tk_index = tk_index.copy()
        self.assertIsNot(tk_index, new_tk_index)

    def test_returns_new_object_with_same_values(self) -> None:
        tk_index = TkIndex(row=12, column=34)
        new_tk_index = tk_index.copy()
        self.assertEqual(12, new_tk_index.row)
        self.assertEqual(34, new_tk_index.column)

class TestTkIndex_TryParseStrIndex(unittest.TestCase):
    def test_returns_start_index(self) -> None:
        tk_index = TkIndex.try_parse_str_index('1.0')
        if self._assert_is_not_none(tk_index):
            self.assertEqual(1, tk_index.row)
            self.assertEqual(0, tk_index.column)

    def test_returns_moved_column(self) -> None:
        tk_index = TkIndex.try_parse_str_index('1.23')
        if self._assert_is_not_none(tk_index):
            self.assertEqual(1, tk_index.row)
            self.assertEqual(23, tk_index.column)

    def test_returns_moved_row(self) -> None:
        tk_index = TkIndex.try_parse_str_index('71.4')
        if self._assert_is_not_none(tk_index):
            self.assertEqual(71, tk_index.row)
            self.assertEqual(4, tk_index.column)

    def test_returns_moved_row_and_column(self) -> None:
        tk_index = TkIndex.try_parse_str_index('123.456')
        if self._assert_is_not_none(tk_index):
            self.assertEqual(123, tk_index.row)
            self.assertEqual(456, tk_index.column)

    def test_returns_none_on_missing_dot(self) -> None:
        self.assertIsNone(TkIndex.try_parse_str_index('123456'))

    def test_returns_none_on_excess_dots(self) -> None:
        self.assertIsNone(TkIndex.try_parse_str_index('1.0.'))
        self.assertIsNone(TkIndex.try_parse_str_index('.1.0'))
        self.assertIsNone(TkIndex.try_parse_str_index('1..0'))

    def test_returns_none_if_row_less_than_one(self) -> None:
        self.assertIsNone(TkIndex.try_parse_str_index('0.0'))
        self.assertIsNone(TkIndex.try_parse_str_index('-1.5'))

    def test_returns_none_if_column_less_than_zero(self) -> None:
        self.assertIsNone(TkIndex.try_parse_str_index('1.-1'))
        self.assertIsNone(TkIndex.try_parse_str_index('2.-2'))

    def _assert_is_not_none[T](self, obj: T | None) -> TypeGuard[T]:
        self.assertIsNotNone(obj)
        return obj is not None

class TestTkIndex_ToStringIndex(unittest.TestCase):
    def test_start_index_and_no_text_returns_zero(self) -> None:
        tk_index = TkIndex()
        self.assertEqual(0, tk_index.to_string_index(''))

    def test_column_more_than_zero_and_no_text_returns_zero(self) -> None:
        self.assertEqual(0, TkIndex(row=1, column=1).to_string_index(''))

    def test_start_index_and_some_text_returns_zero(self) -> None:
        self.assertEqual(0, TkIndex().to_string_index('frog'))

    def test_column_one_and_some_text_returns_one(self) -> None:
        self.assertEqual(1, TkIndex(row=1, column=1).to_string_index('frog'))

    def test_column_at_middle_of_text_returns_middle_index(self) -> None:
        self.assertEqual(2, TkIndex(row=1, column=2).to_string_index('frog'))

    def test_column_at_end_of_text_returns_end_index(self) -> None:
        self.assertEqual(4, TkIndex(row=1, column=4).to_string_index('frog'))

    def test_column_beyond_end_of_text_returns_end_index(self) -> None:
        self.assertEqual(4, TkIndex(row=1, column=5).to_string_index('frog'))

    def test_column_before_emoji_text_returns_index(self) -> None:
        self.assertEqual(0, TkIndex(row=1, column=0).to_string_index('fr🦂og'))
        self.assertEqual(1, TkIndex(row=1, column=1).to_string_index('fr🦂og'))
        self.assertEqual(2, TkIndex(row=1, column=2).to_string_index('fr🦂og'))

    def test_column_after_emoji_text_returns_codepoint_adjusted_index(self) -> None:
        self.assertEqual(3, TkIndex(row=1, column=4).to_string_index('fr🦂og'))
        self.assertEqual(4, TkIndex(row=1, column=5).to_string_index('fr🦂og'))
        self.assertEqual(5, TkIndex(row=1, column=6).to_string_index('fr🦂og'))

    def test_column_within_emoji_text_returns_codepoint_adjusted_index(self) -> None:
        self.assertEqual(3, TkIndex(row=1, column=3).to_string_index('fr🦂og'))

    def test_second_row_returns_index(self) -> None:
        self.assertEqual(3, TkIndex(row=2, column=0).to_string_index('fr\nog'))

    def test_second_row_beyond_text_returns_index_at_end(self) -> None:
        self.assertEqual(1, TkIndex(row=2, column=0).to_string_index('a'))

    def test_second_row_with_column_beyond_text_returns_index_at_end(self) -> None:
        self.assertEqual(5, TkIndex(row=2, column=5).to_string_index('abc\nz'))

    def test_second_row_with_column_beyond_text_returns_index_at_end_of_second_row(self) -> None:
        self.assertEqual(7, TkIndex(row=2, column=5).to_string_index('abc\nzip\nfrog'))

    def test_third_row_returns_index(self) -> None:
        self.assertEqual(6, TkIndex(row=3, column=0).to_string_index('fr\nog\n'))
