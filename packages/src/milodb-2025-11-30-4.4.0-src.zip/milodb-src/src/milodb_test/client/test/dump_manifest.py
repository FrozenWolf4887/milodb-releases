# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from typing import TYPE_CHECKING
from milodb.client.updater.manifest.local_manifest import ILocalManifest
from milodb.client.updater.manifest.version_manifest import ICoreFile, IVariant, IVersion, IVersionManifest
if TYPE_CHECKING:
    from pathlib import Path
    from milodb.client.updater.manifest.common_manifest import IConfigFile, ILaunchFile, IVersionNumber

def dump_version_manifest(manifest: IVersionManifest) -> None:
    print(f'Format     : {manifest.format}')
    variant_name: str
    variant: IVariant
    for variant_name, variant in manifest.variants.items():
        print(f'Variant    : {variant_name}')
        version_number: IVersionNumber
        version: IVersion
        for version_number, version in variant.versions.items():
            print(f'  Version    : {version_number}')
            print(f'    Date       : {version.date}')
            print(f'    Log        : {version.log}')
            operating_system: str
            launch_file: ILaunchFile
            for operating_system, launch_file in version.launch_files.items():
                print(f'    Launch     : {operating_system} -> {launch_file.filename}')
            core_filename: Path
            core_file: ICoreFile
            for core_filename, core_file in version.core_files.items():
                print(f'    Core File    : {core_filename}')
                print(f'      Digest       : {core_file.digest}')
                print(f'      Exe          : {core_file.exe}')
            config_key: int
            config_file: IConfigFile
            for config_key, config_file in version.config_files.items():
                print(f'    Config Key   : {config_key}')
                print(f'      Filename     : {config_file.filename}')

def dump_local_manifest(manifest: ILocalManifest) -> None:
    print(f'Format     : {manifest.format}')
    print(f'Variant    : {manifest.variant_name}')
    print(f'Version    : {manifest.version_number}')
    print(f'Date       : {manifest.date}')
    core_filename: Path
    for core_filename in manifest.core_files:
        print(f'Core File  : {core_filename}')
    config_key: int
    config_file: IConfigFile
    for config_key, config_file in manifest.config_files.items():
        print(f'Config Key : {config_key}')
        print(f'  Filename   : {config_file.filename}')
