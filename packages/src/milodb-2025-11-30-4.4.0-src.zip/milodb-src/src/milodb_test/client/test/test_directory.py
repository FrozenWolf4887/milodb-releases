# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from __future__ import annotations
import os
import stat
import sys
import tempfile
from pathlib import Path
from typing import NoReturn, Self, TYPE_CHECKING
if TYPE_CHECKING:
    import unittest
    from collections.abc import Iterable, Sequence
    from types import TracebackType

class TestDirectory:
    def __init__(self, test_case: unittest.TestCase, debug_name: str | None = None) -> None:
        self._test_case: unittest.TestCase = test_case
        self._debug_name: str | None = debug_name
        self._path: Path | None = None

    def __enter__(self) -> Self:
        self._path = Path(tempfile.mkdtemp())
        return self

    def __exit__(self, exc_type: type[BaseException] | None, exc_value: BaseException | None, traceback: TracebackType | None) -> None:
        if not self._path:
            return
        if exc_value is not None:
            print(f"WARNING: Exception detected in '{self._test_case.id()}'")
            print(f"Showing contents of directory '{self._path}'{f' ({self._debug_name})' if self._debug_name else ''}:")
            _display_directory_contents(self._path)
        _delete_directory_recursively(self._path)
        self._path = None

    @property
    def path(self) -> Path:
        if self._has_path() and self._path:
            return self._path
        return Path()

    def path_of(self, filename: str | Path) -> Path:
        if self._has_path() and self._path:
            return self._path / filename
        return Path()

    def assert_file_exists(self, filename: str | Path | FakeFile, expected_data_or_size: bytes | int | None = None, *, is_executable: bool = False, is_readonly: bool = False) -> None:
        """On Windows, the executable mode is not checked as all files are considered executable."""
        if self._has_path() and self._path:
            filepath: Path
            if isinstance(filename, FakeFile):
                filepath = self._path.joinpath(filename.filename)
            else:
                filepath = self._path.joinpath(filename)

            if expected_data_or_size is None or isinstance(expected_data_or_size, int):
                self._test_case.assertTrue(filepath.exists(), f"File '{filepath}' does not exist")
                self._test_case.assertTrue(filepath.is_file(), f"File '{filepath}' is not a file")
                if isinstance(expected_data_or_size, int):
                    self._test_case.assertEqual(filepath.stat().st_size, expected_data_or_size, f"Path '{filepath}' file size should be {expected_data_or_size} bytes")
            else:
                try:
                    actual_data: bytes = filepath.read_bytes()
                except FileNotFoundError:
                    self._test_case.fail(f"File '{filepath}' does not exist")
                except OSError as ex:
                    self._test_case.fail(f"File '{filepath}' cannot be read: {ex}")
                else:
                    self._test_case.assertEqual(expected_data_or_size, actual_data)

            if sys.platform != 'win32':
                self._test_case.assertEqual(os.access(filepath, os.X_OK), is_executable, f"Path '{filepath}' should {'not ' if not is_executable else ''}be executable")
                self._test_case.assertEqual(os.access(filepath, os.W_OK), not is_readonly, f"Path '{filepath}' should {'not ' if not is_readonly else ''}be read-only")

    def assert_file_missing(self, filename: str | Path) -> None:
        if self._has_path() and self._path:
            filepath: Path = self._path / filename
            self._test_case.assertFalse(filepath.exists(), f"File '{filepath}' exists when it shouldn't")

    def assert_empty(self) -> None:
        self.assert_contains([], [])

    def assert_contains(self, expected_list_of_files: Iterable[str | Path | FakeFile], expected_list_of_dirpaths: Iterable[str | Path]) -> None:
        if self._has_path() and self._path:
            root_path: Path = self._path

            def fail(ex: OSError) -> NoReturn:
                self._test_case.fail(f"Error walking directory: {ex}")

            actual_list_of_filepaths: list[str] = []
            actual_list_of_dirpaths: list[str] = []

            dirpath: str
            list_of_dirnames: Sequence[str]
            list_of_filenames: Sequence[str]
            for dirpath, list_of_dirnames, list_of_filenames in os.walk(root_path, onerror=fail):
                actual_list_of_dirpaths.extend( [ str(Path(dirpath, dirname)) for dirname in list_of_dirnames ] )
                actual_list_of_filepaths.extend( [ str(Path(dirpath, filename)) for filename in list_of_filenames ] )

            self._test_case.assertCountEqual([ str(root_path.joinpath(file)) if isinstance(file, str | Path) else str(root_path.joinpath(file.filename)) for file in expected_list_of_files ], actual_list_of_filepaths)
            self._test_case.assertCountEqual([ str(root_path.joinpath(dirpath)) for dirpath in expected_list_of_dirpaths ], actual_list_of_dirpaths)

    def _has_path(self) -> bool:
        if self._path:
            return True
        self._test_case.fail('TEST ERROR: TestDirectory has not been created or has been destroyed')
        return Path()

def _display_directory_contents(starting_path: Path) -> None:
    def warning(ex: OSError) -> None:
        print(f'WARNING: {ex}')

    dirpath: str
    list_of_directories: Sequence[str]
    list_of_filenames: Sequence[str]
    for dirpath, list_of_directories, list_of_filenames in os.walk(starting_path, onerror=warning):
        path: Path
        for filename in list_of_filenames:
            path = Path(dirpath, filename)
            stats: os.stat_result = path.stat()
            print(f"  {stats.st_size:10,} bytes  {'EXE' if os.access(path, os.X_OK) else '   '} '{path}'")
        for directory_name in list_of_directories:
            path = Path(dirpath, directory_name)
            print(f"  {'<DIR>':10}            '{path}'")

def _delete_directory_recursively(starting_path: Path) -> None:
    def fail(ex: OSError) -> NoReturn:
        raise ex

    dirpath: str
    list_of_directory_names: Sequence[str]
    list_of_filenames: Sequence[str]
    for dirpath, list_of_directory_names, list_of_filenames in os.walk(starting_path, topdown=False, onerror=fail):
        for filename in list_of_filenames:
            Path(dirpath, filename).chmod(stat.S_IWUSR | stat.S_IWGRP | stat.S_IWOTH)
            Path(dirpath, filename).unlink()
        for directory_name in list_of_directory_names:
            Path(dirpath, directory_name).rmdir()
    starting_path.rmdir()

class FakeFile:
    def __init__(self, directory: Path | TestDirectory, filename_or_path: str | Path, size_or_data: int | bytes, *, is_executable: bool = False, is_readonly: bool = False) -> None:
        self._filepath: Path
        if isinstance(directory, TestDirectory):
            self._filepath = directory.path / filename_or_path
        else:
            self._filepath = directory /filename_or_path
        self._filename: Path = Path(filename_or_path)
        self._size: int
        self._data: bytes
        self._is_executable = is_executable

        self._filepath.parent.mkdir(parents=True, exist_ok=True)

        if isinstance(size_or_data, int):
            self._size = size_or_data
            buffer: bytearray = bytearray(self._size)
            index: int
            for index in range(len(buffer)): # pylint: disable=consider-using-enumerate
                buffer[index] = index % 256
            self._data = bytes(buffer)
            with self._filepath.open('wb') as file:
                file.write(buffer)
        else:
            self._size = len(size_or_data)
            self._data = size_or_data
            with self._filepath.open('wb') as file:
                file.write(size_or_data)

        if is_executable or is_readonly:
            stat_result: os.stat_result = self._filepath.stat()
            new_mode: int = stat_result.st_mode
            if is_executable:
                new_mode = new_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH
            if is_readonly:
                new_mode = new_mode & ~(stat.S_IWUSR | stat.S_IWGRP | stat.S_IWOTH)
            self._filepath.chmod(new_mode)

    @property
    def filename(self) -> Path:
        return self._filename

    @property
    def filepath(self) -> Path:
        return self._filepath

    @property
    def size(self) -> int:
        return self._size

    @property
    def data(self) -> bytes:
        return self._data

    @property
    def parent(self) -> Path:
        return self._filepath.parent

    @property
    def is_executable(self) -> bool:
        return self._is_executable

class FakeTempFile:
    def __init__(self, dirpath: Path | TestDirectory, filename: str, size_or_data: int | bytes, *, is_executable: bool = False) -> None:
        self._filepath: Path
        if isinstance(dirpath, TestDirectory):
            self._filepath = dirpath.path / f'mdbu-{filename}'
        else:
            self._filepath = dirpath / f'mdbu-{filename}'
        self._filename: str = filename
        self._size: int
        self._data: bytes
        self._is_executable = is_executable

        self._filepath.parent.mkdir(parents=True, exist_ok=True)

        if isinstance(size_or_data, int):
            self._size = size_or_data
            buffer: bytearray = bytearray(self._size)
            index: int
            for index in range(len(buffer)): # pylint: disable=consider-using-enumerate
                buffer[index] = index % 256
            self._data = bytes(buffer)
            with self._filepath.open('wb') as file:
                file.write(buffer)
        else:
            self._size = len(size_or_data)
            self._data = size_or_data
            with self._filepath.open('wb') as file:
                file.write(size_or_data)

        if is_executable:
            stat_result: os.stat_result = self._filepath.stat()
            self._filepath.chmod(stat_result.st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)

    @property
    def filename(self) -> str:
        return self._filename

    @property
    def filepath(self) -> Path:
        return self._filepath

    @property
    def size(self) -> int:
        return self._size

    @property
    def data(self) -> bytes:
        return self._data

    @property
    def is_executable(self) -> bool:
        return self._is_executable
