#!/usr/bin/env python3
# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import sys
import tkinter as tk
from collections.abc import Sequence
from typing import TYPE_CHECKING
from milodb.client.startup.dataset import DataSet, load_dataset
from milodb.client.startup.startup import StartupResult, startup
from milodb.client.view.gui.dialogs.progress_dialog import ProgressDialog
from milodb.client.view.gui.main_window import MainWindow
from milodb.client.view.gui.theme import configure_ttk_styles
from milodb.client.view.gui.util.tk_thread import run_tk_thread_routine
if TYPE_CHECKING:
    from milodb.client.startup.command_line import CommandLine
    from milodb.client.startup.shutdown_action import IShutdownAction

class _Main:
    def __init__(self, list_of_args: Sequence[str]) -> None:
        self._list_of_args: Sequence[str] = list_of_args

        self._exit_code: int = 0
        self._dataset: DataSet | None = None
        self._quit_after_startup: bool = False

        self._root: tk.Tk = tk.Tk()
        self._root.wm_withdraw()
        configure_ttk_styles(self._root)
        self._root.after_idle(self._main_tk)
        self._root.mainloop()

    @property
    def exit_code(self) -> int:
        return self._exit_code

    def _main_tk(self) -> None:
        with ProgressDialog() as progress_dialog:
            run_tk_thread_routine(lambda: self._startup(progress_dialog), progress_dialog, 'GUI startup')
            if progress_dialog.any_warnings_or_errors:
                progress_dialog.prompt_on_exit()

        if self._dataset and not self._quit_after_startup:
            main_window: MainWindow = MainWindow(self._dataset)
            main_window.wait_window()
            shutdown_action: IShutdownAction | None = main_window.shutdown_action
            if shutdown_action:
                with ProgressDialog() as progress_dialog:
                    self._exit_code = run_tk_thread_routine(lambda: shutdown_action.perform_action(progress_dialog), progress_dialog, 'GUI shutdown')

        self._root.quit()

    def _startup(self, progress_dialog: ProgressDialog) -> None:
        startup_result: StartupResult
        command_line: CommandLine | None
        startup_result, command_line = startup(self._list_of_args, progress_dialog)
        if startup_result.shutdown_action:
            self._exit_code = startup_result.shutdown_action.perform_action(progress_dialog)
        else:
            self._exit_code = startup_result.exit_code

        if startup_result.run_main_application:
            self._dataset = load_dataset(progress_dialog, no_load=command_line.no_load if command_line else False)

        if command_line:
            if command_line.startup_pause:
                progress_dialog.prompt_on_exit()
            if command_line.startup_quit:
                self._quit_after_startup = True

if __name__ == "__main__":
    sys.exit(_Main(sys.argv[1:]).exit_code)
