# MiloDB Experimental GUI, Change Log

## 4.0.0-alpha.1, 2025-03-09

* Added: Initial release of GUI for evaluation edition