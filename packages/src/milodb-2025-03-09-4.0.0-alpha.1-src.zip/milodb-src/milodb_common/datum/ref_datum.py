# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from __future__ import annotations
import contextlib
from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from collections.abc import Callable

class RefDatum[T]:
    def __init__(self, default: T) -> None:
        self._ref: T = default
        self._set_of_listeners: set[Callable[[RefDatum[T]], None]] = set()

    def set(self, ref: T) -> None:
        if self._ref != ref:
            self._ref = ref
            listener: Callable[[RefDatum[T]], None]
            for listener in self._set_of_listeners:
                listener(self)

    def get(self) -> T:
        return self._ref

    def add_listener(self, listener: Callable[[RefDatum[T]], None], *, call_immediately: bool=False) -> None:
        self._set_of_listeners.add(listener)
        if call_immediately:
            listener(self)

    def remove_listener(self, listener: Callable[[RefDatum[T]], None]) -> None:
        with contextlib.suppress(KeyError):
            self._set_of_listeners.remove(listener)

    def __bool__(self) -> bool:
        return bool(self._ref)
