# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
import tkinter as tk
from collections.abc import Iterable, Sequence
from pathlib import Path
from tkinter import messagebox
from PIL import Image, ImageTk
from milodb_client.database.tease import Tease
from milodb_client.query.infix_query_parser import InfixError, InfixQueryParser, PostfixQuery
from milodb_client.query.postfix_query_executor import PostfixError, PostfixQueryExecutor, PostfixQueryResult
from milodb_client.query.query import IQuery
from milodb_client.query.tease_match import TeaseMatch
from milodb_client.resources import resource_path
from milodb_client.util.sort_keys import OrderedSortKey
from milodb_client.util.tease_match_sorter import ITeaseMatchSorter
from milodb_client.view.gui import general_colours, general_layout
from milodb_client.view.gui.text_ex import TextEx
from milodb_common.datum.ref_datum import RefDatum
from milodb_common.parser.arg import ArgumentError
from milodb_common.parser.candidate_text import CandidateText
from milodb_common.parser.expanding_token_stream import ExpandedToken, ExpandingTokenStream
from milodb_common.parser.token_stream import TokenStreamError
from milodb_common.variables.i_user_variables import IUserVariables

# spell-checker: ignore borderwidth columnspan padx pady insertbackground selectbackground selectforeground

_COL_PANEL_BACK: str = general_colours.PANEL_BACK
_COL_HEADER_FORE: str = general_colours.HEADER_FORE
_COL_HEADER_BACK: str = general_colours.HEADER_BACK
_COL_QUERY_BACK: str = general_colours.VALUE_BACK
_COL_QUERY_FORE: str = general_colours.VALUE_FORE
_COL_SELECT_BACK: str = general_colours.VALUE_SELECTED_BACK
_COL_SELECT_FORE: str = general_colours.VALUE_SELECTED_FORE

_LAYOUT_RELIEF: general_layout.Relief = general_layout.PANEL_RELIEF
_LAYOUT_BORDER_WIDTH: int = general_layout.PANEL_BORDER_WIDTH
_LAYOUT_PADDING_X: int = general_layout.PANEL_PADDING_X
_LAYOUT_PADDING_Y: int = general_layout.PANEL_PADDING_Y

_HEADER_PAD_X: int = 2

class RawQueryPanel(tk.Frame):
    def __init__(self, master: tk.Misc, list_of_teases: Sequence[Tease], user_variables: IUserVariables, list_of_tease_matches: RefDatum[Sequence[TeaseMatch]], selected_tease_index: RefDatum[int | None], tease_match_sorter: ITeaseMatchSorter, list_of_active_sort_keys: RefDatum[Sequence[OrderedSortKey]]) -> None:
        super().__init__(master, background=_COL_PANEL_BACK, relief=_LAYOUT_RELIEF, padx=_LAYOUT_PADDING_X, pady=_LAYOUT_PADDING_Y, borderwidth=_LAYOUT_BORDER_WIDTH)

        self._list_of_teases: Sequence[Tease] = list_of_teases
        self._user_variables: IUserVariables = user_variables
        self._list_of_tease_matches: RefDatum[Sequence[TeaseMatch]] = list_of_tease_matches
        self._selected_tease_index: RefDatum[int | None] = selected_tease_index
        self._tease_match_sorter: ITeaseMatchSorter = tease_match_sorter
        self._list_of_active_sort_keys: RefDatum[Sequence[OrderedSortKey]] = list_of_active_sort_keys

        self._infix_parser: InfixQueryParser = InfixQueryParser()
        self._postfix_executor: PostfixQueryExecutor = PostfixQueryExecutor()
        self._last_postfix_query: PostfixQuery | None = None
        self._list_of_suggestions: list[CandidateText] = []
        self._suggestion_starting_index: int = 0

        with Image.open(resource_path(Path('milodb-field-active.png'))) as icon:
            self._input_correct_image: ImageTk.PhotoImage = ImageTk.PhotoImage(icon)
        with Image.open(resource_path(Path('milodb-field-error.png'))) as icon:
            self._input_error_image: ImageTk.PhotoImage = ImageTk.PhotoImage(icon)

        tk.Label(self, text='Query', anchor=tk.W, justify=tk.LEFT, foreground=_COL_HEADER_FORE, background=_COL_HEADER_BACK, padx=_HEADER_PAD_X).grid(row=0, column=0, sticky=tk.NSEW)
        tk.Label(self, text='Suggestion', anchor=tk.W, justify=tk.LEFT, foreground=_COL_HEADER_FORE, background=_COL_HEADER_BACK, padx=_HEADER_PAD_X).grid(row=1, column=0, sticky=tk.NSEW)
        tk.Label(self, text='Expansion', anchor=tk.W, justify=tk.LEFT, foreground=_COL_HEADER_FORE, background=_COL_HEADER_BACK, padx=_HEADER_PAD_X).grid(row=2, column=0, sticky=tk.NSEW)
        tk.Label(self, text='Status', anchor=tk.W, justify=tk.LEFT, foreground=_COL_HEADER_FORE, background=_COL_HEADER_BACK, padx=_HEADER_PAD_X).grid(row=3, column=0, sticky=tk.NSEW)
        tk.Label(self, text='Expected', anchor=tk.W, justify=tk.LEFT, foreground=_COL_HEADER_FORE, background=_COL_HEADER_BACK, padx=_HEADER_PAD_X).grid(row=4, column=0, sticky=tk.NSEW)

        self._query_icon: tk.Label = tk.Label(self, image=self._input_error_image)
        self._query_icon.grid(row=0, column=1)
        self._query_entry: TextEx = TextEx(self, foreground=_COL_QUERY_FORE, background=_COL_QUERY_BACK, insertbackground=_COL_QUERY_FORE, selectbackground=_COL_SELECT_BACK, selectforeground=_COL_SELECT_FORE)
        self._query_entry.grid(row=0, column=2, sticky=tk.EW)
        self._query_entry.bind(TextEx.CARET_MOVED_BINDING, self._on_caret_moved)
        self._query_entry.bind(TextEx.TEXT_CHANGED_BINDING, self._on_text_changed)
        self._query_entry.bind('<Return>', self._on_return_pressed)
        self._query_entry.bind('<Tab>', self._on_tab_pressed)

        self._suggestions_label: tk.Label = tk.Label(self, anchor=tk.W, justify=tk.LEFT, foreground=_COL_HEADER_FORE, background=_COL_PANEL_BACK)
        self._suggestions_label.grid(row=1, column=1, columnspan=2, sticky=tk.EW)

        self._expansion_label: tk.Label = tk.Label(self, anchor=tk.W, justify=tk.LEFT, foreground=_COL_HEADER_FORE, background=_COL_PANEL_BACK)
        self._expansion_label.grid(row=2, column=1, columnspan=2, sticky=tk.EW)

        self._status_label: tk.Label = tk.Label(self, anchor=tk.W, justify=tk.LEFT, foreground=_COL_HEADER_FORE, background=_COL_PANEL_BACK)
        self._status_label.grid(row=3, column=1, columnspan=2, sticky=tk.EW)

        self._expected_label: tk.Label = tk.Label(self, anchor=tk.W, justify=tk.LEFT, foreground=_COL_HEADER_FORE, background=_COL_PANEL_BACK)
        self._expected_label.grid(row=4, column=1, columnspan=2, sticky=tk.EW)

        self.columnconfigure(2, weight=1)

        self._provide_input_suggestions('', 0)
        self._validate_input('')

    def set_focus(self) -> None:
        self._query_entry.focus()

    def _on_caret_moved(self, _: object) -> None:
        caret_index: int = self._query_entry.get_caret_index()
        user_input: str = self._query_entry.get_text()
        self._provide_input_suggestions(user_input, caret_index)

    def _on_text_changed(self, _: object) -> None:
        user_input: str = self._query_entry.get_text()
        self._validate_input(user_input)

    def _on_return_pressed(self, _: object) -> str:
        if self._last_postfix_query:
            self._execute_query(self._last_postfix_query.query_chain)
        return 'break'

    def _on_tab_pressed(self, _: object) -> str | None:
        if self._list_of_suggestions:
            list_of_completion_text: list[str] = [
                f'{candidate.text}{candidate.following_delimiter}'[self._suggestion_starting_index:] for candidate in self._list_of_suggestions
            ]

            completion_text: str
            if len(list_of_completion_text) > 1:
                length_of_shortest_completion_text: int = min(len(text) for text in list_of_completion_text)
                completion_length: int = 0
                for completion_length in range(length_of_shortest_completion_text):
                    if len({text[completion_length] for text in list_of_completion_text}) != 1:
                        break
                completion_text = list_of_completion_text[0][:completion_length]
            else:
                completion_text = list_of_completion_text[0]

            self._query_entry.selection_clear()
            self._query_entry.insert(tk.INSERT, completion_text)
        return 'break'

    def _execute_query(self, postfix_query_chain: Sequence[IQuery]) -> None:
        try:
            result: PostfixQueryResult = self._postfix_executor.execute(self._list_of_teases, postfix_query_chain, 10_000_000)
        except PostfixError as ex:
            messagebox.showerror(
                title='Unexpected error',
                message='Unexpected fault in postfix query chain',
                detail=ex.message,
            )
            return

        self._selected_tease_index.set(None)
        self._list_of_tease_matches.set(self._tease_match_sorter.sort(result.list_of_tease_matches, self._list_of_active_sort_keys.get()))
        if result.list_of_tease_matches:
            self._selected_tease_index.set(0)

        if result.was_max_match_count_reached:
            percentage_searched: float = 0.0
            if result.queried_tease_count != 0:
                percentage_searched = 100.0 * result.queried_tease_count / result.total_tease_count
            messagebox.showwarning(
                title='Limit reached',
                message=f'Limit of {result.max_match_count:,} matching items was reached.',
                detail=(
                    f'Search stopped with {result.total_match_count:,} matching items.\n'
                    f'Searched {result.queried_tease_count:,} of {result.total_tease_count:,} teases ({percentage_searched:.1f}%).'
                ),
            )

    def _validate_input(self, text: str) -> None:
        token_stream: ExpandingTokenStream = ExpandingTokenStream(text, self._user_variables)
        token_stream.set_keep_delimiters('()')

        self._last_postfix_query = None
        try:
            self._last_postfix_query = self._infix_parser.convert_to_postfix(token_stream)
        except TokenStreamError as ex:
            self._status_label.config(text=f'Token Error: {ex.cause_of_fault_text}')
            if ex.cause_of_fault_token:
                self._query_entry.show_error(ex.cause_of_fault_token.inner_indices.start, ex.cause_of_fault_token.inner_indices.end)
            else:
                self._query_entry.show_error(ex.cause_of_fault_character_index)
            self._expected_label.config(text=_get_expected_text(ex.list_of_candidate_text))
        except ArgumentError as ex:
            self._status_label.config(text=f"Argument Error: {ex.message}")
            if ex.fault_token:
                self._query_entry.show_error(ex.fault_token.inner_indices.start, ex.fault_token.inner_indices.end)
            else:
                self._query_entry.clear_error()
            self._expected_label.config(text=_get_expected_text(ex.list_of_candidate_text))
        except InfixError as ex:
            self._status_label.config(text=f'Infix Error: {ex.message}')
            if ex.fault_token:
                self._query_entry.show_error(ex.fault_token.inner_indices.start, ex.fault_token.inner_indices.end)
            else:
                self._query_entry.clear_error()
            self._expected_label.config(text=_get_expected_text(ex.list_of_candidate_text))
        else:
            self._status_label.config(text='Okay')
            self._query_entry.clear_error()
            self._expected_label.config(text=_get_expected_text(self._last_postfix_query.list_of_candidate_text))

        self._expansion_label.config(text=token_stream.get_expanded_raw_text())
        self._query_icon.config(image=self._input_correct_image if self._last_postfix_query else self._input_error_image)

    def _provide_input_suggestions(self, text: str, cursor_index: int) -> None:
        list_of_candidate_text: list[CandidateText] = []

        text_of_tokens_before_cursor: str = text[:cursor_index]
        token_stream: ExpandingTokenStream = ExpandingTokenStream(text_of_tokens_before_cursor, self._user_variables, None, None, cursor_index)
        token_stream.set_keep_delimiters('()')

        try:
            postfix_query: PostfixQuery = self._infix_parser.convert_to_postfix(token_stream)
        except (TokenStreamError, ArgumentError, InfixError) as ex:
            list_of_candidate_text.extend(ex.list_of_candidate_text)
        else:
            list_of_candidate_text.extend(postfix_query.list_of_candidate_text)

        stopped_on_token: ExpandedToken | None = token_stream.get_stopped_on_token()
        if stopped_on_token and stopped_on_token.text.startswith('$') and token_stream.is_expansion_enabled():
            list_of_variable_names: Iterable[str] = [f'${name}' for name in self._user_variables.get_list_of_names()]
            list_of_candidate_text.extend(CandidateText.space_delimited_list(list_of_variable_names))

        self._suggestion_starting_index = cursor_index - stopped_on_token.original_token.outer_indices.start if stopped_on_token else 0

        self._list_of_suggestions = _get_suggestion_candidates(list_of_candidate_text, cursor_index, stopped_on_token)
        self._suggestions_label.config(text=_get_expected_text(self._list_of_suggestions))

def _get_suggestion_candidates(list_of_candidate_text: Sequence[CandidateText], cursor_index: int, stopped_on_token: ExpandedToken | None = None) -> list[CandidateText]:
    partial_token_text: str = stopped_on_token.text[:cursor_index - stopped_on_token.original_token.outer_indices.start] if stopped_on_token else ''
    return [
        candidate_text for candidate_text in sorted(list_of_candidate_text, key=lambda ct: ct.text) if candidate_text.text.startswith(partial_token_text)
    ]

def _get_expected_text(list_of_candidate_text: Sequence[CandidateText]) -> str:
    return ', '.join([
        f'{candidate_text.text}{candidate_text.following_delimiter}' for candidate_text in sorted(list_of_candidate_text, key=lambda ct: ct.text)
    ])
