# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from __future__ import annotations
import tkinter as tk
from typing import override
from milodb_client.view.gui.log_text import LogText

class OpenTeaseDialog(tk.Toplevel):
    def __init__(self, master: tk.Tk | tk.Toplevel) -> None:
        super().__init__(master)
        self.geometry('320x200')

        self._log_text: LogText = LogText(self)
        self._log_text.pack(fill=tk.BOTH, expand=True)

        self.transient(master)
        self.wait_visibility()
        self.grab_set()

    @override
    def destroy(self) -> None:
        self.grab_release()
        super().destroy()

    @property
    def log_text(self) -> LogText:
        return self._log_text

    def show_okay_button(self) -> None:
        button: tk.Button = tk.Button(self, text='Okay', command=self.destroy)
        button.pack()
