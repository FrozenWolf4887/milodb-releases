# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
import tkinter as tk
from collections.abc import Sequence
from pathlib import Path
from tkinter import ttk
from typing import TYPE_CHECKING
from PIL import Image, ImageTk
from milodb_client.config.launch_config import BrowseLaunchConfig, OpenLaunchConfig
from milodb_client.config.update_config import UpdateConfig
from milodb_client.database.tease import Tease
from milodb_client.database.thumbnail_database import ThumbnailDatabase
from milodb_client.query.tease_match import TeaseMatch
from milodb_client.resources import resource_path
from milodb_client.startup.shutdown_action import IShutdownAction
from milodb_client.updater.local_file_hasher import LocalFileHasher
from milodb_client.updater.local_file_tester import LocalFileTester
from milodb_client.updater.manifest.local_manifest import ILocalManifest
from milodb_client.updater.temp_directory import TempDirectoryCreator
from milodb_client.util.launcher import launch
from milodb_client.util.sort_keys import DATE_SORT_KEY, OrderedSortKey, TEASE_ID_SORT_KEY
from milodb_client.util.tease_match_sorter import ITeaseMatchSorter, TeaseMatchSorter
from milodb_client.view.gui import general_colours, general_layout
from milodb_client.view.gui.match_info_panel import MatchInfoPanel
from milodb_client.view.gui.open_tease_dialog import OpenTeaseDialog
from milodb_client.view.gui.raw_query_panel import RawQueryPanel
from milodb_client.view.gui.table_list_panel import TableListPanel
from milodb_client.view.gui.tease_card_list_panel import TeaseCardListPanel
from milodb_client.view.gui.text_matches_panel import TextMatchesPanel
from milodb_client.view.gui.toolbar_panel import ToolbarPanel
from milodb_client.view.gui.update_dialog import UpdateDialog
from milodb_common.config.framework import IConfig
from milodb_common.datum.ref_datum import RefDatum
from milodb_common.internet.uri_scraper_factory import UriScraperFactory
from milodb_common.util.get_url import get_url_of_tease
from milodb_common.variables.i_user_variables import IUserVariables
if TYPE_CHECKING:
    from milodb_common.config.i_launch_config import ILaunchConfig

# spell-checker: ignore padx pady

_PANED_WINDOW_STYLE_NAME: str = 'My.TPanedwindow'
_COL_PANEL_BACK: str = general_colours.PANEL_BACK
_LAYOUT_PANEL_MARGIN_X: int = general_layout.PANEL_MARGIN_X
_LAYOUT_PANEL_MARGIN_Y: int = general_layout.PANEL_MARGIN_Y

class MainWindow:
    def __init__(self, local_manifest: ILocalManifest | None, system_config: IConfig, list_of_teases: Sequence[Tease], thumbnail_database: ThumbnailDatabase, user_variables: IUserVariables, ref_shutdown_action: RefDatum[IShutdownAction | None]) -> None:
        self._local_manifest: ILocalManifest | None = local_manifest
        self._list_of_teases: Sequence[Tease] = list_of_teases
        self._thumbnail_database: ThumbnailDatabase = thumbnail_database
        self._user_variables: IUserVariables = user_variables
        self._ref_shutdown_action: RefDatum[IShutdownAction | None] = ref_shutdown_action

        self._update_config: UpdateConfig = UpdateConfig(system_config)
        self._command_browse_launch_config: ILaunchConfig = BrowseLaunchConfig(system_config)
        self._command_open_launch_config: ILaunchConfig = OpenLaunchConfig(system_config)
        self._list_of_tease_matches: RefDatum[Sequence[TeaseMatch]] = RefDatum([])
        self._selected_tease_index: RefDatum[int | None] = RefDatum(None)
        self._list_of_active_sort_keys: RefDatum[Sequence[OrderedSortKey]] = RefDatum([])
        self._abbreviate_text: RefDatum[bool] = RefDatum(default=True)
        self._show_only_matching_pages: RefDatum[bool] = RefDatum[bool](default=True)
        self._show_page_refs: RefDatum[bool] = RefDatum[bool](default=False)
        self._tease_match_sorter: ITeaseMatchSorter = TeaseMatchSorter([OrderedSortKey(DATE_SORT_KEY, is_ascending=False), OrderedSortKey(TEASE_ID_SORT_KEY, is_ascending=False)])

        self._reset_tease_matches()
        self._init_window()
        self._window.mainloop()

    def _init_window(self) -> None:
        self._window: tk.Tk = tk.Tk()
        self._window.configure(background=_COL_PANEL_BACK)
        self._window.title('MiloDB')

        style = ttk.Style(master=self._window)
        list_of_preferred_styles: list[str] = ['clam', 'alt']
        preferred_style: str
        for preferred_style in list_of_preferred_styles:
            if preferred_style in style.theme_names():
                style.theme_use(preferred_style)
                break

        style.configure(_PANED_WINDOW_STYLE_NAME, background='#888', foreground='#FFF')

        icon: Image.Image
        with Image.open(resource_path(Path('milodb-search-icon.ico'))) as icon:
            self._window.iconphoto(True, ImageTk.PhotoImage(icon)) # noqa: FBT003 Boolean positional value in function call
        self._window.geometry('1024x600')

        top_frame: tk.Frame = tk.Frame(self._window, background=_COL_PANEL_BACK)
        raw_query_panel: RawQueryPanel = RawQueryPanel(top_frame, self._list_of_teases, self._user_variables, self._list_of_tease_matches, self._selected_tease_index, self._tease_match_sorter, self._list_of_active_sort_keys)
        raw_query_panel.grid(column=0, row=0, sticky=tk.NSEW, padx=(0, _LAYOUT_PANEL_MARGIN_X))
        ToolbarPanel(top_frame, self._open_update_dialog).grid(column=1, row=0, sticky='nse')
        top_frame.columnconfigure(0, weight=1)
        top_frame.rowconfigure(0, weight=1)
        top_frame.pack(fill=tk.X, pady=(0, _LAYOUT_PANEL_MARGIN_Y))

        outer_paned_window: ttk.PanedWindow = ttk.PanedWindow(self._window, orient=tk.HORIZONTAL, style=_PANED_WINDOW_STYLE_NAME)
        outer_paned_window.pack(fill=tk.BOTH, expand=True)

        list_frame: tk.Frame = tk.Frame(outer_paned_window, background=_COL_PANEL_BACK)
        match_info_panel: MatchInfoPanel = MatchInfoPanel(list_frame, self._list_of_teases, self._list_of_tease_matches, self._selected_tease_index, self._reset_tease_matches)
        match_info_panel.pack(fill=tk.X, pady=(0, _LAYOUT_PANEL_MARGIN_Y))
        inner_paned_window: ttk.PanedWindow = ttk.PanedWindow(list_frame, orient=tk.HORIZONTAL, style=_PANED_WINDOW_STYLE_NAME)
        inner_paned_window.pack(fill=tk.BOTH, expand=True, padx=(0, _LAYOUT_PANEL_MARGIN_X))

        table_list_panel: TableListPanel = TableListPanel(inner_paned_window, self._list_of_tease_matches, self._selected_tease_index, self._tease_match_sorter, self._list_of_active_sort_keys, self._open_tease)
        card_list_panel: TeaseCardListPanel = TeaseCardListPanel(inner_paned_window, self._list_of_tease_matches, self._selected_tease_index, self._thumbnail_database, self._open_tease)
        text_matches_panel: TextMatchesPanel = TextMatchesPanel(outer_paned_window, self._list_of_tease_matches, self._selected_tease_index, self._show_only_matching_pages, self._abbreviate_text, self._show_page_refs)

        outer_paned_window.add(list_frame, weight=1)
        outer_paned_window.add(text_matches_panel, weight=1)
        outer_paned_window.update()
        outer_paned_window.sashpos(0, int(outer_paned_window.winfo_width() * 0.85))

        inner_paned_window.add(table_list_panel, weight=1)
        inner_paned_window.add(card_list_panel, weight=1)
        inner_paned_window.update()
        inner_paned_window.sashpos(0, int(inner_paned_window.winfo_width() * 0.5))

        raw_query_panel.set_focus()

    def _reset_tease_matches(self) -> None:
        self._selected_tease_index.set(None)
        self._list_of_tease_matches.set(
            self._tease_match_sorter.sort([
                TeaseMatch(index + 1, tease, []) for index, tease in enumerate(self._list_of_teases)
            ],
            self._list_of_active_sort_keys.get(),
        ))

    def _open_update_dialog(self) -> None:
        UpdateDialog(self._window, self._update_config, self._local_manifest, LocalFileHasher(), LocalFileTester(), UriScraperFactory(), TempDirectoryCreator(), self._ref_shutdown_action, self._shutdown_app)

    def _open_tease(self, tease: Tease) -> None:
        open_tease_dialog: OpenTeaseDialog = OpenTeaseDialog(self._window)
        open_tease_dialog.log_text.normal_printer.writeln(f"Opening '{tease.get_title()}'")
        tease_url: str = get_url_of_tease(tease.get_tease_id())
        launch(self._command_open_launch_config, None, tease_url, open_tease_dialog.log_text.normal_printer, open_tease_dialog.log_text.warning_printer, open_tease_dialog.log_text.error_printer)
        if open_tease_dialog.log_text.any_warnings_or_errors:
            open_tease_dialog.show_okay_button()
        else:
            open_tease_dialog.destroy()

    def _shutdown_app(self) -> None:
        self._window.destroy()
