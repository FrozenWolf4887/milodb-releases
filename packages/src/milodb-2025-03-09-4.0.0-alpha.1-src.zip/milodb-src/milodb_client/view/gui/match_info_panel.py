# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
import tkinter as tk
from collections.abc import Callable, Sequence
from typing import override
from milodb_client.database.tease import Tease
from milodb_client.query.tease_match import TeaseMatch
from milodb_client.view.gui import general_colours, general_layout
from milodb_common.datum.ref_datum import RefDatum

# spell-checker: ignore padx pady borderwidth

_COL_PANEL_BACK: str = general_colours.PANEL_BACK
_COL_TEXT_FORE: str = general_colours.PANEL_TEXT_FORE
_COL_TEXT_BACK: str = general_colours.PANEL_BACK
_COL_BUTTON_BACK: str = general_colours.BUTTON_BACK
_COL_BUTTON_FORE: str = general_colours.BUTTON_FORE

_LAYOUT_RELIEF: general_layout.Relief = general_layout.PANEL_RELIEF
_LAYOUT_BORDER_WIDTH: int = general_layout.PANEL_BORDER_WIDTH
_LAYOUT_PADDING_X: int = general_layout.PANEL_PADDING_X
_LAYOUT_PADDING_Y: int = general_layout.PANEL_PADDING_Y

class MatchInfoPanel(tk.Frame):
    def __init__(self, master: tk.Misc, list_of_teases: Sequence[Tease], list_of_tease_matches: RefDatum[Sequence[TeaseMatch]], selected_tease_index: RefDatum[int | None], reset_tease_matches: Callable[[], None]) -> None:
        super().__init__(master, background=_COL_PANEL_BACK, relief=_LAYOUT_RELIEF, padx=_LAYOUT_PADDING_X, pady=_LAYOUT_PADDING_Y, borderwidth=_LAYOUT_BORDER_WIDTH)
        self._list_of_teases: Sequence[Tease] = list_of_teases
        self._list_of_tease_matches: RefDatum[Sequence[TeaseMatch]] = list_of_tease_matches
        self._selected_tease_index: RefDatum[int | None] = selected_tease_index
        self._reset_tease_matches: Callable[[], None] = reset_tease_matches

        tk.Button(self, text='Reset', foreground=_COL_BUTTON_FORE, background=_COL_BUTTON_BACK, command=self._on_reset_button_pressed).pack(side=tk.LEFT)
        self._tease_match_count_text: tk.Label = tk.Label(self, foreground=_COL_TEXT_FORE, background=_COL_TEXT_BACK, padx=10)
        self._tease_match_count_text.pack(side=tk.LEFT)
        self._selected_tease_text: tk.Label = tk.Label(self, foreground=_COL_TEXT_FORE, background=_COL_TEXT_BACK, padx=10)
        self._selected_tease_text.pack(side=tk.LEFT)

        self._list_of_tease_matches.add_listener(self._on_list_of_tease_matches_changed, call_immediately=True)
        self._selected_tease_index.add_listener(self._on_selected_tease_index_changed, call_immediately=True)

    @override
    def destroy(self) -> None:
        self._list_of_tease_matches.remove_listener(self._on_list_of_tease_matches_changed)
        self._selected_tease_index.remove_listener(self._on_selected_tease_index_changed)
        super().destroy()

    def _on_list_of_tease_matches_changed(self, _: RefDatum[Sequence[TeaseMatch]]) -> None:
        tease_count: int = len(self._list_of_teases)
        match_count: int = len(self._list_of_tease_matches.get())
        match_percentage: int = max(1 if match_count else 0, match_count * 100 // tease_count) if tease_count > 0 else 0
        self._tease_match_count_text.config(text=f'Showing {match_count:,} of {tease_count:,} teases ({match_percentage}%)')

    def _on_selected_tease_index_changed(self, _: RefDatum[int | None]) -> None:
        selected_tease_index: int | None = self._selected_tease_index.get()
        if selected_tease_index is None:
            self._selected_tease_text.config(text='Nothing selected')
        else:
            tease_match: TeaseMatch = self._list_of_tease_matches.get()[selected_tease_index]
            self._selected_tease_text.config(text=f'Selected tease #{tease_match.tease.get_tease_id()}')

    def _on_reset_button_pressed(self) -> None:
        self._reset_tease_matches()
