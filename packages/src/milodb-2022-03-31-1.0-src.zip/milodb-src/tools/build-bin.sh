#!/bin/bash
set -e
echo "** Prepare virtual environment"
python -m venv /tmp/mvdb/venv --clear
source /tmp/mvdb/venv/bin/activate
pip install pyinstaller py7zr colorama pyperclip
echo "** Build executable"
pyinstaller --distpath bin --workpath /tmp/mvdb/build --clean --strip ../milodb.spec
