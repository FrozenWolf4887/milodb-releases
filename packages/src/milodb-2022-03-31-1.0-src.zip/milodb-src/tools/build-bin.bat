@echo off
echo ** Prepare virtual environment
python -m venv "%TEMP%\mvdb\venv" --clear
call "%TEMP%\mvdb\venv\Scripts\activate.bat"
python -m pip install --upgrade pip
pip install wheel
pip install pyinstaller pyreadline py7zr colorama pyperclip
echo ** Build executable
pyinstaller --distpath bin --workpath "%TEMP%\mvdb\build" --clean ..\milodb.spec
call "%TEMP%\mvdb\venv\Scripts\deactivate.bat"
