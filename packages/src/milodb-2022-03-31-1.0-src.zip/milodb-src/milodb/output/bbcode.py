import milodb.query as query
from milodb.config import BBCodeConfig, UserConfig
from milodb.output.outputter import Outputter
from milodb.output.support import IterateThroughMatches, EllipsifyText, EllipsisLocation, get_url_of_tease, get_url_of_author, get_list_of_metadata_matches
from milodb.tease import Tease, TeaseProperty, TeaseStrListProperty, TotmStatus
from typing import Dict, List, Optional

from milodb.tease import TeaseProperty

_MAP_OF_TOTM_STATUS_TO_TEXT: Dict[TotmStatus, str] = {
    TotmStatus.NONE: ' ',
    TotmStatus.NOMINEE: 'n',
    TotmStatus.WINNER: 'w'
}

class BBCodeOutputter(Outputter):
    def __init__(self, bbcode_config: BBCodeConfig, user_config: UserConfig) -> None:
        self._bbcode_config: BBCodeConfig = bbcode_config
        self._user_config: UserConfig = user_config

    def get_name(self) -> str:
        return 'bbcode'

    def print_list_of_teases(self, list_of_tease_matches: List[query.TeaseMatch]) -> None:
        tease_match: query.TeaseMatch
        for tease_match in list_of_tease_matches:
            self._print_oneline_of_tease(tease_match)

    def print_summary_of_tease(self, tease_match: query.TeaseMatch) -> None:
        match_index: str = str(tease_match.index_of_match) if tease_match.index_of_match else 'none'
        tease_id: int = tease_match.tease.tease_id
        author_id: int = tease_match.tease.author_id
        formatted_tease_id: str = self._highlight_metadata(tease_match, Tease.tease_id, 6, '#')
        formatted_author_id: str = self._highlight_metadata(tease_match, Tease.author_id, 6, '@')
        formatted_tease_title: str = self._highlight_metadata(tease_match, Tease.title)
        formatted_author_name: str = self._highlight_metadata(tease_match, Tease.author_name)
        formatted_tease_date: str = self._highlight_metadata(tease_match, Tease.date)
        formatted_tease_type: str = self._highlight_metadata(tease_match, Tease.type, 7)
        formatted_tease_rating: str = self._highlight_metadata(tease_match, Tease.rating_value, 7)
        formatted_tags: str = ', '.join(self._highlight_metadata_string_list(tease_match, Tease.list_of_tags, False, False))
        formatted_summary: str = self._highlight_metadata(tease_match, Tease.summary)
        url_of_tease: str = get_url_of_tease(tease_id)
        url_of_author: str = get_url_of_author(author_id)
        print(f"[pre][color={self._bbcode_config.index_heading_colour}]Index   [/color]{match_index:>7}[/pre]")
        print(f"[pre][color={self._bbcode_config.tease_heading_colour}]Tease   [/color][url={url_of_tease}]{formatted_tease_id}[/url]   [color={self._bbcode_config.tease_heading_colour}]Title  [/color][/pre]'{formatted_tease_title}'")
        print(f"[pre][color={self._bbcode_config.author_heading_colour}]Author  [/color][url={url_of_author}]{formatted_author_id}[/url]   [color={self._bbcode_config.author_heading_colour}]Name   [/color][/pre]'{formatted_author_name}'")
        print(f"[pre][color={self._bbcode_config.type_heading_colour}]Type    [/color]{formatted_tease_type}   [color={self._bbcode_config.date_heading_colour}]Date   [/color][/pre]{formatted_tease_date}")
        print(f"[pre][color={self._bbcode_config.rating_heading_colour}]Rating  [/color]{formatted_tease_rating}   [color={self._bbcode_config.tags_heading_colour}]Tags   [/color][/pre]{formatted_tags}")
        print(f"[pre][color={self._bbcode_config.summary_heading_colour}]Summary[/color][/pre]")
        print(formatted_summary or 'None')

    def print_matching_text_of_list_of_teases(self, list_of_tease_matches: List[query.TeaseMatch]) -> None:
        index: int
        tease_match: query.TeaseMatch
        for index, tease_match in enumerate(list_of_tease_matches):
            if index > 0:
                print()
            self.print_summary_of_tease(tease_match)
            self._print_matching_text_of_tease(tease_match)

    def _print_matching_text_of_tease(self, tease_match: query.TeaseMatch) -> None:
        list_of_formatted_text: List[str] = self._highlight_metadata_string_list(tease_match, Tease.list_of_text_blocks, True, self._user_config.is_ellipsis_enabled)
        if list_of_formatted_text:
            print(f'[color={self._bbcode_config.matching_text_heading_colour}]Matching text[/color]')
            print(f"[pre]{40 * '-'}[/pre]")

            for formatted_text_block in list_of_formatted_text:
                print(formatted_text_block)
                print(f"[pre]{40 * '-'}[/pre]")

    def _print_oneline_of_tease(self, tease_match: query.TeaseMatch) -> None:
        tease_id: int = tease_match.tease.tease_id
        author_id: int = tease_match.tease.author_id
        match_index: str = str(tease_match.index_of_match) if tease_match.index_of_match else '-'
        formatted_tease_id: str = self._highlight_metadata(tease_match, Tease.tease_id, 5, '#')
        formatted_tease_type: str = self._highlight_metadata(tease_match, Tease.type)
        formatted_tease_rating: str = self._highlight_metadata(tease_match, Tease.rating_value)
        formatted_tease_date: str = self._highlight_metadata(tease_match, Tease.date)
        formatted_tease_title: str = self._highlight_metadata(tease_match, Tease.title)
        formatted_author_name: str = self._highlight_metadata(tease_match, Tease.author_name)
        formatted_author_id: str = self._highlight_metadata(tease_match, Tease.author_id)
        totm_text: str = _MAP_OF_TOTM_STATUS_TO_TEXT.get(tease_match.tease.totm_status, ' ')
        url_of_tease: str = get_url_of_tease(tease_id)
        url_of_author: str = get_url_of_author(author_id)
        print((
            "[pre]"
            f'{match_index:>3}:'
            f'  [url={url_of_tease}]{formatted_tease_id}[/url]'
            f'  {formatted_tease_type}'
            f'  {formatted_tease_rating}'
            f'  {totm_text}'
            f'  {formatted_tease_date}'
            f'  [/pre]{formatted_tease_title}'
            f' : [[i][/i]{formatted_author_name}, [url={url_of_author}]@{formatted_author_id}[/url]]'))

    def _highlight_text(self, text: str, list_of_matches: List[query.MatchDetails], is_ellipsis_enabled: bool) -> str:
        formatted_text = ''

        def on_normal_text(text: str, is_first_item: bool, is_last_item: bool) -> None:
            nonlocal formatted_text
            if is_ellipsis_enabled:
                formatted_text += self._ellipsify_and_escape_text_item(text, is_first_item, is_last_item)
            else:
                formatted_text += _escape_text(text)

        def on_matched_text(text: str, is_first_item: bool, is_last_item: bool) -> None:
            nonlocal formatted_text
            if self._user_config.is_highlighting_enabled:
                formatted_text += f'[b][color={self._bbcode_config.matching_text_colour}]'
                formatted_text += _escape_text(text)
                formatted_text += '[/color][/b]'
            else:
                formatted_text += _escape_text(text)

        IterateThroughMatches(text, list_of_matches, on_normal_text, on_matched_text)

        return formatted_text

    def _ellipsify_and_escape_text_item(self, text, is_first_item: bool, is_last_item: bool) -> str:
        formatted_text: str = ''

        def on_text(text: str):
            nonlocal formatted_text
            formatted_text += _escape_text(text)

        def on_ellipsis():
            nonlocal formatted_text
            formatted_text += f'[color={self._bbcode_config.ellipsis_colour}]\u2026[/color]'

        EllipsifyText(text, self._user_config.ellipsis_max_width, EllipsisLocation.from_position(is_first_item, is_last_item), on_text, on_ellipsis)

        return formatted_text

    def _highlight_metadata(self, tease_match: query.TeaseMatch, tease_property: TeaseProperty, width: int = 0, prefix_text:str = None) -> str:
        field_value: str = tease_match.tease.get_text_of_property(tease_property)
        formatted_value: str = self._highlight_text(field_value, get_list_of_metadata_matches(tease_property, tease_match.list_of_query_matches), False)

        if width != 0:
            if prefix_text:
                formatted_value = prefix_text + formatted_value

            pad_char_count = abs(width) - len(field_value)
            if pad_char_count > 0:
                if width < 0:
                    formatted_value = formatted_value + (pad_char_count * ' ')
                else:
                    formatted_value = (pad_char_count * ' ') + formatted_value

        return formatted_value

    def _highlight_metadata_string_list(self, tease_match: query.TeaseMatch, tease_property: TeaseStrListProperty, include_matching_only: bool, use_ellipsis: bool) -> List[str]:
        list_of_formatted_text: List[str] = []

        index_of_block: int
        text_block: str
        for index_of_block, text_block in enumerate(tease_match.tease.get_str_list_property(tease_property)):
            list_of_text_query_matches: List[query.FieldStrListQueryMatch] = [
                query_match for query_match in tease_match.list_of_query_matches if
                    isinstance(query_match, query.FieldStrListQueryMatch) and (query_match.tease_property == tease_property) and (query_match.index_of_block == index_of_block)
            ]
            formatted_text: Optional[str] = None
            if list_of_text_query_matches:
                for text_query_match in list_of_text_query_matches:
                    formatted_text = self._highlight_text(text_block, text_query_match.list_of_matches, use_ellipsis and include_matching_only)
            elif not include_matching_only:
                formatted_text = _escape_text(text_block)

            if formatted_text is not None:
                list_of_formatted_text.append(formatted_text)

        return list_of_formatted_text

def _escape_text(text: str) -> str:
    return text.replace('[', '[[i][/i]')
