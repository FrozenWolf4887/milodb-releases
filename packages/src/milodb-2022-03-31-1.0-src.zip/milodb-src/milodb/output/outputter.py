import milodb.query as query
from abc import ABC, abstractmethod
from typing import List

class Outputter(ABC):
    @abstractmethod
    def get_name(self) -> str: pass
    @abstractmethod
    def print_list_of_teases(self, list_of_tease_matches: List[query.TeaseMatch]) -> None: pass
    @abstractmethod
    def print_summary_of_tease(self, tease_match: query.TeaseMatch) -> None: pass
    @abstractmethod
    def print_matching_text_of_list_of_teases(self, list_of_tease_matches: List[query.TeaseMatch]) -> None: pass
