import milodb.query as query
from milodb.tease import TeaseProperty
from enum import Enum
from typing import Callable, List

class EllipsisLocation(Enum):
    LEFT = 0
    MIDDLE = 1
    RIGHT = 2

    @classmethod
    def from_position(cls, is_first_item: bool, is_last_item: bool) -> 'EllipsisLocation':
        if is_first_item:
            if is_last_item:
                return EllipsisLocation.MIDDLE
            else:
                return EllipsisLocation.LEFT
        else:
            if is_last_item:
                return EllipsisLocation.RIGHT
            else:
                return EllipsisLocation.MIDDLE

def get_url_of_tease(tease_id: int) -> str:
    return f"https://milovana.com/webteases/showtease.php?id={tease_id}"

def get_url_of_author(author_id: int) -> str:
    return f"https://milovana.com/forum/memberlist.php?mode=viewprofile&u={author_id}"

def get_list_of_metadata_matches(tease_property: TeaseProperty, list_of_query_matches: List[query.QueryMatch]) -> List[query.MatchDetails]:
    list_of_matches: List[query.MatchDetails] = []

    query_match: query.QueryMatch
    for query_match in list_of_query_matches:
        if isinstance(query_match, query.FieldQueryMatch) and query_match.tease_property == tease_property:
            list_of_matches.extend(query_match.list_of_matches)

    return list_of_matches

def abbrev_text_with_ellipsis(text: str, max_length: int, ellipsis_location: EllipsisLocation, ellipsis_text: str):
    if len(text) > max_length:
        if ellipsis_location == EllipsisLocation.RIGHT:
            text = ellipsis_text + text[len(text) - max_length + 1:]
        elif ellipsis_location == EllipsisLocation.MIDDLE:
            text = text[:max_length // 2] + ellipsis_text + text[len(text) - (max_length - 1) // 2:]
        else:
            text = text[:max_length - 1] + ellipsis_text

    return text

class EllipsifyText:
    def __init__(self, text: str, max_length: int, ellipsis_location: EllipsisLocation, callback_normal_text: Callable[[str], None], callback_ellipsis: Callable[[], None]):
        if ellipsis_location == EllipsisLocation.MIDDLE:
            max_length *= 2
        if len(text) > max_length:
            if ellipsis_location == EllipsisLocation.LEFT:
                callback_ellipsis()
                callback_normal_text(text[len(text) - max_length + 1:])
            elif ellipsis_location == EllipsisLocation.MIDDLE:
                callback_normal_text(text[:max_length // 2])
                callback_ellipsis()
                callback_normal_text(text[len(text) - (max_length - 1) // 2:])
            else:
                callback_normal_text(text[:max_length - 1])
                callback_ellipsis()
        else:
            callback_normal_text(text)

class IterateThroughMatches:
    def __init__(self, text: str, list_of_matches: List[query.MatchDetails], callback_normal_text: Callable[[str, bool, bool], None], callback_matched_text: Callable[[str, bool, bool], None]) -> None:
        self._text: str = text
        self._list_of_matches: List[query.MatchDetails] = list_of_matches
        self._callback_normal_text: Callable[[str, bool, bool], None] = callback_normal_text
        self._callback_matched_text: Callable[[str, bool, bool], None] = callback_matched_text

        self._match_start_index: int = 0
        self._match_end_index: int = 0
        self._is_currently_in_match: bool = False
        self._is_first_callback: bool = True

        self._index: int = 0
        for self._index in range(0, len(text)):
            self._process_index()

        if self._is_currently_in_match:
            self._callback_matched_text(text[self._match_start_index:], self._is_first_callback, True)
        else:
            self._callback_normal_text(text[self._match_end_index:], self._is_first_callback, True)

    def _process_index(self) -> None:
        if self._is_index_in_match():
            if not self._is_currently_in_match:
                if self._index > self._match_end_index:
                    self._callback_normal_text(self._text[self._match_end_index:self._index], self._is_first_callback, False)
                self._is_first_callback = False
                self._is_currently_in_match = True
                self._match_start_index = self._index
        else:
            if self._is_currently_in_match:
                if self._index > self._match_start_index:
                    self._callback_matched_text(self._text[self._match_start_index:self._index], self._is_first_callback, False)
                self._is_first_callback = False
                self._is_currently_in_match = False
                self._match_end_index = self._index

    def _is_index_in_match(self) -> bool:
        if self._text[self._index] != '\n':
            match: query.MatchDetails
            for match in self._list_of_matches:
                if match.is_whole_match or (self._index >= match.start_index and self._index < match.end_index):
                    return True
        return False
