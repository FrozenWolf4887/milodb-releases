import milodb.query as query
from milodb.config import UserConfig
from milodb.output.outputter import Outputter
from milodb.output.support import IterateThroughMatches, EllipsifyText, EllipsisLocation, get_url_of_author, get_url_of_tease
from milodb.tease import Tease, TotmStatus
from typing import Dict, List

_MAP_OF_TOTM_STATUS_TO_TEXT: Dict[TotmStatus, str] = {
    TotmStatus.NONE: ' ',
    TotmStatus.NOMINEE: 'n',
    TotmStatus.WINNER: 'w'
}

class PlainOutputter(Outputter):
    def __init__(self, user_config: UserConfig) -> None:
        self._user_config: UserConfig = user_config

    def get_name(self) -> str:
        return 'plain'

    def print_list_of_teases(self, list_of_tease_matches: List[query.TeaseMatch]) -> None:
        tease_match: query.TeaseMatch
        for tease_match in list_of_tease_matches:
            self._print_oneline_of_tease(tease_match)

    def print_summary_of_tease(self, tease_match: query.TeaseMatch) -> None:
        match_index: str = str(tease_match.index_of_match) if tease_match.index_of_match else 'none'
        tease_id: int = tease_match.tease.tease_id
        author_id: int = tease_match.tease.author_id
        tease_id_text: str = f'#{tease_id}'
        tease_type: str = tease_match.tease.get_text_of_property(Tease.type)
        tease_rating: float = tease_match.tease.rating_value
        tease_tags: str = ', '.join(tease_match.tease.get_str_list_property(Tease.list_of_tags))
        tease_date: str = tease_match.tease.get_text_of_property(Tease.date)
        tease_title: str = tease_match.tease.title
        author_name: str = tease_match.tease.author_name
        author_id_text: str = f'@{author_id}'
        summary: str = tease_match.tease.summary
        url_of_tease: str = get_url_of_tease(tease_id)
        url_of_author: str = get_url_of_author(author_id)
        print(f"Index   {match_index:>7}")
        print(f"Tease   {tease_id_text:>7}   Title  '{tease_title}'")
        print(f"Author  {author_id_text:>7}   Name   '{author_name}'")
        print(f"Type    {tease_type:>7}   Date   {tease_date}")
        print(f"Rating  {tease_rating:>7}   Tags   {tease_tags}")
        print(f"Tease   {url_of_tease}")
        print(f"Author  {url_of_author}")
        print("Summary")
        print(summary or 'None')

    def print_matching_text_of_list_of_teases(self, list_of_tease_matches: List[query.TeaseMatch]) -> None:
        index: int
        tease_match: query.TeaseMatch
        for index, tease_match in enumerate(list_of_tease_matches):
            if index > 0:
                print()
            self.print_summary_of_tease(tease_match)
            self._print_matching_text_of_tease(tease_match)

    def _print_matching_text_of_tease(self, tease_match: query.TeaseMatch) -> None:
        list_of_text_query_matches: List[query.FieldStrListQueryMatch] = [query_match for query_match in tease_match.list_of_query_matches if isinstance(query_match, query.FieldStrListQueryMatch)]
        if list_of_text_query_matches:
            print('Matching text')
            print(40 * '-')

            text_query_match: query.FieldStrListQueryMatch
            for text_query_match in list_of_text_query_matches:
                text_block: str = tease_match.tease.list_of_text_blocks[text_query_match.index_of_block]
                if self._user_config.is_ellipsis_enabled:
                    ellipsified_text_block: str = self._ellipsify_text(text_block, text_query_match.list_of_matches)
                    print(ellipsified_text_block)
                else:
                    print(text_block)
                print(40 * '-')

    def _print_oneline_of_tease(self, tease_match: query.TeaseMatch) -> None:
        match_index: str = str(tease_match.index_of_match) if tease_match.index_of_match else '-'
        tease_id: str = '#' + str(tease_match.tease.tease_id)
        tease_type: str = tease_match.tease.get_text_of_property(Tease.type)
        tease_rating: float = tease_match.tease.rating_value
        tease_date: str = tease_match.tease.get_text_of_property(Tease.date)
        tease_title: str = tease_match.tease.title
        author_name: str = tease_match.tease.author_name
        author_id: str = str(tease_match.tease.author_id)
        totm_text: str = _MAP_OF_TOTM_STATUS_TO_TEXT.get(tease_match.tease.totm_status, ' ')
        print((
            f'{match_index:>3}:'
            f'  {tease_id:>6}'
            f'  {tease_type}'
            f'  {tease_rating:>3}'
            f'  {totm_text}'
            f'  {tease_date}'
            f'  {tease_title}'
            f' : [{author_name}, @{author_id}]'))

    def _ellipsify_text(self, text: str, list_of_matches: List[query.MatchDetails]) -> str:
        formatted_text = ''

        def on_normal_text(text: str, is_first_item: bool, is_last_item: bool) -> None:
            nonlocal formatted_text
            formatted_text += self._ellipsify_text_item(text, is_first_item, is_last_item)

        def on_matched_text(text: str, is_first_item: bool, is_last_item: bool) -> None:
            nonlocal formatted_text
            formatted_text += text

        IterateThroughMatches(text, list_of_matches, on_normal_text, on_matched_text)

        return formatted_text

    def _ellipsify_text_item(self, text, is_first_item: bool, is_last_item: bool) -> str:
        formatted_text: str = ''

        def on_text(text: str):
            nonlocal formatted_text
            formatted_text += text

        def on_ellipsis():
            nonlocal formatted_text
            formatted_text += '\u2026'

        EllipsifyText(text, self._user_config.ellipsis_max_width, EllipsisLocation.from_position(is_first_item, is_last_item), on_text, on_ellipsis)

        return formatted_text
