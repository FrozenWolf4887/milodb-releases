from milodb.tokeniser import Token
from typing import List, Optional

class LoadError(Exception):
    def __init__(self, message: str, fault_token: Optional[Token], list_of_expected_text: Optional[List[str]]):
        self.message: str = message
        self.fault_token: Optional[Token] = fault_token
        self.list_of_expected_text: Optional[List[str]] = list_of_expected_text

class UnknownCommandError(Exception):
    def __init__(self, command_token: Token):
        self.command_token: Token = command_token
