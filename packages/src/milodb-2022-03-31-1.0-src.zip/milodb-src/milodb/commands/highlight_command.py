from milodb.commands.argument_stream import ArgumentStream
from milodb.commands.command import Command, CommandContext
from milodb.commands.enums import OnOrOff
from typing import List, Optional

class HighlightCommand(Command):
    def __init__(self, context: CommandContext) -> None:
        self._context = context
        self._new_highlighting: Optional[OnOrOff] = None

    def load(self, argument_stream: ArgumentStream) -> Optional[List[str]]:
        if not argument_stream.is_empty():
            self._new_highlighting = argument_stream.pop_enum(OnOrOff)
            argument_stream.fail_if_not_empty()
            return None
        else:
            return OnOrOff.lowercase_names()

    def execute(self) -> None:
        if self._new_highlighting:
            self._context.user_config.is_highlighting_enabled = self._new_highlighting.value
            print(f"Changed highlighting to '{self._new_highlighting.name.lower()}'")
        else:
            print(f"Current highlighting is '{OnOrOff(self._context.user_config.is_highlighting_enabled).name.lower()}'")
            print(f"Available options are {OnOrOff.lowercase_names()}")

    @classmethod
    def get_one_line_summary(cls) -> str:
        return "Sets whether text matches are highlighted in the output"

    @classmethod
    def get_detailed_summary(cls, context: CommandContext) -> str:
        return (
            f"Arguments: [{'|'.join(OnOrOff.lowercase_names())}]\n"
            "Enables or disables the highlighting of matching text in fields and paragraphs.\n"
            "When used without arguments, the current setting is shown.\n"
            "Highlighting will only be shown on the console when a suitable output format has"
            " been selected with the format command.\n"
            "Example:\r"
            "  \tTurn off highlighting\r"
            "  > \thighlight off\r"
            "Example:\r"
            "  \tShow the current setting\r"
            "  > \thighlight\n"
            "See also:\r"
            "  \tlist, show, browse, browseall, ellipsis, format\n"
        )
