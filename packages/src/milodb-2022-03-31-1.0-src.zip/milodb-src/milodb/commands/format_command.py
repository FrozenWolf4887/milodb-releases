from milodb.commands.argument_stream import ArgumentStream
from milodb.commands.command import Command, CommandContext
from milodb.output import Outputter
from typing import Dict, List, Optional

class FormatCommand(Command):
    def __init__(self, context: CommandContext) -> None:
        self._context = context
        self._new_outputter: Optional[Outputter] = None

    def load(self, argument_stream: ArgumentStream) -> Optional[List[str]]:
        if not argument_stream.is_empty():
            map_of_outputter_name_to_object: Dict[str, Outputter] = {}
            for outputter in self._context.list_of_outputters:
                map_of_outputter_name_to_object[outputter.get_name()] = outputter
            self._new_outputter = argument_stream.pop_dict_value(map_of_outputter_name_to_object)
            argument_stream.fail_if_not_empty()
            return None
        else:
            return self._get_list_of_outputter_names(self._context)

    def execute(self) -> None:
        if self._new_outputter:
            self._context.current_outputter = self._new_outputter
            print(f"Changed format to '{self._context.current_outputter.get_name()}'")
        else:
            print(f"Current format is '{self._context.current_outputter.get_name()}'")
            print(f"Available formats are {self._get_list_of_outputter_names(self._context)}")

    @classmethod
    def get_one_line_summary(cls) -> str:
        return "Sets the formatting used in the output of commands"

    @classmethod
    def get_detailed_summary(cls, context: CommandContext) -> str:
        return (
            f"Arguments: [{'|'.join(cls._get_list_of_outputter_names(context))}]\n"
            "Changes the output format that is produced by commands such as list, summary,"
            " and show. Some of the formats are more suitable for copy-pasting into another"
            " application that supports that format; 'bbcode' for example is suitable to be"
            " pasted into the Milovana forums.\n"
            "When used without arguments, the current setting is shown.\n"
            "Example:\r"
            "  \tSelect the bbcode output format\r"
            "  > \tformat bbcode\r"
            "Example:\r"
            "  \tShow the current setting\r"
            "  > \tformat\n"
            "See also:\r"
            "  \tlist, summary, show, ellipsis, highlight\n"
        )

    @staticmethod
    def _get_list_of_outputter_names(context: CommandContext) -> List[str]:
        return [outputter.get_name() for outputter in context.list_of_outputters]
