import milodb.query as query
from milodb.commands.argument_stream import ArgumentStream
from milodb.commands.command import Command, CommandContext
from milodb.commands.command_support import sort_tease_matches
from milodb.commands.exceptions import LoadError
from milodb.infix_to_postfix import FailedPostfixConversionResult, SuccessfulPostfixConversionResult, get_list_of_field_names, get_list_of_operators, get_list_of_verb_names
from milodb.infix_to_postfix import convert as convert_infix_to_postfix
from milodb.tokeniser import Token
from typing import List, Optional, Union

HELP_FIELD_NAMES: List[str] = sorted(get_list_of_field_names())
HELP_VERB_NAMES: List[str] = sorted(get_list_of_verb_names())
HELP_OPERATORS: List[str] = sorted(get_list_of_operators())

class QueryCommand(Command):
    def __init__(self, context: CommandContext) -> None:
        self._context = context
        self._postfix_query_chain: List[query.QueryBase]

    def load(self, argument_stream: ArgumentStream) -> Optional[List[str]]:
        list_of_arguments: List[Token] = []
        while not argument_stream.is_empty():
            list_of_arguments.append(argument_stream.pop_token())

        postfix_result: Union[SuccessfulPostfixConversionResult, FailedPostfixConversionResult] = convert_infix_to_postfix(list_of_arguments)
        if isinstance(postfix_result, SuccessfulPostfixConversionResult):
            self._postfix_query_chain = postfix_result.postfix_query_chain
            return postfix_result.list_of_expected_next_text
        elif isinstance(postfix_result, FailedPostfixConversionResult):
            raise LoadError(
                f"Grammar error: {postfix_result.cause_of_fault_text}",
                 postfix_result.cause_of_fault_token,
                 postfix_result.list_of_expected_next_text)
        else:
            raise LoadError('Internal error: Unexpected postfix conversion result', None, None)

    def execute(self) -> None:
        postfix_query_chain: List[query.QueryBase] = self._postfix_query_chain
        self._context.list_of_tease_matches = self._context.database.run_postfix_query_chain(postfix_query_chain)
        sort_tease_matches(self._context)
        if self._context.list_of_tease_matches:
            self._context.current_outputter.print_list_of_teases(self._context.list_of_tease_matches)
        else:
            print("No matches")

    @classmethod
    def get_one_line_summary(cls) -> str:
        return "Performs a deep search against metadata and text content"

    @classmethod
    def get_detailed_summary(cls, context: CommandContext) -> str:
        return (
            "Arguments: <infix query expression>\n"
            "A simple query is in the form: <field> <verb> <regex>. More complex"
            " queries can be constructed with parentheses and boolean operators.\n"
            "Fields:\r"
            f"  \t{', '.join(HELP_FIELD_NAMES)}\r"
            "Verbs:\r"
            f"  \t{', '.join(HELP_VERB_NAMES)}\r"
            "Operators:\r"
            f"  \t{', '.join(HELP_OPERATORS)}\n"
            "The 'contains' and 'is' verbs are a plain text search where 'contains' will match text"
            " anywhere within the specified field, and 'is' will match against the whole field.\n"
            "The 'match' verb is a regular expression search. For more information on regular"
            " expression syntax, see 'https://pythex.org/'. When the regular expression contains"
            " a space or groups, surround the text with single or double quotes.\n"
            "The '=', '>', '>=', '<', '<=' verbs perform value comparisons against numerical and date"
            " fields.\n"
            "The 'not' operator is used before a conditional expression to negate it, such as 'not"
            " type is eos'.\n"
            "The list of results found by the query are sorted according to the current sort"
            " criteria specified with the sort command, and shown with the list command.\n"
            "Example:\r"
            "  \tSearch all text paragraphs for a word\r"
            "  > \tquery text contains banana\r"
            "Example:\r"
            "  \tSearch the title field\r"
            "  \tNote: Quotes are used here because of the space\r"
            '  > \tquery title contains "lexi belle"\r'
            "Example:\r"
            "  \tSearch all text paragraphs for a regular expression\r"
            "  \tNote: Quotes are used here because of the parentheses\r"
            "  > \tquery text matches '(8|eight).?ball'\r"
            "Example:\r"
            "  \tSearch for all teases over a certain rating\r"
            '  > \tquery rating >= 4.5\r'
            "Example:\r"
            "  \tSearch for all teases on and newer than a certain date\r"
            '  > \tquery date >= 2019-03-14\r'
            "Example:\r"
            "  \tPerform a search for multiple fields\r"
            "  > \tquery title matches denial.+part and rating > 4 and text contains denied\r"
            "Example:\r"
            "  \tPerform a search using parentheses\r"
            '  > \tquery (type is nyx or type is eos) and text matches "chastity.?(belt|cage)"\n'
            "See also:\r"
            "  \tlist, sort, show, summary, browse, browseall\n"
        )
