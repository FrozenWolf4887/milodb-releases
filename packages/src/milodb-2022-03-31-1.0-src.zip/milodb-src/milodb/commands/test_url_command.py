from milodb.commands.command import Command
from milodb.commands.url_command import UrlCommand
from milodb.commands.test_command_base import CommandTestBase
from typing import Type

COMMAND_NAME: str = 'url'
COMMAND_CLASS: Type[Command] = UrlCommand

class TestUrlCommand(CommandTestBase):
    def test_without_arguments_returns_failure(self):
        self.run_test([COMMAND_NAME])
        self.assert_unsuccessful(COMMAND_CLASS, None, 'Insufficient parameters. Expecting RefId', None)

    def test_with_one_index_returns_success(self):
        self.run_test([COMMAND_NAME, '1234'])
        self.assert_successful(COMMAND_CLASS)

    def test_with_two_indices_returns_failure(self):
        self.run_test([COMMAND_NAME, '1234', '5678'])
        self.assert_unsuccessful(COMMAND_CLASS, 2, 'Unexpected additional parameter', None)

    def test_with_signed_index_returns_failure(self):
        self.run_test([COMMAND_NAME, '-5678'])
        self.assert_unsuccessful(COMMAND_CLASS, 1, 'Invalid RefId; expecting value, #value, or @value', None)

    def test_with_one_teaseid_returns_success(self):
        self.run_test([COMMAND_NAME, '#1234'])
        self.assert_successful(COMMAND_CLASS)

    def test_with_two_teaseids_returns_failure(self):
        self.run_test([COMMAND_NAME, '#1234', '#5678'])
        self.assert_unsuccessful(COMMAND_CLASS, 2, 'Unexpected additional parameter', None)

    def test_with_signed_teaseid_returns_failure(self):
        self.run_test([COMMAND_NAME, '#-5678'])
        self.assert_unsuccessful(COMMAND_CLASS, 1, 'TeaseId is not a positive integer', None)

    def test_with_one_authorid_returns_success(self):
        self.run_test([COMMAND_NAME, '@1234'])
        self.assert_successful(COMMAND_CLASS)

    def test_with_two_authorids_returns_failure(self):
        self.run_test([COMMAND_NAME, '@1234', '@5678'])
        self.assert_unsuccessful(COMMAND_CLASS, 2, 'Unexpected additional parameter', None)

    def test_with_signed_authorid_returns_failure(self):
        self.run_test([COMMAND_NAME, '@-5678'])
        self.assert_unsuccessful(COMMAND_CLASS, 1, 'AuthorId is not a positive integer', None)

    def test_with_non_refid_returns_failure(self):
        self.run_test([COMMAND_NAME, 'mango'])
        self.assert_unsuccessful(COMMAND_CLASS, 1, 'Invalid RefId; expecting value, #value, or @value', None)
