from milodb.commands.help_command import HelpCommand
from milodb.commands.test_command_base import CommandTestBase

class TestHelpCommand(CommandTestBase):
    def test_without_arguments_returns_success(self):
        self.run_test(['help'])
        self.assert_successful(HelpCommand)

    def test_with_known_command_argument_returns_success(self):
        self.run_test(['help', 'list'])
        self.assert_successful(HelpCommand)

    def test_with_invalid_argument_returns_failure(self):
        self.run_test(['help', 'mango'])
        self.assert_unsuccessful(HelpCommand, 1, 'Unrecognised command name', self.list_of_command_names)

    def test_with_redundant_argument_returns_failure(self):
        self.run_test(['help', 'list', 'list'])
        self.assert_unsuccessful(HelpCommand, 2, 'Unexpected additional parameter', None)
