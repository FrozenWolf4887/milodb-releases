from milodb.commands.argument_stream import ArgumentStream
from milodb.commands.command import Command, CommandContext
from milodb.commands.exceptions import LoadError
from milodb.tokeniser import Token
from dataclasses import dataclass
from typing import List, Optional, Type, Union

@dataclass
class SuccessfulCommandParseResult:
    command: Command
    list_of_possible_next_text: Optional[List[str]]

@dataclass
class FailedCommandParseResult:
    command_class: Optional[Type[Command]]
    fault_token: Optional[Token]
    fault_text: str
    list_of_expected_text: Optional[List[str]]

def parse(list_of_tokens: Optional[List[Token]], context: CommandContext) -> Union[SuccessfulCommandParseResult, FailedCommandParseResult]:
    result: Union[SuccessfulCommandParseResult, FailedCommandParseResult]

    if list_of_tokens:
        command_token: Token = list_of_tokens[0]
        command_class: Optional[Type[Command]] = context.command_factory.try_get_command_class_from_name(command_token.text)
        if command_class:
            command: Command = command_class(context)
            argument_stream: ArgumentStream = ArgumentStream(list_of_tokens[1:])
            try:
                list_of_possible_next_text: Optional[List[str]] = command.load(argument_stream)
                result = SuccessfulCommandParseResult(command, list_of_possible_next_text)
            except LoadError as ex:
                result = FailedCommandParseResult(command_class, ex.fault_token, ex.message, ex.list_of_expected_text)
        else:
            result = FailedCommandParseResult(None, command_token, 'Unknown command', list(context.command_factory.get_list_of_command_names()))
    else:
        result = FailedCommandParseResult(None, None, 'Input is empty', list(context.command_factory.get_list_of_command_names()))

    return result
