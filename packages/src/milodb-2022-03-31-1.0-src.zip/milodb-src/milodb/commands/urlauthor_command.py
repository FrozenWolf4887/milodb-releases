import milodb.query as query
from milodb.commands.argument_stream import ArgumentStream
from milodb.commands.command import Command, CommandContext
from milodb.commands.database_support import try_get_tease_id_from_ref_id
from milodb.output.support import get_url_of_author
from milodb.ref_id import AuthorId, RefId
import pyperclip # type: ignore
from typing import List, Optional

class UrlAuthorCommand(Command):
    def __init__(self, context: CommandContext) -> None:
        self._context = context
        self._ref_id: RefId

    def load(self, argument_stream: ArgumentStream) -> Optional[List[str]]:
        self._ref_id = argument_stream.pop_ref_id()
        argument_stream.fail_if_not_empty()
        return None

    def execute(self) -> None:
        if isinstance(self._ref_id, AuthorId):
            author_url: str = get_url_of_author(self._ref_id.author_id)
            print(f"Copied to clipboard '{author_url}'")
            pyperclip.copy(author_url)
        else:
            tease_match: Optional[query.TeaseMatch] = try_get_tease_id_from_ref_id(self._context, self._ref_id)
            if tease_match:
                author_url_of_tease = get_url_of_author(tease_match.tease.author_id)
                print(f"Copied to clipboard '{author_url_of_tease}'")
                pyperclip.copy(author_url_of_tease)

    @classmethod
    def get_one_line_summary(cls) -> str:
        return "Copies the URL of an author's profile to the clipboard"

    @classmethod
    def get_detailed_summary(cls, context: CommandContext) -> str:
        return (
            "Arguments: <RefId>\n"
            "The URL is copied to the clipboard to make it easier for users to paste the"
            " URL into other applications as needed.\n"
            "RefIds can be an index into the list of matches such as '3', a teaseId such as"
            " '#38664', or an authorId such as '@43937'.\n"
            "Example:\r"
            "  \tCopy the URL of an author's profile by index in the match list\r"
            "  > \turlauthor 3\r"
            "Example:\r"
            "  \tCopy the URL of an author's profile for a specific teaseId\r"
            "  > \turlauthor #16830\r"
            "Example:\r"
            "  \tCopy the URL of an author's profile by specific authorId\r"
            "  > \turlauthor @43937\n"
            "See also:\r"
            "  \turl, open, openauthor\n"
        )
