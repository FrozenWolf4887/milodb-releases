from milodb.commands.enums import EnumEx
from milodb.commands.exceptions import LoadError
from milodb.ref_id import RefId, MatchIndex, TeaseId, AuthorId
from milodb.tokeniser import Token
from typing import Dict, List, Optional, Tuple, Type, TypeVar

class ArgumentStream:
    def __init__(self, list_of_tokens: List[Token]):
        self._list_of_tokens: List[Token] = list_of_tokens

    def is_empty(self) -> bool:
        return not self._list_of_tokens

    def pop_token(self) -> Token:
        return self._pop('Expecting text or value')

    def pop_text(self) -> str:
        return self.pop_token().text

    def pop_int(self) -> int:
        token: Token = self._pop('Expecting value')
        return self._parse_int(token, token.text, 'Parameter is not an integer')

    def pop_uint(self) -> int:
        token: Token = self._pop('Expecting value')
        return self._parse_uint(token, token.text, 'Parameter is not a positive integer')

    def pop_ref_id(self) -> RefId:
        ref_id: RefId
        value: int
        token: Token = self._pop('Expecting RefId')
        if token.text.startswith('#'):
            value = self._parse_uint(token, token.text[1:], 'TeaseId is not a positive integer')
            ref_id = TeaseId(value)
        elif token.text.startswith('@'):
            value = self._parse_uint(token, token.text[1:], 'AuthorId is not a positive integer')
            ref_id = AuthorId(value)
        elif token.text[0:1].isdigit():
            value = self._parse_uint(token, token.text, 'Match index is not a positive integer')
            ref_id = MatchIndex(value)
        else:
            raise self._create_load_error('Invalid RefId; expecting value, #value, or @value', token)

        return ref_id

    V = TypeVar("V")
    def pop_dict_value(self, dictionary: Dict[str, V]) -> V:
        value, _ = self.pop_dict_value_and_token(dictionary)
        return value

    W = TypeVar("W")
    def pop_dict_value_and_token(self, dictionary: Dict[str, W]) -> Tuple[W, Token]:
        list_of_keys = list(dictionary.keys())
        token: Token = self._pop('Expecting text', list_of_keys)
        try:
            return dictionary[token.text], token
        except KeyError:
            raise self._create_load_error(f'Invalid parameter. Expected one of {list_of_keys}', token, list_of_keys)

    T = TypeVar("T", bound=EnumEx)
    def pop_enum(self, enum_class: Type[T]) -> T:
        enum, _ = self.pop_enum_and_token(enum_class)
        return enum

    U = TypeVar("U", bound=EnumEx)
    def pop_enum_and_token(self, enum_class: Type[U]) -> Tuple[U, Token]:
        token: Token = self._pop('Expecting enumeration value', enum_class.lowercase_names())
        try:
            return enum_class[token.text.upper()], token
        except KeyError:
            raise self._create_load_error(f'Unknown enumeration value', token, enum_class.lowercase_names())

    def fail_if_not_empty(self) -> None:
        if self._list_of_tokens:
            raise self._create_load_error('Unexpected additional parameter', self._list_of_tokens[0])

    def _pop(self, message, list_of_expected_text: Optional[List[str]] = None) -> Token:
        if self._list_of_tokens:
            return self._list_of_tokens.pop(0)
        else:
            raise self._create_load_error(f'Insufficient parameters. {message}', None, list_of_expected_text)

    def _parse_int(self, token: Token, text: str, error_text: str) -> int:
        try:
            value = int(text)
            return value
        except ValueError:
            raise self._create_load_error(error_text, token)

    def _parse_uint(self, token: Token, text: str, error_text: str) -> int:
        value: int = self._parse_int(token, text, error_text)
        if value < 0:
            raise self._create_load_error(error_text, token)
        return value

    def _create_load_error(self, message, token: Optional[Token], list_of_expected_text: Optional[List[str]] = None) -> LoadError:
        return LoadError(message, token, list_of_expected_text)
