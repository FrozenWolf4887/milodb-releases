import milodb.query as query
from milodb.commands import CommandContext, FailedCommandParseResult, OrderedSortKey, RealCommandFactory, SuccessfulCommandParseResult, default_list_of_active_sort_keys, list_of_available_sort_keys
from milodb.commands import parse as parse_command
from milodb.config import AnsiConfig, BBCodeConfig, HtmlConfig, SystemConfig, UserConfig
from milodb.database import Database
from milodb.output import Outputter, PlainOutputter, AnsiOutputter, BBCodeOutputter, HtmlOutputter
from milodb.tokeniser import FailedTokenisationResult, SuccessfulTokenisationResult, Token, tokenise
from milodb.version import MILODB_VERSION, MILODB_DATE
import datetime
import readline
from typing import Optional, List, Union

DATABASE_FILENAME: str = 'database.mdb'
CONFIG_FILENAME: str = 'config.json'
AUTOEXEC_FILENAME: str = 'autoexec.txt'

class Main:
    def __init__(self):
        print(f'Milovana Database {MILODB_VERSION or "(Development)"}, {MILODB_DATE or "(Undated)"}')

        database: Database = Database()
        user_config: UserConfig = UserConfig()
        system_config: SystemConfig = SystemConfig(CONFIG_FILENAME)
        plain_outputter: Outputter = PlainOutputter(user_config)
        ansi_outputter: Outputter = AnsiOutputter(AnsiConfig(system_config), user_config)
        bbcode_outputter: Outputter = BBCodeOutputter(BBCodeConfig(system_config), user_config)
        html_outputter: Outputter = HtmlOutputter(HtmlConfig(system_config), user_config)
        list_of_outputters: List[Outputter] = [plain_outputter, ansi_outputter, bbcode_outputter, html_outputter]
        current_outputter: Outputter = ansi_outputter
        list_of_tease_matches: Optional[List[query.TeaseMatch]] = None
        list_of_active_sort_keys: List[OrderedSortKey] = default_list_of_active_sort_keys
        command_factory: RealCommandFactory = RealCommandFactory()

        database.load_from_file(DATABASE_FILENAME)
        oldest_tease_date: Optional[datetime.date] = database.try_get_oldest_tease_date()
        newest_tease_date: Optional[datetime.date] = database.try_get_newest_tease_date()
        print(f"{database.get_count_of_loaded_teases():,} teases loaded ranging from {oldest_tease_date or 'None'} to {newest_tease_date or 'None'}\n")

        self._context = CommandContext(False, database, command_factory, user_config, system_config, list_of_tease_matches, list_of_available_sort_keys, list_of_active_sort_keys, list_of_outputters, current_outputter)
        self._run_autoexec()
        if not self._context.quit_flag:
            self._run_interactive_prompt()

    def _run_autoexec(self) -> None:
        autoexec_lines: Optional[List[str]] = None

        try:
            with open(AUTOEXEC_FILENAME) as file:
                autoexec_lines = file.readlines()
        except IOError:
            pass

        if autoexec_lines:
            print(f"Running commands from '{AUTOEXEC_FILENAME}':")
            line_index: int = 0
            while (not self._context.quit_flag) and (line_index < len(autoexec_lines)):
                line: str = autoexec_lines[line_index].strip()
                if line:
                    print(f'> {line}')
                    self._process_user_input(line)
                line_index += 1

    def _run_interactive_prompt(self) -> None:
        tab_completer = TabCompleter(self._context)

        print('Enter command (or "help"):')
        while not self._context.quit_flag:
            user_input: str = input('> ')
            self._process_user_input(user_input)

        tab_completer.shutdown()

    def _process_user_input(self, user_input: str):
        tokenise_result: Union[SuccessfulTokenisationResult, FailedTokenisationResult] = tokenise(user_input)
        if isinstance(tokenise_result, SuccessfulTokenisationResult):
            if tokenise_result.list_of_tokens:
                print()
                self._process_command(tokenise_result.list_of_tokens)
                print()
        elif isinstance(tokenise_result, FailedTokenisationResult):
            print(f"\nError: Syntax error: {tokenise_result.cause_of_fault_text} at offset {tokenise_result.cause_of_fault_character_index}\n")
        else:
            print('\nError: Internal error: Unexpected tokenisation result\n')

    def _process_command(self, list_of_tokens: List[Token]):
        parse_result: Union[SuccessfulCommandParseResult, FailedCommandParseResult] = parse_command(list_of_tokens, self._context)
        if isinstance(parse_result, SuccessfulCommandParseResult):
            parse_result.command.execute()
        elif isinstance(parse_result, FailedCommandParseResult):
            print(f'Error: {parse_result.fault_text}')
            if parse_result.command_class:
                print(f'Command: {parse_result.command_class}')
            if parse_result.fault_token:
                print(f"Faulty token: '{parse_result.fault_token.text}' starting at character #{parse_result.fault_token.start_character_index}")
            if parse_result.list_of_expected_text:
                print(f'Expected: {sorted(parse_result.list_of_expected_text)}')
        else:
            print('Error: Internal error: Unexpected command parse result')

class TabCompleter:
    def __init__(self, context: CommandContext) -> None:
        self._context = context
        self._possible_next_text: Optional[List[str]] = None

        def input_completer(text: str, state: int) -> Optional[str]:
            if state == 0:
                previous_text: str = readline.get_line_buffer()[0: readline.get_begidx()]
                self._possible_next_text = self._try_get_possible_next_text(previous_text, text)

            return self._possible_next_text[state] if self._possible_next_text and state < len(self._possible_next_text) else None

        readline.parse_and_bind("tab: complete")
        readline.set_completer(input_completer)
        readline.set_completer_delims(' ()')

    def _try_get_possible_next_text(self, previous_text: str, text: str) -> Optional[List[str]]:
        tokenise_result: Union[SuccessfulTokenisationResult, FailedTokenisationResult] = tokenise(previous_text)
        if isinstance(tokenise_result, SuccessfulTokenisationResult):
            list_of_expected_next_text: Optional[List[str]] = None
            parse_result: Union[SuccessfulCommandParseResult, FailedCommandParseResult] = parse_command(tokenise_result.list_of_tokens, self._context)
            if isinstance(parse_result, SuccessfulCommandParseResult):
                list_of_expected_next_text = parse_result.list_of_possible_next_text
            elif isinstance(parse_result, FailedCommandParseResult) and \
                (not parse_result.fault_token or (parse_result.fault_token and parse_result.fault_token.end_character_index > readline.get_begidx())):
                    list_of_expected_next_text = parse_result.list_of_expected_text
            if list_of_expected_next_text:
                return [ x + ' ' for x in list_of_expected_next_text if x.startswith(text) ]
        return None

    def shutdown(self) -> None:
        readline.set_completer(None)
