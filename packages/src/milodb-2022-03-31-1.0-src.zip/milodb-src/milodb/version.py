from typing import Optional

MILODB_VERSION: Optional[str] = '1.0'
MILODB_DATE: Optional[str] = '2022-03-31'
