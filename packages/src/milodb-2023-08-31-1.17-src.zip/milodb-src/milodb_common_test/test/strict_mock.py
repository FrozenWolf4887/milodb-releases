# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from abc import ABC
from typing import Any
from unittest.mock import NonCallableMock

class StrictMock(NonCallableMock):
    def __init__(self, interface: type[ABC]) -> None:
        self._mocked_interface: type[ABC] = interface
        super().__init__(spec=[], name=interface.__name__)

    def __getattr__(self, name: str) -> Any:
        if name in dir():
            return super().__getattr__(name)
        if name in dir(self._mocked_interface):
            raise AssertionError(f"Mock interface '{self._mocked_interface.__name__}' unexpected access to '{name}'")
        raise AttributeError(f"Mock interface '{self._mocked_interface.__name__}' has no attribute '{name}'")

    def __setattr__(self, name: str, value: Any) -> None:
        if name == '_mocked_interface':
            object.__setattr__(self, name, value)
        elif name in dir(self._mocked_interface):
            super().__setattr__(name, value)
        else:
            raise AttributeError(f"Mock interface '{self._mocked_interface.__name__}' has no attribute '{name}'")
