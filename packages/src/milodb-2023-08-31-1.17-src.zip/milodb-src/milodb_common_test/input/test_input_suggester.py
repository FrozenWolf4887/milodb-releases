# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
import unittest
from unittest.mock import Mock
from prompt_toolkit.completion import Completion # type: ignore
from milodb_common.command_framework.argument_stream import ArgumentStream
from milodb_common.command_framework.candidate_text import CandidateText
from milodb_common.command_framework.command_constructor import CommandConstructor
from milodb_common.command_framework.i_command import ICommand, ICommandLoader
from milodb_common.command_framework.i_command_factory import ICommandFactory
from milodb_common.command_framework.i_help_info import IHelpInfo
from milodb_common.commands.enums import EnumEx
from milodb_common.input.input_suggester import InputSuggester
from milodb_common.parser.token import Token
from milodb_common.variables.i_user_variables import IUserVariables

class Colour(EnumEx):
    RED = 0
    BLACK = 1
    GREEN = 2
    BLUE = 3

class Food(EnumEx):
    PEACH = 10
    APPLE = 11
    ORANGE = 12
    PEAR = 13

class CompassPrimary(EnumEx):
    NORTH = 20
    EAST = 21
    SOUTH = 22
    WEST = 23

class CompassSecondary(EnumEx):
    EAST = 30
    WEST = 31

list_of_colours: list[str] = Colour.lowercase_names()
list_of_food: list[str] = Food.lowercase_names()
list_of_compass_primary: list[str] = CompassPrimary.lowercase_names()
list_of_compass_secondary: list[str] = CompassSecondary.lowercase_names()

class FakeCommand(ICommand):
    def execute(self) -> None:
        pass

class MockMultiColourCommand(ICommandLoader):
    def load(self, argument_stream: ArgumentStream) -> ICommandLoader.Result:
        ArgumentStream.pop_list(lambda: argument_stream.pop_optional_enum(Colour))
        return ICommandLoader.Result(
            FakeCommand(),
            CandidateText.space_delimited_list(list_of_colours))

class MockSingleFoodCommand(ICommandLoader):
    def load(self, argument_stream: ArgumentStream) -> ICommandLoader.Result:
        argument_stream.pop_enum(Food)
        argument_stream.fail_if_not_empty()
        return ICommandLoader.Result(
            FakeCommand(),
            CandidateText.space_delimited_list(list_of_food))

class MockCompassCommand(ICommandLoader):
    def load(self, argument_stream: ArgumentStream) -> ICommandLoader.Result:
        next_text: list[str] = []

        compass_primary: CompassPrimary = argument_stream.pop_enum(CompassPrimary)
        if compass_primary in {CompassPrimary.NORTH, CompassPrimary.SOUTH}:
            if argument_stream.pop_optional_enum(CompassSecondary):
                argument_stream.fail_if_not_empty()
            else:
                next_text = CompassSecondary.lowercase_names()
        else:
            argument_stream.fail_if_not_empty()
            next_text = CompassSecondary.lowercase_names()

        return ICommandLoader.Result(
            FakeCommand(),
            CandidateText.space_delimited_list(next_text))

class MockFailingCommand(ICommandLoader):
    _exception_on_token_number: int = 0
    _list_of_candidate_text: list[CandidateText] = []

    @classmethod
    def reset(cls) -> None:
        MockFailingCommand._exception_on_token_number = 0
        MockFailingCommand._list_of_candidate_text = []

    @classmethod
    def set_exception_on_token(cls, token_number: int, list_of_candidate_text: list[CandidateText]) -> None:
        MockFailingCommand._exception_on_token_number = token_number
        MockFailingCommand._list_of_candidate_text = list_of_candidate_text

    def load(self, argument_stream: ArgumentStream) -> ICommandLoader.Result:
        token: Token | None = None
        for _ in range(MockFailingCommand._exception_on_token_number):
            token = argument_stream.pop_optional_token()
        raise ICommandLoader.Error('failed', token, MockFailingCommand._list_of_candidate_text)

class MockCommandFactory(ICommandFactory):
    MAP_OF_COMMAND_NAME_TO_OBJECT: dict[str, ICommandLoader] = {
        'colour': MockMultiColourCommand(),
        'food': MockSingleFoodCommand(),
        'compass': MockCompassCommand(),
        'bad': MockFailingCommand()
    }

    LIST_OF_COMMAND_NAMES: list[str] = list(MAP_OF_COMMAND_NAME_TO_OBJECT)

    def get_list_of_command_names(self) -> list[str]:
        return list(MockCommandFactory.MAP_OF_COMMAND_NAME_TO_OBJECT)

    def try_get_command_loader_from_name(self, command_name: str) -> ICommandLoader | None:
        return MockCommandFactory.MAP_OF_COMMAND_NAME_TO_OBJECT.get(command_name)

    def try_get_command_help_from_name(self, command_name: str) -> IHelpInfo | None:
        return None

class TestInputSuggester(unittest.TestCase):
    def setUp(self) -> None:
        MockFailingCommand.reset()

        self.dictionary_of_variables: dict[str, str] = {}
        self.dictionary_of_command_classes: dict[str, type[ICommandLoader]] = {}

        mock_user_variables = Mock(IUserVariables)
        mock_user_variables.try_retrieve = self.dictionary_of_variables.get
        mock_user_variables.get_list_of_names = lambda: list(self.dictionary_of_variables.keys())

        command_factory: MockCommandFactory = MockCommandFactory()
        command_constructor: CommandConstructor = CommandConstructor(command_factory)

        self._input_suggester: InputSuggester = InputSuggester(command_constructor, mock_user_variables)

    def check(self, text_with_placeholders: str, list_of_expected_text: list[str]) -> None:
        text_either_side_of_cursor: list[str] = text_with_placeholders.split('|')
        self.assertEqual(2, len(text_either_side_of_cursor), f"Input text '{text_with_placeholders}' missing or excessive cursor placeholder '|'")

        text_left_of_cursor: str = text_either_side_of_cursor[0]
        text_right_of_cursor: str = text_either_side_of_cursor[1]

        text_either_side_of_insertion_point: list[str] = text_left_of_cursor.split('@')
        self.assertEqual(2, len(text_either_side_of_insertion_point), f"Input text '{text_with_placeholders}' missing or excessive insertion placeholder '@'")

        text_left_of_insertion_point: str = text_either_side_of_insertion_point[0]
        text_right_of_insertion_point: str = text_either_side_of_insertion_point[1]

        text: str = text_left_of_insertion_point + text_right_of_insertion_point + text_right_of_cursor
        insertion_index: int = len(text_left_of_insertion_point)
        cursor_index: int = len(text_left_of_insertion_point) + len(text_right_of_insertion_point)

        list_of_completions: list[Completion] = self._input_suggester.get_possible_completions(text, cursor_index)

        self.assertEqual(len(list_of_expected_text), len(list_of_completions), f'Expected {len(list_of_expected_text)} completions but got {len(list_of_completions)}')

        list_of_delimited_expected_text: list[str] = [text + ' ' for text in list_of_expected_text]

        i: int
        completion: Completion
        for i, completion in enumerate(list_of_completions):
            self.assertEqual(insertion_index - cursor_index, completion.start_position,
                             f'Mismatched relative insertion index for completion #{i}. Expected {insertion_index - cursor_index} but got {completion.start_position}')
            self.assertEqual(list_of_delimited_expected_text[i], completion.text,
                             f"Mismatched completion text for completion #{i}. Expected '{list_of_delimited_expected_text[i]}' but got '{completion.text}'")

    def test_command_name_completion_provides_suggestions(self) -> None:
        self.check('@|', MockCommandFactory.LIST_OF_COMMAND_NAMES)
        self.check('@c|', ['colour', 'compass'])
        self.check('@co|', ['colour', 'compass'])
        self.check('@col|', ['colour'])
        self.check('@c|o', ['colour', 'compass'])
        self.check('@c|ol', ['colour', 'compass'])
        self.check('@co|l', ['colour', 'compass'])
        self.check('@colour|', ['colour'])
        self.check('@|z', MockCommandFactory.LIST_OF_COMMAND_NAMES)
        self.check('@z|', [])
        self.check('@c|zz', ['colour', 'compass'])
        self.check('@col|zz', ['colour'])

    def test_colour_command_suggests_colours(self) -> None:
        self.check('colour @|', list_of_colours)
        self.check('colour @r|', ['red'])
        self.check('colour @red|', ['red'])
        self.check('colour @reds|', [])
        self.check('colour @g|', ['green'])
        self.check('colour @green|', ['green'])
        self.check('colour @greens|', [])
        self.check('colour @b|', ['black', 'blue'])
        self.check('colour @bl|', ['black', 'blue'])
        self.check('colour @blu|', ['blue'])
        self.check('colour @blue|', ['blue'])
        self.check('colour @bluez|', [])
        self.check('colour @|blue', list_of_colours)
        self.check('colour @bl|ue', ['black', 'blue'])
        self.check('colour @bl|uez', ['black', 'blue'])
        self.check('colour @bla|', ['black'])
        self.check('colour @black|', ['black'])
        self.check('colour @blackq|', [])

    def test_colour_command_suggests_colours_for_subsequent_token(self) -> None:
        self.check('colour red @|', ['red', 'black', 'green', 'blue'])
        self.check('colour red @bl|', ['black', 'blue'])
        self.check('colour red @blue|', ['blue'])
        self.check('colour red green blue black @|', ['red', 'black', 'green', 'blue'])

    def test_load_error_provides_suggestions_without_error_token(self) -> None:
        MockFailingCommand.set_exception_on_token(0, [])
        self.check('bad @|', [])
        self.check('bad @|ness', [])
        MockFailingCommand.set_exception_on_token(1, [])
        self.check('bad @ness|', [])
        MockFailingCommand.set_exception_on_token(0, CandidateText.space_delimited_list(['cat', 'dog']))
        self.check('bad @|', ['cat', 'dog'])
        MockFailingCommand.set_exception_on_token(1, CandidateText.space_delimited_list(['cat', 'dog']))
        self.check('bad @d|', ['dog'])
        self.check('bad @d|izzy', ['dog'])

    def test_command_expansion_suggests_primary_compass_directions(self) -> None:
        self.dictionary_of_variables['cmd'] = 'compass'
        self.check('$cmd @|', list_of_compass_primary)
        self.check('$cmd @|zap', list_of_compass_primary)
        self.check('$cmd @n|', ['north'])
        self.check('$cmd @e|', ['east'])
        self.check('$cmd @sout|', ['south'])
        self.check('$cmd @s|zap', ['south'])

    def test_command_expansion_suggests_secondary_compass_directions(self) -> None:
        self.dictionary_of_variables['cmd'] = 'compass'
        self.check('$cmd north @|', list_of_compass_secondary)
        self.check('$cmd north @|zap', list_of_compass_secondary)
        self.check('$cmd south @w|', ['west'])
        self.check('$cmd south @w|zap', ['west'])

    def test_parameter_does_not_suggest_variables_without_prefix(self) -> None:
        self.dictionary_of_variables['tasty'] = 'apple'
        self.dictionary_of_variables['fatty'] = 'avocado'
        self.dictionary_of_variables['sharp'] = 'lemon'
        self.dictionary_of_variables['sauce'] = 'tomato'
        self.check('food @|', list_of_food)
        self.check('food @|zap', list_of_food)
        self.check('food @|$tasty', list_of_food)

    def test_parameter_suggests_variables_with_prefix(self) -> None:
        self.dictionary_of_variables['tasty'] = 'apple'
        self.dictionary_of_variables['fatty'] = 'avocado'
        self.dictionary_of_variables['sharp'] = 'lemon'
        self.dictionary_of_variables['sauce'] = 'tomato'
        list_of_variables: list[str] = [f'${name}' for name in self.dictionary_of_variables]
        self.check('food @$|', list_of_variables)
        self.check('food @$|zap', list_of_variables)
        self.check('food @$s|', ['$sharp', '$sauce'])
        self.check('food @$s|zap', ['$sharp', '$sauce'])

    def test_command_expansion_suggests_secondary_compass_directions_after_expansion(self) -> None:
        self.dictionary_of_variables['primaryDirection'] = 'east'
        self.check('compass $primaryDirection @|', list_of_compass_secondary)
        self.check('compass $primaryDirection @|zap', list_of_compass_secondary)
        self.dictionary_of_variables['primaryDirection'] = 'north'
        self.check('compass $primaryDirection @w|', ['west'])
        self.check('compass $primaryDirection @w|zap', ['west'])
