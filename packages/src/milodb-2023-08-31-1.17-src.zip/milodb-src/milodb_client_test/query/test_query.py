# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
import unittest
from unittest.mock import Mock
from milodb_client.database.tease import Tease
from milodb_client.query.field_match import FieldItemMatch, FieldListMatch, FieldPageListMatch, IFieldMatch
from milodb_client.query.infix_query_parser import InfixError, InfixQueryParser, PostfixQuery
from milodb_client.query.postfix_query_executor import PostfixError, PostfixQueryExecutor, PostfixQueryResult
from milodb_client.query.syntax import get_list_of_field_names, get_list_of_operators, get_list_of_verb_names
from milodb_client.query.tease_match import TeaseMatch
from milodb_common.command_framework.argument_stream import ArgumentStream, ArgumentStreamError
from milodb_common.command_framework.candidate_text import CandidateText
from milodb_common.parser.expanding_token_stream import ExpandingTokenStream
from milodb_common.parser.token import StartEnd, Token
from milodb_common.parser.token_stream import TokenStreamError
from milodb_common_test.commands.error_messages import ErrorMessage

MAX_MATCH_COUNT: int = 1_000_000
FIELD_NAMES: list[str] = get_list_of_field_names()
VERB_NAMES: list[str] = get_list_of_verb_names()
HELP_OPERATORS: list[str] = get_list_of_operators()
BINARY_OPERATORS: list[str] = ['and', 'or']
UNARY_OPERATORS: list[str] = ['not']
TEASE_TYPES: list[str] = ['reg', 'aud', 'eos', 'nyx']

FAKE_THUMBNAIL: str = "https://media.milovana.com/timg/tb_s/73d0969cdbccbf0aa37a5dd2ac1c8962e53ff7a4.jpg"

tease_1: Tease = Tease(
    {
        "aid": 1000,
        "anm": "Miss Minogue",
        "dat": "2019-04-27",
        "rvl": 4.2,
        "sum": "Our problems should be shared.",
        "tgs": ":wonder:wheels-for-feels:with:free:minky:",
        "thm": FAKE_THUMBNAIL,
        "tid": 4801,
        "ttl": "Confide in me",
        "pgs": [ {
            "ref": "chorus-start",
            "txt": "Stick or twist"
            }, {
            "ref": "line2",
            "txt": "What's mine is yours"
            }, {
            "ref": "line3",
            "txt": "Hit or miss"
            }, {
            "ref": "end",
            "txt": "We all have a cross to bear"
            }
        ],
        "typ": 2
    })

tease_2: Tease = Tease(
    {
        "aid": 2345,
        "anm": "Lewis",
        "dat": "2017-02-16",
        "rvl": 3.9,
        "sum": "Alice was beginning to get very tired of sitting by her sister on the bank, and of having nothing to do",
        "tgs": ":rabbit:hatter:alice:the-queen-of-hearts:",
        "thm": FAKE_THUMBNAIL,
        "tid": 5673,
        "ttl": "Alice's Adventures in Wonderland",
        "pgs": [ {
            "ref": "line1",
            "txt": "Alice was not a bit hurt, and she jumped up on to her feet in a moment"
            }, {
            "ref": "line2",
            "txt": "She looked up, but it was all dark overhead; before her was another long passage, and the White Rabbit was still in sight, hurrying down it."
            }, {
            "ref": "line2",
            "txt": 'There was not a moment to be lost: away went Alice like the wind, and was just in time to hear it say, as it turned a corner, "Oh my ears and whiskers, how late it\'s getting!"'
            }, {
            "ref": "line3",
            "txt": "She was close behind it when she turned the corner, but the Rabbit was no longer to be seen"
            }, {
            "ref": "line4",
            "txt": "she found herself in a long, low hall, which was lit up by a row of lamps hanging from the roof."
            }
        ],
        "typ": 0
    })

tease_3: Tease = Tease(
    {
        "aid": 7602,
        "anm": "Scott",
        "dat": "2022-03-13",
        "rvl": 1.8,
        "sum": "In a dystopian world, what will become of us all?",
        "tgs": ":dystopia:orwellian:2022:",
        "thm": FAKE_THUMBNAIL,
        "tid": 7129,
        "ttl": "Twenty Twenty Two",
        "pgs": [ {
            "ref": "intro",
            "txt": "The Author of the Waverley Novels had hitherto proceeded in an unabated course of popularity, and might, in his peculiar district of literature, have been termed L’Enfant Gâté of success."
            }, {
            "ref": "preface",
            "txt": "It was plain, however, that frequent publication must finally wear out the public favour, unless some mode could be devised to give an appearance of novelty to subsequent productions."
            }, {
            "ref": "appendixA",
            "txt": "Scottish manners, Scottish dialect, and Scottish characters of note, being those with which the author was most intimately,"
            }, {
            "ref": "appendixB",
            "txt": "and familiarly acquainted, were the groundwork upon which he had hitherto relied for giving effect to his narrative."
            }
        ],
        "typ": 1
    })

fake_list_of_teases: list[Tease] = [
    tease_1,
    tease_2,
    tease_3
]

def create_fake_tokens(list_of_token_text: list[str]) -> list[Token]:
    list_of_tokens: list[Token] = []
    token_index: int = 0
    token_start_character: int = 0
    for token_text in list_of_token_text:
        token_end_character: int = token_start_character + len(token_text)
        list_of_tokens.append(Token(token_text, token_index, StartEnd(token_start_character, token_end_character), StartEnd(token_start_character, token_end_character), token_text in '()'))
        token_start_character = token_end_character + 1
        token_index += 1
    return list_of_tokens

def is_equal_list_of_indices(left_list_indices: list[IFieldMatch.Indices], right_list_of_indices: list[IFieldMatch.Indices]) -> bool:
    left_indices: IFieldMatch.Indices
    for left_indices in left_list_indices:
        was_match_found: bool = False
        right_indices: IFieldMatch.Indices
        for right_indices in right_list_of_indices:
            was_match_found = left_indices.start_index == right_indices.start_index and left_indices.end_index == right_indices.end_index
            if was_match_found:
                break
        if not was_match_found:
            return False
    return True

def is_equal_field_item_match(left: FieldItemMatch, right: FieldItemMatch) -> bool:
    if left.tease_property == right.tease_property:
        return is_equal_list_of_indices(left.list_of_indices, right.list_of_indices)
    return False

def is_equal_field_list_match(left: FieldListMatch, right: FieldListMatch) -> bool:
    if left.tease_property == right.tease_property and left.index_of_block == right.index_of_block:
        return is_equal_list_of_indices(left.list_of_indices, right.list_of_indices)
    return False

def is_equal_field_page_list_match(left: FieldPageListMatch, right: FieldPageListMatch) -> bool:
    if left.page is right.page and left.index_of_page == right.index_of_page:
        return is_equal_list_of_indices(left.list_of_indices, right.list_of_indices)
    return False

def is_equal_tease_match(left: TeaseMatch, right: TeaseMatch) -> bool:
    if left.tease == right.tease and len(left.list_of_field_matches) == len(right.list_of_field_matches):
        left_field_match: IFieldMatch
        for left_field_match in left.list_of_field_matches:
            was_match_found: bool = False
            right_field_match: IFieldMatch
            for right_field_match in right.list_of_field_matches:
                if isinstance(left_field_match, FieldItemMatch) and isinstance(right_field_match, FieldItemMatch):
                    was_match_found = is_equal_field_item_match(left_field_match, right_field_match)
                elif isinstance(left_field_match, FieldListMatch) and isinstance(right_field_match, FieldListMatch):
                    was_match_found = is_equal_field_list_match(left_field_match, right_field_match)
                elif isinstance(left_field_match, FieldPageListMatch) and isinstance(right_field_match, FieldPageListMatch):
                    was_match_found = is_equal_field_page_list_match(left_field_match, right_field_match)
                if was_match_found:
                    break
            if not was_match_found:
                return False
        return True
    return False

class TestQuery(unittest.TestCase):
    def setUp(self) -> None:
        self.postfix_query: PostfixQuery
        self.list_of_tokens: list[Token] = []
        self.list_of_tease_matches: list[TeaseMatch] = []
        self.exception: (InfixError | ArgumentStreamError | TokenStreamError | PostfixError | None) = None

    def execute(self, list_of_token_text: list[str]) -> None:
        self.list_of_tokens = create_fake_tokens(list_of_token_text)
        mock_token_stream = Mock(ExpandingTokenStream)
        mock_token_stream.next = Mock(side_effect=[*self.list_of_tokens, None])
        argument_stream: ArgumentStream = ArgumentStream(mock_token_stream)
        try:
            self.postfix_query = InfixQueryParser().convert_to_postfix(argument_stream)
        except (InfixError, ArgumentStreamError, TokenStreamError) as ex:
            self.exception = ex
            return
        try:
            result: PostfixQueryResult = PostfixQueryExecutor().execute(fake_list_of_teases, self.postfix_query.query_chain, MAX_MATCH_COUNT)
        except PostfixError as ex:
            self.exception = ex
            return
        self.assertFalse(result.was_max_match_count_reached)
        self.list_of_tease_matches = result.list_of_tease_matches

    def assert_error(self, exception_type: type[(InfixError | ArgumentStreamError | TokenStreamError)], error_message: str, error_token_index: (int | None)) -> None:
        self.assertIsInstance(self.exception, exception_type)
        if isinstance(self.exception, (InfixError, ArgumentStreamError)):
            self.assertEqual(
                error_message, self.exception.message,
                f"Expected error message of '{error_message}' but got '{self.exception.message}'")
            if error_token_index is not None:
                error_token = self.list_of_tokens[error_token_index]
                self.assertIs(
                    error_token, self.exception.fault_token,
                    'Mismatched error token')
            else:
                self.assertIsNone(
                    self.exception.fault_token,
                    "Received an error token when one wasn't expected")
        elif isinstance(self.exception, TokenStreamError):
            self.assertEqual(
                error_message, self.exception.cause_of_fault_text,
                f"Expected error message of '{error_message}' but got '{self.exception.cause_of_fault_text}'")
            if error_token_index is not None:
                error_token = self.list_of_tokens[error_token_index]
                self.assertIs(
                    error_token, self.exception.cause_of_fault_token,
                    'Mismatched error token')
            else:
                self.assertIsNone(
                    self.exception.cause_of_fault_token,
                    "Received an error token when one wasn't expected")

    def assert_successful(self, expected_list_of_tease_matches: list[TeaseMatch]) -> None:
        self.assertIsNone(self.exception)
        if self.exception is None:
            self.assertEqual(
                len(expected_list_of_tease_matches), len(self.list_of_tease_matches),
                f'Resulting tease match list expected to contain {len(expected_list_of_tease_matches)} entries but contains {len(self.list_of_tease_matches)}')

            expected_index: int
            expected_tease_match: TeaseMatch
            for expected_index, expected_tease_match in enumerate(expected_list_of_tease_matches):
                was_match_found: bool = False
                actual_tease_match: TeaseMatch
                for actual_tease_match in self.list_of_tease_matches:
                    was_match_found = is_equal_tease_match(expected_tease_match, actual_tease_match)
                    if was_match_found:
                        break
                if not was_match_found:
                    self.fail(f"No match for expected tease match #{expected_index}")
        else:
            self.fail('Conversion failed when it should have succeeded')

    def assert_candidate_text(self, *expected_lists_of_next_text: list[str] | list[CandidateText] | str | CandidateText| None) -> None:
        actual_list_of_candidate_text: list[CandidateText]
        if isinstance(self.exception, PostfixError):
            actual_list_of_candidate_text = []
        elif self.exception is not None:
            actual_list_of_candidate_text = self.exception.list_of_candidate_text
        else:
            actual_list_of_candidate_text = self.postfix_query.list_of_candidate_text

        expected_list_of_candidate_text: list[CandidateText] = _collect_lists_of_candidate_text(*expected_lists_of_next_text)

        actual_candidate_text_block: str = '\n'.join(str(candidate_text) for candidate_text in sorted(actual_list_of_candidate_text, key=lambda ct: ct.text)) + '\n'
        expected_candidate_text_block: str = '\n'.join(str(candidate_text) for candidate_text in sorted(expected_list_of_candidate_text, key=lambda ct: ct.text)) + '\n'
        self.assertEqual(expected_candidate_text_block, actual_candidate_text_block)

def _collect_lists_of_candidate_text(*lists_of_candidate_text: list[str] | list[CandidateText] | str | CandidateText| None) -> list[CandidateText]:
    list_of_candidate_text: list[CandidateText] = []
    for arg in lists_of_candidate_text:
        if isinstance(arg, list):
            item: str | CandidateText
            for item in arg:
                if isinstance(item, str):
                    list_of_candidate_text.append(CandidateText(item, '' if item in '()' else ' '))
                else:
                    list_of_candidate_text.append(item)
        elif isinstance(arg, str):
            list_of_candidate_text.append(CandidateText(arg, '' if arg in '()' else ' '))
        elif arg is not None:
            list_of_candidate_text.append(arg)
    return list_of_candidate_text

class TestInvalidInputs(TestQuery):
    def test_empty_input_yields_error(self) -> None:
        self.execute([])
        self.assert_error(InfixError, 'Unexpected end of input when expecting a query', None)

    def test_invalid_query_yields_error(self) -> None:
        self.execute(['mango'])
        self.assert_error(InfixError, 'Unknown field name or operator', 0)
        self.assert_candidate_text(FIELD_NAMES, UNARY_OPERATORS, '(')

class TestTitle(TestQuery):
    field = 'title'
    verb_list = ['is', 'contains', 'matches']

    def test_fails_without_verb(self) -> None:
        self.execute([self.field])
        self.assert_error(ArgumentStreamError, ErrorMessage.INSUFFICIENT, None)
        self.assert_candidate_text(self.verb_list)

class TestTitleIs(TestQuery):
    field = 'title'
    verb = 'is'

    def test_fails_without_argument(self) -> None:
        self.execute([self.field, self.verb])
        self.assert_error(ArgumentStreamError, ErrorMessage.INSUFFICIENT_EXPECTING_TEXT, None)

    def test_matches_nothing(self) -> None:
        self.execute([self.field, self.verb, 'mango'])
        self.assert_successful([])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_matches_whole(self) -> None:
        self.execute([self.field, self.verb, 'confiDE in me'])
        matched_field_1: IFieldMatch = FieldItemMatch(Tease.title, [IFieldMatch.Indices(0, 13)])
        matched_tease_1: TeaseMatch = TeaseMatch(None, tease_1, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_matches_plain_text_only(self) -> None:
        self.execute([self.field, self.verb, 'confiDE.in me'])
        self.assert_successful([])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_matches_whole_text_only(self) -> None:
        self.execute([self.field, self.verb, 'fide'])
        self.assert_successful([])
        self.assert_candidate_text(BINARY_OPERATORS)

class TestTitleContains(TestQuery):
    field = 'title'
    verb = 'contains'

    def test_fails_without_argument(self) -> None:
        self.execute([self.field, self.verb])
        self.assert_error(ArgumentStreamError, ErrorMessage.INSUFFICIENT_EXPECTING_TEXT, None)

    def test_matches_nothing(self) -> None:
        self.execute([self.field, self.verb, 'mango'])
        self.assert_successful([])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_matches_part(self) -> None:
        self.execute([self.field, self.verb, 'fIDe'])
        matched_field_1: IFieldMatch = FieldItemMatch(Tease.title, [IFieldMatch.Indices(3, 7)])
        matched_tease_1: TeaseMatch = TeaseMatch(None, tease_1, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_matches_multiple_parts(self) -> None:
        self.execute([self.field, self.verb, 'wen'])
        matched_field_1: IFieldMatch = FieldItemMatch(Tease.title, [IFieldMatch.Indices(1, 4), IFieldMatch.Indices(8, 11)])
        matched_tease_1: TeaseMatch = TeaseMatch(None, tease_3, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_matches_plain_text_only(self) -> None:
        self.execute([self.field, self.verb, 'fi.e'])
        self.assert_successful([])
        self.assert_candidate_text(BINARY_OPERATORS)

class TestTitleMatches(TestQuery):
    field = 'title'
    verb = 'matches'

    def test_fails_without_argument(self) -> None:
        self.execute([self.field, self.verb])
        self.assert_error(ArgumentStreamError, ErrorMessage.INSUFFICIENT_EXPECTING_REGEX, None)
        self.assert_candidate_text(None)

    def test_matches_nothing(self) -> None:
        self.execute([self.field, self.verb, 'mango'])
        self.assert_successful([])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_matches_part(self) -> None:
        self.execute([self.field, self.verb, 'fIDe'])
        matched_field_1: IFieldMatch = FieldItemMatch(Tease.title, [IFieldMatch.Indices(3, 7)])
        matched_tease_1: TeaseMatch = TeaseMatch(None, tease_1, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_matches_regex(self) -> None:
        self.execute([self.field, self.verb, 'on.+in me'])
        matched_field_1: IFieldMatch = FieldItemMatch(Tease.title, [IFieldMatch.Indices(1, 13)])
        matched_tease_1: TeaseMatch = TeaseMatch(None, tease_1, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_matches_multiple_regex(self) -> None:
        self.execute([self.field, self.verb, 't.+?ty'])
        matched_field_1: IFieldMatch = FieldItemMatch(Tease.title, [IFieldMatch.Indices(0, 6), IFieldMatch.Indices(7, 13)])
        matched_tease_1: TeaseMatch = TeaseMatch(None, tease_3, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_fails_with_invalid_regex(self) -> None:
        self.execute([self.field, self.verb, 'on(in'])
        self.assert_error(ArgumentStreamError, 'Invalid regular expression: missing ), unterminated subpattern at position 2', 2)
        self.assert_candidate_text(None)

class TestRating(TestQuery):
    field = 'rating'
    verb_list = ['=', '>', '<', '>=', '<=']

    def test_fails_without_verb(self) -> None:
        self.execute([self.field])
        self.assert_error(ArgumentStreamError, ErrorMessage.INSUFFICIENT, None)
        self.assert_candidate_text(self.verb_list)

    def test_fails_without_argument(self) -> None:
        for verb in self.verb_list:
            with self.subTest(verb=verb):
                self.execute([self.field, verb])
                self.assert_error(ArgumentStreamError, ErrorMessage.INSUFFICIENT_EXPECTING_UNSIGNED_DECIMAL, None)
                self.assert_candidate_text(None)

    def test_fails_with_non_float_argument(self) -> None:
        for verb in self.verb_list:
            with self.subTest(verb=verb):
                self.execute([self.field, verb, 'frog'])
                self.assert_error(ArgumentStreamError, ErrorMessage.EXPECTING_UNSIGNED_DECIMAL, 2)
                self.assert_candidate_text(None)

    def test_fails_with_negative_argument(self) -> None:
        for verb in self.verb_list:
            with self.subTest(verb=verb):
                for value in ('-1', '-0.1'):
                    with self.subTest(value=value):
                        self.execute([self.field, verb, value])
                        self.assert_error(ArgumentStreamError, ErrorMessage.EXPECTING_UNSIGNED_DECIMAL, 2)
                        self.assert_candidate_text(None)

    def test_gt_matches_nothing(self) -> None:
        self.execute([self.field, '>', '4.2'])
        self.assert_successful([])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_gt_matches_one_item(self) -> None:
        self.execute([self.field, '>', '3.9'])
        matched_field_1: IFieldMatch = FieldItemMatch(Tease.rating_value, [IFieldMatch.Indices.whole_match()])
        matched_tease_1: TeaseMatch = TeaseMatch(None, tease_1, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_gt_matches_two_items(self) -> None:
        self.execute([self.field, '>', '1.8'])
        matched_field_1: IFieldMatch = FieldItemMatch(Tease.rating_value, [IFieldMatch.Indices.whole_match()])
        matched_tease_1: TeaseMatch = TeaseMatch(None, tease_1, [matched_field_1])
        matched_tease_2: TeaseMatch = TeaseMatch(None, tease_2, [matched_field_1])
        self.assert_successful([matched_tease_1, matched_tease_2])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_gt_matches_all_items(self) -> None:
        self.execute([self.field, '>', '0'])
        matched_field_1: IFieldMatch = FieldItemMatch(Tease.rating_value, [IFieldMatch.Indices.whole_match()])
        matched_tease_1: TeaseMatch = TeaseMatch(None, tease_1, [matched_field_1])
        matched_tease_2: TeaseMatch = TeaseMatch(None, tease_2, [matched_field_1])
        matched_tease_3: TeaseMatch = TeaseMatch(None, tease_3, [matched_field_1])
        self.assert_successful([matched_tease_1, matched_tease_2, matched_tease_3])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_ge_matches_nothing(self) -> None:
        self.execute([self.field, '>=', '4.3'])
        self.assert_successful([])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_ge_matches_one_item(self) -> None:
        self.execute([self.field, '>=', '4.2'])
        matched_field_1: IFieldMatch = FieldItemMatch(Tease.rating_value, [IFieldMatch.Indices.whole_match()])
        matched_tease_1: TeaseMatch = TeaseMatch(None, tease_1, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_ge_matches_two_items(self) -> None:
        self.execute([self.field, '>=', '3.9'])
        matched_field_1: IFieldMatch = FieldItemMatch(Tease.rating_value, [IFieldMatch.Indices.whole_match()])
        matched_tease_1: TeaseMatch = TeaseMatch(None, tease_1, [matched_field_1])
        matched_tease_2: TeaseMatch = TeaseMatch(None, tease_2, [matched_field_1])
        self.assert_successful([matched_tease_1, matched_tease_2])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_ge_matches_all_items(self) -> None:
        self.execute([self.field, '>=', '0'])
        matched_field_1: IFieldMatch = FieldItemMatch(Tease.rating_value, [IFieldMatch.Indices.whole_match()])
        matched_tease_1: TeaseMatch = TeaseMatch(None, tease_1, [matched_field_1])
        matched_tease_2: TeaseMatch = TeaseMatch(None, tease_2, [matched_field_1])
        matched_tease_3: TeaseMatch = TeaseMatch(None, tease_3, [matched_field_1])
        self.assert_successful([matched_tease_1, matched_tease_2, matched_tease_3])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_lt_matches_nothing(self) -> None:
        self.execute([self.field, '<', '1.8'])
        self.assert_successful([])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_lt_matches_one_item(self) -> None:
        self.execute([self.field, '<', '3.9'])
        matched_field_1: IFieldMatch = FieldItemMatch(Tease.rating_value, [IFieldMatch.Indices.whole_match()])
        matched_tease_1: TeaseMatch = TeaseMatch(None, tease_3, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_lt_matches_two_items(self) -> None:
        self.execute([self.field, '<', '4.2'])
        matched_field_1: IFieldMatch = FieldItemMatch(Tease.rating_value, [IFieldMatch.Indices.whole_match()])
        matched_tease_1: TeaseMatch = TeaseMatch(None, tease_2, [matched_field_1])
        matched_tease_2: TeaseMatch = TeaseMatch(None, tease_3, [matched_field_1])
        self.assert_successful([matched_tease_1, matched_tease_2])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_le_matches_nothing(self) -> None:
        self.execute([self.field, '<=', '1.7'])
        self.assert_successful([])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_le_matches_one_item(self) -> None:
        self.execute([self.field, '<=', '1.8'])
        matched_field_1: IFieldMatch = FieldItemMatch(Tease.rating_value, [IFieldMatch.Indices.whole_match()])
        matched_tease_1: TeaseMatch = TeaseMatch(None, tease_3, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_le_matches_two_items(self) -> None:
        self.execute([self.field, '<=', '3.9'])
        matched_field_1: IFieldMatch = FieldItemMatch(Tease.rating_value, [IFieldMatch.Indices.whole_match()])
        matched_tease_1: TeaseMatch = TeaseMatch(None, tease_2, [matched_field_1])
        matched_tease_2: TeaseMatch = TeaseMatch(None, tease_3, [matched_field_1])
        self.assert_successful([matched_tease_1, matched_tease_2])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_eq_matches_nothing(self) -> None:
        self.execute([self.field, '=', '3.1'])
        self.assert_successful([])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_eq_matches_one_item(self) -> None:
        self.execute([self.field, '=', '3.9'])
        matched_field_1: IFieldMatch = FieldItemMatch(Tease.rating_value, [IFieldMatch.Indices.whole_match()])
        matched_tease_1: TeaseMatch = TeaseMatch(None, tease_2, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_candidate_text(BINARY_OPERATORS)

class TestDate(TestQuery):
    field = 'date'
    verb_list = ['=', '>', '<', '>=', '<=']

    def test_fails_without_verb(self) -> None:
        self.execute([self.field])
        self.assert_error(ArgumentStreamError, ErrorMessage.INSUFFICIENT, None)
        self.assert_candidate_text(self.verb_list)

    def test_fails_without_argument(self) -> None:
        for verb in self.verb_list:
            with self.subTest(verb=verb):
                self.execute([self.field, verb])
                self.assert_error(ArgumentStreamError, ErrorMessage.INSUFFICIENT_EXPECTING_DATE, None)
                self.assert_candidate_text(None)

    def test_fails_with_non_float_argument(self) -> None:
        for verb in self.verb_list:
            with self.subTest(verb=verb):
                self.execute([self.field, verb, 'frog'])
                self.assert_error(ArgumentStreamError, ErrorMessage.INVALID_DATE, 2)
                self.assert_candidate_text(None)

    def test_gt_matches_nothing(self) -> None:
        self.execute([self.field, '>', '2022-03-13'])
        self.assert_successful([])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_gt_matches_one_item(self) -> None:
        self.execute([self.field, '>', '2022-03-12'])
        matched_field_1: IFieldMatch = FieldItemMatch(Tease.date, [IFieldMatch.Indices.whole_match()])
        matched_tease_1: TeaseMatch = TeaseMatch(None, tease_3, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_gt_matches_two_items(self) -> None:
        self.execute([self.field, '>', '2019-04-26'])
        matched_field_1: IFieldMatch = FieldItemMatch(Tease.date, [IFieldMatch.Indices.whole_match()])
        matched_tease_1: TeaseMatch = TeaseMatch(None, tease_1, [matched_field_1])
        matched_tease_2: TeaseMatch = TeaseMatch(None, tease_3, [matched_field_1])
        self.assert_successful([matched_tease_1, matched_tease_2])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_ge_matches_nothing(self) -> None:
        self.execute([self.field, '>=', '2022-03-14'])
        self.assert_successful([])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_ge_matches_one_item(self) -> None:
        self.execute([self.field, '>=', '2022-03-13'])
        matched_field_1: IFieldMatch = FieldItemMatch(Tease.date, [IFieldMatch.Indices.whole_match()])
        matched_tease_1: TeaseMatch = TeaseMatch(None, tease_3, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_ge_matches_two_items(self) -> None:
        self.execute([self.field, '>=', '2019-04-27'])
        matched_field_1: IFieldMatch = FieldItemMatch(Tease.date, [IFieldMatch.Indices.whole_match()])
        matched_tease_1: TeaseMatch = TeaseMatch(None, tease_1, [matched_field_1])
        matched_tease_2: TeaseMatch = TeaseMatch(None, tease_3, [matched_field_1])
        self.assert_successful([matched_tease_1, matched_tease_2])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_lt_matches_nothing(self) -> None:
        self.execute([self.field, '<', '2017-02-16'])
        self.assert_successful([])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_lt_matches_one_item(self) -> None:
        self.execute([self.field, '<', '2017-02-17'])
        matched_field_1: IFieldMatch = FieldItemMatch(Tease.date, [IFieldMatch.Indices.whole_match()])
        matched_tease_1: TeaseMatch = TeaseMatch(None, tease_2, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_lt_matches_two_items(self) -> None:
        self.execute([self.field, '<', '2019-04-28'])
        matched_field_1: IFieldMatch = FieldItemMatch(Tease.date, [IFieldMatch.Indices.whole_match()])
        matched_tease_1: TeaseMatch = TeaseMatch(None, tease_2, [matched_field_1])
        matched_tease_2: TeaseMatch = TeaseMatch(None, tease_1, [matched_field_1])
        self.assert_successful([matched_tease_1, matched_tease_2])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_le_matches_nothing(self) -> None:
        self.execute([self.field, '<=', '2017-02-15'])
        self.assert_successful([])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_le_matches_one_item(self) -> None:
        self.execute([self.field, '<=', '2017-02-16'])
        matched_field_1: IFieldMatch = FieldItemMatch(Tease.date, [IFieldMatch.Indices.whole_match()])
        matched_tease_1: TeaseMatch = TeaseMatch(None, tease_2, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_le_matches_two_items(self) -> None:
        self.execute([self.field, '<=', '2019-04-27'])
        matched_field_1: IFieldMatch = FieldItemMatch(Tease.date, [IFieldMatch.Indices.whole_match()])
        matched_tease_1: TeaseMatch = TeaseMatch(None, tease_2, [matched_field_1])
        matched_tease_2: TeaseMatch = TeaseMatch(None, tease_1, [matched_field_1])
        self.assert_successful([matched_tease_1, matched_tease_2])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_eq_matches_nothing(self) -> None:
        self.execute([self.field, '=', '2018-07-02'])
        self.assert_successful([])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_eq_matches_one_item(self) -> None:
        self.execute([self.field, '=', '2019-04-27'])
        matched_field_1: IFieldMatch = FieldItemMatch(Tease.date, [IFieldMatch.Indices.whole_match()])
        matched_tease_1: TeaseMatch = TeaseMatch(None, tease_1, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_candidate_text(BINARY_OPERATORS)

class TestTag(TestQuery):
    field = 'tag'
    verb_list = ['is', 'contains', 'matches']

    def test_fails_without_verb(self) -> None:
        self.execute([self.field])
        self.assert_error(ArgumentStreamError, ErrorMessage.INSUFFICIENT, None)
        self.assert_candidate_text(self.verb_list)

class TestTagIs(TestQuery):
    field = 'tag'
    verb = 'is'

    def test_fails_without_argument(self) -> None:
        self.execute([self.field, self.verb])
        self.assert_error(ArgumentStreamError, ErrorMessage.INSUFFICIENT_EXPECTING_TEXT, None)

    def test_matches_nothing(self) -> None:
        self.execute([self.field, self.verb, 'mango'])
        self.assert_successful([])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_matches_whole(self) -> None:
        self.execute([self.field, self.verb, 'Alice'])
        matched_field_1: IFieldMatch = FieldListMatch(Tease.list_of_tags, 2, [IFieldMatch.Indices(0, 5)])
        matched_tease_1: TeaseMatch = TeaseMatch(None, tease_2, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_matches_plain_text_only(self) -> None:
        self.execute([self.field, self.verb, 'Al.ce'])
        self.assert_successful([])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_matches_whole_text_only(self) -> None:
        self.execute([self.field, self.verb, 'topia'])
        self.assert_successful([])
        self.assert_candidate_text(BINARY_OPERATORS)

class TestTagContains(TestQuery):
    field = 'tag'
    verb = 'contains'

    def test_fails_without_argument(self) -> None:
        self.execute([self.field, self.verb])
        self.assert_error(ArgumentStreamError, ErrorMessage.INSUFFICIENT_EXPECTING_TEXT, None)

    def test_matches_nothing(self) -> None:
        self.execute([self.field, self.verb, 'mango'])
        self.assert_successful([])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_matches_part(self) -> None:
        self.execute([self.field, self.verb, 'abbi'])
        matched_field_1: IFieldMatch = FieldListMatch(Tease.list_of_tags, 0, [IFieldMatch.Indices(1, 5)])
        matched_tease_1: TeaseMatch = TeaseMatch(None, tease_2, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_matches_multiple_part(self) -> None:
        self.execute([self.field, self.verb, 'ee'])
        matched_field_1: IFieldMatch = FieldListMatch(Tease.list_of_tags, 1, [IFieldMatch.Indices(2, 4), IFieldMatch.Indices(12, 14)])
        matched_field_2: IFieldMatch = FieldListMatch(Tease.list_of_tags, 3, [IFieldMatch.Indices(2, 4)])
        matched_field_3: IFieldMatch = FieldListMatch(Tease.list_of_tags, 3, [IFieldMatch.Indices(6, 8)])
        matched_tease_1: TeaseMatch = TeaseMatch(None, tease_1, [matched_field_1, matched_field_2])
        matched_tease_2: TeaseMatch = TeaseMatch(None, tease_2, [matched_field_3])
        self.assert_successful([matched_tease_1, matched_tease_2])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_matches_plain_text_only(self) -> None:
        self.execute([self.field, self.verb, 'ali.e'])
        self.assert_successful([])
        self.assert_candidate_text(BINARY_OPERATORS)

class TestTagMatches(TestQuery):
    field = 'tag'
    verb = 'matches'

    def test_fails_without_argument(self) -> None:
        self.execute([self.field, self.verb])
        self.assert_error(ArgumentStreamError, ErrorMessage.INSUFFICIENT_EXPECTING_REGEX, None)
        self.assert_candidate_text(None)

    def test_matches_nothing(self) -> None:
        self.execute([self.field, self.verb, 'mango'])
        self.assert_successful([])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_matches_part(self) -> None:
        self.execute([self.field, self.verb, 'fOR'])
        matched_field_1: IFieldMatch = FieldListMatch(Tease.list_of_tags, 1, [IFieldMatch.Indices(7, 10)])
        matched_tease_1: TeaseMatch = TeaseMatch(None, tease_1, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_matches_regex(self) -> None:
        self.execute([self.field, self.verb, 'queen.+heart'])
        matched_field_1: IFieldMatch = FieldListMatch(Tease.list_of_tags, 3, [IFieldMatch.Indices(4, 18)])
        matched_tease_1: TeaseMatch = TeaseMatch(None, tease_2, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_matches_multiple_regex(self) -> None:
        self.execute([self.field, self.verb, 'e{2}'])
        matched_field_1: IFieldMatch = FieldListMatch(Tease.list_of_tags, 1, [IFieldMatch.Indices(2, 4), IFieldMatch.Indices(12, 14)])
        matched_field_2: IFieldMatch = FieldListMatch(Tease.list_of_tags, 3, [IFieldMatch.Indices(2, 4)])
        matched_field_3: IFieldMatch = FieldListMatch(Tease.list_of_tags, 3, [IFieldMatch.Indices(6, 8)])
        matched_tease_1: TeaseMatch = TeaseMatch(None, tease_1, [matched_field_1, matched_field_2])
        matched_tease_2: TeaseMatch = TeaseMatch(None, tease_2, [matched_field_3])
        self.assert_successful([matched_tease_1, matched_tease_2])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_fails_with_invalid_regex(self) -> None:
        self.execute([self.field, self.verb, 'on(in'])
        self.assert_error(ArgumentStreamError, 'Invalid regular expression: missing ), unterminated subpattern at position 2', 2)
        self.assert_candidate_text(None)

class TestTypeIs(TestQuery):
    field = 'type'
    verb = 'is'

    def test_fails_without_argument(self) -> None:
        self.execute([self.field, self.verb])
        self.assert_error(ArgumentStreamError, ErrorMessage.INSUFFICIENT, None)
        self.assert_candidate_text(TEASE_TYPES)

    def test_fails_with_invalid_type(self) -> None:
        self.execute([self.field, self.verb, 'mango'])
        self.assert_error(ArgumentStreamError, ErrorMessage.INVALID_ENUM, 2)
        self.assert_candidate_text(TEASE_TYPES)

    def test_matches_entry(self) -> None:
        self.execute([self.field, self.verb, 'reg'])
        matched_field_1: IFieldMatch = FieldItemMatch(Tease.type, [IFieldMatch.Indices.whole_match()])
        matched_tease_1: TeaseMatch = TeaseMatch(None, tease_2, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_candidate_text(BINARY_OPERATORS)

class TestTextContains(TestQuery):
    field = 'text'
    verb = 'contains'

    def test_fails_without_argument(self) -> None:
        self.execute([self.field, self.verb])
        self.assert_error(ArgumentStreamError, ErrorMessage.INSUFFICIENT_EXPECTING_TEXT, None)

    def test_matches_nothing(self) -> None:
        self.execute([self.field, self.verb, 'mango'])
        self.assert_successful([])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_matches_one_part_in_one_block_of_one_tease(self) -> None:
        self.execute([self.field, self.verb, 'herself'])
        matched_field_1: IFieldMatch = FieldPageListMatch(tease_2.list_of_pages()[4], 4, [IFieldMatch.Indices(10, 17)])
        matched_tease_1: TeaseMatch = TeaseMatch(None, tease_2, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_matches_one_parts_in_multiple_blocks_of_one_tease(self) -> None:
        self.execute([self.field, self.verb, 'hitherto'])
        matched_field_1: IFieldMatch = FieldPageListMatch(tease_3.list_of_pages()[0], 0, [IFieldMatch.Indices(38, 46)])
        matched_field_2: IFieldMatch = FieldPageListMatch(tease_3.list_of_pages()[3], 3, [IFieldMatch.Indices(65, 73)])
        matched_tease_1: TeaseMatch = TeaseMatch(None, tease_3, [matched_field_1, matched_field_2])
        self.assert_successful([matched_tease_1])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_matches_multiple_parts_in_one_block_of_one_tease(self) -> None:
        self.execute([self.field, self.verb, 'public'])
        matched_field_1: IFieldMatch = FieldPageListMatch(tease_3.list_of_pages()[1], 1, [IFieldMatch.Indices(37, 43), IFieldMatch.Indices(75, 81)])
        matched_tease_1: TeaseMatch = TeaseMatch(None, tease_3, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_matches_one_part_in_one_block_of_multiple_teases(self) -> None:
        self.execute([self.field, self.verb, 'have'])
        matched_field_1: IFieldMatch = FieldPageListMatch(tease_1.list_of_pages()[3], 3, [IFieldMatch.Indices(7, 11)])
        matched_field_2: IFieldMatch = FieldPageListMatch(tease_3.list_of_pages()[0], 0, [IFieldMatch.Indices(145, 149)])
        matched_tease_1: TeaseMatch = TeaseMatch(None, tease_1, [matched_field_1])
        matched_tease_2: TeaseMatch = TeaseMatch(None, tease_3, [matched_field_2])
        self.assert_successful([matched_tease_1, matched_tease_2])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_matches_one_part_in_some_blocks_of_multiple_teases(self) -> None:
        self.execute([self.field, self.verb, 'which'])
        matched_field_1: IFieldMatch = FieldPageListMatch(tease_2.list_of_pages()[4], 4, [IFieldMatch.Indices(39, 44)])
        matched_field_2: IFieldMatch = FieldPageListMatch(tease_3.list_of_pages()[2], 2, [IFieldMatch.Indices(86, 91)])
        matched_field_3: IFieldMatch = FieldPageListMatch(tease_3.list_of_pages()[3], 3, [IFieldMatch.Indices(52, 57)])
        matched_tease_1: TeaseMatch = TeaseMatch(None, tease_2, [matched_field_1])
        matched_tease_2: TeaseMatch = TeaseMatch(None, tease_3, [matched_field_2, matched_field_3])
        self.assert_successful([matched_tease_1, matched_tease_2])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_matches_regardless_of_case(self) -> None:
        self.execute([self.field, self.verb, 'auTHor'])
        matched_field_1: IFieldMatch = FieldPageListMatch(tease_3.list_of_pages()[0], 0, [IFieldMatch.Indices(4, 10)])
        matched_field_2: IFieldMatch = FieldPageListMatch(tease_3.list_of_pages()[2], 2, [IFieldMatch.Indices(96, 102)])
        matched_tease_1: TeaseMatch = TeaseMatch(None, tease_3, [matched_field_1, matched_field_2])
        self.assert_successful([matched_tease_1])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_matches_plain_text_only(self) -> None:
        self.execute([self.field, self.verb, 'pub.ic'])
        self.assert_successful([])
        self.assert_candidate_text(BINARY_OPERATORS)

class TestTextMatches(TestQuery):
    field = 'text'
    verb = 'matches'

    def test_fails_without_argument(self) -> None:
        self.execute([self.field, self.verb])
        self.assert_error(ArgumentStreamError, ErrorMessage.INSUFFICIENT_EXPECTING_REGEX, None)

    def test_matches_nothing(self) -> None:
        self.execute([self.field, self.verb, 'mango'])
        self.assert_successful([])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_matches_one_part_in_one_block_of_one_tease(self) -> None:
        self.execute([self.field, self.verb, 'her.elf'])
        matched_field_1: IFieldMatch = FieldPageListMatch(tease_2.list_of_pages()[4], 4, [IFieldMatch.Indices(10, 17)])
        matched_tease_1: TeaseMatch = TeaseMatch(None, tease_2, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_matches_one_parts_in_multiple_blocks_of_one_tease(self) -> None:
        self.execute([self.field, self.verb, 'hi[th]{2}erto'])
        matched_field_1: IFieldMatch = FieldPageListMatch(tease_3.list_of_pages()[0], 0, [IFieldMatch.Indices(38, 46)])
        matched_field_2: IFieldMatch = FieldPageListMatch(tease_3.list_of_pages()[3], 3, [IFieldMatch.Indices(65, 73)])
        matched_tease_1: TeaseMatch = TeaseMatch(None, tease_3, [matched_field_1, matched_field_2])
        self.assert_successful([matched_tease_1])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_matches_multiple_parts_in_one_block_of_one_tease(self) -> None:
        self.execute([self.field, self.verb, 'p[a-z]blic'])
        matched_field_1: IFieldMatch = FieldPageListMatch(tease_3.list_of_pages()[1], 1, [IFieldMatch.Indices(37, 43), IFieldMatch.Indices(75, 81)])
        matched_tease_1: TeaseMatch = TeaseMatch(None, tease_3, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_matches_one_part_in_one_block_of_multiple_teases(self) -> None:
        self.execute([self.field, self.verb, 'ha[^z]e'])
        matched_field_1: IFieldMatch = FieldPageListMatch(tease_1.list_of_pages()[3], 3, [IFieldMatch.Indices(7, 11)])
        matched_field_2: IFieldMatch = FieldPageListMatch(tease_3.list_of_pages()[0], 0, [IFieldMatch.Indices(145, 149)])
        matched_tease_1: TeaseMatch = TeaseMatch(None, tease_1, [matched_field_1])
        matched_tease_2: TeaseMatch = TeaseMatch(None, tease_3, [matched_field_2])
        self.assert_successful([matched_tease_1, matched_tease_2])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_matches_one_part_in_some_blocks_of_multiple_teases(self) -> None:
        self.execute([self.field, self.verb, 'which|witch'])
        matched_field_1: IFieldMatch = FieldPageListMatch(tease_2.list_of_pages()[4], 4, [IFieldMatch.Indices(39, 44)])
        matched_field_2: IFieldMatch = FieldPageListMatch(tease_3.list_of_pages()[2], 2, [IFieldMatch.Indices(86, 91)])
        matched_field_3: IFieldMatch = FieldPageListMatch(tease_3.list_of_pages()[3], 3, [IFieldMatch.Indices(52, 57)])
        matched_tease_1: TeaseMatch = TeaseMatch(None, tease_2, [matched_field_1])
        matched_tease_2: TeaseMatch = TeaseMatch(None, tease_3, [matched_field_2, matched_field_3])
        self.assert_successful([matched_tease_1, matched_tease_2])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_matches_regardless_of_case(self) -> None:
        self.execute([self.field, self.verb, 'auTHo[A-Z]'])
        matched_field_1: IFieldMatch = FieldPageListMatch(tease_3.list_of_pages()[0], 0, [IFieldMatch.Indices(4, 10)])
        matched_field_2: IFieldMatch = FieldPageListMatch(tease_3.list_of_pages()[2], 2, [IFieldMatch.Indices(96, 102)])
        matched_tease_1: TeaseMatch = TeaseMatch(None, tease_3, [matched_field_1, matched_field_2])
        self.assert_successful([matched_tease_1])
        self.assert_candidate_text(BINARY_OPERATORS)

class TestAndOperator(TestQuery):
    def test_matches_one_part_in_some_blocks_of_multiple_teases(self) -> None:
        self.execute(['text', 'contains', 'which', 'and', 'teaseId', '=', '5673'])
        matched_field_1: IFieldMatch = FieldItemMatch(Tease.tease_id, [IFieldMatch.Indices.whole_match()])
        matched_field_2: IFieldMatch = FieldPageListMatch(tease_2.list_of_pages()[4], 4, [IFieldMatch.Indices(39, 44)])
        matched_tease_1: TeaseMatch = TeaseMatch(None, tease_2, [matched_field_1, matched_field_2])
        self.assert_successful([matched_tease_1])
        self.assert_candidate_text(BINARY_OPERATORS)
