# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from unittest import TestCase
from milodb_client.commands.count_words import count_words

class TestCountWords(TestCase):
    def check(self, expected_word_count: int, text: str) -> None:
        word_count: int = count_words(text)
        self.assertEqual(expected_word_count, word_count)

    def test_empty_text_has_zero_words(self) -> None:
        self.check(0, '')

    def test_single_character_is_one_word(self) -> None:
        self.check(1, 't')

    def test_multiple_characters_are_one_word(self) -> None:
        self.check(1, 'foo')
        self.check(1, 'hello')
        self.check(1, 'something')

    def test_non_spaces_are_conjoined_as_a_word(self) -> None:
        self.check(1, '123')
        self.check(1, 'he_1llo')
        self.check(1, '!"£$%^567so\'@#~;me_thing')

    def test_a_space_splits_words(self) -> None:
        self.check(2, 'hello world')
        self.check(2, 'hello\rworld')
        self.check(2, 'hello\nworld')
        self.check(2, 'hello\tworld')
        self.check(2, 'hello\fworld')
        self.check(4, 'this is\rsomething\nelse')

    def test_multiple_spaces_splits_words(self) -> None:
        self.check(2, 'hello   world')
        self.check(4, 'this\r\ris\n\nsomething\t\telse')

    def test_multiple_different_spaces_splits_words(self) -> None:
        self.check(2, 'hello \r\n  \fworld')
        self.check(4, 'this\r\nis\n\t\nsomething\t\felse')

    def test_leading_space_is_ignored(self) -> None:
        self.check(2, ' hello world')
        self.check(4, '  this is something else')
        self.check(4, ' \r\nthis is something else')

    def test_trailing_space_is_ignored(self) -> None:
        self.check(2, 'hello world ')
        self.check(4, 'this is something else\r\n')
        self.check(4, 'this is something else \t')

    def test_leading_and_trailing_space_is_ignored(self) -> None:
        self.check(2, ' hello world ')
        self.check(4, '\t \fthis is something else\r\n')
        self.check(4, '  this is something else\t')
