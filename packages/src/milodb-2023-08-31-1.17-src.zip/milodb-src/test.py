#!/usr/bin/env python3
# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0

import sys
if sys.version_info >= (3, 10):
    import os
    from typing import NoReturn
    from unittest import TestCase, TestLoader, TestResult, TestSuite
else:
    print("Python version 3.10 or greater required")
    print("Actual version is " + sys.version)
    sys.exit(1)

LIST_OF_TEST_PACKAGES: tuple[str, ...] = ('milodb_admin_test', 'milodb_client_test', 'milodb_common_test')

def _test_package(package_name: str) -> bool:
    print(f"** Running tests from '\x1b[33m{package_name}\x1b[0m'\n*")

    test_suite: TestSuite = TestLoader().discover(start_dir=package_name, top_level_dir='.', pattern='test_*.py')
    test_result: TestResult = TestResult()
    test_suite.run(test_result)
    if test_result.wasSuccessful():
        print(f'\x1b[32mPASS\x1b[0m: {test_result.testsRun} tests ran successfully\n')
        return True

    failed_test: tuple[TestCase, str]
    for failed_test in test_result.errors + test_result.failures:
        test_case: TestCase = failed_test[0]
        test_failure_text: str = failed_test[1]
        print(80 * '=')
        print(f'\x1b[35;1m{test_case}\x1b[0m')
        print(80 * '-')
        print(test_failure_text, end='')
    print(80 * '-')
    print(f'\x1b[31;1mFAIL\x1b[0m: {test_result.testsRun} tests run of which {len(test_result.errors)} errored and {len(test_result.failures)} failed\n')

    return False

def test_all() -> bool:
    result: bool = True
    package_name: str
    for package_name in LIST_OF_TEST_PACKAGES:
        if os.path.isdir(package_name):
            if not _test_package(package_name):
                result = False
        else:
            print(f"** Skipped tests from '\x1b[33m{package_name}\x1b[0m'\n*")
    return result

def _is_debugger_active() -> bool:
    return hasattr(sys, 'gettrace') and sys.gettrace() is not None

def main() -> NoReturn:
    exit_code: int = 0
    if not test_all() and not _is_debugger_active():
        exit_code = 1
    sys.exit(exit_code)

if __name__ == "__main__":
    main()
