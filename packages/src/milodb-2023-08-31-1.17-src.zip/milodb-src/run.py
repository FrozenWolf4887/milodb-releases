#!/usr/bin/env python3
# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0

import sys
if sys.version_info >= (3, 10):
    from milodb_client.main import Main
else:
    print("Python version 3.10 or greater required")
    print("Actual version is " + sys.version)
    sys.exit(1)

if __name__ == "__main__":
    autoexec: bool = not set(sys.argv).intersection(['-n', '--no-autoexec'])
    Main().run(autoexec)
