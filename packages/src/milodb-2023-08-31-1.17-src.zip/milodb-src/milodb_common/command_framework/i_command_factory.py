# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from abc import ABC, abstractmethod
from milodb_common.command_framework.i_command import ICommandLoader
from milodb_common.command_framework.i_help_info import IHelpInfo

class ICommandFactory(ABC):
    @abstractmethod
    def get_list_of_command_names(self) -> list[str]:
        pass

    @abstractmethod
    def try_get_command_loader_from_name(self, command_name: str) -> ICommandLoader | None:
        pass

    @abstractmethod
    def try_get_command_help_from_name(self, command_name: str) -> IHelpInfo | None:
        pass
