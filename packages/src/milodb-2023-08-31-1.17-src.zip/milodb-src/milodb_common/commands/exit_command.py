# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from milodb_common.command_framework.argument_stream import ArgumentStream
from milodb_common.command_framework.i_command import ICommand, ICommandLoader
from milodb_common.command_framework.i_help_info import IHelpInfo
from milodb_common.command_framework.quit_flag import QuitFlag

class Executor(ICommand):
    def __init__(self, quit_flag: QuitFlag) -> None:
        self._quit_flag: QuitFlag = quit_flag

    def execute(self) -> None:
        self._quit_flag.set()

class Loader(ICommandLoader):
    def __init__(self, quit_flag: QuitFlag) -> None:
        self._quit_flag: QuitFlag = quit_flag

    def load(self, argument_stream: ArgumentStream) -> ICommandLoader.Result:
        argument_stream.fail_if_not_empty()
        return ICommandLoader.Result(Executor(self._quit_flag), [])

class Help(IHelpInfo):
    def get_one_line_summary(self) -> str:
        return "Exits the application"

    def get_detailed_summary(self) -> str:
        return (
            "Arguments: none\n"
            "Exits the application.\n"
            "Example:\r"
            "  > \texit\n"
        )
