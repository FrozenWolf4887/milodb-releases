# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from enum import Enum
from typing import Optional
from typing_extensions import Self

class EnumEx(Enum):
    @classmethod
    def lowercase_names(cls) -> list[str]:
        return [enum.name.lower() for enum in cls]

    @classmethod
    def values(cls) -> list[str]:
        return [enum.value for enum in cls]

    @classmethod
    def lowercase_values(cls) -> list[str]:
        return [enum.value.lower() for enum in cls]

    @classmethod
    def try_lookup_caseless(cls, name: str) -> Optional[Self]: # pylint: disable=consider-alternative-union-syntax
        name = name.lower()
        enum: EnumEx
        for enum in cls:
            if enum.name.lower() == name:
                return enum
        return None

class OnOrOff(EnumEx):
    ON = True
    OFF = False
