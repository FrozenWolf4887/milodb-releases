# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from abc import ABC, abstractmethod

class IDefaultInputText(ABC):
    @abstractmethod
    def set(self, value: str) -> None:
        pass

    @abstractmethod
    def clear(self) -> None:
        pass

    @abstractmethod
    def get(self) -> str:
        pass

class DefaultInputText(IDefaultInputText):
    def __init__(self) -> None:
        self._text: str = ''

    def set(self, value: str) -> None:
        self._text = value

    def clear(self) -> None:
        self._text = ''

    def get(self) -> str:
        return self._text
