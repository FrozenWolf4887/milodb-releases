# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from milodb_common.command_framework.i_command_constructor import ICommandConstructor
from milodb_common.command_framework.quit_flag import QuitFlag
from milodb_common.input.process import process_user_input
from milodb_common.variables.i_user_variables import IUserVariables

def run_autoexec(filepath: str, command_constructor: ICommandConstructor, user_variables: IUserVariables, quit_flag: QuitFlag, ignore_if_not_found: bool = True) -> None:
    autoexec_lines: list[str] | None = None

    try:
        with open(filepath, 'rt', encoding='utf-8') as file:
            autoexec_lines = [line.rstrip('\n') for line in file.readlines()]
    except FileNotFoundError:
        if not ignore_if_not_found:
            print(f"Error: File '{filepath}' not found")
    except IOError as ex:
        print(f"Error: File '{filepath}' read error: {ex}")

    if autoexec_lines:
        print(f"Running commands from '{filepath}':")
        line: str
        for line in autoexec_lines:
            if quit_flag:
                break
            if line:
                print(f'> {line}')
                process_user_input(line, command_constructor, user_variables)
