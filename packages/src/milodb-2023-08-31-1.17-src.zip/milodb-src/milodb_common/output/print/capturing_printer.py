# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from milodb_common.output.print.i_printer import IPrinter
from milodb_common.output.string_builder import StringBuilder

class CapturingPrinter(IPrinter):
    def __init__(self) -> None:
        self._text: StringBuilder = StringBuilder()

    def writeln(self, text: str | None = None) -> None:
        if text:
            self._text.put(text)
        self._text.put('\n')

    def clear(self) -> None:
        self._text.clear()

    def __str__(self) -> str:
        return self.text

    @property
    def text(self) -> str:
        return self._text.get_text()
