# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from milodb_common.output.print.i_printer import IPrinter

class StdoutPrinter(IPrinter):
    def writeln(self, text: str | None = None) -> None:
        if text:
            print(text)
        else:
            print()
