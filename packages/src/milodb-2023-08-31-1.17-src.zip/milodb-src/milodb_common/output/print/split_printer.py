# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from milodb_common.output.print.i_printer import IPrinter

class SplitPrinter(IPrinter):
    def __init__(self, list_of_printers: list[IPrinter]) -> None:
        self._list_of_printers: list[IPrinter] = list_of_printers

    def writeln(self, text: str | None = None) -> None:
        printer: IPrinter
        for printer in self._list_of_printers:
            printer.writeln(text)
