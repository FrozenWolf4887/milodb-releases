# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from milodb_common.output.print.redirectable_printer import RedirectablePrinter

class NormalPrinter(RedirectablePrinter):
    def writeln(self, text: str | None = None) -> None:
        self._target_printer.writeln(text)
