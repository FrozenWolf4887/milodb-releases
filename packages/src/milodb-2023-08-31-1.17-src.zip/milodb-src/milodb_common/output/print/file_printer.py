# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from typing import IO
from milodb_common.output.print.i_printer import IPrinter

class FilePrinter(IPrinter):
    def __init__(self, file: IO[str]) -> None:
        self._file: IO[str] = file

    def writeln(self, text: str | None = None) -> None:
        if text:
            self._file.write(text)
        self._file.write('\n')
