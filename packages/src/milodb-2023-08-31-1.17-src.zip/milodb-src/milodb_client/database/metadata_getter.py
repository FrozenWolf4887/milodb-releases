# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
import datetime
from collections.abc import Callable
from typing import Any, TypeVar

_KeyT = TypeVar('_KeyT')
_ValueT = TypeVar('_ValueT')
_NumberT = TypeVar('_NumberT', int, float)

class MetadataGetter:
    def __init__(self, metadata: dict[str, Any], exception_class: type[Exception]):
        self._metadata: dict[str, Any] = metadata
        self._exception_class: type[Exception] = exception_class

    def sub_metadata(self, metadata: dict[str, Any]) -> 'MetadataGetter':
        return MetadataGetter(metadata, self._exception_class)

    def try_get_str(self, key: str) -> str | None:
        value: Any = self._metadata.get(key)
        if value is None:
            return None
        if isinstance(value, str):
            return value
        raise self._exception_class(f"Key '{key}' is not a string")

    def try_get_int(self, key: str, min_value: int | None, max_value: int | None) -> int | None:
        value: Any = self._metadata.get(key)
        if value is None:
            return None
        if not isinstance(value, int):
            raise self._exception_class(f"Key '{key}' is not an integer")
        self._verify_number_range(key, value, min_value, max_value)
        return value

    def try_get_float(self, key: str, min_value: float | None, max_value: float | None) -> float | None:
        value: Any = self._metadata.get(key)
        if value is None:
            return None
        if not isinstance(value, int | float):
            raise self._exception_class(f"Key '{key}' is not a decimal")
        value = float(value)
        self._verify_number_range(key, value, min_value, max_value)
        return value

    def try_get_date(self, key: str) -> datetime.date | None:
        value: Any = self._metadata.get(key)
        if value is None:
            return None
        if not isinstance(value, str):
            raise self._exception_class(f"Key '{key}' is not a string")
        try:
            return datetime.date.fromisoformat(value)
        except ValueError as ex:
            raise self._exception_class(f"Key '{key}' value '{value}' is not a valid ISO date") from ex

    def try_get_bool(self, key: str) -> bool | None:
        value: Any = self._metadata.get(key)
        if value is None or isinstance(value, bool):
            return value
        bool_value: bool | None = None
        if isinstance(value, str):
            bool_value = _MAP_OF_BOOLEAN_TEXT_TO_VALUE.get(value.lower())
        if bool_value is None:
            raise self._exception_class(f"Key '{key}' value '{value}' is not a valid boolean")
        return bool_value

    def try_get_dict_value(self, key: str, dict_key_getter: Callable[[str], _KeyT | None], dictionary: dict[_KeyT, _ValueT]) -> _ValueT | None:
        dict_key: _KeyT | None = dict_key_getter(key)
        if dict_key is None:
            return None
        value: _ValueT | None = dictionary.get(dict_key)
        if value is None:
            raise self._exception_class(f"Key '{key}' value '{dict_key}' is not a known value")
        return value

    def get_str(self, key: str) -> str:
        value: str | None = self.try_get_str(key)
        if value is None:
            raise self._exception_class(f"Key '{key}' is missing")
        return value

    def get_str_or_blank(self, key: str) -> str:
        value: str | None = self.try_get_str(key)
        return '' if value is None else value

    def get_dict_list_or_empty(self, key: str) -> list[dict[Any, Any]]:
        value: Any = self._metadata.get(key)
        if value is None:
            return []
        if not isinstance(value, list):
            raise self._exception_class(f"Key '{key}' is not a list")
        list_of_values: list[Any] = value
        list_of_dict: list[dict[Any, Any]] = []
        index: int
        for index, value in enumerate(list_of_values):
            if not isinstance(value, dict):
                raise self._exception_class(f"Key '{key}' list entry #{index} is not a dictionary")
            list_of_dict.append(value)
        return list_of_dict

    def get_str_list_or_empty(self, key: str) -> list[str]:
        value: Any = self._metadata.get(key)
        if value is None:
            return []
        if not isinstance(value, list):
            raise self._exception_class(f"Key '{key}' is not a list")
        list_of_values: list[Any] = value
        list_of_strings: list[str] = []
        index: int
        for index, value in enumerate(list_of_values):
            if not isinstance(value, str):
                raise self._exception_class(f"Key '{key}' list entry #{index} is not a string")
            list_of_strings.append(value)
        return list_of_strings

    def get_int(self, key: str, min_value: int | None, max_value: int | None, default_value_if_none: int | None) -> int:
        value: int | None = self.try_get_int(key, min_value, max_value)
        if value is None:
            if default_value_if_none is not None:
                return default_value_if_none
            raise self._exception_class(f"Key '{key}' is missing")
        return value

    def get_float(self, key: str, min_value: float | None, max_value: float | None, default_value_if_none: float | None) -> float:
        value: float | None = self.try_get_float(key, min_value, max_value)
        if value is None:
            if default_value_if_none is not None:
                return default_value_if_none
            raise self._exception_class(f"Key '{key}' is missing")
        return value

    def get_date(self, key: str) -> datetime.date:
        value: datetime.date | None = self.try_get_date(key)
        if value is None:
            raise self._exception_class(f"Key '{key}' is missing")
        return value

    def get_bool_or_default(self, key: str, default: bool) -> bool:
        value: bool | None = self.try_get_bool(key)
        return default if value is None else value

    def get_dict_value(self, key: str, dict_key_getter: Callable[[str], _KeyT], dictionary: dict[_KeyT, _ValueT]) -> _ValueT:
        dict_key: _KeyT = dict_key_getter(key)
        value: _ValueT | None = dictionary.get(dict_key)
        if value is None:
            raise self._exception_class(f"Key '{key}' value '{dict_key}' is not recognised")
        return value

    def _verify_number_range(self, key: str, value: _NumberT, min_value: _NumberT | None, max_value: _NumberT | None) -> None:
        if (min_value is not None and value < min_value) or (max_value is not None and value > max_value):
            if min_value is not None:
                if max_value is not None:
                    raise self._exception_class(f"Key '{key}' value '{value}' is out of range '{min_value}' to '{max_value}'")
                raise self._exception_class(f"Key '{key}' value '{value}' should be '{min_value}' or greater")
            raise self._exception_class(f"Key '{key}' value '{value}' should be '{max_value}' or less")

_MAP_OF_BOOLEAN_TEXT_TO_VALUE: dict[str, bool] = {
    'true': True,
    'false': False
}
