# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
import os
import sys
from typing import Any

_root_path: str = os.path.dirname(__file__)
if getattr(sys, 'frozen', False) and hasattr(sys, '_MEIPASS'):
    some_path: Any = getattr(sys, '_MEIPASS')
    if isinstance(some_path, str):
        _root_path = some_path

def resource_path(relative_path: str) -> str:
    return os.path.join(_root_path, 'resources', relative_path)
