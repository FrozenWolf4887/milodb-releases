# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
import time
from typing import Any

class PrintTimedActivity:
    def __init__(self, prefix_text: str, suffix_text: str = ': ', seconds_width: int = 1) -> None:
        self._prefix_text: str = prefix_text
        self._suffix_text: str = suffix_text
        self._seconds_width: int = seconds_width
        self._start_millis: int = 0

    def __enter__(self) -> None:
        print(f"{self._prefix_text}", end='', flush=True)
        self._start_millis = _now_millis()

    def __exit__(self, exc_type: Any, exc_value: Any, traceback: Any) -> None:
        duration_millis: int = _now_millis() - self._start_millis
        was_aborted: bool = exc_type or exc_value or traceback
        print(f"{self._suffix_text}{duration_millis // 1000:>{self._seconds_width}}.{duration_millis % 1000:>03}s{' (aborted)' if was_aborted else ''}")

def _now_millis() -> int:
    return int(round(time.time() * 1000))
