# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
import os
import webbrowser
from milodb_client.config.commands_config import ILaunchConfig
from milodb_client.config.config_schema import CommandLaunchOption
from milodb_common.output.print.i_printer import IPrinter

def launch(launch_config: ILaunchConfig, filepath: str | None, url: str | None, normal_printer: IPrinter, error_printer: IPrinter) -> None:
    if launch_config.launch_option is CommandLaunchOption.DEFAULT:
        if filepath:
            normal_printer.writeln(f"Opening '{filepath}' in default web browser")
            webbrowser.open(filepath)
        elif url:
            normal_printer.writeln(f"Opening '{url}' in default web browser")
            webbrowser.open(url)
    elif launch_config.launch_option is CommandLaunchOption.CUSTOM:
        expanded_command: str = launch_config.custom_launch_command
        if filepath:
            expanded_command = expanded_command.replace('$p', filepath)
        if url:
            expanded_command = expanded_command.replace('$u', url)
        normal_printer.writeln(f"Launching: {launch_config.custom_launch_command}")
        normal_printer.writeln(f"       as: {expanded_command}")
        os.system(expanded_command)
    elif launch_config.launch_option is not CommandLaunchOption.NONE:
        error_printer.writeln(f"Unsupported launch option '{launch_config.launch_option.name}'")
