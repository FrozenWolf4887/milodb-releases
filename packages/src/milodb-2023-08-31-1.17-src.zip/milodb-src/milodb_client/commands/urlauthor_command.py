# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from milodb_client.commands.database_support import try_get_tease_id_from_ref_id
from milodb_client.database.tease import Tease
from milodb_client.output.support import get_url_of_author
from milodb_client.query.tease_match import TeaseMatch
from milodb_common.command_framework.argument_stream import ArgumentStream
from milodb_common.command_framework.i_command import ICommand, ICommandLoader
from milodb_common.command_framework.i_help_info import IHelpInfo
from milodb_common.command_framework.ref_id import AuthorId, RefId
from milodb_common.output.print.i_printer import IPrinter

class Loader(ICommandLoader):
    def __init__(self, list_of_teases: list[Tease], list_of_tease_matches: list[TeaseMatch], normal_printer: IPrinter, error_printer: IPrinter) -> None:
        self._list_of_teases: list[Tease] = list_of_teases
        self._list_of_tease_matches: list[TeaseMatch] = list_of_tease_matches
        self._normal_printer: IPrinter = normal_printer
        self._error_printer: IPrinter = error_printer

    def load(self, argument_stream: ArgumentStream) -> ICommandLoader.Result:
        list_of_ref_ids: list[RefId] = ArgumentStream.pop_minimum_list(1, argument_stream.pop_ref_id, argument_stream.pop_optional_ref_id)
        return ICommandLoader.Result(Executor(list_of_ref_ids, self._list_of_teases, self._list_of_tease_matches, self._normal_printer, self._error_printer), [])

class Executor(ICommand):
    def __init__(self, list_of_ref_ids: list[RefId], list_of_teases: list[Tease], list_of_tease_matches: list[TeaseMatch], normal_printer: IPrinter, error_printer: IPrinter) -> None:
        self._list_of_ref_ids: list[RefId] = list_of_ref_ids
        self._list_of_teases: list[Tease] = list_of_teases
        self._list_of_tease_matches: list[TeaseMatch] = list_of_tease_matches
        self._normal_printer: IPrinter = normal_printer
        self._error_printer: IPrinter = error_printer

    def execute(self) -> None:
        ref_id: RefId
        for ref_id in self._list_of_ref_ids:
            if isinstance(ref_id, AuthorId):
                author_url: str = get_url_of_author(ref_id.author_id)
                self._normal_printer.writeln(author_url)
            else:
                tease_match: TeaseMatch | None = try_get_tease_id_from_ref_id(self._list_of_teases, self._list_of_tease_matches, ref_id, self._error_printer)
                if tease_match:
                    if tease_match.tease.has_author():
                        author_url_of_tease = get_url_of_author(tease_match.tease.author_id())
                        self._normal_printer.writeln(author_url_of_tease)
                    else:
                        self._error_printer.writeln(f"Tease id '{tease_match.tease.tease_id()}' has no known author")

class Help(IHelpInfo):
    def get_one_line_summary(self) -> str:
        return "Displays the URL of some author's profiles"

    def get_detailed_summary(self) -> str:
        return (
            "Arguments: <list of RefIds>\n"
            "This command is often used with the copy command to copy the displayed URL to"
            " the clipboard.\n"
            "RefIds can be an index into the list of matches such as '3', a teaseId such as"
            " '#38664', or an authorId such as '@43937'.\n"
            "Example:\r"
            "  \tDisplay the URL of an author's profile by index in the match list\r"
            "  > \turlauthor 3\r"
            "Example:\r"
            "  \tDisplay the URL of an author's profile for a specific teaseId\r"
            "  > \turlauthor #16830\r"
            "Example:\r"
            "  \tDisplay the URL of an author's profile by specific authorId\r"
            "  > \turlauthor @43937\n"
            "See also:\r"
            "  \tcopy, url, open, openauthor\n"
        )
