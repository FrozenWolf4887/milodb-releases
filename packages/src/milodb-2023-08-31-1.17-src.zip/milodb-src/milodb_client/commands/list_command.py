# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from milodb_client.commands.database_support import try_create_list_of_tease_matches_from_ref_ids
from milodb_client.database.tease import Tease
from milodb_client.output.format.i_formatter_factory import IFormatterCreator
from milodb_client.query.tease_match import TeaseMatch
from milodb_common.command_framework.argument_stream import ArgumentStream
from milodb_common.command_framework.i_command import ICommand, ICommandLoader
from milodb_common.command_framework.i_help_info import IHelpInfo
from milodb_common.command_framework.ref_id import RefId
from milodb_common.output.print.i_printer import IPrinter

class Loader(ICommandLoader):
    def __init__(self, list_of_teases: list[Tease], list_of_tease_matches: list[TeaseMatch], formatter_creator: IFormatterCreator, normal_printer: IPrinter, error_printer: IPrinter) -> None:
        self._list_of_teases: list[Tease] = list_of_teases
        self._list_of_tease_matches: list[TeaseMatch] = list_of_tease_matches
        self._formatter_creator: IFormatterCreator = formatter_creator
        self._normal_printer: IPrinter = normal_printer
        self._error_printer: IPrinter = error_printer

    def load(self, argument_stream: ArgumentStream) -> ICommandLoader.Result:
        list_of_ref_ids: list[RefId] = ArgumentStream.pop_list(argument_stream.pop_optional_ref_id)
        return ICommandLoader.Result(
                Executor(
                    list_of_ref_ids, self._list_of_teases,
                    self._list_of_tease_matches,
                    self._formatter_creator,
                    self._normal_printer,
                    self._error_printer), [])

class Executor(ICommand):
    def __init__(self, list_of_ref_ids: list[RefId], list_of_teases: list[Tease], list_of_tease_matches: list[TeaseMatch], formatter_creator: IFormatterCreator, normal_printer: IPrinter, error_printer: IPrinter) -> None:
        self._list_of_ref_ids: list[RefId] = list_of_ref_ids
        self._list_of_teases: list[Tease] = list_of_teases
        self._list_of_tease_matches: list[TeaseMatch] = list_of_tease_matches
        self._formatter_creator: IFormatterCreator = formatter_creator
        self._normal_printer: IPrinter = normal_printer
        self._error_printer: IPrinter = error_printer

    def execute(self) -> None:
        list_of_tease_matches: list[TeaseMatch] | None = None
        if self._list_of_ref_ids:
            list_of_tease_matches = try_create_list_of_tease_matches_from_ref_ids(self._list_of_teases, self._list_of_tease_matches, self._list_of_ref_ids, self._error_printer)
        else:
            list_of_tease_matches = self._list_of_tease_matches

        if list_of_tease_matches:
            self._formatter_creator.create(self._normal_printer).print_list_of_teases(list_of_tease_matches)
        else:
            self._error_printer.writeln("No teases available to list")

class Help(IHelpInfo):
    def get_one_line_summary(self) -> str:
        return "Lists the current results, one per line"

    def get_detailed_summary(self) -> str:
        return (
            "Arguments: [list of RefIds]\n"
            "The formatting used in the list can be controlled with the format command.\n"
            "When used without arguments, all teases that were found from the last query are"
            " included. When one or more RefIds are specified, only those teases are included.\n"
            "RefIds can be an index into the list of matches such as '3', a teaseId such as"
            " '#38664', or an authorId such as '@43937'.\n"
            "The field shown as *n (e.g. *12) indicates how many field matches were made with"
            " the query to provide a guide to the possible relevance of that tease.\n"
            "Matching fields may be highlighted which can be controlled with the highlight"
            " command.\n"
            "Example:\r"
            "  \tList the results of the last query\r"
            "  > \tlist\r"
            "Example:\r"
            "  \tList some matched teases by index\r"
            "  > \tlist 3 7\r"
            "Example:\r"
            "  \tList some specific teaseIds\r"
            "  > \tlist #16830 #1465 #38664\r"
            "Example:\r"
            "  \tList teases for a specific authorId\r"
            "  > \tlist @43937\n"
            "See also:\r"
            "  \tformat, highlight, summary, show, sort\n"
        )
