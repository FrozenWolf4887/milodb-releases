# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from dataclasses import dataclass
from typing import Any
import pyclip # type: ignore
from milodb_common.command_framework.argument_stream import ArgumentStream
from milodb_common.command_framework.candidate_text import CandidateText
from milodb_common.command_framework.i_command import ICommand, ICommandLoader
from milodb_common.command_framework.i_command_constructor import ICommandConstructor
from milodb_common.command_framework.i_help_info import IHelpInfo
from milodb_common.output.print.capturing_printer import CapturingPrinter
from milodb_common.output.print.i_printer import IPrinter, IRedirectablePrinter
from milodb_common.output.print.split_printer import SplitPrinter

class Loader(ICommandLoader):
    def __init__(self, command_constructor: ICommandConstructor, list_of_printers: list[IRedirectablePrinter]) -> None:
        self._command_constructor: ICommandConstructor = command_constructor
        self._list_of_printers: list[IRedirectablePrinter] = list_of_printers

    def load(self, argument_stream: ArgumentStream) -> ICommandLoader.Result:
        construct_result: ICommandConstructor.ConstructResult = self._command_constructor.try_construct(argument_stream)
        if isinstance(construct_result, ICommandConstructor.SuccessfulResult):
            return ICommandLoader.Result(
                Executor(construct_result.command, self._list_of_printers),
                construct_result.list_of_candidate_text)
        if isinstance(construct_result, ICommandConstructor.EmptyInputResult):
            raise ICommandLoader.Error(
                'Expecting a following command', None, CandidateText.space_delimited_list(construct_result.list_of_command_names))
        raise ICommandConstructor.DelegateError(construct_result)

class Executor(ICommand):
    def __init__(self, delegate_command: ICommand, list_of_printers: list[IRedirectablePrinter]) -> None:
        self._delegate_command: ICommand = delegate_command
        self._list_of_printers: list[IRedirectablePrinter] = list_of_printers

    def execute(self) -> None:
        with _Capture(self._list_of_printers):
            self._delegate_command.execute()

@dataclass
class _RedirectedPrinter:
    printer: IRedirectablePrinter
    previous_target: IPrinter

class _Capture:
    def __init__(self, list_of_printers: list[IRedirectablePrinter]) -> None:
        self._list_of_printers: list[IRedirectablePrinter] = list_of_printers
        self._list_of_redirected_printers: list[_RedirectedPrinter]
        self._capturing_printer: CapturingPrinter

    def __enter__(self) -> None:
        self._list_of_redirected_printers = []
        self._capturing_printer = CapturingPrinter()
        printer: IRedirectablePrinter
        for printer in self._list_of_printers:
            current_printer_target: IPrinter = printer.get_target_printer()
            self._list_of_redirected_printers.append(_RedirectedPrinter(printer, current_printer_target))
            printer.set_target_printer(SplitPrinter([current_printer_target, self._capturing_printer]))

    def __exit__(self, exc_type: Any, exc_value: Any, traceback: Any) -> None:
        redirected_printer: _RedirectedPrinter
        for redirected_printer in self._list_of_redirected_printers:
            redirected_printer.printer.set_target_printer(redirected_printer.previous_target)
        try:
            pyclip.copy(self._capturing_printer.text.rstrip()) # type: ignore
        except pyclip.ClipboardSetupException as ex:
            print(f'Error: Unable to copy to clipboard: {ex}')

    @property
    def text(self) -> str:
        return self._capturing_printer.text

class Help(IHelpInfo):
    def get_one_line_summary(self) -> str:
        return "Copies the output of the subsequent command to the clipboard"

    def get_detailed_summary(self) -> str:
        return (
            "Arguments: <subsequent command...>\n"
            "The output of the subsequent command is copied to the clipboard in the currently"
            " selected format.\n"
            "Example:\r"
            "  \tList the current query results and copy the list to the clipboard\r"
            "  > \tcopy list\n"
            "Example:\r"
            "  \tCopy the url of the author of match #3 to the clipboard\r"
            "  > \tcopy urlauthor 3\n"
            "See also:\r"
            "  \tformat, ellipsis, highlight\n"
        )
