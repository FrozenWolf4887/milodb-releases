# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from milodb_client.output.format.i_formatter_factory import IFormatterCreator, IFormatterFactory
from milodb_common.command_framework.argument_stream import ArgumentStream
from milodb_common.command_framework.candidate_text import CandidateText
from milodb_common.command_framework.i_command import ICommand, ICommandLoader
from milodb_common.command_framework.i_help_info import IHelpInfo
from milodb_common.datum.ref_datum import RefDatum
from milodb_common.output.print.i_printer import IPrinter

class Loader(ICommandLoader):
    def __init__(self, ref_formatter_creator: RefDatum[IFormatterCreator], formatter_factory: IFormatterFactory, normal_printer: IPrinter) -> None:
        self._ref_formatter_creator: RefDatum[IFormatterCreator] = ref_formatter_creator
        self._formatter_factory: IFormatterFactory = formatter_factory
        self._normal_printer: IPrinter = normal_printer

    def load(self, argument_stream: ArgumentStream) -> ICommandLoader.Result:
        new_formatter_creator: IFormatterCreator | None = argument_stream.pop_optional_dict_value(self._formatter_factory.map_of_name_to_formatter_creator)
        if new_formatter_creator is not None:
            argument_stream.fail_if_not_empty()
            return ICommandLoader.Result(ExecutorChangeFormat(new_formatter_creator, self._ref_formatter_creator, self._normal_printer), [])
        return ICommandLoader.Result(
            ExecutorPrintCurrentFormat(
                self._ref_formatter_creator.get().get_name(), self._formatter_factory.get_list_of_formatter_names(), self._normal_printer),
                CandidateText.space_delimited_list(self._formatter_factory.get_list_of_formatter_names()))

class ExecutorPrintCurrentFormat(ICommand):
    def __init__(self, current_formatter_name: str, list_of_formatter_names: list[str], normal_printer: IPrinter) -> None:
        self._current_formatter_name: str = current_formatter_name
        self._list_of_formatter_names: list[str] = list_of_formatter_names
        self._normal_printer: IPrinter = normal_printer

    def execute(self) -> None:
        self._normal_printer.writeln(f"Current format is '{self._current_formatter_name}'")
        self._normal_printer.writeln(f"Available formats are {self._list_of_formatter_names}")

class ExecutorChangeFormat(ICommand):
    def __init__(self, new_formatter_creator: IFormatterCreator, ref_formatter_creator: RefDatum[IFormatterCreator], normal_printer: IPrinter) -> None:
        self._new_formatter_creator: IFormatterCreator = new_formatter_creator
        self._ref_formatter_creator: RefDatum[IFormatterCreator] = ref_formatter_creator
        self._normal_printer: IPrinter = normal_printer

    def execute(self) -> None:
        self._ref_formatter_creator.set(self._new_formatter_creator)
        self._normal_printer.writeln(f"Changed format to '{self._new_formatter_creator.get_name()}'")

class Help(IHelpInfo):
    def __init__(self, list_of_formatter_names: list[str]) -> None:
        self._list_of_formatter_names: list[str] = list_of_formatter_names

    def get_one_line_summary(self) -> str:
        return "Sets the formatting used in the output of commands"

    def get_detailed_summary(self) -> str:
        return (
            f"Arguments: [{'|'.join(self._list_of_formatter_names)}]\n"
            "Changes the output format that is produced by commands such as list, summary,"
            " and show. Some of the formats are more suitable for copy-pasting into another"
            " application that supports that format; 'bbcode' for example is suitable to be"
            " pasted into the Milovana forums.\n"
            "When used without arguments, the current setting is shown.\n"
            "Example:\r"
            "  \tSelect the bbcode output format\r"
            "  > \tformat bbcode\r"
            "Example:\r"
            "  \tShow the current setting\r"
            "  > \tformat\n"
            "See also:\r"
            "  \tlist, summary, show, ellipsis, highlight\n"
        )
