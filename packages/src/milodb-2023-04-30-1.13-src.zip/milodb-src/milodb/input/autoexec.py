# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from milodb.command_framework.command_loader import CommandLoader
from milodb.command_framework.i_command_factory import ICommandFactory
from milodb.command_framework.quit_flag import QuitFlag
from milodb.i_user_variables import IUserVariables
from milodb.input.process import process_user_input

def run_autoexec(filepath: str, command_factory: ICommandFactory, user_variables: IUserVariables, quit_flag: QuitFlag) -> None:
    autoexec_lines: (list[str] | None) = None

    try:
        with open(filepath, 'rt', encoding='utf-8') as file:
            autoexec_lines = [line.rstrip('\n') for line in file.readlines()]
    except IOError:
        pass

    if autoexec_lines:
        command_loader: CommandLoader = CommandLoader(command_factory)
        print(f"Running commands from '{filepath}':")
        line: str
        for line in autoexec_lines:
            if quit_flag:
                break
            if line:
                print(f'> {line}')
                process_user_input(line, command_loader, user_variables)
