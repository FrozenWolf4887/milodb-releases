# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from milodb.command_framework.argument_stream import ArgumentStream
from milodb.command_framework.i_command_loader import FailedLoadResult, ICommandLoader, LoadResult, SuccessfulLoadResult
from milodb.i_user_variables import IUserVariables
from milodb.parser.expanding_token_stream import ExpandingTokenStream

def process_user_input(user_input: str, command_loader: ICommandLoader, user_variables: IUserVariables) -> None:
    token_stream: ExpandingTokenStream = ExpandingTokenStream(user_input, user_variables)
    argument_stream: ArgumentStream = ArgumentStream(token_stream)
    load_result: LoadResult = command_loader.try_load(argument_stream)
    if isinstance(load_result, SuccessfulLoadResult):
        print()
        load_result.command.execute()
        print()
    elif isinstance(load_result, FailedLoadResult):
        print(f'\nError: {load_result.fault_text}')
        if load_result.command_class:
            print(f'Command: {load_result.command_class}')
        if load_result.fault_token:
            print(f"Faulty token: '{load_result.fault_token.text}' starting at character #{load_result.fault_token.inner_indices.start}")
        if load_result.input_text:
            print(f"Input text: {load_result.input_text}")
        if load_result.list_of_expected_text:
            print(f'Expected: {sorted(load_result.list_of_expected_text)}')
        print()
