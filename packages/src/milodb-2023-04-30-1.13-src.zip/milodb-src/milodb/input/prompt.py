# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
import os
import sys
from prompt_toolkit import PromptSession # type: ignore
from prompt_toolkit.history import InMemoryHistory # type: ignore
from prompt_toolkit.shortcuts import CompleteStyle # type: ignore
from milodb.command_framework.command_loader import CommandLoader
from milodb.command_framework.i_command_factory import ICommandFactory
from milodb.command_framework.quit_flag import QuitFlag
from milodb.i_user_variables import IUserVariables
from milodb.input.default_input import IDefaultInputText
from milodb.input.input_suggester import InputSuggester
from milodb.input.process import process_user_input
from milodb.input.tab_completer import TabCompleter

def run_interactive_prompt(command_factory: ICommandFactory, user_variables: IUserVariables, default_input_text: IDefaultInputText, quit_flag: QuitFlag) -> None:
    default_input_text.clear()

    print('Enter command (or "help"):')

    if _is_dumb_terminal():
        _run_dumb_prompt(command_factory, user_variables, default_input_text, quit_flag)
    else:
        _run_smart_prompt(command_factory, user_variables, default_input_text, quit_flag)

def _is_dumb_terminal() -> bool:
    return not os.isatty(sys.stdin.fileno())

def _run_dumb_prompt(command_factory: ICommandFactory, user_variables: IUserVariables, default_input_text: IDefaultInputText, quit_flag: QuitFlag) -> None:
    command_loader: CommandLoader = CommandLoader(command_factory)
    while not quit_flag:
        try:
            user_input: str = input('> ')
        except EOFError:
            quit_flag.set()
        else:
            default_input_text.clear()
            process_user_input(user_input, command_loader, user_variables)

def _run_smart_prompt(command_factory: ICommandFactory, user_variables: IUserVariables, default_input_text: IDefaultInputText, quit_flag: QuitFlag) -> None:
    command_loader: CommandLoader = CommandLoader(command_factory)
    history: InMemoryHistory = InMemoryHistory()
    input_suggester: InputSuggester = InputSuggester(command_loader, user_variables)
    tab_completer: TabCompleter = TabCompleter(input_suggester)

    prompt_session: PromptSession[str] = PromptSession(history=history, completer=tab_completer, complete_style=CompleteStyle.READLINE_LIKE)
    while not quit_flag:
        user_input: str = prompt_session.prompt('> ', default=default_input_text.get())
        default_input_text.clear()
        process_user_input(user_input, command_loader, user_variables)
