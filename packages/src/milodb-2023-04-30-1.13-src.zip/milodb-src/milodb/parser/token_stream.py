# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from dataclasses import dataclass, field
from milodb.parser.token import StartEnd, Token

@dataclass
class TokenStreamError(Exception):
    cause_of_fault_text: str
    cause_of_fault_character_index: int
    cause_of_fault_token: (Token | None) = None
    list_of_expected_text: list[str] = field(default_factory=list)

class TokenStream:
    def __init__(self, text: str, stop_before_character_index: (int | None) = None) -> None:
        self._text: str = text
        self._stop_before_character_index: (int | None) = stop_before_character_index

        self._index: int = 0
        self._queued_tokens: list[Token] = []
        self._token_number: int = 0
        self._token_text: str = ""
        self._current_outer_start_index: int = 0
        self._current_inner_start_index: int = 0
        self._is_escaping: bool = False
        self._is_in_token: bool = False
        self._is_in_quoted_string: bool = False
        self._string_quote: str = ''
        self._expecting_delimiter: bool = False
        self._stopped_on_token: (Token | None) = None
        self._current_token: (Token | None) = None
        self._previous_token: (Token | None) = None

    def get_all_text(self) -> str:
        return self._text

    def next(self) -> (Token | None):
        token: (Token | None) = None

        if not self._stopped_on_token:
            if self._queued_tokens:
                token = self._queued_tokens.pop(0)
            else:
                self._load_next_token()
                token = self._queued_tokens.pop(0) if self._queued_tokens else None

            if (token and self._stop_before_character_index is not None) and (token.outer_indices.end >= self._stop_before_character_index):
                self._stopped_on_token = token
                token = None

            self._current_token = token
            if self._current_token and not self._stopped_on_token:
                self._previous_token = self._current_token

        return token

    def get_remaining_raw_text(self) -> str:
        if self._previous_token:
            return self._text[self._previous_token.outer_indices.end:]
        return self._text

    def get_stopped_on_token(self) -> (Token | None):
        return self._stopped_on_token

    def _load_next_token(self) -> None:
        while not self._queued_tokens and self._index < len(self._text):
            self._process_character(self._text[self._index])
            self._index += 1

        if not self._queued_tokens:
            if self._is_escaping:
                raise TokenStreamError('Trailing escape character at end of text', len(self._text))

            if self._is_in_quoted_string:
                raise TokenStreamError('String not terminated at end of text', self._current_outer_start_index)

            if self._token_text:
                self._queue_token(self._token_text, StartEnd(self._current_outer_start_index, len(self._text)), StartEnd(self._current_outer_start_index, len(self._text)))
                self._token_text = ""

    def _process_character(self, char: str) -> None:
        if self._expecting_delimiter:
            if char not in {' ', '(', ')'}:
                raise TokenStreamError('Expecting delimiter', self._index)
            self._expecting_delimiter = False

        if self._is_escaping:
            self._process_escaped_character(char)
        else:
            self._process_non_escaped_character(char)

    def _process_escaped_character(self, char: str) -> None:
        if char in {'"', "'"}:
            self._token_text += char
        else:
            self._token_text += '\\' + char
        self._is_escaping = False

    def _process_non_escaped_character(self, char: str) -> None:
        if char == '\\':
            self._is_escaping = True
        elif self._is_in_quoted_string:
            self._process_character_in_string(char)
        else:
            self._process_character_out_of_string(char)

    def _process_character_in_string(self, char: str) -> None:
        if char == self._string_quote:
            self._is_in_quoted_string = False
            self._queue_token(self._token_text, StartEnd(self._current_outer_start_index, self._index + 1), StartEnd(self._current_outer_start_index + 1, self._index))
            self._expecting_delimiter = True
        else:
            self._token_text += char

    def _process_character_out_of_string(self, char: str) -> None:
        if char in {'"', "'"}:
            self._is_in_quoted_string = True
            self._string_quote = char
            self._is_in_token = True
            self._current_outer_start_index = self._index
        elif char in {' ', '(', ')'}:
            if self._token_text:
                self._queue_token(self._token_text, StartEnd(self._current_outer_start_index, self._index), StartEnd(self._current_outer_start_index, self._index))
            if char in {'(', ')'}:
                self._queue_token(char, StartEnd(self._index, self._index + 1), StartEnd(self._index, self._index + 1))
        else:
            if not self._is_in_token:
                self._is_in_token = True
                self._current_outer_start_index = self._index
            self._token_text += char

    def _queue_token(self, text: str, outer_indices: StartEnd, inner_indices: StartEnd) -> None:
        token = Token(text, self._token_number, outer_indices, inner_indices)
        self._queued_tokens.append(token)
        self._token_number += 1
        self._token_text = ""
        self._is_in_token = False
