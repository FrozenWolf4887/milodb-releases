# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
import os
import sys
from typing import Any, BinaryIO

_root_path: str = os.path.dirname(__file__)
if getattr(sys, 'frozen', False) and hasattr(sys, '_MEIPASS'):
    some_path: Any = getattr(sys, '_MEIPASS')
    if isinstance(some_path, str):
        _root_path = some_path

def resource_path(relative_path: str) -> str:
    return os.path.join(_root_path, 'resources', relative_path)

def try_copy_file(source_filepath: str, target_filepath: str) -> bool:
    was_successful: bool = False

    try:
        source_file: BinaryIO
        target_file: BinaryIO
        with open(source_filepath, 'rb') as source_file:
            with open(target_filepath, 'w+b') as target_file:
                target_file.write(source_file.read())
        was_successful = True
    except IOError as ex:
        print(f"ERROR: Unable to copy '{source_filepath}' to '{target_filepath}': {ex}")

    return was_successful
