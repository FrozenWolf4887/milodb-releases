# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from abc import ABC, abstractmethod
from dataclasses import dataclass
from milodb.command_framework.argument_stream import ArgumentStream
from milodb.parser.token import Token

class ICommand(ABC):
    @abstractmethod
    def load(self, argument_stream: ArgumentStream) -> list[str]:
        pass

    @abstractmethod
    def execute(self) -> None:
        pass

class ICommandCreator(ABC):
    @abstractmethod
    def create(self) -> ICommand:
        pass

    @abstractmethod
    def get_command_class(self) -> type[ICommand]:
        pass

@dataclass
class CommandLoadError(Exception):
    message: str
    fault_token: (Token | None)
    list_of_expected_text: list[str]
