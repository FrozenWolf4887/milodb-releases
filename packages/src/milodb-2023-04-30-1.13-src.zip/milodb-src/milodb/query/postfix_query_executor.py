# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from abc import ABC, abstractmethod
from dataclasses import dataclass
from milodb.database.tease import Tease
from milodb.query.match_result import IMatchResult, TrueMatchResult
from milodb.query.query import IQuery
from milodb.query.tease_match import TeaseMatch

@dataclass
class PostfixError(Exception):
    message: str

@dataclass
class PostfixQueryResult:
    total_match_count: int
    max_match_count: int
    was_max_match_count_reached: bool
    total_tease_count: int
    queried_tease_count: int
    list_of_tease_matches: list[TeaseMatch]

class IPostfixQueryExecutor(ABC):
    @abstractmethod
    def execute(self, list_of_teases: list[Tease], chain_of_postfix_queries: list[IQuery], max_match_count: int) -> PostfixQueryResult:
        pass

class PostfixQueryExecutor(IPostfixQueryExecutor):
    def execute(self, list_of_teases: list[Tease], chain_of_postfix_queries: list[IQuery], max_match_count: int) -> PostfixQueryResult:
        list_of_tease_matches: list[TeaseMatch] = []

        index_of_match: int = 1
        total_match_count: int = 0
        was_max_match_count_reached: bool = False
        index_of_tease: int = 0
        tease: Tease
        for index_of_tease, tease in enumerate(list_of_teases):
            stack_of_match_results: list[IMatchResult] = []

            query_object: IQuery
            for query_object in chain_of_postfix_queries:
                query_object.perform_query(stack_of_match_results, tease)

            if len(stack_of_match_results) == 1:
                match_result: IMatchResult = stack_of_match_results[0]
                if isinstance(match_result, TrueMatchResult):
                    match_count: int = match_result.get_match_count()
                    if total_match_count + match_count <= max_match_count:
                        list_of_tease_matches.append(TeaseMatch(index_of_match, tease, match_result.list_of_field_matches))
                        total_match_count += match_count
                    else:
                        was_max_match_count_reached = True
                        break
                    index_of_match += 1
            else:
                raise PostfixError("Bad expression: Expected a single result remaining on the stack")

        return PostfixQueryResult(total_match_count, max_match_count, was_max_match_count_reached, len(list_of_teases), index_of_tease, list_of_tease_matches)
