# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
import datetime
from abc import abstractmethod
from collections.abc import Callable
from milodb.command_framework.argument_stream import ArgumentStream
from milodb.database.tease import TeaseDateProperty, TeaseFloatProperty, TeaseIntProperty, TeaseStrListProperty, TeaseStrProperty, TeaseTypeProperty
from milodb.query.query import IQuery

class IFieldFloatPredicate(IQuery):
    @abstractmethod
    def __init__(self, tease_property: TeaseFloatProperty, argument_stream: ArgumentStream, compare_func: Callable[[float, float], bool]) -> None:
        pass

class IFieldIntPredicate(IQuery):
    @abstractmethod
    def __init__(self, tease_property: TeaseIntProperty, argument_stream: ArgumentStream, compare_func: Callable[[int, int], bool]) -> None:
        pass

class IFieldStrPredicate(IQuery):
    @abstractmethod
    def __init__(self, tease_property: TeaseStrProperty, argument_stream: ArgumentStream) -> None:
        pass

class IFieldStrListPredicate(IQuery):
    @abstractmethod
    def __init__(self, tease_property: TeaseStrListProperty, argument_stream: ArgumentStream) -> None:
        pass

class IFieldTypePredicate(IQuery):
    @abstractmethod
    def __init__(self, tease_property: TeaseTypeProperty, argument_stream: ArgumentStream) -> None:
        pass

class IFieldDatePredicate(IQuery):
    @abstractmethod
    def __init__(self, tease_property: TeaseDateProperty, argument_stream: ArgumentStream, compare_func: Callable[[datetime.date, datetime.date], bool]) -> None:
        pass

class IFieldTotmPredicate(IQuery):
    @abstractmethod
    def __init__(self, argument_stream: ArgumentStream) -> None:
        pass
