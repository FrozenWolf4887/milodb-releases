# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
import operator
from milodb.database.tease import Tease
from milodb.query.boolean_operator import And, Not, Or
from milodb.query.field_comparators import FieldDateCompare, FieldStrContains, FieldStrIs, FieldStrListContains, FieldStrListIs, FieldStrListMatches, FieldStrMatches, FieldTotmIs, FieldTypeIs, FieldUnsignedFloatCompare, FieldUnsignedIntCompare
from milodb.query.field_verb import FieldDateVerb, FieldFloatVerb, FieldIntVerb, FieldStrListVerb, FieldStrVerb, FieldTotmVerb, FieldTypeVerb, IFieldVerb
from milodb.query.query import IQuery

MAP_OF_TEASE_FIELDNAME_TO_VERBS: dict[str, dict[str, IFieldVerb]] = {
    'teaseId': {
        '=': FieldIntVerb(Tease.tease_id, FieldUnsignedIntCompare, operator.eq),
        '>': FieldIntVerb(Tease.tease_id, FieldUnsignedIntCompare, operator.gt),
        '<': FieldIntVerb(Tease.tease_id, FieldUnsignedIntCompare, operator.lt),
        '>=': FieldIntVerb(Tease.tease_id, FieldUnsignedIntCompare, operator.ge),
        '<=': FieldIntVerb(Tease.tease_id, FieldUnsignedIntCompare, operator.le)
    },
    'authorId': {
        '=': FieldIntVerb(Tease.author_id, FieldUnsignedIntCompare, operator.eq),
        '>': FieldIntVerb(Tease.author_id, FieldUnsignedIntCompare, operator.gt),
        '<': FieldIntVerb(Tease.author_id, FieldUnsignedIntCompare, operator.lt),
        '>=': FieldIntVerb(Tease.author_id, FieldUnsignedIntCompare, operator.ge),
        '<=': FieldIntVerb(Tease.author_id, FieldUnsignedIntCompare, operator.le)
    },
    'type': {
        'is': FieldTypeVerb(Tease.type, FieldTypeIs),
    },
    'title': {
        'is': FieldStrVerb(Tease.title, FieldStrIs),
        'contains': FieldStrVerb(Tease.title, FieldStrContains),
        'matches': FieldStrVerb(Tease.title, FieldStrMatches)
    },
    'summary': {
        'is': FieldStrVerb(Tease.summary, FieldStrIs),
        'contains': FieldStrVerb(Tease.summary, FieldStrContains),
        'matches': FieldStrVerb(Tease.summary, FieldStrMatches)
    },
    'author': {
        'is': FieldStrVerb(Tease.author_name, FieldStrIs),
        'contains': FieldStrVerb(Tease.author_name, FieldStrContains),
        'matches': FieldStrVerb(Tease.author_name, FieldStrMatches)
    },
    'tag': {
        'is': FieldStrListVerb(Tease.list_of_tags, FieldStrListIs),
        'contains': FieldStrListVerb(Tease.list_of_tags, FieldStrListContains),
        'matches': FieldStrListVerb(Tease.list_of_tags, FieldStrListMatches)
    },
    'date': {
        '=': FieldDateVerb(Tease.date, FieldDateCompare, operator.eq),
        '>': FieldDateVerb(Tease.date, FieldDateCompare, operator.gt),
        '<': FieldDateVerb(Tease.date, FieldDateCompare, operator.lt),
        '>=': FieldDateVerb(Tease.date, FieldDateCompare, operator.ge),
        '<=': FieldDateVerb(Tease.date, FieldDateCompare, operator.le)
    },
    'rating': {
        '=': FieldFloatVerb(Tease.rating_value, FieldUnsignedFloatCompare, operator.eq),
        '>': FieldFloatVerb(Tease.rating_value, FieldUnsignedFloatCompare, operator.gt),
        '<': FieldFloatVerb(Tease.rating_value, FieldUnsignedFloatCompare, operator.lt),
        '>=': FieldFloatVerb(Tease.rating_value, FieldUnsignedFloatCompare, operator.ge),
        '<=': FieldFloatVerb(Tease.rating_value, FieldUnsignedFloatCompare, operator.le)
    },
    'text': {
        'contains': FieldStrListVerb(Tease.list_of_text_blocks, FieldStrListContains),
        'matches': FieldStrListVerb(Tease.list_of_text_blocks, FieldStrListMatches)
    },
    'totm': {
        'is': FieldTotmVerb(FieldTotmIs)
    }
}

MAP_OF_BINARY_OPERATORS_TO_QUERY_CLASS: dict[str, type[IQuery]] = {
    'and': And,
    'or': Or
}

MAP_OF_UNARY_OPERATORS_TO_QUERY_CLASS: dict[str, type[IQuery]] = {
    'not': Not
}

def get_list_of_field_names() -> list[str]:
    return list(MAP_OF_TEASE_FIELDNAME_TO_VERBS.keys())

def get_list_of_verb_names() -> list[str]:
    list_of_verb_names: list[str] = []
    verb_dictionary: dict[str, IFieldVerb]
    for verb_dictionary in MAP_OF_TEASE_FIELDNAME_TO_VERBS.values():
        list_of_verb_names.extend(verb_dictionary.keys())
    return list(set(list_of_verb_names))

def get_list_of_operators() -> list[str]:
    return list(MAP_OF_BINARY_OPERATORS_TO_QUERY_CLASS.keys()) + list(MAP_OF_UNARY_OPERATORS_TO_QUERY_CLASS.keys()) + ['(', ')']
