# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
import json
from typing import Any
from milodb.i_user_variables import IPersistentUserVariables, VARIABLE_NAME_PATTERN

class FileUserVariables(IPersistentUserVariables):
    def __init__(self, filepath: str) -> None:
        self._map_of_name_to_value: dict[str, str] = {}
        self._filepath: str = filepath
        self._load_was_successful: bool = True

        try:
            with open(filepath, 'rt', encoding='utf-8') as file:
                json_object: Any = json.load(file)
        except FileNotFoundError:
            pass
        except (IOError, json.JSONDecodeError) as ex:
            print(f"Error: Unable to load variables from '{filepath}': {ex}")
            self._load_was_successful = False
        else:
            print(f"Loaded variables from '{filepath}'")
            if isinstance(json_object, dict):
                some_dictionary: dict[Any, Any] = json_object
                self._map_of_name_to_value = self._validate_config(some_dictionary)
            else:
                print("Error: Root of variables file is not a JSON dictionary")
                self._load_was_successful = False

        if not self._load_was_successful:
            print("CRITICAL: Variables set or changed at runtime will not be saved to prevent corruption")

    def _validate_config(self, some_dictionary: dict[Any, Any]) -> dict[str, str]:
        map_of_name_to_value: dict[str, str] = {}

        index: int
        name: Any
        value: Any
        for index, (name, value) in enumerate(some_dictionary.items()):
            is_valid: bool = True
            if not isinstance(name, str):
                print(f'Error: Variable at index #{index} has a non string name')
                is_valid = False
            elif not name:
                print(f'Error: Variable at index #{index} has a blank name')
                is_valid = False
            elif not VARIABLE_NAME_PATTERN.fullmatch(name):
                print(f"Error: Variable at index #{index} named '{name}' does not conform to pattern '{VARIABLE_NAME_PATTERN.pattern}'")
                is_valid = False
            if not isinstance(value, str):
                print(f"Error: Variable at index #{index} named '{name}' has a value that is not a string")
                is_valid = False
            if is_valid:
                map_of_name_to_value[name] = value
            else:
                self._load_was_successful = False

        return map_of_name_to_value

    def try_retrieve(self, name: str) -> (str | None):
        value: Any = self._map_of_name_to_value.get(name)
        return value if isinstance(value, str) else None

    def set(self, name: str, value: str) -> None:
        self._map_of_name_to_value[name] = value

    def try_delete(self, name: str) -> bool:
        try:
            self._map_of_name_to_value.pop(name)
        except KeyError:
            return False
        return True

    def try_save(self) -> IPersistentUserVariables.SaveResult:
        if not self._load_was_successful:
            return IPersistentUserVariables.SaveResult(False, "Variable not saved due to initial loading error", None)
        try:
            with open(self._filepath, 'wt', encoding='utf-8') as file:
                json.dump(self._map_of_name_to_value, file, indent=4, ensure_ascii=False, sort_keys=True)
        except IOError as ex:
            return IPersistentUserVariables.SaveResult(False, None, f"Unable to save variables to '{self._filepath}': {ex}")
        return IPersistentUserVariables.SaveResult(True, None, None)

    def get_list_of_names(self) -> list[str]:
        return list(self._map_of_name_to_value.keys())

    def get_list_of_variables(self) -> list[tuple[str, str]]:
        return list(self._map_of_name_to_value.items())
