# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from milodb.config.config_schema import CONFIG_SCHEMA
from milodb.config.framework import IConfig

class AnsiConfig:
    def __init__(self, config: IConfig) -> None:
        self._config = config

    @property
    def index_heading_colour(self) -> str:
        return self._config.get_config_value(CONFIG_SCHEMA.format.ansi.colour.index_heading)

    @property
    def hits_heading_colour(self) -> str:
        return self._config.get_config_value(CONFIG_SCHEMA.format.ansi.colour.hits_heading)

    @property
    def tease_heading_colour(self) -> str:
        return self._config.get_config_value(CONFIG_SCHEMA.format.ansi.colour.tease_heading)

    @property
    def author_heading_colour(self) -> str:
        return self._config.get_config_value(CONFIG_SCHEMA.format.ansi.colour.author_heading)

    @property
    def type_heading_colour(self) -> str:
        return self._config.get_config_value(CONFIG_SCHEMA.format.ansi.colour.type_heading)

    @property
    def date_heading_colour(self) -> str:
        return self._config.get_config_value(CONFIG_SCHEMA.format.ansi.colour.date_heading)

    @property
    def rating_heading_colour(self) -> str:
        return self._config.get_config_value(CONFIG_SCHEMA.format.ansi.colour.rating_heading)

    @property
    def tags_heading_colour(self) -> str:
        return self._config.get_config_value(CONFIG_SCHEMA.format.ansi.colour.tags_heading)

    @property
    def summary_heading_colour(self) -> str:
        return self._config.get_config_value(CONFIG_SCHEMA.format.ansi.colour.summary_heading)

    @property
    def matching_text_heading_colour(self) -> str:
        return self._config.get_config_value(CONFIG_SCHEMA.format.ansi.colour.matching_text_heading)

    @property
    def matching_text_colour(self) -> str:
        return self._config.get_config_value(CONFIG_SCHEMA.format.ansi.colour.matching_text)

    @property
    def ellipsis_colour(self) -> str:
        return self._config.get_config_value(CONFIG_SCHEMA.format.ansi.colour.ellipsis)
