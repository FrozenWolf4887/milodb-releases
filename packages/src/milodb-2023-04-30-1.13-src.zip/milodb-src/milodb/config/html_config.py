# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from milodb.config.config_schema import CONFIG_SCHEMA
from milodb.config.framework import IConfig
from milodb.config.framework import IConfigLeaf

class HtmlConfig:
    def __init__(self, config: IConfig) -> None:
        self._config: IConfig = config

    @property
    def css_file_path(self) -> str:
        return self._config.get_config_value(CONFIG_SCHEMA.format.html.css.file_path)

    def try_get_colour_field(self, key: str) -> (str | None):
        config_leaf: IConfigLeaf | None = CONFIG_SCHEMA.format.html.css.colour.try_find_child_leaf(key)
        if config_leaf:
            return self._config.get_config_value(config_leaf)
        return None
