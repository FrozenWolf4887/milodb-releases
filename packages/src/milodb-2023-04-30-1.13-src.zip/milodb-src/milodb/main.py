# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
import datetime
from milodb.command_framework.quit_flag import QuitFlag
from milodb.commands.browse_command import BrowseAllCommand, BrowseCommand
from milodb.commands.command_factory import CommandFactory
from milodb.commands.config_command import ConfigCommand
from milodb.commands.copy_command import CopyCommand
from milodb.commands.database_stats import DatabaseStats
from milodb.commands.ellipsis_command import EllipsisCommand
from milodb.commands.exit_command import ExitCommand
from milodb.commands.format_command import FormatCommand
from milodb.commands.help_command import HelpCommand
from milodb.commands.highlight_command import HighlightCommand
from milodb.commands.list_command import ListCommand
from milodb.commands.open_command import OpenCommand
from milodb.commands.openauthor_command import OpenAuthorCommand
from milodb.commands.query_command import QueryCommand
from milodb.commands.show_command import ShowAllCommand, ShowCommand
from milodb.commands.sort_command import SortCommand
from milodb.commands.sort_keys import DATE_SORT_KEY, LIST_OF_AVAILABLE_SORT_KEYS, OrderedSortKey, TEASE_ID_SORT_KEY
from milodb.commands.stats_command import StatsCommand
from milodb.commands.summary_command import SummaryCommand
from milodb.commands.tease_match_sorter import ITeaseMatchSorter, TeaseMatchSorter
from milodb.commands.url_command import UrlCommand
from milodb.commands.urlauthor_command import UrlAuthorCommand
from milodb.commands.var_command import VarCommand
from milodb.config.ansi_config import AnsiConfig
from milodb.config.bbcode_config import BBCodeConfig
from milodb.config.config_schema import CONFIG_SCHEMA
from milodb.config.framework import IConfig
from milodb.config.html_config import HtmlConfig
from milodb.config.json_config_file import JsonConfigFile
from milodb.database.database import load_teases_from_database_file, try_get_newest_tease_date, try_get_oldest_tease_date
from milodb.database.tease import Tease
from milodb.datum.ref_datum import RefDatum
from milodb.file_user_variables import FileUserVariables
from milodb.i_user_variables import IPersistentUserVariables
from milodb.input.autoexec import run_autoexec
from milodb.input.default_input import DefaultInputText, IDefaultInputText
from milodb.input.prompt import run_interactive_prompt
from milodb.output.format.ansi_formatter import AnsiFormatter
from milodb.output.format.bbcode_formatter import BBCodeFormatter
from milodb.output.format.html_formatter import HtmlFormatter
from milodb.output.format.i_formatter import IFormatter
from milodb.output.format.i_html_formatter import IHtmlFormatter
from milodb.output.format.plain_formatter import PlainFormatter
from milodb.output.print.error_printer import ErrorPrinter
from milodb.output.print.i_printer import IPrinter, IRedirectablePrinter
from milodb.output.print.normal_printer import NormalPrinter
from milodb.output.print.stdout_printer import StdoutPrinter
from milodb.output.print.warning_printer import WarningPrinter
from milodb.query.infix_query_parser import InfixQueryParser
from milodb.query.postfix_query_executor import PostfixQueryExecutor
from milodb.query.tease_match import TeaseMatch
from milodb.version import MILODB_DATE, MILODB_VERSION

DATABASE_FILENAME: str = 'database.mdb'
CONFIG_FILENAME: str = 'config.json'
VARIABLES_FILENAME: str = 'variables.json'
AUTOEXEC_FILENAME: str = 'autoexec.txt'

class Main:
    # pylint: disable=too-many-statements
    def __init__(self) -> None:
        print(f'Milovana Database {MILODB_VERSION or "(Development)"}, {MILODB_DATE or "(Undated)"}')

        stdout_printer: IPrinter = StdoutPrinter()
        normal_printer: IRedirectablePrinter = NormalPrinter(stdout_printer)
        error_printer: IRedirectablePrinter = ErrorPrinter(stdout_printer)
        warning_printer: IRedirectablePrinter = WarningPrinter(stdout_printer)
        system_config: IConfig = JsonConfigFile(CONFIG_FILENAME, CONFIG_SCHEMA)
        list_of_tease_matches: RefDatum[list[TeaseMatch]] = RefDatum([])
        use_highlighting: RefDatum[bool] = RefDatum(True)
        use_ellipsis: RefDatum[bool] = RefDatum(True)
        ellipsis_max_width: RefDatum[int] = RefDatum(40)
        plain_formatter: IFormatter = PlainFormatter()
        ansi_formatter: IFormatter = AnsiFormatter(AnsiConfig(system_config))
        bbcode_formatter: IFormatter = BBCodeFormatter(BBCodeConfig(system_config))
        html_formatter: IHtmlFormatter = HtmlFormatter(HtmlConfig(system_config))
        current_formatter: RefDatum[IFormatter] = RefDatum(ansi_formatter)
        list_of_formatters: list[IFormatter] = [plain_formatter, ansi_formatter, bbcode_formatter, html_formatter]
        tease_match_sorter: ITeaseMatchSorter = TeaseMatchSorter([OrderedSortKey(DATE_SORT_KEY, True), OrderedSortKey(TEASE_ID_SORT_KEY, True)])
        list_of_active_sort_keys: RefDatum[list[OrderedSortKey]] = RefDatum([])
        infix_query_parser: InfixQueryParser = InfixQueryParser()
        postfix_query_executor: PostfixQueryExecutor = PostfixQueryExecutor()
        self._default_input_text: IDefaultInputText = DefaultInputText()
        self._user_variables: IPersistentUserVariables = FileUserVariables(VARIABLES_FILENAME)
        self._quit_flag: QuitFlag = QuitFlag()

        list_of_teases: list[Tease] = load_teases_from_database_file(DATABASE_FILENAME)
        oldest_tease_date: (datetime.date | None) = try_get_oldest_tease_date(list_of_teases)
        newest_tease_date: (datetime.date | None) = try_get_newest_tease_date(list_of_teases)
        print(f"{len(list_of_teases):,} teases loaded ranging from {oldest_tease_date or 'None'} to {newest_tease_date or 'None'}\n")

        database_stats: DatabaseStats = DatabaseStats(list_of_teases)

        self._command_factory: CommandFactory = CommandFactory()
        self._command_factory.register_command('exit', lambda: ExitCommand(self._quit_flag), ExitCommand.Help)
        self._command_factory.register_command('help', lambda: HelpCommand(self._command_factory, normal_printer), HelpCommand.Help)
        self._command_factory.register_command('list', lambda: ListCommand(list_of_teases, list_of_tease_matches.get(), current_formatter.get(), use_highlighting.get(), normal_printer, error_printer), ListCommand.Help)
        self._command_factory.register_command('format', lambda: FormatCommand(current_formatter, list_of_formatters, normal_printer), lambda: FormatCommand.Help(list_of_formatters))
        self._command_factory.register_command('highlight', lambda: HighlightCommand(use_highlighting, normal_printer), HighlightCommand.Help)
        self._command_factory.register_command('ellipsis', lambda: EllipsisCommand(use_ellipsis, normal_printer), EllipsisCommand.Help)
        self._command_factory.register_command('show', lambda: ShowCommand(list_of_teases, list_of_tease_matches.get(), current_formatter.get(), use_highlighting.get(), use_ellipsis.get(), ellipsis_max_width.get(), normal_printer, error_printer), ShowCommand.Help)
        self._command_factory.register_command('showall', lambda: ShowAllCommand(list_of_teases, list_of_tease_matches.get(), current_formatter.get(), use_highlighting.get(), normal_printer, error_printer), ShowAllCommand.Help)
        self._command_factory.register_command('summary', lambda: SummaryCommand(list_of_teases, list_of_tease_matches.get(), current_formatter.get(), use_highlighting.get(), normal_printer, error_printer), SummaryCommand.Help)
        self._command_factory.register_command('open', lambda: OpenCommand(list_of_teases, list_of_tease_matches.get(), normal_printer, error_printer), OpenCommand.Help)
        self._command_factory.register_command('openauthor', lambda: OpenAuthorCommand(list_of_teases, list_of_tease_matches.get(), normal_printer, error_printer), OpenAuthorCommand.Help)
        self._command_factory.register_command('browse', lambda: BrowseCommand(list_of_teases, list_of_tease_matches.get(), html_formatter, use_highlighting.get(), use_ellipsis.get(), ellipsis_max_width.get(), normal_printer, error_printer), BrowseCommand.Help)
        self._command_factory.register_command('browseall', lambda: BrowseAllCommand(list_of_teases, list_of_tease_matches.get(), html_formatter, use_highlighting.get(), normal_printer, error_printer), BrowseAllCommand.Help)
        self._command_factory.register_command('query', lambda: QueryCommand(list_of_teases, infix_query_parser, postfix_query_executor, list_of_tease_matches, tease_match_sorter, list_of_active_sort_keys.get(), current_formatter.get(), use_highlighting.get(), normal_printer, warning_printer, error_printer), QueryCommand.Help)
        self._command_factory.register_command('sort', lambda: SortCommand(list_of_tease_matches, tease_match_sorter, list_of_active_sort_keys, LIST_OF_AVAILABLE_SORT_KEYS, normal_printer), lambda: SortCommand.Help(LIST_OF_AVAILABLE_SORT_KEYS))
        self._command_factory.register_command('url', lambda: UrlCommand(list_of_teases, list_of_tease_matches.get(), normal_printer, error_printer), UrlCommand.Help)
        self._command_factory.register_command('urlauthor', lambda: UrlAuthorCommand(list_of_teases, list_of_tease_matches.get(), normal_printer, error_printer), UrlAuthorCommand.Help)
        self._command_factory.register_command('stats', lambda: StatsCommand(database_stats, normal_printer), StatsCommand.Help)
        self._command_factory.register_command('copy', lambda: CopyCommand(self._command_factory, [normal_printer, warning_printer, error_printer]), CopyCommand.Help)
        self._command_factory.register_command('var', lambda: VarCommand(self._user_variables, self._default_input_text, normal_printer, warning_printer, error_printer), VarCommand.Help)
        self._command_factory.register_command('config', lambda: ConfigCommand(system_config, normal_printer), ConfigCommand.Help)

    def run(self) -> None:
        run_autoexec(AUTOEXEC_FILENAME, self._command_factory, self._user_variables, self._quit_flag)
        if not self._quit_flag:
            run_interactive_prompt(self._command_factory, self._user_variables, self._default_input_text, self._quit_flag)
