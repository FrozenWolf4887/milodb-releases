# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from milodb.command_framework.argument_stream import ArgumentStream
from milodb.command_framework.i_command import ICommand
from milodb.command_framework.i_help_info import IHelpInfo
from milodb.commands.enums import OnOrOff
from milodb.datum.ref_datum import RefDatum
from milodb.output.print.i_printer import IPrinter

class EllipsisCommand(ICommand):
    def __init__(self, use_ellipsis: RefDatum[bool], normal_printer: IPrinter) -> None:
        self._use_ellipsis: RefDatum[bool] = use_ellipsis
        self._normal_printer: IPrinter = normal_printer
        self._new_ellipsis: (OnOrOff | None) = None

    def load(self, argument_stream: ArgumentStream) -> list[str]:
        self._new_ellipsis = argument_stream.pop_optional_enum(OnOrOff)
        if self._new_ellipsis is not None:
            argument_stream.fail_if_not_empty()
            return []
        return OnOrOff.lowercase_names()

    def execute(self) -> None:
        if self._new_ellipsis:
            self._use_ellipsis.set(self._new_ellipsis.value)
            self._normal_printer.writeln(f"Changed ellipsis mode to '{self._new_ellipsis.name.lower()}'")
        else:
            self._normal_printer.writeln(f"Current ellipsis mode is '{OnOrOff(self._use_ellipsis.get()).name.lower()}'")
            self._normal_printer.writeln(f"Available options are {OnOrOff.lowercase_names()}")

    class Help(IHelpInfo):
        def get_one_line_summary(self) -> str:
            return "Sets whether matching text paragraphs are abbreviated with an ellipsis"

        def get_detailed_summary(self) -> str:
            return (
                f"Arguments: [{'|'.join(OnOrOff.lowercase_names())}]\n"
                "Enables or disables the abbreviation for text in paragraph matches. Abbreviation"
                " is typically shown with the ellipsis character '\u2026'.\n"
                "When used without arguments, the current setting is shown.\n"
                "Example:\r"
                "  \tTurn off text abbreviation\r"
                "  > \tellipsis off\r"
                "Example:\r"
                "  \tShow the current setting\r"
                "  > \tellipsis\n"
                "See also:\r"
                "  \tshow, browse, format, highlight\n"
            )
