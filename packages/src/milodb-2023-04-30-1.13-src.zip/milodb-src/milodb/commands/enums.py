# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from enum import Enum

class EnumEx(Enum):
    @classmethod
    def lowercase_names(cls) -> list[str]:
        return [e.name.lower() for e in cls]

    @classmethod
    def values(cls) -> list[str]:
        return [e.value for e in cls]

    @classmethod
    def lowercase_values(cls) -> list[str]:
        return [e.value.lower() for e in cls]

class OnOrOff(EnumEx):
    ON = True
    OFF = False
