# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from collections.abc import Callable
from milodb.command_framework.i_command import ICommand
from milodb.command_framework.i_command_factory import ICommandFactory
from milodb.command_framework.i_help_info import IHelpInfo

class CommandFactory(ICommandFactory):
    def __init__(self) -> None:
        self._map_of_command_name_to_constructor: dict[str, Callable[[], ICommand]] = {}
        self._map_of_help_name_to_constructor: dict[str, Callable[[], IHelpInfo]] = {}

    def register_command(self, command_name: str, command_constructor: Callable[[], ICommand], help_constructor: Callable[[], IHelpInfo]) -> None:
        self._map_of_command_name_to_constructor[command_name] = command_constructor
        self._map_of_help_name_to_constructor[command_name] = help_constructor

    def get_list_of_command_names(self) -> list[str]:
        return list(self._map_of_command_name_to_constructor)

    def try_get_command_from_name(self, command_name: str) -> (ICommand | None):
        constructor: (Callable[[], ICommand] | None) = self._map_of_command_name_to_constructor.get(command_name)
        if constructor:
            return constructor()
        return None

    def try_get_command_help_from_name(self, command_name: str) -> (IHelpInfo | None):
        constructor: (Callable[[], IHelpInfo] | None) = self._map_of_help_name_to_constructor.get(command_name)
        if constructor:
            return constructor()
        return None
