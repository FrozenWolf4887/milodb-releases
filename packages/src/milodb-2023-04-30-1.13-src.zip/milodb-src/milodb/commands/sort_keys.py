# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
import datetime
from abc import ABC, abstractmethod
from enum import IntEnum
from typing import TypeVar
from milodb.database.tease import Tease, TeaseDateProperty, TeaseFloatProperty, TeaseIntProperty, TeaseStrProperty, TeaseTypeProperty
from milodb.query.tease_match import TeaseMatch

class CompareResult(IntEnum):
    LEFT_IS_LESS = -1
    BOTH_ARE_SAME = 0
    LEFT_IS_MORE = 1

    def invert(self) -> 'CompareResult':
        return CompareResult(self.value * -1)

class ISortKey(ABC):
    @abstractmethod
    def get_name(self) -> str:
        pass
    @abstractmethod
    def get_description(self) -> str:
        pass
    @abstractmethod
    def compare(self, left: TeaseMatch, right: TeaseMatch) -> CompareResult:
        pass

class IntegerFieldSortKey(ISortKey):
    def __init__(self, name: str, tease_property: TeaseIntProperty, description: str) -> None:
        self._name: str = name
        self._tease_property: TeaseIntProperty = tease_property
        self._description = description

    def get_name(self) -> str:
        return self._name

    def get_description(self) -> str:
        return self._description

    def compare(self, left: TeaseMatch, right: TeaseMatch) -> CompareResult:
        left_value: int = self._tease_property(left.tease)
        right_value: int = self._tease_property(right.tease)
        return _diff(left_value, right_value)

class FloatFieldSortKey(ISortKey):
    def __init__(self, name: str, tease_property: TeaseFloatProperty, description: str) -> None:
        self._name: str = name
        self._tease_property: TeaseFloatProperty = tease_property
        self._description = description

    def get_name(self) -> str:
        return self._name

    def get_description(self) -> str:
        return self._description

    def compare(self, left: TeaseMatch, right: TeaseMatch) -> CompareResult:
        left_value: float = self._tease_property(left.tease)
        right_value: float = self._tease_property(right.tease)
        return _diff(left_value, right_value)

class StringFieldSortKey(ISortKey):
    def __init__(self, name: str, tease_property: TeaseStrProperty, description: str) -> None:
        self._name: str = name
        self._tease_property: TeaseStrProperty = tease_property
        self._description = description

    def get_name(self) -> str:
        return self._name

    def get_description(self) -> str:
        return self._description

    def compare(self, left: TeaseMatch, right: TeaseMatch) -> CompareResult:
        left_value: str = self._tease_property(left.tease)
        right_value: str = self._tease_property(right.tease)
        return _diff(left_value, right_value)

class TeaseTypeSortKey(ISortKey):
    def __init__(self, name: str, tease_property: TeaseTypeProperty, description: str) -> None:
        self._name: str = name
        self._tease_property: TeaseTypeProperty = tease_property
        self._description = description

    def get_name(self) -> str:
        return self._name

    def get_description(self) -> str:
        return self._description

    def compare(self, left: TeaseMatch, right: TeaseMatch) -> CompareResult:
        left_value: str = self._tease_property(left.tease).value
        right_value: str = self._tease_property(right.tease).value
        return _diff(left_value, right_value)

class DateFieldSortKey(ISortKey):
    def __init__(self, name: str, tease_property: TeaseDateProperty, description: str) -> None:
        self._name: str = name
        self._tease_property: TeaseDateProperty = tease_property
        self._description = description

    def get_name(self) -> str:
        return self._name

    def get_description(self) -> str:
        return self._description

    def compare(self, left: TeaseMatch, right: TeaseMatch) -> CompareResult:
        left_value: datetime.date = self._tease_property(left.tease)
        right_value: datetime.date = self._tease_property(right.tease)
        return _diff(left_value, right_value)

class TotmTagSortKey(ISortKey):
    def __init__(self, name: str, description: str) -> None:
        self._name: str = name
        self._description = description

    def get_name(self) -> str:
        return self._name

    def get_description(self) -> str:
        return self._description

    def compare(self, left: TeaseMatch, right: TeaseMatch) -> CompareResult:
        left_value: int = left.tease.totm_status().value
        right_value: int = right.tease.totm_status().value
        return _diff(left_value, right_value)

class MatchCountSortKey(ISortKey):
    def __init__(self, name: str, description: str) -> None:
        self._name: str = name
        self._description = description

    def get_name(self) -> str:
        return self._name

    def get_description(self) -> str:
        return self._description

    def compare(self, left: TeaseMatch, right: TeaseMatch) -> CompareResult:
        left_value: int = left.get_match_count()
        right_value: int = right.get_match_count()
        return _diff(left_value, right_value)

class OrderedSortKey(ISortKey):
    def __init__(self, data_sort_key: ISortKey, is_ascending: bool) -> None:
        self._data_sort_key: ISortKey = data_sort_key
        self._is_ascending: bool = is_ascending

    def get_name(self) -> str:
        return self._data_sort_key.get_name()

    def get_description(self) -> str:
        return self._data_sort_key.get_description()

    def is_ascending(self) -> bool:
        return self._is_ascending

    def compare(self, left: TeaseMatch, right: TeaseMatch) -> CompareResult:
        compare_result: CompareResult = self._data_sort_key.compare(left, right)
        if self._is_ascending:
            return compare_result
        return compare_result.invert()

T = TypeVar("T", int, float, str, datetime.date)
def _diff(left: T, right: T) -> CompareResult:
    if left < right:
        return CompareResult.LEFT_IS_LESS
    if left > right:
        return CompareResult.LEFT_IS_MORE
    return CompareResult.BOTH_ARE_SAME

TEASE_ID_SORT_KEY: ISortKey = IntegerFieldSortKey('teaseId', Tease.tease_id, 'Numerical id of the tease')
AUTHOR_ID_SORT_KEY: ISortKey = IntegerFieldSortKey('authorId', Tease.author_id, 'Numerical id of the author')
DATE_SORT_KEY: ISortKey = DateFieldSortKey('date', Tease.date, 'Published date of the tease')
TITLE_SORT_KEY: ISortKey = StringFieldSortKey('title', Tease.title, 'Title of the tease')
RATING_SORT_KEY: ISortKey = FloatFieldSortKey('rating', Tease.rating_value, 'Value rating of the tease')
TYPE_SORT_KEY: ISortKey = TeaseTypeSortKey('type', Tease.type, 'EOS, regular, audio, etc. tease type')
TOTM_SORT_KEY: ISortKey = TotmTagSortKey('totm', 'Tease-Of-The-Month nominees and winners')
MATCH_COUNT_SORT_KEY: ISortKey = MatchCountSortKey('hits', 'Number of tease field matches from the last query')

LIST_OF_AVAILABLE_SORT_KEYS: list[ISortKey] = [
    TEASE_ID_SORT_KEY,
    AUTHOR_ID_SORT_KEY,
    DATE_SORT_KEY,
    TITLE_SORT_KEY,
    RATING_SORT_KEY,
    TYPE_SORT_KEY,
    TOTM_SORT_KEY,
    MATCH_COUNT_SORT_KEY
]
