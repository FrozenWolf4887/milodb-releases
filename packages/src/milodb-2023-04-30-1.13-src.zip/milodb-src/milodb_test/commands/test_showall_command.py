# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from dataclasses import dataclass, field
from unittest.mock import ANY, Mock, call
from milodb.command_framework.i_command import ICommand
from milodb.commands.show_command import ShowAllCommand
from milodb.database.tease import Tease
from milodb.output.format.i_formatter import IFormatter
from milodb.output.print.i_printer import IPrinter
from milodb.query.tease_match import TeaseMatch
from milodb_test.commands import fake_teases
from milodb_test.commands.error_messages import ErrorMessage
from milodb_test.commands.test_command_base import CommandTestBase, NonIndexedTeaseMatch
from milodb_test.strict_mock import StrictMock

_DEFAULT_LIST_OF_TEASES: list[Tease] = [
    fake_teases.TEASE_ID_1000_AUTHOR_ID_4567,
    fake_teases.TEASE_ID_1234_AUTHOR_ID_6431,
    fake_teases.TEASE_ID_5678_AUTHOR_ID_4567,
    fake_teases.TEASE_ID_2000_AUTHOR_ID_6431,
    fake_teases.TEASE_ID_8721_AUTHOR_ID_7213
]

@dataclass
class _Args:
    list_of_teases: list[Tease] = field(default_factory=_DEFAULT_LIST_OF_TEASES.copy)
    list_of_tease_matches: list[TeaseMatch] = field(default_factory=list)
    formatter: StrictMock = field(default_factory=lambda: StrictMock(IFormatter))
    use_highlighting: bool = True
    normal_printer: StrictMock = field(default_factory=lambda: StrictMock(IPrinter))
    error_printer: StrictMock = field(default_factory=lambda: StrictMock(IPrinter))

class TestBrowseCommand(CommandTestBase):
    def setUp(self) -> None:
        self._args: _Args = _Args()
        return super().setUp()

    def create_command(self) -> ICommand:
        return ShowAllCommand(
            self._args.list_of_teases,
            self._args.list_of_tease_matches,
            self._args.formatter,
            self._args.use_highlighting,
            self._args.normal_printer,
            self._args.error_printer
        )

    def test_without_arguments_and_no_matches_outputs_error(self) -> None:
        self._args.error_printer.writeln = Mock()
        self.command_load_and_execute([])
        self._args.error_printer.writeln.assert_called_once_with('No teases available to show')
        self.assert_next_text([])

    def test_without_arguments_and_some_matches_calls_formatter(self) -> None:
        list_of_tease_matches: list[TeaseMatch] = [
            TeaseMatch(0, fake_teases.TEASE_ID_5678_AUTHOR_ID_4567, []),
            TeaseMatch(1, fake_teases.TEASE_ID_8721_AUTHOR_ID_7213, [])
        ]
        self._args.list_of_tease_matches = list_of_tease_matches
        self._args.formatter.print_all_text_of_list_of_teases = Mock()
        self.command_load_and_execute([])
        self._args.formatter.print_all_text_of_list_of_teases.assert_called_once_with(list_of_tease_matches, ANY, self._args.normal_printer)
        self.assert_next_text([])

    def test_with_one_in_range_index_calls_formatter(self) -> None:
        list_of_tease_matches: list[TeaseMatch] = [
            TeaseMatch(0, fake_teases.TEASE_ID_5678_AUTHOR_ID_4567, []),
            TeaseMatch(1, fake_teases.TEASE_ID_8721_AUTHOR_ID_7213, [])
        ]
        self._args.list_of_tease_matches = list_of_tease_matches
        self._args.formatter.print_all_text_of_list_of_teases = Mock()
        self.command_load_and_execute(['1'])
        self._args.formatter.print_all_text_of_list_of_teases.assert_called_once_with([list_of_tease_matches[1]], ANY, self._args.normal_printer)
        self.assert_next_text([])

    def test_with_one_out_of_range_index_outputs_error(self) -> None:
        list_of_tease_matches: list[TeaseMatch] = [
            TeaseMatch(0, fake_teases.TEASE_ID_5678_AUTHOR_ID_4567, []),
            TeaseMatch(1, fake_teases.TEASE_ID_8721_AUTHOR_ID_7213, [])
        ]
        self._args.list_of_tease_matches = list_of_tease_matches
        self._args.error_printer.writeln = Mock()
        self.command_load_and_execute(['2'])
        self._args.error_printer.writeln.assert_has_calls([call("Match index '2' is out of range"), call('No teases available to show')])
        self.assert_next_text([])

    def test_with_one_in_range_and_one_out_of_range_outputs_error(self) -> None:
        list_of_tease_matches: list[TeaseMatch] = [
            TeaseMatch(0, fake_teases.TEASE_ID_5678_AUTHOR_ID_4567, []),
            TeaseMatch(1, fake_teases.TEASE_ID_8721_AUTHOR_ID_7213, [])
        ]
        self._args.list_of_tease_matches = list_of_tease_matches
        self._args.error_printer.writeln = Mock()
        self.command_load_and_execute(['0', '2'])
        self._args.error_printer.writeln.assert_has_calls([call("Match index '2' is out of range"), call('No teases available to show')])
        self.assert_next_text([])

    def test_with_one_existing_teaseid_in_matches_calls_formatter(self) -> None:
        list_of_tease_matches: list[TeaseMatch] = [
            TeaseMatch(0, fake_teases.TEASE_ID_5678_AUTHOR_ID_4567, []),
            TeaseMatch(1, fake_teases.TEASE_ID_8721_AUTHOR_ID_7213, [])
        ]
        self._args.list_of_tease_matches = list_of_tease_matches
        self._args.formatter.print_all_text_of_list_of_teases = Mock()
        self.command_load_and_execute(['#8721'])
        self._args.formatter.print_all_text_of_list_of_teases.assert_called_once_with([list_of_tease_matches[1]], ANY, self._args.normal_printer)
        self.assert_next_text([])

    def test_with_one_existing_teaseid_in_database_calls_formatter(self) -> None:
        list_of_tease_matches: list[TeaseMatch] = [
            TeaseMatch(0, fake_teases.TEASE_ID_5678_AUTHOR_ID_4567, []),
            TeaseMatch(1, fake_teases.TEASE_ID_8721_AUTHOR_ID_7213, [])
        ]
        self._args.list_of_tease_matches = list_of_tease_matches
        self._args.formatter.print_all_text_of_list_of_teases = Mock()
        self.command_load_and_execute(['#2000'])
        self._args.formatter.print_all_text_of_list_of_teases.assert_called_once_with(
            [NonIndexedTeaseMatch(fake_teases.TEASE_ID_2000_AUTHOR_ID_6431)],
            ANY, self._args.normal_printer)
        self.assert_next_text([])

    def test_with_one_non_existing_teaseid_outputs_error(self) -> None:
        self._args.error_printer.writeln = Mock()
        self.command_load_and_execute(['#1235'])
        self._args.error_printer.writeln.assert_has_calls([call("Unable to find tease for tease id '1235'"), call('No teases available to show')])
        self.assert_next_text([])

    def test_with_one_teaseid_in_matches_and_one_in_database_calls_formatter(self) -> None:
        list_of_tease_matches: list[TeaseMatch] = [
            TeaseMatch(0, fake_teases.TEASE_ID_5678_AUTHOR_ID_4567, []),
            TeaseMatch(1, fake_teases.TEASE_ID_1234_AUTHOR_ID_6431, [])
        ]
        self._args.list_of_tease_matches = list_of_tease_matches
        self._args.formatter.print_all_text_of_list_of_teases = Mock()
        self.command_load_and_execute(['#2000', '#1234'])
        self._args.formatter.print_all_text_of_list_of_teases.assert_called_once_with(
            [NonIndexedTeaseMatch(fake_teases.TEASE_ID_2000_AUTHOR_ID_6431), list_of_tease_matches[1]],
            ANY, self._args.normal_printer)
        self.assert_next_text([])

    def test_with_one_authorid_from_matches_calls_formatter(self) -> None:
        list_of_tease_matches: list[TeaseMatch] = [
            TeaseMatch(0, fake_teases.TEASE_ID_1234_AUTHOR_ID_6431, []),
            TeaseMatch(1, fake_teases.TEASE_ID_1000_AUTHOR_ID_4567, []),
            TeaseMatch(2, fake_teases.TEASE_ID_8721_AUTHOR_ID_7213, []),
            TeaseMatch(3, fake_teases.TEASE_ID_5678_AUTHOR_ID_4567, [])
        ]
        self._args.list_of_tease_matches = list_of_tease_matches
        self._args.formatter.print_all_text_of_list_of_teases = Mock()
        self.command_load_and_execute(['@4567'])
        self._args.formatter.print_all_text_of_list_of_teases.assert_called_once_with([list_of_tease_matches[1], list_of_tease_matches[3]], ANY, self._args.normal_printer)
        self.assert_next_text([])

    def test_with_one_existing_authorid_in_database_calls_formatter(self) -> None:
        list_of_tease_matches: list[TeaseMatch] = [
            TeaseMatch(0, fake_teases.TEASE_ID_1234_AUTHOR_ID_6431, []),
            TeaseMatch(1, fake_teases.TEASE_ID_1000_AUTHOR_ID_4567, [])
        ]
        self._args.list_of_tease_matches = list_of_tease_matches
        self._args.formatter.print_all_text_of_list_of_teases = Mock()
        self.command_load_and_execute(['@7213'])
        self._args.formatter.print_all_text_of_list_of_teases.assert_called_once_with(
            [NonIndexedTeaseMatch(fake_teases.TEASE_ID_8721_AUTHOR_ID_7213)],
            ANY, self._args.normal_printer)
        self.assert_next_text([])

    def test_with_one_existing_authorid_in_both_matches_and_database_calls_formatter(self) -> None:
        list_of_tease_matches: list[TeaseMatch] = [
            TeaseMatch(0, fake_teases.TEASE_ID_1234_AUTHOR_ID_6431, []),
            TeaseMatch(1, fake_teases.TEASE_ID_1000_AUTHOR_ID_4567, [])
        ]
        self._args.list_of_tease_matches = list_of_tease_matches
        self._args.formatter.print_all_text_of_list_of_teases = Mock()
        self.command_load_and_execute(['@6431'])
        self._args.formatter.print_all_text_of_list_of_teases.assert_called_once_with(
            [list_of_tease_matches[0], NonIndexedTeaseMatch(fake_teases.TEASE_ID_2000_AUTHOR_ID_6431)],
            ANY, self._args.normal_printer)
        self.assert_next_text([])

    def test_with_one_non_existing_authorid_outputs_error(self) -> None:
        self._args.error_printer = Mock()
        self.command_load_and_execute(['@8312'])
        self._args.error_printer.writeln.assert_has_calls([call("Unable to find author id '8312'"), call('No teases available to show')])
        self.assert_next_text([])

    def test_with_mixed_refids_calls_formatter(self) -> None:
        list_of_tease_matches: list[TeaseMatch] = [
            TeaseMatch(0, fake_teases.TEASE_ID_1234_AUTHOR_ID_6431, []),
            TeaseMatch(1, fake_teases.TEASE_ID_1000_AUTHOR_ID_4567, []),
            TeaseMatch(2, fake_teases.TEASE_ID_8721_AUTHOR_ID_7213, []),
            TeaseMatch(3, fake_teases.TEASE_ID_5678_AUTHOR_ID_4567, [])
        ]
        self._args.list_of_tease_matches = list_of_tease_matches
        self._args.formatter.print_all_text_of_list_of_teases = Mock()
        self.command_load_and_execute(['2', '#2000', '#5678', '1', '@6431'])
        self._args.formatter.print_all_text_of_list_of_teases.assert_called_once_with(
            [list_of_tease_matches[2],
             NonIndexedTeaseMatch(fake_teases.TEASE_ID_2000_AUTHOR_ID_6431),
             list_of_tease_matches[3],
             list_of_tease_matches[1],
             list_of_tease_matches[0],
             NonIndexedTeaseMatch(fake_teases.TEASE_ID_2000_AUTHOR_ID_6431)],
            ANY, self._args.normal_printer)
        self.assert_next_text([])

    def test_highlight_parameter_passed_to_formatter_as_is(self) -> None:
        use_highlighting: bool
        for use_highlighting in (True, False):
            with self.subTest(use_highlight=use_highlighting):
                self.setUp()
                self._args.use_highlighting = use_highlighting
                self._args.formatter.print_all_text_of_list_of_teases = Mock()
                self.command_load_and_execute(['#1000'])
                self._args.formatter.print_all_text_of_list_of_teases.assert_called_once_with(ANY, use_highlighting, self._args.normal_printer)
                self.assert_next_text([])

    def test_with_signed_index_returns_failure(self) -> None:
        self.command_load(['1234', '-5678', '9012'])
        self.assert_argument_error(2, ErrorMessage.INVALID_REFID, [])

    def test_with_signed_teaseid_returns_failure(self) -> None:
        self.command_load(['#1234', '#-5678', '#9012'])
        self.assert_argument_error(2, ErrorMessage.INVALID_TEASEID, [])

    def test_with_signed_authorid_returns_failure(self) -> None:
        self.command_load(['@1234', '@-5678', '@9012'])
        self.assert_argument_error(2, ErrorMessage.INVALID_AUTHORID, [])

    def test_with_non_refid_returns_failure(self) -> None:
        self.command_load(['mango', '5678', '9012'])
        self.assert_argument_error(1, ErrorMessage.INVALID_REFID, [])
