# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from dataclasses import dataclass, field
from milodb.command_framework.i_command import ICommand
from milodb.command_framework.quit_flag import QuitFlag
from milodb.commands.exit_command import ExitCommand
from milodb_test.commands.error_messages import ErrorMessage
from milodb_test.commands.test_command_base import CommandTestBase

@dataclass
class _Args:
    quit_flag: QuitFlag = field(default_factory=QuitFlag)

class TestExitCommand(CommandTestBase):
    def setUp(self) -> None:
        self._args: _Args = _Args()
        return super().setUp()

    def create_command(self) -> ICommand:
        return ExitCommand(
            self._args.quit_flag
        )

    def test_without_arguments_sets_quit_flag(self) -> None:
        self.command_load_and_execute([])
        self.assertTrue(self._args.quit_flag)
        self.assert_next_text([])

    def test_with_redundant_argument_returns_failure(self) -> None:
        self.command_load(['now'])
        self.assert_argument_error(1, ErrorMessage.UNEXPECTED, [])
