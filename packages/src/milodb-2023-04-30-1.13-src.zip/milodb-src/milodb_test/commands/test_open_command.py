# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from dataclasses import dataclass, field
from milodb.command_framework.i_command import ICommand
from milodb.commands.open_command import OpenCommand
from milodb.database.tease import Tease
from milodb.output.print.i_printer import IPrinter
from milodb.query.tease_match import TeaseMatch
from milodb_test.commands import fake_teases
from milodb_test.commands.error_messages import ErrorMessage
from milodb_test.commands.test_command_base import CommandTestBase
from milodb_test.strict_mock import StrictMock

_DEFAULT_LIST_OF_TEASES: list[Tease] = [
    fake_teases.TEASE_ID_1000_AUTHOR_ID_4567,
    fake_teases.TEASE_ID_1234_AUTHOR_ID_6431,
    fake_teases.TEASE_ID_5678_AUTHOR_ID_4567,
    fake_teases.TEASE_ID_2000_AUTHOR_ID_6431,
    fake_teases.TEASE_ID_8721_AUTHOR_ID_7213
]

@dataclass
class _Args:
    list_of_teases: list[Tease] = field(default_factory=_DEFAULT_LIST_OF_TEASES.copy)
    list_of_tease_matches: list[TeaseMatch] = field(default_factory=list)
    normal_printer: StrictMock = field(default_factory=lambda: StrictMock(IPrinter))
    error_printer: StrictMock = field(default_factory=lambda: StrictMock(IPrinter))

class OpenCommandTestBase(CommandTestBase):
    def setUp(self) -> None:
        self._args: _Args = _Args()
        return super().setUp()

    def create_command(self) -> ICommand:
        return OpenCommand(
            self._args.list_of_teases,
            self._args.list_of_tease_matches,
            self._args.normal_printer,
            self._args.error_printer
        )

class TestOpenCommandLoad(OpenCommandTestBase):
    def test_without_arguments_returns_failure(self) -> None:
        self.command_load([])
        self.assert_argument_error(None, ErrorMessage.INSUFFICIENT_EXPECTING_REFID, [])

    def test_with_signed_index_returns_failure(self) -> None:
        self.command_load(['1234', '-5678', '9012'])
        self.assert_argument_error(2, ErrorMessage.INVALID_REFID, [])

    def test_with_signed_teaseid_returns_failure(self) -> None:
        self.command_load(['#1234', '#-5678', '#9012'])
        self.assert_argument_error(2, ErrorMessage.INVALID_TEASEID, [])

    def test_with_signed_authorid_returns_failure(self) -> None:
        self.command_load(['@1234', '@-5678', '@9012'])
        self.assert_argument_error(2, ErrorMessage.INVALID_AUTHORID, [])

    def test_with_non_refid_returns_failure(self) -> None:
        self.command_load(['mango', '5678', '9012'])
        self.assert_argument_error(1, ErrorMessage.INVALID_REFID, [])

# class TestOpenCommandExecute(OpenCommandTestBase):
#     def test_with_one_index_returns_success(self) -> None:
#         self.command_load(['1234'])

#     def test_with_three_indices_returns_success(self) -> None:
#         self.command_load(['1234', '5678', '9012'])

#     def test_with_one_teaseid_returns_success(self) -> None:
#         self.command_load(['#1234'])

#     def test_with_three_teaseids_returns_success(self) -> None:
#         self.command_load(['#1234', '#5678', '#9012'])

#     def test_with_one_authorid_returns_success(self) -> None:
#         self.command_load(['@1234'])

#     def test_with_three_authorids_returns_success(self) -> None:
#         self.command_load(['@1234', '@5678', '@9012'])

#     def test_with_mixed_refids_returns_success(self) -> None:
#         self.command_load(['@1234', '5678', '#9012'])
