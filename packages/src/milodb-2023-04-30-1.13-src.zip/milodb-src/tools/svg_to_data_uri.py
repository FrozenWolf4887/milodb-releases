#!/usr/bin/env python3
# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0

import sys
if sys.version_info >= (3, 10):
    import os
else:
    print("Python version 3.10 or greater required")
    print("Actual version is " + sys.version)
    sys.exit(1)

DATA_PREFIX: str = 'data:image/svg+xml,'
SUBSTITUTIONS: tuple[tuple[str, str], ...] = (
    ('"', "'"),
    ('%', r'%25'),
    ('<', r'%3c'),
    ('>', r'%3e'),
    ('{', r'%7b'),
    ('}', r'%7d'),
    ('#', r'%23')
)

def show_syntax(app_name: str) -> None:
    print((
        f'Syntax: {app_name} input-file\n'
        '    Translates the specified SVG input file to a Data URI that is suitable\n'
        '    for embedding in a webpage. The result is written to stdout.\n'
        'Note:\n'
        '    It is recommended to process the SVG file through the optimiser, svgo,\n'
        '    before using this tool.\n'
        '    svgo is available from: https://github.com/svg/svgo\n'
        'Options:\n'
        '    -h  --help  Show this help'
        ))

def translate_file(filepath: str) -> int:
    try:
        with open(filepath, 'rt', encoding='utf-8') as file:
            file_text: str = file.read()
    except IOError as ex:
        print(f"Error reading from '{filepath}': {ex}", file=sys.stderr)
        return 1

    key: str
    value: str
    for key, value in SUBSTITUTIONS:
        file_text = file_text.replace(key, value)

    print(DATA_PREFIX + file_text)

    return 0

def main(app_name: str, list_of_args: list[str]) -> int:
    if not list_of_args or '-h' in list_of_args or '--help' in list_of_args:
        show_syntax(app_name)
        return 0
    if len(list_of_args) > 1:
        print('Error: Excessive parameters')
        show_syntax(app_name)
        return 1

    return translate_file(list_of_args[0])

if __name__ == "__main__":
    sys.exit(main(os.path.basename(sys.argv[0]), sys.argv[1:]))
