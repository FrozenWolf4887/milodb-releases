@REM MiloDB by FrozenWolf is marked with CC0 1.0.
@REM To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0

@echo off
setlocal

echo ** Prepare virtual environment
python -m venv "%TEMP%\mvdb\venv-terminal" --clear --upgrade-deps
call "%TEMP%\mvdb\venv-terminal\Scripts\activate.bat"

echo ** Install packages
pip install -r requirements-build.txt -r requirements-run-terminal.txt

echo ** Build executable
set PYTHONOPTIMIZE=2
pyinstaller --distpath bin --workpath "%TEMP%\mvdb\build-terminal" --clean milodb-terminal.spec

echo ** Dump requirements
pip freeze

call "%TEMP%\mvdb\venv-terminal\Scripts\deactivate.bat"
