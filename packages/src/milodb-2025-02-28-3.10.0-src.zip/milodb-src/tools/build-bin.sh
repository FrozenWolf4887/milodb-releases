#!/bin/bash
# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0

set -e

echo "** Prepare virtual environment"
python -m venv /tmp/mvdb/venv-terminal --clear --upgrade-deps
# shellcheck disable=SC1091
source /tmp/mvdb/venv-terminal/bin/activate

echo "** Install packages"
pip install -r requirements-build.txt -r requirements-run-terminal.txt

echo "** Build executable"
PYTHONOPTIMIZE=2 pyinstaller --distpath bin --workpath /tmp/mvdb/build-terminal --clean milodb-terminal.spec

echo "** Dump requirements"
pip freeze
