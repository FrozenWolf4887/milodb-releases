# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
import os
import subprocess
import sys
from abc import ABC, abstractmethod
from collections.abc import Iterable
from pathlib import Path
from typing import override
from milodb_client.startup.command_line import Argument
from milodb_client.view.i_log_display import ILogDisplay

class IShutdownAction(ABC):
    @abstractmethod
    def perform_action(self, log_display : ILogDisplay) -> int:
        pass

class RestartToPerformUpdateAction(IShutdownAction):
    def __init__(self, *, temp_application_filepath: Path, update_sequence_filepath: Path) -> None:
        self._temp_application_filepath: Path = temp_application_filepath
        self._update_sequence_filepath: Path = update_sequence_filepath

    @override
    def perform_action(self, log_display: ILogDisplay) -> int:
        log_display.normal_printer.writeln('Restarting application to perform update...')
        return _launch(self._temp_application_filepath, [Argument.PERFORM_UPDATE, self._update_sequence_filepath], log_display)

class RestartToCompleteUpdateAction(IShutdownAction):
    def __init__(self, *, new_application_filepath: Path, temp_application_filepath: Path, update_sequence_filepath: Path, temp_directory: Path) -> None:
        self._new_application_filepath: Path = new_application_filepath
        self._temp_application_filepath: Path = temp_application_filepath
        self._update_sequence_filepath: Path = update_sequence_filepath
        self._temp_directory: Path = temp_directory

    @override
    def perform_action(self, log_display: ILogDisplay) -> int:
        log_display.normal_printer.writeln('Restarting application to complete update...')
        return _launch(self._new_application_filepath, [Argument.PURGE_TEMP_DIRECTORY, self._temp_directory], log_display)

def _launch(application_filepath: Path, command_line: Iterable[str | Path], log_display: ILogDisplay) -> int:
    if sys.platform == 'win32':
        log_display.normal_printer.writeln(f"Launching win32 '{application_filepath}'")
        try:
            subprocess.Popen( # pylint: disable=consider-using-with # noqa: S603 `subprocess` call: check for execution of untrusted input
                [application_filepath, Argument.WAIT_PID, str(os.getpid()), *command_line],
                start_new_session=True,
                creationflags=subprocess.CREATE_NEW_CONSOLE)
        except OSError as ex:
            log_display.print_fatal_and_prompt_to_continue(f'Failed to start win32 application: {ex}')
            return 1
    else:
        log_display.normal_printer.writeln(f"Launching POSIX '{application_filepath}'")
        try:
            # Note: Ruff error S606 suggests to use subprocess.Popen(), but that can't do the same thing as os.execv() which
            #       replaces the currently running executable with the new one.
            os.execv(application_filepath, (application_filepath, *command_line)) # noqa: S606 Starting a process without a shell
        except OSError as ex:
            log_display.print_fatal_and_prompt_to_continue(f'Failed to start posix application: {ex}')
            return 1

    return 0
