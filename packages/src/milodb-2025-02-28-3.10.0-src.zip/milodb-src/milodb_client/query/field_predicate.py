# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
import datetime
from abc import abstractmethod
from collections.abc import Callable
from milodb_client.database.tease import TeaseDateProperty, TeaseFloatProperty, TeaseIntProperty, TeaseStrListProperty, TeaseStrProperty, TeaseTypeProperty
from milodb_client.query.query import IQuery
from milodb_common.parser.expanding_token_stream import ExpandingTokenStream
from milodb_common.types.partial_date import PartialDate

class IFieldFloatPredicate(IQuery):
    @abstractmethod
    def __init__(self, tease_property: TeaseFloatProperty, token_stream: ExpandingTokenStream, compare_func: Callable[[float, float], bool]) -> None:
        pass

class IFieldIntPredicate(IQuery):
    @abstractmethod
    def __init__(self, tease_property: TeaseIntProperty, token_stream: ExpandingTokenStream, compare_func: Callable[[int, int], bool]) -> None:
        pass

class IFieldStrPredicate(IQuery):
    @abstractmethod
    def __init__(self, tease_property: TeaseStrProperty, token_stream: ExpandingTokenStream) -> None:
        pass

class IFieldStrListPredicate(IQuery):
    @abstractmethod
    def __init__(self, tease_property: TeaseStrListProperty, token_stream: ExpandingTokenStream) -> None:
        pass

class IFieldTypePredicate(IQuery):
    @abstractmethod
    def __init__(self, tease_property: TeaseTypeProperty, token_stream: ExpandingTokenStream) -> None:
        pass

class IFieldDatePredicate(IQuery):
    @abstractmethod
    def __init__(self, tease_property: TeaseDateProperty, token_stream: ExpandingTokenStream, compare_func: Callable[[datetime.date, PartialDate], bool]) -> None:
        pass

class IFieldTotmPredicate(IQuery):
    @abstractmethod
    def __init__(self, token_stream: ExpandingTokenStream) -> None:
        pass

class IFieldStatusPredicate(IQuery):
    @abstractmethod
    def __init__(self, token_stream: ExpandingTokenStream) -> None:
        pass

class IFieldAuthorStatusPredicate(IQuery):
    @abstractmethod
    def __init__(self, token_stream: ExpandingTokenStream) -> None:
        pass

class IFieldPageListPredicate(IQuery):
    @abstractmethod
    def __init__(self, token_stream: ExpandingTokenStream) -> None:
        pass
