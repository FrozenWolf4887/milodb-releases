# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from abc import ABC, abstractmethod
from collections.abc import MutableSequence
from milodb_client.database.tease import Tease
from milodb_client.query.match_result import IMatchResult

class IQuery(ABC):
    @abstractmethod
    def perform_query(self, stack_of_match_results: MutableSequence[IMatchResult], tease: Tease) -> None:
        pass
