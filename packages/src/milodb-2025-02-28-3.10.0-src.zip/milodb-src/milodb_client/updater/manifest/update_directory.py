# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from __future__ import annotations
from abc import ABC, abstractmethod
from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from collections.abc import Mapping
    from milodb_client.updater.manifest.common_manifest import IHexDigest

class IUpdateDirectory(ABC):
    @property
    @abstractmethod
    def format(self) -> int:
        pass

    @property
    @abstractmethod
    def version_manifest_uri(self) -> str:
        pass

    @property
    @abstractmethod
    def asset_register(self) -> IAssetRegister:
        pass

class IAssetRegister(ABC):
    @property
    @abstractmethod
    def template_asset_uri(self) -> str | None:
        pass

    @property
    @abstractmethod
    def assets(self) -> Mapping[IHexDigest, IAsset]:
        pass

    @abstractmethod
    def resolve_asset_uri(self, host_uri: str, digest: IHexDigest) -> str | None:
        pass

class IAsset(ABC):
    @property
    @abstractmethod
    def digest(self) -> IHexDigest:
        pass

    @property
    @abstractmethod
    def uri(self) -> str | None:
        pass

    @property
    @abstractmethod
    def identifier(self) -> str | None:
        pass

    @property
    @abstractmethod
    def size(self) -> int:
        pass
