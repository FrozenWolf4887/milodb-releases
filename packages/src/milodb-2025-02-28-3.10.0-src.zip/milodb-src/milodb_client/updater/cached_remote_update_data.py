# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from __future__ import annotations
import json
import urllib.parse
from typing import TYPE_CHECKING
from milodb_client.updater.manifest.i_schema_types import IItem, SchemaLoadError
from milodb_client.updater.manifest.update_directory_schema import UpdateDirectorySchema
from milodb_client.updater.manifest.version_manifest_schema import VersionManifestSchema
if TYPE_CHECKING:
    from milodb_client.updater.manifest.update_directory import IUpdateDirectory
    from milodb_client.updater.manifest.version_manifest import IVersionManifest
    from milodb_common.internet.i_uri_scraper import IUriScraper
    from milodb_common.internet.i_uri_scraper_factory import IUriScraperFactory
    from milodb_common.internet.scrape_result import ScrapeResult
    from milodb_common.output.print.i_printer import IPrinter

class CachedRemoteUpdateData:
    _cached_update_directory: IUpdateDirectory | None = None
    _cached_version_manifest: IVersionManifest | None = None

    def __init__(self, update_directory: IUpdateDirectory, version_manifest: IVersionManifest) -> None:
        self._update_directory: IUpdateDirectory = update_directory
        self._version_manifest: IVersionManifest = version_manifest

    @property
    def update_directory(self) -> IUpdateDirectory:
        return self._update_directory

    @property
    def version_manifest(self) -> IVersionManifest:
        return self._version_manifest

    @staticmethod
    def fetch(update_directory_uri: str, uri_scraper_factory: IUriScraperFactory, normal_printer: IPrinter, error_printer: IPrinter) -> CachedRemoteUpdateData | None:
        uri_scraper: IUriScraper
        with uri_scraper_factory.new_pool(normal_printer.writeln) as uri_scraper:
            if not CachedRemoteUpdateData._cached_update_directory:
                try:
                    CachedRemoteUpdateData._cached_update_directory = _fetch_schema_file(UpdateDirectorySchema(), 'update directory', update_directory_uri, uri_scraper, normal_printer)
                except _FetchSchemaError as ex:
                    error_printer.writeln(str(ex))
            else:
                normal_printer.writeln('Reusing cached update directory')

            if not CachedRemoteUpdateData._cached_version_manifest and CachedRemoteUpdateData._cached_update_directory:
                version_manifest_uri: str = urllib.parse.urljoin(update_directory_uri, CachedRemoteUpdateData._cached_update_directory.version_manifest_uri)
                try:
                    CachedRemoteUpdateData._cached_version_manifest = _fetch_schema_file(VersionManifestSchema(), 'version manifest', version_manifest_uri, uri_scraper, normal_printer)
                except _FetchSchemaError as ex:
                    error_printer.writeln(str(ex))
            else:
                normal_printer.writeln('Reusing cached version manifest')

        if CachedRemoteUpdateData._cached_update_directory and CachedRemoteUpdateData._cached_version_manifest:
            return CachedRemoteUpdateData(CachedRemoteUpdateData._cached_update_directory, CachedRemoteUpdateData._cached_version_manifest)

        return None

class _FetchSchemaError(Exception):
    pass

def _fetch_schema_file[T: IItem](schema: T, name_of_schema: str, uri: str, uri_scraper: IUriScraper, printer: IPrinter) -> T:
    printer.writeln(f'Fetching {name_of_schema}')

    scrape_result: ScrapeResult = uri_scraper.try_scrape(uri, lambda msg: printer.writeln(f'  {msg}'))
    if scrape_result.error_message:
        msg = f"Failed to fetch {name_of_schema} from '{uri}': {scrape_result.error_message}"
        raise _FetchSchemaError(msg)

    try:
        json_root: object = json.loads(scrape_result.content)
    except json.JSONDecodeError as ex:
        msg = f"{name_of_schema.capitalize()} '{uri}' could not be parsed as JSON: {ex}"
        raise _FetchSchemaError(msg) from ex

    try:
        schema.load(json_root)
    except SchemaLoadError as ex:
        msg = f"{name_of_schema.capitalize()} '{uri}' error: {ex}"
        raise _FetchSchemaError(msg) from ex

    return schema
