# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from collections.abc import Sequence
from typing import override
from milodb_client.query.tease_match import TeaseMatch
from milodb_client.util.sort_keys import AUTHOR_ID_SORT_KEY, DATE_SORT_KEY, ISortKey, MATCH_COUNT_SORT_KEY, OrderedSortKey, RATING_SORT_KEY, TEASE_ID_SORT_KEY, TITLE_SORT_KEY, TOTM_SORT_KEY, TYPE_SORT_KEY
from milodb_client.util.sort_keys import SortCompareResult

class NamedSortKey(ISortKey):
    def __init__(self, name: str, sort_key: ISortKey, description: str) -> None:
        self._name: str = name
        self._sort_key: ISortKey = sort_key
        self._description: str = description

    @property
    def name(self) -> str:
        return self._name

    @property
    def description(self) -> str:
        return self._description

    @override
    def compare(self, left: TeaseMatch, right: TeaseMatch) -> SortCompareResult:
        return self._sort_key.compare(left, right)

class OrderedNamedSortKey(OrderedSortKey):
    def __init__(self, named_sort_key: NamedSortKey, *, is_ascending: bool) -> None:
        super().__init__(named_sort_key, is_ascending=is_ascending)
        self._named_sort_key: NamedSortKey = named_sort_key

    @property
    def named_sort_key(self) -> NamedSortKey:
        return self._named_sort_key

NAMED_TEASE_ID_SORT_KEY = NamedSortKey('teaseId', TEASE_ID_SORT_KEY, 'Numerical id of the tease')
NAMED_AUTHOR_ID_SORT_KEY = NamedSortKey('authorId', AUTHOR_ID_SORT_KEY, 'Numerical id of the author')
NAMED_DATE_SORT_KEY = NamedSortKey('date', DATE_SORT_KEY, 'Published date of the tease')
NAMED_TITLE_SORT_KEY = NamedSortKey('title', TITLE_SORT_KEY, 'Title of the tease')
NAMED_RATING_SORT_KEY = NamedSortKey('rating', RATING_SORT_KEY, 'Value rating of the tease')
NAMED_TYPE_SORT_KEY = NamedSortKey('type', TYPE_SORT_KEY, 'EOS, regular, audio, etc. tease type')
NAMED_TOTM_SORT_KEY = NamedSortKey('totm', TOTM_SORT_KEY, 'Tease-Of-The-Month nominees and winners')
NAMED_MATCH_COUNT_SORT_KEY = NamedSortKey('hits', MATCH_COUNT_SORT_KEY, 'Number of tease field matches from the last query')

LIST_OF_AVAILABLE_SORT_KEYS: Sequence[NamedSortKey] = [
    NAMED_TEASE_ID_SORT_KEY,
    NAMED_AUTHOR_ID_SORT_KEY,
    NAMED_DATE_SORT_KEY,
    NAMED_TITLE_SORT_KEY,
    NAMED_RATING_SORT_KEY,
    NAMED_TYPE_SORT_KEY,
    NAMED_TOTM_SORT_KEY,
    NAMED_MATCH_COUNT_SORT_KEY,
]
