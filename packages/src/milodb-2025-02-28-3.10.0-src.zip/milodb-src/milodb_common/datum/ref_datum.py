# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
class RefDatum[T]:
    def __init__(self, default: T) -> None:
        self._ref: T = default

    def set(self, ref: T) -> None:
        self._ref = ref

    def get(self) -> T:
        return self._ref

    def __bool__(self) -> bool:
        return bool(self._ref)
