# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from collections.abc import Callable
from pathlib import Path
from typing import override
from urllib.request import url2pathname
from milodb_common.internet.i_path_scraper import IPathScraper
from milodb_common.internet.scrape_result import ScrapeResult

class FilePathScraper(IPathScraper):
    @override
    def try_scrape(self, filepath: str, progress_callback: Callable[[str], None] | None) -> ScrapeResult:
        decoded_filepath: Path = Path(url2pathname(filepath))
        if progress_callback:
            progress_callback(f"Reading file '{decoded_filepath}'")

        try:
            content: bytes = decoded_filepath.read_bytes()
        except OSError as ex:
            return ScrapeResult(f"Cannot read from file '{decoded_filepath}': {ex}", None, b'')

        if progress_callback:
            progress_callback(f'Read {len(content):,} bytes')

        return ScrapeResult(None, None, content)

    @override
    def close(self, progress_callback: Callable[[str], None] | None) -> None:
        """There is no connection to close."""
