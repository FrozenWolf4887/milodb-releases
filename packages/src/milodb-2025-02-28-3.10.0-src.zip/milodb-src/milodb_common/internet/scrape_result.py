# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from dataclasses import dataclass

@dataclass
class ScrapeResult:
    error_message: str | None
    redirection_uri: str | None
    content: bytes
