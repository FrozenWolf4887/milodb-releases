# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from abc import abstractmethod
from types import TracebackType
from milodb_common.internet.i_uri_scraper import IUriScraper

class IUriScraperPool:
    @abstractmethod
    def __enter__(self) -> IUriScraper:
        pass

    @abstractmethod
    def __exit__(self, exc_type: type[BaseException] | None, exc_value: BaseException | None, traceback: TracebackType | None) -> None:
        pass
