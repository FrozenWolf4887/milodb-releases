# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
import sys
from collections.abc import MutableMapping
from enum import Enum
from milodb_client.config.config_schema import CONFIG_SCHEMA
from milodb_common.output.print.i_printer import IPrinter

class ConfigMigrationResult(Enum):
    NOT_NEEDED = 0
    FAILED = 1
    SUCCESSFUL = 2

def try_migrate_config(config_dict: MutableMapping[object, object], normal_printer: IPrinter, error_printer: IPrinter) -> ConfigMigrationResult:
    config_version: object = config_dict.get(CONFIG_SCHEMA.version.key_name)
    if not isinstance(config_version, str):
        error_printer.writeln(f"Unable to identify current config version because key '{CONFIG_SCHEMA.version.full_path}' is missing or not text")
        return ConfigMigrationResult.FAILED

    match config_version:
        case '1':
            normal_printer.writeln('Migrating config file from v1 to v2')
            return _MigrateConfigV1toV2(error_printer).run(config_dict)
        case '2':
            return ConfigMigrationResult.NOT_NEEDED
        case _:
            error_printer.writeln(f"Unknown config file version '{config_version}' specified by key '{CONFIG_SCHEMA.version.full_path}'")
            return ConfigMigrationResult.FAILED

class _MigrateConfigV1toV2:
    def __init__(self, error_printer: IPrinter) -> None:
        self._error_printer: IPrinter = error_printer
        self._was_successful: bool = True

    def run(self, config_dict: MutableMapping[object, object]) -> ConfigMigrationResult:
        platform_key_name: str = 'windows' if sys.platform == 'win32' else 'linux'
        self._create_group(config_dict, f'commands/browse/{platform_key_name}')
        self._move_key(config_dict, 'commands/browse/customLaunchCommand', f'commands/browse/{platform_key_name}/customLaunchCommand')
        self._move_key(config_dict, 'commands/browse/launchOption', f'commands/browse/{platform_key_name}/launchOption')
        self._create_group(config_dict, f'commands/open/{platform_key_name}')
        self._move_key(config_dict, 'commands/open/customLaunchCommand', f'commands/open/{platform_key_name}/customLaunchCommand')
        self._move_key(config_dict, 'commands/open/launchOption', f'commands/open/{platform_key_name}/launchOption')
        self._set_key(config_dict, CONFIG_SCHEMA.version.full_path, '2')
        return ConfigMigrationResult.SUCCESSFUL if self._was_successful else ConfigMigrationResult.FAILED

    def _create_group(self, config_dict: MutableMapping[object, object], path: str) -> None:
        current_group: MutableMapping[object, object] = config_dict
        part: str
        for part in path.split('/'):
            group: object = current_group.get(part)
            if group is None:
                group = {}
                current_group[part] = group
            elif not isinstance(group, dict):
                self._was_successful = False
                self._error_printer.writeln(f"Failed to create group '{path}' because part '{part}' already exists and is not a group")
                return
            current_group = group

    def _move_key(self, config_dict: MutableMapping[object, object], source_path: str, target_path: str) -> None:
        source_path_group: str
        source_path_key: str
        source_path_group, source_path_key = _split_group_and_key(source_path)
        target_path_group: str
        target_path_key: str
        target_path_group, target_path_key = _split_group_and_key(target_path)

        source_group: MutableMapping[object, object] | None = self._try_find_group(config_dict, source_path_group)
        if source_group is not None:
            target_group: MutableMapping[object, object] | None = self._try_find_group(config_dict, target_path_group)
            if target_group is not None:
                value: object = source_group.pop(source_path_key, None)
                if value is not None:
                    target_group[target_path_key] = value
            else:
                self._was_successful = False
                self._error_printer.writeln(f"Failed to find group '{target_path}'")

    def _set_key(self, config_dict: MutableMapping[object, object], path: str, value: str) -> None:
        path_group: str
        path_key: str
        path_group, path_key = _split_group_and_key(path)
        group: MutableMapping[object, object] | None = self._try_find_group(config_dict, path_group)
        if group is not None:
            group[path_key] = value
        else:
            self._was_successful = False
            self._error_printer.writeln(f"Failed to find group '{path}'")

    def _try_find_group(self, config_dict: MutableMapping[object, object], path: str) -> MutableMapping[object, object] | None:
        if not path:
            return config_dict

        current_group: MutableMapping[object, object] = config_dict
        part: str
        for part in path.split('/'):
            group: object = current_group.get(part)
            if group is None:
                return None
            if not isinstance(group, dict):
                self._was_successful = False
                self._error_printer.writeln(f"Failed to find group '{path}' because part '{part}' is not a group")
                return None
            current_group = group
        return current_group

_TWO_PARTS: int = 2

def _split_group_and_key(path: str) -> tuple[str, str]:
    split: list[str] = path.rsplit('/', 1)
    if len(split) < _TWO_PARTS:
        return '', split[0]
    return split[0], split[1]
