# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
import sys
from collections.abc import Iterable, Sequence
from milodb_client.commands.database_support import try_create_list_of_tease_matches_from_ref_ids
from milodb_client.commands.launcher import launch
from milodb_client.config.commands_config import ILaunchConfig
from milodb_client.config.config_schema import CONFIG_SCHEMA, CommandLaunchOption
from milodb_client.config.framework import IConfigEnumLeaf, IConfigLeaf
from milodb_client.database.tease import Tease
from milodb_client.output.support import get_url_of_author, get_url_of_tease
from milodb_client.query.tease_match import TeaseMatch
from milodb_common.command_framework.argument_stream import ArgumentStream
from milodb_common.command_framework.i_command import CommandLoaderResult
from milodb_common.command_framework.i_help_info import IHelpInfo
from milodb_common.command_framework.ref_id import AuthorId, RefId
from milodb_common.commands import enums
from milodb_common.output.print.i_printer import IPrinter

_CONFIG_LAUNCH_OPTION: IConfigEnumLeaf[CommandLaunchOption] = \
    CONFIG_SCHEMA.commands.open.windows.launch_option if sys.platform == 'win32' else \
    CONFIG_SCHEMA.commands.open.linux.launch_option
_CONFIG_LAUNCH_COMMAND: IConfigLeaf = \
    CONFIG_SCHEMA.commands.open.windows.custom_launch_command if sys.platform == 'win32' else \
    CONFIG_SCHEMA.commands.open.linux.custom_launch_command

_CONFIG_HELP_TEXT: str = (
    "Config:\r"
    f"  * \t'{_CONFIG_LAUNCH_OPTION.full_path}'\r"
    "    \tDetermines how the web browser is launched to open the links. The options"
    f" are {enums.lowercase_names(_CONFIG_LAUNCH_OPTION.enum_class)}.\r"
    f"  * \t'{_CONFIG_LAUNCH_COMMAND.full_path}'\r"
    f"    \tWhen '{_CONFIG_LAUNCH_OPTION.key_name}' is set to"
    f" '{_CONFIG_LAUNCH_OPTION.enum_class.CUSTOM.name.lower()}'"
    " this specifies the custom command to be executed where the following symbol can be"
    " specified:\r"
    "      $u  \tURI to the tease or author's profile"
)

def load(argument_stream: ArgumentStream, list_of_teases: Iterable[Tease], list_of_tease_matches: Iterable[TeaseMatch], launch_config: ILaunchConfig, normal_printer: IPrinter, error_printer: IPrinter) -> CommandLoaderResult:
    list_of_ref_ids: list[RefId] = []
    list_of_author_ids: list[int] = []

    ref_id: RefId
    for ref_id in ArgumentStream.pop_minimum_list(1, argument_stream.pop_ref_id, argument_stream.pop_optional_ref_id):
        if isinstance(ref_id, AuthorId):
            list_of_author_ids.append(ref_id.author_id)
        else:
            list_of_ref_ids.append(ref_id)

    return CommandLoaderResult(
        lambda: execute(list_of_ref_ids, list_of_author_ids, list_of_teases, list_of_tease_matches, launch_config, normal_printer, error_printer),
        [],
    )

def execute(list_of_ref_ids: Iterable[RefId], list_of_author_ids: Iterable[int], list_of_teases: Iterable[Tease], list_of_tease_matches: Iterable[TeaseMatch], launch_config: ILaunchConfig, normal_printer: IPrinter, error_printer: IPrinter) -> None:
    list_of_tease_matches_to_open: Sequence[TeaseMatch] | None = None
    is_ref_id_list_reasonable: bool = True
    if list_of_ref_ids:
        list_of_tease_matches_to_open = try_create_list_of_tease_matches_from_ref_ids(list_of_teases, list_of_tease_matches, list_of_ref_ids, error_printer)

        if list_of_tease_matches_to_open:
            tease_match: TeaseMatch
            for tease_match in list_of_tease_matches_to_open:
                tease_url: str = get_url_of_tease(tease_match.tease.tease_id())
                normal_printer.writeln(f"Opening '{tease_match.tease.title()}'")
                launch(launch_config, None, tease_url, normal_printer)
        else:
            error_printer.writeln("No teases available to open")
            is_ref_id_list_reasonable = False

    if is_ref_id_list_reasonable:
        for author_id in list_of_author_ids:
            author_url: str = get_url_of_author(author_id)
            launch(launch_config, None, author_url, normal_printer)

class Help(IHelpInfo):
    def get_one_line_summary(self) -> str:
        return "Opens a specified tease or author profile in a web browser"

    def get_detailed_summary(self) -> str:
        return (
            "Arguments: <list of RefIds>\n"
            "Opens one or more teases or author profiles in a web browser from the list of"
            " RefIds. This effectively opens the link to the original tease or author profile on"
            " Milovana.\n"
            "RefIds can be an index into the list of matches such as '3', a teaseId such as"
            " '#38664', or an authorId such as '@43937'.\n"
            f"{_CONFIG_HELP_TEXT}\n"
            "Example:\r"
            "  \tOpen a tease by index in the match list\r"
            "  > \topen 3\r"
            "Example:\r"
            "  \tOpen a tease by its specific teaseId\r"
            "  > \topen #16830\r"
            "Example:\r"
            "  \tOpen the profile of a specific authorId\r"
            "  > \topen @43937\n"
            "See also:\r"
            "  \topenauthor, url, urlauthor"
        )
