# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from abc import ABC, abstractmethod
from collections.abc import Callable
from milodb_common.internet.i_uri_scraper_pool import IUriScraperPool

class IUriScraperFactory(ABC):
    @abstractmethod
    def new_pool(self, close_callback: Callable[[str], None] | None = None) -> IUriScraperPool:
        pass
