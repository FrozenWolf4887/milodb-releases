# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from abc import ABC, abstractmethod
from collections.abc import Callable
from dataclasses import dataclass
from milodb_common.internet.scrape_result import ScrapeResult

class IUriScraper(ABC):
    @dataclass
    class Result:
        error_message: str | None
        content: bytes

    @abstractmethod
    def try_scrape(self, url: str, progress_callback: Callable[[str], None] | None) -> ScrapeResult:
        pass

    @abstractmethod
    def close(self, progress_callback: Callable[[str], None] | None) -> None:
        pass
