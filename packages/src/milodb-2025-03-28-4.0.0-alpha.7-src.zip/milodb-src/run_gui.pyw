#!/usr/bin/env python3
# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/

import sys
if sys.version_info < (3, 12):
    print("Python version 3.12 or greater required")
    print("Actual version is " + sys.version)
    sys.exit(1)

# pylint: disable=wrong-import-position
from collections.abc import Sequence
from typing import NoReturn, TYPE_CHECKING
from milodb_client.startup.startup import StartupResult, startup
from milodb_client.view.gui.main_gui import MainGui
from milodb_client.view.gui.popup_log_display import PopupLogDisplay
if TYPE_CHECKING:
    from milodb_client.startup.shutdown_action import IShutdownAction
# pylint: enable=wrong-import-position

def _main(list_of_args: Sequence[str]) -> NoReturn:
    exit_code: int = 0

    log_display: PopupLogDisplay
    with PopupLogDisplay() as log_display:
        startup_result: StartupResult
        startup_result, _ = startup(list_of_args, log_display)
        if startup_result.shutdown_action:
            exit_code = startup_result.shutdown_action.perform_action(log_display)
        else:
            exit_code = startup_result.exit_code

        main_gui: MainGui | None = None
        if startup_result.run_main_application:
            main_gui = MainGui(log_display)

    if main_gui:
        shutdown_action: IShutdownAction | None = main_gui.run()
        if shutdown_action:
            with PopupLogDisplay() as log_display:
                exit_code = shutdown_action.perform_action(log_display)

    sys.exit(exit_code)

if __name__ == "__main__":
    _main(sys.argv[1:])
