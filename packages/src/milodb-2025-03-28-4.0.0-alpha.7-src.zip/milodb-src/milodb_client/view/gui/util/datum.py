# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from __future__ import annotations
from abc import abstractmethod
from collections.abc import Callable
from dataclasses import dataclass
from typing import override
from milodb_common.util.ref import IRef

class IDatum[T](IRef[T]):
    @abstractmethod
    def add_listener(self, listener: Callable[[], None], *, call_immediately: bool=False) -> None:
        pass

    @abstractmethod
    def add_value_listener(self, listener: Callable[[T], None], *, call_immediately: bool=False) -> None:
        pass

    @abstractmethod
    def remove_listener(self, listener: _Callback[T]) -> None:
        pass

class SimpleDatum[T](IDatum[T]):
    def __init__(self, default: T) -> None:
        self._ref: T = default
        self._list_of_listeners: list[_CallbackWrapper[T]] = []

    @override
    def set(self, ref: T) -> None:
        if self._ref != ref:
            self._ref = ref
            listener: _CallbackWrapper[T]
            for listener in self._list_of_listeners:
                match listener:
                    case _BasicCallbackWrapper():
                        listener.callback()
                    case _ValueCallbackWrapper():
                        listener.callback(self._ref)

    @override
    def get(self) -> T:
        return self._ref

    @override
    def __bool__(self) -> bool:
        return bool(self._ref)

    @override
    def add_listener(self, listener: Callable[[], None], *, call_immediately: bool=False) -> None:
        self._list_of_listeners.append(_BasicCallbackWrapper(listener))
        if call_immediately:
            listener()

    @override
    def add_value_listener(self, listener: Callable[[T], None], *, call_immediately: bool=False) -> None:
        self._list_of_listeners.append(_ValueCallbackWrapper(listener))
        if call_immediately:
            listener(self._ref)

    @override
    def remove_listener(self, listener: _Callback[T]) -> None:
        self._list_of_listeners = [
            callback_wrapper for callback_wrapper in self._list_of_listeners if callback_wrapper.callback is not listener
        ]

class SuppressingDatum[T](IDatum[T]):
    def __init__(self, proxy_datum: IDatum[T]) -> None:
        self._proxy_datum: IDatum[T] = proxy_datum
        self._is_observing_proxy: bool = False
        self._list_of_listeners: list[_CallbackWrapper[T]] = []
        self._suppress_callbacks: bool = False

    @override
    def set(self, ref: T) -> None:
        self._suppress_callbacks = True
        self._proxy_datum.set(ref)
        self._suppress_callbacks = False

    @override
    def get(self) -> T:
        return self._proxy_datum.get()

    @override
    def __bool__(self) -> bool:
        return bool(self._proxy_datum)

    @override
    def add_listener(self, listener: Callable[[], None], *, call_immediately: bool=False) -> None:
        self._list_of_listeners.append(_BasicCallbackWrapper(listener))
        if not self._is_observing_proxy:
            self._proxy_datum.add_value_listener(self._on_proxy_value_changed)
            self._is_observing_proxy = True
        if call_immediately:
            listener()

    @override
    def add_value_listener(self, listener: Callable[[T], None], *, call_immediately: bool=False) -> None:
        self._list_of_listeners.append(_ValueCallbackWrapper(listener))
        if not self._is_observing_proxy:
            self._proxy_datum.add_value_listener(self._on_proxy_value_changed)
            self._is_observing_proxy = True
        if call_immediately:
            listener(self._proxy_datum.get())

    @override
    def remove_listener(self, listener: _Callback[T]) -> None:
        self._list_of_listeners = [
            existing_listener for existing_listener in self._list_of_listeners if existing_listener.callback is not listener
        ]
        if not self._list_of_listeners and self._is_observing_proxy:
            self._proxy_datum.remove_listener(self._on_proxy_value_changed)
            self._is_observing_proxy = False

    def _on_proxy_value_changed(self, value: T) -> None:
        if not self._suppress_callbacks:
            listener: _CallbackWrapper[T]
            for listener in self._list_of_listeners:
                match listener:
                    case _BasicCallbackWrapper():
                        listener.callback()
                    case _ValueCallbackWrapper():
                        listener.callback(value)

@dataclass
class _BasicCallbackWrapper:
    callback: Callable[[], None]

@dataclass
class _ValueCallbackWrapper[T]:
    callback: Callable[[T], None]

type _Callback[T] = Callable[[], None] | Callable[[T], None]
type _CallbackWrapper[T] = _BasicCallbackWrapper | _ValueCallbackWrapper[T]
