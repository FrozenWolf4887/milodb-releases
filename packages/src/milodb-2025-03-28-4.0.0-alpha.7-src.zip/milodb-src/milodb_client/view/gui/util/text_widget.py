# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import idlelib.redirector # type: ignore[import-not-found]
import tkinter as tk

def set_text_readonly(text: tk.Text) -> None:
    redirector = idlelib.redirector.WidgetRedirector(text)
    text.insert = redirector.register('insert', lambda *_args, **_kw: 'break') # type: ignore[method-assign]
    text.delete = redirector.register('delete', lambda *_args, **_kw: 'break') # type: ignore[method-assign]
