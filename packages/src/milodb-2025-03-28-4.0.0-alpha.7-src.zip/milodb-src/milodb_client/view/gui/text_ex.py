# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import contextlib
import tkinter as tk
from idlelib.redirector import OriginalCommand, WidgetRedirector # type: ignore[import-not-found]
from typing import Any, TYPE_CHECKING
if TYPE_CHECKING:
    from collections.abc import Sequence

# spell-checker: ignore underlinefg

class TextEx(tk.Text):
    CARET_MOVED_BINDING: str = '<<CaretMoved>>'
    TEXT_CHANGED_BINDING: str = '<<TextChanged>>'

    def __init__(self, master: tk.Widget, **kwargs: Any) -> None: # noqa: ANN401 Dynamically typed expressions (typing.Any) are disallowed:
        super().__init__(master, **kwargs, height=1, wrap='none')

        self._caret_index: int = 0

        self.bind('<Return>', lambda _event: 'break')
        self.bind('<Tab>', self._on_tab)
        self.bind('<<Paste>>', self._on_paste)
        self.bind('<<PasteSelection>>', self._on_paste)

        self.event_add(self.CARET_MOVED_BINDING, 'None')
        self.event_add(self.TEXT_CHANGED_BINDING, 'None')

        redirector = WidgetRedirector(self)
        self._original_on_mark: OriginalCommand = redirector.register("mark", self._on_mark)
        self._original_on_insert: OriginalCommand = redirector.register("insert", self._on_insert)
        self._original_on_delete: OriginalCommand = redirector.register("delete", self._on_delete)

        self.tag_config('err', foreground='#F88', underline=True, underlinefg='#F88')

    def get_text(self) -> str:
        text: str = self.get('1.0', tk.END)
        return text[:len(text) - 1]

    def get_caret_index(self) -> int:
        return self._caret_index

    def clear_error(self) -> None:
        self.tag_remove('err', '1.0', tk.END)

    def show_error(self, begin_index: int, end_index: int | None = None) -> None:
        self.clear_error()
        self.tag_add('err', f'1.{begin_index}', f'1.{end_index if end_index is not None else begin_index+1}')

    def _on_mark(self, *args: object) -> OriginalCommand:
        original_command: OriginalCommand = self._original_on_mark(*args)
        self._update_caret()
        return original_command

    def _on_insert(self, *args: object) -> OriginalCommand:
        original_command: OriginalCommand = self._original_on_insert(*args)
        if len(args) == 2 and args[1]: # noqa: PLR2004 Magic value used in comparison
            self.event_generate(self.TEXT_CHANGED_BINDING)
        self._update_caret()
        return original_command

    def _on_delete(self, *args: object) -> OriginalCommand:
        original_command: OriginalCommand = self._original_on_delete(*args)
        self.event_generate(self.TEXT_CHANGED_BINDING)
        self._update_caret()
        return original_command

    def _get_caret_index(self) -> int:
        cursor_index_text: str = self.index(tk.INSERT)
        if cursor_index_text:
            list_of_values: Sequence[str] = cursor_index_text.rsplit('.', maxsplit=1)
            if list_of_values:
                with contextlib.suppress(ValueError):
                    return int(list_of_values[-1])
        return 0

    def _update_caret(self) -> None:
        caret_index: int = self._get_caret_index()
        if caret_index != self._caret_index:
            self._caret_index = caret_index
            self.event_generate(self.CARET_MOVED_BINDING)

    def _on_tab(self, _: object) -> str:
        next_control: tk.Misc | None = self.tk_focusNext()
        if next_control:
            next_control.focus()
        return 'break'

    def _on_paste(self, _: object) -> str | None:
        text: str | None = self._get_clipboard()
        if text is not None:
            text = _cut_text_at_line_break(text)
            self._delete_selection()
            self.insert(self.index(tk.INSERT), text)
            self.see(self.index(tk.INSERT))
        return 'break'

    def _delete_selection(self) -> None:
        index_of_selection_begin: str | None = None
        index_of_selection_end: str | None = None
        try:
            index_of_selection_begin = self.index(tk.SEL_FIRST)
            index_of_selection_end = self.index(tk.SEL_LAST)
        except tk.TclError:
            pass

        if index_of_selection_begin and index_of_selection_end:
            self.delete(index_of_selection_begin, index_of_selection_end)

    def _get_clipboard(self) -> str | None:
        text: object = None
        try:
            root: tk.Tk | tk.Toplevel = self.winfo_toplevel()
            text = root.clipboard_get()
        except tk.TclError:
            pass
        if isinstance(text, str):
            return text
        return None

def _cut_text_at_line_break(text: str) -> str:
    lf_pos: int = text.find('\n')
    cr_pos: int = text.find('\r')
    break_pos: int = -1
    if lf_pos != -1:
        break_pos = lf_pos
    if cr_pos != -1 and cr_pos < break_pos:
        break_pos = cr_pos
    if break_pos != -1:
        text = text[:break_pos]
    return text
