# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import tkinter as tk
from collections.abc import Callable
from milodb_client.view.gui import general_colours, general_layout

# spell-checker: ignore padx pady borderwidth

_COL_PANEL_BACK: str = general_colours.PANEL_BACK
_COL_BUTTON_BACK: str = general_colours.BUTTON_BACK
_COL_BUTTON_FORE: str = general_colours.BUTTON_FORE

_LAYOUT_RELIEF: general_layout.Relief = general_layout.PANEL_RELIEF
_LAYOUT_BORDER_WIDTH: int = general_layout.PANEL_BORDER_WIDTH
_LAYOUT_PADDING_X: int = general_layout.PANEL_PADDING_X
_LAYOUT_PADDING_Y: int = general_layout.PANEL_PADDING_Y

class ToolbarPanel(tk.Frame):
    def __init__(self, master: tk.Misc, *, open_about_dialog: Callable[[], None], open_update_dialog: Callable[[], None], open_stats_dialog: Callable[[], None]) -> None:
        super().__init__(master, background=_COL_PANEL_BACK, relief=_LAYOUT_RELIEF, padx=_LAYOUT_PADDING_X, pady=_LAYOUT_PADDING_Y, borderwidth=_LAYOUT_BORDER_WIDTH)

        tk.Button(self, text='About', foreground=_COL_BUTTON_FORE, background=_COL_BUTTON_BACK, command=open_about_dialog).pack(fill=tk.X)
        tk.Button(self, text='Update', foreground=_COL_BUTTON_FORE, background=_COL_BUTTON_BACK, command=open_update_dialog).pack(fill=tk.X)
        tk.Button(self, text='Stats', foreground=_COL_BUTTON_FORE, background=_COL_BUTTON_BACK, command=open_stats_dialog).pack(fill=tk.X)
