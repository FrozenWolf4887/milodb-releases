# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from __future__ import annotations
import tkinter as tk
from tkinter import ttk
from typing import TYPE_CHECKING, override
from milodb_client.view.gui import general_colours, general_layout
from milodb_client.view.gui.frame_widgets import WrappingLabel
from milodb_client.view.gui.scrollable_frame import ScrollableFrame
if TYPE_CHECKING:
    from collections.abc import Callable, Sequence
    from milodb_client.database.tease import Tease
    from milodb_client.util.database_stats import DatabaseStats, TeaseContentStats, TotmStats

_COL_PANEL_BACK: str = general_colours.PANEL_BACK
_COL_BUTTON_BACK: str = general_colours.BUTTON_BACK
_COL_BUTTON_FORE: str = general_colours.BUTTON_FORE
_COL_TABLE_HEADER_BACK: str = general_colours.HEADER_BACK
_COL_TABLE_HEADER_FORE: str = general_colours.HEADER_FORE
_COL_TABLE_CONTENT_BACK: str = general_colours.VALUE_BACK
_COL_TABLE_CONTENT_FORE: str = general_colours.VALUE_FORE

_LAYOUT_RELIEF: general_layout.Relief = general_layout.PANEL_RELIEF
_LAYOUT_BORDER_WIDTH: int = general_layout.PANEL_BORDER_WIDTH
_LAYOUT_PADDING_X: int = general_layout.PANEL_PADDING_X
_LAYOUT_PADDING_Y: int = general_layout.PANEL_PADDING_Y

_TABLE_CELL_X_PADDING: int = 4
_TABLE_CELL_Y_PADDING: int = 1
_TABLE_GRIDLINE_THICKNESS: int = 1

# spell-checker: ignore borderwidth padx pady

class StatsDialog(tk.Toplevel):
    def __init__(self, master: tk.Tk, database_stats: DatabaseStats) -> None:
        super().__init__(master, background=_COL_PANEL_BACK, relief=_LAYOUT_RELIEF, padx=_LAYOUT_PADDING_X, pady=_LAYOUT_PADDING_Y, borderwidth=_LAYOUT_BORDER_WIDTH)
        self.geometry('640x480')

        notebook: ttk.Notebook = ttk.Notebook(self)
        notebook.pack(fill=tk.BOTH, expand=True)

        notebook.add(_create_general_tab(notebook, database_stats), text='General')
        notebook.add(_create_tags_tab(notebook, database_stats), text='Tags')
        notebook.add(_create_authors_tab(notebook, database_stats), text='Authors')
        notebook.add(_create_awards_tab(notebook, database_stats), text='Awards')
        notebook.add(_create_tease_content_tab(notebook, database_stats), text='Tease Content')
        notebook.add(_create_author_content_tab(notebook, database_stats), text='Author Content')
        notebook.add(_create_images_tab(notebook, database_stats), text='Images')

        button_frame: tk.Frame = tk.Frame(self, background=_COL_PANEL_BACK)
        button_frame.pack(fill=tk.X)
        tk.Button(button_frame, text='Okay', foreground=_COL_BUTTON_FORE, background=_COL_BUTTON_BACK, command=self.destroy).pack()

        self.transient(master)
        self.wait_visibility()
        self.grab_set()

    @override
    def destroy(self) -> None:
        self.grab_release()
        super().destroy()

def _create_general_tab(master: tk.Misc, database_stats: DatabaseStats) -> tk.Widget:
    frame: ScrollableFrame = ScrollableFrame(master, background=_COL_PANEL_BACK)
    frame.top_frame.pack(fill=tk.BOTH, expand=True)

    map_of_heading_to_generator: dict[str, Callable[[], str]] = {
        'Total Teases': lambda: f'{database_stats.number_of_teases:,}',
        'Deleted Teases': lambda: f'{database_stats.count_of_deleted_teases:,}',
        'Teases by Unknown Authors': lambda: f'{database_stats.count_of_missing_authors:,}',
        'Total Authors': lambda: f'{len(database_stats.map_of_author_to_tease_count):,}',
        'Unique Tags': lambda: f'{len(database_stats.map_of_tag_to_occurrence_count):,}',
        'TOTM winners': lambda: f'{database_stats.count_of_totm_winners:,}',
        'TOTM nominees': lambda: f'{database_stats.count_of_totm_nominees:,}',
        'Total Content Words': lambda: f'{database_stats.total_count_of_words:,}',
    }

    row: int
    heading: str
    generator: Callable[[], str]
    for row, (heading, generator) in enumerate(map_of_heading_to_generator.items()):
        tk.Label(frame.content_frame, text=heading, anchor=tk.W, justify=tk.LEFT, fg=_COL_TABLE_HEADER_FORE, bg=_COL_TABLE_HEADER_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
        tk.Label(frame.content_frame, text=generator(), anchor=tk.E, justify=tk.RIGHT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)

    frame.set_child_bindtags_for_scrolling()
    return frame.top_frame

def _create_tags_tab(master: tk.Misc, database_stats: DatabaseStats) -> tk.Widget:
    frame: ScrollableFrame = ScrollableFrame(master, background=_COL_PANEL_BACK)
    frame.top_frame.pack(fill=tk.BOTH, expand=True)

    tk.Label(frame.content_frame, text='#', anchor=tk.E, justify=tk.RIGHT, fg=_COL_TABLE_HEADER_FORE, bg=_COL_TABLE_HEADER_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=0, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
    tk.Label(frame.content_frame, text='Occurrences', anchor=tk.E, justify=tk.RIGHT, fg=_COL_TABLE_HEADER_FORE, bg=_COL_TABLE_HEADER_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=0, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
    tk.Label(frame.content_frame, text='Tag', anchor=tk.W, justify=tk.LEFT, fg=_COL_TABLE_HEADER_FORE, bg=_COL_TABLE_HEADER_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=0, column=2, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)

    sorted_list_of_tags_and_occurrence_count: Sequence[tuple[str, int]] = sorted(database_stats.map_of_tag_to_occurrence_count.items(), key=lambda x: x[1], reverse=True)
    index: int
    tag: str
    count: int
    for index, (tag, count) in enumerate(sorted_list_of_tags_and_occurrence_count[:80]):
        row = index + 1
        tk.Label(frame.content_frame, text=str(index + 1), anchor=tk.E, justify=tk.RIGHT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
        tk.Label(frame.content_frame, text=f'{count:,}', anchor=tk.E, justify=tk.RIGHT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
        tk.Label(frame.content_frame, text=tag, anchor=tk.W, justify=tk.LEFT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row, column=2, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)

    frame.set_child_bindtags_for_scrolling()
    return frame.top_frame

def _create_authors_tab(master: tk.Misc, database_stats: DatabaseStats) -> tk.Widget:
    frame: ScrollableFrame = ScrollableFrame(master, background=_COL_PANEL_BACK)
    frame.top_frame.pack(fill=tk.BOTH, expand=True)

    tk.Label(frame.content_frame, text='#', anchor=tk.E, justify=tk.RIGHT, fg=_COL_TABLE_HEADER_FORE, bg=_COL_TABLE_HEADER_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=0, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
    tk.Label(frame.content_frame, text='Teases', anchor=tk.E, justify=tk.RIGHT, fg=_COL_TABLE_HEADER_FORE, bg=_COL_TABLE_HEADER_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=0, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
    tk.Label(frame.content_frame, text='Author', anchor=tk.W, justify=tk.LEFT, fg=_COL_TABLE_HEADER_FORE, bg=_COL_TABLE_HEADER_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=0, column=2, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)

    sorted_list_of_authors_and_tease_count: Sequence[tuple[str, int]] = sorted(database_stats.map_of_author_to_tease_count.items(), key=lambda x: x[1], reverse=True)
    index: int
    author: str
    tease_count: int
    for index, (author, tease_count) in enumerate(sorted_list_of_authors_and_tease_count[:80]):
        row = index + 1
        tk.Label(frame.content_frame, text=str(index + 1), anchor=tk.E, justify=tk.RIGHT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
        tk.Label(frame.content_frame, text=f'{tease_count:,}', anchor=tk.E, justify=tk.RIGHT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
        tk.Label(frame.content_frame, text=author, anchor=tk.W, justify=tk.LEFT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row, column=2, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)

    frame.set_child_bindtags_for_scrolling()
    return frame.top_frame

def _create_awards_tab(master: tk.Misc, database_stats: DatabaseStats) -> tk.Widget:
    frame: ScrollableFrame = ScrollableFrame(master, background=_COL_PANEL_BACK)
    frame.top_frame.pack(fill=tk.BOTH, expand=True)

    tk.Label(frame.content_frame, text='#', anchor=tk.E, justify=tk.RIGHT, fg=_COL_TABLE_HEADER_FORE, bg=_COL_TABLE_HEADER_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=0, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
    tk.Label(frame.content_frame, text='Wins', anchor=tk.E, justify=tk.RIGHT, fg=_COL_TABLE_HEADER_FORE, bg=_COL_TABLE_HEADER_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=0, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
    tk.Label(frame.content_frame, text='Nominations', anchor=tk.E, justify=tk.RIGHT, fg=_COL_TABLE_HEADER_FORE, bg=_COL_TABLE_HEADER_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=0, column=2, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
    tk.Label(frame.content_frame, text='Author', anchor=tk.W, justify=tk.LEFT, fg=_COL_TABLE_HEADER_FORE, bg=_COL_TABLE_HEADER_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=0, column=3, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)

    sorted_list_of_authors_and_totm_stats: Sequence[tuple[str, TotmStats]] = sorted(database_stats.map_of_author_to_totm_stats.items(), key=lambda x: (x[1].wins, x[1].nominations), reverse=True)
    index: int
    author: str
    totm_stats: TotmStats
    for index, (author, totm_stats) in enumerate(sorted_list_of_authors_and_totm_stats[:80]):
        row = index + 1
        tk.Label(frame.content_frame, text=str(index + 1), anchor=tk.E, justify=tk.RIGHT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
        tk.Label(frame.content_frame, text=f'{totm_stats.wins:,}', anchor=tk.E, justify=tk.RIGHT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
        tk.Label(frame.content_frame, text=f'{totm_stats.nominations:,}', anchor=tk.E, justify=tk.RIGHT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row, column=2, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
        tk.Label(frame.content_frame, text=author, anchor=tk.W, justify=tk.LEFT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row, column=3, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)

    frame.set_child_bindtags_for_scrolling()
    return frame.top_frame

def _create_tease_content_tab(master: tk.Misc, database_stats: DatabaseStats) -> tk.Widget:
    frame: ScrollableFrame = ScrollableFrame(master, background=_COL_PANEL_BACK)
    frame.top_frame.pack(fill=tk.BOTH, expand=True)

    tk.Label(frame.content_frame, text='#', anchor=tk.E, justify=tk.RIGHT, fg=_COL_TABLE_HEADER_FORE, bg=_COL_TABLE_HEADER_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=0, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
    tk.Label(frame.content_frame, text='Words', anchor=tk.E, justify=tk.RIGHT, fg=_COL_TABLE_HEADER_FORE, bg=_COL_TABLE_HEADER_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=0, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
    tk.Label(frame.content_frame, text='Tease', anchor=tk.W, justify=tk.LEFT, fg=_COL_TABLE_HEADER_FORE, bg=_COL_TABLE_HEADER_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=0, column=2, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
    tk.Label(frame.content_frame, text='Author', anchor=tk.W, justify=tk.LEFT, fg=_COL_TABLE_HEADER_FORE, bg=_COL_TABLE_HEADER_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=0, column=3, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)

    sorted_list_of_content_stats: Sequence[TeaseContentStats] = sorted(database_stats.list_of_content_stats, key=lambda stat: stat.word_count, reverse=True)
    index: int
    content_stats: TeaseContentStats
    for index, content_stats in enumerate(sorted_list_of_content_stats[:80]):
        row = index + 1
        tk.Label(frame.content_frame, text=str(index + 1), anchor=tk.E, justify=tk.RIGHT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
        tk.Label(frame.content_frame, text=f'{content_stats.word_count:,}', anchor=tk.E, justify=tk.RIGHT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
        WrappingLabel(frame.content_frame, text=content_stats.tease.get_title(), anchor=tk.W, justify=tk.LEFT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row, column=2, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
        tk.Label(frame.content_frame, text=content_stats.tease.get_author_name(), anchor=tk.W, justify=tk.LEFT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row, column=3, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)

    frame.content_frame.columnconfigure(2, weight=1)
    frame.set_child_bindtags_for_scrolling()
    return frame.top_frame

def _create_author_content_tab(master: tk.Misc, database_stats: DatabaseStats) -> tk.Widget:
    frame: ScrollableFrame = ScrollableFrame(master, background=_COL_PANEL_BACK)
    frame.top_frame.pack(fill=tk.BOTH, expand=True)

    tk.Label(frame.content_frame, text='#', anchor=tk.E, justify=tk.RIGHT, fg=_COL_TABLE_HEADER_FORE, bg=_COL_TABLE_HEADER_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=0, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
    tk.Label(frame.content_frame, text='Words', anchor=tk.E, justify=tk.RIGHT, fg=_COL_TABLE_HEADER_FORE, bg=_COL_TABLE_HEADER_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=0, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
    tk.Label(frame.content_frame, text='Author', anchor=tk.W, justify=tk.LEFT, fg=_COL_TABLE_HEADER_FORE, bg=_COL_TABLE_HEADER_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=0, column=2, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)

    sorted_list_of_authors_and_word_count: Sequence[tuple[str, int]] = sorted(database_stats.map_of_author_to_word_count.items(), key=lambda x: x[1], reverse=True)
    author: str
    word_count: int
    for index, (author, word_count) in enumerate(sorted_list_of_authors_and_word_count[:80]):
        row = index + 1
        tk.Label(frame.content_frame, text=str(index + 1), anchor=tk.E, justify=tk.RIGHT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
        tk.Label(frame.content_frame, text=f'{word_count:,}', anchor=tk.E, justify=tk.RIGHT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
        tk.Label(frame.content_frame, text=author, anchor=tk.W, justify=tk.LEFT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row, column=2, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)

    frame.set_child_bindtags_for_scrolling()
    return frame.top_frame

def _create_images_tab(master: tk.Misc, database_stats: DatabaseStats) -> tk.Widget:
    frame: ScrollableFrame = ScrollableFrame(master, background=_COL_PANEL_BACK)
    frame.top_frame.pack(fill=tk.BOTH, expand=True)

    tk.Label(frame.content_frame, text='#', anchor=tk.E, justify=tk.RIGHT, fg=_COL_TABLE_HEADER_FORE, bg=_COL_TABLE_HEADER_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=0, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
    tk.Label(frame.content_frame, text='Unique', anchor=tk.E, justify=tk.RIGHT, fg=_COL_TABLE_HEADER_FORE, bg=_COL_TABLE_HEADER_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=0, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
    tk.Label(frame.content_frame, text='Tease', anchor=tk.W, justify=tk.LEFT, fg=_COL_TABLE_HEADER_FORE, bg=_COL_TABLE_HEADER_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=0, column=2, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
    tk.Label(frame.content_frame, text='Author', anchor=tk.W, justify=tk.LEFT, fg=_COL_TABLE_HEADER_FORE, bg=_COL_TABLE_HEADER_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=0, column=3, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)

    index: int
    tease: Tease
    for index, tease in enumerate(database_stats.list_of_teases_by_decreasing_image_count[:80]):
        row = index + 1
        tk.Label(frame.content_frame, text=str(index + 1), anchor=tk.E, justify=tk.RIGHT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
        tk.Label(frame.content_frame, text=f'{tease.get_count_of_unique_images():,}', anchor=tk.E, justify=tk.RIGHT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
        WrappingLabel(frame.content_frame, text=tease.get_title(), anchor=tk.W, justify=tk.LEFT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row, column=2, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
        tk.Label(frame.content_frame, text=tease.get_author_name(), anchor=tk.W, justify=tk.LEFT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row, column=3, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)

    frame.content_frame.columnconfigure(2, weight=1)
    frame.set_child_bindtags_for_scrolling()
    return frame.top_frame
