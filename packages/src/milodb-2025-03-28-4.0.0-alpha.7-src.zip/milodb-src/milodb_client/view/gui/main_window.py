# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import tkinter as tk
from collections.abc import Sequence
from pathlib import Path
from tkinter import ttk
from typing import TYPE_CHECKING
import pyclip # type: ignore[import-untyped]
from PIL import Image, ImageTk
from milodb_client.config.launch_config import BrowseLaunchConfig, OpenLaunchConfig
from milodb_client.config.update_config import UpdateConfig
from milodb_client.database.author import Author
from milodb_client.database.tease import Tease
from milodb_client.database.thumbnail_database import ThumbnailDatabase
from milodb_client.query.tease_match import TeaseMatch
from milodb_client.resources import resource_path
from milodb_client.startup.shutdown_action import IShutdownAction
from milodb_client.updater.local_file_hasher import LocalFileHasher
from milodb_client.updater.local_file_tester import LocalFileTester
from milodb_client.updater.manifest.local_manifest import ILocalManifest
from milodb_client.updater.temp_directory import TempDirectoryCreator
from milodb_client.util.database_stats import DatabaseStats
from milodb_client.util.launcher import launch
from milodb_client.util.sort_keys import DATE_SORT_KEY, OrderedSortKey, TEASE_ID_SORT_KEY
from milodb_client.util.tease_match_sorter import ITeaseMatchSorter, TeaseMatchSorter
from milodb_client.view.gui import general_colours, general_layout
from milodb_client.view.gui.about_dialog import AboutDialog
from milodb_client.view.gui.log_dialog import LogDialog
from milodb_client.view.gui.match_info_panel import MatchInfoPanel
from milodb_client.view.gui.raw_query_panel import RawQueryPanel
from milodb_client.view.gui.stats_dialog import StatsDialog
from milodb_client.view.gui.table_list_panel import TableListPanel
from milodb_client.view.gui.tease_card_list_panel import TeaseCardListPanel
from milodb_client.view.gui.text_matches_panel import TextMatchesPanel
from milodb_client.view.gui.toolbar_panel import ToolbarPanel
from milodb_client.view.gui.update_dialog import UpdateDialog
from milodb_client.view.gui.util.datum import IDatum, SimpleDatum
from milodb_common.config.framework import IConfig
from milodb_common.config.i_launch_config import LaunchOption
from milodb_common.internet.uri_scraper_factory import UriScraperFactory
from milodb_common.util.get_url import get_url_of_author, get_url_of_author_teases, get_url_of_tease
from milodb_common.util.ref import IRef
from milodb_common.variables.i_user_variables import IUserVariables
if TYPE_CHECKING:
    from milodb_common.config.i_launch_config import ILaunchConfig

# spell-checker: ignore padx pady tearoff

_PANED_WINDOW_STYLE_NAME: str = 'My.TPanedwindow'
_COL_PANEL_BACK: str = general_colours.PANEL_BACK
_LAYOUT_PANEL_MARGIN_X: int = general_layout.PANEL_MARGIN_X
_LAYOUT_PANEL_MARGIN_Y: int = general_layout.PANEL_MARGIN_Y

class MainWindow:
    def __init__(self, local_manifest: ILocalManifest | None, system_config: IConfig, list_of_teases: Sequence[Tease], thumbnail_database: ThumbnailDatabase, user_variables: IUserVariables, ref_shutdown_action: IRef[IShutdownAction | None]) -> None:
        self._local_manifest: ILocalManifest | None = local_manifest
        self._list_of_teases: Sequence[Tease] = list_of_teases
        self._thumbnail_database: ThumbnailDatabase = thumbnail_database
        self._user_variables: IUserVariables = user_variables
        self._ref_shutdown_action: IRef[IShutdownAction | None] = ref_shutdown_action

        self._update_config: UpdateConfig = UpdateConfig(system_config)
        self._command_browse_launch_config: ILaunchConfig = BrowseLaunchConfig(system_config)
        self._command_open_launch_config: ILaunchConfig = OpenLaunchConfig(system_config)
        self._tease_match_sorter: ITeaseMatchSorter = TeaseMatchSorter([OrderedSortKey(DATE_SORT_KEY, is_ascending=False), OrderedSortKey(TEASE_ID_SORT_KEY, is_ascending=False)])

        self._list_of_tease_matches: IDatum[Sequence[TeaseMatch]] = SimpleDatum([])
        self._selected_tease_index: IDatum[int | None] = SimpleDatum(None)
        self._list_of_active_sort_keys: IDatum[Sequence[OrderedSortKey]] = SimpleDatum([])
        self._abbreviate_text: IDatum[bool] = SimpleDatum(default=True)
        self._show_only_matching_pages: IDatum[bool] = SimpleDatum[bool](default=True)
        self._show_page_refs: IDatum[bool] = SimpleDatum[bool](default=False)
        self._database_stats: DatabaseStats = DatabaseStats(self._list_of_teases)

        self._reset_tease_matches()
        self._init_window()
        self._window.mainloop()

    def _init_window(self) -> None:
        self._window: tk.Tk = tk.Tk()
        self._window.configure(background=_COL_PANEL_BACK)
        self._window.title('MiloDB')

        style = ttk.Style(master=self._window)
        style.theme_use('clam')
        style.configure(_PANED_WINDOW_STYLE_NAME, background='#888', foreground='#FFF')

        icon: Image.Image
        with Image.open(resource_path(Path('milodb-search-icon.ico'))) as icon:
            self._window.iconphoto(True, ImageTk.PhotoImage(icon)) # noqa: FBT003 Boolean positional value in function call
        self._window.geometry('1024x600')

        top_frame: tk.Frame = tk.Frame(self._window, background=_COL_PANEL_BACK)
        raw_query_panel: RawQueryPanel = RawQueryPanel(top_frame, self._list_of_teases, self._user_variables, self._list_of_tease_matches, self._selected_tease_index, self._tease_match_sorter, self._list_of_active_sort_keys)
        raw_query_panel.grid(column=0, row=0, sticky=tk.NSEW, padx=(0, _LAYOUT_PANEL_MARGIN_X))
        ToolbarPanel(top_frame, open_about_dialog=self._open_about_dialog, open_update_dialog=self._open_update_dialog, open_stats_dialog=self._open_stats_dialog).grid(column=1, row=0, sticky='nse')
        top_frame.columnconfigure(0, weight=1)
        top_frame.rowconfigure(0, weight=1)
        top_frame.pack(fill=tk.X, pady=(0, _LAYOUT_PANEL_MARGIN_Y))

        outer_paned_window: ttk.PanedWindow = ttk.PanedWindow(self._window, orient=tk.HORIZONTAL, style=_PANED_WINDOW_STYLE_NAME)
        outer_paned_window.pack(fill=tk.BOTH, expand=True)

        list_frame: tk.Frame = tk.Frame(outer_paned_window, background=_COL_PANEL_BACK)
        match_info_panel: MatchInfoPanel = MatchInfoPanel(list_frame, self._list_of_teases, self._list_of_tease_matches, self._selected_tease_index, self._reset_tease_matches)
        match_info_panel.pack(fill=tk.X, pady=(0, _LAYOUT_PANEL_MARGIN_Y))
        inner_paned_window: ttk.PanedWindow = ttk.PanedWindow(list_frame, orient=tk.HORIZONTAL, style=_PANED_WINDOW_STYLE_NAME)
        inner_paned_window.pack(fill=tk.BOTH, expand=True, padx=(0, _LAYOUT_PANEL_MARGIN_X))

        table_list_panel: TableListPanel = TableListPanel(inner_paned_window, self._list_of_tease_matches, self._selected_tease_index, self._tease_match_sorter, self._list_of_active_sort_keys, self._open_tease, self._popup_tease_menu)
        card_list_panel: TeaseCardListPanel = TeaseCardListPanel(inner_paned_window, self._list_of_tease_matches, self._selected_tease_index, self._thumbnail_database, self._open_tease, self._popup_tease_menu)
        text_matches_panel: TextMatchesPanel = TextMatchesPanel(outer_paned_window, self._list_of_tease_matches, self._selected_tease_index, self._show_only_matching_pages, self._abbreviate_text, self._show_page_refs)

        outer_paned_window.add(list_frame, weight=1)
        outer_paned_window.add(text_matches_panel, weight=1)
        outer_paned_window.update()
        outer_paned_window.sashpos(0, int(outer_paned_window.winfo_width() * 0.85))

        inner_paned_window.add(table_list_panel, weight=1)
        inner_paned_window.add(card_list_panel, weight=1)
        inner_paned_window.update()
        inner_paned_window.sashpos(0, int(inner_paned_window.winfo_width() * 0.5))

        raw_query_panel.set_focus()

    def _reset_tease_matches(self) -> None:
        self._selected_tease_index.set(None)
        self._list_of_tease_matches.set(
            self._tease_match_sorter.sort([
                TeaseMatch(index + 1, tease, []) for index, tease in enumerate(self._list_of_teases)
            ],
            self._list_of_active_sort_keys.get(),
        ))

    def _open_about_dialog(self) -> None:
        AboutDialog(self._window, self._local_manifest)

    def _open_update_dialog(self) -> None:
        UpdateDialog(self._window, self._update_config, self._local_manifest, LocalFileHasher(), LocalFileTester(), UriScraperFactory(), TempDirectoryCreator(), self._ref_shutdown_action, self._shutdown_app)

    def _open_stats_dialog(self) -> None:
        StatsDialog(self._window, self._database_stats)

    def _popup_tease_menu(self, parent: tk.Misc, x_root: int, y_root: int, tease_match: TeaseMatch) -> None:
        is_open_available: bool = self._command_open_launch_config.launch_option is not LaunchOption.NONE
        is_open_tease_available: bool = is_open_available
        is_open_author_available: bool = is_open_available and tease_match.tease.author.has_author
        is_copy_uri_of_author_available: bool = tease_match.tease.author.has_author
        popup_menu: tk.Menu = tk.Menu(parent, tearoff=0)
        popup_menu.add_command(label='Open Tease', command=lambda: self._open_tease(tease_match.tease), state=tk.NORMAL if is_open_tease_available else tk.DISABLED)
        popup_menu.add_command(label='Open Author Profile', command=lambda: self._open_author_profile(tease_match.tease.author), state=tk.NORMAL if is_open_author_available else tk.DISABLED)
        popup_menu.add_command(label='Open Author Tease List', command=lambda: self._open_author_tease_list(tease_match.tease.author), state=tk.NORMAL if is_open_author_available else tk.DISABLED)
        popup_menu.add_separator()
        popup_menu.add_command(label='Copy URI of Tease', command=lambda: self._copy_url_of_tease(tease_match.tease))
        popup_menu.add_command(label='Copy URI of Author Profile', command=lambda: self._copy_url_of_author_profile(tease_match.tease.author), state=tk.NORMAL if is_copy_uri_of_author_available else tk.DISABLED)
        popup_menu.tk_popup(x_root, y_root)
        popup_menu.focus()
        popup_menu.bind('<FocusOut>', lambda _event: popup_menu.destroy())

    def _open_tease(self, tease: Tease) -> None:
        is_open_available: bool = self._command_open_launch_config.launch_option is not LaunchOption.NONE
        if not is_open_available:
            return
        log_dialog: LogDialog = LogDialog(self._window)
        tease_id: int = tease.get_tease_id()
        log_dialog.log_text.normal_printer.writeln(f"Opening tease #{tease_id} '{tease.get_title()}'")
        tease_url: str = get_url_of_tease(tease_id)
        launch(self._command_open_launch_config, None, tease_url, log_dialog.log_text.normal_printer, log_dialog.log_text.warning_printer, log_dialog.log_text.error_printer)
        if log_dialog.log_text.any_warnings_or_errors:
            log_dialog.show_okay_button()
        else:
            log_dialog.destroy()

    def _open_author_profile(self, author: Author) -> None:
        is_open_available: bool = self._command_open_launch_config.launch_option is not LaunchOption.NONE
        if not is_open_available:
            return
        log_dialog: LogDialog = LogDialog(self._window)
        if author.has_author:
            log_dialog.log_text.normal_printer.writeln(f"Opening author profile @{author.author_id} '{author.name}'")
            author_url: str = get_url_of_author(author.author_id)
            launch(self._command_open_launch_config, None, author_url, log_dialog.log_text.normal_printer, log_dialog.log_text.warning_printer, log_dialog.log_text.error_printer)
        else:
            log_dialog.log_text.error_printer.writeln('Cannot open author profile because the author is not known')
        if log_dialog.log_text.any_warnings_or_errors:
            log_dialog.show_okay_button()
        else:
            log_dialog.destroy()

    def _open_author_tease_list(self, author: Author) -> None:
        is_open_available: bool = self._command_open_launch_config.launch_option is not LaunchOption.NONE
        if not is_open_available:
            return
        log_dialog: LogDialog = LogDialog(self._window)
        if author.has_author:
            log_dialog.log_text.normal_printer.writeln(f"Opening author @{author.author_id} '{author.name}' tease list")
            author_url: str = get_url_of_author_teases(author.author_id)
            launch(self._command_open_launch_config, None, author_url, log_dialog.log_text.normal_printer, log_dialog.log_text.warning_printer, log_dialog.log_text.error_printer)
        else:
            log_dialog.log_text.error_printer.writeln('Cannot open author tease list because the author is not known')
        if log_dialog.log_text.any_warnings_or_errors:
            log_dialog.show_okay_button()
        else:
            log_dialog.destroy()

    def _copy_url_of_tease(self, tease: Tease) -> None:
        tease_url: str = get_url_of_tease(tease.get_tease_id())
        self._copy_to_clipboard(tease_url)

    def _copy_url_of_author_profile(self, author: Author) -> None:
        if author.has_author:
            author_url: str = get_url_of_author(author.author_id)
            self._copy_to_clipboard(author_url)
        else:
            log_dialog = LogDialog(self._window)
            log_dialog.log_text.error_printer.writeln('Cannot copy URI of author profile because the author is not known')
            log_dialog.show_okay_button()

    def _copy_to_clipboard(self, text: str) -> None:
        try:
            pyclip.copy(text)
        except pyclip.ClipboardSetupException as ex:
            log_dialog: LogDialog = LogDialog(self._window)
            log_dialog.log_text.error_printer.writeln(f'Unable to copy to clipboard: {ex}')
            log_dialog.show_okay_button()

    def _shutdown_app(self) -> None:
        self._window.destroy()
