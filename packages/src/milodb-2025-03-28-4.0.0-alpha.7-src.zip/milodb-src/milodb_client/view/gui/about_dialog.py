# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from __future__ import annotations
import platform
import sys
import tkinter as tk
from typing import TYPE_CHECKING, override
import psutil
from milodb_client.util import app_info
from milodb_client.view.gui import general_colours, general_layout
from milodb_client.view.gui.frame_widgets import WrappingLabel
from milodb_client.view.gui.scrollable_frame import ScrollableFrame
from milodb_common.util.get_url import get_url_of_author
from milodb_common.util.unit_size import UnitSizeText, unit_size
if TYPE_CHECKING:
    from collections.abc import Callable
    from milodb_client.updater.manifest.local_manifest import ILocalManifest

_COL_PANEL_BACK: str = general_colours.PANEL_BACK
_COL_BUTTON_BACK: str = general_colours.BUTTON_BACK
_COL_BUTTON_FORE: str = general_colours.BUTTON_FORE
_COL_TABLE_HEADER_BACK: str = general_colours.HEADER_BACK
_COL_TABLE_HEADER_FORE: str = general_colours.HEADER_FORE
_COL_TABLE_CONTENT_BACK: str = general_colours.VALUE_BACK
_COL_TABLE_CONTENT_FORE: str = general_colours.VALUE_FORE

_LAYOUT_RELIEF: general_layout.Relief = general_layout.PANEL_RELIEF
_LAYOUT_BORDER_WIDTH: int = general_layout.PANEL_BORDER_WIDTH
_LAYOUT_PADDING_X: int = general_layout.PANEL_PADDING_X
_LAYOUT_PADDING_Y: int = general_layout.PANEL_PADDING_Y

_TABLE_CELL_X_PADDING: int = 4
_TABLE_CELL_Y_PADDING: int = 1
_TABLE_GRIDLINE_THICKNESS: int = 1

# spell-checker: ignore borderwidth padx pady

class AboutDialog(tk.Toplevel):
    def __init__(self, master: tk.Tk, local_manifest: ILocalManifest | None) -> None:
        super().__init__(master, background=_COL_PANEL_BACK, relief=_LAYOUT_RELIEF, padx=_LAYOUT_PADDING_X, pady=_LAYOUT_PADDING_Y, borderwidth=_LAYOUT_BORDER_WIDTH)
        self.geometry('640x480')

        memory = psutil.virtual_memory()
        total_memory_size: UnitSizeText = unit_size(memory.total)
        available_memory_size: UnitSizeText = unit_size(memory.available)
        core_count: int | None = psutil.cpu_count(logical=False)
        thread_count: int | None = psutil.cpu_count()

        map_of_heading_to_generator: dict[str, Callable[[], str]] = {
            'Name': lambda: app_info.APPLICATION_NAME,
            'Variant': lambda: local_manifest.variant_name if local_manifest else 'unknown',
            'Version': lambda: str(local_manifest.version_number) if local_manifest else 'unknown',
            'Date': lambda: local_manifest.date.isoformat() if local_manifest else 'unknown',
            'Author': lambda: app_info.AUTHOR_NAME,
            'Author Profile': lambda: get_url_of_author(app_info.AUTHOR_ID),
            'Machine': lambda: f'{platform.machine()}, {sys.platform}',
            'Platform': platform.platform,
            'Memory Total': lambda: f'{total_memory_size.size_text} {total_memory_size.unit_text}',
            'Memory Free': lambda: f'{available_memory_size.size_text} {available_memory_size.unit_text}',
            'CPU': platform.processor,
            'CPU Cores': lambda: str(core_count) if core_count else 'unknown',
            'CPU Threads': lambda: str(thread_count) if thread_count else 'unknown',
            'Python': lambda: sys.version,
            'Software Licence': lambda: app_info.SOFTWARE_LICENCE_TEXT,
            'Tease Copyright': lambda: app_info.TEASE_COPYRIGHT_TEXT,
            'Support Topic': lambda: app_info.FORUM_THREAD_URL,
        }

        table_frame: ScrollableFrame = ScrollableFrame(self, background=_COL_PANEL_BACK)
        table_frame.top_frame.pack(fill=tk.BOTH, expand=True)

        row: int
        heading: str
        generator: Callable[[], str]
        for row, (heading, generator) in enumerate(map_of_heading_to_generator.items()):
            tk.Label(table_frame.content_frame, text=heading, anchor=tk.W, justify=tk.LEFT, fg=_COL_TABLE_HEADER_FORE, bg=_COL_TABLE_HEADER_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            WrappingLabel(table_frame.content_frame, text=generator(), anchor=tk.W, justify=tk.LEFT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)

        table_frame.content_frame.columnconfigure(1, weight=1)
        table_frame.set_child_bindtags_for_scrolling()

        button_frame: tk.Frame = tk.Frame(self, background=_COL_PANEL_BACK)
        button_frame.pack(fill=tk.X)
        tk.Button(button_frame, text='Okay', foreground=_COL_BUTTON_FORE, background=_COL_BUTTON_BACK, command=self.destroy).pack()

        self.transient(master)
        self.wait_visibility()
        self.grab_set()

    @override
    def destroy(self) -> None:
        self.grab_release()
        super().destroy()
