# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from math import ceil, pi
from PIL import Image, ImageDraw
from milodb_client.view.gui.geometric_shapes import make_star_points
from milodb_client.view.gui.turtle import Alignment, Flip, Turtle, TurtleShape
from milodb_client.view.gui.util.singleton import Singleton
from milodb_common.view.gui.metrics import Point

_TOTM_NOMINEE_FILL_COLOUR: str = '#CCC'
_TOTM_NOMINEE_LINE_COLOUR: str = '#444'
_TOTM_WINNER_FILL_COLOUR: str = '#FF3'
_TOTM_WINNER_LINE_COLOUR: str = '#444'

class _RatingImageShape:
    STAR_POINTS: int = 5
    OUTER_RADIUS: float = 500.0
    INNER_RADIUS: float = 200.0
    OUTER_ROTATION_RADIANS: float = pi / 4.2
    INNER_ROTATION_RADIANS: float = OUTER_ROTATION_RADIANS

    NUMBER_OF_STARS: int = 5
    WIDTH_OF_STAR: int = ceil(OUTER_RADIUS * 2)
    SPACING_BETWEEN_STARS: int = ceil(OUTER_RADIUS * 2 * 0.83)
    HEIGHT_OF_STAR: int = ceil(OUTER_RADIUS * 2)

    ORIGINAL_IMAGE_WIDTH: int = SPACING_BETWEEN_STARS * (NUMBER_OF_STARS - 1) + WIDTH_OF_STAR
    ORIGINAL_IMAGE_HEIGHT: int = HEIGHT_OF_STAR

    def __init__(self) -> None:
        self.list_of_polygons: list[list[Point]] = []
        for star in range(self.NUMBER_OF_STARS):
            self.list_of_polygons.append(
                make_star_points(
                    left = star * self.SPACING_BETWEEN_STARS,
                    top = 0,
                    number_of_points = self.STAR_POINTS,
                    outer_radius = self.OUTER_RADIUS,
                    inner_radius = self.INNER_RADIUS,
                    outer_rotation_radians = self.OUTER_ROTATION_RADIANS,
                    inner_rotation_radians = self.INNER_ROTATION_RADIANS,
                ),
            )

class _RatingFilledImageShape(_RatingImageShape):
    FILL_COLOUR: str = '#FD3'
    LINE_THICKNESS: int = 0
    LINE_COLOUR: str = '#000'

class _RatingHollowImageShape(_RatingImageShape):
    FILL_COLOUR: str = '#888'
    LINE_THICKNESS: int = 0
    LINE_COLOUR: str = '#000'

class _UnknownAuthorImageShape:
    LINE_COLOUR: str = '#858'
    FILL_COLOUR: str = '#B8B'
    LINE_THICKNESS: int = 10
    DOT_RADIUS: int = 37

    def __init__(self) -> None:
        turtle: Turtle = Turtle()
        shape: TurtleShape = TurtleShape(turtle, Point(47, 78))
        shape \
            .bezier(Point(78, 9), Point(137, 58)) \
            .bezier(Point(204, 116), Point(118, 172)) \
            .bezier(Point(103, 187), Point(99, 205)) \
            .bezier(Point(88, 236), Point(65, 205)) \
            .bezier(Point(61, 190), Point(119, 131)) \
            .bezier(Point(152, 91), Point(102, 71)) \
            .bezier(Point(75, 67), Point(71, 91)) \
            .bezier(Point(71, 100), Point(63, 106)) \
            .bezier(Point(29, 116), shape.origin) \
            .scale(width = 1.8)

        self.original_image_width: int = ceil(shape.calc_width())
        self.original_image_height: int = ceil(shape.calc_height())
        self.dot_center: Point = Point(self.original_image_width / 2 - 30, self.original_image_height + 50)
        self.original_image_width += self.LINE_THICKNESS
        self.original_image_height = ceil(self.dot_center.y + self.DOT_RADIUS + self.LINE_THICKNESS / 2)
        self.list_of_points: list[Point] = shape.calc_points(Alignment.NORTH_WEST, align_x=ceil(self.LINE_THICKNESS / 2), align_y=ceil(self.LINE_THICKNESS / 2))

class _DeletedImageShape:
    ORIGINAL_IMAGE_WIDTH: int = 50
    ORIGINAL_IMAGE_HEIGHT: int = 50
    LINE_WIDTH: int = 10
    LINE_COLOUR: str = '#F31'
    BORDER_THICKNESS: int = ORIGINAL_IMAGE_WIDTH // 10

class _StatusImageShape:
    ORIGINAL_IMAGE_WIDTH: int = 50
    ORIGINAL_IMAGE_HEIGHT: int = 50
    LETTER_COLOUR: str = '#FFF'
    LETTER_WIDTH: int = 8
    DOT_TOP_OFFSET: int = 7
    STEM_TOP_OFFSET: int = 25
    STEM_HEIGHT: int = 15
    BACKGROUND_COLOUR: str = '#311'

class _TotmImageShape:
    LINE_THICKNESS: int = 5

    def __init__(self) -> None:
        turtle: Turtle = Turtle()
        trophy_body: TurtleShape = TurtleShape(turtle, Point(60, 60))
        trophy_body \
            .line(Point(170, 60)) \
            .bezier(Point(170, 210), Point(60, 210), trophy_body.origin)

        right_handle: TurtleShape = TurtleShape(turtle, Point(159, 80))
        right_handle \
            .bezier(Point(181, 51), Point(225, 65), Point(205, 101)) \
            .bezier(Point(185, 132), Point(178, 116), Point(167, 140)) \
            .bezier(Point(154, 164), Point(148, 124), Point(159, 120)) \
            .bezier(Point(197, 105), Point(209, 70), Point(182, 80)) \
            .bezier(Point(170, 84), Point(159, 100)) \
            .line(right_handle.origin)

        left_handle: TurtleShape = right_handle.copy()
        left_handle.flip(Flip.HORIZONTAL_AT_LEFT)
        left_handle.translate(left=77)

        trophy_base: TurtleShape = TurtleShape(turtle, Point(70, 200))
        trophy_base \
            .bezier(Point(100, 190), Point(100, 160)) \
            .bezier(Point(100, 130), Point(130, 130), Point(130, 160)) \
            .bezier(Point(130, 190), Point(160, 200)) \
            .line(Point(160, 220)) \
            .line(Point(70, 220)) \
            .line(trophy_base.origin) \

        trophy_body.raise_to_top()

        self.original_image_width: int = ceil(turtle.calc_width()) + self.LINE_THICKNESS
        self.original_image_height: int = ceil(turtle.calc_height()) + self.LINE_THICKNESS
        self.list_of_polygons: list[list[Point]] = []
        shape: TurtleShape
        for shape in turtle.list_of_shapes:
            self.list_of_polygons.append(shape.calc_points(Alignment.NORTH_WEST, align_x=self.LINE_THICKNESS / 2, align_y=self.LINE_THICKNESS / 2))

class _EosImageShape:
    FILL_COLOUR: str = '#FFF'
    LINE_COLOUR: str = '#78A'
    OUTLINE_THICKNESS: int = 9
    BONE_THICKNESS: int = 5

    def __init__(self) -> None:
        turtle: Turtle = Turtle()
        feather: TurtleShape = TurtleShape(turtle, Point(0, 132))
        feather \
            .bezier(Point(0, 32), Point(100, 47), Point(126, 0)) \
            .bezier(Point(126, 100), Point(26, 85), feather.origin)

        feather_bone: TurtleShape = TurtleShape(turtle, feather.origin)
        feather_bone.bezier(Point(0, 56), Point(126, 56), Point(126, 0))

        self.original_image_width: int = ceil(turtle.calc_width()) + self.OUTLINE_THICKNESS
        self.original_image_height: int = ceil(turtle.calc_height()) + self.OUTLINE_THICKNESS
        self.list_of_feather_poly_points: list[Point] = feather.calc_points(Alignment.NORTH_WEST, align_x=self.OUTLINE_THICKNESS / 2, align_y=self.OUTLINE_THICKNESS / 2)
        self.list_of_bone_poly_points = feather_bone.calc_points(Alignment.NORTH_WEST, align_x=self.OUTLINE_THICKNESS / 2, align_y=self.OUTLINE_THICKNESS / 2)

class _FlashImageShape:
    FILL_COLOUR: str = '#FFF'
    LINE_COLOUR: str = '#78A'
    LINE_THICKNESS: int = 9

    def __init__(self) -> None:
        turtle: Turtle = Turtle()
        shape: TurtleShape = TurtleShape(turtle, Point(0, 116))
        shape \
            .bezier(Point(78, 116), Point(27, 0), Point(135, 0)) \
            .line(Point(135, 34)) \
            .bezier(Point(91, 34), Point(91, 63)) \
            .line(Point(113, 63)) \
            .line(Point(113, 94)) \
            .line(Point(80, 94)) \
            .bezier(Point(41, 156), Point(15, 156)) \
            .line(Point(0, 156)) \
            .line(shape.origin)

        self.original_image_width: int = ceil(turtle.calc_width()) + self.LINE_THICKNESS
        self.original_image_height: int = ceil(turtle.calc_height()) + self.LINE_THICKNESS
        self.list_of_points: list[Point] = shape.calc_points(Alignment.NORTH_WEST, align_x=self.LINE_THICKNESS / 2, align_y=self.LINE_THICKNESS / 2)

class _AudioImageShape:
    FILL_COLOUR: str = '#78A'
    LINE_COLOUR: str = '#FFF'
    SHAPE_THICKNESS: int = 20
    LINE_THICKNESS: int = 7

    def __init__(self) -> None:
        turtle: Turtle = Turtle()
        shape: TurtleShape = TurtleShape(turtle, Point(8, 82))
        shape \
            .line(Point(23, 58)) \
            .line(Point(38, 101)) \
            .line(Point(68, 7)) \
            .line(Point(78, 119)) \
            .line(Point(94, 47)) \
            .line(Point(107, 81)) \
            .line(Point(122, 52)) \
            .line(Point(132, 70))

        self.original_image_width: int = ceil(turtle.calc_width()) + self.SHAPE_THICKNESS
        self.original_image_height: int = ceil(turtle.calc_height()) + self.SHAPE_THICKNESS
        self.list_of_points: list[Point] = shape.calc_points(Alignment.NORTH_WEST, align_x=self.SHAPE_THICKNESS / 2, align_y=self.SHAPE_THICKNESS / 2)

class _RegularImageShape:
    FILL_COLOUR: str = '#FFF'
    LINE_COLOUR: str = '#78A'
    OUTLINE_THICKNESS: int = 6

    def __init__(self) -> None:
        turtle: Turtle = Turtle()

        left_page_top: TurtleShape = TurtleShape(turtle, Point(115, 161))
        left_page_top \
            .bezier(Point(88, 135), Point(50, 145)) \
            .line(Point(50, 237)) \
            .bezier(Point(88, 231), Point(115, 258)) \
            .line(left_page_top.origin)

        left_page_top.copy() \
            .scale(width=0.9, height=0.6) \
            .align(Alignment.SOUTH_EAST, left_page_top.calc_bottom_right()) \
            .lower_to_bottom()

        left_page_top.copy() \
            .scale(width=0.8, height=0.2) \
            .align(Alignment.SOUTH_EAST, left_page_top.calc_bottom_right()) \
            .lower_to_bottom()

        right_page_top: TurtleShape = left_page_top.copy() \
            .flip(Flip.HORIZONTAL_AT_RIGHT)

        right_page_top.copy() \
            .scale(width=0.9, height=0.6) \
            .align(Alignment.SOUTH_WEST, right_page_top.calc_bottom_left()) \
            .lower_to_bottom()

        right_page_top.copy() \
            .scale(width=0.8, height=0.2) \
            .align(Alignment.SOUTH_WEST, right_page_top.calc_bottom_left()) \
            .lower_to_bottom()

        left_text_line: TurtleShape = TurtleShape(turtle, Point(105, 167)) \
            .bezier(Point(83, 150), Point(62, 156))

        right_text_line: TurtleShape = left_text_line.copy() \
            .flip(Flip.HORIZONTAL_AT_RIGHT) \
            .translate(right = 2 * (left_page_top.calc_max_x() - left_text_line.calc_max_x()))

        for _ in range(6):
            left_text_line = left_text_line.copy().translate(down=11)
            right_text_line = right_text_line.copy().translate(down=11)

        self.original_image_width: int = ceil(turtle.calc_width()) + self.OUTLINE_THICKNESS
        self.original_image_height: int = ceil(turtle.calc_height()) + self.OUTLINE_THICKNESS
        self.list_of_polygons: list[list[Point]] = []
        shape: TurtleShape
        for shape in turtle.list_of_shapes:
            self.list_of_polygons.append(shape.calc_points(Alignment.NORTH_WEST, align_x=self.OUTLINE_THICKNESS / 2, align_y=self.OUTLINE_THICKNESS / 2))

_RATING_FILLED_IMAGE_SHAPE = Singleton(_RatingFilledImageShape)
_RATING_HOLLOW_IMAGE_SHAPE = Singleton(_RatingHollowImageShape)
_MISSING_AUTHOR_IMAGE_SHAPE = Singleton(_UnknownAuthorImageShape)
_DELETED_IMAGE_SHAPE = Singleton(_DeletedImageShape)
_TOTM_IMAGE_SHAPE = Singleton(_TotmImageShape)
_EOS_IMAGE_SHAPE = Singleton(_EosImageShape)
_FLASH_IMAGE_SHAPE = Singleton(_FlashImageShape)
_AUDIO_IMAGE_SHAPE = Singleton(_AudioImageShape)
_REGULAR_IMAGE_SHAPE = Singleton(_RegularImageShape)
_STATUS_IMAGE_SHAPE = Singleton(_StatusImageShape)

def render_rating_filled_image(*, image_height: int) -> Image.Image:
    shape: _RatingFilledImageShape = _RATING_FILLED_IMAGE_SHAPE.instance
    image: Image.Image = Image.new('RGBA', size=(shape.ORIGINAL_IMAGE_WIDTH, shape.ORIGINAL_IMAGE_HEIGHT))
    draw: ImageDraw.ImageDraw = ImageDraw.Draw(image)
    list_of_points: list[Point]
    for list_of_points in shape.list_of_polygons:
        draw.polygon(list_of_points, fill=shape.FILL_COLOUR, outline=shape.LINE_COLOUR, width=shape.LINE_THICKNESS)
    image_width: int = image_height * shape.ORIGINAL_IMAGE_WIDTH // shape.ORIGINAL_IMAGE_HEIGHT
    return image.resize((image_width, image_height), resample=Image.Resampling.BICUBIC)

def render_rating_hollow_image(*, image_height: int) -> Image.Image:
    shape: _RatingHollowImageShape = _RATING_HOLLOW_IMAGE_SHAPE.instance
    image: Image.Image = Image.new('RGBA', size=(shape.ORIGINAL_IMAGE_WIDTH, shape.ORIGINAL_IMAGE_HEIGHT))
    draw: ImageDraw.ImageDraw = ImageDraw.Draw(image)
    list_of_points: list[Point]
    for list_of_points in shape.list_of_polygons:
        draw.polygon(list_of_points, fill=shape.FILL_COLOUR, outline=shape.LINE_COLOUR, width=shape.LINE_THICKNESS)
    image_width: int = image_height * shape.ORIGINAL_IMAGE_WIDTH // shape.ORIGINAL_IMAGE_HEIGHT
    return image.resize((image_width, image_height), resample=Image.Resampling.BICUBIC)

def render_unknown_author_image(*, image_height: int) -> Image.Image:
    shape: _UnknownAuthorImageShape = _MISSING_AUTHOR_IMAGE_SHAPE.instance
    image = Image.new('RGBA', size=(shape.original_image_width, shape.original_image_height))
    draw: ImageDraw.ImageDraw = ImageDraw.Draw(image)
    draw.polygon(shape.list_of_points, fill=shape.FILL_COLOUR)
    draw.line(shape.list_of_points, fill=shape.LINE_COLOUR, width=shape.LINE_THICKNESS, joint='curve')
    draw.ellipse((shape.dot_center.x - shape.DOT_RADIUS, shape.dot_center.y - shape.DOT_RADIUS, shape.dot_center.x + shape.DOT_RADIUS, shape.dot_center.y + shape.DOT_RADIUS), fill=shape.FILL_COLOUR, outline=shape.LINE_COLOUR, width=shape.LINE_THICKNESS)
    image_width: int = image_height * shape.original_image_width // shape.original_image_height
    return image.resize((image_width, image_height), resample=Image.Resampling.BICUBIC)

def _render_deleted_image(*, image_height: int) -> Image.Image:
    shape: _DeletedImageShape = _DELETED_IMAGE_SHAPE.instance
    image: Image.Image = Image.new('RGBA', size=(shape.ORIGINAL_IMAGE_WIDTH, shape.ORIGINAL_IMAGE_HEIGHT))
    draw: ImageDraw.ImageDraw = ImageDraw.Draw(image)
    draw.line((shape.BORDER_THICKNESS, shape.BORDER_THICKNESS, shape.ORIGINAL_IMAGE_WIDTH - shape.BORDER_THICKNESS, shape.ORIGINAL_IMAGE_HEIGHT - shape.BORDER_THICKNESS), fill=shape.LINE_COLOUR, width=shape.LINE_WIDTH)
    draw.line((shape.BORDER_THICKNESS, shape.ORIGINAL_IMAGE_HEIGHT - shape.BORDER_THICKNESS, shape.ORIGINAL_IMAGE_WIDTH - shape.BORDER_THICKNESS, shape.BORDER_THICKNESS), fill=shape.LINE_COLOUR, width=shape.LINE_WIDTH)
    image_width: int = image_height * shape.ORIGINAL_IMAGE_WIDTH // shape.ORIGINAL_IMAGE_HEIGHT
    return image.resize((image_width, image_height), resample=Image.Resampling.BICUBIC)

render_deleted_tease_image = _render_deleted_image
render_gone_author_image = _render_deleted_image

def _render_totm_image(*, line_colour: str, fill_colour: str, image_height: int) -> Image.Image:
    shape: _TotmImageShape = _TOTM_IMAGE_SHAPE.instance
    image: Image.Image = Image.new('RGBA', size=(shape.original_image_width, shape.original_image_height))
    draw: ImageDraw.ImageDraw = ImageDraw.Draw(image)
    list_of_points: list[Point]
    for list_of_points in shape.list_of_polygons:
        draw.polygon(list_of_points, fill=fill_colour)
        draw.line(list_of_points, fill=line_colour, width=shape.LINE_THICKNESS, joint='curve')
    return image.resize((image_height * shape.original_image_width // shape.original_image_height, image_height), resample=Image.Resampling.BICUBIC)

def render_totm_nominee_image(*, image_height: int) -> Image.Image:
    return _render_totm_image(line_colour=_TOTM_NOMINEE_LINE_COLOUR, fill_colour=_TOTM_NOMINEE_FILL_COLOUR, image_height=image_height)

def render_totm_winner_image(*, image_height: int) -> Image.Image:
    return _render_totm_image(line_colour=_TOTM_WINNER_LINE_COLOUR, fill_colour=_TOTM_WINNER_FILL_COLOUR, image_height=image_height)

def render_totm_header_image(*, image_height: int) -> Image.Image:
    nominee_image: Image.Image = _render_totm_image(line_colour=_TOTM_NOMINEE_LINE_COLOUR, fill_colour=_TOTM_NOMINEE_FILL_COLOUR, image_height=image_height)
    winner_image: Image.Image = _render_totm_image(line_colour=_TOTM_WINNER_LINE_COLOUR, fill_colour=_TOTM_WINNER_FILL_COLOUR, image_height=image_height)
    nominee_image = nominee_image.crop((0, 0, nominee_image.width // 2, nominee_image.height))
    winner_image = winner_image.crop((winner_image.width // 2, 0, winner_image.width, nominee_image.height))
    mixed_image: Image.Image = Image.new('RGBA', size=(nominee_image.width + winner_image.width, max(nominee_image.height, winner_image.height)))
    mixed_image.paste(nominee_image, (0, 0))
    mixed_image.paste(winner_image, (nominee_image.width, 0))
    return mixed_image

def render_eos_image(*, image_height: int) -> Image.Image:
    shape: _EosImageShape = _EOS_IMAGE_SHAPE.instance
    image: Image.Image = Image.new('RGBA', size=(shape.original_image_width, shape.original_image_height))
    draw: ImageDraw.ImageDraw = ImageDraw.Draw(image)
    draw.polygon(shape.list_of_feather_poly_points, fill=_EosImageShape.FILL_COLOUR)
    draw.line(shape.list_of_feather_poly_points, fill=_EosImageShape.LINE_COLOUR, width=_EosImageShape.OUTLINE_THICKNESS, joint='curve')
    draw.line(shape.list_of_bone_poly_points, fill=_EosImageShape.LINE_COLOUR, width=_EosImageShape.BONE_THICKNESS, joint='curve')
    return image.resize((image_height * shape.original_image_width // shape.original_image_height, image_height), resample=Image.Resampling.BICUBIC)

def render_flash_image(*, image_height: int) -> Image.Image:
    shape: _FlashImageShape = _FLASH_IMAGE_SHAPE.instance
    image: Image.Image = Image.new('RGBA', size=(shape.original_image_width, shape.original_image_height))
    draw: ImageDraw.ImageDraw = ImageDraw.Draw(image)
    draw.polygon(shape.list_of_points, fill=shape.FILL_COLOUR)
    draw.line(shape.list_of_points, fill=shape.LINE_COLOUR, width=shape.LINE_THICKNESS, joint='curve')
    return image.resize((image_height * shape.original_image_width // shape.original_image_height, image_height), resample=Image.Resampling.BICUBIC)

def render_audio_image(*, image_height: int) -> Image.Image:
    shape: _AudioImageShape = _AUDIO_IMAGE_SHAPE.instance
    image: Image.Image = Image.new('RGBA', size=(shape.original_image_width, shape.original_image_height))
    draw: ImageDraw.ImageDraw = ImageDraw.Draw(image)
    draw.line(shape.list_of_points, fill=shape.FILL_COLOUR, width=shape.SHAPE_THICKNESS, joint='curve')
    draw.line(shape.list_of_points, fill=shape.LINE_COLOUR, width=shape.LINE_THICKNESS, joint='curve')
    return image.resize((image_height * shape.original_image_width // shape.original_image_height, image_height), resample=Image.Resampling.BICUBIC)

def render_regular_image(*, image_height: int) -> Image.Image:
    shape: _RegularImageShape = _REGULAR_IMAGE_SHAPE.instance
    image = Image.new('RGBA', size=(shape.original_image_width, shape.original_image_height))
    draw: ImageDraw.ImageDraw = ImageDraw.Draw(image)
    list_of_points: list[Point]
    for list_of_points in shape.list_of_polygons:
        draw.polygon(list_of_points, fill=shape.FILL_COLOUR)
        draw.line(list_of_points, fill=shape.LINE_COLOUR, width=shape.OUTLINE_THICKNESS, joint='curve')
    return image.resize((image_height * shape.original_image_width // shape.original_image_height, image_height), resample=Image.Resampling.BICUBIC)

def render_status_image(*, image_height: int) -> Image.Image:
    shape: _StatusImageShape = _STATUS_IMAGE_SHAPE.instance
    image = Image.new('RGBA', size=(shape.ORIGINAL_IMAGE_WIDTH, shape.ORIGINAL_IMAGE_HEIGHT))
    draw: ImageDraw.ImageDraw = ImageDraw.Draw(image)
    draw.ellipse((0, 0, shape.ORIGINAL_IMAGE_WIDTH, shape.ORIGINAL_IMAGE_HEIGHT), shape.BACKGROUND_COLOUR, width=0)
    draw.ellipse(((shape.ORIGINAL_IMAGE_WIDTH - shape.LETTER_WIDTH) / 2, shape.DOT_TOP_OFFSET, (shape.ORIGINAL_IMAGE_WIDTH + shape.LETTER_WIDTH) / 2, shape.DOT_TOP_OFFSET + shape.LETTER_WIDTH), shape.LETTER_COLOUR, width=0)
    _draw_capped_line(draw, shape.ORIGINAL_IMAGE_WIDTH / 2, shape.STEM_TOP_OFFSET, shape.ORIGINAL_IMAGE_WIDTH / 2, shape.STEM_TOP_OFFSET + shape.STEM_HEIGHT, fill=shape.LETTER_COLOUR, width=shape.LETTER_WIDTH)
    return image.resize((image_height * shape.ORIGINAL_IMAGE_WIDTH // shape.ORIGINAL_IMAGE_HEIGHT, image_height), resample=Image.Resampling.BICUBIC)

def _draw_capped_line(draw: ImageDraw.ImageDraw, x1: float, y1: float, x2: float, y2: float, *, fill: str, width: int) -> None:
    draw.line((x1, y1, x2, y2), fill=fill, width=width+1)
    draw.ellipse((x1 - width / 2, y1 - width / 2, x1 + width / 2, y1 + width / 2), fill=fill, width=0)
    draw.ellipse((x2 - width / 2, y2 - width / 2, x2 + width / 2, y2 + width / 2), fill=fill, width=0)
