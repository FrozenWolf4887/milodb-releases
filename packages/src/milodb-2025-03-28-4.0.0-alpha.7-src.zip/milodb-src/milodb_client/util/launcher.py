# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import os
import webbrowser
from pathlib import Path
from milodb_common.config.i_launch_config import ILaunchConfig, LaunchOption
from milodb_common.output.print.i_printer import IPrinter

def launch(launch_config: ILaunchConfig, filepath: Path | None, url: str | None, normal_printer: IPrinter, warning_printer: IPrinter, error_printer: IPrinter) -> None:
    match launch_config.launch_option:
        case LaunchOption.DEFAULT:
            _launch_default(filepath, url, normal_printer, error_printer)
        case LaunchOption.CUSTOM:
            _launch_custom(launch_config, filepath, url, normal_printer, warning_printer)
        case LaunchOption.NONE:
            pass

def _launch_default(filepath: Path | None, url: str | None, normal_printer: IPrinter, error_printer: IPrinter) -> None:
    target: str | None = None
    if filepath:
        normal_printer.writeln(f"Opening '{filepath}' in default web browser")
        target = str(filepath)
    elif url:
        normal_printer.writeln(f"Opening '{url}' in default web browser")
        target = url

    if target:
        try:
            was_successful: bool = webbrowser.open(target)
        except webbrowser.Error as ex:
            error_printer.writeln(f'Failed to launch default web browser: {ex}')
        else:
            if not was_successful:
                error_printer.writeln('Failed to identify default web browser')

def _launch_custom(launch_config: ILaunchConfig, filepath: Path | None, url: str | None, normal_printer: IPrinter, warning_printer: IPrinter) -> None:
    expanded_command: str = launch_config.custom_launch_command
    if filepath:
        expanded_command = expanded_command.replace('$p', str(filepath))
    if url:
        expanded_command = expanded_command.replace('$u', url)
    normal_printer.writeln(f"Launching: {launch_config.custom_launch_command}")
    normal_printer.writeln(f"       as: {expanded_command}")

    exit_code: int = os.system(expanded_command) # noqa: S605 Starting a process with a shell, possible injection detected
    if exit_code != 0:
        warning_printer.writeln(f'Application returned with exit code {exit_code}')
