from typing import Optional

MILODB_VERSION: Optional[str] = '1.6'
MILODB_DATE: Optional[str] = '2022-09-30'
