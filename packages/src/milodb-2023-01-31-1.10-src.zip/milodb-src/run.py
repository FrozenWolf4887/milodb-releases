#!/usr/bin/env python3

import sys
if sys.version_info >= (3, 7):
    from milodb.main import Main
else:
    print("Python version 3.7 or greater required")
    print("Actual version is " + sys.version)
    sys.exit(1)

if __name__ == "__main__":
    Main().run()
