@echo off
setlocal
echo ** Prepare virtual environment
python -m venv "%TEMP%\mvdb\venv" --clear
call "%TEMP%\mvdb\venv\Scripts\activate.bat"
pip install -r requirements-windows.txt
echo ** Build executable
set PYTHONOPTIMIZE=2
pyinstaller --distpath bin --workpath "%TEMP%\mvdb\build" --clean ..\milodb.spec
echo "** Save requirements"
pip freeze > "requirements-windows.txt"
type "requirements-windows.txt"
call "%TEMP%\mvdb\venv\Scripts\deactivate.bat"
