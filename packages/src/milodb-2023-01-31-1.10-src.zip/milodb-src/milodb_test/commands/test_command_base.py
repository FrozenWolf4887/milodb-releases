from typing import Callable, Dict, List, Optional, Type, Union
from unittest import TestCase
from unittest.mock import Mock
from milodb import query
from milodb.command_framework.argument_stream import ArgumentStream, ArgumentStreamError
from milodb.command_framework.i_command import CommandLoadError, ICommand
from milodb.command_framework.i_command_factory import ICommandFactory
from milodb.command_framework.i_command_loader import CommandLoadDelegateError
from milodb.command_framework.i_help_info import IHelpInfo
from milodb.command_framework.quit_flag import QuitFlag
from milodb.commands.command import Command
from milodb.commands.command_context import CommandContext
from milodb.commands.help_info import HelpInfo
from milodb.commands.sort_keys import OrderedSortKey, default_list_of_active_sort_keys, list_of_available_sort_keys
from milodb.config.framework import IConfig
from milodb.config.session_config import SessionConfig
from milodb.database import Database
from milodb.output.output_sink import OutputSink, OutputWriter
from milodb.output.outputter import Outputter
from milodb.tokeniser import ExpandingTokenStream, StartEnd, Token
from milodb.user_variables import UserVariables

class MockCommandFactory(ICommandFactory):
    def __init__(self, map_of_command_name_to_class: Dict[str, Type[Command]], map_of_command_name_to_help_class: Dict[str, Type[HelpInfo]]):
        self._map_of_command_name_to_class: Dict[str, Type[Command]] = map_of_command_name_to_class
        self._map_of_command_name_to_help_class: Dict[str, Type[HelpInfo]] = map_of_command_name_to_help_class
        self._context: Optional[CommandContext] = None

    def set_command_context(self, command_context: CommandContext) -> None:
        self._context = command_context

    def get_list_of_command_names(self) -> List[str]:
        return list(self._map_of_command_name_to_class)

    def try_get_command_from_name(self, command_name: str) -> Optional[ICommand]:
        if self._context:
            command_class: Optional[Type[Command]] = self._map_of_command_name_to_class.get(command_name)
            if command_class:
                return command_class(self._context)
        return None

    def try_get_command_help_from_name(self, command_name: str) -> Optional[IHelpInfo]:
        if self._context:
            help_class: Optional[Type[HelpInfo]] = self._map_of_command_name_to_help_class.get(command_name)
            if help_class:
                return help_class(self._context)
        return None

class CommandTestBase(TestCase):
    def setUp(self) -> None:
        database = Mock(Database)
        self._map_of_command_name_to_class: Dict[str, Type[Command]] = {}
        self._map_of_command_name_to_help_class: Dict[str, Type[HelpInfo]] = {}
        command_factory: MockCommandFactory = MockCommandFactory(self._map_of_command_name_to_class, self._map_of_command_name_to_help_class)
        self.normal_writer = Mock(OutputSink)
        self.error_writer = Mock(OutputWriter)
        self.warning_writer = Mock(OutputWriter)
        self.session_config = SessionConfig(self.normal_writer, self.error_writer, self.warning_writer)
        self._dictionary_of_variables: Dict[str, str] = {}
        self.mock_variables = Mock(UserVariables)
        mock_try_retrive: Callable[[str], Optional[str]] = self._dictionary_of_variables.get
        self.mock_variables.try_retrieve = mock_try_retrive
        self.mock_variables.get_list_of_names = lambda: list(self._dictionary_of_variables.keys())
        self.mock_variables.set = Mock()
        system_config = Mock(IConfig)
        list_of_tease_matches: Optional[List[query.TeaseMatch]] = None
        list_of_active_sort_keys: List[OrderedSortKey] = default_list_of_active_sort_keys.copy()
        self.mock_outputter = Mock(Outputter)
        list_of_outputters: List[Outputter] = [self.mock_outputter]
        self.context: CommandContext = CommandContext(
            QuitFlag(), database, command_factory,
            self.session_config, system_config, self.mock_variables,
            list_of_tease_matches,
            list_of_available_sort_keys, list_of_active_sort_keys,
            list_of_outputters, self.mock_outputter)
        command_factory.set_command_context(self.context)

        self.list_of_tokens: List[Optional[Token]] = []
        self.mock_token_stream = Mock(ExpandingTokenStream)

        self._command_under_test: Optional[ICommand] = None
        self._load_exception: Optional[Union[ArgumentStreamError, CommandLoadError, CommandLoadDelegateError]] = None
        self._list_of_next_text: List[str] = []

    def set_command_class_under_test(self, command_class: Type[Command], command_name: Optional[str] = None) -> None:
        self._command_under_test = command_class(self.context)
        self._map_of_command_name_to_class[command_name or 'stubCommandName'] = command_class

    def add_command_help_to_factory(self, help_class: Type[HelpInfo], command_name: str) -> None:
        self._map_of_command_name_to_help_class[command_name] = help_class

    def get_list_of_command_names(self) -> List[str]:
        return list(self._map_of_command_name_to_class)

    def add_variable(self, name: str, value: str) -> None:
        self._dictionary_of_variables[name] = value

    def load_test(self, list_of_token_text: Optional[List[str]], remaining_raw_text: Optional[str] = None, expanded_raw_text: Optional[str] = None) -> None:
        self.assertIsNotNone(self._command_under_test)
        stub_command_token: Optional[Token] = None
        self.list_of_tokens = [stub_command_token]
        if self._command_under_test:
            if not list_of_token_text:
                self.mock_token_stream.next = Mock(return_value=None)
                self.mock_token_stream.get_remaining_raw_text = Mock(return_value='')
            else:
                self.list_of_tokens.extend(self.create_fake_tokens(list_of_token_text))
                self.mock_token_stream.next = Mock(side_effect=self.list_of_tokens[1:])
                self.mock_token_stream.get_expanded_raw_text = Mock(return_value=(expanded_raw_text or ''))
                self.mock_token_stream.get_remaining_raw_text = Mock(return_value=(remaining_raw_text or ''))
            argument_stream: ArgumentStream = ArgumentStream(self.mock_token_stream)
            try:
                self._list_of_next_text = self._command_under_test.load(argument_stream)
            except (ArgumentStreamError, CommandLoadError, CommandLoadDelegateError) as ex:
                self._load_exception = ex

    def execute_test(self, list_of_token_text: Optional[List[str]], remaining_raw_text: Optional[str] = None, expanded_raw_text: Optional[str] = None) -> None:
        self.load_test(list_of_token_text, remaining_raw_text, expanded_raw_text)
        if self._load_exception is None and self._command_under_test:
            self._command_under_test.execute()
        else:
            self.fail("Parsing should have been successful but wasn't")

    def create_fake_tokens(self, list_of_token_text: List[str]) -> List[Optional[Token]]:
        list_of_tokens: List[Optional[Token]] = []
        token_number: int = 1
        token_start_index: int = 0
        for token_text in list_of_token_text:
            token_end_index: int = token_start_index + len(token_text)
            outer_indices: StartEnd = StartEnd(token_start_index, token_end_index)
            inner_indices: StartEnd = StartEnd(token_start_index, token_end_index)
            if token_text and token_text[0] in ['"\'']:
                inner_indices.start += 1
                inner_indices.end -= 1
            list_of_tokens.append(Token(token_text, token_number, outer_indices, inner_indices))
            token_start_index = token_end_index + 1
            token_number += 1
        list_of_tokens.append(None)
        return list_of_tokens

    def assert_successful(self, list_of_next_text: Optional[List[str]] = None) -> None:
        self.assertIsNone(self._load_exception, f"Load should have been successful but wasn't\nException was: {self._load_exception}")
        if list_of_next_text is not None:
            self.assertListEqual(list_of_next_text, self._list_of_next_text, 'Mismatch in expected next text')

    def assert_argument_error(self, fault_token_index: Optional[int], fault_text: str, list_of_expected_text: List[str]) -> None:
        self.assertIsInstance(self._load_exception, ArgumentStreamError)
        if isinstance(self._load_exception, ArgumentStreamError):
            if fault_token_index is not None:
                self.assertEqual(
                    self.list_of_tokens[fault_token_index], self._load_exception.fault_token,
                    'Unexpected fault token reported')
            else:
                self.assertIsNone(
                    self._load_exception.fault_token,
                    'Unexpected fault token reported')

            self.assertEqual(
                fault_text, self._load_exception.message,
                f"Expected error message of '{fault_text}' but got '{self._load_exception.message}'")

            self.assertListEqual(sorted(list_of_expected_text), sorted(self._load_exception.list_of_expected_text))

    def assert_load_error(self, fault_token_index: Optional[int], fault_text: str, list_of_expected_text: List[str]) -> None:
        self.assertIsInstance(self._load_exception, CommandLoadError)
        if isinstance(self._load_exception, CommandLoadError):
            if fault_token_index is not None:
                self.assertEqual(
                    self.list_of_tokens[fault_token_index], self._load_exception.fault_token,
                    'Unexpected fault token reported')
            else:
                self.assertIsNone(
                    self._load_exception.fault_token,
                    'Unexpected fault token reported')

            self.assertEqual(
                fault_text, self._load_exception.message,
                f"Expected error message of '{fault_text}' but got '{self._load_exception.message}'")

            self.assertListEqual(sorted(list_of_expected_text), sorted(self._load_exception.list_of_expected_text))
