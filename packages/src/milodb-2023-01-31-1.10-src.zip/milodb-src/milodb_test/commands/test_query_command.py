from milodb.commands.query_command import QueryCommand
from milodb_test.commands.error_messages import ErrorMessage
from milodb_test.commands.test_command_base import CommandTestBase

class QueryCommandTestBase(CommandTestBase):
    def setUp(self) -> None:
        super().setUp()
        self.set_command_class_under_test(QueryCommand)

class TestQueryCommand(QueryCommandTestBase):
    def test_without_arguments_returns_failure(self) -> None:
        self.load_test([])
        self.assert_load_error(
            None, 'Unexpected end of input when expecting a query',
            ['title', 'summary', 'teaseId', 'author', 'authorId', 'text', 'date', 'type', 'tag', 'rating', '(', 'not', 'totm'])

    def test_with_one_field_name_returns_failure(self) -> None:
        self.load_test(['title'])
        self.assert_argument_error(
            None, ErrorMessage.INSUFFICIENT,
            ['is', 'contains', 'matches'])

    def test_with_valid_query_returns_success(self) -> None:
        self.load_test(['title', 'contains', 'mango'])
        self.assert_successful()
