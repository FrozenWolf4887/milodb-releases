from typing import Callable, List, Optional
from unittest.mock import Mock, call
from milodb.commands.list_command import ListCommand
from milodb.query import TeaseMatch
from milodb.tease import Tease
from milodb_test.commands.error_messages import ErrorMessage
from milodb_test.commands.test_command_base import CommandTestBase

class ListCommandTestBase(CommandTestBase):
    def setUp(self) -> None:
        super().setUp()
        self.set_command_class_under_test(ListCommand)

class TestListCommandParse(ListCommandTestBase):
    def test_without_arguments_returns_success(self) -> None:
        self.load_test([])
        self.assert_successful()

    def test_with_one_index_returns_success(self) -> None:
        self.load_test(['1234'])
        self.assert_successful()

    def test_with_three_indices_returns_success(self) -> None:
        self.load_test(['1234', '5678', '9012'])
        self.assert_successful()

    def test_with_signed_index_returns_failure(self) -> None:
        self.load_test(['1234', '-5678', '9012'])
        self.assert_argument_error(2, ErrorMessage.INVALID_REFID, [])

    def test_with_one_teaseid_returns_success(self) -> None:
        self.load_test(['#1250'])
        self.assert_successful()

    def test_with_three_teaseids_returns_success(self) -> None:
        self.load_test(['#1234', '#5678', '#9072'])
        self.assert_successful()

    def test_with_signed_teaseid_returns_failure(self) -> None:
        self.load_test(['#1234', '#-5678', '#9012'])
        self.assert_argument_error(2, ErrorMessage.INVALID_TEASEID, [])

    def test_with_one_authorid_returns_success(self) -> None:
        self.load_test(['@1234'])
        self.assert_successful()

    def test_with_three_authorids_returns_success(self) -> None:
        self.load_test(['@1234', '@5678', '@9012'])
        self.assert_successful()

    def test_with_signed_authorid_returns_failure(self) -> None:
        self.load_test(['@1234', '@-5678', '@9012'])
        self.assert_argument_error(2, ErrorMessage.INVALID_AUTHORID, [])

    def test_with_mixed_refids_returns_success(self) -> None:
        self.load_test(['@1234', '5678', '#9012'])
        self.assert_successful()

    def test_with_non_refid_returns_failure(self) -> None:
        self.load_test(['mango', '5678', '9012'])
        self.assert_argument_error(1, ErrorMessage.INVALID_REFID, [])

class TestListCommandExecute(ListCommandTestBase):
    def setUp(self) -> None:
        super().setUp()
        self.mock_tease_0 = Mock(Tease)
        self.mock_tease_1 = Mock(Tease)
        self.mock_tease_2 = Mock(Tease)
        self.mock_tease_3 = Mock(Tease)
        self.mock_tease_4 = Mock(Tease)
        type(self.mock_tease_0).tease_id = Mock(return_value=1000)
        type(self.mock_tease_0).author_id = Mock(return_value=4567)
        type(self.mock_tease_1).tease_id = Mock(return_value=1234)
        type(self.mock_tease_1).author_id = Mock(return_value=6431)
        type(self.mock_tease_2).tease_id = Mock(return_value=5678)
        type(self.mock_tease_2).author_id = Mock(return_value=4567)
        type(self.mock_tease_3).tease_id = Mock(return_value=2000)
        type(self.mock_tease_3).author_id = Mock(return_value=6431)
        type(self.mock_tease_4).tease_id = Mock(return_value=8721)
        type(self.mock_tease_4).author_id = Mock(return_value=7213)
        self.fake_tease_match_0: TeaseMatch = TeaseMatch(0, self.mock_tease_0, [])
        self.fake_tease_match_1: TeaseMatch = TeaseMatch(1, self.mock_tease_1, [])
        self.fake_tease_match_2: TeaseMatch = TeaseMatch(2, self.mock_tease_2, [])
        self.fake_list_of_tease_matches: List[TeaseMatch] = [self.fake_tease_match_0, self.fake_tease_match_1, self.fake_tease_match_2]

    def test_without_arguments_and_no_matches_outputs_error(self) -> None:
        self.execute_test([])

        self.error_writer.writeln.assert_called_once_with('No teases available to list')
        self.mock_outputter.print_list_of_teases.assert_not_called()

    def test_without_arguments_and_some_matches_calls_outputter(self) -> None:
        self.context.list_of_tease_matches = self.fake_list_of_tease_matches

        self.execute_test([])

        self.normal_writer.writeln.assert_not_called()
        self.mock_outputter.print_list_of_teases.assert_called_once_with(self.fake_list_of_tease_matches)

    def test_with_one_in_range_index_calls_outputter(self) -> None:
        self.context.list_of_tease_matches = self.fake_list_of_tease_matches

        self.execute_test(['1'])

        self.normal_writer.writeln.assert_not_called()
        self.mock_outputter.print_list_of_teases.assert_called_once_with([self.fake_tease_match_1])

    def test_with_one_out_of_range_index_outputs_error(self) -> None:
        self.context.list_of_tease_matches = self.fake_list_of_tease_matches

        self.execute_test(['4'])

        self.error_writer.writeln.assert_has_calls([call("Match index '4' is out of range"), call('No teases available to list')])
        self.mock_outputter.print_list_of_teases.assert_not_called()

    def test_with_one_in_range_and_one_out_of_range_outputs_error(self) -> None:
        self.context.list_of_tease_matches = self.fake_list_of_tease_matches

        self.execute_test(['1', '6'])

        self.error_writer.writeln.assert_has_calls([call("Match index '6' is out of range"), call('No teases available to list')])
        self.mock_outputter.print_list_of_teases.assert_not_called()

    def test_with_one_existing_teaseid_in_matches_calls_outputter(self) -> None:
        self.context.list_of_tease_matches = self.fake_list_of_tease_matches

        self.execute_test(['#1234'])

        self.normal_writer.writeln.assert_not_called()
        self.mock_outputter.print_list_of_teases.assert_called_once_with([self.fake_tease_match_1])

    def test_with_one_existing_teaseid_in_database_calls_outputter(self) -> None:
        self.context.list_of_tease_matches = self.fake_list_of_tease_matches
        mock_try_get_tease: Callable[[int], Optional[Tease]] = lambda tease_id: self.mock_tease_3 if tease_id == 2000 else None
        setattr(self.context.database, "try_get_tease", Mock(side_effect=mock_try_get_tease))

        self.execute_test(['#2000'])

        self.normal_writer.writeln.assert_not_called()
        self.mock_outputter.print_list_of_teases.assert_called_once()
        list_passed: List[TeaseMatch] = self.mock_outputter.print_list_of_teases.call_args.args[0]
        self.assertEqual(1, len(list_passed))
        self.assertIsNone(list_passed[0].index_of_match)
        self.assertListEqual([], list_passed[0].list_of_query_matches)
        self.assertIs(self.mock_tease_3, list_passed[0].tease)

    def test_with_one_non_existing_teaseid_outputs_error(self) -> None:
        self.context.list_of_tease_matches = self.fake_list_of_tease_matches
        setattr(self.context.database, "try_get_tease", Mock(return_value=None))

        self.execute_test(['#1235'])

        self.error_writer.writeln.assert_has_calls([call("Unable to find tease for tease id '1235'"), call('No teases available to list')])
        self.mock_outputter.print_list_of_teases.assert_not_called()

    def test_with_one_teaseid_in_matches_and_one_in_database_calls_outputter(self) -> None:
        self.context.list_of_tease_matches = self.fake_list_of_tease_matches
        mock_try_get_tease: Callable[[int], Optional[Tease]] = lambda tease_id: self.mock_tease_3 if tease_id == 2000 else None
        setattr(self.context.database, "try_get_tease", Mock(side_effect=mock_try_get_tease))

        self.execute_test(['#2000', '#1234'])

        self.normal_writer.writeln.assert_not_called()
        self.mock_outputter.print_list_of_teases.assert_called_once()
        list_passed: List[TeaseMatch] = self.mock_outputter.print_list_of_teases.call_args.args[0]
        self.assertEqual(2, len(list_passed))
        self.assertIsNone(list_passed[0].index_of_match)
        self.assertListEqual([], list_passed[0].list_of_query_matches)
        self.assertIs(self.mock_tease_3, list_passed[0].tease)
        self.assertIs(self.fake_tease_match_1, list_passed[1])

    def test_with_one_authorid_from_matches_calls_outputter(self) -> None:
        self.context.list_of_tease_matches = self.fake_list_of_tease_matches
        mock_get_teases_by_author_id: Callable[[int], List[Tease]] = lambda author_id: [self.mock_tease_0, self.mock_tease_2] if author_id == 4567 else []
        setattr(self.context.database, "get_teases_by_author_id", Mock(side_effect=mock_get_teases_by_author_id))

        self.execute_test(['@4567'])

        self.normal_writer.writeln.assert_not_called()
        self.mock_outputter.print_list_of_teases.assert_called_once_with([self.fake_tease_match_0, self.fake_tease_match_2])

    def test_with_one_existing_authorid_in_database_calls_outputter(self) -> None:
        self.context.list_of_tease_matches = self.fake_list_of_tease_matches
        mock_get_teases_by_author_id: Callable[[int], List[Tease]] = lambda author_id: [self.mock_tease_4] if author_id == 7213 else []
        setattr(self.context.database, "get_teases_by_author_id", Mock(side_effect=mock_get_teases_by_author_id))

        self.execute_test(['@7213'])

        self.normal_writer.writeln.assert_not_called()
        self.mock_outputter.print_list_of_teases.assert_called_once()
        list_passed: List[TeaseMatch] = self.mock_outputter.print_list_of_teases.call_args.args[0]
        self.assertEqual(1, len(list_passed))
        self.assertIsNone(list_passed[0].index_of_match)
        self.assertListEqual([], list_passed[0].list_of_query_matches)
        self.assertIs(self.mock_tease_4, list_passed[0].tease)

    def test_with_one_non_existing_authorid_outputs_error(self) -> None:
        self.context.list_of_tease_matches = self.fake_list_of_tease_matches
        setattr(self.context.database, "get_teases_by_author_id", Mock(return_value=[]))

        self.execute_test(['@8312'])

        self.error_writer.writeln.assert_has_calls([call("Unable to find author id '8312'"), call('No teases available to list')])
        self.mock_outputter.print_list_of_teases.assert_not_called()

    def test_with_one_existing_authorid_in_both_matches_and_database_calls_outputter(self) -> None:
        self.context.list_of_tease_matches = self.fake_list_of_tease_matches
        mock_get_teases_by_author_id: Callable[[int], List[Tease]] = lambda author_id: [self.mock_tease_1, self.mock_tease_3] if author_id == 6431 else []
        setattr(self.context.database, "get_teases_by_author_id", Mock(side_effect=mock_get_teases_by_author_id))

        self.execute_test(['@6431'])

        self.normal_writer.writeln.assert_not_called()
        self.mock_outputter.print_list_of_teases.assert_called_once()
        list_passed: List[TeaseMatch] = self.mock_outputter.print_list_of_teases.call_args.args[0]
        self.assertEqual(2, len(list_passed))
        self.assertIs(self.fake_tease_match_1, list_passed[0])
        self.assertIsNone(list_passed[1].index_of_match)
        self.assertListEqual([], list_passed[1].list_of_query_matches)
        self.assertIs(self.mock_tease_3, list_passed[1].tease)

    def test_with_mixed_refids_calls_outputter(self) -> None:
        self.context.list_of_tease_matches = self.fake_list_of_tease_matches
        mock_try_get_tease: Callable[[int], Optional[Tease]] = lambda tease_id: self.mock_tease_4 if tease_id == 8721 else None
        setattr(self.context.database, "try_get_tease", Mock(side_effect=mock_try_get_tease))
        mock_get_teases_by_author_id: Callable[[int], List[Tease]] = lambda author_id: [self.mock_tease_1, self.mock_tease_3] if author_id == 6431 else []
        setattr(self.context.database, "get_teases_by_author_id", Mock(side_effect=mock_get_teases_by_author_id))

        self.execute_test(['2', '#1234', '0', '@6431', '#8721'])

        self.normal_writer.writeln.assert_not_called()
        self.mock_outputter.print_list_of_teases.assert_called_once()
        list_passed: List[TeaseMatch] = self.mock_outputter.print_list_of_teases.call_args.args[0]
        self.assertEqual(6, len(list_passed))
        self.assertIs(self.fake_tease_match_2, list_passed[0])
        self.assertIs(self.fake_tease_match_1, list_passed[1])
        self.assertIs(self.fake_tease_match_0, list_passed[2])
        self.assertIs(self.fake_tease_match_1, list_passed[3])
        self.assertIsNone(list_passed[4].index_of_match)
        self.assertListEqual([], list_passed[4].list_of_query_matches)
        self.assertIs(self.mock_tease_3, list_passed[4].tease)
        self.assertIsNone(list_passed[5].index_of_match)
        self.assertListEqual([], list_passed[5].list_of_query_matches)
        self.assertIs(self.mock_tease_4, list_passed[5].tease)
