from unittest.mock import Mock
from milodb.command_framework.i_command import ICommand
from milodb.commands.help_command import HelpCommand
from milodb_test.commands.error_messages import ErrorMessage
from milodb_test.commands.test_command_base import CommandTestBase

class HelpCommandTestBase(CommandTestBase):
    def setUp(self) -> None:
        super().setUp()
        self.set_command_class_under_test(HelpCommand, 'help')

class TestHelpCommand(HelpCommandTestBase):
    def test_without_arguments_returns_success(self) -> None:
        self.load_test([])
        self.assert_successful(self.get_list_of_command_names())

    def test_with_known_command_argument_returns_success(self) -> None:
        self.add_command_help_to_factory(type(Mock(ICommand)), 'dummy')
        self.load_test(['dummy'])
        self.assert_successful([])

    def test_with_invalid_argument_returns_failure(self) -> None:
        self.add_command_help_to_factory(type(Mock(ICommand)), 'fake')
        self.add_command_help_to_factory(type(Mock(ICommand)), 'dummy')
        self.load_test(['mango'])
        self.assert_load_error(1, ErrorMessage.INVALID_COMMAND, self.get_list_of_command_names())

    def test_with_redundant_argument_returns_failure(self) -> None:
        self.add_command_help_to_factory(type(Mock(ICommand)), 'fake')
        self.load_test(['fake', 'fake'])
        self.assert_argument_error(2, ErrorMessage.UNEXPECTED, [])
