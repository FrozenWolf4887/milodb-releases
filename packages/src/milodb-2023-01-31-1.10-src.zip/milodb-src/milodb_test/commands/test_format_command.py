from unittest.mock import Mock
from milodb.commands.format_command import FormatCommand
from milodb.output.outputter import Outputter
from milodb_test.commands.error_messages import ErrorMessage
from milodb_test.commands.test_command_base import CommandTestBase

class FormatCommandTestBase(CommandTestBase):
    def setUp(self) -> None:
        super().setUp()
        self.set_command_class_under_test(FormatCommand)

class TestFormatCommand(FormatCommandTestBase):
    def test_without_arguments_returns_success(self) -> None:
        self.load_test([])
        self.assert_successful()

    def test_with_one_argument_returns_success(self) -> None:
        outputter1 = Mock(Outputter)
        outputter1.get_name = Mock(return_value='one')
        outputter2 = Mock(Outputter)
        outputter2.get_name = Mock(return_value='two')
        self.context.current_outputter = outputter1
        self.context.list_of_outputters = [outputter1, outputter2]
        self.load_test(['two'])
        self.assert_successful()

    def test_with_one_invalid_argument_returns_failure(self) -> None:
        outputter1 = Mock(Outputter)
        outputter1.get_name = Mock(return_value='one')
        outputter2 = Mock(Outputter)
        outputter2.get_name = Mock(return_value='two')
        self.context.current_outputter = outputter1
        self.context.list_of_outputters = [outputter1, outputter2]
        self.load_test(['three'])
        self.assert_argument_error(1, ErrorMessage.INVALID, ['one', 'two'])

    def test_with_redundant_argument_returns_failure(self) -> None:
        outputter1 = Mock(Outputter)
        outputter1.get_name = Mock(return_value='one')
        outputter2 = Mock(Outputter)
        outputter2.get_name = Mock(return_value='two')
        self.context.current_outputter = outputter1
        self.context.list_of_outputters = [outputter1, outputter2]
        self.load_test(['two', 'one'])
        self.assert_argument_error(2, ErrorMessage.UNEXPECTED, [])
