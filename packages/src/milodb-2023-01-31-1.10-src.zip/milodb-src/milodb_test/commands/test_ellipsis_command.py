from milodb.commands.ellipsis_command import EllipsisCommand
from milodb_test.commands.error_messages import ErrorMessage
from milodb_test.commands.test_command_base import CommandTestBase

class EllipsisCommandTestBase(CommandTestBase):
    def setUp(self) -> None:
        super().setUp()
        self.set_command_class_under_test(EllipsisCommand)

class TestEllipsisCommand(EllipsisCommandTestBase):
    def test_without_arguments_returns_success(self) -> None:
        self.load_test([])
        self.assert_successful()

    def test_with_off_argument_returns_success(self) -> None:
        self.load_test(['off'])
        self.assert_successful()

    def test_with_on_argument_returns_success(self) -> None:
        self.load_test(['on'])
        self.assert_successful()

    def test_with_invalid_argument_returns_failure(self) -> None:
        self.load_test(['mango'])
        self.assert_argument_error(1, ErrorMessage.INVALID_ENUM, ['on', 'off'])

    def test_with_redundant_argument_returns_failure(self) -> None:
        self.load_test(['on', 'off'])
        self.assert_argument_error(2, ErrorMessage.UNEXPECTED, [])
