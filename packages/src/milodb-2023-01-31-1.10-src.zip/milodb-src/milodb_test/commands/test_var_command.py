from unittest.mock import Mock
from milodb.commands.var_command import VarCommand
from milodb_test.commands.error_messages import ErrorMessage
from milodb_test.commands.test_command_base import CommandTestBase

COMMAND_SET: str = 'set'
COMMAND_GET: str = 'get'
COMMAND_DELETE: str = 'delete'
COMMAND_RENAME: str = 'rename'
COMMAND_COPY: str = 'copy'
COMMAND_EDIT: str = 'edit'

class VarCommandTestBase(CommandTestBase):
    def setUp(self) -> None:
        super().setUp()
        self.set_command_class_under_test(VarCommand)

class TestVarCommand(VarCommandTestBase):
    def test_without_arguments_returns_success(self) -> None:
        self.load_test([])
        self.assert_successful()

    def test_unknown_action_returns_failure(self) -> None:
        self.load_test(['boo'])
        self.assert_argument_error(1, ErrorMessage.INVALID, ['set', 'get', 'delete', 'rename', 'copy', 'edit'])

class TestVarSetCommandLoad(VarCommandTestBase):
    def test_without_arguments_returns_failure(self) -> None:
        self.load_test([COMMAND_SET])
        self.assert_argument_error(None, ErrorMessage.INSUFFICIENT_EXPECTING_VARIABLE, [])

        self.add_variable('honey', 'toffee')
        self.add_variable('badger', 'apple')
        self.load_test([COMMAND_SET])
        self.assert_argument_error(None, ErrorMessage.INSUFFICIENT_EXPECTING_VARIABLE, ['honey', 'badger'])

    def test_without_value_returns_failure(self) -> None:
        self.load_test([COMMAND_SET, 'pear'])
        self.assert_load_error(None, 'Expected some text to set as the variable value', [])

        self.add_variable('honey', 'toffee')
        self.add_variable('badger', 'apple')
        self.load_test([COMMAND_SET, 'pear'])
        self.assert_load_error(None, 'Expected some text to set as the variable value', [])

    def test_with_bad_variable_name_returns_failure(self) -> None:
        self.load_test([COMMAND_SET, '$pear'])
        self.assert_argument_error(2, r"Variable name '$pear' does not match pattern '[\w\-\+]+'", [])

        self.load_test([COMMAND_SET, 'p%ear'])
        self.assert_argument_error(2, r"Variable name 'p%ear' does not match pattern '[\w\-\+]+'", [])

        self.add_variable('honey', 'toffee')
        self.add_variable('badger', 'apple')
        self.load_test([COMMAND_SET, 'pear#'])
        self.assert_argument_error(2, r"Variable name 'pear#' does not match pattern '[\w\-\+]+'", ['honey', 'badger'])

class TestVarSetCommandExecute(VarCommandTestBase):
    def test_new_variable_with_value_sets_successfully(self) -> None:
        self.execute_test([COMMAND_SET, 'pear'], 'something')
        self.mock_variables.set.assert_called_once_with('pear', 'something')
        self.mock_variables.try_save.assert_called_once()

    def test_existing_variable_with_value_sets_successfully(self) -> None:
        self.add_variable('honey', 'toffee')
        self.add_variable('badger', 'apple')
        self.execute_test([COMMAND_SET, 'honey'], 'lemon')
        self.mock_variables.set.assert_called_once_with('honey', 'lemon')
        self.mock_variables.try_save.assert_called_once()

    def test_variable_with_complex_name_sets_successfully(self) -> None:
        self.execute_test([COMMAND_SET, '012The-Qu34ick+Br56own-F78ox+Ju9mps-Over+The-L0azy+Dog'], 'something')
        self.mock_variables.set.assert_called_once_with('012The-Qu34ick+Br56own-F78ox+Ju9mps-Over+The-L0azy+Dog', 'something')
        self.mock_variables.try_save.assert_called_once()

    def test_variable_with_remaining_text_sets_verbatim_but_stripped(self) -> None:
        self.execute_test([COMMAND_SET, 'pear'], '  this   is " some text  ;;<> that can\'t  be tokenised  ')
        self.mock_variables.set.assert_called_once_with('pear', 'this   is " some text  ;;<> that can\'t  be tokenised')
        self.mock_variables.try_save.assert_called_once()

class TestVarGetCommandLoad(VarCommandTestBase):
    def test_without_arguments_returns_failure(self) -> None:
        self.load_test([COMMAND_GET])
        self.assert_argument_error(None, ErrorMessage.INSUFFICIENT_EXPECTING_VARIABLE, [])

        self.add_variable('honey', 'toffee')
        self.add_variable('badger', 'apple')
        self.load_test([COMMAND_GET])
        self.assert_argument_error(None, ErrorMessage.INSUFFICIENT_EXPECTING_VARIABLE, ['honey', 'badger'])

    def test_with_variable_name_returns_success(self) -> None:
        self.load_test([COMMAND_GET, 'pear'])
        self.assert_successful()

    def test_with_bad_variable_name_returns_failure(self) -> None:
        self.load_test([COMMAND_GET, '$pear'])
        self.assert_argument_error(2, r"Variable name '$pear' does not match pattern '[\w\-\+]+'", [])

        self.load_test([COMMAND_SET, 'p%ear'])
        self.assert_argument_error(2, r"Variable name 'p%ear' does not match pattern '[\w\-\+]+'", [])

        self.add_variable('honey', 'toffee')
        self.add_variable('badger', 'apple')
        self.load_test([COMMAND_GET, 'pear#'])
        self.assert_argument_error(2, r"Variable name 'pear#' does not match pattern '[\w\-\+]+'", ['honey', 'badger'])

    def test_excessive_parameters_returns_failure(self) -> None:
        self.load_test([COMMAND_GET, 'pear', 'bar'])
        self.assert_argument_error(3, ErrorMessage.UNEXPECTED, [])

class TestVarGetCommandExecute(VarCommandTestBase):
    def test_existing_variable_gets_successfully(self) -> None:
        self.add_variable('honey', 'toffee')
        self.add_variable('badger', 'apple')
        self.execute_test([COMMAND_GET, 'badger'])
        self.normal_writer.writeln.assert_called_once_with('  badger : apple')
        self.mock_variables.try_save.assert_not_called()

    def test_unknown_variable_prints_failure(self) -> None:
        self.add_variable('honey', 'toffee')
        self.add_variable('badger', 'apple')
        self.execute_test([COMMAND_GET, 'apple'])
        self.error_writer.writeln.assert_called_once_with("Unknown variable 'apple'")
        self.mock_variables.try_save.assert_not_called()

class TestVarDeleteCommandLoad(VarCommandTestBase):
    def test_without_arguments_returns_failure(self) -> None:
        self.load_test([COMMAND_DELETE])
        self.assert_argument_error(None, ErrorMessage.INSUFFICIENT_EXPECTING_VARIABLE, [])

        self.add_variable('honey', 'toffee')
        self.add_variable('badger', 'apple')
        self.load_test([COMMAND_DELETE])
        self.assert_argument_error(None, ErrorMessage.INSUFFICIENT_EXPECTING_VARIABLE, ['honey', 'badger'])

    def test_with_variable_name_returns_success(self) -> None:
        self.load_test([COMMAND_DELETE, 'pear'])
        self.assert_successful()

    def test_with_bad_variable_name_returns_failure(self) -> None:
        self.load_test([COMMAND_DELETE, '$pear'])
        self.assert_argument_error(2, r"Variable name '$pear' does not match pattern '[\w\-\+]+'", [])

        self.load_test([COMMAND_DELETE, 'p%ear'])
        self.assert_argument_error(2, r"Variable name 'p%ear' does not match pattern '[\w\-\+]+'", [])

        self.add_variable('honey', 'toffee')
        self.add_variable('badger', 'apple')
        self.load_test([COMMAND_DELETE, 'pear#'])
        self.assert_argument_error(2, r"Variable name 'pear#' does not match pattern '[\w\-\+]+'", ['honey', 'badger'])

    def test_excessive_parameters_returns_failure(self) -> None:
        self.load_test([COMMAND_DELETE, 'pear', 'bar'])
        self.assert_argument_error(3, ErrorMessage.UNEXPECTED, [])

class TestVarDeleteCommandExecute(VarCommandTestBase):
    def test_existing_variable_deletes_successfully(self) -> None:
        self.add_variable('honey', 'toffee')
        self.add_variable('badger', 'apple')
        self.mock_variables.try_delete = Mock(return_value=True)
        self.execute_test([COMMAND_DELETE, 'badger'])
        self.mock_variables.try_delete.assert_called_once_with("badger")
        self.mock_variables.try_save.assert_called_once()

    def test_unknown_variable_prints_failure(self) -> None:
        self.add_variable('honey', 'toffee')
        self.add_variable('badger', 'apple')
        self.mock_variables.try_delete = Mock(return_value=False)
        self.execute_test([COMMAND_DELETE, 'apple'])
        self.error_writer.writeln.assert_called_once_with("Unknown variable 'apple'")
        self.mock_variables.try_save.assert_not_called()

class TestVarRenameCommandLoad(VarCommandTestBase):
    def test_without_arguments_returns_failure(self) -> None:
        self.load_test([COMMAND_RENAME])
        self.assert_argument_error(None, ErrorMessage.INSUFFICIENT_EXPECTING_VARIABLE, [])

        self.add_variable('honey', 'toffee')
        self.add_variable('badger', 'apple')
        self.load_test([COMMAND_RENAME])
        self.assert_argument_error(None, ErrorMessage.INSUFFICIENT_EXPECTING_VARIABLE, ['honey', 'badger'])

    def test_with_single_variable_name_returns_failure(self) -> None:
        self.load_test([COMMAND_RENAME, 'pear'])
        self.assert_argument_error(None, ErrorMessage.INSUFFICIENT_EXPECTING_VARIABLE, [])

        self.add_variable('honey', 'toffee')
        self.add_variable('badger', 'apple')
        self.load_test([COMMAND_RENAME, 'mango'])
        self.assert_argument_error(None, ErrorMessage.INSUFFICIENT_EXPECTING_VARIABLE, [])

    def test_with_two_variable_names_returns_success(self) -> None:
        self.load_test([COMMAND_RENAME, 'pear', 'mango'])
        self.assert_successful()

    def test_with_bad_variable_name_returns_failure(self) -> None:
        self.load_test([COMMAND_RENAME, '$pear'])
        self.assert_argument_error(2, r"Variable name '$pear' does not match pattern '[\w\-\+]+'", [])

        self.load_test([COMMAND_RENAME, 'mango', 'p%ear'])
        self.assert_argument_error(3, r"Variable name 'p%ear' does not match pattern '[\w\-\+]+'", [])

        self.add_variable('honey', 'toffee')
        self.add_variable('badger', 'apple')
        self.load_test([COMMAND_RENAME, 'pear#', 'mango'])
        self.assert_argument_error(2, r"Variable name 'pear#' does not match pattern '[\w\-\+]+'", ['honey', 'badger'])

        self.load_test([COMMAND_RENAME, 'pear', 'mango#'])
        self.assert_argument_error(3, r"Variable name 'mango#' does not match pattern '[\w\-\+]+'", [])

    def test_excessive_parameters_returns_failure(self) -> None:
        self.load_test([COMMAND_RENAME, 'pear', 'bar', 'foo'])
        self.assert_argument_error(4, ErrorMessage.UNEXPECTED, [])

class TestVarRenameCommandExecute(VarCommandTestBase):
    def test_existing_variable_renames_to_new_name_successfully(self) -> None:
        self.add_variable('honey', 'toffee')
        self.add_variable('badger', 'apple')
        self.mock_variables.try_delete = Mock(return_value=True)
        self.execute_test([COMMAND_RENAME, 'badger', 'tree'])
        self.mock_variables.set.assert_called_once_with('tree', 'apple')
        self.mock_variables.try_delete.assert_called_once_with('badger')
        self.mock_variables.try_save.assert_called_once()

    def test_unknown_variable_prints_failure(self) -> None:
        self.add_variable('honey', 'toffee')
        self.add_variable('badger', 'apple')
        self.mock_variables.try_delete = Mock(return_value=False)
        self.execute_test([COMMAND_RENAME, 'apple', 'tree'])
        self.error_writer.writeln.assert_called_once_with("Unknown variable 'apple'")
        self.mock_variables.try_save.assert_not_called()

    def test_existing_variable_rename_fails_when_new_name_exists(self) -> None:
        self.add_variable('honey', 'toffee')
        self.add_variable('badger', 'apple')
        self.mock_variables.try_delete = Mock(return_value=False)
        self.execute_test([COMMAND_RENAME, 'honey', 'badger'])
        self.error_writer.writeln.assert_called_once_with("Cannot rename variable 'honey' to 'badger' because 'badger' already exists")
        self.mock_variables.try_save.assert_not_called()

    def test_existing_variable_rename_fails_when_new_name_is_the_same(self) -> None:
        self.add_variable('honey', 'toffee')
        self.add_variable('badger', 'apple')
        self.mock_variables.try_delete = Mock(return_value=False)
        self.execute_test([COMMAND_RENAME, 'honey', 'honey'])
        self.error_writer.writeln.assert_called_once_with("Variable 'honey' cannot be renamed to itself")
        self.mock_variables.try_save.assert_not_called()

class TestVarCopyCommandLoad(VarCommandTestBase):
    def test_without_arguments_returns_failure(self) -> None:
        self.load_test([COMMAND_COPY])
        self.assert_argument_error(None, ErrorMessage.INSUFFICIENT_EXPECTING_VARIABLE, [])

        self.add_variable('honey', 'toffee')
        self.add_variable('badger', 'apple')
        self.load_test([COMMAND_COPY])
        self.assert_argument_error(None, ErrorMessage.INSUFFICIENT_EXPECTING_VARIABLE, ['honey', 'badger'])

    def test_with_single_variable_name_returns_failure(self) -> None:
        self.load_test([COMMAND_COPY, 'pear'])
        self.assert_argument_error(None, ErrorMessage.INSUFFICIENT_EXPECTING_VARIABLE, [])

        self.add_variable('honey', 'toffee')
        self.add_variable('badger', 'apple')
        self.load_test([COMMAND_COPY, 'mango'])
        self.assert_argument_error(None, ErrorMessage.INSUFFICIENT_EXPECTING_VARIABLE, [])

    def test_with_two_variable_names_returns_success(self) -> None:
        self.load_test([COMMAND_COPY, 'pear', 'mango'])
        self.assert_successful()

    def test_with_bad_variable_name_returns_failure(self) -> None:
        self.load_test([COMMAND_COPY, '$pear'])
        self.assert_argument_error(2, r"Variable name '$pear' does not match pattern '[\w\-\+]+'", [])

        self.load_test([COMMAND_COPY, 'mango', 'p%ear'])
        self.assert_argument_error(3, r"Variable name 'p%ear' does not match pattern '[\w\-\+]+'", [])

        self.add_variable('honey', 'toffee')
        self.add_variable('badger', 'apple')
        self.load_test([COMMAND_COPY, 'pear#', 'mango'])
        self.assert_argument_error(2, r"Variable name 'pear#' does not match pattern '[\w\-\+]+'", ['honey', 'badger'])

        self.load_test([COMMAND_COPY, 'pear', 'mango#'])
        self.assert_argument_error(3, r"Variable name 'mango#' does not match pattern '[\w\-\+]+'", [])

    def test_excessive_parameters_returns_failure(self) -> None:
        self.load_test([COMMAND_COPY, 'pear', 'bar', 'foo'])
        self.assert_argument_error(4, ErrorMessage.UNEXPECTED, [])

class TestVarCopyCommandExecute(VarCommandTestBase):
    def test_existing_variable_copies_to_new_name_successfully(self) -> None:
        self.add_variable('honey', 'toffee')
        self.add_variable('badger', 'apple')
        self.mock_variables.try_delete = Mock(return_value=True)
        self.execute_test([COMMAND_COPY, 'badger', 'tree'])
        self.mock_variables.set.assert_called_once_with('tree', 'apple')
        self.mock_variables.try_save.assert_called_once()

    def test_unknown_variable_prints_failure(self) -> None:
        self.add_variable('honey', 'toffee')
        self.add_variable('badger', 'apple')
        self.mock_variables.try_delete = Mock(return_value=False)
        self.execute_test([COMMAND_COPY, 'apple', 'tree'])
        self.error_writer.writeln.assert_called_once_with("Unknown variable 'apple'")
        self.mock_variables.try_save.assert_not_called()

    def test_existing_variable_rename_fails_when_new_name_exists(self) -> None:
        self.add_variable('honey', 'toffee')
        self.add_variable('badger', 'apple')
        self.mock_variables.try_delete = Mock(return_value=False)
        self.execute_test([COMMAND_COPY, 'honey', 'badger'])
        self.error_writer.writeln.assert_called_once_with("Cannot copy variable 'honey' to 'badger' because 'badger' already exists")
        self.mock_variables.try_save.assert_not_called()

    def test_existing_variable_rename_fails_when_new_name_is_the_same(self) -> None:
        self.add_variable('honey', 'toffee')
        self.add_variable('badger', 'apple')
        self.mock_variables.try_delete = Mock(return_value=False)
        self.execute_test([COMMAND_COPY, 'honey', 'honey'])
        self.error_writer.writeln.assert_called_once_with("Variable 'honey' cannot be copied to itself")
        self.mock_variables.try_save.assert_not_called()

class TestVarEditCommandLoad(VarCommandTestBase):
    def test_without_arguments_returns_failure(self) -> None:
        self.load_test([COMMAND_EDIT])
        self.assert_argument_error(None, ErrorMessage.INSUFFICIENT_EXPECTING_VARIABLE, [])

        self.add_variable('honey', 'toffee')
        self.add_variable('badger', 'apple')
        self.load_test([COMMAND_EDIT])
        self.assert_argument_error(None, ErrorMessage.INSUFFICIENT_EXPECTING_VARIABLE, ['honey', 'badger'])

    def test_with_variable_name_returns_success(self) -> None:
        self.load_test([COMMAND_EDIT, 'pear'])
        self.assert_successful()

    def test_with_bad_variable_name_returns_failure(self) -> None:
        self.load_test([COMMAND_EDIT, '$pear'])
        self.assert_argument_error(2, r"Variable name '$pear' does not match pattern '[\w\-\+]+'", [])

        self.load_test([COMMAND_EDIT, 'p%ear'])
        self.assert_argument_error(2, r"Variable name 'p%ear' does not match pattern '[\w\-\+]+'", [])

        self.add_variable('honey', 'toffee')
        self.add_variable('badger', 'apple')
        self.load_test([COMMAND_EDIT, 'pear#'])
        self.assert_argument_error(2, r"Variable name 'pear#' does not match pattern '[\w\-\+]+'", ['honey', 'badger'])

    def test_excessive_parameters_returns_failure(self) -> None:
        self.load_test([COMMAND_EDIT, 'pear', 'bar'])
        self.assert_argument_error(3, ErrorMessage.UNEXPECTED, [])

class TestVarEditCommandExecute(VarCommandTestBase):
    def test_existing_variable_edits_successfully(self) -> None:
        self.add_variable('honey', 'toffee')
        self.add_variable('badger', 'apple')
        self.execute_test([COMMAND_EDIT, 'badger'])
        self.assertEqual(self.context.session_config.default_input_text.get(), 'var set badger apple')

    def test_unknown_variable_prints_failure(self) -> None:
        self.add_variable('honey', 'toffee')
        self.add_variable('badger', 'apple')
        self.execute_test([COMMAND_EDIT, 'apple'])
        self.error_writer.writeln.assert_called_once_with("Unknown variable 'apple'")
