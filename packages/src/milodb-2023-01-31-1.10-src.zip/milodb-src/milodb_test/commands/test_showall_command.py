from milodb.commands.showall_command import ShowAllCommand
from milodb_test.commands.error_messages import ErrorMessage
from milodb_test.commands.test_command_base import CommandTestBase

class ShowAllCommandTestBase(CommandTestBase):
    def setUp(self) -> None:
        super().setUp()
        self.set_command_class_under_test(ShowAllCommand)

class TestShowAllCommand(ShowAllCommandTestBase):
    def test_without_arguments_returns_success(self) -> None:
        self.load_test([])
        self.assert_successful()

    def test_with_one_index_returns_success(self) -> None:
        self.load_test(['1234'])
        self.assert_successful()

    def test_with_three_indices_returns_success(self) -> None:
        self.load_test(['1234', '5678', '9012'])
        self.assert_successful()

    def test_with_signed_index_returns_failure(self) -> None:
        self.load_test(['1234', '-5678', '9012'])
        self.assert_argument_error(2, ErrorMessage.INVALID_REFID, [])

    def test_with_one_teaseid_returns_success(self) -> None:
        self.load_test(['#1234'])
        self.assert_successful()

    def test_with_three_teaseids_returns_success(self) -> None:
        self.load_test(['#1234', '#5678', '#9012'])
        self.assert_successful()

    def test_with_signed_teaseid_returns_failure(self) -> None:
        self.load_test(['#1234', '#-5678', '#9012'])
        self.assert_argument_error(2, ErrorMessage.INVALID_TEASEID, [])

    def test_with_one_authorid_returns_success(self) -> None:
        self.load_test(['@1234'])
        self.assert_successful()

    def test_with_three_authorids_returns_success(self) -> None:
        self.load_test(['@1234', '@5678', '@9012'])
        self.assert_successful()

    def test_with_signed_authorid_returns_failure(self) -> None:
        self.load_test(['@1234', '@-5678', '@9012'])
        self.assert_argument_error(2, ErrorMessage.INVALID_AUTHORID, [])

    def test_with_mixed_refids_returns_success(self) -> None:
        self.load_test(['@1234', '5678', '#9012'])
        self.assert_successful()

    def test_with_non_refid_returns_failure(self) -> None:
        self.load_test(['mango', '5678', '9012'])
        self.assert_argument_error(1, ErrorMessage.INVALID_REFID, [])
