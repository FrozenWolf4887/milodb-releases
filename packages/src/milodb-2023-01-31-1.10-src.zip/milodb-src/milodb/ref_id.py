from dataclasses import dataclass
from typing import Union

@dataclass
class MatchIndex:
    match_index: int

@dataclass
class TeaseId:
    tease_id: int

@dataclass
class AuthorId:
    author_id: int

RefId = Union[MatchIndex, TeaseId, AuthorId]
