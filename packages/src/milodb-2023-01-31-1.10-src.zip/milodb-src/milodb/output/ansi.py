from typing import Dict, List, Optional
import colorama # type: ignore
from milodb import query
from milodb.config.ansi_config import AnsiConfig
from milodb.config.session_config import SessionConfig
from milodb.output.outputter import Outputter
from milodb.output.support import EllipsifyText, EllipsisLocation, IterateThroughMatches, get_list_of_indexed_metadata_matches, get_list_of_metadata_matches, get_url_of_author, get_url_of_tease, iterate_through_lines
from milodb.tease import Tease, TeaseProperty, TeaseStrListProperty, TotmStatus

colorama.init(strip=False)

_MAP_OF_TOTM_STATUS_TO_TEXT: Dict[TotmStatus, str] = {
    TotmStatus.NONE: ' ',
    TotmStatus.NOMINEE: 'n',
    TotmStatus.WINNER: 'w'
}

class AnsiOutputter(Outputter):
    def __init__(self, ansi_config: AnsiConfig, session_config: SessionConfig) -> None:
        self._ansi_config: AnsiConfig = ansi_config
        self._session_config: SessionConfig = session_config

    def get_name(self) -> str:
        return 'ansi'

    def print_list_of_teases(self, list_of_tease_matches: List[query.TeaseMatch]) -> None:
        tease_match: query.TeaseMatch
        for tease_match in list_of_tease_matches:
            self._print_oneline_of_tease(tease_match)

    def print_summary_of_tease(self, tease_match: query.TeaseMatch) -> None:
        match_index: str = str(tease_match.index_of_match) if tease_match.index_of_match else 'none'
        tease_id: int = tease_match.tease.tease_id()
        author_id: int = tease_match.tease.author_id()
        formatted_tease_id: str = self._highlight_metadata(tease_match, Tease.tease_id, 6, '#')
        formatted_tease_title: str = self._highlight_metadata(tease_match, Tease.title)
        formatted_author_id: str = self._highlight_metadata(tease_match, Tease.author_id, 6, '@') if tease_match.tease.has_author() else 'unknown'
        formatted_author_name: str = f"'{self._highlight_metadata(tease_match, Tease.author_name)}'" if tease_match.tease.has_author() else 'unknown'
        formatted_tease_date: str = self._highlight_metadata(tease_match, Tease.date)
        formatted_tease_type: str = self._highlight_metadata(tease_match, Tease.type, 7)
        formatted_tease_rating: str = self._highlight_metadata(tease_match, Tease.rating_value, 7)
        formatted_tags: str = ', '.join(self._highlight_metadata_string_list(tease_match, Tease.list_of_tags, False, False))
        formatted_summary: str = self._highlight_metadata(tease_match, Tease.summary)
        url_of_tease: str = get_url_of_tease(tease_id)
        url_of_author: str = get_url_of_author(author_id) if tease_match.tease.has_author() else 'link unavailable (author unknown)'
        self._session_config.normal_writer.writeln(f"\x1b[{self._ansi_config.index_heading_colour}mIndex   \x1b[0m{match_index:>7}   \x1b[{self._ansi_config.hits_heading_colour}mHits   \x1b[0m{tease_match.get_match_count()}")
        self._session_config.normal_writer.writeln(f"\x1b[{self._ansi_config.tease_heading_colour}mTease   \x1b[0m{formatted_tease_id}   \x1b[{self._ansi_config.tease_heading_colour}mTitle  \x1b[0m'{formatted_tease_title}'")
        self._session_config.normal_writer.writeln(f"\x1b[{self._ansi_config.author_heading_colour}mAuthor  \x1b[0m{formatted_author_id}   \x1b[{self._ansi_config.author_heading_colour}mName   \x1b[0m{formatted_author_name}")
        self._session_config.normal_writer.writeln(f"\x1b[{self._ansi_config.type_heading_colour}mType    \x1b[0m{formatted_tease_type}   \x1b[{self._ansi_config.date_heading_colour}mDate   \x1b[0m{formatted_tease_date}")
        self._session_config.normal_writer.writeln(f"\x1b[{self._ansi_config.rating_heading_colour}mRating  \x1b[0m{formatted_tease_rating}   \x1b[{self._ansi_config.tags_heading_colour}mTags   \x1b[0m{formatted_tags}")
        self._session_config.normal_writer.writeln(f"\x1b[{self._ansi_config.tease_heading_colour}mTease   \x1b[0m{url_of_tease}")
        if tease_match.tease.has_author():
            self._session_config.normal_writer.writeln(f"\x1b[{self._ansi_config.author_heading_colour}mAuthor  \x1b[0m{url_of_author}")
        self._session_config.normal_writer.writeln(f"\x1b[{self._ansi_config.summary_heading_colour}mSummary\x1b[0m")
        self._session_config.normal_writer.writeln(formatted_summary or 'None')

    def print_all_text_of_list_of_teases(self, list_of_tease_matches: List[query.TeaseMatch]) -> None:
        index: int
        tease_match: query.TeaseMatch
        for index, tease_match in enumerate(list_of_tease_matches):
            if index > 0:
                self._session_config.normal_writer.writeln()
            self.print_summary_of_tease(tease_match)
            self._print_all_text_of_tease(tease_match)

    def print_matching_text_of_list_of_teases(self, list_of_tease_matches: List[query.TeaseMatch]) -> None:
        index: int
        tease_match: query.TeaseMatch
        for index, tease_match in enumerate(list_of_tease_matches):
            if index > 0:
                self._session_config.normal_writer.writeln()
            self.print_summary_of_tease(tease_match)
            self._print_matching_text_of_tease(tease_match)

    def _print_all_text_of_tease(self, tease_match: query.TeaseMatch) -> None:
        list_of_formatted_text: List[str] = self._highlight_metadata_string_list(tease_match, Tease.list_of_text_blocks, False, False)
        if list_of_formatted_text:
            self._session_config.normal_writer.writeln(f'\x1b[{self._ansi_config.matching_text_heading_colour}mText\x1b[0m')
            self._session_config.normal_writer.writeln(40 * '-')
            self._session_config.normal_writer.writeln(('\n' + 40 * '-' + '\n').join(list_of_formatted_text))
            self._session_config.normal_writer.writeln(40 * '-')

    def _print_matching_text_of_tease(self, tease_match: query.TeaseMatch) -> None:
        list_of_formatted_text: List[str] = self._highlight_metadata_string_list(tease_match, Tease.list_of_text_blocks, True, self._session_config.is_ellipsis_enabled)
        if list_of_formatted_text:
            self._session_config.normal_writer.writeln(f'\x1b[{self._ansi_config.matching_text_heading_colour}mMatching text\x1b[0m')
            self._session_config.normal_writer.writeln(40 * '-')
            self._session_config.normal_writer.writeln(('\n' + 40 * '-' + '\n').join(list_of_formatted_text))
            self._session_config.normal_writer.writeln(40 * '-')

    def _print_oneline_of_tease(self, tease_match: query.TeaseMatch) -> None:
        match_index: str = str(tease_match.index_of_match) if tease_match.index_of_match else '-'
        hits: str = '*' + str(tease_match.get_match_count())
        formatted_tease_id: str = self._highlight_metadata(tease_match, Tease.tease_id, 5, '#')
        formatted_tease_type: str = self._highlight_metadata(tease_match, Tease.type)
        formatted_tease_rating: str = self._highlight_metadata(tease_match, Tease.rating_value, 3)
        formatted_tease_date: str = self._highlight_metadata(tease_match, Tease.date)
        formatted_tease_title: str = self._highlight_metadata(tease_match, Tease.title)
        formatted_author_text: str = 'unknown author'
        if tease_match.tease.has_author():
            formatted_author_name: str = self._highlight_metadata(tease_match, Tease.author_name)
            formatted_author_id: str = self._highlight_metadata(tease_match, Tease.author_id)
            formatted_author_text = f"{formatted_author_name}, @{formatted_author_id}"
        totm_text: str = _MAP_OF_TOTM_STATUS_TO_TEXT.get(tease_match.tease.totm_status(), ' ')
        self._session_config.normal_writer.writeln((
            f'{match_index:>3}:'
            f' {hits:>4}'
            f'  {formatted_tease_id}'
            f'  {formatted_tease_type}'
            f'  {formatted_tease_rating}'
            f'  {totm_text}'
            f'  {formatted_tease_date}'
            f'  {formatted_tease_title}'
            f' : [{formatted_author_text}]'))

    def _highlight_metadata(self, tease_match: query.TeaseMatch, tease_property: TeaseProperty, width: int = 0, prefix_text: str = '') -> str:
        field_value: str = tease_match.tease.get_text_of_property(tease_property)
        formatted_value: str = self._highlight_text(field_value, get_list_of_metadata_matches(tease_property, tease_match.list_of_query_matches), False)

        if width != 0:
            if prefix_text:
                formatted_value = prefix_text + formatted_value

            pad_char_count = abs(width) - len(field_value)
            if pad_char_count > 0:
                if width < 0:
                    formatted_value = formatted_value + (pad_char_count * ' ')
                else:
                    formatted_value = (pad_char_count * ' ') + formatted_value

        return formatted_value

    def _highlight_metadata_string_list(self, tease_match: query.TeaseMatch, tease_property: TeaseStrListProperty, include_matching_only: bool, use_ellipsis: bool) -> List[str]:
        list_of_formatted_text: List[str] = []

        index_of_block: int
        text_block: str
        for index_of_block, text_block in enumerate(tease_property(tease_match.tease)):
            list_of_match_details: List[query.MatchDetails] = get_list_of_indexed_metadata_matches(tease_property, index_of_block, tease_match.list_of_query_matches)
            formatted_text: Optional[str] = None
            if list_of_match_details:
                formatted_text = self._highlight_text(text_block, list_of_match_details, use_ellipsis and include_matching_only)
            elif not include_matching_only:
                formatted_text = _escape_text(text_block)

            if formatted_text is not None:
                list_of_formatted_text.append(formatted_text)

        return list_of_formatted_text

    def _highlight_text(self, text: str, list_of_matches: List[query.MatchDetails], is_ellipsis_enabled: bool) -> str:
        formatted_text = ''

        def on_normal_text(text: str, is_first_item: bool, is_last_item: bool) -> None:
            nonlocal formatted_text
            if is_ellipsis_enabled:
                formatted_text += self._ellipsify_and_escape_text_item(text, is_first_item, is_last_item)
            else:
                formatted_text += _escape_text(text)

        def on_matched_text(text: str, _is_first_item: bool, _is_last_item: bool) -> None:
            nonlocal formatted_text
            if self._session_config.is_highlighting_enabled:
                iterate_through_lines(text, on_highlight_text, on_end_of_line_text)
            else:
                formatted_text += _escape_text(text)

        def on_highlight_text(text: str) -> None:
            nonlocal formatted_text
            formatted_text += f'\x1b[{self._ansi_config.matching_text_colour}m'
            formatted_text += _escape_text(text)
            formatted_text += '\x1b[0m'

        def on_end_of_line_text(text: str) -> None:
            nonlocal formatted_text
            formatted_text += text

        IterateThroughMatches(text, list_of_matches, on_normal_text, on_matched_text)

        return formatted_text

    def _ellipsify_and_escape_text_item(self, text: str, is_first_item: bool, is_last_item: bool) -> str:
        formatted_text: str = ''

        def on_text(text: str) -> None:
            nonlocal formatted_text
            formatted_text += _escape_text(text)

        def on_ellipsis() -> None:
            nonlocal formatted_text
            formatted_text += f'\x1b[{self._ansi_config.ellipsis_colour}m\u2026\x1b[0m'

        EllipsifyText(text, self._session_config.ellipsis_max_width, EllipsisLocation.from_position(is_first_item, is_last_item), on_text, on_ellipsis)

        return formatted_text

def _escape_text(text: str) -> str:
    return text.replace('\x1b', '')
