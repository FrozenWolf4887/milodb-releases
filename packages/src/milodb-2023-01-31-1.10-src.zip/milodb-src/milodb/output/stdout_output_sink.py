from milodb.output.output_sink import OutputSink

class StdoutOutputSink(OutputSink):
    def write(self, text: str) -> None:
        print(text, end='')
