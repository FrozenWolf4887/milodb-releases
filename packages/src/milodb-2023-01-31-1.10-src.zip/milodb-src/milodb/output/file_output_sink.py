from typing import IO
from milodb.output.output_sink import OutputSink

class FileOutputSink(OutputSink):
    def __init__(self, file: IO[str]) -> None:
        self._file: IO[str] = file

    def write(self, text: str) -> None:
        self._file.write(text)
