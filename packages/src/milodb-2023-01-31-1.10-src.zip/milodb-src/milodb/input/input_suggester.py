from typing import List, Optional
from prompt_toolkit.completion import Completion # type: ignore
from milodb.command_framework.argument_stream import ArgumentStream
from milodb.command_framework.i_command_loader import EmptyInputResult, ICommandLoader, LoadResult, SuccessfulLoadResult
from milodb.tokeniser import ExpandedToken, ExpandingTokenStream
from milodb.user_variables import UserVariables

class InputSuggester:
    def __init__(self, command_loader: ICommandLoader, user_variables: UserVariables) -> None:
        self._command_loader = command_loader
        self._user_variables = user_variables

    def get_possible_completions(self, text: str, cursor_index: int) -> List[Completion]:
        list_of_completions: List[Completion] = []

        text_of_tokens_before_cursor: str = text[:cursor_index]
        token_stream: ExpandingTokenStream = ExpandingTokenStream(text_of_tokens_before_cursor, self._user_variables, cursor_index)
        argument_stream: ArgumentStream = ArgumentStream(token_stream)
        load_result: LoadResult = self._command_loader.try_load(argument_stream)
        stopped_on_token: Optional[ExpandedToken] = token_stream.get_stopped_on_token()

        if isinstance(load_result, EmptyInputResult):
            list_of_completions = self._create_completion_list(load_result.list_of_command_names, cursor_index, stopped_on_token)
        elif isinstance(load_result, SuccessfulLoadResult):
            list_of_completions = self._create_completion_list(load_result.list_of_possible_next_text, cursor_index, stopped_on_token)
        elif not load_result.fault_token:
            list_of_completions = self._create_completion_list(load_result.list_of_expected_text, cursor_index, stopped_on_token)

        if stopped_on_token and stopped_on_token.text.startswith('$') and token_stream.is_expansion_enabled():
            list_of_variable_names: List[str] = [f'${name}' for name in self._user_variables.get_list_of_names()]
            list_of_completions.extend(self._create_completion_list(list_of_variable_names, cursor_index, stopped_on_token))

        return list_of_completions

    def _create_completion_list(self, list_of_text: List[str], cursor_index: int, stopped_on_token: Optional[ExpandedToken] = None) -> List[Completion]:
        if stopped_on_token and stopped_on_token.variable_depth == 0:
            return [Completion(text, stopped_on_token.original_token.outer_indices.start - cursor_index) for text in list_of_text if text.startswith(stopped_on_token.text)]
        return [Completion(text, 0) for text in list_of_text]
