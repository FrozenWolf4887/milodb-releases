from typing import List, Optional
from milodb.command_framework.command_loader import CommandLoader
from milodb.command_framework.i_command_factory import ICommandFactory
from milodb.command_framework.quit_flag import QuitFlag
from milodb.input.process import process_user_input
from milodb.user_variables import UserVariables

def run_autoexec(filepath: str, command_factory: ICommandFactory, user_variables: UserVariables, quit_flag: QuitFlag) -> None:
    autoexec_lines: Optional[List[str]] = None

    try:
        with open(filepath, 'rt', encoding='utf-8') as file:
            autoexec_lines = file.readlines()
    except IOError:
        pass

    if autoexec_lines:
        command_loader: CommandLoader = CommandLoader(command_factory)
        print(f"Running commands from '{filepath}':")
        line_index: int = 0
        while (not quit_flag) and (line_index < len(autoexec_lines)):
            line: str = autoexec_lines[line_index].strip()
            if line:
                print(f'> {line}')
                process_user_input(line, command_loader, user_variables)
            line_index += 1
