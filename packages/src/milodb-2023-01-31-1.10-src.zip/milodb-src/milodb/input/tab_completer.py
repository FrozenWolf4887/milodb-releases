from typing import Iterable, List
from prompt_toolkit.completion import CompleteEvent, Completer, Completion # type: ignore
from prompt_toolkit.document import Document # type: ignore
from milodb.input.input_suggester import InputSuggester

class TabCompleter(Completer):
    def __init__(self, input_suggester: InputSuggester) -> None:
        self._input_suggester: InputSuggester = input_suggester

    def get_completions(self, document: Document, complete_event: CompleteEvent) -> Iterable[Completion]:
        list_of_completions: List[Completion] = self._input_suggester.get_possible_completions(document.text, document.cursor_position_col)
        completion: Completion
        for completion in list_of_completions:
            completion.text += ' '
        return list_of_completions
