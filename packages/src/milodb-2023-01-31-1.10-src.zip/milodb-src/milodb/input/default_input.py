class DefaultInputText:
    def __init__(self) -> None:
        self._text: str = ''

    def set(self, value: str) -> None:
        self._text = value

    def clear(self) -> None:
        self._text = ''

    def get(self) -> str:
        return self._text
