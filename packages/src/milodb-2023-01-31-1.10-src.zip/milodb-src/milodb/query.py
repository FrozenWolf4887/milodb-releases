import datetime
import re
from abc import ABC, abstractmethod
from typing import Callable, Dict, List, Match, Optional, Pattern
from milodb.command_framework.argument_stream import ArgumentStream
from milodb.tease import Tease, TeaseDateProperty, TeaseFloatProperty, TeaseIntProperty, TeaseProperty, TeaseStrListProperty, TeaseStrProperty, TeaseType, TeaseTypeProperty, TotmStatus
from milodb.tokeniser import Token

_REGEX_PATTERN_FLAGS: int = re.MULTILINE | re.DOTALL | re.IGNORECASE

class QueryMatch(ABC):
    @abstractmethod
    def get_match_count(self) -> int:
        pass

class MatchDetails:
    def __init__(self, start_index: int, end_index: int) -> None:
        self._start_index = start_index
        self._end_index = end_index

    @property
    def is_whole_match(self) -> bool:
        return (self._start_index == 0) and (self._end_index == 0)

    @property
    def start_index(self) -> int:
        return self._start_index

    @property
    def end_index(self) -> int:
        return self._end_index

class FieldQueryMatch(QueryMatch):
    def __init__(self, tease_property: TeaseProperty, list_of_matches: List[MatchDetails]) -> None:
        self.tease_property: TeaseProperty = tease_property
        self.list_of_matches: List[MatchDetails] = list_of_matches

    def get_match_count(self) -> int:
        return len(self.list_of_matches)

class FieldStrListQueryMatch(QueryMatch):
    def __init__(self, tease_property: TeaseStrListProperty, index_of_block: int, list_of_matches: List[MatchDetails]) -> None:
        self.tease_property: TeaseStrListProperty = tease_property
        self.index_of_block: int = index_of_block
        self.list_of_matches: List[MatchDetails] = list_of_matches

    def get_match_count(self) -> int:
        return len(self.list_of_matches)

class MatchResult(QueryMatch):
    pass

class TrueMatchResult(MatchResult):
    def __init__(self, list_of_query_matches: List[QueryMatch]) -> None:
        self.list_of_query_matches: List[QueryMatch] = list_of_query_matches

    def get_match_count(self) -> int:
        match_count: int = 0
        query_match: QueryMatch
        for query_match in self.list_of_query_matches:
            match_count += query_match.get_match_count()
        return match_count

class FalseMatchResult(MatchResult):
    def get_match_count(self) -> int:
        return 0

class TeaseMatch:
    def __init__(self, index_of_match: Optional[int], tease: Tease, list_of_query_matches: List[QueryMatch]) -> None:
        self.index_of_match: Optional[int] = index_of_match
        self.tease: Tease = tease
        self.list_of_query_matches: List[QueryMatch] = list_of_query_matches

    def get_match_count(self) -> int:
        match_count: int = 0
        query_match: QueryMatch
        for query_match in self.list_of_query_matches:
            match_count += query_match.get_match_count()
        return match_count

class QueryException(Exception):
    def __init__(self, message: str, token: Optional[Token], list_of_possible_text: Optional[List[str]] = None) -> None:
        super().__init__(message)
        self.token: Optional[Token] = token
        self.list_of_possible_text: Optional[List[str]] = list_of_possible_text

class QueryBase(ABC):
    @abstractmethod
    def perform_query(self, stack_of_match_results: List[MatchResult], tease: Tease) -> None:
        pass

class FieldFloatPredicate(QueryBase):
    @abstractmethod
    def __init__(self, tease_property: TeaseFloatProperty, argument_stream: ArgumentStream, compare_func: Callable[[float, float], bool]) -> None:
        pass

class FieldIntPredicate(QueryBase):
    @abstractmethod
    def __init__(self, tease_property: TeaseFloatProperty, argument_stream: ArgumentStream, compare_func: Callable[[int, int], bool]) -> None:
        pass

class FieldStrPredicate(QueryBase):
    @abstractmethod
    def __init__(self, tease_property: TeaseStrProperty, argument_stream: ArgumentStream) -> None:
        pass

class FieldStrListPredicate(QueryBase):
    @abstractmethod
    def __init__(self, tease_property: TeaseStrListProperty, argument_stream: ArgumentStream) -> None:
        pass

class FieldTypePredicate(QueryBase):
    @abstractmethod
    def __init__(self, tease_property: TeaseTypeProperty, argument_stream: ArgumentStream) -> None:
        pass

class FieldDatePredicate(QueryBase):
    @abstractmethod
    def __init__(self, tease_property: TeaseDateProperty, argument_stream: ArgumentStream, compare_func: Callable[[datetime.date, datetime.date], bool]) -> None:
        pass

class FieldTotmPredicate(QueryBase):
    @abstractmethod
    def __init__(self, argument_stream: ArgumentStream) -> None:
        pass

class FieldStrIs(FieldStrPredicate):
    def __init__(self, tease_property: TeaseStrProperty, argument_stream: ArgumentStream) -> None:
        self._tease_property: TeaseStrProperty = tease_property
        self._plain_text: str = argument_stream.pop_text().lower()

    def perform_query(self, stack_of_match_results: List[MatchResult], tease: Tease) -> None:
        field_value: str = tease.get_text_of_property(self._tease_property).lower()
        if field_value == self._plain_text:
            match: MatchDetails = MatchDetails(0, len(field_value))
            stack_of_match_results.append(TrueMatchResult(
                [FieldQueryMatch(self._tease_property, [match])]))
        else:
            stack_of_match_results.append(FalseMatchResult())

class FieldStrContains(FieldStrPredicate):
    def __init__(self, tease_property: TeaseStrProperty, argument_stream: ArgumentStream) -> None:
        self._tease_property: TeaseStrProperty = tease_property
        self._plain_text: str = argument_stream.pop_text().lower()

    def perform_query(self, stack_of_match_results: List[MatchResult], tease: Tease) -> None:
        list_of_match_details: List[MatchDetails] = []

        field_value: str = tease.get_text_of_property(self._tease_property).lower()
        search_index: int = 0
        while search_index != -1:
            search_index = field_value.find(self._plain_text, search_index)
            if search_index != -1:
                match: MatchDetails = MatchDetails(search_index, search_index + len(self._plain_text))
                list_of_match_details.append(match)
                search_index += len(self._plain_text)

        if list_of_match_details:
            stack_of_match_results.append(TrueMatchResult(
                [FieldQueryMatch(self._tease_property, list_of_match_details)]))
        else:
            stack_of_match_results.append(FalseMatchResult())

class FieldStrMatches(FieldStrPredicate):
    def __init__(self, tease_property: TeaseStrProperty, argument_stream: ArgumentStream) -> None:
        self._tease_property: TeaseStrProperty = tease_property
        self._pattern: Pattern[str] = argument_stream.pop_regex(_REGEX_PATTERN_FLAGS)

    def perform_query(self, stack_of_match_results: List[MatchResult], tease: Tease) -> None:
        field_value: str = tease.get_text_of_property(self._tease_property)
        list_of_matches: List[Match[str]] = list(self._pattern.finditer(field_value))
        if list_of_matches:
            list_of_match_details: List[MatchDetails] = [MatchDetails(match.start(), match.end()) for match in list_of_matches]
            stack_of_match_results.append(TrueMatchResult(
                [FieldQueryMatch(self._tease_property, list_of_match_details)]))
        else:
            stack_of_match_results.append(FalseMatchResult())

class FieldStrListIs(FieldStrListPredicate):
    def __init__(self, tease_property: TeaseStrListProperty, argument_stream: ArgumentStream) -> None:
        self._tease_property: TeaseStrListProperty = tease_property
        self._plain_text: str = argument_stream.pop_text().lower()

    def perform_query(self, stack_of_match_results: List[MatchResult], tease: Tease) -> None:
        list_of_query_matches: List[QueryMatch] = []

        list_index: int
        text: str
        for list_index, text in enumerate(self._tease_property(tease)):
            if text.lower() == self._plain_text:
                match: MatchDetails = MatchDetails(0, len(text))
                list_of_query_matches.append(FieldStrListQueryMatch(self._tease_property, list_index, [match]))

        if list_of_query_matches:
            stack_of_match_results.append(TrueMatchResult(list_of_query_matches))
        else:
            stack_of_match_results.append(FalseMatchResult())

class FieldStrListMatches(FieldStrListPredicate):
    def __init__(self, tease_property: TeaseStrListProperty, argument_stream: ArgumentStream) -> None:
        self._tease_property: TeaseStrListProperty = tease_property
        self._pattern: Pattern[str] = argument_stream.pop_regex(_REGEX_PATTERN_FLAGS)

    def perform_query(self, stack_of_match_results: List[MatchResult], tease: Tease) -> None:
        list_of_query_matches: List[QueryMatch] = []

        list_index: int
        text: str
        for list_index, text in enumerate(self._tease_property(tease)):
            list_of_matches: List[Match[str]] = list(self._pattern.finditer(text))
            if list_of_matches:
                list_of_match_details: List[MatchDetails] = [MatchDetails(match.start(), match.end()) for match in list_of_matches]
                list_of_query_matches.append(FieldStrListQueryMatch(self._tease_property, list_index, list_of_match_details))

        if list_of_query_matches:
            stack_of_match_results.append(TrueMatchResult(list_of_query_matches))
        else:
            stack_of_match_results.append(FalseMatchResult())

class FieldStrListContains(FieldStrListPredicate):
    def __init__(self, tease_property: TeaseStrListProperty, argument_stream: ArgumentStream) -> None:
        self._tease_property: TeaseStrListProperty = tease_property
        self._plain_text: str = argument_stream.pop_text().lower()

    def perform_query(self, stack_of_match_results: List[MatchResult], tease: Tease) -> None:
        list_of_query_matches: List[QueryMatch] = []

        list_index: int
        text: str
        for list_index, text in enumerate(self._tease_property(tease)):
            text = text.lower()
            list_of_match_details: List[MatchDetails] = []
            search_index: int = 0
            while search_index != -1:
                search_index = text.find(self._plain_text, search_index)
                if search_index != -1:
                    match: MatchDetails = MatchDetails(search_index, search_index + len(self._plain_text))
                    list_of_match_details.append(match)
                    search_index += len(self._plain_text)

            if list_of_match_details:
                list_of_query_matches.append(FieldStrListQueryMatch(self._tease_property, list_index, list_of_match_details))

        if list_of_query_matches:
            stack_of_match_results.append(TrueMatchResult(list_of_query_matches))
        else:
            stack_of_match_results.append(FalseMatchResult())

class FieldUnsignedIntCompare(FieldIntPredicate):
    def __init__(self, tease_property: TeaseIntProperty, argument_stream: ArgumentStream, compare_func: Callable[[int, int], bool]) -> None:
        self._tease_property: TeaseIntProperty = tease_property
        self._compare_func: Callable[[int, int], bool] = compare_func
        self._value: int = argument_stream.pop_uint()

    def perform_query(self, stack_of_match_results: List[MatchResult], tease: Tease) -> None:
        field_value: int = self._tease_property(tease)
        if self._compare_func(field_value, self._value):
            stack_of_match_results.append(TrueMatchResult(
                [FieldQueryMatch(self._tease_property, [MatchDetails(0, 0)])]))
        else:
            stack_of_match_results.append(FalseMatchResult())

class FieldUnsignedFloatCompare(FieldFloatPredicate):
    def __init__(self, tease_property: TeaseFloatProperty, argument_stream: ArgumentStream, compare_func: Callable[[float, float], bool]) -> None:
        self._tease_property: TeaseFloatProperty = tease_property
        self._compare_func: Callable[[float, float], bool] = compare_func
        self._value: float = argument_stream.pop_ufloat()

    def perform_query(self, stack_of_match_results: List[MatchResult], tease: Tease) -> None:
        field_value: float = self._tease_property(tease)
        if self._compare_func(field_value, self._value):
            stack_of_match_results.append(TrueMatchResult(
                [FieldQueryMatch(self._tease_property, [MatchDetails(0, 0)])]))
        else:
            stack_of_match_results.append(FalseMatchResult())

class FieldTypeIs(FieldTypePredicate):
    def __init__(self, tease_property: TeaseTypeProperty, argument_stream: ArgumentStream) -> None:
        self._tease_property: TeaseTypeProperty = tease_property
        self._tease_type: TeaseType = argument_stream.pop_enum_by_value(TeaseType)

    def perform_query(self, stack_of_match_results: List[MatchResult], tease: Tease) -> None:
        field_value: TeaseType = self._tease_property(tease)
        if field_value == self._tease_type:
            stack_of_match_results.append(TrueMatchResult(
                [FieldQueryMatch(self._tease_property, [MatchDetails(0, 0)])]))
        else:
            stack_of_match_results.append(FalseMatchResult())

class FieldDateCompare(FieldDatePredicate):
    def __init__(self, tease_property: TeaseDateProperty, argument_stream: ArgumentStream, compare_func: Callable[[datetime.date, datetime.date], bool]) -> None:
        self._tease_property: TeaseDateProperty = tease_property
        self._compare_func: Callable[[datetime.date, datetime.date], bool] = compare_func
        self._value: datetime.date = argument_stream.pop_date()

    def perform_query(self, stack_of_match_results: List[MatchResult], tease: Tease) -> None:
        field_value: datetime.date = self._tease_property(tease)
        if self._compare_func(field_value, self._value):
            stack_of_match_results.append(TrueMatchResult(
                [FieldQueryMatch(self._tease_property, [MatchDetails(0, 0)])]))
        else:
            stack_of_match_results.append(FalseMatchResult())

class FieldTotmIs(FieldTotmPredicate):
    _MAP_OF_VALUE_TO_COMPARATOR: Dict[str, Callable[[Tease], bool]] = {
        'winner': lambda tease: tease.totm_status() == TotmStatus.WINNER,
        'nominee': lambda tease: tease.totm_status() == TotmStatus.NOMINEE,
        'either': lambda tease: tease.totm_status() != TotmStatus.NONE
    }

    def __init__(self, argument_stream: ArgumentStream) -> None:
        self._comparator: Callable[[Tease], bool] = argument_stream.pop_dict_value(FieldTotmIs._MAP_OF_VALUE_TO_COMPARATOR)

    def perform_query(self, stack_of_match_results: List[MatchResult], tease: Tease) -> None:
        if self._comparator(tease):
            stack_of_match_results.append(TrueMatchResult(
                [FieldQueryMatch(Tease.totm_status, [MatchDetails(0, 0)])]))
        else:
            stack_of_match_results.append(FalseMatchResult())

class And(QueryBase):
    def perform_query(self, stack_of_match_results: List[MatchResult], tease: Tease) -> None:
        if len(stack_of_match_results) >= 2:
            right: QueryMatch = stack_of_match_results.pop()
            left: QueryMatch = stack_of_match_results.pop()
            if isinstance(left, TrueMatchResult) and isinstance(right, TrueMatchResult):
                merged: List[QueryMatch] = merge_list_of_query_matches(left.list_of_query_matches, right.list_of_query_matches)
                stack_of_match_results.append(TrueMatchResult(merged))
            else:
                stack_of_match_results.append(FalseMatchResult())
        else:
            raise QueryException("Bad expression: AND requires at least two match results on the stack", None)

class Not(QueryBase):
    def perform_query(self, stack_of_match_results: List[MatchResult], tease: Tease) -> None:
        if len(stack_of_match_results) >= 1:
            result: QueryMatch = stack_of_match_results.pop()
            if isinstance(result, TrueMatchResult):
                stack_of_match_results.append(FalseMatchResult())
            else:
                stack_of_match_results.append(TrueMatchResult([]))
        else:
            raise QueryException("Bad expression: NOT requires at least one match result on the stack", None)

class Or(QueryBase):
    def perform_query(self, stack_of_match_results: List[MatchResult], tease: Tease) -> None:
        if len(stack_of_match_results) >= 2:
            right: QueryMatch = stack_of_match_results.pop()
            left: QueryMatch = stack_of_match_results.pop()
            if isinstance(left, TrueMatchResult):
                if isinstance(right, TrueMatchResult):
                    merged: List[QueryMatch] = merge_list_of_query_matches(left.list_of_query_matches, right.list_of_query_matches)
                    stack_of_match_results.append(TrueMatchResult(merged))
                else:
                    stack_of_match_results.append(left)
            else:
                if isinstance(right, TrueMatchResult):
                    stack_of_match_results.append(right)
                else:
                    stack_of_match_results.append(FalseMatchResult())
        else:
            raise QueryException("Bad expression: OR requires at least two query results on the stack", None)

def merge_list_of_query_matches(left: List[QueryMatch], right: List[QueryMatch]) -> List[QueryMatch]:
    new_list_of_query_matches: List[QueryMatch] = merge_list_of_field_query_matches(left, right)
    new_list_of_query_matches.extend(merge_list_of_field_string_list_query_matches(left, right))
    return new_list_of_query_matches

def merge_list_of_field_query_matches(left: List[QueryMatch], right: List[QueryMatch]) -> List[QueryMatch]:
    merged_list: List[QueryMatch] = []

    list_of_all_field_query_matches: List[FieldQueryMatch] = [match for match in left if isinstance(match, FieldQueryMatch)]
    list_of_all_field_query_matches.extend([match for match in right if isinstance(match, FieldQueryMatch)])

    list_of_unique_tease_properties: List[TeaseProperty] = []
    field_query_match: FieldQueryMatch
    for field_query_match in list_of_all_field_query_matches:
        if field_query_match.tease_property not in list_of_unique_tease_properties:
            list_of_unique_tease_properties.append(field_query_match.tease_property)

    tease_property: TeaseProperty
    for tease_property in list_of_unique_tease_properties:
        merged_field_query_match = FieldQueryMatch(tease_property, [])
        for match in list_of_all_field_query_matches:
            if match.tease_property == tease_property:
                merged_field_query_match.list_of_matches.extend(match.list_of_matches)
        merged_list.append(merged_field_query_match)

    return merged_list

def merge_list_of_field_string_list_query_matches(left: List[QueryMatch], right: List[QueryMatch]) -> List[FieldStrListQueryMatch]:
    merged_list: List[FieldStrListQueryMatch] = []

    list_of_all_field_query_matches: List[FieldStrListQueryMatch] = [match for match in left if isinstance(match, FieldStrListQueryMatch)]
    list_of_all_field_query_matches.extend([match for match in right if isinstance(match, FieldStrListQueryMatch)])

    list_of_unique_tease_properties: List[TeaseStrListProperty] = []
    field_query_match: FieldStrListQueryMatch
    for field_query_match in list_of_all_field_query_matches:
        if field_query_match.tease_property not in list_of_unique_tease_properties:
            list_of_unique_tease_properties.append(field_query_match.tease_property)

    tease_property: TeaseStrListProperty
    for tease_property in list_of_unique_tease_properties:
        list_of_query_matches_for_property: List[FieldStrListQueryMatch] = [
            field_query_match for field_query_match in list_of_all_field_query_matches if field_query_match.tease_property == tease_property
        ]
        merged_list.extend(merge_list_of_field_string_list_query_matches_for_single_property(list_of_query_matches_for_property))

    return merged_list

def merge_list_of_field_string_list_query_matches_for_single_property(list_of_query_matches: List[FieldStrListQueryMatch]) -> List[FieldStrListQueryMatch]:
    merged_list: List[FieldStrListQueryMatch] = []

    list_of_query_matches = sorted(list_of_query_matches, key=lambda match: match.index_of_block)

    current_match: Optional[FieldStrListQueryMatch] = None
    match: FieldStrListQueryMatch
    for match in list_of_query_matches:
        if current_match:
            if current_match.index_of_block == match.index_of_block:
                current_match.list_of_matches.extend(match.list_of_matches)
            else:
                merged_list.append(current_match)
                current_match = match
        else:
            current_match = match

    if current_match:
        merged_list.append(current_match)

    return merged_list
