import datetime
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Union
from milodb.commands.enums import EnumEx

class TeaseType(EnumEx):
    REGULAR = 'reg'
    AUDIO = 'aud'
    NYX = 'nyx'
    EOS = 'eos'

class TotmStatus(Enum):
    NONE = 0
    NOMINEE = 1
    WINNER = 2

TeasePropertyType = Union[str, int, float, TeaseType, List[str], datetime.date, TotmStatus]
TeaseProperty = Callable[['Tease'], TeasePropertyType]
TeaseStrProperty = Callable[['Tease'], str]
TeaseIntProperty = Callable[['Tease'], int]
TeaseFloatProperty = Callable[['Tease'], float]
TeaseTypeProperty = Callable[['Tease'], TeaseType]
TeaseDateProperty = Callable[['Tease'], datetime.date]
TeaseTotmProperty = Callable[['Tease'], TotmStatus]
TeaseStrListProperty = Callable[['Tease'], List[str]]

_MAX_TEASE_ID: int = 999999
_MAX_AUTHOR_ID: int = 999999
_MAX_IMAGE_COUNT: int = 999999

class Tease:
    class LoadError(Exception):
        pass

    def __init__(self, metadata: Dict[Any, Any]) -> None:
        self._tease_id: int = self._get_meta_uint(metadata, 'tid', 1, _MAX_TEASE_ID)
        self._author_id: Optional[int] = self._try_get_meta_uint(metadata, 'aid', 0, _MAX_AUTHOR_ID)
        raw_type: int = self._get_meta_uint(metadata, 'typ', min(_MAP_OF_RAW_TYPE_TO_COOKED_TYPE.keys()), max(_MAP_OF_RAW_TYPE_TO_COOKED_TYPE.keys()))
        possible_type: Optional[TeaseType] = _MAP_OF_RAW_TYPE_TO_COOKED_TYPE.get(raw_type)
        if not possible_type:
            raise Tease.LoadError(f"Type of tease '{raw_type}' is unknown")
        self._type: TeaseType = possible_type
        self._title: str = self._get_optional_meta_str(metadata, 'ttl')
        self._summary: str = self._get_optional_meta_str(metadata, 'sum')
        self._thumbnail: str = self._get_optional_meta_str(metadata, 'thm')
        self._author_name: str = self._get_optional_meta_str(metadata, 'anm')
        raw_tags: str = self._get_optional_meta_str(metadata, 'tgs')
        self._tags: List[str] = [tag for tag in raw_tags.split(':') if tag]
        self._date: datetime.date = self._get_meta_date(metadata, 'dat')
        self._rating_value: float = self._get_optional_meta_float(metadata, 'rvl', 1, 5, 0.0)
        self._list_of_text_blocks: List[str] = []
        self._totm_status = TotmStatus.NONE
        if 'totm-nominee' in self._tags:
            self._totm_status = TotmStatus.NOMINEE
        if 'totm' in self._tags:
            self._totm_status = TotmStatus.WINNER
        raw_text_list: Any = metadata.get('txt')
        if isinstance(raw_text_list, list):
            text_value: Any
            for text_value in raw_text_list:
                if isinstance(text_value, str):
                    self._list_of_text_blocks.append(text_value)
        self._count_of_images = self._get_optional_meta_uint(metadata, 'imr', 0, _MAX_IMAGE_COUNT, 0)
        self._count_of_unique_images = self._get_optional_meta_uint(metadata, 'imu', 0, _MAX_IMAGE_COUNT, 0)

    def tease_id(self) -> int:
        return self._tease_id

    def has_author(self) -> bool:
        return self._author_id is not None

    def author_id(self) -> int:
        return self._author_id or 0

    def type(self) -> TeaseType:
        return self._type

    def title(self) -> str:
        return self._title

    def summary(self) -> str:
        return self._summary

    def thumbnail(self) -> str:
        return self._thumbnail

    def author_name(self) -> str:
        return self._author_name

    def list_of_tags(self) -> List[str]:
        return self._tags

    def date(self) -> datetime.date:
        return self._date

    def rating_value(self) -> float:
        return self._rating_value

    def totm_status(self) -> TotmStatus:
        return self._totm_status

    def list_of_text_blocks(self) -> List[str]:
        return self._list_of_text_blocks

    def count_of_images(self) -> int:
        return self._count_of_images

    def count_of_unique_images(self) -> int:
        return self._count_of_unique_images

    def get_text_of_property(self, tease_property: TeaseProperty) -> str:
        value: TeasePropertyType = tease_property(self)
        if isinstance(value, TeaseType):
            return value.value
        if isinstance(value, str):
            return value
        if isinstance(value, (int, float)):
            return str(value)
        if isinstance(value, datetime.date):
            return value.isoformat()
        return ''

    @staticmethod
    def _get_meta_uint(metadata: Dict[str, Any], key: str, min_value: int, max_value: int) -> int:
        try:
            value: Any = metadata[key]
            if isinstance(value, int):
                if min_value <= value <= max_value:
                    return value
                raise Tease.LoadError(f"Key '{key}' value '{value}' out of range")
            raise Tease.LoadError(f"Key '{key}' is not an integer")
        except KeyError as ex:
            raise Tease.LoadError(f"Key '{key}' is missing") from ex

    @staticmethod
    def _try_get_meta_uint(metadata: Dict[str, Any], key: str, min_value: int, max_value: int) -> Optional[int]:
        value: Any = metadata.get(key)
        if value is not None:
            if isinstance(value, int):
                if min_value <= value <= max_value:
                    return value
                raise Tease.LoadError(f"Key '{key}' value '{value}' out of range")
            raise Tease.LoadError(f"Key '{key}' is not an integer")
        return None

    @staticmethod
    def _get_optional_meta_uint(metadata: Dict[str, Any], key: str, min_value: int, max_value: int, default_value: int) -> int:
        value: Optional[int] = Tease._try_get_meta_uint(metadata, key, min_value, max_value)
        return value if value is not None else default_value

    @staticmethod
    def _get_optional_meta_float(metadata: Dict[str, Any], key: str, min_value: float, max_value: float, default_value: float) -> float:
        value: Any = metadata.get(key)
        if value:
            if isinstance(value, (float, int)):
                if min_value <= value <= max_value:
                    return float(value)
                raise Tease.LoadError(f"Key '{key}' value '{value}' out of range")
            raise Tease.LoadError(f"Key '{key}' value '{value}' is not a decimal")
        return default_value

    @staticmethod
    def _get_meta_str(metadata: Dict[str, Any], key: str) -> str:
        try:
            value: Any = metadata[key]
            if isinstance(value, str):
                return value
            raise Tease.LoadError(f"Key '{key}' is not a string value")
        except KeyError as ex:
            raise Tease.LoadError(f"Key '{key}' is missing") from ex

    @staticmethod
    def _get_optional_meta_str(metadata: Dict[str, Any], key: str) -> str:
        value: Any = metadata.get(key, '')
        if isinstance(value, str):
            return value
        raise Tease.LoadError(f"Key '{key}' is not a string value")

    @staticmethod
    def _get_meta_date(metadata: Dict[str, Any], key: str) -> datetime.date:
        try:
            value: Any = metadata[key]
            if isinstance(value, str):
                return datetime.date.fromisoformat(value)
            raise Tease.LoadError(f"Key '{key}' is not a string value")
        except ValueError as ex:
            raise Tease.LoadError(f"Key '{key}' is not a valid date format: '{ex}'") from ex
        except KeyError as ex:
            raise Tease.LoadError(f"Key '{key}' is missing") from ex

_MAP_OF_RAW_TYPE_TO_COOKED_TYPE: Dict[int, TeaseType] = {
    0: TeaseType.REGULAR,
    1: TeaseType.NYX,
    2: TeaseType.EOS,
    3: TeaseType.AUDIO
}
