from typing import Optional

MILODB_VERSION: Optional[str] = '1.10'
MILODB_DATE: Optional[str] = '2023-01-31'
