from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import List, Optional, Type, Union
from milodb.command_framework.argument_stream import ArgumentStream
from milodb.command_framework.i_command import ICommand
from milodb.tokeniser import Token

@dataclass
class EmptyInputResult:
    list_of_command_names: List[str]

@dataclass
class SuccessfulLoadResult:
    command: ICommand
    list_of_possible_next_text: List[str]

@dataclass
class FailedLoadResult:
    command_class: Optional[Type[ICommand]]
    fault_token: Optional[Token]
    fault_text: str
    input_text: str
    list_of_expected_text: List[str]

LoadResult = Union[SuccessfulLoadResult, FailedLoadResult, EmptyInputResult]

@dataclass
class CommandLoadDelegateError(Exception):
    load_result: LoadResult

class ICommandLoader(ABC):
    @abstractmethod
    def try_load(self, argument_stream: ArgumentStream) -> LoadResult:
        pass
