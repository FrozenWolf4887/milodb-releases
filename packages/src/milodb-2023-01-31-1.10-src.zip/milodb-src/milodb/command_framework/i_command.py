from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import List, Optional, Type
from milodb.command_framework.argument_stream import ArgumentStream
from milodb.tokeniser import Token

class ICommand(ABC):
    @abstractmethod
    def load(self, argument_stream: ArgumentStream) -> List[str]:
        pass

    @abstractmethod
    def execute(self) -> None:
        pass

class ICommandCreator(ABC):
    @abstractmethod
    def create(self) -> ICommand:
        pass

    @abstractmethod
    def get_command_class(self) -> Type[ICommand]:
        pass

@dataclass
class CommandLoadError(Exception):
    message: str
    fault_token: Optional[Token]
    list_of_expected_text: List[str]
