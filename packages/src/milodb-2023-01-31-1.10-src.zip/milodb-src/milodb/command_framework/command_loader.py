from typing import List, Optional
from milodb.command_framework.argument_stream import ArgumentStream, ArgumentStreamError
from milodb.command_framework.i_command import CommandLoadError, ICommand
from milodb.command_framework.i_command_factory import ICommandFactory
from milodb.command_framework.i_command_loader import CommandLoadDelegateError, EmptyInputResult, FailedLoadResult, ICommandLoader, LoadResult, SuccessfulLoadResult
from milodb.tokeniser import Token, TokenStreamError

class CommandLoader(ICommandLoader):
    def __init__(self, command_factory: ICommandFactory) -> None:
        self._command_factory: ICommandFactory = command_factory

    def try_load(self, argument_stream: ArgumentStream) -> LoadResult:
        result: LoadResult

        command_token: Optional[Token] = argument_stream.pop_optional_token()
        if command_token:
            result = self._try_load_from_command_name(argument_stream, command_token)
        else:
            result = EmptyInputResult(list(self._command_factory.get_list_of_command_names()))

        return result

    def _try_load_from_command_name(self, argument_stream: ArgumentStream, command_token: Token) -> LoadResult:
        result: LoadResult

        command: Optional[ICommand] = self._command_factory.try_get_command_from_name(command_token.text)
        if command:
            result = self._try_load_command(argument_stream, command)
        else:
            result = FailedLoadResult(
                command_class = None,
                fault_token = command_token,
                fault_text = 'Unknown command',
                input_text = self._get_expanded_input_text(argument_stream),
                list_of_expected_text = self._command_factory.get_list_of_command_names())

        return result

    def _try_load_command(self, argument_stream: ArgumentStream, command: ICommand) -> LoadResult:
        result: LoadResult

        try:
            list_of_possible_next_text: List[str] = command.load(argument_stream)
            result = SuccessfulLoadResult(command, list_of_possible_next_text)
        except TokenStreamError as ex:
            result = FailedLoadResult(
                command_class = type(command),
                fault_token = ex.cause_of_fault_token,
                fault_text = f"Parsing error at character #{ex.cause_of_fault_character_index} '{ex.cause_of_fault_text}'",
                input_text = self._get_expanded_input_text(argument_stream),
                list_of_expected_text = ex.list_of_expected_text)
        except ArgumentStreamError as ex:
            result = FailedLoadResult(
                command_class = type(command),
                fault_token = ex.fault_token,
                fault_text = f"Argument error '{ex.message}'",
                input_text = self._get_expanded_input_text(argument_stream),
                list_of_expected_text = ex.list_of_expected_text)
        except CommandLoadError as ex:
            result = FailedLoadResult(
                command_class = type(command),
                fault_token = ex.fault_token,
                fault_text = ex.message,
                input_text = self._get_expanded_input_text(argument_stream),
                list_of_expected_text = ex.list_of_expected_text)
        except CommandLoadDelegateError as ex:
            result = ex.load_result

        return result

    def _get_expanded_input_text(self, argument_stream: ArgumentStream) -> str:
        return argument_stream.get_expanded_raw_text() + argument_stream.get_remaining_raw_text()
