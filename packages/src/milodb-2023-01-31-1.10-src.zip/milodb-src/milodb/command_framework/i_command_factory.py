from abc import ABC, abstractmethod
from typing import List, Optional
from milodb.command_framework.i_command import ICommand
from milodb.command_framework.i_help_info import IHelpInfo

class ICommandFactory(ABC):
    @abstractmethod
    def get_list_of_command_names(self) -> List[str]:
        pass

    @abstractmethod
    def try_get_command_from_name(self, command_name: str) -> Optional[ICommand]:
        pass

    @abstractmethod
    def try_get_command_help_from_name(self, command_name: str) -> Optional[IHelpInfo]:
        pass
