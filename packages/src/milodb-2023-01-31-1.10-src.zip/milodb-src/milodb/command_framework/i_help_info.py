from abc import ABC, abstractmethod

class IHelpInfo(ABC):
    @abstractmethod
    def get_one_line_summary(self) -> str:
        pass

    @abstractmethod
    def get_detailed_summary(self) -> str:
        pass
