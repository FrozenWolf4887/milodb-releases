from typing import List, Optional
from milodb import query
from milodb.command_framework.argument_stream import ArgumentStream
from milodb.commands.command import Command
from milodb.commands.command_context import CommandContext
from milodb.commands.database_support import try_create_list_of_tease_matches_from_ref_ids
from milodb.commands.help_info import HelpInfo
from milodb.ref_id import RefId

class SummaryCommand(Command):
    def __init__(self, context: CommandContext) -> None:
        self._context = context
        self._list_of_ref_ids: List[RefId] = []

    def load(self, argument_stream: ArgumentStream) -> List[str]:
        self._list_of_ref_ids = argument_stream.pop_list_of_ref_ids()
        return []

    def execute(self) -> None:
        list_of_tease_matches: Optional[List[query.TeaseMatch]] = None
        if self._list_of_ref_ids:
            list_of_tease_matches = try_create_list_of_tease_matches_from_ref_ids(self._context, self._list_of_ref_ids)
        else:
            list_of_tease_matches = self._context.list_of_tease_matches

        if list_of_tease_matches:
            is_first_tease: bool = True
            tease_match: query.TeaseMatch
            for tease_match in list_of_tease_matches:
                if is_first_tease:
                    is_first_tease = False
                else:
                    self._context.session_config.normal_writer.writeln()
                self._context.current_outputter.print_summary_of_tease(tease_match)
        else:
            self._context.session_config.error_writer.writeln("No teases available to summarise")

    class Help(HelpInfo):
        def __init__(self, context: CommandContext) -> None:
            self._context = context

        def get_one_line_summary(self) -> str:
            return "Prints the summaries for the current results"

        def get_detailed_summary(self) -> str:
            return (
                "Arguments: [list of RefIds]\n"
                "Shows summary details for each tease without any matching text paragraphs. The"
                " formatting used for the details can be controlled with the format command.\n"
                "When used without arguments, all teases that were found from the last query are"
                " included. When one or more RefIds are specified, only those teases are included.\n"
                "RefIds can be an index into the list of matches such as '3', a teaseId such as"
                " '#38664', or an authorId such as '@43937'.\n"
                "Matching fields may be highlighted which can be controlled with the highlight"
                " command.\n"
                "Example:\r"
                "  \tShow details of the last query results\r"
                "  > \tsummary\r"
                "Example:\r"
                "  \tShow details of a tease by index in the match list\r"
                "  > \tsummary 3\r"
                "Example:\r"
                "  \tShow details for some specific teaseIds\r"
                "  > \tsummary #16830 #1465 #38664\r"
                "Example:\r"
                "  \tShow details of the teases from a specific authorId\r"
                "  > \topen @43937\n"
                "See also:\r"
                "  \tshow, format, highlight\n"
            )
