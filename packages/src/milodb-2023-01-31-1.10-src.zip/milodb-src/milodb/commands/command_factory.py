from dataclasses import dataclass
from typing import Dict, List, Optional, Type
from milodb.command_framework.i_command import ICommand
from milodb.command_framework.i_command_factory import ICommandFactory
from milodb.command_framework.i_help_info import IHelpInfo
from milodb.commands.browse_command import BrowseCommand
from milodb.commands.browseall_command import BrowseAllCommand
from milodb.commands.command import Command
from milodb.commands.command_context import CommandContext
from milodb.commands.copy_command import CopyCommand
from milodb.commands.ellipsis_command import EllipsisCommand
from milodb.commands.exit_command import ExitCommand
from milodb.commands.format_command import FormatCommand
from milodb.commands.help_command import HelpCommand
from milodb.commands.help_info import HelpInfo
from milodb.commands.highlight_command import HighlightCommand
from milodb.commands.list_command import ListCommand
from milodb.commands.open_command import OpenCommand
from milodb.commands.openauthor_command import OpenAuthorCommand
from milodb.commands.query_command import QueryCommand
from milodb.commands.show_command import ShowCommand
from milodb.commands.showall_command import ShowAllCommand
from milodb.commands.sort_command import SortCommand
from milodb.commands.stats_command import StatsCommand
from milodb.commands.summary_command import SummaryCommand
from milodb.commands.url_command import UrlCommand
from milodb.commands.urlauthor_command import UrlAuthorCommand
from milodb.commands.var_command import VarCommand

@dataclass
class CommandHost:
    command_class: Type[Command]
    command_help_class: Type[HelpInfo]

class CommandFactory(ICommandFactory):
    _MAP_OF_COMMAND_CLASS_TO_HOST: Dict[str, CommandHost] = {
        'exit': CommandHost(ExitCommand, ExitCommand.Help),
        'help': CommandHost(HelpCommand, HelpCommand.Help),
        'list': CommandHost(ListCommand, ListCommand.Help),
        'format': CommandHost(FormatCommand, FormatCommand.Help),
        'highlight': CommandHost(HighlightCommand, HighlightCommand.Help),
        'ellipsis': CommandHost(EllipsisCommand, EllipsisCommand.Help),
        'show': CommandHost(ShowCommand, ShowCommand.Help),
        'showall': CommandHost(ShowAllCommand, ShowAllCommand.Help),
        'summary': CommandHost(SummaryCommand, SummaryCommand.Help),
        'open': CommandHost(OpenCommand, OpenCommand.Help),
        'openauthor': CommandHost(OpenAuthorCommand, OpenAuthorCommand.Help),
        'browse': CommandHost(BrowseCommand, BrowseCommand.Help),
        'browseall': CommandHost(BrowseAllCommand, BrowseAllCommand.Help),
        'query': CommandHost(QueryCommand, QueryCommand.Help),
        'sort': CommandHost(SortCommand, SortCommand.Help),
        'url': CommandHost(UrlCommand, UrlCommand.Help),
        'urlauthor': CommandHost(UrlAuthorCommand, UrlAuthorCommand.Help),
        'stats': CommandHost(StatsCommand, StatsCommand.Help),
        'copy': CommandHost(CopyCommand, CopyCommand.Help),
        'var': CommandHost(VarCommand, VarCommand.Help)
    }

    def __init__(self) -> None:
        self._context: Optional[CommandContext] = None

    def set_command_context(self, context: CommandContext) -> None:
        self._context = context

    def get_list_of_command_names(self) -> List[str]:
        return list(CommandFactory._MAP_OF_COMMAND_CLASS_TO_HOST)

    def try_get_command_from_name(self, command_name: str) -> Optional[ICommand]:
        if self._context:
            host: Optional[CommandHost] = CommandFactory._MAP_OF_COMMAND_CLASS_TO_HOST.get(command_name)
            if host:
                return host.command_class(self._context)
        return None

    def try_get_command_help_from_name(self, command_name: str) -> Optional[IHelpInfo]:
        if self._context:
            host: Optional[CommandHost] = CommandFactory._MAP_OF_COMMAND_CLASS_TO_HOST.get(command_name)
            if host:
                return host.command_help_class(self._context)
        return None
