from abc import ABC, abstractmethod
from milodb.command_framework.i_command import ICommand
from milodb.commands.command_context import CommandContext

class Command(ICommand, ABC):
    @abstractmethod
    def __init__(self, context: CommandContext) -> None:
        pass
