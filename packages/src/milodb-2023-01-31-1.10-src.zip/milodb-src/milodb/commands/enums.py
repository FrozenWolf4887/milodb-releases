from enum import Enum
from typing import List

class EnumEx(Enum):
    @classmethod
    def lowercase_names(cls) -> List[str]:
        return [e.name.lower() for e in cls]

    @classmethod
    def values(cls) -> List[str]:
        return [e.value for e in cls]

    @classmethod
    def lowercase_values(cls) -> List[str]:
        return [e.value.lower() for e in cls]

class OnOrOff(EnumEx):
    ON = True
    OFF = False
