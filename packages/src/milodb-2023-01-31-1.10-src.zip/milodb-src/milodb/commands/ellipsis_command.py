from typing import List, Optional
from milodb.command_framework.argument_stream import ArgumentStream
from milodb.commands.command import Command
from milodb.commands.command_context import CommandContext
from milodb.commands.enums import OnOrOff
from milodb.commands.help_info import HelpInfo

class EllipsisCommand(Command):
    def __init__(self, context: CommandContext) -> None:
        self._context = context
        self._new_ellipsis: Optional[OnOrOff] = None

    def load(self, argument_stream: ArgumentStream) -> List[str]:
        self._new_ellipsis = argument_stream.pop_optional_enum(OnOrOff)
        if self._new_ellipsis is not None:
            argument_stream.fail_if_not_empty()
            return []
        return OnOrOff.lowercase_names()

    def execute(self) -> None:
        if self._new_ellipsis:
            self._context.session_config.is_ellipsis_enabled = self._new_ellipsis.value
            self._context.session_config.normal_writer.writeln(f"Changed ellipsis mode to '{self._new_ellipsis.name.lower()}'")
        else:
            self._context.session_config.normal_writer.writeln(f"Current ellipsis mode is '{OnOrOff(self._context.session_config.is_ellipsis_enabled).name.lower()}'")
            self._context.session_config.normal_writer.writeln(f"Available options are {OnOrOff.lowercase_names()}")

    class Help(HelpInfo):
        def __init__(self, context: CommandContext) -> None:
            self._context = context

        def get_one_line_summary(self) -> str:
            return "Sets whether matching text paragraphs are abbreviated with an ellipsis"

        def get_detailed_summary(self) -> str:
            return (
                f"Arguments: [{'|'.join(OnOrOff.lowercase_names())}]\n"
                "Enables or disables the abbreviation for text in paragraph matches. Abbreviation"
                " is typically shown with the ellipsis character '\u2026'.\n"
                "When used without arguments, the current setting is shown.\n"
                "Example:\r"
                "  \tTurn off text abbreviation\r"
                "  > \tellipsis off\r"
                "Example:\r"
                "  \tShow the current setting\r"
                "  > \tellipsis\n"
                "See also:\r"
                "  \tshow, browse, format, highlight\n"
            )
