from typing import List, Optional
from milodb import query
from milodb.command_framework.argument_stream import ArgumentStream
from milodb.commands.command import Command
from milodb.commands.command_context import CommandContext
from milodb.commands.database_support import try_get_tease_id_from_ref_id
from milodb.commands.help_info import HelpInfo
from milodb.output.support import get_url_of_author, get_url_of_tease
from milodb.ref_id import AuthorId, RefId

class UrlCommand(Command):
    def __init__(self, context: CommandContext) -> None:
        self._context = context
        self._ref_id: RefId

    def load(self, argument_stream: ArgumentStream) -> List[str]:
        self._ref_id = argument_stream.pop_ref_id()
        argument_stream.fail_if_not_empty()
        return []

    def execute(self) -> None:
        if isinstance(self._ref_id, AuthorId):
            author_url: str = get_url_of_author(self._ref_id.author_id)
            self._context.session_config.normal_writer.writeln(author_url)
        else:
            tease_match: Optional[query.TeaseMatch] = try_get_tease_id_from_ref_id(self._context, self._ref_id)
            if tease_match:
                tease_url: str = get_url_of_tease(tease_match.tease.tease_id())
                self._context.session_config.normal_writer.writeln(tease_url)

    class Help(HelpInfo):
        def __init__(self, context: CommandContext) -> None:
            self._context = context

        def get_one_line_summary(self) -> str:
            return "Displays the URL of a specified tease or author profile"

        def get_detailed_summary(self) -> str:
            return (
                "Arguments: <RefId>\n"
                "This command is often used with the copy command to copy the displayed URL to"
                " the clipboard.\n"
                "RefIds can be an index into the list of matches such as '3', a teaseId such as"
                " '#38664', or an authorId such as '@43937'.\n"
                "Example:\r"
                "  \tDisplay the URL of a tease by index in the match list\r"
                "  > \turl 3\r"
                "Example:\r"
                "  \tDisplay the URL of a tease by its specific teaseId\r"
                "  > \turl #16830\r"
                "Example:\r"
                "  \tDisplay the URL of an author's profile by specific authorId\r"
                "  > \turl @43937\n"
                "See also:\r"
                "  \tcopy, urlauthor, open, openauthor\n"
            )
