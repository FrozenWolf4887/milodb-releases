from typing import List, Optional
from milodb.command_framework.argument_stream import ArgumentStream
from milodb.commands.command import Command
from milodb.commands.command_context import CommandContext
from milodb.commands.enums import OnOrOff
from milodb.commands.help_info import HelpInfo

class HighlightCommand(Command):
    def __init__(self, context: CommandContext) -> None:
        self._context = context
        self._new_highlighting: Optional[OnOrOff] = None

    def load(self, argument_stream: ArgumentStream) -> List[str]:
        self._new_highlighting = argument_stream.pop_optional_enum(OnOrOff)
        if self._new_highlighting is not None:
            argument_stream.fail_if_not_empty()
            return []
        return OnOrOff.lowercase_names()

    def execute(self) -> None:
        if self._new_highlighting:
            self._context.session_config.is_highlighting_enabled = self._new_highlighting.value
            self._context.session_config.normal_writer.writeln(f"Changed highlighting to '{self._new_highlighting.name.lower()}'")
        else:
            self._context.session_config.normal_writer.writeln(f"Current highlighting is '{OnOrOff(self._context.session_config.is_highlighting_enabled).name.lower()}'")
            self._context.session_config.normal_writer.writeln(f"Available options are {OnOrOff.lowercase_names()}")

    class Help(HelpInfo):
        def __init__(self, context: CommandContext) -> None:
            self._context = context

        def get_one_line_summary(self) -> str:
            return "Sets whether text matches are highlighted in the output"

        def get_detailed_summary(self) -> str:
            return (
                f"Arguments: [{'|'.join(OnOrOff.lowercase_names())}]\n"
                "Enables or disables the highlighting of matching text in fields and paragraphs.\n"
                "When used without arguments, the current setting is shown.\n"
                "Highlighting will only be shown on the console when a suitable output format has"
                " been selected with the format command.\n"
                "Example:\r"
                "  \tTurn off highlighting\r"
                "  > \thighlight off\r"
                "Example:\r"
                "  \tShow the current setting\r"
                "  > \thighlight\n"
                "See also:\r"
                "  \tlist, show, browse, browseall, ellipsis, format\n"
            )
