from typing import Any, List, Optional
import pyperclip # type: ignore
from milodb.command_framework.argument_stream import ArgumentStream
from milodb.command_framework.command_loader import CommandLoader
from milodb.command_framework.i_command import CommandLoadError, ICommand
from milodb.command_framework.i_command_loader import CommandLoadDelegateError, EmptyInputResult, LoadResult, SuccessfulLoadResult
from milodb.commands.command import Command
from milodb.commands.command_context import CommandContext
from milodb.commands.help_info import HelpInfo
from milodb.config.session_config import SessionConfig
from milodb.output.capturing_output_sink import CapturingOutputSink
from milodb.output.output_sink import OutputSink, OutputWriter

class CopyCommand(Command):
    def __init__(self, context: CommandContext) -> None:
        self._context = context
        self._delegate_command: Optional[ICommand] = None

    def load(self, argument_stream: ArgumentStream) -> List[str]:
        command_loader: CommandLoader = CommandLoader(self._context.command_factory)
        load_result: LoadResult = command_loader.try_load(argument_stream)
        if isinstance(load_result, SuccessfulLoadResult):
            self._delegate_command = load_result.command
            return load_result.list_of_possible_next_text
        if isinstance(load_result, EmptyInputResult):
            raise CommandLoadError(
                'Expecting a following command', None, load_result.list_of_command_names)
        raise CommandLoadDelegateError(load_result)

    def execute(self) -> None:
        if self._delegate_command:
            with _Capture(self._context.session_config):
                self._delegate_command.execute()

    class Help(HelpInfo):
        def __init__(self, context: CommandContext) -> None:
            self._context = context

        def get_one_line_summary(self) -> str:
            return "Copies the output of the subsequent command to the clipboard"

        def get_detailed_summary(self) -> str:
            return (
                "Arguments: <subsequent command...>\n"
                "The output of the subsequent command is copied to the clipboard in the currently"
                " selected format.\n"
                "Example:\r"
                "  \tList the current query results and copy the list to the clipboard\r"
                "  > \tcopy list\n"
                "Example:\r"
                "  \tCopy the url of the author of match #3 to the clipboard\r"
                "  > \tcopy urlauthor 3\n"
                "See also:\r"
                "  \tformat, ellipsis, highlight\n"
            )

class _Capture:
    def __init__(self, session_config: SessionConfig) -> None:
        self._session_config: SessionConfig = session_config
        self._previous_normal_writer: OutputSink
        self._previous_error_writer: OutputWriter
        self._previous_warning_writer: OutputWriter
        self._capturing_text_output: CapturingOutputSink

    def __enter__(self) -> None:
        self._previous_normal_writer = self._session_config.normal_writer
        self._previous_error_writer = self._session_config.error_writer
        self._previous_warning_writer = self._session_config.warning_writer
        self._capturing_text_output = CapturingOutputSink(self._previous_normal_writer)
        self._session_config.normal_writer = self._capturing_text_output
        self._session_config.error_writer.redirect_output(self._capturing_text_output)
        self._session_config.warning_writer.redirect_output(self._capturing_text_output)

    def __exit__(self, exc_type: Any, exc_value: Any, traceback: Any) -> None:
        self._session_config.normal_writer = self._previous_normal_writer
        self._session_config.error_writer = self._previous_error_writer
        self._session_config.warning_writer = self._previous_warning_writer
        try:
            pyperclip.copy(self._capturing_text_output.text.rstrip())  # type: ignore
        except pyperclip.PyperclipException as ex:
            print(f'Error: Unable to copy to clipboard: {ex}')

    @property
    def text(self) -> str:
        return self._capturing_text_output.text
