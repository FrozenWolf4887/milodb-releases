import webbrowser
from typing import List, Optional
from milodb import query
from milodb.command_framework.argument_stream import ArgumentStream
from milodb.commands.command import Command
from milodb.commands.command_context import CommandContext
from milodb.commands.database_support import try_create_list_of_tease_matches_from_ref_ids
from milodb.commands.help_info import HelpInfo
from milodb.output.support import get_url_of_author
from milodb.ref_id import AuthorId, RefId

class OpenAuthorCommand(Command):
    def __init__(self, context: CommandContext) -> None:
        self._context = context
        self._list_of_ref_ids: List[RefId] = []
        self._list_of_author_ids: List[int] = []

    def load(self, argument_stream: ArgumentStream) -> List[str]:
        list_of_ref_ids: List[RefId] = argument_stream.pop_list_of_ref_ids(minimum_number=1)
        ref_id: RefId
        for ref_id in list_of_ref_ids:
            if isinstance(ref_id, AuthorId):
                self._list_of_author_ids.append(ref_id.author_id)
            else:
                self._list_of_ref_ids.append(ref_id)
        return []

    def execute(self) -> None:
        list_of_tease_matches: Optional[List[query.TeaseMatch]] = None
        is_ref_id_list_reasonable: bool = True
        if self._list_of_ref_ids:
            list_of_tease_matches = try_create_list_of_tease_matches_from_ref_ids(self._context, self._list_of_ref_ids)

            if list_of_tease_matches:
                tease_match: query.TeaseMatch
                for tease_match in list_of_tease_matches:
                    if tease_match.tease.has_author():
                        author_url_for_tease: str = get_url_of_author(tease_match.tease.author_id())
                        self._context.session_config.normal_writer.writeln(f"Opening '{author_url_for_tease}'")
                        webbrowser.open(author_url_for_tease)
                    else:
                        self._context.session_config.error_writer.writeln(f"Tease id '{tease_match.tease.tease_id()}' has no known author")
            else:
                self._context.session_config.error_writer.writeln("No teases available from which to open authors")
                is_ref_id_list_reasonable = False

        if is_ref_id_list_reasonable:
            for author_id in self._list_of_author_ids:
                author_url: str = get_url_of_author(author_id)
                self._context.session_config.normal_writer.writeln(f"Opening '{author_url}'")
                webbrowser.open(author_url)

    class Help(HelpInfo):
        def __init__(self, context: CommandContext) -> None:
            self._context = context

        def get_one_line_summary(self) -> str:
            return "Opens a specified author profile in the default browser"

        def get_detailed_summary(self) -> str:
            return (
                "Arguments: <list of RefIds>\n"
                "Opens one or more author profiles in the default browser from the list of RefIds."
                " This effectively opens the link to the author profile on Milovana.\n"
                "RefIds can be an index into the list of matches such as '3', a teaseId such as"
                " '#38664', or an authorId such as '@43937'.\n"
                "Example:\r"
                "  \tOpen an author's profile for a tease by index in the match list\r"
                "  > \topenauthor 3\r"
                "Example:\r"
                "  \tOpen am author's profile for a specific teaseId\r"
                "  > \topenauthor #16830\r"
                "Example:\r"
                "  \tOpen the profile of a specific authorId\r"
                "  > \topenauthor @43937\n"
                "See also:\r"
                "  \topen, url, urlauthor"
            )
