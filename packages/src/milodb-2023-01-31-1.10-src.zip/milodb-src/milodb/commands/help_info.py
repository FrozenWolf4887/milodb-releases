from abc import ABC, abstractmethod
from milodb.command_framework.i_help_info import IHelpInfo
from milodb.commands.command_context import CommandContext

class HelpInfo(IHelpInfo, ABC):
    @abstractmethod
    def __init__(self, context: CommandContext) -> None:
        pass
