from typing import List
from milodb.command_framework.argument_stream import ArgumentStream
from milodb.commands.command import Command
from milodb.commands.command_context import CommandContext
from milodb.commands.help_info import HelpInfo

class ExitCommand(Command):
    def __init__(self, context: CommandContext) -> None:
        self._context = context

    def load(self, argument_stream: ArgumentStream) -> List[str]:
        argument_stream.fail_if_not_empty()
        return []

    def execute(self) -> None:
        self._context.quit_flag.set()

    class Help(HelpInfo):
        def __init__(self, context: CommandContext) -> None:
            self._context = context

        def get_one_line_summary(self) -> str:
            return "Exits the application"

        def get_detailed_summary(self) -> str:
            return (
                "Arguments: none\n"
                "Exits the application.\n"
                "Example:\r"
                "  > \texit\n"
            )
