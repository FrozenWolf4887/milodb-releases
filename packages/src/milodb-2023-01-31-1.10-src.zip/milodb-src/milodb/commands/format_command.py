from typing import Dict, List, Optional
from milodb.command_framework.argument_stream import ArgumentStream
from milodb.commands.command import Command
from milodb.commands.command_context import CommandContext
from milodb.commands.help_info import HelpInfo
from milodb.output.outputter import Outputter

class FormatCommand(Command):
    def __init__(self, context: CommandContext) -> None:
        self._context = context
        self._new_outputter: Optional[Outputter] = None

    def load(self, argument_stream: ArgumentStream) -> List[str]:
        map_of_outputter_name_to_object: Dict[str, Outputter] = {}
        for outputter in self._context.list_of_outputters:
            map_of_outputter_name_to_object[outputter.get_name()] = outputter
        self._new_outputter = argument_stream.pop_optional_dict_value(map_of_outputter_name_to_object)
        if self._new_outputter is not None:
            argument_stream.fail_if_not_empty()
            return []
        return self._get_list_of_outputter_names(self._context)

    def execute(self) -> None:
        if self._new_outputter:
            self._context.current_outputter = self._new_outputter
            self._context.session_config.normal_writer.writeln(f"Changed format to '{self._context.current_outputter.get_name()}'")
        else:
            self._context.session_config.normal_writer.writeln(f"Current format is '{self._context.current_outputter.get_name()}'")
            self._context.session_config.normal_writer.writeln(f"Available formats are {self._get_list_of_outputter_names(self._context)}")

    @staticmethod
    def _get_list_of_outputter_names(context: CommandContext) -> List[str]:
        return [outputter.get_name() for outputter in context.list_of_outputters]

    class Help(HelpInfo):
        def __init__(self, context: CommandContext) -> None:
            self._context = context

        def get_one_line_summary(self) -> str:
            return "Sets the formatting used in the output of commands"

        def get_detailed_summary(self) -> str:
            return (
                f"Arguments: [{'|'.join(FormatCommand._get_list_of_outputter_names(self._context))}]\n"
                "Changes the output format that is produced by commands such as list, summary,"
                " and show. Some of the formats are more suitable for copy-pasting into another"
                " application that supports that format; 'bbcode' for example is suitable to be"
                " pasted into the Milovana forums.\n"
                "When used without arguments, the current setting is shown.\n"
                "Example:\r"
                "  \tSelect the bbcode output format\r"
                "  > \tformat bbcode\r"
                "Example:\r"
                "  \tShow the current setting\r"
                "  > \tformat\n"
                "See also:\r"
                "  \tlist, summary, show, ellipsis, highlight\n"
            )
