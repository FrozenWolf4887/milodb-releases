from typing import List
from milodb.command_framework.argument_stream import ArgumentStream
from milodb.command_framework.i_command import CommandLoadError
from milodb.commands.command import Command
from milodb.commands.command_context import CommandContext
from milodb.commands.command_support import sort_tease_matches
from milodb.commands.help_info import HelpInfo
from milodb.database import PostfixQueryResult
from milodb.infix_to_postfix import PostfixError, PostfixResult, get_list_of_field_names, get_list_of_operators, get_list_of_verb_names
from milodb.infix_to_postfix import convert as convert_infix_to_postfix

HELP_FIELD_NAMES: List[str] = sorted(get_list_of_field_names())
HELP_VERB_NAMES: List[str] = sorted(get_list_of_verb_names())
HELP_OPERATORS: List[str] = sorted(get_list_of_operators())

class QueryCommand(Command):
    def __init__(self, context: CommandContext) -> None:
        self._context = context
        self._postfix_result: PostfixResult

    def load(self, argument_stream: ArgumentStream) -> List[str]:
        try:
            self._postfix_result = convert_infix_to_postfix(argument_stream)
            return self._postfix_result.list_of_expected_next_text
        except PostfixError as ex:
            raise CommandLoadError(
                ex.message,
                ex.fault_token,
                ex.list_of_expected_text) from ex

    def execute(self) -> None:
        result: PostfixQueryResult = self._context.database.run_postfix_query_chain(self._postfix_result.postfix_query_chain, 10_000_000)
        self._context.list_of_tease_matches = result.list_of_matching_teases
        sort_tease_matches(self._context)
        if self._context.list_of_tease_matches:
            self._context.current_outputter.print_list_of_teases(self._context.list_of_tease_matches)
        else:
            self._context.session_config.normal_writer.writeln("No matches")
        if result.was_max_match_count_reached:
            self._context.session_config.normal_writer.writeln()
            self._context.session_config.warning_writer.writeln(f'Limit of {result.max_match_count:,} matching items was reached')
            self._context.session_config.normal_writer.writeln(f'   Note: Search stopped with {result.total_match_count:,} matching items')
            percentage_searched: float = 0.0
            if result.queried_tease_count != 0:
                percentage_searched = 100.0 * result.queried_tease_count / result.total_tease_count
            self._context.session_config.normal_writer.writeln(f'   Note: Searched {result.queried_tease_count:,} of {result.total_tease_count:,} teases ({percentage_searched:.1f}%)')

    class Help(HelpInfo):
        def __init__(self, context: CommandContext) -> None:
            self._context = context

        def get_one_line_summary(self) -> str:
            return "Performs a deep search against metadata and text content"

        def get_detailed_summary(self) -> str:
            return (
                "Arguments: <infix query expression>\n"
                "A simple query is in the form: <field> <verb> <regex>. More complex"
                " queries can be constructed with parentheses and boolean operators.\n"
                "Fields:\r"
                f"  \t{', '.join(HELP_FIELD_NAMES)}\r"
                "Verbs:\r"
                f"  \t{', '.join(HELP_VERB_NAMES)}\r"
                "Operators:\r"
                f"  \t{', '.join(HELP_OPERATORS)}\n"
                "The 'contains' and 'is' verbs are a plain text search where 'contains' will match text"
                " anywhere within the specified field, and 'is' will match against the whole field.\n"
                "The 'match' verb is a regular expression search. For more information on regular"
                " expression syntax, see 'https://pythex.org/'. When the regular expression contains"
                " a space or groups, surround the text with single or double quotes.\n"
                "The '=', '>', '>=', '<', '<=' verbs perform value comparisons against numerical and date"
                " fields.\n"
                "The 'not' operator is used before a conditional expression to negate it, such as 'not"
                " type is eos'.\n"
                "The list of results found by the query are sorted according to the current sort"
                " criteria specified with the sort command, and shown with the list command.\n"
                'Teases that have no known authors have an implicit authorId of 0 and authorName of "",'
                " and therefore can be queried with either 'authorId = 0' or 'authorName is \"\"'\n"
                "Example:\r"
                "  \tSearch all text paragraphs for a word\r"
                "  > \tquery text contains banana\r"
                "Example:\r"
                "  \tSearch the title field\r"
                "  \tNote: Quotes are used here because of the space\r"
                '  > \tquery title contains "lexi belle"\r'
                "Example:\r"
                "  \tSearch all text paragraphs for a regular expression\r"
                "  \tNote: Quotes are used here because of the parentheses\r"
                "  > \tquery text matches '(8|eight).?ball'\r"
                "Example:\r"
                "  \tSearch for all teases over a certain rating\r"
                '  > \tquery rating >= 4.5\r'
                "Example:\r"
                "  \tSearch for all teases on and newer than a certain date\r"
                '  > \tquery date >= 2019-03-14\r'
                "Example:\r"
                "  \tPerform a search for multiple fields\r"
                "  > \tquery title matches denial.+part and rating > 4 and text contains denied\r"
                "Example:\r"
                "  \tPerform a search using parentheses\r"
                '  > \tquery (type is nyx or type is eos) and text matches "chastity.?(belt|cage)"\n'
                "See also:\r"
                "  \tlist, sort, show, summary, browse, browseall\n"
            )
