from milodb.input.default_input import DefaultInputText
from milodb.output.output_sink import OutputSink, OutputWriter

class SessionConfig:
    def __init__(self, output_sink: OutputSink, error_writer: OutputWriter, warning_writer: OutputWriter) -> None:
        self.is_highlighting_enabled: bool = True
        self.is_ellipsis_enabled: bool = True
        self.ellipsis_max_width: int = 40
        self.normal_writer: OutputSink = output_sink
        self.error_writer: OutputWriter = error_writer
        self.warning_writer: OutputWriter = warning_writer
        self.default_input_text: DefaultInputText = DefaultInputText()

    def copy(self) -> 'SessionConfig':
        session_config = SessionConfig(self.normal_writer, self.error_writer, self.warning_writer)
        session_config.is_ellipsis_enabled = self.is_ellipsis_enabled
        session_config.is_highlighting_enabled = self.is_highlighting_enabled
        session_config.ellipsis_max_width = self.ellipsis_max_width
        return session_config
