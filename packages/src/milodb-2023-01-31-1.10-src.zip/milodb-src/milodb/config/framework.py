from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional, Union

class IConfigItem(ABC):
    @property
    @abstractmethod
    def key_name(self) -> str:
        pass

    @property
    @abstractmethod
    def default_value(self) -> Union[str, Dict[Any, Any]]:
        pass

    @property
    @abstractmethod
    def parent(self) -> Optional['IConfigGroup']:
        pass

    @property
    @abstractmethod
    def full_path(self) -> str:
        pass

    @abstractmethod
    def validate_existing(self, unknown: Any) -> None:
        pass

    @abstractmethod
    def report_redundancy(self, unknown: Any) -> None:
        pass

    @abstractmethod
    def try_add_missing(self, unknown: Any) -> bool:
        pass

class IConfigLeaf(IConfigItem):
    @property
    @abstractmethod
    def default_value(self) -> str:
        pass

    @abstractmethod
    def fetch_value_or_default(self, unknown: Any) -> str:
        pass

class IConfigGroup(IConfigItem):
    @property
    @abstractmethod
    def default_value(self) -> Dict[Any, Any]:
        pass

    @abstractmethod
    def add_child(self, child: IConfigItem) -> None:
        pass

    @abstractmethod
    def try_find_child(self, key_name: str) -> Optional[IConfigItem]:
        pass

    @abstractmethod
    def try_find_child_leaf(self, key_name: str) -> Optional[IConfigLeaf]:
        pass

class ConfigLeaf(IConfigLeaf):
    def __init__(self, parent: IConfigGroup, key_name: str, default_value: str) -> None:
        self._parent: IConfigGroup = parent
        self._key_name: str = key_name
        self._default_value: str = default_value
        parent.add_child(self)

    @property
    def parent(self) -> Optional[IConfigGroup]:
        return self._parent

    @property
    def key_name(self) -> str:
        return self._key_name

    @property
    def default_value(self) -> str:
        return self._default_value

    @property
    def full_path(self) -> str:
        return f'{self._parent.full_path}/{self._key_name}'

    def validate_existing(self, unknown: Any) -> None:
        if not isinstance(unknown, str):
            print(f"Error: Config entry '{self.full_path}' is not text")

    def report_redundancy(self, unknown: Any) -> None:
        """Single item cannot have redundancy"""

    def try_add_missing(self, unknown: Any) -> bool:
        """Single item cannot add children"""
        return False

    def fetch_value_or_default(self, unknown: Any) -> str:
        group_dict: Optional[Dict[Any, Any]] = self._seek_group_dict(unknown)
        if group_dict:
            value: Any = group_dict.get(self._key_name)
            if isinstance(value, str):
                return value
        return self._default_value

    def _seek_group_dict(self, unknown: Any) -> Optional[Dict[Any, Any]]:
        group_dict: Optional[Dict[Any, Any]] = None

        if isinstance(unknown, dict):
            hierarchy: List[IConfigGroup] = []
            temp_parent: Optional[IConfigGroup] = self._parent
            while temp_parent is not None:
                hierarchy.append(temp_parent)
                temp_parent = temp_parent.parent

            while hierarchy and isinstance(unknown, dict):
                group_dict = unknown
                key_name: str = hierarchy.pop().key_name
                unknown = group_dict.get(key_name)

            if not hierarchy and isinstance(unknown, dict):
                group_dict = unknown

        return group_dict

class ConfigGroup(IConfigGroup):
    def __init__(self, parent: Optional[IConfigGroup], key_name: str) -> None:
        self._parent: Optional[IConfigGroup] = parent
        self._key_name: str = key_name
        self._list_of_children: List[IConfigItem] = []
        if parent is not None:
            parent.add_child(self)

    @property
    def parent(self) -> Optional[IConfigGroup]:
        return self._parent

    @property
    def key_name(self) -> str:
        return self._key_name

    @property
    def default_value(self) -> Dict[Any, Any]:
        group_dict: Dict[Any, Any] = {}
        child: IConfigItem
        for child in self._list_of_children:
            group_dict[child.key_name] = child.default_value
        return group_dict

    @property
    def full_path(self) -> str:
        if self._parent is not None:
            return self._parent.full_path + '/' + self._key_name
        return self._key_name

    def validate_existing(self, unknown: Any) -> None:
        if isinstance(unknown, dict):
            group_dict: Dict[Any, Any] = unknown
            child: IConfigItem
            for child in self._list_of_children:
                child_value: Any = group_dict.get(child.key_name)
                if child_value is not None:
                    child.validate_existing(child_value)
        else:
            print(f"Error: Config entry '{self.full_path}' is not a group")

    def report_redundancy(self, unknown: Any) -> None:
        if isinstance(unknown, dict):
            group_dict: Dict[Any, Any] = unknown
            key_name: Any
            value: Any
            for key_name, value in group_dict.items():
                was_found_in_schema: bool = False
                child: IConfigItem
                for child in self._list_of_children:
                    if key_name == child.key_name:
                        was_found_in_schema = True
                        child.report_redundancy(value)
                        break
                if not was_found_in_schema:
                    print(f"Warning: Config entry '{self.full_path}/{key_name}' is not recognised")

    def try_add_missing(self, unknown: Any) -> bool:
        was_anything_added: bool = False
        if isinstance(unknown, dict):
            group_dict: Dict[Any, Any] = unknown
            child: IConfigItem
            for child in self._list_of_children:
                value: Optional[Any] = group_dict.get(child.key_name)
                if value is None:
                    print(f"Added config entry '{child.full_path}'")
                    group_dict[child.key_name] = child.default_value
                    was_anything_added = True
                else:
                    was_anything_added = child.try_add_missing(value) or was_anything_added
        return was_anything_added

    def add_child(self, child: IConfigItem) -> None:
        self._list_of_children.append(child)

    def try_find_child(self, key_name: str) -> Optional[IConfigItem]:
        child: IConfigItem
        for child in self._list_of_children:
            if child.key_name == key_name:
                return child
        return None

    def try_find_child_leaf(self, key_name: str) -> Optional[IConfigLeaf]:
        child: Optional[IConfigItem] = self.try_find_child(key_name)
        if isinstance(child, IConfigLeaf):
            return child
        return None

class IConfig(ABC):
    @abstractmethod
    def get_config_value(self, config_leaf: IConfigLeaf) -> str:
        pass
