from typing import Optional
from milodb.config.config_schema import ConfigSchema
from milodb.config.framework import IConfig
from milodb.config.framework import IConfigLeaf

class HtmlConfig:
    def __init__(self, config: IConfig) -> None:
        self._config = config

    @property
    def css_file_path(self) -> str:
        return self._config.get_config_value(ConfigSchema.format_html_css_file_path)

    def try_get_colour_field(self, key: str) -> Optional[str]:
        config_leaf: Optional[IConfigLeaf] = ConfigSchema.format_html_css_colour.try_find_child_leaf(key)
        if config_leaf:
            return self._config.get_config_value(config_leaf)
        return None
