# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from dataclasses import dataclass, field
from unittest.mock import Mock
from milodb_client.commands import browse_command
from milodb_client.config.commands_config import ILaunchConfig
from milodb_client.database.tease import Tease
from milodb_client.output.format.i_html_file_writer import IHtmlFileWriter
from milodb_client.query.tease_match import TeaseMatch
from milodb_client_test.test import fake_teases
from milodb_common.command_framework.i_command import ICommandLoader
from milodb_common.output.print.i_printer import IPrinter
from milodb_common_test.commands.test_command_base import CommandTestBase
from milodb_common_test.test.strict_mock import StrictMock

_DEFAULT_LIST_OF_TEASES: list[Tease] = [
    fake_teases.TEASE_ID_1000_AUTHOR_ID_4567,
    fake_teases.TEASE_ID_1234_AUTHOR_ID_6431,
    fake_teases.TEASE_ID_5678_AUTHOR_ID_4567,
    fake_teases.TEASE_ID_2000_AUTHOR_ID_6431,
    fake_teases.TEASE_ID_8721_AUTHOR_ID_7213,
]

@dataclass
class _Args:
    list_of_teases: list[Tease] = field(default_factory=_DEFAULT_LIST_OF_TEASES.copy)
    list_of_tease_matches: list[TeaseMatch] = field(default_factory=list)
    launch_config: StrictMock = field(default_factory=lambda: StrictMock(ILaunchConfig))
    html_file_writer: StrictMock = field(default_factory=lambda: StrictMock(IHtmlFileWriter))
    normal_printer: StrictMock = field(default_factory=lambda: StrictMock(IPrinter))
    error_printer: StrictMock = field(default_factory=lambda: StrictMock(IPrinter))

class TestBrowseCommand(CommandTestBase):
    def setUp(self) -> None:
        self._args: _Args = _Args()
        return super().setUp()

    def create_command_loader(self) -> ICommandLoader:
        return browse_command.BrowseLoader(
            self._args.list_of_teases,
            self._args.list_of_tease_matches,
            self._args.launch_config,
            self._args.html_file_writer,
            self._args.normal_printer,
            self._args.error_printer,
        )

    def test_without_arguments_and_no_matches_outputs_error(self) -> None:
        self._args.error_printer.writeln = Mock()
        self.command_load_and_execute([])
        self._args.error_printer.writeln.assert_called_once_with('No teases available to browse')
        self.assert_next_text([])
