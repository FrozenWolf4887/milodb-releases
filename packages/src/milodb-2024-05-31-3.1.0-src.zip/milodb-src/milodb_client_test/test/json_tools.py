# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
import json

def load_and_prune_json_key(json_text: str, path_to_remove: str) -> dict[object, object]:
    json_root: dict[object, object] = load_json(json_text)
    prune_json_key(json_root, path_to_remove)
    return json_root

def load_and_change_json_value(json_text: str, path_to_change: str, new_value: object) -> dict[object, object]:
    json_root: dict[object, object] = load_json(json_text)
    change_json_value(json_root, path_to_change, new_value)
    return json_root

def load_and_add_json_key(json_text: str, path_to_add: str, value: object) -> dict[object, object]:
    json_root: dict[object, object] = load_json(json_text)
    add_json_key(json_root, path_to_add, value)
    return json_root

def load_and_change_json_key(json_text: str, path_to_change: str, new_key: object) -> dict[object, object]:
    json_root: dict[object, object] = load_json(json_text)
    change_json_key(json_root, path_to_change, new_key)
    return json_root

def load_json(json_text: str) -> dict[object, object]:
    try:
        json_root: object = json.loads(json_text)
    except json.JSONDecodeError as ex:
        _fail(f'TEST ERROR: Manifest is not valid JSON: {ex}')
        return {}
    if isinstance(json_root, dict):
        json_root_dict: dict[object, object] = json_root
        return json_root_dict
    _fail('TEST ERROR: Manifest root is not a JSON dictionary')
    return {}

def traverse_json_path(json_root: dict[object, object], list_of_path_groups: list[str]) -> dict[object, object]:
    json_current_dict: dict[object, object] = json_root
    path_group: str
    for path_group in list_of_path_groups:
        json_entry: object | None = json_current_dict.get(path_group)
        if json_entry is None:
            _fail(f"TEST ERROR: Bad path '{'/'.join(list_of_path_groups)}' part '{path_group}' missing")
            return {}
        if not isinstance(json_entry, dict):
            _fail(f"TEST ERROR: Bad path '{'/'.join(list_of_path_groups)}' part '{path_group}' is not a group")
            return {}
        json_current_dict = json_entry
    return json_current_dict

def prune_json_key(json_root: dict[object, object], path_to_remove: str) -> None:
    list_of_path_groups: list[str] = path_to_remove.split('/')
    path_leaf: str = list_of_path_groups.pop()
    json_group = traverse_json_path(json_root, list_of_path_groups)
    try:
        del json_group[path_leaf]
    except KeyError:
        _fail(f"TEST ERROR: Bad path '{path_to_remove}' part '{path_leaf}' missing")

_NO_SUCH_KEY: object = object()

def change_json_value(json_root: dict[object, object], path_to_change: str, new_value: object) -> None:
    list_of_path_groups: list[str] = path_to_change.split('/')
    path_leaf: str = list_of_path_groups.pop()
    json_group = traverse_json_path(json_root, list_of_path_groups)
    if json_group.get(path_leaf, _NO_SUCH_KEY) is _NO_SUCH_KEY:
        _fail(f"TEST ERROR: Bad path '{path_to_change}' part '{path_leaf}' missing")
    json_group[path_leaf] = new_value

def add_json_key(json_root: dict[object, object], path_to_change: str, value: object) -> None:
    list_of_path_groups: list[str] = path_to_change.split('/')
    path_leaf: str = list_of_path_groups.pop()
    json_group = traverse_json_path(json_root, list_of_path_groups)
    json_group[path_leaf] = value

def change_json_key(json_root: dict[object, object], path_to_change: str, new_key: object) -> None:
    list_of_path_groups: list[str] = path_to_change.split('/')
    path_leaf: str = list_of_path_groups.pop()
    json_group = traverse_json_path(json_root, list_of_path_groups)
    try:
        json_group[new_key] = json_group.pop(path_leaf)
    except KeyError:
        _fail(f"TEST ERROR: Bad path '{path_to_change}' part '{path_leaf}' missing")

def _fail(message: str) -> None:
    """Fail with an AssertionError.

    ### Raises
    - AssertionError
    """
    raise AssertionError(message)
