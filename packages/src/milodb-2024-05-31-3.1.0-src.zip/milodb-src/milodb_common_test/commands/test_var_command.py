# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from dataclasses import dataclass, field
from unittest.mock import Mock, call
from milodb_common.command_framework.i_command import ICommandLoader
from milodb_common.commands import var_command
from milodb_common.input.default_input import IDefaultInputText
from milodb_common.output.print.i_printer import IPrinter
from milodb_common.variables.i_user_variables import IPersistentUserVariables
from milodb_common_test.commands.error_messages import ErrorMessage
from milodb_common_test.commands.test_command_base import CommandTestBase
from milodb_common_test.test.strict_mock import StrictMock

COMMAND_SET: str = 'set'
COMMAND_GET: str = 'get'
COMMAND_DELETE: str = 'delete'
COMMAND_RENAME: str = 'rename'
COMMAND_COPY: str = 'copy'
COMMAND_EDIT: str = 'edit'

_DEFAULT_DICTIONARY_OF_VARIABLES: dict[str, str] = {
    'honey': 'apple',
    'badger': 'pear',
}
_DEFAULT_LIST_OF_VARIABLE_NAMES: list[str] = list(_DEFAULT_DICTIONARY_OF_VARIABLES.keys())

@dataclass
class _Args:
    user_variables: StrictMock = field(default_factory=lambda: StrictMock(IPersistentUserVariables))
    default_input_text: StrictMock = field(default_factory=lambda: StrictMock(IDefaultInputText))
    normal_printer: StrictMock = field(default_factory=lambda: StrictMock(IPrinter))
    warning_printer: StrictMock = field(default_factory=lambda: StrictMock(IPrinter))
    error_printer: StrictMock = field(default_factory=lambda: StrictMock(IPrinter))

class VarCommandTestBase(CommandTestBase):
    def setUp(self) -> None:
        self._args = _Args()
        return super().setUp()

    def create_command_loader(self) -> ICommandLoader:
        return var_command.Loader(
            self._args.user_variables,
            self._args.default_input_text,
            self._args.normal_printer,
            self._args.warning_printer,
            self._args.error_printer,
        )

class TestVarCommand(VarCommandTestBase):
    def test_without_arguments_lists_no_variables(self) -> None:
        self._args.user_variables.get_list_of_variables = Mock(return_value=[])
        self._args.normal_printer.writeln = Mock()
        self.command_load_and_execute([])
        self._args.normal_printer.writeln.assert_called_once_with('No variables available to list')

    def test_without_arguments_lists_single_variable(self) -> None:
        variables: dict[str, str] = {
            'something': 'this is a test',
        }
        self._args.user_variables.get_list_of_variables = Mock(return_value=list(variables.items()))
        self._args.normal_printer.writeln = Mock()
        self.command_load_and_execute([])
        self._args.normal_printer.writeln.assert_called_once_with('  something : this is a test')

    def test_without_arguments_lists_multiple_variables_aligned(self) -> None:
        variables: dict[str, str] = {
            'something': 'this is a test',
            'short': 'shorter variable name',
            'aLittleLonger': 'just a little longer',
        }
        self._args.user_variables.get_list_of_variables = Mock(return_value=list(variables.items()))
        self._args.normal_printer.writeln = Mock()
        self.command_load_and_execute([])
        self._args.normal_printer.writeln.assert_has_calls([
            call('  something     : this is a test'),
            call('  short         : shorter variable name'),
            call('  aLittleLonger : just a little longer'),
        ])

    def test_unknown_action_returns_failure(self) -> None:
        self.command_load(['boo'])
        self.assert_argument_error(1, ErrorMessage.INVALID, ['set', 'get', 'delete', 'rename', 'copy', 'edit'])

class TestVarSetCommandLoad(VarCommandTestBase):
    def test_without_arguments_and_no_variables_returns_failure(self) -> None:
        self._args.user_variables.get_list_of_names = Mock(return_value=[])
        self.command_load([COMMAND_SET])
        self.assert_argument_error(None, ErrorMessage.INSUFFICIENT_EXPECTING_VARIABLE, [])

    def test_without_arguments_and_some_variables_returns_failure(self) -> None:
        self._args.user_variables.get_list_of_names = Mock(return_value=_DEFAULT_LIST_OF_VARIABLE_NAMES)
        self.command_load([COMMAND_SET])
        self.assert_argument_error(None, ErrorMessage.INSUFFICIENT_EXPECTING_VARIABLE, _DEFAULT_LIST_OF_VARIABLE_NAMES)

    def test_without_value_returns_failure(self) -> None:
        self._args.user_variables.get_list_of_names = Mock(return_value=_DEFAULT_LIST_OF_VARIABLE_NAMES)
        self.command_load([COMMAND_SET, 'pear'])
        self.assert_load_error(None, 'Expected some text to set as the variable value', [])

    def test_with_prefixed_variable_name_returns_failure(self) -> None:
        self._args.user_variables.get_list_of_names = Mock(return_value=_DEFAULT_LIST_OF_VARIABLE_NAMES)
        self.command_load([COMMAND_SET, '$pear'])
        self.assert_argument_error(2, r"Variable name '$pear' does not match pattern '[\w\-\+]+'", _DEFAULT_LIST_OF_VARIABLE_NAMES)

    def test_with_bad_variable_name_returns_failure(self) -> None:
        self._args.user_variables.get_list_of_names = Mock(return_value=_DEFAULT_LIST_OF_VARIABLE_NAMES)
        self.command_load([COMMAND_SET, 'p%ear'])
        self.assert_argument_error(2, r"Variable name 'p%ear' does not match pattern '[\w\-\+]+'", _DEFAULT_LIST_OF_VARIABLE_NAMES)

class TestVarSetCommandExecute(VarCommandTestBase):
    def test_new_variable_with_value_sets_successfully(self) -> None:
        self._args.user_variables.get_list_of_names = Mock(return_value=_DEFAULT_LIST_OF_VARIABLE_NAMES)
        self._args.user_variables.set = Mock()
        self._args.user_variables.try_save = Mock(return_value=IPersistentUserVariables.SaveResult(was_successful=True, warning_message=None, error_message=None))
        self.command_load_and_execute([COMMAND_SET, 'pear'], 'something')
        self._args.user_variables.set.assert_called_once_with('pear', 'something')
        self._args.user_variables.try_save.assert_called_once()

    def test_existing_variable_with_value_sets_successfully(self) -> None:
        self._args.user_variables.get_list_of_names = Mock(return_value=_DEFAULT_LIST_OF_VARIABLE_NAMES)
        self._args.user_variables.set = Mock()
        self._args.user_variables.try_save = Mock(return_value=IPersistentUserVariables.SaveResult(was_successful=True, warning_message=None, error_message=None))
        self.command_load_and_execute([COMMAND_SET, 'honey'], 'lemon')
        self._args.user_variables.set.assert_called_once_with('honey', 'lemon')
        self._args.user_variables.try_save.assert_called_once()

    def test_variable_with_complex_name_sets_successfully(self) -> None:
        self._args.user_variables.get_list_of_names = Mock(return_value=_DEFAULT_LIST_OF_VARIABLE_NAMES)
        self._args.user_variables.set = Mock()
        self._args.user_variables.try_save = Mock(return_value=IPersistentUserVariables.SaveResult(was_successful=True, warning_message=None, error_message=None))
        self.command_load_and_execute([COMMAND_SET, '012The-Qu34ick+Br56own-F78ox+Ju9mps-Over+The-L0azy+Dog'], 'something')
        self._args.user_variables.set.assert_called_once_with('012The-Qu34ick+Br56own-F78ox+Ju9mps-Over+The-L0azy+Dog', 'something')
        self._args.user_variables.try_save.assert_called_once()

    def test_variable_with_remaining_text_sets_verbatim_but_stripped(self) -> None:
        self._args.user_variables.get_list_of_names = Mock(return_value=_DEFAULT_LIST_OF_VARIABLE_NAMES)
        self._args.user_variables.set = Mock()
        self._args.user_variables.try_save = Mock(return_value=IPersistentUserVariables.SaveResult(was_successful=True, warning_message=None, error_message=None))
        self.command_load_and_execute([COMMAND_SET, 'pear'], '  this   is " some text  ;;<> that can\'t  be tokenised  ')
        self._args.user_variables.set.assert_called_once_with('pear', 'this   is " some text  ;;<> that can\'t  be tokenised')
        self._args.user_variables.try_save.assert_called_once()

    def test_warning_on_save_failure_is_printed(self) -> None:
        self._args.user_variables.get_list_of_names = Mock(return_value=[])
        self._args.user_variables.set = Mock()
        self._args.user_variables.try_save = Mock(return_value=IPersistentUserVariables.SaveResult(was_successful=False, warning_message='this is a warning', error_message=None))
        self._args.warning_printer.writeln = Mock()
        self.command_load_and_execute([COMMAND_SET, 'pear'], 'something')
        self._args.warning_printer.writeln.assert_called_once_with('this is a warning')

    def test_error_on_save_failure_is_printed(self) -> None:
        self._args.user_variables.get_list_of_names = Mock(return_value=[])
        self._args.user_variables.set = Mock()
        self._args.user_variables.try_save = Mock(return_value=IPersistentUserVariables.SaveResult(was_successful=False, warning_message=None, error_message='this is an error'))
        self._args.error_printer.writeln = Mock()
        self.command_load_and_execute([COMMAND_SET, 'pear'], 'something')
        self._args.error_printer.writeln.assert_called_once_with('this is an error')

    def test_warning_and_error_on_save_failure_is_printed(self) -> None:
        self._args.user_variables.get_list_of_names = Mock(return_value=[])
        self._args.user_variables.set = Mock()
        self._args.user_variables.try_save = Mock(return_value=IPersistentUserVariables.SaveResult(was_successful=False, warning_message='this is a warning', error_message='this is an error'))
        self._args.warning_printer.writeln = Mock()
        self._args.error_printer.writeln = Mock()
        self.command_load_and_execute([COMMAND_SET, 'pear'], 'something')
        self._args.warning_printer.writeln.assert_called_once_with('this is a warning')
        self._args.error_printer.writeln.assert_called_once_with('this is an error')

class TestVarGetCommandLoad(VarCommandTestBase):
    def test_without_arguments_and_no_variables_returns_failure(self) -> None:
        self._args.user_variables.get_list_of_names = Mock(return_value=[])
        self.command_load([COMMAND_GET])
        self.assert_argument_error(None, ErrorMessage.INSUFFICIENT_EXPECTING_VARIABLE, [])

    def test_without_arguments_and_some_variables_returns_failure(self) -> None:
        self._args.user_variables.get_list_of_names = Mock(return_value=_DEFAULT_LIST_OF_VARIABLE_NAMES)
        self.command_load([COMMAND_GET])
        self.assert_argument_error(None, ErrorMessage.INSUFFICIENT_EXPECTING_VARIABLE, _DEFAULT_LIST_OF_VARIABLE_NAMES)

    def test_with_prefixed_variable_name_returns_failure(self) -> None:
        self._args.user_variables.get_list_of_names = Mock(return_value=_DEFAULT_LIST_OF_VARIABLE_NAMES)
        self.command_load([COMMAND_GET, '$pear'])
        self.assert_argument_error(2, r"Variable name '$pear' does not match pattern '[\w\-\+]+'", _DEFAULT_LIST_OF_VARIABLE_NAMES)

    def test_with_bad_variable_name_returns_failure(self) -> None:
        self._args.user_variables.get_list_of_names = Mock(return_value=_DEFAULT_LIST_OF_VARIABLE_NAMES)
        self.command_load([COMMAND_SET, 'p%ear'])
        self.assert_argument_error(2, r"Variable name 'p%ear' does not match pattern '[\w\-\+]+'", _DEFAULT_LIST_OF_VARIABLE_NAMES)

    def test_excessive_parameters_returns_failure(self) -> None:
        self._args.user_variables.get_list_of_names = Mock(return_value=_DEFAULT_LIST_OF_VARIABLE_NAMES)
        self.command_load([COMMAND_GET, 'pear', 'bar'])
        self.assert_argument_error(3, ErrorMessage.UNEXPECTED, [])

class TestVarGetCommandExecute(VarCommandTestBase):
    def test_existing_variable_gets_successfully(self) -> None:
        self._args.user_variables.get_list_of_names = Mock(return_value=_DEFAULT_LIST_OF_VARIABLE_NAMES)
        self._args.user_variables.try_retrieve = Mock(side_effect=_DEFAULT_DICTIONARY_OF_VARIABLES.get)
        self._args.normal_printer.writeln = Mock()
        self.command_load_and_execute([COMMAND_GET, 'badger'])
        self._args.user_variables.try_retrieve.assert_called_once_with('badger')
        self._args.normal_printer.writeln.assert_called_once_with('  badger : pear')

    def test_unknown_variable_prints_failure(self) -> None:
        self._args.user_variables.get_list_of_names = Mock(return_value=_DEFAULT_LIST_OF_VARIABLE_NAMES)
        self._args.user_variables.try_retrieve = Mock(return_value=None)
        self._args.error_printer.writeln = Mock()
        self.command_load_and_execute([COMMAND_GET, 'apple'])
        self._args.user_variables.try_retrieve.assert_called_once_with('apple')
        self._args.error_printer.writeln.assert_called_once_with("Unknown variable 'apple'")

class TestVarDeleteCommandLoad(VarCommandTestBase):
    def test_without_arguments_and_no_arguments_returns_failure(self) -> None:
        self._args.user_variables.get_list_of_names = Mock(return_value=[])
        self.command_load([COMMAND_DELETE])
        self.assert_argument_error(None, ErrorMessage.INSUFFICIENT_EXPECTING_VARIABLE, [])

    def test_without_arguments_and_some_arguments_returns_failure(self) -> None:
        self._args.user_variables.get_list_of_names = Mock(return_value=_DEFAULT_LIST_OF_VARIABLE_NAMES)
        self.command_load([COMMAND_DELETE])
        self.assert_argument_error(None, ErrorMessage.INSUFFICIENT_EXPECTING_VARIABLE, _DEFAULT_LIST_OF_VARIABLE_NAMES)

    def test_with_prefixed_variable_name_returns_failure(self) -> None:
        self._args.user_variables.get_list_of_names = Mock(return_value=_DEFAULT_LIST_OF_VARIABLE_NAMES)
        self.command_load([COMMAND_DELETE, '$pear'])
        self.assert_argument_error(2, r"Variable name '$pear' does not match pattern '[\w\-\+]+'", _DEFAULT_LIST_OF_VARIABLE_NAMES)

    def test_with_invalid_variable_name_returns_failure(self) -> None:
        self._args.user_variables.get_list_of_names = Mock(return_value=_DEFAULT_LIST_OF_VARIABLE_NAMES)
        self.command_load([COMMAND_DELETE, 'p%ear'])
        self.assert_argument_error(2, r"Variable name 'p%ear' does not match pattern '[\w\-\+]+'", _DEFAULT_LIST_OF_VARIABLE_NAMES)

    def test_excessive_parameters_returns_failure(self) -> None:
        self._args.user_variables.get_list_of_names = Mock(return_value=_DEFAULT_LIST_OF_VARIABLE_NAMES)
        self.command_load([COMMAND_DELETE, 'pear', 'bar'])
        self.assert_argument_error(3, ErrorMessage.UNEXPECTED, [])

class TestVarDeleteCommandExecute(VarCommandTestBase):
    def test_existing_variable_deletes_successfully(self) -> None:
        self._args.user_variables.get_list_of_names = Mock(return_value=_DEFAULT_LIST_OF_VARIABLE_NAMES)
        self._args.user_variables.try_delete = Mock(return_value=True)
        self._args.user_variables.try_save = Mock(return_value=IPersistentUserVariables.SaveResult(was_successful=True, warning_message=None, error_message=None))
        self.command_load_and_execute([COMMAND_DELETE, 'badger'])
        self._args.user_variables.try_delete.assert_called_once_with("badger")
        self._args.user_variables.try_save.assert_called_once()

    def test_unknown_variable_prints_failure(self) -> None:
        self._args.user_variables.get_list_of_names = Mock(return_value=_DEFAULT_LIST_OF_VARIABLE_NAMES)
        self._args.user_variables.try_delete = Mock(return_value=False)
        self._args.error_printer.writeln = Mock()
        self.command_load_and_execute([COMMAND_DELETE, 'apple'])
        self._args.error_printer.writeln.assert_called_once_with("Unknown variable 'apple'")

class TestVarRenameCommandLoad(VarCommandTestBase):
    def test_without_arguments_returns_failure(self) -> None:
        self._args.user_variables.get_list_of_names = Mock(return_value=_DEFAULT_LIST_OF_VARIABLE_NAMES)
        self.command_load([COMMAND_RENAME])
        self.assert_argument_error(None, ErrorMessage.INSUFFICIENT_EXPECTING_VARIABLE, _DEFAULT_LIST_OF_VARIABLE_NAMES)

    def test_with_single_variable_name_returns_failure(self) -> None:
        self._args.user_variables.get_list_of_names = Mock(return_value=_DEFAULT_LIST_OF_VARIABLE_NAMES)
        self.command_load([COMMAND_RENAME, 'pear'])
        self.assert_argument_error(None, ErrorMessage.INSUFFICIENT_EXPECTING_VARIABLE, [])

    def test_with_prefixed_first_variable_name_returns_failure(self) -> None:
        self._args.user_variables.get_list_of_names = Mock(return_value=_DEFAULT_LIST_OF_VARIABLE_NAMES)
        self.command_load([COMMAND_RENAME, '$pear'])
        self.assert_argument_error(2, r"Variable name '$pear' does not match pattern '[\w\-\+]+'", _DEFAULT_LIST_OF_VARIABLE_NAMES)

    def test_with_prefixed_second_variable_name_returns_failure(self) -> None:
        self._args.user_variables.get_list_of_names = Mock(return_value=_DEFAULT_LIST_OF_VARIABLE_NAMES)
        self.command_load([COMMAND_RENAME, 'pear', '$apple'])
        self.assert_argument_error(3, r"Variable name '$apple' does not match pattern '[\w\-\+]+'", [])

    def test_with_invalid_first_variable_name_returns_failure(self) -> None:
        self._args.user_variables.get_list_of_names = Mock(return_value=_DEFAULT_LIST_OF_VARIABLE_NAMES)
        self.command_load([COMMAND_RENAME, 'ma*ngo', 'pear'])
        self.assert_argument_error(2, r"Variable name 'ma*ngo' does not match pattern '[\w\-\+]+'", _DEFAULT_LIST_OF_VARIABLE_NAMES)

    def test_with_invalid_second_variable_name_returns_failure(self) -> None:
        self._args.user_variables.get_list_of_names = Mock(return_value=_DEFAULT_LIST_OF_VARIABLE_NAMES)
        self.command_load([COMMAND_RENAME, 'mango', 'p%ear'])
        self.assert_argument_error(3, r"Variable name 'p%ear' does not match pattern '[\w\-\+]+'", [])

    def test_excessive_parameters_returns_failure(self) -> None:
        self._args.user_variables.get_list_of_names = Mock(return_value=_DEFAULT_LIST_OF_VARIABLE_NAMES)
        self.command_load([COMMAND_RENAME, 'pear', 'bar', 'foo'])
        self.assert_argument_error(4, ErrorMessage.UNEXPECTED, [])

class TestVarRenameCommandExecute(VarCommandTestBase):
    def test_existing_variable_renames_to_new_name_successfully(self) -> None:
        self._args.user_variables.get_list_of_names = Mock(return_value=_DEFAULT_LIST_OF_VARIABLE_NAMES)
        self._args.user_variables.try_retrieve = Mock(side_effect=_DEFAULT_DICTIONARY_OF_VARIABLES.get)
        self._args.user_variables.set = Mock()
        self._args.user_variables.try_delete = Mock(return_value=True)
        self._args.user_variables.try_save = Mock()
        self.command_load_and_execute([COMMAND_RENAME, 'badger', 'tree'])
        self._args.user_variables.try_retrieve.assert_has_calls([call('badger'), call('tree')])
        self._args.user_variables.set.assert_called_once_with('tree', 'pear')
        self._args.user_variables.try_delete.assert_called_once_with('badger')
        self._args.user_variables.try_save.assert_called_once()

    def test_unknown_variable_prints_failure(self) -> None:
        self._args.user_variables.get_list_of_names = Mock(return_value=_DEFAULT_LIST_OF_VARIABLE_NAMES)
        self._args.user_variables.try_retrieve = Mock(return_value=None)
        self._args.error_printer.writeln = Mock()
        self.command_load_and_execute([COMMAND_RENAME, 'apple', 'tree'])
        self._args.error_printer.writeln.assert_called_once_with("Unknown variable 'apple'")

    def test_existing_variable_rename_fails_when_new_name_exists(self) -> None:
        self._args.user_variables.get_list_of_names = Mock(return_value=_DEFAULT_LIST_OF_VARIABLE_NAMES)
        self._args.user_variables.try_retrieve = Mock(side_effect=_DEFAULT_DICTIONARY_OF_VARIABLES.get)
        self._args.error_printer.writeln = Mock()
        self.command_load_and_execute([COMMAND_RENAME, 'honey', 'badger'])
        self._args.error_printer.writeln.assert_called_once_with("Cannot rename variable 'honey' to 'badger' because 'badger' already exists")

    def test_existing_variable_rename_fails_when_new_name_is_the_same(self) -> None:
        self._args.user_variables.get_list_of_names = Mock(return_value=_DEFAULT_LIST_OF_VARIABLE_NAMES)
        self._args.user_variables.try_retrieve = Mock(side_effect=_DEFAULT_DICTIONARY_OF_VARIABLES.get)
        self._args.error_printer.writeln = Mock()
        self.command_load_and_execute([COMMAND_RENAME, 'honey', 'honey'])
        self._args.error_printer.writeln.assert_called_once_with("Variable 'honey' cannot be renamed to itself")

class TestVarCopyCommandLoad(VarCommandTestBase):
    def test_without_arguments_returns_failure(self) -> None:
        self._args.user_variables.get_list_of_names = Mock(return_value=_DEFAULT_LIST_OF_VARIABLE_NAMES)
        self.command_load([COMMAND_COPY])
        self.assert_argument_error(None, ErrorMessage.INSUFFICIENT_EXPECTING_VARIABLE, _DEFAULT_LIST_OF_VARIABLE_NAMES)

    def test_with_single_variable_name_returns_failure(self) -> None:
        self._args.user_variables.get_list_of_names = Mock(return_value=_DEFAULT_LIST_OF_VARIABLE_NAMES)
        self.command_load([COMMAND_COPY, 'pear'])
        self.assert_argument_error(None, ErrorMessage.INSUFFICIENT_EXPECTING_VARIABLE, [])

    def test_with_prefixed_first_variable_name_returns_failure(self) -> None:
        self._args.user_variables.get_list_of_names = Mock(return_value=_DEFAULT_LIST_OF_VARIABLE_NAMES)
        self.command_load([COMMAND_COPY, '$pear', 'apple'])
        self.assert_argument_error(2, r"Variable name '$pear' does not match pattern '[\w\-\+]+'", _DEFAULT_LIST_OF_VARIABLE_NAMES)

    def test_with_prefixed_second_variable_name_returns_failure(self) -> None:
        self._args.user_variables.get_list_of_names = Mock(return_value=_DEFAULT_LIST_OF_VARIABLE_NAMES)
        self.command_load([COMMAND_COPY, 'pear', '$apple'])
        self.assert_argument_error(3, r"Variable name '$apple' does not match pattern '[\w\-\+]+'", [])

    def test_with_invalid_first_variable_name_returns_failure(self) -> None:
        self._args.user_variables.get_list_of_names = Mock(return_value=_DEFAULT_LIST_OF_VARIABLE_NAMES)
        self.command_load([COMMAND_COPY, 'pe*ar', 'apple'])
        self.assert_argument_error(2, r"Variable name 'pe*ar' does not match pattern '[\w\-\+]+'", _DEFAULT_LIST_OF_VARIABLE_NAMES)

    def test_with_invalid_second_variable_name_returns_failure(self) -> None:
        self._args.user_variables.get_list_of_names = Mock(return_value=_DEFAULT_LIST_OF_VARIABLE_NAMES)
        self.command_load([COMMAND_COPY, 'pear', 'appl&e'])
        self.assert_argument_error(3, r"Variable name 'appl&e' does not match pattern '[\w\-\+]+'", [])

    def test_excessive_parameters_returns_failure(self) -> None:
        self._args.user_variables.get_list_of_names = Mock(return_value=_DEFAULT_LIST_OF_VARIABLE_NAMES)
        self.command_load([COMMAND_COPY, 'pear', 'bar', 'foo'])
        self.assert_argument_error(4, ErrorMessage.UNEXPECTED, [])

class TestVarCopyCommandExecute(VarCommandTestBase):
    def test_existing_variable_copies_to_new_name_successfully(self) -> None:
        self._args.user_variables.get_list_of_names = Mock(return_value=_DEFAULT_LIST_OF_VARIABLE_NAMES)
        self._args.user_variables.try_retrieve = Mock(side_effect=_DEFAULT_DICTIONARY_OF_VARIABLES.get)
        self._args.user_variables.set = Mock()
        self._args.user_variables.try_delete = Mock(return_value=True)
        self._args.user_variables.try_save = Mock()
        self.command_load_and_execute([COMMAND_COPY, 'badger', 'tree'])
        self._args.user_variables.try_retrieve.assert_has_calls([call('badger'), call('tree')])
        self._args.user_variables.set.assert_called_once_with('tree', 'pear')
        self._args.user_variables.try_save.assert_called_once()
        self.assert_next_text([])

    def test_unknown_variable_prints_failure(self) -> None:
        self._args.user_variables.get_list_of_names = Mock(return_value=_DEFAULT_LIST_OF_VARIABLE_NAMES)
        self._args.user_variables.try_retrieve = Mock(side_effect=_DEFAULT_DICTIONARY_OF_VARIABLES.get)
        self._args.error_printer.writeln = Mock()
        self.command_load_and_execute([COMMAND_COPY, 'apple', 'tree'])
        self._args.error_printer.writeln.assert_called_once_with("Unknown variable 'apple'")
        self.assert_next_text([])

    def test_existing_variable_rename_fails_when_new_name_exists(self) -> None:
        self._args.user_variables.get_list_of_names = Mock(return_value=_DEFAULT_LIST_OF_VARIABLE_NAMES)
        self._args.user_variables.try_retrieve = Mock(side_effect=_DEFAULT_DICTIONARY_OF_VARIABLES.get)
        self._args.error_printer.writeln = Mock()
        self.command_load_and_execute([COMMAND_COPY, 'honey', 'badger'])
        self._args.error_printer.writeln.assert_called_once_with("Cannot copy variable 'honey' to 'badger' because 'badger' already exists")
        self.assert_next_text([])

    def test_existing_variable_rename_fails_when_new_name_is_the_same(self) -> None:
        self._args.user_variables.get_list_of_names = Mock(return_value=_DEFAULT_LIST_OF_VARIABLE_NAMES)
        self._args.user_variables.try_retrieve = Mock(side_effect=_DEFAULT_DICTIONARY_OF_VARIABLES.get)
        self._args.error_printer.writeln = Mock()
        self.command_load_and_execute([COMMAND_COPY, 'honey', 'honey'])
        self._args.error_printer.writeln.assert_called_once_with("Variable 'honey' cannot be copied to itself")
        self.assert_next_text([])

class TestVarEditCommandLoad(VarCommandTestBase):
    def test_without_arguments_returns_failure(self) -> None:
        self._args.user_variables.get_list_of_names = Mock(return_value=_DEFAULT_LIST_OF_VARIABLE_NAMES)
        self.command_load([COMMAND_EDIT])
        self.assert_argument_error(None, ErrorMessage.INSUFFICIENT_EXPECTING_VARIABLE, _DEFAULT_LIST_OF_VARIABLE_NAMES)

    def test_with_prefixed_variable_name_returns_failure(self) -> None:
        self._args.user_variables.get_list_of_names = Mock(return_value=_DEFAULT_LIST_OF_VARIABLE_NAMES)
        self.command_load([COMMAND_EDIT, '$pear'])
        self.assert_argument_error(2, r"Variable name '$pear' does not match pattern '[\w\-\+]+'", _DEFAULT_LIST_OF_VARIABLE_NAMES)

    def test_with_invalid_variable_name_returns_failure(self) -> None:
        self._args.user_variables.get_list_of_names = Mock(return_value=_DEFAULT_LIST_OF_VARIABLE_NAMES)
        self.command_load([COMMAND_EDIT, 'pear#'])
        self.assert_argument_error(2, r"Variable name 'pear#' does not match pattern '[\w\-\+]+'", _DEFAULT_LIST_OF_VARIABLE_NAMES)

    def test_excessive_parameters_returns_failure(self) -> None:
        self._args.user_variables.get_list_of_names = Mock(return_value=_DEFAULT_LIST_OF_VARIABLE_NAMES)
        self.command_load([COMMAND_EDIT, 'pear', 'bar'])
        self.assert_argument_error(3, ErrorMessage.UNEXPECTED, [])

class TestVarEditCommandExecute(VarCommandTestBase):
    def test_existing_variable_edits_successfully(self) -> None:
        self._args.user_variables.get_list_of_names = Mock(return_value=_DEFAULT_LIST_OF_VARIABLE_NAMES)
        self._args.user_variables.try_retrieve = Mock(side_effect=_DEFAULT_DICTIONARY_OF_VARIABLES.get)
        self._args.default_input_text.set = Mock()
        self.command_load_and_execute([COMMAND_EDIT, 'badger'])
        self._args.default_input_text.set.assert_called_once_with('var set badger pear')
        self.assert_next_text([])

    def test_unknown_variable_prints_failure(self) -> None:
        self._args.user_variables.get_list_of_names = Mock(return_value=_DEFAULT_LIST_OF_VARIABLE_NAMES)
        self._args.user_variables.try_retrieve = Mock(side_effect=_DEFAULT_DICTIONARY_OF_VARIABLES.get)
        self._args.error_printer.writeln = Mock()
        self.command_load_and_execute([COMMAND_EDIT, 'apple'])
        self._args.error_printer.writeln.assert_called_once_with("Unknown variable 'apple'")
        self.assert_next_text([])
