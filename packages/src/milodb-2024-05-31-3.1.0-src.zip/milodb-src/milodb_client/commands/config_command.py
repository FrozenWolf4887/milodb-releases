# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from typing import TYPE_CHECKING
from milodb_client.config.config_schema import CONFIG_SCHEMA
from milodb_client.config.framework import IConfig, IConfigGroup, IConfigLeaf
from milodb_common.command_framework.argument_stream import ArgumentStream
from milodb_common.command_framework.candidate_text import CandidateText
from milodb_common.command_framework.i_command import ICommand, ICommandLoader
from milodb_common.command_framework.i_help_info import IHelpInfo
from milodb_common.output.print.i_printer import IPrinter
from milodb_common.parser.token import Token
if TYPE_CHECKING:
    from collections.abc import Callable

_PATH_DIVIDER_CHAR: str = '/'

class Loader(ICommandLoader):
    def __init__(self, config: IConfig, normal_printer: IPrinter) -> None:
        self._config: IConfig = config
        self._normal_printer: IPrinter = normal_printer

    def load(self, argument_stream: ArgumentStream) -> ICommandLoader.Result:
        map_of_action_to_subcommand_loader: dict[str, Callable[[], ICommandLoader]] = {
            'get': lambda: _LoaderGet(self._config, self._normal_printer),
        }
        subcommand: ICommandLoader = argument_stream.pop_dict_value(map_of_action_to_subcommand_loader)()
        return subcommand.load(argument_stream)

class _LoaderGet(ICommandLoader):
    def __init__(self, config: IConfig, normal_printer: IPrinter) -> None:
        self._config: IConfig = config
        self._normal_printer: IPrinter = normal_printer
        self._current_group: IConfigGroup = CONFIG_SCHEMA
        self._leaf_to_print: IConfigLeaf | None = None
        self._is_on_path_divider: bool = False

    def load(self, argument_stream: ArgumentStream) -> ICommandLoader.Result:
        argument_stream.set_keep_delimiters(_PATH_DIVIDER_CHAR)
        argument_stream.for_each(argument_stream.pop_optional_token, self._traverse_config_path)
        argument_stream.fail_if_not_empty()
        return ICommandLoader.Result(
            ExecutorGet(self._config, self._current_group, self._leaf_to_print, self._normal_printer),
            _get_list_of_candidate_text_for_group(self._current_group) if self._leaf_to_print else [])

    def _traverse_config_path(self, token: Token) -> bool:
        if self._is_on_path_divider:
            if token.text != _PATH_DIVIDER_CHAR:
                msg = f"Expected path divider '{_PATH_DIVIDER_CHAR}' after '{self._current_group.full_path}'"
                raise ICommandLoader.Error(msg, token, [CandidateText(_PATH_DIVIDER_CHAR, '')])
            self._is_on_path_divider = False
            return True

        name_of_group_or_leaf: str = token.text.strip()
        leaf: IConfigLeaf | None = self._current_group.try_find_child_leaf(name_of_group_or_leaf)
        if leaf:
            self._leaf_to_print = leaf
            return False

        group: IConfigGroup | None = self._current_group.try_find_child_group(name_of_group_or_leaf)
        if group:
            self._current_group = group
            self._is_on_path_divider = True
        else:
            msg = f"Unrecognised config group or leaf '{name_of_group_or_leaf}' within '{self._current_group.full_path}'"
            raise ICommandLoader.Error(msg, token, _get_list_of_candidate_text_for_group(self._current_group))

        return True

class ExecutorGet(ICommand):
    def __init__(self, config: IConfig, group: IConfigGroup, leaf: IConfigLeaf | None, normal_printer: IPrinter) -> None:
        self._config: IConfig = config
        self._group: IConfigGroup = group
        self._leaf: IConfigLeaf | None = leaf
        self._normal_printer: IPrinter = normal_printer

    def execute(self) -> None:
        self._print_item(self._group, self._leaf)

    def _print_item(self, group: IConfigGroup, leaf: IConfigLeaf | None) -> None:
        if leaf:
            self._normal_printer.writeln(f" Leaf: {leaf.full_path} = '{leaf.fetch_value_or_default(self._config)}'")
        else:
            self._normal_printer.writeln(f'Group: {group.full_path}')
            child_leaf: IConfigLeaf
            for child_leaf in group.list_of_child_leaves:
                self._print_item(group, child_leaf)
            child_group: IConfigGroup
            for child_group in group.list_of_child_groups:
                self._print_item(child_group, None)

def _get_list_of_candidate_text_for_group(group: IConfigGroup) -> list[CandidateText]:
    list_of_candidate_text: list[CandidateText] = [
        CandidateText(child_group.key_name, _PATH_DIVIDER_CHAR) for child_group in group.list_of_child_groups
    ]
    list_of_candidate_text.extend(
        CandidateText(leaf.key_name, ' ') for leaf in group.list_of_child_leaves
    )
    return list_of_candidate_text

class Help(IHelpInfo):
    def get_one_line_summary(self) -> str:
        return "Views and edits configuration"

    def get_detailed_summary(self) -> str:
        return (
            "Arguments: get <path to config item>\n"
        )
