# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from milodb_client.commands.database_support import try_create_list_of_tease_matches_from_ref_ids
from milodb_client.commands.launcher import launch
from milodb_client.config.commands_config import ILaunchConfig
from milodb_client.config.config_schema import CONFIG_SCHEMA
from milodb_client.database.tease import Tease
from milodb_client.output.support import get_url_of_author
from milodb_client.query.tease_match import TeaseMatch
from milodb_common.command_framework.argument_stream import ArgumentStream
from milodb_common.command_framework.i_command import ICommand, ICommandLoader
from milodb_common.command_framework.i_help_info import IHelpInfo
from milodb_common.command_framework.ref_id import AuthorId, RefId
from milodb_common.commands import enums
from milodb_common.output.print.i_printer import IPrinter

_CONFIG_HELP_TEXT: str = (
    "Config:\r"
    f"  \t{CONFIG_SCHEMA.commands.open.launch_option.full_path}\r"
    "    \tDetermines how the webbrowser is launched to open the links. The options"
    f" are {enums.lowercase_names(CONFIG_SCHEMA.commands.open.launch_option.enum_class)}.\r"
    f"  \t{CONFIG_SCHEMA.commands.open.custom_launch_command.full_path}\r"
    f"    \tWhen '{CONFIG_SCHEMA.commands.open.launch_option.key_name}' is set to"
    f" '{CONFIG_SCHEMA.commands.open.launch_option.enum_class.CUSTOM.name.lower()}'"
    " this specifies the custom command to be executed where the following symbol can be"
    " specified:\r"
    "      $u  \tURI to the generated file"
)

class Loader(ICommandLoader):
    def __init__(self, list_of_teases: list[Tease], list_of_tease_matches: list[TeaseMatch], launch_config: ILaunchConfig, normal_printer: IPrinter, error_printer: IPrinter) -> None:
        self._list_of_teases: list[Tease] = list_of_teases
        self._list_of_tease_matches: list[TeaseMatch] = list_of_tease_matches
        self._launch_config: ILaunchConfig = launch_config
        self._normal_printer: IPrinter = normal_printer
        self._error_printer: IPrinter = error_printer
        self._list_of_ref_ids: list[RefId] = []
        self._list_of_author_ids: list[int] = []

    def load(self, argument_stream: ArgumentStream) -> ICommandLoader.Result:
        list_of_ref_ids: list[RefId] = []
        list_of_author_ids: list[int] = []

        ref_id: RefId
        for ref_id in ArgumentStream.pop_minimum_list(1, argument_stream.pop_ref_id, argument_stream.pop_optional_ref_id):
            if isinstance(ref_id, AuthorId):
                list_of_author_ids.append(ref_id.author_id)
            else:
                list_of_ref_ids.append(ref_id)

        return ICommandLoader.Result(
            Executor(
                list_of_ref_ids,
                list_of_author_ids,
                self._list_of_teases,
                self._list_of_tease_matches,
                self._launch_config,
                self._normal_printer,
                self._error_printer),
            [])

class Executor(ICommand):
    def __init__(self, list_of_ref_ids: list[RefId], list_of_author_ids: list[int], list_of_teases: list[Tease], list_of_tease_matches: list[TeaseMatch], launch_config: ILaunchConfig, normal_printer: IPrinter, error_printer: IPrinter) -> None:
        self._list_of_ref_ids: list[RefId] = list_of_ref_ids
        self._list_of_author_ids: list[int] = list_of_author_ids
        self._list_of_teases: list[Tease] = list_of_teases
        self._list_of_tease_matches: list[TeaseMatch] = list_of_tease_matches
        self._launch_config: ILaunchConfig = launch_config
        self._normal_printer: IPrinter = normal_printer
        self._error_printer: IPrinter = error_printer

    def execute(self) -> None:
        list_of_tease_matches: list[TeaseMatch] | None = None
        is_ref_id_list_reasonable: bool = True
        if self._list_of_ref_ids:
            list_of_tease_matches = try_create_list_of_tease_matches_from_ref_ids(self._list_of_teases, self._list_of_tease_matches, self._list_of_ref_ids, self._error_printer)

            if list_of_tease_matches:
                tease_match: TeaseMatch
                for tease_match in list_of_tease_matches:
                    if tease_match.tease.has_author():
                        author_url_for_tease: str = get_url_of_author(tease_match.tease.author_id())
                        launch(self._launch_config, None, author_url_for_tease, self._normal_printer)
                    else:
                        self._error_printer.writeln(f"Tease id '{tease_match.tease.tease_id()}' has no known author")
            else:
                self._error_printer.writeln("No teases available from which to open authors")
                is_ref_id_list_reasonable = False

        if is_ref_id_list_reasonable:
            for author_id in self._list_of_author_ids:
                author_url: str = get_url_of_author(author_id)
                launch(self._launch_config, None, author_url, self._normal_printer)

class Help(IHelpInfo):
    def get_one_line_summary(self) -> str:
        return "Opens a specified author profile in the default browser"

    def get_detailed_summary(self) -> str:
        return (
            "Arguments: <list of RefIds>\n"
            "Opens one or more author profiles in the default browser from the list of RefIds."
            " This effectively opens the link to the author profile on Milovana.\n"
            "RefIds can be an index into the list of matches such as '3', a teaseId such as"
            " '#38664', or an authorId such as '@43937'.\n"
            f"{_CONFIG_HELP_TEXT}\n"
            "Example:\r"
            "  \tOpen an author's profile for a tease by index in the match list\r"
            "  > \topenauthor 3\r"
            "Example:\r"
            "  \tOpen am author's profile for a specific teaseId\r"
            "  > \topenauthor #16830\r"
            "Example:\r"
            "  \tOpen the profile of a specific authorId\r"
            "  > \topenauthor @43937\n"
            "See also:\r"
            "  \topen, url, urlauthor"
        )
