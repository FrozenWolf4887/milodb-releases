# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from milodb_common.command_framework.argument_stream import ArgumentStream
from milodb_common.command_framework.candidate_text import CandidateText
from milodb_common.command_framework.i_command import ICommand, ICommandLoader
from milodb_common.command_framework.i_help_info import IHelpInfo
from milodb_common.commands import enums
from milodb_common.commands.enums import OnOrOff
from milodb_common.datum.ref_datum import RefDatum
from milodb_common.output.print.i_printer import IPrinter

class Loader(ICommandLoader):
    def __init__(self, ref_use_highlighting: RefDatum[bool], normal_printer: IPrinter) -> None:
        self._ref_use_highlighting: RefDatum[bool] = ref_use_highlighting
        self._normal_printer: IPrinter = normal_printer

    def load(self, argument_stream: ArgumentStream) -> ICommandLoader.Result:
        new_use_highlighting: OnOrOff | None = argument_stream.pop_optional_enum(OnOrOff)
        if new_use_highlighting is not None:
            argument_stream.fail_if_not_empty()
            return ICommandLoader.Result(ExecutorChangeHighlight(new_use_highlighting, self._ref_use_highlighting, self._normal_printer), [])
        return ICommandLoader.Result(
            ExecutorPrintCurrentHighlight(self._normal_printer, use_highlighting=self._ref_use_highlighting.get()),
            CandidateText.space_delimited_list(enums.lowercase_names(OnOrOff)))

class ExecutorPrintCurrentHighlight(ICommand):
    def __init__(self, normal_printer: IPrinter, *, use_highlighting: bool) -> None:
        self._use_highlighting: bool = use_highlighting
        self._normal_printer: IPrinter = normal_printer

    def execute(self) -> None:
        self._normal_printer.writeln(f"Current highlighting is '{OnOrOff(self._use_highlighting).name.lower()}'")
        self._normal_printer.writeln(f"Available options are {enums.lowercase_names(OnOrOff)}")

class ExecutorChangeHighlight(ICommand):
    def __init__(self, new_use_highlighting: OnOrOff, ref_use_highlighting: RefDatum[bool], normal_printer: IPrinter) -> None:
        self._new_use_highlighting: OnOrOff = new_use_highlighting
        self._ref_use_highlighting: RefDatum[bool] = ref_use_highlighting
        self._normal_printer: IPrinter = normal_printer

    def execute(self) -> None:
        self._ref_use_highlighting.set(self._new_use_highlighting.value)
        self._normal_printer.writeln(f"Changed highlighting to '{self._new_use_highlighting.name.lower()}'")

class Help(IHelpInfo):
    def get_one_line_summary(self) -> str:
        return "Sets whether text matches are highlighted in the output"

    def get_detailed_summary(self) -> str:
        return (
            f"Arguments: [{'|'.join(enums.lowercase_names(OnOrOff))}]\n"
            "Enables or disables the highlighting of matching text in fields and paragraphs.\n"
            "When used without arguments, the current setting is shown.\n"
            "Highlighting will only be shown on the console when a suitable output format has"
            " been selected with the format command.\n"
            "Example:\r"
            "  \tTurn off highlighting\r"
            "  > \thighlight off\r"
            "Example:\r"
            "  \tShow the current setting\r"
            "  > \thighlight\n"
            "See also:\r"
            "  \tlist, show, browse, browseall, ellipsis, format, pagerefs\n"
        )
