# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from milodb_common.command_framework.argument_stream import ArgumentStream
from milodb_common.command_framework.candidate_text import CandidateText
from milodb_common.command_framework.i_command import ICommand, ICommandLoader
from milodb_common.command_framework.i_help_info import IHelpInfo
from milodb_common.commands import enums
from milodb_common.commands.enums import OnOrOff
from milodb_common.datum.ref_datum import RefDatum
from milodb_common.output.print.i_printer import IPrinter

class Loader(ICommandLoader):
    def __init__(self, ref_use_ellipsis: RefDatum[bool], normal_printer: IPrinter) -> None:
        self._ref_use_ellipsis: RefDatum[bool] = ref_use_ellipsis
        self._normal_printer: IPrinter = normal_printer

    def load(self, argument_stream: ArgumentStream) -> ICommandLoader.Result:
        new_ellipsis: OnOrOff | None = argument_stream.pop_optional_enum(OnOrOff)
        if new_ellipsis is not None:
            argument_stream.fail_if_not_empty()
            return ICommandLoader.Result(ExecutorChangeEllipsis(new_ellipsis, self._ref_use_ellipsis, self._normal_printer), [])
        return ICommandLoader.Result(
            ExecutorPrintCurrentEllipsis(self._normal_printer, use_ellipsis=self._ref_use_ellipsis.get()),
            CandidateText.space_delimited_list(enums.lowercase_names(OnOrOff)))

class ExecutorPrintCurrentEllipsis(ICommand):
    def __init__(self, normal_printer: IPrinter, *, use_ellipsis: bool) -> None:
        self._use_ellipsis: bool = use_ellipsis
        self._normal_printer: IPrinter = normal_printer

    def execute(self) -> None:
        self._normal_printer.writeln(f"Current ellipsis mode is '{OnOrOff(self._use_ellipsis).name.lower()}'")
        self._normal_printer.writeln(f"Available options are {enums.lowercase_names(OnOrOff)}")

class ExecutorChangeEllipsis(ICommand):
    def __init__(self, new_use_ellipsis: OnOrOff, ref_use_ellipsis: RefDatum[bool], normal_printer: IPrinter) -> None:
        self._new_use_ellipsis: OnOrOff = new_use_ellipsis
        self._ref_use_ellipsis: RefDatum[bool] = ref_use_ellipsis
        self._normal_printer: IPrinter = normal_printer

    def execute(self) -> None:
        self._ref_use_ellipsis.set(self._new_use_ellipsis.value)
        self._normal_printer.writeln(f"Changed ellipsis mode to '{self._new_use_ellipsis.name.lower()}'")

class Help(IHelpInfo):
    def get_one_line_summary(self) -> str:
        return "Sets whether matching text paragraphs are abbreviated with an ellipsis"

    def get_detailed_summary(self) -> str:
        return (
            f"Arguments: [{'|'.join(enums.lowercase_names(OnOrOff))}]\n"
            "Enables or disables the abbreviation for text in paragraph matches. Abbreviation"
            " is typically shown with the ellipsis character '\u2026'.\n"
            "When used without arguments, the current setting is shown.\n"
            "Example:\r"
            "  \tTurn off text abbreviation\r"
            "  > \tellipsis off\r"
            "Example:\r"
            "  \tShow the current setting\r"
            "  > \tellipsis\n"
            "See also:\r"
            "  \tshow, browse, format, highlight, pagerefs\n"
        )
