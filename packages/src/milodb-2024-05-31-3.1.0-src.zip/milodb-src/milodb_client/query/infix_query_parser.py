# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from abc import ABC, abstractmethod
from dataclasses import dataclass
from milodb_client.query.field_verb import IFieldVerb
from milodb_client.query.query import IQuery
from milodb_client.query.syntax import MAP_OF_BINARY_OPERATORS_TO_QUERY_CLASS, MAP_OF_TEASE_FIELDNAME_TO_VERBS, MAP_OF_UNARY_OPERATORS_TO_QUERY_CLASS
from milodb_common.command_framework.argument_stream import ArgumentStream
from milodb_common.command_framework.candidate_text import CandidateText
from milodb_common.parser.token import Token

@dataclass
class InfixError(Exception):
    message: str
    fault_token: Token | None
    list_of_candidate_text: list[CandidateText]

@dataclass
class PostfixQuery:
    query_chain: list[IQuery]
    list_of_candidate_text: list[CandidateText]

class IInfixQueryParser(ABC):
    @abstractmethod
    def convert_to_postfix(self, argument_stream: ArgumentStream) -> PostfixQuery:
        pass

class InfixQueryParser(IInfixQueryParser):
    def convert_to_postfix(self, argument_stream: ArgumentStream) -> PostfixQuery:
        return _InfixQueryParserProcessor(argument_stream).get_result()

class _InfixQueryParserProcessor:
    def __init__(self, argument_stream: ArgumentStream) -> None:
        self._argument_stream: ArgumentStream = argument_stream
        self._stack_of_operators: list[IQuery | None] = []
        self._expecting_query: bool = True
        self._expecting_verb_list: list[str] | None = None
        self._expecting_binary_operator: bool = False
        self._expecting_unary_operator: bool = True
        self._expecting_open: bool = True
        self._expecting_close: bool = False
        self._postfix_query_chain: list[IQuery] = []

        self._process_queue_of_tokens()

    def get_result(self) -> PostfixQuery:
        return PostfixQuery(self._postfix_query_chain, self._get_list_of_candidate_text())

    def _get_list_of_candidate_text(self) -> list[CandidateText]:
        list_of_candidate_text: list[CandidateText] = []
        if self._expecting_query:
            list_of_candidate_text.extend(CandidateText.space_delimited_list(MAP_OF_TEASE_FIELDNAME_TO_VERBS.keys()))
        if self._expecting_binary_operator:
            list_of_candidate_text.extend(CandidateText.space_delimited_list(MAP_OF_BINARY_OPERATORS_TO_QUERY_CLASS.keys()))
        if self._expecting_unary_operator:
            list_of_candidate_text.extend(CandidateText.space_delimited_list(MAP_OF_UNARY_OPERATORS_TO_QUERY_CLASS.keys()))
        if self._expecting_verb_list:
            list_of_candidate_text.extend(CandidateText.space_delimited_list(self._expecting_verb_list))
        if self._expecting_open:
            list_of_candidate_text.append(CandidateText('(', ''))
        if self._expecting_close:
            list_of_candidate_text.append(CandidateText(')', ''))
        return list_of_candidate_text

    def _process_queue_of_tokens(self) -> None:
        ArgumentStream.for_each(self._argument_stream.pop_optional_token, self._process_token)

        if self._expecting_query:
            msg = 'Unexpected end of input when expecting a query'
            raise InfixError(msg, None, self._get_list_of_candidate_text())

        while self._stack_of_operators:
            the_operator: IQuery | None = self._stack_of_operators.pop()
            if the_operator:
                self._postfix_query_chain.append(the_operator)
            else:
                msg = 'No matching closing parenthesis for opening parenthesis'
                raise InfixError(msg, None, self._get_list_of_candidate_text())

    def _process_token(self, token: Token) -> bool:
        if not (self._try_process_query_field(token) or
                self._try_process_binary_operator(token) or
                self._try_process_unary_operator(token) or
                self._try_process_parenthesis(token)):
            msg = 'Unknown field name or operator'
            raise InfixError(msg, token, self._get_list_of_candidate_text())
        return True

    def _try_process_query_field(self, token: Token) -> bool:
        verb_dictionary: dict[str, IFieldVerb] | None = MAP_OF_TEASE_FIELDNAME_TO_VERBS.get(token.text)
        if verb_dictionary:
            if not self._expecting_query:
                msg = 'Not expecting field query'
                raise InfixError(msg, token, self._get_list_of_candidate_text())
            self._process_query_field(token, verb_dictionary)
            return True
        return False

    def _try_process_binary_operator(self, token: Token) -> bool:
        query_class: type[IQuery] | None = MAP_OF_BINARY_OPERATORS_TO_QUERY_CLASS.get(token.text)
        if query_class:
            if not self._expecting_binary_operator:
                msg = 'Not expecting binary operator'
                raise InfixError(msg, token, self._get_list_of_candidate_text())
            self._process_binary_operator(token, query_class)
            return True
        return False

    def _try_process_unary_operator(self, token: Token) -> bool:
        query_class: type[IQuery] | None = MAP_OF_UNARY_OPERATORS_TO_QUERY_CLASS.get(token.text)
        if query_class:
            if not self._expecting_unary_operator:
                msg = 'Not expecting unary operator'
                raise InfixError(msg, token, self._get_list_of_candidate_text())
            self._process_unary_operator(token, query_class)
            return True
        return False

    def _try_process_parenthesis(self, token: Token) -> bool:
        token_text = token.text
        if token_text == '(':
            if not self._expecting_open:
                msg = 'Not expecting opening parenthesis'
                raise InfixError(msg, token, self._get_list_of_candidate_text())
            self._process_open_parenthesis(token)
            return True
        if token_text == ')':
            if not self._expecting_close:
                msg = 'Not expecting closing parenthesis'
                raise InfixError(msg, token, self._get_list_of_candidate_text())
            self._process_close_parenthesis(token)
            return True
        return False

    def _process_query_field(self, _: Token, verb_dictionary: dict[str, IFieldVerb]) -> None:
        self._expecting_query = False
        self._expecting_verb_list = list(verb_dictionary.keys())
        self._expecting_binary_operator = False
        self._expecting_unary_operator = False
        self._expecting_open = False
        self._expecting_close = False

        field_verb: IFieldVerb = self._argument_stream.pop_dict_value(verb_dictionary)

        self._expecting_query = False
        self._expecting_verb_list = None
        self._expecting_binary_operator = False
        self._expecting_unary_operator = False
        self._expecting_open = False
        self._expecting_close = False

        query_object: IQuery = field_verb.create_query(self._argument_stream)

        self._postfix_query_chain.append(query_object)
        self._pop_unary_operators_to_postfix_query_chain()

        self._expecting_query = False
        self._expecting_verb_list = None
        self._expecting_binary_operator = True
        self._expecting_unary_operator = False
        self._expecting_open = False
        self._expecting_close = self._has_any_stacked_open_parenthesis()

    def _process_binary_operator(self, _: Token, query_class: type[IQuery]) -> None:
        self._stack_of_operators.append(query_class())

        self._expecting_query = True
        self._expecting_verb_list = None
        self._expecting_binary_operator = False
        self._expecting_unary_operator = True
        self._expecting_open = True
        self._expecting_close = False

    def _process_unary_operator(self, _: Token, query_class: type[IQuery]) -> None:
        self._stack_of_operators.append(query_class())

        self._expecting_query = True
        self._expecting_verb_list = None
        self._expecting_binary_operator = False
        self._expecting_unary_operator = False
        self._expecting_open = True
        self._expecting_close = False

    def _process_open_parenthesis(self, _: Token) -> None:
        self._stack_of_operators.append(None)

        self._expecting_query = True
        self._expecting_verb_list = None
        self._expecting_binary_operator = False
        self._expecting_unary_operator = True
        self._expecting_open = True
        self._expecting_close = False

    def _process_close_parenthesis(self, token: Token) -> None:
        while self._stack_of_operators:
            the_operator: IQuery | None = self._stack_of_operators.pop()
            if not the_operator:
                break
            self._postfix_query_chain.append(the_operator)
        else:
            msg = 'No matching opening parenthesis for closing parenthesis'
            raise InfixError(msg, token, self._get_list_of_candidate_text())

        self._expecting_query = False
        self._expecting_verb_list = None
        self._expecting_binary_operator = True
        self._expecting_unary_operator = False
        self._expecting_open = False
        self._expecting_close = self._has_any_stacked_open_parenthesis()

    def _pop_unary_operators_to_postfix_query_chain(self) -> None:
        while self._stack_of_operators:
            the_operator: IQuery | None = self._stack_of_operators[-1]
            if the_operator and _is_unary_operator_query(the_operator):
                self._stack_of_operators.pop()
                self._postfix_query_chain.append(the_operator)
            else:
                break

    def _has_any_stacked_open_parenthesis(self) -> bool:
        return any(the_operator is None for the_operator in self._stack_of_operators)

def _is_unary_operator_query(query: IQuery) -> bool:
    is_unary: bool = False
    query_class: type[IQuery]
    for query_class in MAP_OF_UNARY_OPERATORS_TO_QUERY_CLASS.values():
        if isinstance(query, query_class):
            is_unary = True
            break
    return is_unary
