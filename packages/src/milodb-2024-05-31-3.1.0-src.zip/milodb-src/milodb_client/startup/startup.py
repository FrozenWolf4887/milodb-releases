# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
import json
import sys
import time
from collections.abc import Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING
import psutil
from milodb_client.startup.command_line import CommandLine, try_parse_command_line
from milodb_client.startup.main import Main
from milodb_client.startup.shutdown_action import IShutdownAction, RestartToCompleteUpdateAction
from milodb_client.updater.i_temp_directory import TempDirectoryError
from milodb_client.updater.manifest.i_schema_types import SchemaLoadError
from milodb_client.updater.manifest.update_sequence_schema import UpdateSequenceSchema
from milodb_client.updater.perform_update import PerformUpdateError, perform_update
from milodb_client.updater.temp_directory import TempDirectory
from milodb_common.output.print.error_printer import ErrorPrinter
from milodb_common.output.print.normal_printer import NormalPrinter
from milodb_common.output.print.stdout_printer import StdoutPrinter
if TYPE_CHECKING:
    from milodb_common.output.print.i_printer import IPrinter, IRedirectablePrinter

_PID_WAIT_TIMEOUT_SECONDS: int = 10

@dataclass(kw_only=True)
class StartupResult:
    exit_code: int
    shutdown_action: IShutdownAction | None

def startup(list_of_args: list[str]) -> StartupResult:
    command_line: CommandLine | None = try_parse_command_line(list_of_args)
    if (command_line and
        _wait_for_list_of_pids_to_end(command_line.list_of_pids_to_wait_on, _PID_WAIT_TIMEOUT_SECONDS) and
        _purge_list_of_temp_directories(command_line.list_of_temp_directories_to_purge)
    ):
        if command_line.update_from_sequence_filepath:
            return _process_perform_update(command_line.update_from_sequence_filepath)
        shutdown_action: IShutdownAction | None = Main().run(autoexec=command_line.autoexec)
        return StartupResult(exit_code=0, shutdown_action=shutdown_action)

    return StartupResult(exit_code=1, shutdown_action=None)

def _wait_for_list_of_pids_to_end(list_of_pids: list[int], timeout_seconds: int) -> bool:
    return all(_wait_for_pid_to_end(pid, timeout_seconds) for pid in list_of_pids)

def _wait_for_pid_to_end(pid: int, timeout_seconds: int) -> bool:
    print(f'Waiting for PID {pid} to finish...')
    start_time_ns: int = time.monotonic_ns()
    while psutil.pid_exists(pid):
        time.sleep(0.5)
        elapsed_time_seconds: int = (time.monotonic_ns() - start_time_ns) // 1_000_000_000
        if elapsed_time_seconds >= timeout_seconds:
            print(f"Fatal: PID {pid} didn't end within {timeout_seconds} seconds")
            return False
    print(f'PID {pid} finished')
    return True

def _purge_list_of_temp_directories(list_of_directories: Sequence[Path]) -> bool:
    directory: Path
    for directory in list_of_directories:
        print(f"Purge temporary directory '{directory}'")
        try:
            TempDirectory(directory).destroy()
        except TempDirectoryError as ex:
            print(f"Fatal: Couldn't purge directory '{directory}': {ex}")
            return False
    return True

def _process_perform_update(update_sequence_filepath: Path) -> StartupResult:
    try:
        with update_sequence_filepath.open('rb') as file:
            update_strategy_json: object = json.load(file)
    except (OSError, json.JSONDecodeError, UnicodeDecodeError) as ex:
        print(f"Fatal: Loading '{update_sequence_filepath}' failed: {ex}")
        return StartupResult(exit_code=1, shutdown_action=None)

    update_sequence: UpdateSequenceSchema = UpdateSequenceSchema()
    try:
        update_sequence.load(update_strategy_json)
    except SchemaLoadError as ex:
        print(f"Fatal: Parsing '{update_sequence_filepath}' failed: {ex}")
        return StartupResult(exit_code=1, shutdown_action=None)

    stdout_printer: IPrinter = StdoutPrinter()
    normal_printer: IRedirectablePrinter = NormalPrinter(stdout_printer)
    error_printer: IRedirectablePrinter = ErrorPrinter(stdout_printer)

    try:
        perform_update(update_sequence, normal_printer, error_printer)
    except PerformUpdateError as ex:
        print(f"Fatal: Failed to perform update: {ex}")
        return StartupResult(exit_code=1, shutdown_action=None)

    shutdown_action: IShutdownAction | None = None
    if update_sequence.launch_filename:
        shutdown_action = RestartToCompleteUpdateAction(
            new_application_filepath=Path(update_sequence.launch_filename),
            temp_application_filepath=Path(sys.executable),
            update_sequence_filepath=Path(update_sequence_filepath),
            temp_directory=Path(update_sequence.temp_directory))
    else:
        print("Warning: There is no known new application that can be started")

    return StartupResult(exit_code=0, shutdown_action=shutdown_action)
