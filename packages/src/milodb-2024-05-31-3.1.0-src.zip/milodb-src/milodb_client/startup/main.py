# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
import json
from pathlib import Path
from typing import TYPE_CHECKING
from milodb_client.commands import browse_command
from milodb_client.commands import copy_command
from milodb_client.commands import ellipsis_command
from milodb_client.commands import format_command
from milodb_client.commands import help_command
from milodb_client.commands import highlight_command
from milodb_client.commands import list_command
from milodb_client.commands import open_command
from milodb_client.commands import openauthor_command
from milodb_client.commands import pagerefs_command
from milodb_client.commands import query_command
from milodb_client.commands import show_command
from milodb_client.commands import sort_command
from milodb_client.commands import stats_command
from milodb_client.commands import summary_command
from milodb_client.commands import update_command
from milodb_client.commands import url_command
from milodb_client.commands import urlauthor_command
from milodb_client.commands.command_factory import CommandFactory
from milodb_client.commands.database_stats import DatabaseStats
from milodb_client.commands.sort_keys import DATE_SORT_KEY, LIST_OF_AVAILABLE_SORT_KEYS, OrderedSortKey, TEASE_ID_SORT_KEY
from milodb_client.commands.tease_match_sorter import ITeaseMatchSorter, TeaseMatchSorter
from milodb_client.config.ansi_config import AnsiConfig
from milodb_client.config.bbcode_config import BBCodeConfig
from milodb_client.config.commands_config import CommandBrowseLaunchConfig, CommandOpenLaunchConfig, ILaunchConfig
from milodb_client.config.config_schema import CONFIG_SCHEMA
from milodb_client.config.html_config import HtmlConfig
from milodb_client.config.json_config_file import JsonConfigFile
from milodb_client.config.update_config import UpdateConfig
from milodb_client.database.database import load_teases_from_database_file, try_get_newest_tease_date, try_get_oldest_tease_date
from milodb_client.output.format.ansi_formatter import AnsiFormatter
from milodb_client.output.format.bbcode_formatter import BBCodeFormatter
from milodb_client.output.format.formatter_factory import FormatterCreator, FormatterFactory
from milodb_client.output.format.html_file_writer import HtmlFileWriter
from milodb_client.output.format.html_formatter import HtmlFormatter
from milodb_client.output.format.plain_formatter import PlainFormatter
from milodb_client.query.infix_query_parser import InfixQueryParser
from milodb_client.query.postfix_query_executor import PostfixQueryExecutor
from milodb_client.startup.shutdown_action import IShutdownAction
from milodb_client.updater.local_file_hasher import LocalFileHasher
from milodb_client.updater.local_file_tester import LocalFileTester
from milodb_client.updater.manifest.i_schema_types import SchemaLoadError
from milodb_client.updater.manifest.local_manifest_schema import LocalManifestSchema
from milodb_client.updater.temp_directory import TempDirectoryCreator
from milodb_common.command_framework.command_constructor import CommandConstructor
from milodb_common.command_framework.quit_flag import QuitFlag
from milodb_common.commands import exit_command
from milodb_common.commands import var_command
from milodb_common.datum.ref_datum import RefDatum
from milodb_common.input.autoexec import run_autoexec
from milodb_common.input.default_input import DefaultInputText, IDefaultInputText
from milodb_common.input.prompt import run_interactive_prompt
from milodb_common.internet.uri_scraper_factory import UriScraperFactory
from milodb_common.output.print.error_printer import ErrorPrinter
from milodb_common.output.print.i_printer import IPrinter, IRedirectablePrinter
from milodb_common.output.print.normal_printer import NormalPrinter
from milodb_common.output.print.stdout_printer import StdoutPrinter
from milodb_common.output.print.warning_printer import WarningPrinter
from milodb_common.variables.file_user_variables import FileUserVariables
if TYPE_CHECKING:
    import datetime
    from milodb_client.config.framework import IConfig
    from milodb_client.database.tease import Tease
    from milodb_client.output.format.i_formatter_factory import IFormatterCreator
    from milodb_client.query.tease_match import TeaseMatch
    from milodb_client.updater.i_file_hasher import IFileHasher
    from milodb_client.updater.i_file_tester import IFileTester
    from milodb_client.updater.i_temp_directory import ITempDirectoryCreator
    from milodb_common.command_framework.i_command_constructor import ICommandConstructor
    from milodb_common.internet.i_uri_scraper_factory import IUriScraperFactory
    from milodb_common.variables.i_user_variables import IPersistentUserVariables

LOCAL_MANIFEST_FILENAME: Path = Path('milodb.ver')
DATABASE_FILENAME: Path = Path('database.mdb')
CONFIG_FILENAME: Path = Path('config.json')
VARIABLES_FILENAME: Path = Path('variables.json')
AUTOEXEC_FILENAME: Path = Path('autoexec.txt')

class Main:
    def __init__(self) -> None: # pylint: disable=too-many-statements # noqa: PLR0915 Too many statements
        stdout_printer: IPrinter = StdoutPrinter()
        normal_printer: IRedirectablePrinter = NormalPrinter(stdout_printer)
        error_printer: IRedirectablePrinter = ErrorPrinter(stdout_printer)
        warning_printer: IRedirectablePrinter = WarningPrinter(stdout_printer)

        local_manifest: LocalManifestSchema | None = _load_local_manifest(LOCAL_MANIFEST_FILENAME, warning_printer, error_printer)
        print(f'Milovana Database {local_manifest.version_number if local_manifest else "(Unknown Version)"}, {local_manifest.date if local_manifest else "(Unknown Date)"}')

        system_config: IConfig = JsonConfigFile(CONFIG_FILENAME, CONFIG_SCHEMA)
        update_config: UpdateConfig = UpdateConfig(system_config)
        command_browse_launch_config: ILaunchConfig = CommandBrowseLaunchConfig(system_config)
        command_open_launch_config: ILaunchConfig = CommandOpenLaunchConfig(system_config)

        list_of_tease_matches: RefDatum[list[TeaseMatch]] = RefDatum([])
        use_highlighting: RefDatum[bool] = RefDatum(True)
        use_ellipsis: RefDatum[bool] = RefDatum(True)
        show_pagerefs: RefDatum[bool] = RefDatum(False)
        ellipsis_max_width: RefDatum[int] = RefDatum(40)
        tease_match_sorter: ITeaseMatchSorter = TeaseMatchSorter([OrderedSortKey(DATE_SORT_KEY, is_ascending=True), OrderedSortKey(TEASE_ID_SORT_KEY, is_ascending=True)])
        list_of_active_sort_keys: RefDatum[list[OrderedSortKey]] = RefDatum([])
        infix_query_parser: InfixQueryParser = InfixQueryParser()
        postfix_query_executor: PostfixQueryExecutor = PostfixQueryExecutor()
        self._default_input_text: IDefaultInputText = DefaultInputText()
        self._user_variables: IPersistentUserVariables = FileUserVariables(VARIABLES_FILENAME)
        self._quit_flag: QuitFlag = QuitFlag()

        plain_formatter_creator: IFormatterCreator = FormatterCreator(
            'plain', lambda printer: PlainFormatter(
                printer,
                ellipsis_max_width=ellipsis_max_width.get() if use_ellipsis.get() else None,
                show_pagerefs=show_pagerefs.get()))
        ansi_formatter_creator: IFormatterCreator = FormatterCreator(
            'ansi', lambda printer: AnsiFormatter(
                AnsiConfig(system_config),
                printer,
                use_highlighting=use_highlighting.get(),
                ellipsis_max_width=ellipsis_max_width.get() if use_ellipsis.get() else None,
                show_pagerefs=show_pagerefs.get()))
        bbcode_formatter_creator: IFormatterCreator = FormatterCreator(
            'bbcode', lambda printer: BBCodeFormatter(
                BBCodeConfig(system_config),
                printer,
                use_highlighting=use_highlighting.get(),
                ellipsis_max_width=ellipsis_max_width.get() if use_ellipsis.get() else None,
                show_pagerefs=show_pagerefs.get()))
        html_formatter_creator: IFormatterCreator = FormatterCreator(
            'html', lambda printer: HtmlFormatter(
                HtmlConfig(system_config),
                printer,
                use_highlighting=use_highlighting.get(),
                ellipsis_max_width=ellipsis_max_width.get() if use_ellipsis.get() else None,
                show_pagerefs=show_pagerefs.get()))

        formatter_factory: FormatterFactory = FormatterFactory()
        formatter_factory.register_formatter(ansi_formatter_creator)
        formatter_factory.register_formatter(plain_formatter_creator)
        formatter_factory.register_formatter(bbcode_formatter_creator)
        formatter_factory.register_formatter(html_formatter_creator)

        current_formatter_creator: RefDatum[IFormatterCreator] = RefDatum(ansi_formatter_creator)
        html_file_writer: HtmlFileWriter = HtmlFileWriter(HtmlConfig(system_config), html_formatter_creator)

        uri_scraper_factory: IUriScraperFactory = UriScraperFactory()
        file_hasher: IFileHasher = LocalFileHasher()
        file_tester: IFileTester = LocalFileTester()
        temp_directory_creator: ITempDirectoryCreator = TempDirectoryCreator()
        self._shutdown_action: RefDatum[IShutdownAction | None] = RefDatum(None)

        list_of_teases: list[Tease] = load_teases_from_database_file(DATABASE_FILENAME)
        oldest_tease_date: datetime.date | None = try_get_oldest_tease_date(list_of_teases)
        newest_tease_date: datetime.date | None = try_get_newest_tease_date(list_of_teases)
        print(f"{len(list_of_teases):,} teases loaded ranging from {oldest_tease_date or 'None'} to {newest_tease_date or 'None'}\n")

        database_stats: DatabaseStats = DatabaseStats(list_of_teases)

        command_factory: CommandFactory = CommandFactory()
        self._command_constructor: ICommandConstructor = CommandConstructor(command_factory)

        command_factory.register_command('exit', lambda: exit_command.Loader(self._quit_flag), exit_command.Help)
        command_factory.register_command('help', lambda: help_command.Loader(command_factory, normal_printer), help_command.Help)
        command_factory.register_command('list', lambda: list_command.Loader(list_of_teases, list_of_tease_matches.get(), current_formatter_creator.get(), normal_printer, error_printer), list_command.Help)
        command_factory.register_command('format', lambda: format_command.Loader(current_formatter_creator, formatter_factory, normal_printer), lambda: format_command.Help(formatter_factory.get_list_of_formatter_names()))
        command_factory.register_command('highlight', lambda: highlight_command.Loader(use_highlighting, normal_printer), highlight_command.Help)
        command_factory.register_command('ellipsis', lambda: ellipsis_command.Loader(use_ellipsis, normal_printer), ellipsis_command.Help)
        command_factory.register_command('show', lambda: show_command.ShowLoader(list_of_teases, list_of_tease_matches.get(), current_formatter_creator.get(), normal_printer, error_printer), show_command.ShowHelp)
        command_factory.register_command('showall', lambda: show_command.ShowAllLoader(list_of_teases, list_of_tease_matches.get(), current_formatter_creator.get(), normal_printer, error_printer), show_command.ShowAllHelp)
        command_factory.register_command('summary', lambda: summary_command.Loader(list_of_teases, list_of_tease_matches.get(), current_formatter_creator.get(), normal_printer, error_printer), summary_command.Help)
        command_factory.register_command('open', lambda: open_command.Loader(list_of_teases, list_of_tease_matches.get(), command_open_launch_config, normal_printer, error_printer), open_command.Help)
        command_factory.register_command('openauthor', lambda: openauthor_command.Loader(list_of_teases, list_of_tease_matches.get(), command_open_launch_config, normal_printer, error_printer), openauthor_command.Help)
        command_factory.register_command('browse', lambda: browse_command.BrowseLoader(list_of_teases, list_of_tease_matches.get(), command_browse_launch_config, html_file_writer, normal_printer, error_printer), browse_command.BrowseHelp)
        command_factory.register_command('browseall', lambda: browse_command.BrowseAllLoader(list_of_teases, list_of_tease_matches.get(), command_browse_launch_config, html_file_writer, normal_printer, error_printer), browse_command.BrowseAllHelp)
        command_factory.register_command('query', lambda: query_command.Loader(list_of_teases, infix_query_parser, postfix_query_executor, list_of_tease_matches, tease_match_sorter, list_of_active_sort_keys.get(), current_formatter_creator.get(), normal_printer, warning_printer, error_printer), query_command.Help)
        command_factory.register_command('sort', lambda: sort_command.Loader(list_of_tease_matches, tease_match_sorter, list_of_active_sort_keys, LIST_OF_AVAILABLE_SORT_KEYS, normal_printer), lambda: sort_command.Help(LIST_OF_AVAILABLE_SORT_KEYS))
        command_factory.register_command('url', lambda: url_command.Loader(list_of_teases, list_of_tease_matches.get(), normal_printer, error_printer), url_command.Help)
        command_factory.register_command('urlauthor', lambda: urlauthor_command.Loader(list_of_teases, list_of_tease_matches.get(), normal_printer, error_printer), urlauthor_command.Help)
        command_factory.register_command('stats', lambda: stats_command.Loader(database_stats, normal_printer), stats_command.Help)
        command_factory.register_command('copy', lambda: copy_command.Loader(self._command_constructor, [normal_printer, warning_printer, error_printer]), copy_command.Help)
        command_factory.register_command('var', lambda: var_command.Loader(self._user_variables, self._default_input_text, normal_printer, warning_printer, error_printer), var_command.Help)
        command_factory.register_command('pagerefs', lambda: pagerefs_command.Loader(show_pagerefs, normal_printer), pagerefs_command.Help)
        command_factory.register_command('update', lambda: update_command.Loader(local_manifest, update_config, file_hasher, file_tester, temp_directory_creator, uri_scraper_factory, self._quit_flag, self._shutdown_action, normal_printer, warning_printer, error_printer), update_command.Help)

    def run(self, *, autoexec: bool) -> IShutdownAction | None:
        if autoexec:
            run_autoexec(AUTOEXEC_FILENAME, self._command_constructor, self._user_variables, self._quit_flag)
        if not self._quit_flag:
            run_interactive_prompt(self._command_constructor, self._user_variables, self._default_input_text, self._quit_flag)
        return self._shutdown_action.get()

def _load_local_manifest(filename: Path, warning_printer: IPrinter, error_printer: IPrinter) -> LocalManifestSchema | None:
    try:
        with filename.open('rb') as file:
            json_root: object = json.load(file)
    except FileNotFoundError:
        warning_printer.writeln(f"Local manifest '{filename}' unavailable")
    except (OSError, json.JSONDecodeError) as ex:
        error_printer.writeln(f"Unable to read from local manifest '{filename}': {ex}")
    else:
        manifest: LocalManifestSchema = LocalManifestSchema()
        try:
            manifest.load(json_root)
        except SchemaLoadError as ex:
            error_printer.writeln(f"Invalid local manifest '{filename}': {ex}")
        else:
            return manifest
    return None
