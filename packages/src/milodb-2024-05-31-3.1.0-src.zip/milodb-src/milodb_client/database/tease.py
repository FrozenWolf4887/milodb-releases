# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
import datetime
from collections.abc import Callable
from enum import Enum
from typing import TypeAlias
from milodb_client.database.metadata_getter import MetadataGetter
from milodb_client.database.tease_page import TeasePage

class TeaseType(Enum):
    REGULAR = 'reg'
    AUDIO = 'aud'
    NYX = 'nyx'
    EOS = 'eos'

class TotmStatus(Enum):
    NONE = 0
    NOMINEE = 1
    WINNER = 2

TeasePropertyType: TypeAlias = str | int | float | TeaseType | list[str] | datetime.date | TotmStatus | list[TeasePage]
TeaseProperty: TypeAlias = Callable[['Tease'], TeasePropertyType]
TeaseStrProperty: TypeAlias = Callable[['Tease'], str]
TeaseIntProperty: TypeAlias = Callable[['Tease'], int]
TeaseFloatProperty: TypeAlias = Callable[['Tease'], float]
TeaseBooleanProperty: TypeAlias = Callable[['Tease'], bool]
TeaseTypeProperty: TypeAlias = Callable[['Tease'], TeaseType]
TeaseDateProperty: TypeAlias = Callable[['Tease'], datetime.date]
TeaseTotmProperty: TypeAlias = Callable[['Tease'], TotmStatus]
TeaseStrListProperty: TypeAlias = Callable[['Tease'], list[str]]
TeasePageListProperty: TypeAlias = Callable[['Tease'], list[TeasePage]]

_KEY_TEASE_ID: str = 'tid'
_KEY_AUTHOR_ID: str = 'aid'
_KEY_TEASE_TYPE: str = 'typ'
_KEY_TITLE: str = 'ttl'
_KEY_SUMMARY: str = 'sum'
_KEY_THUMBNAIL: str = 'thm'
_KEY_AUTHOR_NAME: str = 'anm'
_KEY_TAGS: str = 'tgs'
_KEY_DATE: str = 'dat'
_KEY_RATING: str = 'rvl'
_KEY_PAGES: str = 'pgs'
_KEY_PAGE_REF: str = 'ref'
_KEY_PAGE_TEXT: str = 'txt'
_KEY_IMAGE_COUNT: str = 'imr'
_KEY_UNIQUE_IMAGE_COUNT: str = 'imu'
_KEY_DELETED: str = 'del'
_KEY_AUTHOR_GONE: str = 'agn'
_TAG_TOTM_WINNER: str = 'totm'
_TAG_TOTM_NOMINEE: str = 'totm-nominee'

class Tease:
    class LoadError(Exception):
        pass

    def __init__(self, metadata: dict[object, object]) -> None:
        getter: MetadataGetter = MetadataGetter(metadata, Tease.LoadError)
        self._tease_id: int = getter.get_int(_KEY_TEASE_ID, min_value=1, max_value=None, default_value_if_none=None)
        self._author_id: int | None = getter.try_get_int(_KEY_AUTHOR_ID, min_value=0, max_value=None)
        self._tease_type: TeaseType = getter.get_dict_value(_KEY_TEASE_TYPE, lambda key: getter.get_int(key, min_value=None, max_value=None, default_value_if_none=None), _MAP_OF_RAW_TYPE_TO_COOKED_TYPE)
        self._title: str = getter.get_str_or_blank(_KEY_TITLE)
        self._summary: str = getter.get_str_or_blank(_KEY_SUMMARY)
        self._thumbnail: str = getter.get_str_or_blank(_KEY_THUMBNAIL)
        self._author_name: str = getter.get_str_or_blank(_KEY_AUTHOR_NAME)
        raw_tags: str = getter.get_str_or_blank(_KEY_TAGS)
        self._tags: list[str] = [tag for tag in raw_tags.split(':') if tag]
        self._date: datetime.date = getter.get_date(_KEY_DATE)
        self._rating_value: float = getter.get_float(_KEY_RATING, min_value=0.0, max_value=5.0, default_value_if_none=0.0)
        self._list_of_pages: list[TeasePage] = _load_list_of_pages(_KEY_PAGES, getter)
        self._totm_status: TotmStatus = TotmStatus.NONE
        if _TAG_TOTM_NOMINEE in self._tags:
            self._totm_status = TotmStatus.NOMINEE
        if _TAG_TOTM_WINNER in self._tags:
            self._totm_status = TotmStatus.WINNER
        self._is_deleted: bool = getter.get_bool_or_default(_KEY_DELETED, default=False)
        self._has_author_gone: bool = getter.get_bool_or_default(_KEY_AUTHOR_GONE, default=False)
        self._count_of_images: int = getter.get_int(_KEY_IMAGE_COUNT, min_value=0, max_value=None, default_value_if_none=0)
        self._count_of_unique_images: int = getter.get_int(_KEY_UNIQUE_IMAGE_COUNT, min_value=0, max_value=None, default_value_if_none=0)

    def tease_id(self) -> int:
        return self._tease_id

    def has_author(self) -> bool:
        return bool(self._author_id)

    def author_id(self) -> int:
        return self._author_id or 0

    def type(self) -> TeaseType:
        return self._tease_type

    def title(self) -> str:
        return self._title

    def summary(self) -> str:
        return self._summary

    def thumbnail(self) -> str:
        return self._thumbnail

    def author_name(self) -> str:
        return self._author_name

    def list_of_tags(self) -> list[str]:
        return self._tags

    def date(self) -> datetime.date:
        return self._date

    def rating_value(self) -> float:
        return self._rating_value

    def totm_status(self) -> TotmStatus:
        return self._totm_status

    def list_of_pages(self) -> list[TeasePage]:
        return self._list_of_pages

    def count_of_images(self) -> int:
        return self._count_of_images

    def count_of_unique_images(self) -> int:
        return self._count_of_unique_images

    def is_deleted(self) -> bool:
        return self._is_deleted

    def has_author_gone(self) -> bool:
        return self._has_author_gone

    def get_text_of_property(self, tease_property: TeaseProperty) -> str:
        value: TeasePropertyType = tease_property(self)
        if isinstance(value, TeaseType):
            return value.value
        if isinstance(value, str):
            return value
        if isinstance(value, int | float):
            return str(value)
        if isinstance(value, datetime.date):
            return value.isoformat()
        return ''

_MAP_OF_RAW_TYPE_TO_COOKED_TYPE: dict[int, TeaseType] = {
    0: TeaseType.REGULAR,
    1: TeaseType.NYX,
    2: TeaseType.EOS,
    3: TeaseType.AUDIO,
}

def _load_list_of_pages(key: str, getter: MetadataGetter) -> list[TeasePage]:
    list_of_pages: list[TeasePage] = []

    list_of_pages_json: list[dict[object, object]] = getter.get_dict_list_or_empty(key)

    page_json: dict[object, object]
    for page_json in list_of_pages_json:
        page_getter: MetadataGetter = getter.sub_metadata(page_json)
        page_ref: str = page_getter.get_str(_KEY_PAGE_REF)
        page_text: str = page_getter.get_str(_KEY_PAGE_TEXT)
        list_of_pages.append(TeasePage(page_ref, page_text))

    return list_of_pages
