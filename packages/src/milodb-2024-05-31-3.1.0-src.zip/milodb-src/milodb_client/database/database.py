# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
import datetime
import json
import lzma
from pathlib import Path
from typing import Any
from milodb_client.database.tease import Tease
from milodb_client.output.print_timed_activity import PrintTimedActivity

_DATABASE_FORMAT_KEY: str = 'fmt'
_DATABASE_FORMAT_VALUE: int = 2
_DATABASE_TEASES_KEY: str = 'tss'

def load_teases_from_database_file(database_filepath: Path) -> list[Tease]:
    with PrintTimedActivity('Load database\n', 'Load completed: '):
        try:
            return _load_from_file(database_filepath)
        except _LoadError as ex:
            print(f'FATAL: {ex}')
        return []

def try_get_oldest_tease_date(list_of_teases: list[Tease]) -> (datetime.date | None):
    oldest_tease_date: (datetime.date | None) = None
    tease: Tease
    for tease in list_of_teases:
        if oldest_tease_date is not None:
            oldest_tease_date = min(oldest_tease_date, tease.date())
        else:
            oldest_tease_date = tease.date()
    return oldest_tease_date

def try_get_newest_tease_date(list_of_teases: list[Tease]) -> (datetime.date | None):
    newest_tease_date: (datetime.date | None) = None
    tease: Tease
    for tease in list_of_teases:
        if newest_tease_date is not None:
            newest_tease_date = max(newest_tease_date, tease.date())
        else:
            newest_tease_date = tease.date()
    return newest_tease_date

def try_get_tease(tease_id: int, list_of_teases: list[Tease]) -> (Tease | None):
    tease: Tease
    for tease in list_of_teases:
        if tease_id == tease.tease_id():
            return tease
    return None

def get_teases_by_author_id(author_id: int, list_of_teases: list[Tease]) -> list[Tease]:
    return [ tease for tease in list_of_teases if author_id == tease.author_id() ]

class _LoadError(Exception):
    pass

def _load_from_file(database_filepath: Path) -> list[Tease]:
    raw_file_contents: bytes = _read_file(database_filepath)
    file_contents: bytes = _unpack_contents(raw_file_contents)
    json_dict: dict[Any, Any] = _parse_json(file_contents)
    _check_format(json_dict)
    json_list: list[Any] = _get_json_list_of_teases(json_dict)
    return _build_tease_list(json_list)

def _read_file(database_filepath: Path) -> bytes:
    with PrintTimedActivity('  Read', '     : '):
        try:
            with database_filepath.open('rb') as file:
                return file.read()
        except IOError as ex:
            raise _LoadError(f"File access error: {ex}") from ex

def _unpack_contents(raw_file_contents: bytes) -> bytes:
    with PrintTimedActivity('  Unpack', '   : '):
        try:
            return lzma.decompress(raw_file_contents)
        except lzma.LZMAError as ex:
            raise _LoadError(f"Unpack failed: {ex}") from ex

def _parse_json(file_contents: bytes) -> dict[Any, Any]:
    with PrintTimedActivity('  Parse', '    : '):
        try:
            json_root: Any = json.loads(file_contents)
        except json.JSONDecodeError as ex:
            raise _LoadError(f"JSON decode error: {ex}") from ex

        if not isinstance(json_root, dict):
            raise _LoadError('Database root is not a dictionary')

        json_dict: dict[Any, Any] = json_root
        return json_dict

def _check_format(json_dict: dict[Any, Any]) -> None:
    raw_format: Any | None = json_dict.get(_DATABASE_FORMAT_KEY)
    if raw_format is None:
        raise _LoadError(f"Database format key '{_DATABASE_FORMAT_KEY}' missing")
    if not isinstance(raw_format, int):
        raise _LoadError(f"Database format key value '{_DATABASE_FORMAT_KEY}' is not an integer")
    if raw_format != _DATABASE_FORMAT_VALUE:
        raise _LoadError(f"Database has format '{raw_format}' which is not the expected format '{_DATABASE_FORMAT_VALUE}'")

def _get_json_list_of_teases(json_dict: dict[Any, Any]) -> list[Any]:
    raw_list: Any | None = json_dict.get(_DATABASE_TEASES_KEY)
    if raw_list is None:
        raise _LoadError(f"Database teases key '{_DATABASE_TEASES_KEY}' missing")
    if not isinstance(raw_list, list):
        raise _LoadError(f"Database teases key value '{_DATABASE_TEASES_KEY}' is not a list")

    json_list: list[Any] = raw_list
    return json_list

def _build_tease_list(json_list: list[Any]) -> list[Tease]:
    list_of_teases: list[Tease] = []

    with PrintTimedActivity('  Assemble', ' : '):
        tease_obj: Any
        for tease_obj in json_list:
            tease_dict: dict[Any, Any] = tease_obj
            try:
                tease: Tease = Tease(tease_dict)
            except Tease.LoadError as ex:
                raise _LoadError(f"Tease load error: {ex}") from ex
            list_of_teases.append(tease)

    return list_of_teases
