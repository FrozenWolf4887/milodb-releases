# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
import re
from abc import ABC, abstractmethod
from dataclasses import dataclass

VARIABLE_NAME_PATTERN: re.Pattern[str] = re.compile(r"[\w\-\+]+")
VARIABLE_FULL_NAME_PATTERN: re.Pattern[str] = re.compile(r'\$' + VARIABLE_NAME_PATTERN.pattern)

class IUserVariables(ABC):
    @abstractmethod
    def try_retrieve(self, name: str) -> str | None:
        pass

    @abstractmethod
    def get_list_of_names(self) -> list[str]:
        pass

    @abstractmethod
    def get_list_of_variables(self) -> list[tuple[str, str]]:
        pass

class IEditableUserVariables(IUserVariables):
    @abstractmethod
    def set(self, name: str, value: str) -> None:
        pass

    @abstractmethod
    def try_delete(self, name: str) -> bool:
        pass

class IPersistentUserVariables(IEditableUserVariables):
    @dataclass
    class SaveResult:
        was_successful: bool
        warning_message: str | None
        error_message: str | None

    @abstractmethod
    def try_save(self) -> SaveResult:
        pass
