# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from typing import TYPE_CHECKING
from milodb_common.command_framework.argument_stream import ArgumentStream
from milodb_common.command_framework.candidate_text import CandidateText
from milodb_common.command_framework.i_command import ICommand, ICommandLoader
from milodb_common.command_framework.i_help_info import IHelpInfo
from milodb_common.input.default_input import IDefaultInputText
from milodb_common.output.print.i_printer import IPrinter
from milodb_common.variables.i_user_variables import IPersistentUserVariables, IUserVariables
if TYPE_CHECKING:
    from collections.abc import Callable

class Loader(ICommandLoader):
    def __init__(self, user_variables: IPersistentUserVariables, default_input_text: IDefaultInputText, normal_printer: IPrinter, warning_printer: IPrinter, error_printer: IPrinter) -> None:
        self._user_variables: IPersistentUserVariables = user_variables
        self._default_input_text: IDefaultInputText = default_input_text
        self._normal_printer: IPrinter = normal_printer
        self._warning_printer: IPrinter = warning_printer
        self._error_printer: IPrinter = error_printer

    def load(self, argument_stream: ArgumentStream) -> ICommandLoader.Result:
        argument_stream.disable_expansion()

        map_of_action_to_delegate: dict[str, Callable[[ArgumentStream], ICommand]] = {
            'set': self._load_action_set,
            'get': self._load_action_get,
            'delete': self._load_action_delete,
            'rename': self._load_action_rename,
            'copy': self._load_action_copy,
            'edit': self._load_action_edit,
        }

        load_command: Callable[[ArgumentStream], ICommand] | None = argument_stream.pop_optional_dict_value(map_of_action_to_delegate)
        if load_command:
            return ICommandLoader.Result(load_command(argument_stream), [])
        return ICommandLoader.Result(
            ExecutorListVariables(self._user_variables, self._normal_printer),
            CandidateText.space_delimited_list(map_of_action_to_delegate.keys()))

    def _load_action_set(self, argument_stream: ArgumentStream) -> ICommand:
        variable_name: str = argument_stream.pop_variable_name(self._user_variables.get_list_of_names())
        variable_value: str = argument_stream.get_remaining_raw_text().strip()
        if not variable_value:
            msg = "Expected some text to set as the variable value"
            raise ICommandLoader.Error(msg, None, [])
        return ExecutorSetVariable(variable_name, variable_value, self._user_variables, self._warning_printer, self._error_printer)

    def _load_action_get(self, argument_stream: ArgumentStream) -> ICommand:
        variable_name: str = argument_stream.pop_variable_name(self._user_variables.get_list_of_names())
        argument_stream.fail_if_not_empty()
        return ExecutorGetVariable(variable_name, self._user_variables, self._normal_printer, self._error_printer)

    def _load_action_delete(self, argument_stream: ArgumentStream) -> ICommand:
        variable_name: str = argument_stream.pop_variable_name(self._user_variables.get_list_of_names())
        argument_stream.fail_if_not_empty()
        return ExecutorDeleteVariable(variable_name, self._user_variables, self._warning_printer, self._error_printer)

    def _load_action_rename(self, argument_stream: ArgumentStream) -> ICommand:
        variable_name: str = argument_stream.pop_variable_name(self._user_variables.get_list_of_names())
        new_variable_name: str = argument_stream.pop_variable_name([])
        argument_stream.fail_if_not_empty()
        return ExecutorRenameVariable(variable_name, new_variable_name, self._user_variables, self._warning_printer, self._error_printer)

    def _load_action_copy(self, argument_stream: ArgumentStream) -> ICommand:
        variable_name: str = argument_stream.pop_variable_name(self._user_variables.get_list_of_names())
        new_variable_name: str = argument_stream.pop_variable_name([])
        argument_stream.fail_if_not_empty()
        return ExecutorCopyVariable(variable_name, new_variable_name, self._user_variables, self._warning_printer, self._error_printer)

    def _load_action_edit(self, argument_stream: ArgumentStream) -> ICommand:
        variable_name: str = argument_stream.pop_variable_name(self._user_variables.get_list_of_names())
        argument_stream.fail_if_not_empty()
        return ExecutorEditVariable(variable_name, self._user_variables, self._default_input_text, self._error_printer)

class ExecutorSetVariable(ICommand):
    def __init__(self, variable_name: str, variable_value: str, user_variables: IPersistentUserVariables, warning_printer: IPrinter, error_printer: IPrinter) -> None:
        self._variable_name: str = variable_name
        self._variable_value: str = variable_value
        self._user_variables: IPersistentUserVariables = user_variables
        self._warning_printer: IPrinter = warning_printer
        self._error_printer: IPrinter = error_printer

    def execute(self) -> None:
        self._user_variables.set(self._variable_name, self._variable_value)
        _save_variables(self._user_variables, self._warning_printer, self._error_printer)

class ExecutorGetVariable(ICommand):
    def __init__(self, variable_name: str, user_variables: IUserVariables, normal_printer: IPrinter, error_printer: IPrinter) -> None:
        self._variable_name: str = variable_name
        self._user_variables: IUserVariables = user_variables
        self._normal_printer: IPrinter = normal_printer
        self._error_printer: IPrinter = error_printer

    def execute(self) -> None:
        value: str | None = self._user_variables.try_retrieve(self._variable_name)
        if value is not None:
            _print_variable(self._normal_printer, self._variable_name, value)
        else:
            self._error_printer.writeln(f"Unknown variable '{self._variable_name}'")

class ExecutorRenameVariable(ICommand):
    def __init__(self, variable_name: str, new_variable_name: str, user_variables: IPersistentUserVariables, warning_printer: IPrinter, error_printer: IPrinter) -> None:
        self._variable_name: str = variable_name
        self._new_variable_name: str = new_variable_name
        self._user_variables: IPersistentUserVariables = user_variables
        self._warning_printer: IPrinter = warning_printer
        self._error_printer: IPrinter = error_printer

    def execute(self) -> None:
        if self._variable_name != self._new_variable_name:
            value: str | None = self._user_variables.try_retrieve(self._variable_name)
            if value is not None:
                if self._user_variables.try_retrieve(self._new_variable_name) is None:
                    self._user_variables.set(self._new_variable_name, value)
                    self._user_variables.try_delete(self._variable_name)
                    _save_variables(self._user_variables, self._warning_printer, self._error_printer)
                else:
                    self._error_printer.writeln(f"Cannot rename variable '{self._variable_name}' to '{self._new_variable_name}' because '{self._new_variable_name}' already exists")
            else:
                self._error_printer.writeln(f"Unknown variable '{self._variable_name}'")
        else:
            self._error_printer.writeln(f"Variable '{self._variable_name}' cannot be renamed to itself")

class ExecutorCopyVariable(ICommand):
    def __init__(self, variable_name: str, new_variable_name: str, user_variables: IPersistentUserVariables, warning_printer: IPrinter, error_printer: IPrinter) -> None:
        self._variable_name: str = variable_name
        self._new_variable_name: str = new_variable_name
        self._user_variables: IPersistentUserVariables = user_variables
        self._warning_printer: IPrinter = warning_printer
        self._error_printer: IPrinter = error_printer

    def execute(self) -> None:
        if self._variable_name != self._new_variable_name:
            value: str | None = self._user_variables.try_retrieve(self._variable_name)
            if value is not None:
                if self._user_variables.try_retrieve(self._new_variable_name) is None:
                    self._user_variables.set(self._new_variable_name, value)
                    _save_variables(self._user_variables, self._warning_printer, self._error_printer)
                else:
                    self._error_printer.writeln(f"Cannot copy variable '{self._variable_name}' to '{self._new_variable_name}' because '{self._new_variable_name}' already exists")
            else:
                self._error_printer.writeln(f"Unknown variable '{self._variable_name}'")
        else:
            self._error_printer.writeln(f"Variable '{self._variable_name}' cannot be copied to itself")

class ExecutorEditVariable(ICommand):
    def __init__(self, variable_name: str, user_variables: IPersistentUserVariables, default_input_text: IDefaultInputText, error_printer: IPrinter) -> None:
        self._variable_name: str = variable_name
        self._user_variables: IPersistentUserVariables = user_variables
        self._default_input_text: IDefaultInputText = default_input_text
        self._error_printer: IPrinter = error_printer

    def execute(self) -> None:
        value: str | None = self._user_variables.try_retrieve(self._variable_name)
        if value is not None:
            self._default_input_text.set(f'var set {self._variable_name} {value}')
        else:
            self._error_printer.writeln(f"Unknown variable '{self._variable_name}'")

class ExecutorListVariables(ICommand):
    def __init__(self, user_variables: IUserVariables, normal_printer: IPrinter) -> None:
        self._user_variables: IUserVariables = user_variables
        self._normal_printer: IPrinter = normal_printer

    def execute(self) -> None:
        name: str
        value: str
        list_of_variables: list[tuple[str, str]] = self._user_variables.get_list_of_variables()
        if list_of_variables:
            max_name_width: int = max(len(name) for name, _ in list_of_variables)
            for name, value in list_of_variables:
                _print_variable(self._normal_printer, name, value, max_name_width)
        else:
            self._normal_printer.writeln('No variables available to list')

class ExecutorDeleteVariable(ICommand):
    def __init__(self, variable_name: str, user_variables: IPersistentUserVariables, warning_printer: IPrinter, error_printer: IPrinter) -> None:
        self._variable_name: str = variable_name
        self._user_variables: IPersistentUserVariables = user_variables
        self._warning_printer: IPrinter = warning_printer
        self._error_printer: IPrinter = error_printer

    def execute(self) -> None:
        if self._user_variables.try_delete(self._variable_name):
            _save_variables(self._user_variables, self._warning_printer, self._error_printer)
        else:
            self._error_printer.writeln(f"Unknown variable '{self._variable_name}'")

def _save_variables(user_variables: IPersistentUserVariables, warning_printer: IPrinter, error_printer: IPrinter) -> None:
    save_result: IPersistentUserVariables.SaveResult = user_variables.try_save()
    if not save_result.was_successful:
        if save_result.error_message:
            error_printer.writeln(save_result.error_message)
        if save_result.warning_message:
            warning_printer.writeln(save_result.warning_message)

def _print_variable(normal_printer: IPrinter, name: str, value: str, max_name_width: int = 0) -> None:
    normal_printer.writeln(f'  {name:<{max_name_width}} : {value}')

class Help(IHelpInfo):
    def get_one_line_summary(self) -> str:
        return "Manages the values of user variables"

    def get_detailed_summary(self) -> str:
        return (
            "Arguments: [get|set|delete|rename|copy|edit]\r"
            "           get VariableName\r"
            "           set VariableName ...\r"
            "           delete VariableName\r"
            "           rename VariableName VariableName\r"
            "           copy VariableName VariableName\r"
            "           edit VariableName\n"
            "Variables can help to provide shortcuts when composing a command and are expanded as"
            " the input is processed. A variable reference can appear anywhere in the input by"
            " prefixing it with '$' and is a standalone delimited token such as:\r"
            "  > \tquery $year2020 and author is FrozenWolf\r"
            "  > \t$myQuery and author is FrozenWolf\n"
            "VariableName consists of alphanumeric characters, underscore, minus, and plus symbols.\n"
            "Each variable persists in a variables file that will be created or updated when a"
            " variable is set or changed. When the application is started, the variables file is"
            " loaded.\n"
            "When a variable is 'set', all text following the name is accepted verbatim.\n"
            "TAB completion for variable names within other commands will only provide suggestions"
            " when the '$' prefix is typed; this is to prevent variables getting mixed in with the"
            " regular options. TAB completion on inputs containing variables will behave as if the"
            " variable has been expanded.\n"
            "Variable expansion is recursive, allowing for variable values to reference other"
            " variables if needed.\n"
            "When this command is called without arguments, the list of variables is displayed.\n"
            "Example:\r"
            "  \tSet a variable to help with a query\r"
            "  > \tvar set year2020 date >= 2020-01-01 and date < 2021-01-01\r"
            "  \tUse the variable in a query\r"
            "  > \tquery $year2020 and text contains holiday\r"
            "  \tWhich is equivalent to\r"
            "  > \tquery date >= 2020-01-01 and date < 2021-01-01 and text contains holiday\r"
            "Example:\r"
            "  \tList all the variables\r"
            "  > \tvar\r"
            "Example:\r"
            "  \tDelete one of the variables\r"
            "  > \tvar delete year2020\r"
            "Example:\r"
            "  \tRename one of the variables\r"
            "  > \tvar rename year2020 agesAgo\r"
            "Example:\r"
            "  \tCopy one of the variables\r"
            "  > \tvar copy year2020 agesAgo\r"
            "Example:\r"
            "  \tEdit one of the variables\r"
            "  > \tvar edit year2020\n"
        )
