# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from abc import ABC, abstractmethod
from collections.abc import Sequence
from dataclasses import dataclass
from milodb_common.command_framework.argument_stream import ArgumentStream
from milodb_common.command_framework.candidate_text import CandidateText
from milodb_common.parser.token import Token

class ICommand(ABC):
    @abstractmethod
    def execute(self) -> None:
        pass

class ICommandLoader(ABC):
    @dataclass
    class Result:
        command: ICommand
        list_of_candidate_text: Sequence[CandidateText]

    @dataclass
    class Error(Exception):
        message: str
        fault_token: Token | None
        list_of_candidate_text: Sequence[CandidateText]

    @abstractmethod
    def load(self, argument_stream: ArgumentStream) -> Result:
        pass
