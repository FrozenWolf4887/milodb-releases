# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import sys
from enum import Enum
from pathlib import Path

IS_FROZEN_APP: bool = getattr(sys, 'frozen', False) and hasattr(sys, '_MEIPASS')
FROZEN_APP_PATH: Path = (
    Path(str(sys._MEIPASS)) if IS_FROZEN_APP  # type: ignore [attr-defined] # pylint: disable=protected-access # noqa: SLF001 Private member accessed # pyright: ignore[reportAttributeAccessIssue]
    else Path()
)

class Platform(Enum):
    UNKNOWN = 'Unknown'
    LINUX = 'Linux'
    MACOS = 'MacOS'
    WINDOWS = 'Windows'

PLATFORM: Platform = Platform.WINDOWS if sys.platform == 'win32' \
                else Platform.LINUX if sys.platform == 'linux' \
                else Platform.MACOS if sys.platform == 'darwin' \
                else Platform.UNKNOWN
