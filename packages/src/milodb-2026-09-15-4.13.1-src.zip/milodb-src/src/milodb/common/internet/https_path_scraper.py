# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import gzip
import sys
import zlib
from collections.abc import Callable
from http import HTTPStatus
from http.client import HTTPException, HTTPResponse, HTTPSConnection, IncompleteRead
from io import BufferedIOBase
from ssl import SSLSocket
from typing import NamedTuple, override
import brotli
from milodb.common.internet.i_scraper import IPathScraper, ScrapeProgressCallback, ScrapeResult
from milodb.common.internet.throttle import Throttle
if sys.version_info >= (3, 14):
    from compression import zstd
else:
    from backports import zstd

_DEFAULT_TIMEOUT_SECONDS: int = 60
_GET_REQUEST: str = 'GET'
_READ_CHUNK_SIZE: int = 1024*1024
_MIN_SECONDS_BETWEEN_REQUESTS: float = 1.5

class _Decoder(NamedTuple):
    decompress: Callable[[bytes], bytes]
    exception: type[Exception]

_MAP_OF_ENCODINGS_TO_DECODER: dict[str, _Decoder] = {
    "gzip": _Decoder(gzip.decompress, gzip.BadGzipFile),
    "deflate": _Decoder(zlib.decompress, zlib.error),
    "br": _Decoder(brotli.decompress, brotli.error),
    "zstd": _Decoder(zstd.decompress, zstd.ZstdError),
}

_REQUEST_HEADERS: dict[str, str] = {
    'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64; rv:153.0) Gecko/20100101 Firefox/153.0',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8, image/jxl',
    'Accept-Language': 'en-GB,en;q=0.9',
    'Accept-Encoding': ','.join(_MAP_OF_ENCODINGS_TO_DECODER),
    'DNT': '1',
    'Sec-GPC': '1',
    'Connection': 'keep-alive',
    'Upgrade-Insecure-Requests': '1',
    'Sec-Fetch-Dest': 'document',
    'Sec-Fetch-Mode': 'navigate',
    'Sec-Fetch-Site': 'none',
    'Sec-Fetch-User': '?1',
    'Priority': 'u=0, i',
}

class HttpsPathScraper(IPathScraper):
    def __init__(self, host_name: str, host_port: int | None = None) -> None:
        self._connection: HTTPSConnection = HTTPSConnection(host_name, host_port or HTTPSConnection.default_port, timeout=_DEFAULT_TIMEOUT_SECONDS)
        self._throttle: Throttle = Throttle(min_seconds_between_yields=_MIN_SECONDS_BETWEEN_REQUESTS)
        self._error_message: str | None = None

    @override
    def try_scrape_path(self, filepath: str, progress_callback: ScrapeProgressCallback | None) -> ScrapeResult:
        self._error_message = None
        if self._connect_to_host(progress_callback) and self._send_request(filepath, progress_callback):
            response: HTTPResponse | None = self._receive_response()
            if response:
                if response.status in {HTTPStatus.MOVED_PERMANENTLY, HTTPStatus.FOUND}:
                    self._error_message = f'Redirection response: {response.status} {response.reason}'
                    redirection_url: str | None = response.getheader('Location')
                    if redirection_url:
                        self._error_message += f": to '{redirection_url}'"
                        return ScrapeResult(self._error_message, redirection_url, b'')
                    self._error_message += ': without location URL'
                    return ScrapeResult(self._error_message, None, b'')

                content: bytes | None = self._read_data(response, progress_callback)
                if content is not None:
                    return ScrapeResult(None, None, content)

        return ScrapeResult(self._error_message, None, b'')

    @override
    def close(self, close_callback: Callable[[str], None] | None) -> None:
        if self._is_connected:
            if close_callback:
                close_callback(f"Disconnecting from '{self._connection.host}:{self._connection.port}'")
            self._connection.close()

    @property
    def _is_connected(self) -> bool:
        return self._connection.sock is not None and isinstance(self._connection.sock, SSLSocket) and self._connection.sock.session is not None

    def _connect_to_host(self, progress_callback: ScrapeProgressCallback | None) -> bool:
        if not self._is_connected:
            self._throttle.apply_throttle_delay()
            if progress_callback:
                progress_callback(message=f"Connecting to '{self._connection.host}:{self._connection.port}'", percentage_complete=None)
            try:
                self._connection.connect()
            except OSError as ex:
                self._error_message = str(ex)
                return False
        return True

    def _send_request(self, filepath: str, progress_callback: ScrapeProgressCallback | None) -> bool:
        self._throttle.apply_throttle_delay()
        if progress_callback:
            progress_callback(message=f"Sending {_GET_REQUEST} request '{filepath}'", percentage_complete=None)
        try:
            self._connection.request(_GET_REQUEST, filepath, headers=_REQUEST_HEADERS)
        except (OSError, HTTPException) as ex:
            self._error_message = str(ex)
            return False
        return True

    def _receive_response(self) -> HTTPResponse | None:
        try:
            response: HTTPResponse = self._connection.getresponse()
        except (OSError, HTTPException) as ex:
            self._error_message = str(ex)
            return None

        if response.status in {HTTPStatus.MOVED_PERMANENTLY, HTTPStatus.FOUND, HTTPStatus.OK}:
            return response

        self._error_message = f'Request failed with response: {response.status} {response.reason}'
        try:
            response.read()
        except (OSError, HTTPException) as ex:
            self._error_message += f' and {ex}'

        return None

    def _read_data(self, response: HTTPResponse, progress_callback: ScrapeProgressCallback | None) -> bytes | None:
        content: bytes | None
        if response.length and progress_callback:
            content = self._read_data_in_chunks(response, response.length, progress_callback)
        else:
            content = self._read_data_all_at_once(response, progress_callback)

        if content is None:
            return None

        content_type: str | None = response.getheader('Content-Type')
        content_encoding: str | None = response.getheader('Content-Encoding')
        if progress_callback:
            progress_callback(message=f"Received {len(content):,} bytes of type '{content_type or 'unspecified'}' encoded as '{content_encoding or 'unspecified'}'", percentage_complete=None)

        if response.getheader('Connection') == 'close':
            if progress_callback:
                progress_callback(message=f"Disconnecting from '{self._connection.host}:{self._connection.port}' at request of server", percentage_complete=None)
            self._connection.close()

        if content_encoding:
            decoder: _Decoder | None = _MAP_OF_ENCODINGS_TO_DECODER.get(content_encoding.lower())
            if decoder:
                decompressed_data: bytes | None = self._decompress_data(content, decoder, progress_callback)
                if decompressed_data is None:
                    return None
                content = decompressed_data

        return content

    def _read_data_all_at_once(self, stream: BufferedIOBase, progress_callback: ScrapeProgressCallback | None) -> bytes | None:
        content: bytearray = bytearray()

        while True:
            try:
                content.extend(stream.read())
            except IncompleteRead as ex:
                if progress_callback:
                    progress_callback(message=f'Received partial {len(ex.partial):,} bytes', percentage_complete=None)
                content.extend(ex.partial)
            except (OSError, HTTPException) as ex:
                self._error_message = str(ex)
                return None
            else:
                return bytes(content)

    def _read_data_in_chunks(self, stream: BufferedIOBase, length: int, progress_callback: ScrapeProgressCallback) -> bytes | None:
        progress_callback(message=f'Size is {length:,} bytes', percentage_complete=None)
        content: bytearray = bytearray()

        percentage_complete: int = -1
        finished_reading: bool = False
        try:
            while not finished_reading:
                new_percentage_complete: int = len(content) * 100 // length
                if new_percentage_complete != percentage_complete:
                    new_percentage_complete = percentage_complete
                    progress_callback(message=None, percentage_complete=percentage_complete)
                try:
                    chunk: bytes = stream.read(_READ_CHUNK_SIZE)
                except IncompleteRead as ex:
                    progress_callback(message=f'Received partial {len(ex.partial):,} bytes', percentage_complete=None)
                    content.extend(ex.partial)
                else:
                    if not chunk:
                        finished_reading = True
                    else:
                        content.extend(chunk)
        except (OSError, HTTPException) as ex:
            self._error_message = str(ex)
            return None

        progress_callback(message=None, percentage_complete=100)

        return bytes(content)

    def _decompress_data(self, content: bytes, decoder: _Decoder, progress_callback: ScrapeProgressCallback | None) -> bytes | None:
        try:
            content = decoder.decompress(content)
        except decoder.exception as ex:
            self._error_message = str(ex)
            return None

        if progress_callback:
            progress_callback(message=f"Decompressed data is {len(content):,} bytes", percentage_complete=None)

        return content
