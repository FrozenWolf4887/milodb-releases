# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import stat
from collections.abc import Iterable
from enum import Enum
from pathlib import Path
from typing import NamedTuple
from milodb.client.updater.i_temp_directory import ITempDirectory
from milodb.client.updater.manifest.update_sequence import IUpdateSequence
from milodb.common.output.print.i_printer import IPrinter

class PerformPreUpdateSafetyCheckError(Exception):
    pass

def perform_pre_update_safety_check(temp_directory: ITempDirectory, update_sequence: IUpdateSequence, printer: IPrinter) -> None:
    """Perform the update according to the specified update_sequence.

    ### Raises
    - PerformUpdateError
    """
    _verify_list_of_files((
        _FileForVerification(update_sequence.root_directory / file.filename, 'deletable', _VerifyAction.WRITEABLE, file.must_exist)
            for action in update_sequence.delete_files_actions.values() for file in action.files
        ), printer,
    )
    _verify_list_of_files((
        _FileForVerification(update_sequence.root_directory / file.original_filename, 'readable', _VerifyAction.READABLE, file.must_exist)
            for action in update_sequence.move_files_actions.values() for file in action.files
        ), printer,
    )
    _verify_list_of_files((
        _FileForVerification(update_sequence.root_directory / file.new_filename, 'writable', _VerifyAction.WRITEABLE, must_exist=False)
            for action in update_sequence.move_files_actions.values() for file in action.files
        ), printer,
    )
    _verify_list_of_files((
        _FileForVerification(temp_directory.path_of(file.source_filename), 'readable', _VerifyAction.READABLE, must_exist=True)
            for action in update_sequence.emplace_files_actions.values() for file in action.files
        ), printer,
    )
    _verify_list_of_files((
        _FileForVerification(update_sequence.root_directory / file.target_filename, 'writable', _VerifyAction.WRITEABLE, must_exist=False)
            for action in update_sequence.emplace_files_actions.values() for file in action.files
        ), printer,
    )
    _verify_list_of_files((
        _FileForVerification(update_sequence.root_directory / file.filename, 'writable', _VerifyAction.WRITEABLE, must_exist=False)
            for action in update_sequence.set_files_attribute_actions.values() for file in action.files
        ), printer,
    )

class _VerifyAction(Enum):
    READABLE = 'readable'
    WRITEABLE = 'writeable'

class _FileForVerification(NamedTuple):
    filepath: Path
    verb_name: str
    verify_action: _VerifyAction
    must_exist: bool

def _verify_list_of_files(list_of_files_for_verification: Iterable[_FileForVerification], printer: IPrinter) -> None:
    file: _FileForVerification
    for file in list_of_files_for_verification:
        printer.write(f"  Verify '{file.filepath}' is {file.verb_name} - ")
        try:
            match file.verify_action:
                case _VerifyAction.READABLE:
                    with file.filepath.open('rb'):
                        pass
                case _VerifyAction.WRITEABLE:
                    mode: int = file.filepath.stat().st_mode
                    new_mode: int = mode | stat.S_IWUSR
                    if mode != new_mode:
                        printer.write('clear RO flag - ')
                        file.filepath.chmod(new_mode)
                    with file.filepath.open('ab'):
                        pass
        except FileNotFoundError as ex:
            if file.must_exist:
                printer.writeln('FAIL')
                msg = f"'{file.filepath}' is missing when it is mandatory"
                raise PerformPreUpdateSafetyCheckError(msg) from ex
            printer.writeln('PASS (missing)')
        except OSError as ex:
            printer.writeln('FAIL')
            msg = f"'{file.filepath}' is not {file.verify_action.value}: {ex}"
            raise PerformPreUpdateSafetyCheckError(msg) from ex
        else:
            printer.writeln('PASS')
