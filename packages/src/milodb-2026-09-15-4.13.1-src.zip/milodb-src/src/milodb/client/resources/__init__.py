# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from pathlib import Path
from milodb.common.system import FROZEN_APP_PATH, IS_FROZEN_APP

RESOURCE_PATH: Path = (
    FROZEN_APP_PATH/'resources' if IS_FROZEN_APP
    else Path(__file__).parent
)
