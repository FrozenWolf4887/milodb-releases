# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import tkinter as tk
from enum import Enum
from typing import override

class EnumVar[E: Enum](tk.Variable):
    def __init__(self, master: tk.Misc, default_value: E) -> None:
        super().__init__(master)
        self._default_value: E = default_value

    @override
    def get(self) -> E:
        value: object = super().get() # type: ignore[no-untyped-call]
        if isinstance(value, str):
            for enum in self._default_value.__class__:
                if enum.name == value:
                    return enum
        return self._default_value

    @override
    def set(self, value: E) -> None:
        super().set(value.name)
