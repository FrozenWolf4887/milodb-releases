#!/usr/bin/env python3
# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import sys
import contextlib
from itertools import chain
from pathlib import Path
from typing import NoReturn
from unittest import TestCase, TestLoader, TestResult, TestSuite

THIS_DIRECTORY: Path = Path(__file__).parent
TESTS_SUBDIRECTORY: Path = Path('milodb_test')
TESTS_FILENAME_GLOB: str = 'test_*.py'
UI_TESTS_FILENAME_GLOB: str = 'ui_test_*.py'

def _list_tests(test_suite: TestSuite) -> None:
    test_entry: TestSuite | TestCase
    for test_entry in test_suite:
        if isinstance(test_entry, TestCase):
            print(test_entry.id())
        else:
            _list_tests(test_entry)

def run_tests(*, suppress_output: bool = False, list_of_test_name_patterns: list[str] | None = None, list_tests: bool=False) -> bool:
    TestLoader.testNamePatterns = list_of_test_name_patterns
    test_suite: TestSuite = TestLoader().discover(start_dir=str(TESTS_SUBDIRECTORY), top_level_dir=str(THIS_DIRECTORY), pattern=TESTS_FILENAME_GLOB)
    ui_test_suite: TestSuite = TestLoader().discover(start_dir=str(TESTS_SUBDIRECTORY), top_level_dir=str(THIS_DIRECTORY), pattern=UI_TESTS_FILENAME_GLOB)

    if list_tests:
        if not suppress_output:
            print('** Unit tests **')
            _list_tests(test_suite)
            print('** UI tests run explicitly by name **')
            _list_tests(ui_test_suite)
        return True

    test_result: TestResult = TestResult()
    test_suite.run(test_result)
    if list_of_test_name_patterns:
        ui_test_suite.run(test_result)

    if test_result.wasSuccessful():
        if not suppress_output:
            print(f'\x1b[32mPASS\x1b[0m: {test_result.testsRun:,} tests ran successfully')
        return True

    failed_test: tuple[TestCase, str]
    for failed_test in chain(test_result.errors, test_result.failures):
        test_case: TestCase = failed_test[0]
        test_failure_text: str = failed_test[1]
        if not suppress_output:
            print(80 * '=')
            print(f'\x1b[35;1m{test_case}\x1b[0m')
            print(80 * '-')
            print(test_failure_text, end='')
    if not suppress_output:
        print(80 * '-')
        print(f'\x1b[31;1mFAIL\x1b[0m: {test_result.testsRun:,} tests run of which {len(test_result.errors):,} errored and {len(test_result.failures)} failed\n')

    return False

def _is_debugger_active() -> bool:
    with contextlib.suppress(AttributeError):
        if sys.gettrace() is not None:
            return True
    with contextlib.suppress(AttributeError):
        if sys.monitoring.get_tool(sys.monitoring.DEBUGGER_ID) is not None:
            return True
    return False

def main() -> NoReturn:
    args: list[str] = sys.argv[1:]

    suppress_output: bool = False
    try:
        args.remove('--quiet')
    except ValueError:
        pass
    else:
        suppress_output = True

    list_tests: bool = False
    try:
        args.remove('--list')
    except ValueError:
        pass
    else:
        list_tests = True

    exit_code: int = 0
    if not run_tests(suppress_output=suppress_output, list_of_test_name_patterns=args or None, list_tests=list_tests) and not _is_debugger_active():
        exit_code = 1
    sys.exit(exit_code)

if __name__ == "__main__":
    main()
