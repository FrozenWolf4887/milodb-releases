# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import tkinter as tk
from collections.abc import Callable
from typing import override
from unittest import TestCase
from milodb.client.view.gui import theme

class TkinterTestCase(TestCase):
    @override
    def setUp(self) -> None:
        super().setUp()
        self.tk_root: tk.Tk

    def run_under_tk(self, method: Callable[[], None]) -> None:
        self.tk_root = tk.Tk()
        theme.configure_ttk_styles(self.tk_root)
        self.tk_root.geometry("100x50")
        tk.Label(self.tk_root, text="Main Window").pack()
        self.tk_root.update()
        self.tk_root.after_idle(method)
        self.tk_root.mainloop()
        self.tk_root.destroy()
