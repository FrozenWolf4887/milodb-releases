# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from typing import override
from milodb.client.view.gui.dialogs.prompt_dialog import PromptDialog
from milodb_test.client.test.tkinter_test_case import TkinterTestCase

_LORUM_IPSUM: str = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.'
_LORUM_IPSUM_WITH_LINEBREAK: str = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.\nSed do eiusmod tempor incididunt ut labore et dolore magna aliqua.'

class TestPromptDialog(TkinterTestCase):
    @override
    def setUp(self) -> None:
        super().setUp()
        self.icon: PromptDialog.Icon = PromptDialog.Icon.WARNING
        self.title: str = 'Test title'
        self.headline_text: str = 'Headline text'
        self.detail_text: str = 'Detail text'
        self.buttons: PromptDialog.Buttons = PromptDialog.Buttons.OKAY
        self.width: int = 400
        self.height: int = 160

        self.response: PromptDialog.Response = PromptDialog.Response.YES

    def _run_test(self) -> None:
        def test() -> None:
            try:
                self.response = PromptDialog(
                    self.tk_root,
                    icon = self.icon,
                    title = self.title,
                    headline_text = self.headline_text,
                    detail_text = self.detail_text,
                    buttons = self.buttons,
                    width = self.width,
                    height = self.height,
                ).wait_response()
            finally:
                self.tk_root.quit()

        self.run_under_tk(test)

    def test_okay_prompt_shows_okay_button(self) -> None:
        self.buttons = PromptDialog.Buttons.OKAY
        self._run_test()
        print(f'User pressed: {self.response}')

    def test_yes_no_prompt_shows_yes_no_buttons(self) -> None:
        self.buttons = PromptDialog.Buttons.YES_NO
        self._run_test()
        print(f'User pressed: {self.response}')

    def test_cancel_prompt_shows_cancel_button(self) -> None:
        self.buttons = PromptDialog.Buttons.CANCEL
        self._run_test()
        print(f'User pressed: {self.response}')

    def test_okay_cancel_prompt_shows_okay_cancel_button(self) -> None:
        self.buttons = PromptDialog.Buttons.OKAY_CANCEL
        self._run_test()
        print(f'User pressed: {self.response}')

    def test_warning_prompt_shows_warning_icon(self) -> None:
        self.icon = PromptDialog.Icon.WARNING
        self._run_test()

    def test_error_prompt_shows_error_icon(self) -> None:
        self.icon = PromptDialog.Icon.ERROR
        self._run_test()

    def test_prompt_can_have_different_titles(self) -> None:
        self.title = 'This is a different title'
        self._run_test()

    def test_prompt_can_have_different_headline_text(self) -> None:
        self.headline_text = 'This is a different headline'
        self._run_test()

    def test_prompt_can_have_different_detail_text(self) -> None:
        self.detail_text = 'This is different detail text'
        self._run_test()

    def test_prompt_will_wordwrap_long_headline_text(self) -> None:
        self.headline_text = _LORUM_IPSUM
        self._run_test()

    def test_prompt_will_show_headline_text_linebreaks(self) -> None:
        self.headline_text = _LORUM_IPSUM_WITH_LINEBREAK
        self._run_test()

    def test_prompt_will_show_detail_text_linebreaks(self) -> None:
        self.detail_text = _LORUM_IPSUM_WITH_LINEBREAK
        self._run_test()
