# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import unittest
from pathlib import Path
from typing import override
from unittest.mock import Mock, PropertyMock
from mockito import when # type: ignore[import-untyped]
from milodb.client.updater.i_temp_directory import ITempDirectory
from milodb.client.updater.manifest.update_sequence import IDeleteFile, IDeleteFilesAction, IEmplaceFile, IEmplaceFilesAction, IMoveFile, IMoveFilesAction, ISetFileAttribute, ISetFilesAttributeAction, IUpdateSequence
from milodb.client.updater.perform_pre_update_safety_check import PerformPreUpdateSafetyCheckError, perform_pre_update_safety_check
from milodb.common.output.print.i_printer import IPrinter
from milodb_test.client.test.fake_data import FAKE_DATA_A, FAKE_DATA_B
from milodb_test.client.test.test_directory import FakeFile, FakeTempFile, TestDirectory
from milodb_test.common.test.strict_mock import InterfaceMock

class TestPerformPreUpdateSafetyCheck(unittest.TestCase):
    @override
    def setUp(self) -> None:
        super().setUp()
        self.printer = InterfaceMock(IPrinter,
            write = Mock(),
            writeln = Mock(),
        )

    def test_move_files_succeeds_if_the_source_does_and_must_exist(self) -> None:
        with TestDirectory(self) as root_dir:
            source_file = FakeFile(root_dir, 'mango.txt', FAKE_DATA_A)
            target_relpath = Path('target.txt')

            update_sequence = InterfaceMock(IUpdateSequence,
                root_directory = PropertyMock(return_value=root_dir.path),
                move_files_actions = PropertyMock(return_value={
                    1: InterfaceMock(IMoveFilesAction,
                        files = PropertyMock(return_value=[
                            InterfaceMock(IMoveFile,
                                must_exist = PropertyMock(return_value=True),
                                original_filename = PropertyMock(return_value=source_file.relpath),
                                new_filename = PropertyMock(return_value=target_relpath),
                            ),
                        ]),
                    ),
                }),
                emplace_files_actions = PropertyMock(return_value={}),
                delete_files_actions = PropertyMock(return_value={}),
                set_files_attribute_actions = PropertyMock(return_value={}),
            )

            temp_directory = InterfaceMock(ITempDirectory)

            perform_pre_update_safety_check(temp_directory, update_sequence, self.printer)

            root_dir.assert_contains(
                expected_list_of_files = [
                    source_file,
                ],
                expected_list_of_dirpaths = [
                ])
            root_dir.assert_file_exists(source_file, FAKE_DATA_A, is_readonly=False)

    def test_move_files_succeeds_if_the_source_does_and_may_not_exist(self) -> None:
        with TestDirectory(self) as root_dir:
            source_file = FakeFile(root_dir, 'mango.txt', FAKE_DATA_A)
            target_relpath = Path('target.txt')

            update_sequence = InterfaceMock(IUpdateSequence,
                root_directory = PropertyMock(return_value=root_dir.path),
                move_files_actions = PropertyMock(return_value={
                    1: InterfaceMock(IMoveFilesAction,
                        files = PropertyMock(return_value=[
                            InterfaceMock(IMoveFile,
                                must_exist = PropertyMock(return_value=False),
                                original_filename = PropertyMock(return_value=source_file.relpath),
                                new_filename = PropertyMock(return_value=target_relpath),
                            ),
                        ]),
                    ),
                }),
                emplace_files_actions = PropertyMock(return_value={}),
                delete_files_actions = PropertyMock(return_value={}),
                set_files_attribute_actions = PropertyMock(return_value={}),
            )

            temp_directory = InterfaceMock(ITempDirectory)

            perform_pre_update_safety_check(temp_directory, update_sequence, self.printer)

            root_dir.assert_contains(
                expected_list_of_files = [
                    source_file,
                ],
                expected_list_of_dirpaths = [
                ])
            root_dir.assert_file_exists(source_file, FAKE_DATA_A, is_readonly=False)

    def test_move_files_succeeds_if_the_source_doesnt_and_may_not_exist(self) -> None:
        with TestDirectory(self) as root_dir:
            source_relpath = Path('mango.txt')
            target_relpath = Path('target.txt')

            update_sequence = InterfaceMock(IUpdateSequence,
                root_directory = PropertyMock(return_value=root_dir.path),
                move_files_actions = PropertyMock(return_value={
                    1: InterfaceMock(IMoveFilesAction,
                        files = PropertyMock(return_value=[
                            InterfaceMock(IMoveFile,
                                must_exist = PropertyMock(return_value=False),
                                original_filename = PropertyMock(return_value=source_relpath),
                                new_filename = PropertyMock(return_value=target_relpath),
                            ),
                        ]),
                    ),
                }),
                emplace_files_actions = PropertyMock(return_value={}),
                delete_files_actions = PropertyMock(return_value={}),
                set_files_attribute_actions = PropertyMock(return_value={}),
            )

            temp_directory = InterfaceMock(ITempDirectory)

            perform_pre_update_safety_check(temp_directory, update_sequence, self.printer)

            root_dir.assert_empty()

    def test_move_files_fails_if_the_source_doesnt_and_must_exist(self) -> None:
        with TestDirectory(self) as root_dir:
            source_relpath = Path('mango.txt')
            target_relpath = Path('target.txt')

            update_sequence = InterfaceMock(IUpdateSequence,
                root_directory = PropertyMock(return_value=root_dir.path),
                move_files_actions = PropertyMock(return_value={
                    1: InterfaceMock(IMoveFilesAction,
                        files = PropertyMock(return_value=[
                            InterfaceMock(IMoveFile,
                                must_exist = PropertyMock(return_value=True),
                                original_filename = PropertyMock(return_value=source_relpath),
                                new_filename = PropertyMock(return_value=target_relpath),
                            ),
                        ]),
                    ),
                }),
                emplace_files_actions = PropertyMock(return_value={}),
                delete_files_actions = PropertyMock(return_value={}),
                set_files_attribute_actions = PropertyMock(return_value={}),
            )

            temp_directory = InterfaceMock(ITempDirectory)

            with self.assertRaises(PerformPreUpdateSafetyCheckError) as ex:
                perform_pre_update_safety_check(temp_directory, update_sequence, self.printer)

            self.assertEqual(f"'{root_dir.path_of(source_relpath)}' is missing when it is mandatory", str(ex.exception))

            root_dir.assert_empty()

    def test_move_files_succeeds_if_the_target_file_exists(self) -> None:
        with TestDirectory(self) as root_dir:
            source_file = FakeFile(root_dir, 'mango.txt', FAKE_DATA_A)
            target_file = FakeFile(root_dir, 'target.txt', FAKE_DATA_B)

            update_sequence = InterfaceMock(IUpdateSequence,
                root_directory = PropertyMock(return_value=root_dir.path),
                move_files_actions = PropertyMock(return_value={
                    1: InterfaceMock(IMoveFilesAction,
                        files = PropertyMock(return_value=[
                            InterfaceMock(IMoveFile,
                                must_exist = PropertyMock(return_value=False),
                                original_filename = PropertyMock(return_value=source_file.relpath),
                                new_filename = PropertyMock(return_value=target_file.relpath),
                            ),
                        ]),
                    ),
                }),
                emplace_files_actions = PropertyMock(return_value={}),
                delete_files_actions = PropertyMock(return_value={}),
                set_files_attribute_actions = PropertyMock(return_value={}),
            )

            temp_directory = InterfaceMock(ITempDirectory)

            perform_pre_update_safety_check(temp_directory, update_sequence, self.printer)

            root_dir.assert_contains(
                expected_list_of_files = [
                    source_file,
                    target_file,
                ],
                expected_list_of_dirpaths = [
                ])
            root_dir.assert_file_exists(source_file, FAKE_DATA_A, is_readonly=False)
            root_dir.assert_file_exists(target_file, FAKE_DATA_B, is_readonly=False)

    def test_move_files_succeeds_and_removes_readonly_flag_if_the_target_file_exists(self) -> None:
        with TestDirectory(self) as root_dir:
            source_file = FakeFile(root_dir, 'mango.txt', FAKE_DATA_A)
            target_file = FakeFile(root_dir, 'target.txt', FAKE_DATA_B, is_readonly=True)

            update_sequence = InterfaceMock(IUpdateSequence,
                root_directory = PropertyMock(return_value=root_dir.path),
                move_files_actions = PropertyMock(return_value={
                    1: InterfaceMock(IMoveFilesAction,
                        files = PropertyMock(return_value=[
                            InterfaceMock(IMoveFile,
                                must_exist = PropertyMock(return_value=False),
                                original_filename = PropertyMock(return_value=source_file.relpath),
                                new_filename = PropertyMock(return_value=target_file.relpath),
                            ),
                        ]),
                    ),
                }),
                emplace_files_actions = PropertyMock(return_value={}),
                delete_files_actions = PropertyMock(return_value={}),
                set_files_attribute_actions = PropertyMock(return_value={}),
            )

            temp_directory = InterfaceMock(ITempDirectory)

            perform_pre_update_safety_check(temp_directory, update_sequence, self.printer)

            root_dir.assert_contains(
                expected_list_of_files = [
                    source_file,
                    target_file,
                ],
                expected_list_of_dirpaths = [
                ])
            root_dir.assert_file_exists(source_file, FAKE_DATA_A, is_readonly=False)
            root_dir.assert_file_exists(target_file, FAKE_DATA_B, is_readonly=False)

    def test_emplace_files_succeeds_if_the_target_file_exists(self) -> None:
        with TestDirectory(self) as root_dir, TestDirectory(self) as temp_dir:
            source_file = FakeTempFile(temp_dir, 'mango.txt', FAKE_DATA_A)
            target_file = FakeFile(root_dir, 'target.txt', FAKE_DATA_B)

            update_sequence = InterfaceMock(IUpdateSequence,
                root_directory = PropertyMock(return_value=root_dir.path),
                temp_directory = PropertyMock(return_value=temp_dir.path),
                move_files_actions = PropertyMock(return_value={}),
                emplace_files_actions = PropertyMock(return_value={
                    1: InterfaceMock(IEmplaceFilesAction,
                        files = PropertyMock(return_value=[
                            InterfaceMock(IEmplaceFile,
                                source_filename = PropertyMock(return_value=Path(source_file.filename)),
                                target_filename = PropertyMock(return_value=target_file.relpath),
                            ),
                        ]),
                    ),
                }),
                delete_files_actions = PropertyMock(return_value={}),
                set_files_attribute_actions = PropertyMock(return_value={}),
            )

            temp_directory = InterfaceMock(ITempDirectory,
                path_of = Mock(),
            )
            when(temp_directory).path_of(Path(source_file.filename)).thenReturn(source_file.filepath)

            perform_pre_update_safety_check(temp_directory, update_sequence, self.printer)

            temp_dir.assert_contains(
                expected_list_of_files = [
                    source_file,
                ],
                expected_list_of_dirpaths = [
                ])
            root_dir.assert_contains(
                expected_list_of_files = [
                    target_file,
                ],
                expected_list_of_dirpaths = [
                ])
            temp_dir.assert_file_exists(source_file, FAKE_DATA_A, is_readonly=False)
            root_dir.assert_file_exists(target_file, FAKE_DATA_B, is_readonly=False)

    def test_emplace_files_succeeds_and_removes_readonly_flag_if_the_target_file_exists(self) -> None:
        with TestDirectory(self) as root_dir, TestDirectory(self) as temp_dir:
            source_file = FakeTempFile(temp_dir, 'mango.txt', FAKE_DATA_A)
            target_file = FakeFile(root_dir, 'target.txt', FAKE_DATA_B, is_readonly=True)

            update_sequence = InterfaceMock(IUpdateSequence,
                root_directory = PropertyMock(return_value=root_dir.path),
                temp_directory = PropertyMock(return_value=temp_dir.path),
                move_files_actions = PropertyMock(return_value={}),
                emplace_files_actions = PropertyMock(return_value={
                    1: InterfaceMock(IEmplaceFilesAction,
                        files = PropertyMock(return_value=[
                            InterfaceMock(IEmplaceFile,
                                source_filename = PropertyMock(return_value=source_file.relpath),
                                target_filename = PropertyMock(return_value=target_file.relpath),
                            ),
                        ]),
                    ),
                }),
                delete_files_actions = PropertyMock(return_value={}),
                set_files_attribute_actions = PropertyMock(return_value={}),
            )

            temp_directory = InterfaceMock(ITempDirectory,
                path_of = Mock(),
            )
            when(temp_directory).path_of(source_file.relpath).thenReturn(source_file.filepath)

            perform_pre_update_safety_check(temp_directory, update_sequence, self.printer)

            root_dir.assert_contains(
                expected_list_of_files = [
                    target_file,
                ],
                expected_list_of_dirpaths = [
                ])
            temp_dir.assert_contains(
                expected_list_of_files = [
                    source_file,
                ],
                expected_list_of_dirpaths = [
                ])
            temp_dir.assert_file_exists(source_file, FAKE_DATA_A, is_readonly=False)
            root_dir.assert_file_exists(target_file, FAKE_DATA_B, is_readonly=False)

    def test_emplace_files_succeeds_if_target_file_doesnt_exist(self) -> None:
        with TestDirectory(self) as root_dir, TestDirectory(self) as temp_dir:
            source_file = FakeTempFile(temp_dir, 'mango.txt', FAKE_DATA_A)
            target_relpath = Path('target.txt')

            update_sequence = InterfaceMock(IUpdateSequence,
                root_directory = PropertyMock(return_value=root_dir.path),
                temp_directory = PropertyMock(return_value=temp_dir.path),
                move_files_actions = PropertyMock(return_value={}),
                emplace_files_actions = PropertyMock(return_value={
                    1: InterfaceMock(IEmplaceFilesAction,
                        files = PropertyMock(return_value=[
                            InterfaceMock(IEmplaceFile,
                                source_filename = PropertyMock(return_value=source_file.relpath),
                                target_filename = PropertyMock(return_value=target_relpath),
                            ),
                        ]),
                    ),
                }),
                delete_files_actions = PropertyMock(return_value={}),
                set_files_attribute_actions = PropertyMock(return_value={}),
            )

            temp_directory = InterfaceMock(ITempDirectory,
                path_of = Mock(),
            )
            when(temp_directory).path_of(source_file.relpath).thenReturn(source_file.filepath)

            perform_pre_update_safety_check(temp_directory, update_sequence, self.printer)

            root_dir.assert_contains(
                expected_list_of_files = [
                ],
                expected_list_of_dirpaths = [
                ])
            temp_dir.assert_contains(
                expected_list_of_files = [
                    source_file,
                ],
                expected_list_of_dirpaths = [
                ])
            temp_dir.assert_file_exists(source_file, FAKE_DATA_A, is_readonly=False)

    def test_emplace_files_fails_if_source_file_doesnt_exist(self) -> None:
        with TestDirectory(self) as root_dir, TestDirectory(self) as temp_dir:
            source_relpath = Path('mango.txt')
            target_relpath = Path('target.txt')

            update_sequence = InterfaceMock(IUpdateSequence,
                root_directory = PropertyMock(return_value=root_dir.path),
                temp_directory = PropertyMock(return_value=temp_dir.path),
                move_files_actions = PropertyMock(return_value={}),
                emplace_files_actions = PropertyMock(return_value={
                    1: InterfaceMock(IEmplaceFilesAction,
                        files = PropertyMock(return_value=[
                            InterfaceMock(IEmplaceFile,
                                source_filename = PropertyMock(return_value=source_relpath),
                                target_filename = PropertyMock(return_value=target_relpath),
                            ),
                        ]),
                    ),
                }),
                delete_files_actions = PropertyMock(return_value={}),
                set_files_attribute_actions = PropertyMock(return_value={}),
            )

            temp_directory = InterfaceMock(ITempDirectory,
                path_of = Mock(),
            )
            when(temp_directory).path_of(source_relpath).thenReturn(temp_dir.path_of(source_relpath))

            with self.assertRaises(PerformPreUpdateSafetyCheckError) as ex:
                perform_pre_update_safety_check(temp_directory, update_sequence, self.printer)

            self.assertEqual(f"'{temp_dir.path_of(source_relpath)}' is missing when it is mandatory", str(ex.exception))

            root_dir.assert_empty()
            temp_dir.assert_empty()

    def test_delete_files_removes_readonly_flag(self) -> None:
        with TestDirectory(self) as root_dir:
            file = FakeFile(root_dir, 'mango.txt', FAKE_DATA_A, is_readonly=True)

            update_sequence = InterfaceMock(IUpdateSequence,
                root_directory = PropertyMock(return_value=root_dir.path),
                move_files_actions = PropertyMock(return_value={}),
                emplace_files_actions = PropertyMock(return_value={}),
                delete_files_actions = PropertyMock(return_value={
                    1: InterfaceMock(IDeleteFilesAction,
                        files = PropertyMock(return_value=[
                            InterfaceMock(IDeleteFile,
                                filename = PropertyMock(return_value=file.relpath),
                                must_exist = PropertyMock(return_value=False),
                            ),
                        ]),
                    ),
                }),
                set_files_attribute_actions = PropertyMock(return_value={}),
            )

            temp_directory = InterfaceMock(ITempDirectory)

            perform_pre_update_safety_check(temp_directory, update_sequence, self.printer)

            root_dir.assert_contains(
                expected_list_of_files = [
                    file,
                ],
                expected_list_of_dirpaths = [
                ])
            root_dir.assert_file_exists(file, FAKE_DATA_A, is_readonly=False)

    def test_delete_files_succeeds_if_it_doesnt_exist_and_is_optional(self) -> None:
        with TestDirectory(self) as root_dir:
            filepath = Path('mango.txt')

            update_sequence = InterfaceMock(IUpdateSequence,
                root_directory = PropertyMock(return_value=root_dir.path),
                move_files_actions = PropertyMock(return_value={}),
                emplace_files_actions = PropertyMock(return_value={}),
                delete_files_actions = PropertyMock(return_value={
                    1: InterfaceMock(IDeleteFilesAction,
                        files = PropertyMock(return_value=[
                            InterfaceMock(IDeleteFile,
                                filename = PropertyMock(return_value=filepath),
                                must_exist = PropertyMock(return_value=False),
                            ),
                        ]),
                    ),
                }),
                set_files_attribute_actions = PropertyMock(return_value={}),
            )

            temp_directory = InterfaceMock(ITempDirectory)

            perform_pre_update_safety_check(temp_directory, update_sequence, self.printer)

            root_dir.assert_empty()

    def test_delete_files_fails_if_it_doesnt_exist_and_is_mandatory(self) -> None:
        with TestDirectory(self) as root_dir:
            filepath = Path('mango.txt')

            update_sequence = InterfaceMock(IUpdateSequence,
                root_directory = PropertyMock(return_value=root_dir.path),
                move_files_actions = PropertyMock(return_value={}),
                emplace_files_actions = PropertyMock(return_value={}),
                delete_files_actions = PropertyMock(return_value={
                    1: InterfaceMock(IDeleteFilesAction,
                        files = PropertyMock(return_value=[
                            InterfaceMock(IDeleteFile,
                                filename = PropertyMock(return_value=filepath),
                                must_exist = PropertyMock(return_value=True),
                            ),
                        ]),
                    ),
                }),
                set_files_attribute_actions = PropertyMock(return_value={}),
            )

            temp_directory = InterfaceMock(ITempDirectory)

            with self.assertRaises(PerformPreUpdateSafetyCheckError) as ex:
                perform_pre_update_safety_check(temp_directory, update_sequence, self.printer)

            self.assertEqual(f"'{root_dir.path_of(filepath)}' is missing when it is mandatory", str(ex.exception))

            root_dir.assert_empty()

    def test_set_files_attributes_succeeds_if_the_file_exists(self) -> None:
        with TestDirectory(self) as root_dir:
            file = FakeFile(root_dir, 'mango.txt', FAKE_DATA_A)

            update_sequence = InterfaceMock(IUpdateSequence,
                root_directory = PropertyMock(return_value=root_dir.path),
                move_files_actions = PropertyMock(return_value={}),
                emplace_files_actions = PropertyMock(return_value={}),
                delete_files_actions = PropertyMock(return_value={}),
                set_files_attribute_actions = PropertyMock(return_value={
                    1: InterfaceMock(ISetFilesAttributeAction,
                        files = PropertyMock(return_value=[
                            InterfaceMock(ISetFileAttribute,
                                filename = PropertyMock(return_value=file.relpath),
                                is_readonly = PropertyMock(return_value=True),
                                is_executable = PropertyMock(return_value=True),
                            ),
                        ]),
                    ),
                }),
            )

            temp_directory = InterfaceMock(ITempDirectory)

            perform_pre_update_safety_check(temp_directory, update_sequence, self.printer)

            root_dir.assert_contains(
                expected_list_of_files = [
                    file,
                ],
                expected_list_of_dirpaths = [
                ])
            root_dir.assert_file_exists(file, FAKE_DATA_A, is_readonly=False)

    def test_set_files_attributes_removes_readonly_flag_if_the_file_exists(self) -> None:
        with TestDirectory(self) as root_dir:
            file = FakeFile(root_dir, 'mango.txt', FAKE_DATA_A, is_readonly=True)

            update_sequence = InterfaceMock(IUpdateSequence,
                root_directory = PropertyMock(return_value=root_dir.path),
                move_files_actions = PropertyMock(return_value={}),
                emplace_files_actions = PropertyMock(return_value={}),
                delete_files_actions = PropertyMock(return_value={}),
                set_files_attribute_actions = PropertyMock(return_value={
                    1: InterfaceMock(ISetFilesAttributeAction,
                        files = PropertyMock(return_value=[
                            InterfaceMock(ISetFileAttribute,
                                filename = PropertyMock(return_value=file.relpath),
                                is_readonly = PropertyMock(return_value=True),
                                is_executable = PropertyMock(return_value=True),
                            ),
                        ]),
                    ),
                }),
            )

            temp_directory = InterfaceMock(ITempDirectory)

            perform_pre_update_safety_check(temp_directory, update_sequence, self.printer)

            root_dir.assert_contains(
                expected_list_of_files = [
                    file,
                ],
                expected_list_of_dirpaths = [
                ])
            root_dir.assert_file_exists(file, FAKE_DATA_A, is_readonly=False)

    def test_set_files_attributes_succeeds_if_the_file_doesnt_exist(self) -> None:
        with TestDirectory(self) as root_dir:
            relpath = Path('mango.txt')

            update_sequence = InterfaceMock(IUpdateSequence,
                root_directory = PropertyMock(return_value=root_dir.path),
                move_files_actions = PropertyMock(return_value={}),
                emplace_files_actions = PropertyMock(return_value={}),
                delete_files_actions = PropertyMock(return_value={}),
                set_files_attribute_actions = PropertyMock(return_value={
                    1: InterfaceMock(ISetFilesAttributeAction,
                        files = PropertyMock(return_value=[
                            InterfaceMock(ISetFileAttribute,
                                filename = PropertyMock(return_value=relpath),
                                is_readonly = PropertyMock(return_value=True),
                                is_executable = PropertyMock(return_value=True),
                            ),
                        ]),
                    ),
                }),
            )

            temp_directory = InterfaceMock(ITempDirectory)

            perform_pre_update_safety_check(temp_directory, update_sequence, self.printer)

            root_dir.assert_empty()
