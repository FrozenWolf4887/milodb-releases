# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import os
import subprocess
from abc import ABC, abstractmethod
from collections.abc import Iterable, Sequence
from pathlib import Path, PurePath
from typing import override
from milodb.client.startup.command_line import Argument
from milodb.client.view.progress_display import IProgressDisplay
from milodb.common.system import IS_FROZEN_APP, PLATFORM, Platform

class IShutdownAction(ABC):
    @abstractmethod
    def perform_action(self, progress_display: IProgressDisplay) -> int:
        pass

class RestartToPerformUpdateAction(IShutdownAction):
    def __init__(self, *, temp_application_filepath: Path, update_sequence_filepath: Path) -> None:
        self._temp_application_filepath: Path = temp_application_filepath
        self._update_sequence_filepath: Path = update_sequence_filepath

    @override
    def perform_action(self, progress_display: IProgressDisplay) -> int:
        progress_display.set_action_text('Updating')
        progress_display.set_activity_category('Restart')
        progress_display.set_activity_text('Launch')
        progress_display.normal_printer.writeln('Restarting application to perform update...')
        return _launch(self._temp_application_filepath, [Argument.PERFORM_UPDATE, self._update_sequence_filepath], progress_display)

class RestartToCompleteUpdateAction(IShutdownAction):
    def __init__(self, *, new_application_filepath: Path, temp_application_filepath: Path, update_sequence_filepath: Path, temp_directory: Path) -> None:
        self._new_application_filepath: Path = new_application_filepath
        self._temp_application_filepath: Path = temp_application_filepath
        self._update_sequence_filepath: Path = update_sequence_filepath
        self._temp_directory: Path = temp_directory

    @override
    def perform_action(self, progress_display: IProgressDisplay) -> int:
        progress_display.set_action_text('Updating')
        progress_display.set_activity_category('Restart')
        progress_display.set_activity_text('Launch')
        progress_display.normal_printer.writeln('Restarting application to complete update...')
        return _launch(self._new_application_filepath, [Argument.PURGE_TEMP_DIRECTORY, self._temp_directory], progress_display)

def _launch(application_filepath: Path, command_line: Iterable[str | Path], progress_display: IProgressDisplay) -> int:
    if PLATFORM is Platform.UNKNOWN:
        progress_display.print_fatal_and_prompt_on_exit(f"Unable to launch '{application_filepath}' because the platform is not recognised")
        return 1

    arguments_for_waiting_for_process_ids: list[str] = []
    for process_id in _get_list_of_process_ids():
        arguments_for_waiting_for_process_ids.extend((Argument.WAIT_PID, str(process_id)))

    all_launch_arguments: Sequence[PurePath | str] = [
        application_filepath.absolute(),
        *arguments_for_waiting_for_process_ids,
        *command_line,
    ]
    progress_display.normal_printer.writeln(f"Current directory is '{Path.cwd()}'")
    progress_display.normal_printer.writeln(f"Launching '{application_filepath.name}' with [")
    progress_display.normal_printer.writeln(f"{'\n  '.join(f"'{str(arg).replace("'", r"\'")}'" for arg in all_launch_arguments)}\n]")
    try:
        subprocess.Popen( # pylint: disable=consider-using-with
            args = all_launch_arguments,
            start_new_session = True,
        )
    except OSError as ex:
        progress_display.print_fatal_and_prompt_on_exit(f'Failed to start application: {ex}')
        return 1

    return 0

def _get_list_of_process_ids() -> list[int]:
    """Get the process ids for this process.

    Frozen applications, i.e. those running under pyinstaller, are child processes of the
    pyinstaller bootstrap:
    https://pyinstaller.org/en/v6.3.0/advanced-topics.html#the-bootstrap-process-in-detail

    When the child process terminates, the executable from which it was launched continues
    to be locked by the operating system until the parent bootstrap process terminates.
    Therefore, to ensure the frozen application has terminated it is necessary to wait for
    its parent process to terminate.
    """
    if IS_FROZEN_APP:
        return [ os.getpid(), os.getppid() ]
    return [ os.getpid() ]
