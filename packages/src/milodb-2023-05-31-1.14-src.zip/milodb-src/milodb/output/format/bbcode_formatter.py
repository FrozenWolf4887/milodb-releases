# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from milodb.config.bbcode_config import BBCodeConfig
from milodb.database.tease import Tease, TeaseProperty, TeaseStrListProperty, TotmStatus
from milodb.output.format.i_formatter import IFormatter
from milodb.output.print.i_printer import IPrinter
from milodb.output.support import EllipsisLocation, ellipsify_text, get_list_of_indexed_metadata_indices, get_list_of_metadata_indices, get_url_of_author, get_url_of_tease, iterate_through_indices, iterate_through_lines
from milodb.query.field_match import IFieldMatch
from milodb.query.tease_match import TeaseMatch

_MAP_OF_TOTM_STATUS_TO_TEXT: dict[TotmStatus, str] = {
    TotmStatus.NONE: ' ',
    TotmStatus.NOMINEE: 'n',
    TotmStatus.WINNER: 'w'
}

class BBCodeFormatter(IFormatter):
    def __init__(self, bbcode_config: BBCodeConfig) -> None:
        self._bbcode_config: BBCodeConfig = bbcode_config

    def get_name(self) -> str:
        return 'bbcode'

    def print_list_of_teases(self, list_of_tease_matches: list[TeaseMatch], use_highlighting: bool, normal_printer: IPrinter) -> None:
        tease_match: TeaseMatch
        for tease_match in list_of_tease_matches:
            self._print_oneline_of_tease(tease_match, use_highlighting, normal_printer)

    def print_summary_of_tease(self, tease_match: TeaseMatch, use_highlighting: bool, normal_printer: IPrinter) -> None:
        match_index: str = str(tease_match.index_of_match) if tease_match.index_of_match else 'none'
        tease_id: int = tease_match.tease.tease_id()
        author_id: int = tease_match.tease.author_id()
        url_of_tease: str = get_url_of_tease(tease_id)
        url_of_author: str = get_url_of_author(author_id)
        formatted_tease_id: str = self._highlight_metadata(tease_match, Tease.tease_id, use_highlighting, 6, '#')
        formatted_tease_title: str = self._highlight_metadata(tease_match, Tease.title, use_highlighting)
        formatted_author_link: str = 'unknown'
        if tease_match.tease.has_author():
            formatted_author_id: str = self._highlight_metadata(tease_match, Tease.author_id, use_highlighting, 6, '@')
            formatted_author_link = f'[url={url_of_author}]{formatted_author_id}[/url]'
        formatted_author_name: str = f"'{self._highlight_metadata(tease_match, Tease.author_name, use_highlighting)}'" if tease_match.tease.has_author() else 'unknown'
        formatted_tease_date: str = self._highlight_metadata(tease_match, Tease.date, use_highlighting)
        formatted_tease_type: str = self._highlight_metadata(tease_match, Tease.type, use_highlighting, 7)
        formatted_tease_rating: str = self._highlight_metadata(tease_match, Tease.rating_value, use_highlighting, 7)
        formatted_tags: str = ', '.join(self._highlight_metadata_string_list(tease_match, Tease.list_of_tags, use_highlighting, None, False))
        formatted_summary: str = self._highlight_metadata(tease_match, Tease.summary, use_highlighting)
        deleted_text: str = f'[[i][/i][color={self._bbcode_config.deleted_heading_colour}][b]DELETED[/b][/color]] ' if tease_match.tease.is_deleted() else ''
        normal_printer.writeln(f"[pre][color={self._bbcode_config.index_heading_colour}]Index   [/color]{match_index:>7}   [color={self._bbcode_config.hits_heading_colour}]Hits   [/color]{tease_match.get_match_count()}[/pre]")
        normal_printer.writeln(f"[pre][color={self._bbcode_config.tease_heading_colour}]Tease   [/color][url={url_of_tease}]{formatted_tease_id}[/url]   [color={self._bbcode_config.tease_heading_colour}]Title  [/color][/pre]{deleted_text}'{formatted_tease_title}'")
        normal_printer.writeln(f"[pre][color={self._bbcode_config.author_heading_colour}]Author  [/color]{formatted_author_link}   [color={self._bbcode_config.author_heading_colour}]Name   [/color][/pre]{formatted_author_name}")
        normal_printer.writeln(f"[pre][color={self._bbcode_config.type_heading_colour}]Type    [/color]{formatted_tease_type}   [color={self._bbcode_config.date_heading_colour}]Date   [/color][/pre]{formatted_tease_date}")
        normal_printer.writeln(f"[pre][color={self._bbcode_config.rating_heading_colour}]Rating  [/color]{formatted_tease_rating}   [color={self._bbcode_config.tags_heading_colour}]Tags   [/color][/pre]{formatted_tags}")
        normal_printer.writeln(f"[pre][color={self._bbcode_config.summary_heading_colour}]Summary[/color][/pre]")
        normal_printer.writeln(formatted_summary or 'None')

    def print_all_text_of_list_of_teases(self, list_of_tease_matches: list[TeaseMatch], use_highlighting: bool, normal_printer: IPrinter) -> None:
        index: int
        tease_match: TeaseMatch
        for index, tease_match in enumerate(list_of_tease_matches):
            if index > 0:
                normal_printer.writeln()
            self.print_summary_of_tease(tease_match,  use_highlighting, normal_printer)
            self._print_all_text_of_tease(tease_match, use_highlighting, normal_printer)

    def print_matching_text_of_list_of_teases(self, list_of_tease_matches: list[TeaseMatch], use_highlighting: bool, ellipsis_max_width: (int | None), normal_printer: IPrinter) -> None:
        index: int
        tease_match: TeaseMatch
        for index, tease_match in enumerate(list_of_tease_matches):
            if index > 0:
                normal_printer.writeln()
            self.print_summary_of_tease(tease_match, use_highlighting, normal_printer)
            self._print_matching_text_of_tease(tease_match, use_highlighting, ellipsis_max_width, normal_printer)

    def _print_all_text_of_tease(self, tease_match: TeaseMatch, use_highlighting: bool, normal_printer: IPrinter) -> None:
        list_of_formatted_text: list[str] = self._highlight_metadata_string_list(tease_match, Tease.list_of_text_blocks, use_highlighting, None, False)
        if list_of_formatted_text:
            normal_printer.writeln(f'[color={self._bbcode_config.matching_text_heading_colour}]Text[/color]')
            normal_printer.writeln(f"[pre]{40 * '-'}[/pre]")
            for formatted_text_block in list_of_formatted_text:
                normal_printer.writeln(formatted_text_block)
                normal_printer.writeln(f"[pre]{40 * '-'}[/pre]")

    def _print_matching_text_of_tease(self, tease_match: TeaseMatch, use_highlighting: bool, ellipsis_max_width: (int | None), normal_printer: IPrinter) -> None:
        list_of_formatted_text: list[str] = self._highlight_metadata_string_list(tease_match, Tease.list_of_text_blocks, use_highlighting, ellipsis_max_width, True)
        if list_of_formatted_text:
            normal_printer.writeln(f'[color={self._bbcode_config.matching_text_heading_colour}]Matching text[/color]')
            normal_printer.writeln(f"[pre]{40 * '-'}[/pre]")
            for formatted_text_block in list_of_formatted_text:
                normal_printer.writeln(formatted_text_block)
                normal_printer.writeln(f"[pre]{40 * '-'}[/pre]")

    def _print_oneline_of_tease(self, tease_match: TeaseMatch, use_highlighting: bool, normal_printer: IPrinter) -> None:
        match_index: str = str(tease_match.index_of_match) if tease_match.index_of_match else '-'
        hits: str = '*' + str(tease_match.get_match_count())
        tease_id: int = tease_match.tease.tease_id()
        author_id: int = tease_match.tease.author_id()
        url_of_tease: str = get_url_of_tease(tease_id)
        url_of_author: str = get_url_of_author(author_id)
        formatted_tease_id: str = self._highlight_metadata(tease_match, Tease.tease_id, use_highlighting, 5, '#')
        formatted_tease_type: str = self._highlight_metadata(tease_match, Tease.type, use_highlighting)
        formatted_tease_rating: str = self._highlight_metadata(tease_match, Tease.rating_value, use_highlighting)
        formatted_tease_date: str = self._highlight_metadata(tease_match, Tease.date, use_highlighting)
        formatted_tease_title: str = self._highlight_metadata(tease_match, Tease.title, use_highlighting)
        formatted_author_text: str = 'unknown author'
        if tease_match.tease.has_author():
            formatted_author_name: str = self._highlight_metadata(tease_match, Tease.author_name, use_highlighting)
            formatted_author_id: str = self._highlight_metadata(tease_match, Tease.author_id, use_highlighting)
            formatted_author_text = f"{formatted_author_name}, [url={url_of_author}]@{formatted_author_id}[/url]"
        totm_text: str = _MAP_OF_TOTM_STATUS_TO_TEXT.get(tease_match.tease.totm_status(), ' ')
        deleted_text: str = f'[[i][/i][color={self._bbcode_config.deleted_heading_colour}][b]DELETED[/b][/color]] ' if tease_match.tease.is_deleted() else ''
        normal_printer.writeln((
            "[pre]"
            f'{match_index:>3}:'
            f' {hits:>4}'
            f'  [url={url_of_tease}]{formatted_tease_id}[/url]'
            f'  {formatted_tease_type}'
            f'  {formatted_tease_rating}'
            f'  {totm_text}'
            f'  {formatted_tease_date}'
            f'  [/pre]{deleted_text}{formatted_tease_title}'
            f' : [[i][/i]{formatted_author_text}]'))

    def _highlight_text(self, text: str, list_of_indices: list[IFieldMatch.Indices], use_highlighting: bool, ellipsis_max_width: (int | None)) -> str:
        formatted_text = ''

        def on_normal_text(text: str, is_first_item: bool, is_last_item: bool) -> None:
            nonlocal formatted_text
            if ellipsis_max_width:
                formatted_text += self._ellipsify_and_escape_text_item(text, is_first_item, is_last_item, ellipsis_max_width)
            else:
                formatted_text += _escape_text(text)

        def on_matched_text(text: str, _is_first_item: bool, _is_last_item: bool) -> None:
            nonlocal formatted_text
            if use_highlighting:
                iterate_through_lines(text, on_highlight_text, on_end_of_line_text)
            else:
                formatted_text += _escape_text(text)

        def on_highlight_text(text: str) -> None:
            nonlocal formatted_text
            formatted_text += f'[b][color={self._bbcode_config.matching_text_colour}]'
            formatted_text += _escape_text(text)
            formatted_text += '[/color][/b]'

        def on_end_of_line_text(text: str) -> None:
            nonlocal formatted_text
            formatted_text += text

        iterate_through_indices(text, list_of_indices, on_normal_text, on_matched_text)

        return formatted_text

    def _ellipsify_and_escape_text_item(self, text: str, is_first_item: bool, is_last_item: bool, ellipsis_max_width: int) -> str:
        formatted_text: str = ''

        def on_text(text: str) -> None:
            nonlocal formatted_text
            formatted_text += _escape_text(text)

        def on_ellipsis() -> None:
            nonlocal formatted_text
            formatted_text += f'[color={self._bbcode_config.ellipsis_colour}]\u2026[/color]'

        ellipsify_text(text, ellipsis_max_width, EllipsisLocation.from_position(is_first_item, is_last_item), on_text, on_ellipsis)

        return formatted_text

    def _highlight_metadata(self, tease_match: TeaseMatch, tease_property: TeaseProperty, use_highlighting: bool, width: int = 0, prefix_text: str = '') -> str:
        field_value: str = tease_match.tease.get_text_of_property(tease_property)
        formatted_value: str = self._highlight_text(field_value, get_list_of_metadata_indices(tease_property, tease_match.list_of_field_matches), use_highlighting, None)

        if width:
            if prefix_text:
                formatted_value = prefix_text + formatted_value

            pad_char_count = abs(width) - len(field_value)
            if pad_char_count > 0:
                if width < 0:
                    formatted_value = formatted_value + (pad_char_count * ' ')
                else:
                    formatted_value = (pad_char_count * ' ') + formatted_value

        return formatted_value

    def _highlight_metadata_string_list(self, tease_match: TeaseMatch, tease_property: TeaseStrListProperty, use_highlighting: bool, ellipsis_max_width: (int | None), include_matching_only: bool) -> list[str]:
        list_of_formatted_text: list[str] = []

        index_of_block: int
        text_block: str
        for index_of_block, text_block in enumerate(tease_property(tease_match.tease)):
            list_of_indices: list[IFieldMatch.Indices] = get_list_of_indexed_metadata_indices(tease_property, index_of_block, tease_match.list_of_field_matches)
            formatted_text: (str | None) = None
            if list_of_indices:
                formatted_text = self._highlight_text(text_block, list_of_indices, use_highlighting, ellipsis_max_width if ellipsis_max_width and include_matching_only else None)
            elif not include_matching_only:
                formatted_text = _escape_text(text_block)

            if formatted_text is not None:
                list_of_formatted_text.append(formatted_text)

        return list_of_formatted_text

def _escape_text(text: str) -> str:
    return text.replace('[', '[[i][/i]')
