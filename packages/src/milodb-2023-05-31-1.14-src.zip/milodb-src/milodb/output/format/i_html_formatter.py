# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from abc import abstractmethod
from milodb.output.format.i_formatter import IFormatter
from milodb.output.print.i_printer import IPrinter
from milodb.query.tease_match import TeaseMatch

class IHtmlFormatter(IFormatter):
    @abstractmethod
    def try_write_browse_file_of_text_matches(self, list_of_tease_matches: list[TeaseMatch], use_highlighting: bool, ellipsis_max_width: int | None, normal_printer: IPrinter, error_printer: IPrinter, icon_data_uri: str) -> bool:
        pass

    @abstractmethod
    def try_write_browse_file_of_all_text(self, list_of_tease_matches: list[TeaseMatch], use_highlighting: bool, normal_printer: IPrinter, error_printer: IPrinter, icon_data_uri: str) -> bool:
        pass
