# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
import colorama
from milodb.config.ansi_config import AnsiConfig
from milodb.database.tease import Tease, TeaseProperty, TeaseStrListProperty, TotmStatus
from milodb.output.format.i_formatter import IFormatter
from milodb.output.print.i_printer import IPrinter
from milodb.output.support import EllipsisLocation, ellipsify_text, get_list_of_indexed_metadata_indices, get_list_of_metadata_indices, get_url_of_author, get_url_of_tease, iterate_through_indices, iterate_through_lines
from milodb.query.field_match import IFieldMatch
from milodb.query.tease_match import TeaseMatch

colorama.init(strip=False)

_MAP_OF_TOTM_STATUS_TO_TEXT: dict[TotmStatus, str] = {
    TotmStatus.NONE: ' ',
    TotmStatus.NOMINEE: 'n',
    TotmStatus.WINNER: 'w'
}

class AnsiFormatter(IFormatter):
    def __init__(self, ansi_config: AnsiConfig) -> None:
        self._ansi_config: AnsiConfig = ansi_config

    def get_name(self) -> str:
        return 'ansi'

    def print_list_of_teases(self, list_of_tease_matches: list[TeaseMatch], use_highlighting: bool, normal_printer: IPrinter) -> None:
        tease_match: TeaseMatch
        for tease_match in list_of_tease_matches:
            self._print_oneline_of_tease(tease_match, use_highlighting, normal_printer)

    def print_summary_of_tease(self, tease_match: TeaseMatch, use_highlighting: bool, normal_printer: IPrinter) -> None:
        match_index: str = str(tease_match.index_of_match) if tease_match.index_of_match else 'none'
        tease_id: int = tease_match.tease.tease_id()
        author_id: int = tease_match.tease.author_id()
        formatted_tease_id: str = self._highlight_metadata(tease_match, Tease.tease_id, use_highlighting, 6, '#')
        formatted_tease_title: str = self._highlight_metadata(tease_match, Tease.title, use_highlighting)
        formatted_author_id: str = self._highlight_metadata(tease_match, Tease.author_id, use_highlighting, 6, '@') if tease_match.tease.has_author() else 'unknown'
        formatted_author_name: str = f"'{self._highlight_metadata(tease_match, Tease.author_name, use_highlighting)}'" if tease_match.tease.has_author() else 'unknown'
        formatted_tease_date: str = self._highlight_metadata(tease_match, Tease.date, use_highlighting)
        formatted_tease_type: str = self._highlight_metadata(tease_match, Tease.type, use_highlighting, 7)
        formatted_tease_rating: str = self._highlight_metadata(tease_match, Tease.rating_value, use_highlighting, 7)
        formatted_tags: str = ', '.join(self._highlight_metadata_string_list(tease_match, Tease.list_of_tags, use_highlighting, None, False))
        formatted_summary: str = self._highlight_metadata(tease_match, Tease.summary, use_highlighting)
        deleted_text: str = f'[\x1b[{self._ansi_config.deleted_heading_colour}mDELETED\x1b[0m] ' if tease_match.tease.is_deleted() else ''
        url_of_tease: str = get_url_of_tease(tease_id)
        url_of_author: str = get_url_of_author(author_id) if tease_match.tease.has_author() else 'link unavailable (author unknown)'
        normal_printer.writeln(f"\x1b[{self._ansi_config.index_heading_colour}mIndex   \x1b[0m{match_index:>7}   \x1b[{self._ansi_config.hits_heading_colour}mHits   \x1b[0m{tease_match.get_match_count()}")
        normal_printer.writeln(f"\x1b[{self._ansi_config.tease_heading_colour}mTease   \x1b[0m{formatted_tease_id}   \x1b[{self._ansi_config.tease_heading_colour}mTitle  {deleted_text}\x1b[0m'{formatted_tease_title}'")
        normal_printer.writeln(f"\x1b[{self._ansi_config.author_heading_colour}mAuthor  \x1b[0m{formatted_author_id}   \x1b[{self._ansi_config.author_heading_colour}mName   \x1b[0m{formatted_author_name}")
        normal_printer.writeln(f"\x1b[{self._ansi_config.type_heading_colour}mType    \x1b[0m{formatted_tease_type}   \x1b[{self._ansi_config.date_heading_colour}mDate   \x1b[0m{formatted_tease_date}")
        normal_printer.writeln(f"\x1b[{self._ansi_config.rating_heading_colour}mRating  \x1b[0m{formatted_tease_rating}   \x1b[{self._ansi_config.tags_heading_colour}mTags   \x1b[0m{formatted_tags}")
        normal_printer.writeln(f"\x1b[{self._ansi_config.tease_heading_colour}mTease   \x1b[0m{url_of_tease}")
        if tease_match.tease.has_author():
            normal_printer.writeln(f"\x1b[{self._ansi_config.author_heading_colour}mAuthor  \x1b[0m{url_of_author}")
        normal_printer.writeln(f"\x1b[{self._ansi_config.summary_heading_colour}mSummary\x1b[0m")
        normal_printer.writeln(formatted_summary or 'None')

    def print_all_text_of_list_of_teases(self, list_of_tease_matches: list[TeaseMatch], use_highlighting: bool, normal_printer: IPrinter) -> None:
        index: int
        tease_match: TeaseMatch
        for index, tease_match in enumerate(list_of_tease_matches):
            if index > 0:
                normal_printer.writeln()
            self.print_summary_of_tease(tease_match, use_highlighting, normal_printer)
            self._print_all_text_of_tease(tease_match, use_highlighting, normal_printer)

    def print_matching_text_of_list_of_teases(self, list_of_tease_matches: list[TeaseMatch], use_highlighting: bool, ellipsis_max_width: (int | None), normal_printer: IPrinter) -> None:
        index: int
        tease_match: TeaseMatch
        for index, tease_match in enumerate(list_of_tease_matches):
            if index > 0:
                normal_printer.writeln()
            self.print_summary_of_tease(tease_match, use_highlighting, normal_printer)
            self._print_matching_text_of_tease(tease_match, use_highlighting, ellipsis_max_width, normal_printer)

    def _print_all_text_of_tease(self, tease_match: TeaseMatch, use_highlighting: bool, normal_printer: IPrinter) -> None:
        list_of_formatted_text: list[str] = self._highlight_metadata_string_list(tease_match, Tease.list_of_text_blocks, use_highlighting, None, False)
        if list_of_formatted_text:
            normal_printer.writeln(f'\x1b[{self._ansi_config.matching_text_heading_colour}mText\x1b[0m')
            normal_printer.writeln(40 * '-')
            normal_printer.writeln(('\n' + 40 * '-' + '\n').join(list_of_formatted_text))
            normal_printer.writeln(40 * '-')

    def _print_matching_text_of_tease(self, tease_match: TeaseMatch, use_highlighting: bool, ellipsis_max_width: (int | None), normal_printer: IPrinter) -> None:
        list_of_formatted_text: list[str] = self._highlight_metadata_string_list(tease_match, Tease.list_of_text_blocks, use_highlighting, ellipsis_max_width, True)
        if list_of_formatted_text:
            normal_printer.writeln(f'\x1b[{self._ansi_config.matching_text_heading_colour}mMatching text\x1b[0m')
            normal_printer.writeln(40 * '-')
            normal_printer.writeln(('\n' + 40 * '-' + '\n').join(list_of_formatted_text))
            normal_printer.writeln(40 * '-')

    def _print_oneline_of_tease(self, tease_match: TeaseMatch, use_highlighting: bool, normal_printer: IPrinter) -> None:
        match_index: str = str(tease_match.index_of_match) if tease_match.index_of_match else '-'
        hits: str = '*' + str(tease_match.get_match_count())
        formatted_tease_id: str = self._highlight_metadata(tease_match, Tease.tease_id, use_highlighting, 5, '#')
        formatted_tease_type: str = self._highlight_metadata(tease_match, Tease.type, use_highlighting)
        formatted_tease_rating: str = self._highlight_metadata(tease_match, Tease.rating_value, use_highlighting, 3)
        formatted_tease_date: str = self._highlight_metadata(tease_match, Tease.date, use_highlighting)
        formatted_tease_title: str = self._highlight_metadata(tease_match, Tease.title, use_highlighting)
        formatted_author_text: str = 'unknown author'
        if tease_match.tease.has_author():
            formatted_author_name: str = self._highlight_metadata(tease_match, Tease.author_name, use_highlighting)
            formatted_author_id: str = self._highlight_metadata(tease_match, Tease.author_id, use_highlighting)
            formatted_author_text = f"{formatted_author_name}, @{formatted_author_id}"
        totm_text: str = _MAP_OF_TOTM_STATUS_TO_TEXT.get(tease_match.tease.totm_status(), ' ')
        deleted_text: str = f'[\x1b[{self._ansi_config.deleted_heading_colour}mDELETED\x1b[0m] ' if tease_match.tease.is_deleted() else ''
        normal_printer.writeln((
            f'{match_index:>3}:'
            f' {hits:>4}'
            f'  {formatted_tease_id}'
            f'  {formatted_tease_type}'
            f'  {formatted_tease_rating}'
            f'  {totm_text}'
            f'  {formatted_tease_date}'
            f'  {deleted_text}{formatted_tease_title}'
            f' : [{formatted_author_text}]'))

    def _highlight_metadata(self, tease_match: TeaseMatch, tease_property: TeaseProperty, use_highlighting: bool, width: int = 0, prefix_text: str = '') -> str:
        field_value: str = tease_match.tease.get_text_of_property(tease_property)
        formatted_value: str = self._highlight_text(field_value, get_list_of_metadata_indices(tease_property, tease_match.list_of_field_matches), use_highlighting, None)

        if width:
            if prefix_text:
                formatted_value = prefix_text + formatted_value

            pad_char_count = abs(width) - len(field_value)
            if pad_char_count > 0:
                if width < 0:
                    formatted_value = formatted_value + (pad_char_count * ' ')
                else:
                    formatted_value = (pad_char_count * ' ') + formatted_value

        return formatted_value

    def _highlight_metadata_string_list(self, tease_match: TeaseMatch, tease_property: TeaseStrListProperty, use_highlighting: bool, ellipsis_max_width: (int | None), include_matching_only: bool) -> list[str]:
        list_of_formatted_text: list[str] = []

        index_of_block: int
        text_block: str
        for index_of_block, text_block in enumerate(tease_property(tease_match.tease)):
            list_of_indices: list[IFieldMatch.Indices] = get_list_of_indexed_metadata_indices(tease_property, index_of_block, tease_match.list_of_field_matches)
            formatted_text: (str | None) = None
            if list_of_indices:
                formatted_text = self._highlight_text(text_block, list_of_indices, use_highlighting, ellipsis_max_width if ellipsis_max_width and include_matching_only else None)
            elif not include_matching_only:
                formatted_text = _escape_text(text_block)

            if formatted_text is not None:
                list_of_formatted_text.append(formatted_text)

        return list_of_formatted_text

    def _highlight_text(self, text: str, list_of_indices: list[IFieldMatch.Indices], use_highlighting: bool, ellipsis_max_width: (int | None)) -> str:
        formatted_text = ''

        def on_normal_text(text: str, is_first_item: bool, is_last_item: bool) -> None:
            nonlocal formatted_text
            if ellipsis_max_width:
                formatted_text += self._ellipsify_and_escape_text_item(text, is_first_item, is_last_item, ellipsis_max_width)
            else:
                formatted_text += _escape_text(text)

        def on_matched_text(text: str, _is_first_item: bool, _is_last_item: bool) -> None:
            nonlocal formatted_text
            if use_highlighting:
                iterate_through_lines(text, on_highlight_text, on_end_of_line_text)
            else:
                formatted_text += _escape_text(text)

        def on_highlight_text(text: str) -> None:
            nonlocal formatted_text
            formatted_text += f'\x1b[{self._ansi_config.matching_text_colour}m'
            formatted_text += _escape_text(text)
            formatted_text += '\x1b[0m'

        def on_end_of_line_text(text: str) -> None:
            nonlocal formatted_text
            formatted_text += text

        iterate_through_indices(text, list_of_indices, on_normal_text, on_matched_text)

        return formatted_text

    def _ellipsify_and_escape_text_item(self, text: str, is_first_item: bool, is_last_item: bool, ellipsis_max_width: int) -> str:
        formatted_text: str = ''

        def on_text(text: str) -> None:
            nonlocal formatted_text
            formatted_text += _escape_text(text)

        def on_ellipsis() -> None:
            nonlocal formatted_text
            formatted_text += f'\x1b[{self._ansi_config.ellipsis_colour}m\u2026\x1b[0m'

        ellipsify_text(text, ellipsis_max_width, EllipsisLocation.from_position(is_first_item, is_last_item), on_text, on_ellipsis)

        return formatted_text

def _escape_text(text: str) -> str:
    return text.replace('\x1b', '')
