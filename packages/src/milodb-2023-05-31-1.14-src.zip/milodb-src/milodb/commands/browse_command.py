# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
import tempfile
import webbrowser
from abc import abstractmethod
from milodb.command_framework.argument_stream import ArgumentStream
from milodb.command_framework.i_command import ICommand
from milodb.command_framework.i_help_info import IHelpInfo
from milodb.command_framework.ref_id import RefId
from milodb.commands.database_support import try_create_list_of_tease_matches_from_ref_ids
from milodb.database.tease import Tease
from milodb.output.format.i_html_formatter import IHtmlFormatter
from milodb.output.print.file_printer import FilePrinter
from milodb.output.print.i_printer import IPrinter
from milodb.query.tease_match import TeaseMatch

ICON_DATA_URI: str = r"data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' xml:space='preserve' width='122mm' height='123mm' viewBox='0 0 122 123'%3e%3cg transform='translate(-47 -120)'%3e%3cpath d='m131 192 37 37a6.35 6.35 90 0 1 0 8l-5 5a6.35 6.35 0 0 1-8 0l-37-37z' style='fill:%23fff;stroke-width:0;stroke-linecap:round;stroke-linejoin:round'/%3e%3ccircle cx='97' cy='170' r='50' style='fill:%23fff;fill-opacity:1;stroke:none;stroke-width:0;stroke-linecap:round;stroke-linejoin:round;stroke-dasharray:none;stroke-opacity:1'/%3e%3cpath d='m131 197 8 7-9 9-7-8z' style='fill:%23616161;stroke-width:0;stroke-linecap:round;stroke-linejoin:round'/%3e%3ccircle cx='97' cy='170' r='47' style='fill:%23616161;fill-opacity:1;stroke:none;stroke-width:0;stroke-linecap:round;stroke-linejoin:round;stroke-dasharray:none;stroke-opacity:1'/%3e%3ccircle cx='97' cy='170' r='40' style='fill:%23f1c3c3;fill-opacity:1;stroke:none;stroke-width:0;stroke-linecap:round;stroke-linejoin:round;stroke-dasharray:none;stroke-opacity:1'/%3e%3cpath d='M88 190c-1-3-1-7-10-15-11.9-13-1-32 13-22 6 3 8 3 12 1 20-16 27 18 3 34-11 9-16 13-18 2z' style='fill:%23b85a5a;fill-opacity:1;stroke:none;stroke-width:12.011;stroke-dasharray:none;stroke-opacity:1'/%3e%3cpath d='M88 190c-1-3-2-8-10-15-12.3-12-1-32 13-22 6 3 8 3 12 1 20-16 27 18 3 34-11 9-16 13-18 2z' style='mix-blend-mode:normal;fill:none;fill-opacity:1;stroke:%23b14d4d;stroke-width:12.011;stroke-dasharray:none;stroke-opacity:.459'/%3e%3cpath d='m139 204 26 26a3.97 3.97 90 0 1 0 6l-3 3a3.97 3.97 180 0 1-6 0l-26-26z' style='fill:%2337474f;fill-opacity:1;stroke-width:0;stroke-linecap:round;stroke-linejoin:round'/%3e%3c/g%3e%3c/svg%3e"

class _BrowseCommandCommon(ICommand):
    def __init__(self, list_of_teases: list[Tease], list_of_tease_matches: list[TeaseMatch], html_formatter: IHtmlFormatter, use_highlighting: bool, normal_printer: IPrinter, error_printer: IPrinter) -> None:
        self._list_of_teases: list[Tease] = list_of_teases
        self._list_of_tease_matches: list[TeaseMatch] = list_of_tease_matches
        self._html_formatter: IHtmlFormatter = html_formatter
        self._use_highlighting: bool = use_highlighting
        self._normal_printer: IPrinter = normal_printer
        self._error_printer: IPrinter = error_printer
        self._list_of_ref_ids: list[RefId] = []

    def load(self, argument_stream: ArgumentStream) -> list[str]:
        self._list_of_ref_ids = ArgumentStream.pop_list(argument_stream.pop_optional_ref_id)
        return []

    def execute(self) -> None:
        list_of_tease_matches: (list[TeaseMatch] | None) = None
        if self._list_of_ref_ids:
            list_of_tease_matches = try_create_list_of_tease_matches_from_ref_ids(self._list_of_teases, self._list_of_tease_matches, self._list_of_ref_ids, self._error_printer)
        else:
            list_of_tease_matches = self._list_of_tease_matches

        if list_of_tease_matches:
            self._generate_html_and_open(list_of_tease_matches)
        else:
            self._error_printer.writeln("No teases available to browse")

    def _generate_html_and_open(self, list_of_tease_matches: list[TeaseMatch]) -> None:
        try:
            with tempfile.NamedTemporaryFile(mode='w+t', suffix='.html', encoding='utf-8', delete=False) as file:
                file_printer: FilePrinter = FilePrinter(file)
                was_successful = self._write_html_to_file(list_of_tease_matches, ICON_DATA_URI, file_printer)
        except IOError as ex:
            self._error_printer.writeln(f'Unable to create temporary file: {ex}')
        else:
            if was_successful:
                self._normal_printer.writeln(f"Opening '{file.name}'")
                webbrowser.open(file.name)

    @abstractmethod
    def _write_html_to_file(self, list_of_tease_matches: list[TeaseMatch], icon_data_uri: str, file_printer: IPrinter) -> bool:
        pass

class BrowseCommand(_BrowseCommandCommon):
    def __init__(self, list_of_teases: list[Tease], list_of_tease_matches: list[TeaseMatch], html_formatter: IHtmlFormatter, use_highlighting: bool, use_ellipsis: bool, ellipsis_max_width: int, normal_printer: IPrinter, error_printer: IPrinter) -> None:
        super().__init__(list_of_teases, list_of_tease_matches, html_formatter, use_highlighting, normal_printer, error_printer)
        self._use_ellipsis: bool = use_ellipsis
        self._ellipsis_max_width: int = ellipsis_max_width

    def _write_html_to_file(self, list_of_tease_matches: list[TeaseMatch], icon_data_uri: str, file_printer: IPrinter) -> bool:
        return self._html_formatter.try_write_browse_file_of_text_matches(list_of_tease_matches, self._use_highlighting, self._ellipsis_max_width if self._use_ellipsis else None, file_printer, self._error_printer, icon_data_uri)

    class Help(IHelpInfo):
        def get_one_line_summary(self) -> str:
            return "Opens a webpage for the results with the matching paragraphs of text"

        def get_detailed_summary(self) -> str:
            return (
                "Arguments: [list of RefIds]\n"
                "Generates a webpage that contains details for each tease including the matching"
                " text paragraphs if appropriate.\n"
                "When used without arguments, all teases that were found from the last query are"
                " included. When one or more RefIds are specified, only those teases are included.\n"
                "RefIds can be an index into the list of matches such as '3', a teaseId such as"
                " '#38664', or an authorId such as '@43937'.\n"
                "Matching fields and text may be highlighted which can be controlled with the"
                " highlight command.\n"
                "The text paragraphs may be abbreviated with an ellipsis which can be controlled"
                " with the ellipsis command.\n"
                "Example:\r"
                "  \tOpen a webpage with the last query results\r"
                "  > \tbrowse\r"
                "Example:\r"
                "  \tOpen a webpage for matched teases by index\r"
                "  > \tbrowse 3 7\r"
                "Example:\r"
                "  \tOpen a webpage for some specific teaseIds\r"
                "  > \tbrowse #16830 #1465 #38664\r"
                "Example:\r"
                "  \tOpen a webpage for teases from some specific authorId\r"
                "  > \tbrowse @43937\n"
                "See also:\r"
                "  \tbrowseall, ellipsis, highlight\n"
            )

class BrowseAllCommand(_BrowseCommandCommon):
    def _write_html_to_file(self, list_of_tease_matches: list[TeaseMatch], icon_data_uri: str, file_printer: IPrinter) -> bool:
        return self._html_formatter.try_write_browse_file_of_all_text(list_of_tease_matches, self._use_highlighting, file_printer, self._error_printer, icon_data_uri)

    class Help(IHelpInfo):
        def get_one_line_summary(self) -> str:
            return "Opens a webpage for the results with all paragraphs of text"

        def get_detailed_summary(self) -> str:
            return (
                "Arguments: [list of RefIds]\n"
                "Generates a webpage that contains details for each tease including all text"
                " paragraphs.\n"
                "When used without arguments, all teases that were found from the last query are"
                " included. When one or more RefIds are specified, only those teases are included.\n"
                "RefIds can be an index into the list of matches such as '3', a teaseId such as"
                " '#38664', or an authorId such as '@43937'.\n"
                "Matching fields and text may be highlighted which can be controlled with the"
                " highlight command.\n"
                "The ellipsis setting is ignored with this command so that all of the text is"
                " shown regardless of whether it matched or not.\n"
                "Example:\r"
                "  \tOpen a webpage with the last query results\r"
                "  > \tbrowseall\r"
                "Example:\r"
                "  \tOpen a webpage for matched teases by index\r"
                "  > \tbrowseall 3 7\r"
                "Example:\r"
                "  \tOpen a webpage for some specific teaseIds\r"
                "  > \tbrowseall #16830 #1465 #38664\r"
                "Example:\r"
                "  \tOpen a webpage for teases from some specific authorId\r"
                "  > \tbrowseall @43937\n"
                "See also:\r"
                "  \tbrowse, ellipsis, highlight\n"
            )
