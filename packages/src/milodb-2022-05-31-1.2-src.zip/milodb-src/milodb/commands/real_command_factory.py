from milodb.commands.browse_command import BrowseCommand
from milodb.commands.browseall_command import BrowseAllCommand
from milodb.commands.command import Command, CommandFactory
from milodb.commands.copy_command import CopyCommand
from milodb.commands.ellipsis_command import EllipsisCommand
from milodb.commands.exit_command import ExitCommand
from milodb.commands.format_command import FormatCommand
from milodb.commands.help_command import HelpCommand
from milodb.commands.highlight_command import HighlightCommand
from milodb.commands.list_command import ListCommand
from milodb.commands.open_command import OpenCommand
from milodb.commands.openauthor_command import OpenAuthorCommand
from milodb.commands.query_command import QueryCommand
from milodb.commands.show_command import ShowCommand
from milodb.commands.sort_command import SortCommand
from milodb.commands.stats_command import StatsCommand
from milodb.commands.summary_command import SummaryCommand
from milodb.commands.url_command import UrlCommand
from milodb.commands.urlauthor_command import UrlAuthorCommand
from typing import Dict, List, Optional, Type

class RealCommandFactory(CommandFactory):
    def try_get_command_class_from_name(self, name: str) -> Optional[Type[Command]]:
        return _MAP_OF_COMMAND_NAME_TO_CLASS.get(name)

    def get_list_of_command_names(self) -> List[str]:
        return list(_MAP_OF_COMMAND_NAME_TO_CLASS.keys())

_MAP_OF_COMMAND_NAME_TO_CLASS: Dict[str, Type[Command]] = {
    'exit': ExitCommand,
    'help': HelpCommand,
    'list': ListCommand,
    'format': FormatCommand,
    'highlight': HighlightCommand,
    'ellipsis': EllipsisCommand,
    'show': ShowCommand,
    'summary': SummaryCommand,
    'open': OpenCommand,
    'openauthor': OpenAuthorCommand,
    'browse': BrowseCommand,
    'browseall': BrowseAllCommand,
    'query': QueryCommand,
    'sort': SortCommand,
    'url': UrlCommand,
    'urlauthor': UrlAuthorCommand,
    'stats': StatsCommand,
    'copy': CopyCommand
}
