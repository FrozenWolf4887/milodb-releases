from milodb.commands.format_command import FormatCommand
from milodb.commands.test_command_base import CommandTestBase
from milodb.output.outputter import Outputter
from unittest.mock import MagicMock, Mock

class TestFormatCommand(CommandTestBase):
    def test_without_arguments_returns_success(self):
        self.run_test(['format'])
        self.assert_successful(FormatCommand)

    def test_with_one_argument_returns_success(self):
        outputter1 = Mock(Outputter)
        outputter1.get_name = MagicMock(return_value='one')
        outputter2 = Mock(Outputter)
        outputter2.get_name = MagicMock(return_value='two')
        self.context.current_outputter = outputter1
        self.context.list_of_outputters = [outputter1, outputter2]
        self.run_test(['format', 'two'])
        self.assert_successful(FormatCommand)

    def test_with_one_invalid_argument_returns_failure(self):
        outputter1 = Mock(Outputter)
        outputter1.get_name = MagicMock(return_value='one')
        outputter2 = Mock(Outputter)
        outputter2.get_name = MagicMock(return_value='two')
        self.context.current_outputter = outputter1
        self.context.list_of_outputters = [outputter1, outputter2]
        self.run_test(['format', 'three'])
        self.assert_unsuccessful(FormatCommand, 1, "Invalid parameter. Expected one of ['one', 'two']", ['one', 'two'])

    def test_with_redundant_argument_returns_failure(self):
        outputter1 = Mock(Outputter)
        outputter1.get_name = MagicMock(return_value='one')
        outputter2 = Mock(Outputter)
        outputter2.get_name = MagicMock(return_value='two')
        self.context.current_outputter = outputter1
        self.context.list_of_outputters = [outputter1, outputter2]
        self.run_test(['format', 'two', 'one'])
        self.assert_unsuccessful(FormatCommand, 2, 'Unexpected additional parameter', None)
