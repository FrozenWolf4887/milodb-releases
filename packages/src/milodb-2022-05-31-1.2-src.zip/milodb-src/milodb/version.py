from typing import Optional

MILODB_VERSION: Optional[str] = '1.2'
MILODB_DATE: Optional[str] = '2022-05-31'
