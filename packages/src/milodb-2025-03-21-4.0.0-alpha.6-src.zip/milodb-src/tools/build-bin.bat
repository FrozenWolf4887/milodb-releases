@REM MiloDB by FrozenWolf is marked with CC0 1.0.
@REM To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
@echo off
setlocal EnableDelayedExpansion
set EXPECTED_PYTHON=python
set EXPECTED_PYTHON_VERSION=3.12
set EXPECTED_PYTHON_VERSION_PATTERN_A=^^Python %EXPECTED_PYTHON_VERSION:.=\.% *$
set EXPECTED_PYTHON_VERSION_PATTERN_B=^^Python %EXPECTED_PYTHON_VERSION:.=\.%\.[0-9][0-9]* *$

REM spell-checker: ignore PYTHONOPTIMIZE distpath errorlevel mvdb setlocal usebackq venv workpath

echo ** Check python version
for /F "usebackq tokens=* delims=" %%i in (`where "%EXPECTED_PYTHON%" 2^> nul`) do if "!pythonExe!"=="" set pythonExe=%%~i
if "!pythonExe!"=="" (echo Error: Python %EXPECTED_PYTHON_VERSION% not found in path & goto :EOF)
echo Python: !pythonExe!
for /F "usebackq tokens=* delims=" %%i in (`"!pythonExe!" --version`) do if "!pythonVersion!"=="" set pythonVersion=%%~i
echo !pythonVersion! | findstr /R /C:"%EXPECTED_PYTHON_VERSION_PATTERN_A%" /C:"%EXPECTED_PYTHON_VERSION_PATTERN_B%" > nul
if errorlevel 1 (echo Error: Python version reported as '!pythonVersion!, but Python %EXPECTED_PYTHON_VERSION% expected & goto :EOF)
echo Python version: !pythonVersion!
goto main

:buildType %= type: 'terminal' or 'gui' =%
    set TYPE=%1

    echo ** Prepare virtual environment for '!TYPE!'
    "!pythonExe!" -m venv "%TEMP%\mvdb\venv-!TYPE!" --clear --upgrade-deps
    call "%TEMP%\mvdb\venv-!TYPE!\Scripts\activate.bat"

    echo ** Install packages for '!TYPE!'
    pip install -r requirements-build.txt -r "requirements-run-!TYPE!.txt"

    echo ** Build executable for '!TYPE!'
    set PYTHONOPTIMIZE=2
    pyinstaller --distpath bin --workpath "%TEMP%\mvdb\build-!TYPE!" --clean "milodb-!TYPE!.spec"

    echo ** Dump requirements for '!TYPE!'
    pip freeze

    call "%TEMP%\mvdb\venv-!TYPE!\Scripts\deactivate.bat"
    goto :EOF

:main
set BUILD_TERMINAL=false
set BUILD_GUI=false
if "%~1" == "" (
    set BUILD_TERMINAL=true
    set BUILD_GUI=true
) else (
    :nextArg
    if "%~1" == "" (
        goto endOfArgs
    ) else if "%~1" == "terminal" (
        set BUILD_TERMINAL=true
    ) else if "%~1" == "gui" (
        set BUILD_GUI=true
    ) else (
        echo Unknown build option '%~1'
        exit /b 1
    )
    shift
    goto nextArg
)
:endOfArgs

if !BUILD_TERMINAL! == true call :buildType terminal
if !BUILD_GUI! == true call :buildType gui
