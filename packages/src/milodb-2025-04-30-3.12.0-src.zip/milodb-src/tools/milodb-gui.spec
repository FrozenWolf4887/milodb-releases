# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
# -*- mode: python ; coding: utf-8 -*-
# spell-checker: disable
import sys
from pathlib import Path
from PyInstaller.building.build_main import Analysis
from PyInstaller.building.datastruct import TOC
from PyInstaller.building.api import EXE, PYZ

ROOT_PATH: Path = Path('..').resolve()
IS_WINDOWS_BUILD: bool = sys.platform == 'win32'
STRIP_LIBRARIES: bool = not IS_WINDOWS_BUILD
EXCLUDE_BINARIES: tuple[str, ...] = ()

analysis = Analysis(
    [ROOT_PATH / 'run_gui.pyw'],
    pathex = [],
    binaries = [],
    datas = [
        (ROOT_PATH / 'milodb_client/resources/milodb-search-icon.ico', 'resources'),
    ],
    hiddenimports = ['PIL._tkinter_finder'],
    hookspath = [],
    hooksconfig = {},
    runtime_hooks = [],
    excludes = ['importlib.metadata', 'pydoc', 'pdb'],
    win_no_prefer_redirects = False,
    win_private_assemblies = False,
    cipher = None,
    noarchive = False,
    optimize = 2,
)

def any_starts_with(text: str, list_of_text: tuple[str, ...]) -> bool:
    return any(text.startswith(value) for value in list_of_text)

analysis.binaries = TOC([binary for binary in analysis.binaries if not any_starts_with(binary[0], EXCLUDE_BINARIES)])

pyz = PYZ(
    analysis.pure,
    analysis.zipped_data,
    cipher = None,
)

exe = EXE(
    pyz,
    analysis.scripts,
    analysis.binaries,
    analysis.zipfiles,
    analysis.datas,
    [],
    name = 'milodb-gui',
    icon = ROOT_PATH / 'milodb_client/resources/milodb-search-icon.ico',
    debug = False,
    bootloader_ignore_signals = False,
    strip = STRIP_LIBRARIES,
    upx = False,
    upx_exclude = [],
    runtime_tmpdir = None,
    console = False,
    disable_windowed_traceback = False,
    target_arch = None,
    codesign_identity = None,
    entitlements_file = None,
)
