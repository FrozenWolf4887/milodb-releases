#!/bin/bash
# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
EXPECTED_PYTHON='python'
EXPECTED_PYTHON_VERSION='3.12'
EXPECTED_PYTHON_VERSION_PATTERN="^Python ${EXPECTED_PYTHON_VERSION//./\\.}(\\.[0-9]+)?$"

echo "** Check python version"
pythonExe="$(which "$EXPECTED_PYTHON")"
[ -z "$pythonExe" ] && echo "Error: Python $EXPECTED_PYTHON_VERSION not found in path" && exit 1
echo "Python executable: $pythonExe"
pythonVersion="$(python --version)"
[[ ! "$pythonVersion" =~ $EXPECTED_PYTHON_VERSION_PATTERN ]] && echo "Error: Python version reported as '$pythonVersion', but Python $EXPECTED_PYTHON_VERSION expected" && exit 1
echo "Python version: $pythonVersion"

# spell-checker: ignore PYTHONOPTIMIZE distpath mvdb venv workpath
set -e

function buildType() # type: 'terminal' or 'gui'
{
    type="$1"

    echo "** Prepare virtual environment for '$type'"
    "$pythonExe" -m venv "/tmp/mvdb/venv-$type" --clear
    # shellcheck disable=SC1090
    source "/tmp/mvdb/venv-$type/bin/activate"

    echo "** Install packages for '$type'"
    pip install --disable-pip-version-check --no-deps -r requirements-build.txt -r "requirements-run-$type.txt"

    echo "** Build executable for '$type'"
    PYTHONOPTIMIZE=2 pyinstaller --distpath bin --workpath "/tmp/mvdb/build-$type" --clean "milodb-$type.spec"

    echo "** Dump requirements '$type'"
    pip freeze
}

buildTerminal=false
buildGui=false

if [ $# -eq 0 ]
then
    buildTerminal=true
    buildGui=true
else
    while [ $# -gt 0 ]
    do
        case "$1" in
            terminal)
                buildTerminal=true
                ;;
            gui)
                buildGui=true
                ;;
            *)
                echo "Unknown build option '$1'"
                exit 1
                ;;
        esac
        shift
    done
fi

[ $buildTerminal == 'true' ] && buildType terminal
[ $buildGui == 'true' ] && buildType gui
