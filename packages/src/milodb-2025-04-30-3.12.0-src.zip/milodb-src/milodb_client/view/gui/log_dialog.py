# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from __future__ import annotations
import tkinter as tk
from milodb_client.view.gui.log_text import LogText
from milodb_client.view.gui.window_widgets import ModalDialog

class LogDialog(ModalDialog):
    def __init__(self, master: tk.Tk) -> None:
        super().__init__(master, width=480, height=400)

        self._log_text: LogText = LogText(self.content_frame)
        self._log_text.pack(fill=tk.BOTH, expand=True)

    @property
    def log_text(self) -> LogText:
        return self._log_text

    def show_okay_button(self) -> None:
        self.add_button('Okay', column=0, command=self.destroy)
