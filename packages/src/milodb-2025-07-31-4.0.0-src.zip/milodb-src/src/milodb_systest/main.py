# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import tempfile
from datetime import UTC, datetime
from milodb_client.view.terminal.main_terminal import MainTerminal
from milodb_common.output.print.capturing_printer import CapturingPrinter
from milodb_common.view.terminal.command_framework.quit_flag import QuitFlag
from milodb_systest.logger import Logger
from milodb_systest.options import Options
from milodb_systest.test_framework import TestFailError
from milodb_systest.test_suite import TestSuite

class Main:
    def __init__(self, options: Options) -> None:
        capturing_printer: CapturingPrinter = CapturingPrinter()
        quit_flag: QuitFlag = QuitFlag()

        def send_input(input_text: str) -> None:
            if not client.inject_command(input_text):
                quit_flag.set()

        def get_output() -> str:
            output_text: str = capturing_printer.text
            capturing_printer.clear()
            return output_text

        def is_quit() -> bool:
            return bool(quit_flag)

        timestamp: str = datetime.now(tz=UTC).astimezone().isoformat().replace(':', '-')

        self._was_successful: bool = False
        try:
            with tempfile.NamedTemporaryFile('wt', encoding='utf-8', delete=False, prefix=f'milodb-systest-{timestamp}-', suffix='.log') as logfile:
                print(f"Logging to '{logfile.name}'")
                logger: Logger = Logger(logfile)
                client: MainTerminal = MainTerminal(capturing_printer, no_load=False)
                try:
                    TestSuite(logger, send_input, get_output, is_quit, options)
                except TestFailError:
                    logger.log_info('Test failed, aborting')
                    self._was_successful = False
                else:
                    self._was_successful = True
        except OSError as ex:
            print(f'OSError: {ex}')

    @property
    def was_successful(self) -> bool:
        return self._was_successful
