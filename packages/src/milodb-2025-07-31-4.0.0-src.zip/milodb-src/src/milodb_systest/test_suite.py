# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import re
from collections.abc import Callable, Sequence
from milodb_systest.formatting import Ansi, BBCode, Html, Url
from milodb_systest.logger import Logger
from milodb_systest.options import Options
from milodb_systest.template_text import TemplateText
from milodb_systest.test_framework import ExpectedLine, TestFramework

_HTML_LIST_HEAD: Sequence[ExpectedLine] = [
    ExpectedLine('<div class="listTable">'),
    ExpectedLine(
        '<div class="th index"></div>'
        '<div class="th hits">Hits</div>'
        '<div class="th teaseId">Id</div>'
        '<div class="th type">Type</div>'
        '<div class="th rating">Rating</div>'
        '<div class="th date">Date</div>'
        '<div class="th title">Title</div>'
        '<div class="th author">Author</div>',
    ),
]

def _html_list_tail(number_of_matches: int) -> Sequence[ExpectedLine]:
    plural_text: str = 'es' if number_of_matches != 1 else ''
    return [
        ExpectedLine('</div>'),
        ExpectedLine(f'<div class="totalMatches">{number_of_matches} match{plural_text}</div>'),
    ]

class TestSuite(TestFramework):
    def __init__(self, logger: Logger, input_sender: Callable[[str], None], output_reader: Callable[[], str], is_quit: Callable[[], bool], options: Options) -> None:
        super().__init__(logger, input_sender, output_reader, is_quit)
        self._options: Options = options
        self._run_tests()

    def _run_tests(self) -> None:
        self._logger.log_info('Starting tests')
        self._test_startup()
        TestSuite.TestDefaults(self)
        TestSuite.TestNoMatches(self)
        TestSuite.TestAnsiList(self)
        TestSuite.TestPlainList(self)
        TestSuite.TestBBCodeList(self)
        TestSuite.TestHtmlList(self)
        self._test_exit()
        self._logger.log_info('Finished running tests')

    def _test_startup(self) -> None:
        expected_lines: list[ExpectedLine] = []
        if self._options.is_development_version:
            expected_lines.append(ExpectedLine("Warning: Local manifest 'milodb-manifest.ver' unavailable"))
            expected_lines.append(ExpectedLine('MiloDB (Unknown Version), (Unknown Date)'))
        else:
            expected_lines.append(ExpectedLine(re.compile(r'MiloDB [1-9](\.[0-9]+)+, 202[2-9]-[0-1][0-9]-[0-3][0-9]')))
        if self._options.has_existing_config:
            expected_lines.append(ExpectedLine("Loaded config from 'config.json'"))
        else:
            expected_lines.append(ExpectedLine("Saved config file 'config.json'"))
        if self._options.has_existing_variables:
            expected_lines.append(ExpectedLine("Loaded variables from 'variables.json'"))
        expected_lines.extend([
            ExpectedLine('Load database'),
            ExpectedLine(re.compile(r'  Read     : [0-2].[0-9]{3}s')),
            ExpectedLine(re.compile(r'  Unpack   : [0-2].[0-9]{3}s')),
            ExpectedLine(re.compile(r'  Parse    : [0-2].[0-9]{3}s')),
            ExpectedLine(re.compile(r'  Assemble : [0-2].[0-9]{3}s')),
            ExpectedLine(re.compile(r'Load completed: [0-6].[0-9]{3}s')),
            ExpectedLine(re.compile(r'[0-9],[0-9]{3} teases loaded ranging from 2006-08-15 to 202[2-9]-[0-1][0-9]-[0-3][0-9]')),
            ExpectedLine(),
        ])

        self.verify_output(expected_lines)

    def _test_exit(self) -> None:
        self.send_command('exit')
        self.verify_output([ ExpectedLine() ], quit_flag=True)

    class TestDefaults:
        def __init__(self, test_framework: TestFramework) -> None:
            self._test_framework: TestFramework = test_framework
            self._test_format_default()
            self._test_ellipsis_default()
            self._test_highlight_default()

        def _test_format_default(self) -> None:
            self._test_framework.verify_command('format', [
                ExpectedLine("Current format is 'ansi'"),
                ExpectedLine("Available formats are ['ansi', 'plain', 'bbcode', 'html']"),
            ])

        def _test_ellipsis_default(self) -> None:
            self._test_framework.verify_command('ellipsis', [
                ExpectedLine("Current ellipsis mode is 'on'"),
                ExpectedLine("Available options are ['on', 'off']"),
            ])

        def _test_highlight_default(self) -> None:
            self._test_framework.verify_command('highlight', [
                ExpectedLine("Current highlighting is 'on'"),
                ExpectedLine("Available options are ['on', 'off']"),
            ])

    class TestNoMatches:
        def __init__(self, test_framework: TestFramework) -> None:
            self._test_framework: TestFramework = test_framework
            self._test_query_no_matches()

        def _test_query_no_matches(self) -> None:
            self._test_framework.verify_command('query teaseId = 1234', [
                ExpectedLine("No matches"),
            ])

    class TestAnsiList:
        def __init__(self, test_framework: TestFramework) -> None:
            self._test_framework: TestFramework = test_framework
            self._template_output: TemplateText = TemplateText("  ~IDX:1~:   *~HTS:1~  #~TID:40134~  ~TYP:eos~  ~RAT:4.7~  w  ~DAT:2019-06-11~  Be~TTL:fore~ Eternity : <S~AUT:hatter~ed, @~AID:29180~>")
            self._test_format()
            self._test_teaseid_highlighting()
            self._test_type_highlighting()
            self._test_rating_highlighting()
            self._test_date_highlighting()
            self._test_title_highlighting()
            self._test_author_highlighting()
            self._test_authorid_highlighting()

        def _test_format(self) -> None:
            self._test_framework.verify_command('format ansi', [
                ExpectedLine("Changed format to 'ansi'"),
            ])

        def _test_teaseid_highlighting(self) -> None:
            self._test_framework.verify_command('query teaseId = 40134', [
                ExpectedLine(self._template_output.expand(TID=Ansi.highlighted)),
            ])

        def _test_type_highlighting(self) -> None:
            self._test_framework.verify_command('query type is eos and summary contains "another soul guides you"', [
                ExpectedLine(self._template_output.expand(HTS=2, TYP=Ansi.highlighted)),
            ])

        def _test_rating_highlighting(self) -> None:
            self._test_framework.verify_command('query rating > 4 and summary contains "another soul guides you"', [
                ExpectedLine(self._template_output.expand(HTS=2, RAT=Ansi.highlighted)),
            ])

        def _test_date_highlighting(self) -> None:
            self._test_framework.verify_command('query date < 2020-01-01 and summary contains "another soul guides you"', [
                ExpectedLine(self._template_output.expand(HTS=2, DAT=Ansi.highlighted)),
            ])

        def _test_title_highlighting(self) -> None:
            self._test_framework.verify_command('query title contains fore and summary contains "another soul guides you"', [
                ExpectedLine(self._template_output.expand(HTS=2, TTL=Ansi.highlighted)),
            ])

        def _test_author_highlighting(self) -> None:
            self._test_framework.verify_command('query author contains hatter and summary contains "another soul guides you"', [
                ExpectedLine(self._template_output.expand(HTS=2, AUT=Ansi.highlighted)),
            ])

        def _test_authorid_highlighting(self) -> None:
            self._test_framework.verify_command('query authorId > 29000 and summary contains "another soul guides you"', [
                ExpectedLine(self._template_output.expand(HTS=2, AID=Ansi.highlighted)),
            ])

    class TestPlainList:
        def __init__(self, test_framework: TestFramework) -> None:
            self._test_framework: TestFramework = test_framework
            self._template_output: TemplateText = TemplateText("  ~IDX:1~:   *~HTS:1~  #~TID:40134~  ~TYP:eos~  ~RAT:4.7~  w  ~DAT:2019-06-11~  Be~TTL:fore~ Eternity : <S~AUT:hatter~ed, @~AID:29180~>")
            self._test_format()
            self._test_teaseid_highlighting()
            self._test_type_highlighting()
            self._test_rating_highlighting()
            self._test_date_highlighting()
            self._test_title_highlighting()
            self._test_author_highlighting()
            self._test_authorid_highlighting()

        def _test_format(self) -> None:
            self._test_framework.verify_command('format plain', [
                ExpectedLine("Changed format to 'plain'"),
            ])

        def _test_teaseid_highlighting(self) -> None:
            self._test_framework.verify_command('query teaseId = 40134', [
                ExpectedLine(self._template_output.expand()),
            ])

        def _test_type_highlighting(self) -> None:
            self._test_framework.verify_command('query type is eos and summary contains "another soul guides you"', [
                ExpectedLine(self._template_output.expand(HTS=2)),
            ])

        def _test_rating_highlighting(self) -> None:
            self._test_framework.verify_command('query rating > 4 and summary contains "another soul guides you"', [
                ExpectedLine(self._template_output.expand(HTS=2)),
            ])

        def _test_date_highlighting(self) -> None:
            self._test_framework.verify_command('query date < 2020-01-01 and summary contains "another soul guides you"', [
                ExpectedLine(self._template_output.expand(HTS=2)),
            ])

        def _test_title_highlighting(self) -> None:
            self._test_framework.verify_command('query title contains fore and summary contains "another soul guides you"', [
                ExpectedLine(self._template_output.expand(HTS=2)),
            ])

        def _test_author_highlighting(self) -> None:
            self._test_framework.verify_command('query author contains hatter and summary contains "another soul guides you"', [
                ExpectedLine(self._template_output.expand(HTS=2)),
            ])

        def _test_authorid_highlighting(self) -> None:
            self._test_framework.verify_command('query authorId > 29000 and summary contains "another soul guides you"', [
                ExpectedLine(self._template_output.expand(HTS=2)),
            ])

    class TestBBCodeList:
        def __init__(self, test_framework: TestFramework) -> None:
            self._test_framework: TestFramework = test_framework
            self._template_output: TemplateText = TemplateText(
                f"[pre]  ~IDX:1~:   *~HTS:1~  [url={Url.tease(40134)}]#~TID:40134~[/url]  ~TYP:eos~  ~RAT:4.7~  w  ~DAT:2019-06-11~  [/pre]Be~TTL:fore~ Eternity : <S~AUT:hatter~ed, [url={Url.author(29180)}]@~AID:29180~[/url]>")
            self._test_format()
            self._test_teaseid_highlighting()
            self._test_type_highlighting()
            self._test_rating_highlighting()
            self._test_date_highlighting()
            self._test_title_highlighting()
            self._test_author_highlighting()
            self._test_authorid_highlighting()

        def _test_format(self) -> None:
            self._test_framework.verify_command('format bbcode', [
                ExpectedLine("Changed format to 'bbcode'"),
            ])

        def _test_teaseid_highlighting(self) -> None:
            self._test_framework.verify_command('query teaseId = 40134', [
                ExpectedLine(self._template_output.expand(TID=BBCode.highlighted)),
            ])

        def _test_type_highlighting(self) -> None:
            self._test_framework.verify_command('query type is eos and summary contains "another soul guides you"', [
                ExpectedLine(self._template_output.expand(HTS=2, TYP=BBCode.highlighted)),
            ])

        def _test_rating_highlighting(self) -> None:
            self._test_framework.verify_command('query rating > 4 and summary contains "another soul guides you"', [
                ExpectedLine(self._template_output.expand(HTS=2, RAT=BBCode.highlighted)),
            ])

        def _test_date_highlighting(self) -> None:
            self._test_framework.verify_command('query date < 2020-01-01 and summary contains "another soul guides you"', [
                ExpectedLine(self._template_output.expand(HTS=2, DAT=BBCode.highlighted)),
            ])

        def _test_title_highlighting(self) -> None:
            self._test_framework.verify_command('query title contains fore and summary contains "another soul guides you"', [
                ExpectedLine(self._template_output.expand(HTS=2, TTL=BBCode.highlighted)),
            ])

        def _test_author_highlighting(self) -> None:
            self._test_framework.verify_command('query author contains hatter and summary contains "another soul guides you"', [
                ExpectedLine(self._template_output.expand(HTS=2, AUT=BBCode.highlighted)),
            ])

        def _test_authorid_highlighting(self) -> None:
            self._test_framework.verify_command('query authorId > 29000 and summary contains "another soul guides you"', [
                ExpectedLine(self._template_output.expand(HTS=2, AID=BBCode.highlighted)),
            ])

    class TestHtmlList:
        def __init__(self, test_framework: TestFramework) -> None:
            self._test_framework: TestFramework = test_framework
            self._template_output: TemplateText = TemplateText(
                '<div class="td index">~IDX:1~</div>'
                '<div class="td hits">~HTS:1~</div>'
                f'<div class="td teaseId"><a href="{Url.tease(40134)}"><div>~TID:40134~</div></a></div>'
                '<div class="td type"><div>~TYP:eos~</div></div>'
                '<div class="td rating"><div>~RAT:4.7~</div></div>'
                '<div class="td date"><div>~DAT:2019-06-11~</div></div>'
                '<div class="td title"><a id="list~LID:40134~" class="toSummary" href="#summary~LID:40134~"><div class="totm-winner"><div>Be~TTL:fore~ Eternity</div></div></a></div>'
                f'<div class="td author"><a href="{Url.author(29180)}"><div>S~AUT:hatter~ed</div></a></div>',
            )
            self._test_format()
            self._test_teaseid_highlighting()
            self._test_type_highlighting()
            self._test_rating_highlighting()
            self._test_date_highlighting()
            self._test_title_highlighting()
            self._test_author_highlighting()

        def _test_format(self) -> None:
            self._test_framework.verify_command('format html', [
                ExpectedLine("Changed format to 'html'"),
            ])

        def _test_teaseid_highlighting(self) -> None:
            self._test_framework.verify_command('query teaseId = 40134', [
                *_HTML_LIST_HEAD,
                ExpectedLine(self._template_output.expand(TID=Html.highlighted)),
                *_html_list_tail(1),
            ])

        def _test_type_highlighting(self) -> None:
            self._test_framework.verify_command('query type is eos and summary contains "another soul guides you"', [
                *_HTML_LIST_HEAD,
                ExpectedLine(self._template_output.expand(HTS=2, TYP=Html.highlighted)),
                *_html_list_tail(1),
            ])

        def _test_rating_highlighting(self) -> None:
            self._test_framework.verify_command('query rating > 4 and summary contains "another soul guides you"', [
                *_HTML_LIST_HEAD,
                ExpectedLine(self._template_output.expand(HTS=2, RAT=Html.highlighted)),
                *_html_list_tail(1),
            ])

        def _test_date_highlighting(self) -> None:
            self._test_framework.verify_command('query date < 2020-01-01 and summary contains "another soul guides you"', [
                *_HTML_LIST_HEAD,
                ExpectedLine(self._template_output.expand(HTS=2, DAT=Html.highlighted)),
                *_html_list_tail(1),
            ])

        def _test_title_highlighting(self) -> None:
            self._test_framework.verify_command('query title contains fore and summary contains "another soul guides you"', [
                *_HTML_LIST_HEAD,
                ExpectedLine(self._template_output.expand(HTS=2, TTL=Html.highlighted)),
                *_html_list_tail(1),
            ])

        def _test_author_highlighting(self) -> None:
            self._test_framework.verify_command('query author contains hatter and summary contains "another soul guides you"', [
                *_HTML_LIST_HEAD,
                ExpectedLine(self._template_output.expand(HTS=2, AUT=Html.highlighted)),
                *_html_list_tail(1),
            ])
