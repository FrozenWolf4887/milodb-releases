# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from abc import ABC, abstractmethod
from collections.abc import Iterable, Set as AbstractSet
from typing import override
from unittest.mock import Mock
from milodb_common.parser.arg import ArgumentError
from milodb_common.parser.arg_token_stream import ArgTokenStream
from milodb_common.parser.candidate_text import CandidateText
from milodb_common.parser.expanding_token_stream import ExpandedToken
from milodb_common.parser.token import StartEnd, Token
from milodb_common.view.terminal.command_framework.i_command import CommandLoader, CommandLoaderError, CommandLoaderResult
from milodb_common.view.terminal.command_framework.i_command_constructor import ICommandConstructor
from milodb_common_test.test.test_case_ex import TestCaseEx

_SET_OF_QUOTE_CHARS: AbstractSet[str] = {'"', "'"}

def create_fake_tokens(list_of_token_text: Iterable[str]) -> list[ExpandedToken | None]:
    list_of_tokens: list[ExpandedToken | None] = []
    token_number: int = 1
    token_start_index: int = 0
    for token_text in list_of_token_text:
        token_end_index: int = token_start_index + len(token_text)
        outer_indices: StartEnd = StartEnd(token_start_index, token_end_index)
        inner_indices: StartEnd = StartEnd(token_start_index, token_end_index)
        if token_text and token_text[0] in _SET_OF_QUOTE_CHARS:
            inner_indices.start += 1
            inner_indices.end -= 1
        topmost_token: Token = Token(token_text, token_number, outer_indices, inner_indices, is_delimiter=False)
        expanded_token: ExpandedToken = ExpandedToken(token_text, token_number, outer_indices, inner_indices, is_delimiter=False, topmost_token=topmost_token, variable_depth=0)
        list_of_tokens.append(expanded_token)
        token_start_index = token_end_index + 1
        token_number += 1
    list_of_tokens.append(None)
    return list_of_tokens

class CommandTestBase(ABC, TestCaseEx):
    @override
    def setUp(self) -> None:
        self.list_of_tokens: list[ExpandedToken | None] = []
        self.mock_arg_token_stream = Mock(ArgTokenStream)

        self._command_loader: CommandLoader | None = None
        self._load_exception: ArgumentError | CommandLoaderError | ICommandConstructor.DelegateError | None = None
        self._load_result: CommandLoaderResult | None = None
        self._token_index = 0

    @abstractmethod
    def load_command(self, arg_token_stream: ArgTokenStream) -> CommandLoaderResult:
        pass

    def command_load(self, list_of_token_text: Iterable[str] | None, remaining_raw_text: str | None = None, expanded_raw_text: str | None = None) -> None:
        stub_command_token: ExpandedToken | None = None
        self.list_of_tokens = [stub_command_token]
        self._token_index = 1
        if not list_of_token_text:
            self.mock_arg_token_stream.next = Mock(return_value=None)
            self.mock_arg_token_stream.next_arg = Mock(return_value=None)
            self.mock_arg_token_stream.get_remaining_raw_text = Mock(return_value='')
        else:
            self.list_of_tokens.extend(create_fake_tokens(list_of_token_text))
            self.mock_arg_token_stream.next = Mock(side_effect=self._pop_token)
            self.mock_arg_token_stream.next_arg = Mock(side_effect=lambda _: self._pop_token())
            self.mock_arg_token_stream.get_expanded_raw_text = Mock(return_value=(expanded_raw_text or ''))
            self.mock_arg_token_stream.get_remaining_raw_text = Mock(return_value=(remaining_raw_text or ''))
        try:
            self._load_result = self.load_command(self.mock_arg_token_stream)
        except (ArgumentError, CommandLoaderError, ICommandConstructor.DelegateError) as ex:
            self._load_exception = ex

    def _pop_token(self) -> ExpandedToken | None:
        token: ExpandedToken | None = None
        if self._token_index < len(self.list_of_tokens):
            token = self.list_of_tokens[self._token_index]
            self._token_index += 1
        return token

    def command_load_and_execute(self, list_of_token_text: Iterable[str] | None, remaining_raw_text: str | None = None, expanded_raw_text: str | None = None) -> None:
        self.command_load(list_of_token_text, remaining_raw_text, expanded_raw_text)
        if self._load_exception is None:
            if self._load_result is not None:
                self._load_result.command()
        else:
            self.fail(f"Load should have been successful but wasn't\nException was: {self._load_exception}")

    def assert_next_text(self, list_of_next_text: Iterable[str]) -> None:
        if self.assert_is_not_none(self._load_result):
            self._assert_candidate_text_list_equal(list_of_next_text, self._load_result.list_of_candidate_text)

    def assert_argument_error(self, fault_token_index: int | None, fault_text: str, list_of_candidate_text: Iterable[str | CandidateText]) -> None:
        if self.assert_is_instance(self._load_exception, ArgumentError):
            if fault_token_index is not None:
                self.assertEqual(
                    self.list_of_tokens[fault_token_index], self._load_exception.fault_token,
                    'Unexpected fault token reported')
            else:
                self.assertIsNone(
                    self._load_exception.fault_token,
                    'Unexpected fault token reported')

            self.assertEqual(
                fault_text, self._load_exception.message,
                f"Expected error message of '{fault_text}' but got '{self._load_exception.message}'")

            self._assert_candidate_text_list_equal(list_of_candidate_text, self._load_exception.list_of_candidate_text)

    def assert_load_error(self, fault_token_index: int | None, fault_text: str, list_of_candidate_text: Iterable[str | CandidateText]) -> None:
        if self.assert_is_instance(self._load_exception, CommandLoaderError):
            if fault_token_index is not None:
                self.assertEqual(
                    self.list_of_tokens[fault_token_index], self._load_exception.fault_token,
                    'Unexpected fault token reported')
            else:
                self.assertIsNone(
                    self._load_exception.fault_token,
                    'Unexpected fault token reported')

            self.assertEqual(
                fault_text, self._load_exception.message,
                f"Expected error message of '{fault_text}' but got '{self._load_exception.message}'")

            self._assert_candidate_text_list_equal(list_of_candidate_text, self._load_exception.list_of_candidate_text)

    def _assert_candidate_text_list_equal(self, expected_list_of_candidate_text: Iterable[str | CandidateText], actual_list_of_candidate_text: Iterable[CandidateText]) -> None:
        expected_list_of_text: list[str] = []
        candidate_text: str | CandidateText
        for candidate_text in expected_list_of_candidate_text:
            if isinstance(candidate_text, CandidateText):
                expected_list_of_text.append(candidate_text.text + candidate_text.following_delimiter)
            else:
                expected_list_of_text.append(candidate_text + ' ')

        actual_list_of_text: Iterable[str] = [candidate_text.text + candidate_text.following_delimiter for candidate_text in actual_list_of_candidate_text]

        self.assertSequenceEqual(sorted(expected_list_of_text), sorted(actual_list_of_text))
