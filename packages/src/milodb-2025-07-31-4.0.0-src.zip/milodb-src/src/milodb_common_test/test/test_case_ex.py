# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import unittest
from typing import TypeGuard
from unittest.util import safe_repr

class TestCaseEx(unittest.TestCase):
    def assert_is_not_none[T](self, obj: T | None, msg: str | None = None) -> TypeGuard[T]:
        if obj is None:
            self.fail(msg or 'unexpectedly None')
        return True

    def assert_is_instance[T](self, obj: object, cls: type[T]) -> TypeGuard[T]:
        if not isinstance(obj, cls):
            self.fail(f'{safe_repr(obj)} is not an instance of {cls!r}')
        return True
