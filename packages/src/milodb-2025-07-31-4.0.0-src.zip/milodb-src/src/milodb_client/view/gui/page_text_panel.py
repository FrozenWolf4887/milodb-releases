# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import tkinter as tk
import tkinter.font as tkfont
from collections.abc import Callable, Sequence
from milodb_client.database.tease_page import TeasePage
from milodb_client.output.support import get_matching_indices_for_page
from milodb_client.query.field_match import IFieldMatch
from milodb_client.view.gui import general_colours, general_style
from milodb_client.view.gui.canvas_widgets import CanvasChamferRectangle, CanvasPlainText, CanvasRectangle, CanvasWrappedText
from milodb_client.view.gui.styled_canvas import StyledCanvas
from milodb_common.view.gui.metrics import Margin, Spacing

_PANEL_CHAMFER_SIZE: int = 5
_PANEL_MARGIN: Margin = Margin(6, 6, 6, 6)
_PAGE_NAME_BACKGROUND_MARGIN: Margin = Margin(4, 0, 4, 0)
_PAGE_NAME_BACKGROUND_HEIGHT: int = 19
_FIELD_SPACING: Spacing = Spacing(0, 2)
_PAGE_TEXT_BACKGROUND_MARGIN: Margin = Margin(4, 0, 4, 4)

_COL_NORMAL_CARD_BACK: str = general_colours.ITEM_NORMAL_BACK
_COL_SELECTED_CARD_BACK: str = general_colours.ITEM_SELECTED_BACK
_COL_PAGE_NAME_BACK: str = general_colours.VALUE_PAGE_BACK
_COL_PAGE_NAME_FORE: str = general_colours.VALUE_PAGE_FORE
_COL_TEXT_BACK: str = general_colours.VALUE_TEXT_BACK

class PageTextPanel:
    def __init__(self, *, index: int, tease_page: TeasePage, list_of_field_matches: Sequence[IFieldMatch], abbreviate_text: bool, show_page_ref: bool, canvas: StyledCanvas, left: int, top: int, width: int, font: tkfont.Font, height_changed_callback: Callable[[int], None]) -> None:
        self._index: int = index
        self._tease_page: TeasePage = tease_page
        self._canvas: StyledCanvas = canvas
        self._font: tkfont.Font = font
        self._height_changed_callback: Callable[[int], None] = height_changed_callback

        self._top: int = top
        self._bottom: int = top
        self._tag: str = f'page{index}'

        self._panel_background: CanvasChamferRectangle = CanvasChamferRectangle(
            canvas,
            chamfer_size = _PANEL_CHAMFER_SIZE,
            left = left,
            top = self._top,
            width = width,
            height = _PANEL_CHAMFER_SIZE * 2,
            fill = _COL_NORMAL_CARD_BACK,
            tags = self._tag,
        )

        self._page_name_background: CanvasRectangle | None = None
        self._page_name: CanvasPlainText | None = None

        if show_page_ref:
            self._create_page_ref()

        text_top: int
        if self._page_name_background:
            text_top = self._page_name_background.bounds.bottom + _FIELD_SPACING.vertical
        else:
            text_top = self._panel_background.bounds.top + _PANEL_MARGIN.top

        self._page_text_background: CanvasRectangle = CanvasRectangle(
            canvas,
            left = self._panel_background.bounds.left + _PANEL_MARGIN.left,
            top = text_top,
            right = self._panel_background.bounds.right - _PANEL_MARGIN.right,
            height = 0,
            fill = _COL_TEXT_BACK,
            tags = self._tag,
        )

        self._page_text: CanvasWrappedText = CanvasWrappedText(
            canvas = canvas,
            origin_x = self._page_text_background.bounds.left + _PAGE_TEXT_BACKGROUND_MARGIN.left,
            origin_y = self._page_text_background.bounds.top + _PAGE_TEXT_BACKGROUND_MARGIN.top,
            width = self._page_text_background.bounds.width - _PAGE_TEXT_BACKGROUND_MARGIN.width,
            line_count = 'dynamic',
            text = tease_page.text,
            style = general_style.TEXT_CARD_SUMMARY,
            list_of_indices = get_matching_indices_for_page(tease_page, list_of_field_matches),
            abbreviate_text = abbreviate_text,
            line_count_changed_callback = self._on_page_text_height_changed,
        )

    def set_top(self, top: int) -> None:
        self._top = top
        self._panel_background.move_to(top = self._top)
        if self._page_name_background and self._page_name:
            self._page_name_background.move_to(top = self._panel_background.bounds.top + _PANEL_MARGIN.top)
            self._page_name.move_to(top = self._page_name_background.bounds.top + _PAGE_NAME_BACKGROUND_MARGIN.top)

        text_top: int
        if self._page_name_background:
            text_top = self._page_name_background.bounds.bottom + _FIELD_SPACING.vertical
        else:
            text_top = self._panel_background.bounds.top + _PANEL_MARGIN.top

        self._page_text_background.move_to(top = text_top)
        self._page_text.move_to(top = self._page_text_background.bounds.top + _PAGE_TEXT_BACKGROUND_MARGIN.top)
        self._bottom = self._panel_background.bounds.bottom

    def set_width(self, width: int) -> None:
        self._panel_background.resize(width = width)
        if self._page_name_background:
            self._page_name_background.resize(width = self._panel_background.bounds.width - _PANEL_MARGIN.width)
        self._page_text_background.resize(width = self._panel_background.bounds.width - _PANEL_MARGIN.width)
        self._page_text.resize(width = self._page_text_background.bounds.width - _PANEL_MARGIN.width)

    @property
    def top(self) -> int:
        return self._top

    @property
    def bottom(self) -> int:
        return self._bottom

    @property
    def tease_page(self) -> TeasePage:
        return self._tease_page

    def set_abbreviate_text(self, abbreviate_text: bool) -> None: # noqa: FBT001 Boolean-typed positional argument in function definition
        self._page_text.set_abbreviate_text(abbreviate_text = abbreviate_text)

    def set_show_page_ref(self, show: bool) -> None: # noqa: FBT001 Boolean-typed positional argument in function definition
        if show:
            if not self._page_name_background:
                self._create_page_ref()
                if self._page_name_background:
                    self._page_text_background.move_to(top = self._page_name_background.bounds.bottom + _FIELD_SPACING.vertical)
                    self._page_text.move_to(top = self._page_text_background.bounds.top + _PAGE_TEXT_BACKGROUND_MARGIN.top)
                    self._panel_background.change(bottom = self._page_text_background.bounds.bottom + _PANEL_MARGIN.bottom)
                    self._bottom = self._panel_background.bounds.bottom
                    self._height_changed_callback(self._index)
        elif self._page_name_background and self._page_name:
            self._canvas.delete(self._page_name_background.widget_id)
            self._page_name_background = None
            self._page_name.destroy()
            self._page_name = None
            self._page_text_background.move_to(top = self._panel_background.bounds.top + _PANEL_MARGIN.top)
            self._page_text.move_to(top = self._page_text_background.bounds.top + _PAGE_TEXT_BACKGROUND_MARGIN.top)
            self._panel_background.change(bottom = self._page_text_background.bounds.bottom + _PANEL_MARGIN.bottom)
            self._bottom = self._panel_background.bounds.bottom
            self._height_changed_callback(self._index)

    def select(self) -> None:
        self._panel_background.set_fill(_COL_SELECTED_CARD_BACK)

    def deselect(self) -> None:
        self._panel_background.set_fill(_COL_NORMAL_CARD_BACK)

    def destroy(self) -> None:
        self._canvas.delete(self._tag)
        self._page_text.destroy()

    def _create_page_ref(self) -> None:
        self._page_name_background = CanvasRectangle(
            canvas = self._canvas,
            left = self._panel_background.bounds.left + _PANEL_MARGIN.left,
            top = self._panel_background.bounds.top + _PANEL_MARGIN.top,
            right = self._panel_background.bounds.right - _PANEL_MARGIN.right,
            height = _PAGE_NAME_BACKGROUND_HEIGHT,
            fill = _COL_PAGE_NAME_BACK,
            tags = self._tag,
        )

        self._page_name = CanvasPlainText(
            canvas = self._canvas,
            origin_x = self._page_name_background.bounds.left + _PAGE_NAME_BACKGROUND_MARGIN.left,
            origin_y = self._page_name_background.bounds.top + _PAGE_NAME_BACKGROUND_MARGIN.top,
            text = self._tease_page.page_ref,
            anchor = tk.NW,
            font = self._font,
            fill = _COL_PAGE_NAME_FORE,
            tags = self._tag,
        )

    def _on_page_text_height_changed(self) -> None:
        self._page_text_background.resize(height = self._page_text.height + _PAGE_TEXT_BACKGROUND_MARGIN.height)
        self._panel_background.change(bottom = self._page_text_background.bounds.bottom + _PANEL_MARGIN.bottom)
        self._bottom = self._panel_background.bounds.bottom
        self._height_changed_callback(self._index)
