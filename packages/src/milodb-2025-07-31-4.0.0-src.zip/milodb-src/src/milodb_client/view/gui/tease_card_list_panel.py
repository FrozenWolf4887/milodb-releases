# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import itertools
import tkinter as tk
import tkinter.font as tkfont
from collections.abc import Callable, Sequence
from tkinter import ttk
from typing import TYPE_CHECKING, override
from milodb_client.database.tease import Tease
from milodb_client.database.thumbnail_database import ThumbnailDatabase
from milodb_client.query.tease_match import TeaseMatch
from milodb_client.view.gui import general_colours, general_font, general_style, generated_images
from milodb_client.view.gui.banner_text import BANNER_NO_MATCHING_TEASES
from milodb_client.view.gui.canvas_widgets import CanvasPlainText, get_canvas_event_relative_coord
from milodb_client.view.gui.popup_menu_call import PopupOrigin, PopupTeaseMenuCallback
from milodb_client.view.gui.styled_canvas import StyledCanvas
from milodb_client.view.gui.styled_frame import StyledFrame
from milodb_client.view.gui.tease_card_panel import TeaseCardPanel
from milodb_client.view.gui.util.datum import IValueDatum, SuppressingDatum
from milodb_common.view.gui.metrics import Padding, Point, Size
if TYPE_CHECKING:
    from PIL import Image

_SCROLL_PAGE_UNITS: int = 10
_LINUX_AND_OSX_MOUSEWHEEL_UP_BUTTON: int = 5
_LINUX_AND_OSX_MOUSEWHEEL_DOWN_BUTTON: int = 4
_CARD_PADDING: Padding = Padding(4, 4, 4, 0)
_COL_BANNER_FORE: str = general_colours.VALUE_TEXT_FORE

_TEASE_TYPE_IMAGE_HEIGHT: int = 23
_TOTM_IMAGE_HEIGHT: int = 23
_RATING_IMAGE_HEIGHT: int = 15
_AUTHOR_STATUS_IMAGE_HEIGHT: int = 15
_TEASE_STATUS_IMAGE_HEIGHT: int = 15

class TeaseCardListPanel(StyledFrame):
    def __init__(self, master: tk.Misc, list_of_tease_matches: IValueDatum[Sequence[TeaseMatch]], selected_tease_index: IValueDatum[int | None], thumbnail_database: ThumbnailDatabase, call_open_tease: Callable[[Tease], None], call_popup_tease_menu: PopupTeaseMenuCallback) -> None:
        super().__init__(master, style=general_style.FRAME_PANEL)
        self._list_of_tease_matches: IValueDatum[Sequence[TeaseMatch]] = list_of_tease_matches
        self._selected_tease_index: SuppressingDatum[int | None] = SuppressingDatum(selected_tease_index)
        self._thumbnail_database: ThumbnailDatabase = thumbnail_database
        self._call_open_tease: Callable[[Tease], None] = call_open_tease
        self._call_popup_tease_menu: PopupTeaseMenuCallback = call_popup_tease_menu

        self._font: tkfont.Font = tkfont.Font(self, general_font.NORMAL_FONT_TUPLE)
        self._italic_font: tkfont.Font = tkfont.Font(self, general_font.ITALIC_FONT_TUPLE)
        self._banner_font: tkfont.Font = tkfont.Font(self, general_font.BANNER_FONT_TUPLE)
        self._text_height: int = self._font.metrics('linespace')
        self._update_all_cards_event_id: str | None = None

        self._rating_filled_image: Image.Image = generated_images.render_rating_filled_image(image_height=_RATING_IMAGE_HEIGHT)
        self._rating_hollow_image: Image.Image = generated_images.render_rating_hollow_image(image_height=_RATING_IMAGE_HEIGHT)
        self._deleted_tease_image: Image.Image = generated_images.render_deleted_tease_image(image_height=_TEASE_STATUS_IMAGE_HEIGHT)
        self._gone_author_image: Image.Image = generated_images.render_gone_author_image(image_height=_AUTHOR_STATUS_IMAGE_HEIGHT)
        self._unknown_author_image: Image.Image = generated_images.render_unknown_author_image(image_height=_AUTHOR_STATUS_IMAGE_HEIGHT)
        self._totm_nominee_image: Image.Image = generated_images.render_totm_nominee_image(image_height=_TOTM_IMAGE_HEIGHT)
        self._totm_winner_image: Image.Image = generated_images.render_totm_winner_image(image_height=_TOTM_IMAGE_HEIGHT)
        self._eos_image: Image.Image = generated_images.render_eos_image(image_height=_TEASE_TYPE_IMAGE_HEIGHT)
        self._flash_image: Image.Image = generated_images.render_flash_image(image_height=_TEASE_TYPE_IMAGE_HEIGHT)
        self._audio_image: Image.Image = generated_images.render_audio_image(image_height=_TEASE_TYPE_IMAGE_HEIGHT)
        self._classic_image: Image.Image = generated_images.render_regular_image(image_height=_TEASE_TYPE_IMAGE_HEIGHT)
        self._map_of_tease_index_to_card: dict[int, TeaseCardPanel] = {}
        self._current_top_index: int = 0
        self._current_bottom_index: int = -1
        self._current_canvas_size: Size | None = None
        self._current_selection_index: int | None = None
        self._banner_text: CanvasPlainText | None = None

        self._create_canvas()
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=1)

        self._list_of_tease_matches.add_new_value_listener(self._on_list_of_tease_matches_changed, call_immediately=True)
        self._selected_tease_index.add_new_value_listener(self._on_selected_tease_index_changed, call_immediately=True)

    @override
    def destroy(self) -> None:
        self._list_of_tease_matches.remove_listener(self._on_list_of_tease_matches_changed)
        self._selected_tease_index.remove_listener(self._on_selected_tease_index_changed)
        self._destroy_all_cards()
        self._destroy_banner_text()
        super().destroy()

    def _on_list_of_tease_matches_changed(self, new_value: Sequence[TeaseMatch]) -> None:
        content_height: int = len(new_value) * (TeaseCardPanel.HEIGHT + _CARD_PADDING.height)
        self._canvas.config(scrollregion=(0, 0, 0, content_height))
        self._canvas.yview_moveto(0)
        self._destroy_all_cards()
        self._update_all_cards()

    def _on_selected_tease_index_changed(self, new_value: int | None) -> None:
        self._select_card(new_value)
        if new_value is not None:
            self._ensure_visible_card(new_value)

    def _ensure_visible_card(self, card_index: int) -> None:
        number_of_cards: int = len(self._list_of_tease_matches.get())
        top_index, bottom_index = self._get_visible_top_and_bottom_row_indices(include_partially_visible=False)
        if card_index < top_index or card_index > bottom_index:
            max_card_cards_per_panel: float = self._canvas.winfo_height() / (TeaseCardPanel.HEIGHT + _CARD_PADDING.height)
            scroll_position: float = max(0.0, (card_index - (max_card_cards_per_panel / 2) + 0.5) / number_of_cards)
            self._canvas.yview_moveto(scroll_position)
            if self._update_all_cards_event_id is None:
                self._update_all_cards_event_id = self._canvas.after_idle(self._on_idle_update_all_cards)

    def _destroy_all_cards(self) -> None:
        if self._update_all_cards_event_id is not None:
            self._canvas.event_delete(self._update_all_cards_event_id)
            self._update_all_cards_event_id = None

        card: TeaseCardPanel
        for card in self._map_of_tease_index_to_card.values():
            card.destroy()
        self._map_of_tease_index_to_card = {}
        self._current_top_index = 0
        self._current_bottom_index = -1

    def _resize_all_cards(self) -> None:
        card_width: int = self._canvas.winfo_width() - _CARD_PADDING.width

        card: TeaseCardPanel
        for card in self._map_of_tease_index_to_card.values():
            card.resize(width = card_width)

    def _create_canvas(self) -> None:
        self._canvas: StyledCanvas = StyledCanvas(self)
        self._canvas.grid(row=1, column=0, sticky=tk.NSEW)
        self._canvas.bind('<Configure>', self._on_canvas_changed)

        scrollbar: ttk.Scrollbar = ttk.Scrollbar(self, orient=tk.VERTICAL, command=self._on_vertical_scroll)
        scrollbar.grid(row=1, column=1, sticky=tk.NS)
        self._canvas.config(yscrollcommand=scrollbar.set)

        self._canvas.bind("<MouseWheel>", lambda event: self._scroll_vertically(_get_scroll_direction_from_event(event)))
        self._canvas.bind("<Button-4>", lambda event: self._scroll_vertically(_get_scroll_direction_from_event(event)))
        self._canvas.bind("<Button-5>", lambda event: self._scroll_vertically(_get_scroll_direction_from_event(event)))
        self._canvas.bind("<Control-MouseWheel>", lambda event: self._scroll_vertically(_get_scroll_direction_from_event(event) * _SCROLL_PAGE_UNITS))
        self._canvas.bind("<Control-Button-4>", lambda event: self._scroll_vertically(_get_scroll_direction_from_event(event) * _SCROLL_PAGE_UNITS))
        self._canvas.bind("<Control-Button-5>", lambda event: self._scroll_vertically(_get_scroll_direction_from_event(event) * _SCROLL_PAGE_UNITS))

        self._canvas.bind('<Button-1>', self._on_mouse_click)
        self._canvas.bind('<Double-1>', self._on_mouse_double_click)
        self._canvas.bind('<Button-2>', self._on_mouse_right_click)
        self._canvas.bind('<Button-3>', self._on_mouse_right_click)

    def _get_visible_top_and_bottom_row_indices(self, *, include_partially_visible: bool) -> tuple[int, int]:
        canvas_height: int = self._canvas.winfo_height()
        top_index: int
        bottom_index: int
        if include_partially_visible:
            top_index = int(self._canvas.canvasy(0) // (TeaseCardPanel.HEIGHT + _CARD_PADDING.height))
            bottom_index = int(self._canvas.canvasy(canvas_height - 1) // (TeaseCardPanel.HEIGHT + _CARD_PADDING.height))
        else:
            top_index = int(self._canvas.canvasy(TeaseCardPanel.HEIGHT) // (TeaseCardPanel.HEIGHT + _CARD_PADDING.height))
            bottom_index = int(self._canvas.canvasy(canvas_height - 1 - TeaseCardPanel.HEIGHT) // (TeaseCardPanel.HEIGHT + _CARD_PADDING.height))
        return top_index, bottom_index

    def _update_all_cards(self) -> None:
        self._destroy_banner_text()
        if not self._list_of_tease_matches:
            self._add_banner_text(BANNER_NO_MATCHING_TEASES)

        top_index: int
        bottom_index: int
        top_index, bottom_index = self._get_visible_top_and_bottom_row_indices(include_partially_visible = True)
        bottom_index = min(bottom_index, len(self._list_of_tease_matches.get()) - 1)

        card_width: int = self._canvas.winfo_width() - _CARD_PADDING.width

        # Draw rows coming into view

        for index in itertools.chain(
                range(max(self._current_bottom_index + 1, top_index), bottom_index + 1),
                range(top_index, min(self._current_top_index, bottom_index + 1)),
            ):
            self._map_of_tease_index_to_card[index] = TeaseCardPanel(
                thumbnail_database = self._thumbnail_database,
                tease_index = index,
                tease_match = self._list_of_tease_matches.get()[index],
                left = _CARD_PADDING.left,
                top = index * (TeaseCardPanel.HEIGHT + _CARD_PADDING.height) + _CARD_PADDING.top,
                width = card_width,
                canvas = self._canvas,
                font = self._font,
                italic_font = self._italic_font,
                rating_filled_image = self._rating_filled_image,
                rating_hollow_image = self._rating_hollow_image,
                deleted_tease_image = self._deleted_tease_image,
                gone_author_image = self._gone_author_image,
                unknown_author_image = self._unknown_author_image,
                totm_nominee_image = self._totm_nominee_image,
                totm_winner_image = self._totm_winner_image,
                eos_image = self._eos_image,
                flash_image = self._flash_image,
                audio_image = self._audio_image,
                classic_image = self._classic_image,
                is_selected = index==self._current_selection_index,
            )

        # Remove rows dropped out of view

        for index in itertools.chain(
                range(self._current_top_index, min(top_index, self._current_bottom_index + 1)),
                range(max(bottom_index + 1, self._current_top_index), self._current_bottom_index + 1),
            ):
            self._map_of_tease_index_to_card.pop(index).destroy()

        self._current_top_index = top_index
        self._current_bottom_index = bottom_index

    def _add_banner_text(self, text: str) -> None:
        self._banner_text = CanvasPlainText(
            self._canvas,
            origin_x = self._canvas.winfo_width() // 2,
            origin_y = _CARD_PADDING.top,
            text = text,
            fill = _COL_BANNER_FORE,
            font = self._banner_font,
            justify = tk.CENTER,
            anchor = tk.N,
        )

    def _destroy_banner_text(self) -> None:
        if self._banner_text:
            self._banner_text.destroy()
            self._banner_text = None

    def _on_vertical_scroll(self, *args: object) -> None:
        if self._canvas.yview() != (0.0, 1.0):
            self._canvas.yview(*args)
            if self._update_all_cards_event_id is None:
                self._update_all_cards_event_id = self._canvas.after_idle(self._on_idle_update_all_cards)

    def _on_idle_update_all_cards(self) -> None:
        self._update_all_cards_event_id = None
        self._update_all_cards()

    def _scroll_vertically(self, scroll_value: int) -> None:
        if scroll_value and self._canvas.yview() != (0.0, 1.0):
            self._canvas.yview_scroll(scroll_value, 'units')
            self._update_all_cards()

    def _on_canvas_changed(self, _event: object) -> None:
        new_width: int = self._canvas.winfo_width()
        new_height: int = self._canvas.winfo_height()
        width_changed: bool = self._current_canvas_size is None or self._current_canvas_size.width != new_width
        height_changed: bool = self._current_canvas_size is None or self._current_canvas_size.height != new_height
        if not (width_changed or height_changed):
            return

        self._current_canvas_size = Size(new_width, new_height)

        if width_changed:
            self._resize_all_cards()
        self._update_all_cards()

    def _on_mouse_click(self, event: tk.Event) -> str: # type: ignore[type-arg]
        card_index: int | None = self._get_card_index_from_event(event)
        if card_index is not None:
            self._select_card(card_index)
            self._selected_tease_index.set(card_index)
        return 'break'

    def _on_mouse_double_click(self, event: tk.Event) -> str: # type: ignore[type-arg]
        card_index: int | None = self._get_card_index_from_event(event)
        if card_index is not None:
            tease_match: TeaseMatch = self._list_of_tease_matches.get()[card_index]
            self._call_open_tease(tease_match.tease)
        return 'break'

    def _on_mouse_right_click(self, event: tk.Event) -> str: # type: ignore[type-arg]
        card_index: int | None = self._get_card_index_from_event(event)
        if card_index is not None:
            self._select_card(card_index)
            self._selected_tease_index.set(card_index)
            tease_match: TeaseMatch = self._list_of_tease_matches.get()[card_index]
            self._call_popup_tease_menu(self._canvas, event.x_root, event.y_root, tease_match, PopupOrigin.TEASE_CARD)
        return 'break'

    def _get_card_index_from_event(self, event: tk.Event) -> int | None: # type: ignore [type-arg]
        point: Point = get_canvas_event_relative_coord(self._canvas, event)
        return self._get_card_index_from_y_offset(int(point.y))

    def _get_card_index_from_y_offset(self, pos_y: int) -> int | None:
        if pos_y >= _CARD_PADDING.top:
            pos_y -= _CARD_PADDING.top
        card_index: int = pos_y // (TeaseCardPanel.HEIGHT + _CARD_PADDING.height)
        if card_index < len(self._list_of_tease_matches.get()):
            return card_index
        return None

    def _select_card(self, tease_index: int | None) -> None:
        if self._current_selection_index == tease_index:
            return

        card: TeaseCardPanel | None
        if self._current_selection_index is not None:
            card = self._map_of_tease_index_to_card.get(self._current_selection_index)
            if card:
                card.deselect()
        self._current_selection_index = tease_index
        if self._current_selection_index is not None:
            card = self._map_of_tease_index_to_card.get(self._current_selection_index)
            if card:
                card.select()

def _get_scroll_direction_from_event(event: tk.Event) -> int: # type: ignore[type-arg]
    if event.num == _LINUX_AND_OSX_MOUSEWHEEL_UP_BUTTON or event.delta < 0:
        return 1
    if event.num == _LINUX_AND_OSX_MOUSEWHEEL_DOWN_BUTTON or event.delta > 0:
        return -1
    return 0
