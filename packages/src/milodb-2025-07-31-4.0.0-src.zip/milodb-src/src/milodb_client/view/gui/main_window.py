# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import tempfile
import tkinter as tk
from collections.abc import Sequence
from functools import partial
from pathlib import Path
from tkinter import ttk
from typing import Protocol, TYPE_CHECKING
import pyclip # type: ignore[import-untyped]
from PIL import Image, ImageTk
from milodb_client.config.ansi_config import AnsiConfig
from milodb_client.config.bbcode_config import BBCodeConfig
from milodb_client.config.html_config import HtmlConfig
from milodb_client.config.launch_config import BrowseLaunchConfig, OpenLaunchConfig
from milodb_client.config.update_config import UpdateConfig
from milodb_client.database.author import Author
from milodb_client.database.tease import Tease
from milodb_client.database.tease_page import TeasePage
from milodb_client.database.thumbnail_database import ThumbnailDatabase
from milodb_client.output.format.ansi_formatter import AnsiFormatter
from milodb_client.output.format.bbcode_formatter import BBCodeFormatter
from milodb_client.output.format.formatter_factory import FormatterCreator
from milodb_client.output.format.html_file_writer import HtmlFileWriter
from milodb_client.output.format.html_formatter import HtmlFormatter
from milodb_client.output.format.i_formatter import IFormatter
from milodb_client.output.format.plain_formatter import PlainFormatter
from milodb_client.query.tease_match import TeaseMatch
from milodb_client.resources import resource_path
from milodb_client.startup.shutdown_action import IShutdownAction
from milodb_client.updater.local_file_hasher import LocalFileHasher
from milodb_client.updater.local_file_tester import LocalFileTester
from milodb_client.updater.manifest.local_manifest import ILocalManifest
from milodb_client.updater.temp_directory import TempDirectoryCreator
from milodb_client.util.database_stats import DatabaseStats
from milodb_client.util.launcher import launch
from milodb_client.util.sort_keys import DATE_SORT_KEY, OrderedSortKey, TEASE_ID_SORT_KEY
from milodb_client.util.tease_match_sorter import ITeaseMatchSorter, TeaseMatchSorter
from milodb_client.view.gui import general_colours, general_layout
from milodb_client.view.gui.about_dialog import AboutDialog
from milodb_client.view.gui.browse_panel import BrowsePanel
from milodb_client.view.gui.config_dialog import ConfigDialog
from milodb_client.view.gui.log_dialog import LogDialog
from milodb_client.view.gui.match_info_panel import MatchInfoPanel
from milodb_client.view.gui.popup_menu_call import PopupOrigin
from milodb_client.view.gui.raw_query_panel import RawQueryPanel
from milodb_client.view.gui.stats_dialog import StatsDialog
from milodb_client.view.gui.styled_frame import StyledFrame
from milodb_client.view.gui.table_list_panel import TableListPanel
from milodb_client.view.gui.tease_card_list_panel import TeaseCardListPanel
from milodb_client.view.gui.text_matches_panel import TextMatchesPanel
from milodb_client.view.gui.theme import configure_ttk_styles
from milodb_client.view.gui.toolbar_panel import ToolbarPanel
from milodb_client.view.gui.update_dialog import UpdateDialog
from milodb_client.view.gui.util.datum import Datum, IValueDatum, ValueDatum
from milodb_common.config.framework import IConfigGroup, IPersistentConfig
from milodb_common.config.i_launch_config import LaunchOption
from milodb_common.internet.url_scraper_factory import UrlScraperFactory
from milodb_common.output.print.capturing_printer import CapturingPrinter
from milodb_common.output.print.file_printer import FilePrinter
from milodb_common.util.get_url import get_url_of_author, get_url_of_author_teases, get_url_of_tease
from milodb_common.util.ref import IRef
from milodb_common.variables.i_user_variables import IPersistentUserVariables
if TYPE_CHECKING:
    from milodb_client.output.format.i_formatter_factory import IFormatterCreator
    from milodb_client.output.format.i_html_file_writer import IHtmlFileWriter
    from milodb_common.config.i_launch_config import ILaunchConfig

# spell-checker: disable
_ICON_DATA_URI: str = r"data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20xml:space='preserve'%20width='122mm'%20height='123mm'%20viewBox='0%200%20122%20123'%3e%3cg%20transform='translate(-47%20-120)'%3e%3cpath%20d='m131%20192%2037%2037a6.35%206.35%2090%200%201%200%208l-5%205a6.35%206.35%200%200%201-8%200l-37-37z'%20style='fill:%23fff;stroke-width:0;stroke-linecap:round;stroke-linejoin:round'/%3e%3ccircle%20cx='97'%20cy='170'%20r='50'%20style='fill:%23fff;fill-opacity:1;stroke:none;stroke-width:0;stroke-linecap:round;stroke-linejoin:round;stroke-dasharray:none;stroke-opacity:1'/%3e%3cpath%20d='m131%20197%208%207-9%209-7-8z'%20style='fill:%23616161;stroke-width:0;stroke-linecap:round;stroke-linejoin:round'/%3e%3ccircle%20cx='97'%20cy='170'%20r='47'%20style='fill:%23616161;fill-opacity:1;stroke:none;stroke-width:0;stroke-linecap:round;stroke-linejoin:round;stroke-dasharray:none;stroke-opacity:1'/%3e%3ccircle%20cx='97'%20cy='170'%20r='40'%20style='fill:%23f1c3c3;fill-opacity:1;stroke:none;stroke-width:0;stroke-linecap:round;stroke-linejoin:round;stroke-dasharray:none;stroke-opacity:1'/%3e%3cpath%20d='M88%20190c-1-3-1-7-10-15-11.9-13-1-32%2013-22%206%203%208%203%2012%201%2020-16%2027%2018%203%2034-11%209-16%2013-18%202z'%20style='fill:%23b85a5a;fill-opacity:1;stroke:none;stroke-width:12.011;stroke-dasharray:none;stroke-opacity:1'/%3e%3cpath%20d='M88%20190c-1-3-2-8-10-15-12.3-12-1-32%2013-22%206%203%208%203%2012%201%2020-16%2027%2018%203%2034-11%209-16%2013-18%202z'%20style='mix-blend-mode:normal;fill:none;fill-opacity:1;stroke:%23b14d4d;stroke-width:12.011;stroke-dasharray:none;stroke-opacity:.459'/%3e%3cpath%20d='m139%20204%2026%2026a3.97%203.97%2090%200%201%200%206l-3%203a3.97%203.97%20180%200%201-6%200l-26-26z'%20style='fill:%2337474f;fill-opacity:1;stroke-width:0;stroke-linecap:round;stroke-linejoin:round'/%3e%3c/g%3e%3c/svg%3e"
# spell-checker: enable

_COL_PANEL_BACK: str = general_colours.PANEL_BACK

_LAYOUT_PANEL_MARGIN_X: int = general_layout.PANEL_MARGIN_X
_LAYOUT_PANEL_MARGIN_Y: int = general_layout.PANEL_MARGIN_Y

_TEMP_ELLIPSIS_MAX_WIDTH: int = 40
_MAX_BROWSE_TEASE_MATCHES: int = 100

class _CreateFormatterCall(Protocol):
    def __call__(self, *, use_highlighting: bool, ellipsis_max_width: int | None, show_pagerefs: bool) -> IFormatter:
        ...

class MainWindow:
    def __init__(self, local_manifest: ILocalManifest | None, config: IPersistentConfig, config_schema: IConfigGroup, list_of_teases: Sequence[Tease], thumbnail_database: ThumbnailDatabase, user_variables: IPersistentUserVariables, ref_shutdown_action: IRef[IShutdownAction | None]) -> None:
        self._local_manifest: ILocalManifest | None = local_manifest
        self._config: IPersistentConfig = config
        self._config_schema: IConfigGroup = config_schema
        self._list_of_teases: Sequence[Tease] = list_of_teases
        self._thumbnail_database: ThumbnailDatabase = thumbnail_database
        self._user_variables: IPersistentUserVariables = user_variables
        self._ref_shutdown_action: IRef[IShutdownAction | None] = ref_shutdown_action

        self._update_config: UpdateConfig = UpdateConfig(config)
        self._ansi_config: AnsiConfig = AnsiConfig(config)
        self._bbcode_config: BBCodeConfig = BBCodeConfig(config)
        self._html_config: HtmlConfig = HtmlConfig(config)
        self._command_browse_launch_config: ILaunchConfig = BrowseLaunchConfig(config)
        self._command_open_launch_config: ILaunchConfig = OpenLaunchConfig(config)
        self._tease_match_sorter: ITeaseMatchSorter = TeaseMatchSorter([OrderedSortKey(DATE_SORT_KEY, is_ascending=False), OrderedSortKey(TEASE_ID_SORT_KEY, is_ascending=False)])
        self._capturing_printer: CapturingPrinter = CapturingPrinter()

        self._list_of_tease_matches: IValueDatum[Sequence[TeaseMatch]] = ValueDatum([])
        self._selected_tease_index: IValueDatum[int | None] = ValueDatum(None)
        self._list_of_active_sort_keys: IValueDatum[Sequence[OrderedSortKey]] = ValueDatum([])
        self._abbreviate_text: IValueDatum[bool] = ValueDatum(True)
        self._show_only_matching_pages: IValueDatum[bool] = ValueDatum(True)
        self._show_page_refs: IValueDatum[bool] = ValueDatum(False)
        self._browse_abbreviate_text: IValueDatum[bool] = ValueDatum(True)
        self._browse_only_matching_pages: IValueDatum[bool] = ValueDatum(True)
        self._browse_page_refs: IValueDatum[bool] = ValueDatum(False)
        self._variables_changed_event: Datum = Datum()
        self._debug_launch: IValueDatum[bool] = ValueDatum(False)
        self._database_stats: DatabaseStats = DatabaseStats(self._list_of_teases)

        self._map_of_format_names_to_creators: dict[str, _CreateFormatterCall] = {
            'as Plain Text': lambda use_highlighting, ellipsis_max_width, show_pagerefs: PlainFormatter(self._capturing_printer, ellipsis_max_width=ellipsis_max_width, show_pagerefs=show_pagerefs), # noqa: ARG005 Unused lambda argument: `use_highlighting`
            'as BBCode': lambda use_highlighting, ellipsis_max_width, show_pagerefs: BBCodeFormatter(self._bbcode_config, self._capturing_printer, use_highlighting=use_highlighting, ellipsis_max_width=ellipsis_max_width, show_pagerefs=show_pagerefs),
            'as ANSI Text': lambda use_highlighting, ellipsis_max_width, show_pagerefs: AnsiFormatter(self._ansi_config, self._capturing_printer, use_highlighting=use_highlighting, ellipsis_max_width=ellipsis_max_width, show_pagerefs=show_pagerefs),
            'as HTML': lambda use_highlighting, ellipsis_max_width, show_pagerefs: HtmlFormatter(self._html_config, self._capturing_printer, use_highlighting=use_highlighting, ellipsis_max_width=ellipsis_max_width, show_pagerefs=show_pagerefs),
        }

        html_formatter_creator: IFormatterCreator = FormatterCreator(
            'html', lambda printer: HtmlFormatter(
                HtmlConfig(self._config),
                printer,
                use_highlighting=True,
                ellipsis_max_width=_TEMP_ELLIPSIS_MAX_WIDTH if self._browse_abbreviate_text.get() else None,
                show_pagerefs=self._browse_page_refs.get(),
            ),
        )
        self._html_file_writer: IHtmlFileWriter = HtmlFileWriter(self._html_config, html_formatter_creator)

        self._reset_tease_matches()
        self._init_window()
        _support_numpad_keys(self._window)
        self._window.mainloop()

    def _init_window(self) -> None:
        self._window: tk.Tk = tk.Tk()
        self._window.configure(background=_COL_PANEL_BACK)
        self._window.title('MiloDB')

        configure_ttk_styles(self._window)

        icon: Image.Image
        with Image.open(resource_path(Path('milodb-search-icon.ico'))) as icon:
            self._window.iconphoto(True, ImageTk.PhotoImage(icon)) # noqa: FBT003 Boolean positional value in function call
        self._window.geometry('1024x600')

        top_frame: StyledFrame = StyledFrame(self._window)
        raw_query_panel: RawQueryPanel = RawQueryPanel(top_frame, self._list_of_teases, self._user_variables, self._list_of_tease_matches, self._selected_tease_index, self._tease_match_sorter, self._list_of_active_sort_keys, self._variables_changed_event)
        raw_query_panel.grid(column=0, row=0, sticky=tk.NSEW, padx=(0, _LAYOUT_PANEL_MARGIN_X))
        ToolbarPanel(top_frame, open_about_dialog=self._open_about_dialog, open_update_dialog=self._open_update_dialog, open_stats_dialog=self._open_stats_dialog, open_config_dialog=self._open_config_dialog).grid(column=1, row=0, sticky='nse')
        top_frame.columnconfigure(0, weight=1)
        top_frame.rowconfigure(0, weight=1)
        top_frame.pack(fill=tk.X, pady=(0, _LAYOUT_PANEL_MARGIN_Y))

        outer_paned_window: ttk.PanedWindow = ttk.PanedWindow(self._window, orient=tk.HORIZONTAL)
        outer_paned_window.pack(fill=tk.BOTH, expand=True)

        list_frame: StyledFrame = StyledFrame(outer_paned_window)
        browse_panel: BrowsePanel = BrowsePanel(list_frame, self._list_of_tease_matches, self._browse_only_matching_pages, self._browse_abbreviate_text, self._browse_page_refs, self._generate_summary)
        browse_panel.grid(row=0, column=0, sticky='nsw')
        match_info_panel: MatchInfoPanel = MatchInfoPanel(list_frame, self._list_of_teases, self._list_of_tease_matches, self._selected_tease_index, self._reset_tease_matches)
        match_info_panel.grid(row=0, column=1, sticky=tk.NSEW)
        inner_paned_window: ttk.PanedWindow = ttk.PanedWindow(list_frame, orient=tk.HORIZONTAL)
        inner_paned_window.grid(row=1, column=0, columnspan=2, sticky=tk.NSEW)
        list_frame.columnconfigure(1, weight=1)
        list_frame.rowconfigure(1, weight=1)

        table_list_panel: TableListPanel = TableListPanel(inner_paned_window, self._list_of_tease_matches, self._selected_tease_index, self._tease_match_sorter, self._list_of_active_sort_keys, self._open_tease, self._popup_tease_menu)
        card_list_panel: TeaseCardListPanel = TeaseCardListPanel(inner_paned_window, self._list_of_tease_matches, self._selected_tease_index, self._thumbnail_database, self._open_tease, self._popup_tease_menu)
        text_matches_panel: TextMatchesPanel = TextMatchesPanel(outer_paned_window, self._list_of_tease_matches, self._selected_tease_index, self._show_only_matching_pages, self._abbreviate_text, self._show_page_refs, self._popup_page_menu)

        outer_paned_window.add(list_frame, weight=1)
        outer_paned_window.add(text_matches_panel, weight=1)
        outer_paned_window.update()
        outer_paned_window.sashpos(0, int(outer_paned_window.winfo_width() * 0.85))

        inner_paned_window.add(table_list_panel, weight=1)
        inner_paned_window.add(card_list_panel, weight=1)
        inner_paned_window.update()
        inner_paned_window.sashpos(0, int(inner_paned_window.winfo_width() * 0.5))

        raw_query_panel.set_focus()

    def _reset_tease_matches(self) -> None:
        self._selected_tease_index.set(None)
        self._list_of_tease_matches.set(
            self._tease_match_sorter.sort([
                TeaseMatch(index + 1, tease, []) for index, tease in enumerate(self._list_of_teases)
            ],
            self._list_of_active_sort_keys.get(),
        ))

    def _generate_summary(self) -> None:
        log_dialog: LogDialog = LogDialog(self._window, debug_enabled=self._debug_launch.get())
        constrained_list_of_tease_matches: Sequence[TeaseMatch] = self._list_of_tease_matches.get()[:_MAX_BROWSE_TEASE_MATCHES]

        log_dialog.log_text.normal_printer.writeln('Generating HTML page')

        try:
            with tempfile.NamedTemporaryFile(mode='w+t', suffix='.html', encoding='utf-8', delete=False) as file:
                log_dialog.log_text.normal_printer.writeln(f"Writing to '{file.name}'")
                file_printer: FilePrinter = FilePrinter(file)
                was_successful: bool
                if self._browse_only_matching_pages.get():
                    was_successful = self._html_file_writer.try_write_browse_file_of_text_matches(constrained_list_of_tease_matches, file_printer, log_dialog.log_text.error_printer, _ICON_DATA_URI)
                else:
                    was_successful = self._html_file_writer.try_write_browse_file_of_all_text(constrained_list_of_tease_matches, file_printer, log_dialog.log_text.error_printer, _ICON_DATA_URI)
        except OSError as ex:
            log_dialog.log_text.error_printer.writeln(f'Unable to create temporary file: {ex}')
        else:
            if was_successful:
                log_dialog.log_text.normal_printer.writeln(f"Created '{file.name}'")
                launch(self._command_browse_launch_config, Path(file.name), Path(file.name).as_uri(), log_dialog.log_text.normal_printer, log_dialog.log_text.warning_printer, log_dialog.log_text.error_printer, log_dialog.log_text.debug_printer)

        was_constrained: bool = len(constrained_list_of_tease_matches) < len(self._list_of_tease_matches.get())
        if was_constrained:
            log_dialog.log_text.warning_printer.writeln(f'Limited match results to the top {_MAX_BROWSE_TEASE_MATCHES} matches')

        if log_dialog.log_text.any_warnings_or_errors or self._debug_launch.get():
            log_dialog.show_okay_button()
        else:
            log_dialog.destroy()

    def _open_about_dialog(self) -> None:
        AboutDialog(self._window, self._local_manifest)

    def _open_update_dialog(self) -> None:
        UpdateDialog(self._window, self._update_config, self._local_manifest, LocalFileHasher(), LocalFileTester(), UrlScraperFactory(), TempDirectoryCreator(), self._ref_shutdown_action, self._shutdown_app)

    def _open_stats_dialog(self) -> None:
        StatsDialog(self._window, self._database_stats)

    def _open_config_dialog(self) -> None:
        ConfigDialog(self._window, self._config, self._config_schema, self._user_variables, self._variables_changed_event, self._debug_launch)

    def _popup_tease_menu(self, parent: tk.Misc, x_root: int, y_root: int, tease_match: TeaseMatch, popup_origin: PopupOrigin) -> None:
        is_open_available: bool = self._command_open_launch_config.launch_option is not LaunchOption.NONE
        is_open_tease_available: bool = is_open_available
        is_open_author_available: bool = is_open_available and tease_match.tease.author.has_author
        is_copy_url_of_author_available: bool = tease_match.tease.author.has_author
        popup_menu: tk.Menu = tk.Menu(parent, tearoff=0)
        popup_menu.add_command(label='Open Tease', command=lambda: self._open_tease(tease_match.tease), state=tk.NORMAL if is_open_tease_available else tk.DISABLED)
        popup_menu.add_command(label='Open Author Profile', command=lambda: self._open_author_profile(tease_match.tease.author), state=tk.NORMAL if is_open_author_available else tk.DISABLED)
        popup_menu.add_command(label='Open Author Tease List', command=lambda: self._open_author_tease_list(tease_match.tease.author), state=tk.NORMAL if is_open_author_available else tk.DISABLED)
        popup_menu.add_separator()
        popup_menu.add_command(label='Copy URL of Tease', command=lambda: self._copy_url_of_tease(tease_match.tease))
        popup_menu.add_command(label='Copy URL of Author Profile', command=lambda: self._copy_url_of_author_profile(tease_match.tease.author), state=tk.NORMAL if is_copy_url_of_author_available else tk.DISABLED)
        popup_menu.add_separator()
        match popup_origin:
            case PopupOrigin.TEASE_CARD:
                copy_card_menu: tk.Menu = tk.Menu(popup_menu, tearoff=0)
                format_name: str
                formatter_creator: _CreateFormatterCall
                for format_name, formatter_creator in self._map_of_format_names_to_creators.items():
                    copy_card_menu.add_command(label=format_name, command=partial(self._copy_card, tease_match, formatter_creator(use_highlighting=True, ellipsis_max_width=None, show_pagerefs=False)))
                popup_menu.add_cascade(label='Copy Card', menu=copy_card_menu)
            case PopupOrigin.LIST_ROW:
                list_row_menu: tk.Menu = tk.Menu(popup_menu, tearoff=0)
                for format_name, formatter_creator in self._map_of_format_names_to_creators.items():
                    list_row_menu.add_command(label=format_name, command=partial(self._copy_list_row, tease_match, formatter_creator(use_highlighting=True, ellipsis_max_width=None, show_pagerefs=False)))
                popup_menu.add_cascade(label='Copy Row', menu=list_row_menu)
        popup_menu.tk_popup(x_root, y_root)
        popup_menu.focus()
        popup_menu.bind('<FocusOut>', lambda _event: popup_menu.destroy())

    def _popup_page_menu(self, parent: tk.Misc, x_root: int, y_root: int, tease_match: TeaseMatch, tease_page: TeasePage | None, *, has_matching_pages: bool) -> None:
        popup_menu: tk.Menu = tk.Menu(parent, tearoff=0)
        if tease_page:
            copy_page_menu: tk.Menu = tk.Menu(popup_menu, tearoff=0)
            format_name: str
            formatter_creator: _CreateFormatterCall
            for format_name, formatter_creator in self._map_of_format_names_to_creators.items():
                copy_page_menu.add_command(label=format_name, command=partial(self._copy_page_text, tease_match, tease_page, formatter_creator(use_highlighting=True, ellipsis_max_width=_TEMP_ELLIPSIS_MAX_WIDTH if self._abbreviate_text.get() else None, show_pagerefs=self._show_page_refs.get())))
            popup_menu.add_cascade(label='Copy Page', menu=copy_page_menu)
        else:
            popup_menu.add_command(label='Copy Page', state=tk.DISABLED)

        if has_matching_pages:
            copy_matching_pages_menu: tk.Menu = tk.Menu(popup_menu, tearoff=0)
            for format_name, formatter_creator in self._map_of_format_names_to_creators.items():
                copy_matching_pages_menu.add_command(label=format_name, command=partial(self._copy_matching_pages_text, tease_match, formatter_creator(use_highlighting=True, ellipsis_max_width=_TEMP_ELLIPSIS_MAX_WIDTH if self._abbreviate_text.get() else None, show_pagerefs=self._show_page_refs.get())))
            popup_menu.add_cascade(label='Copy Matching Pages', menu=copy_matching_pages_menu)
        else:
            popup_menu.add_command(label='Copy Matching Pages', state=tk.DISABLED)

        if tease_match.tease.get_list_of_pages():
            copy_all_pages_menu: tk.Menu = tk.Menu(popup_menu, tearoff=0)
            for format_name, formatter_creator in self._map_of_format_names_to_creators.items():
                copy_all_pages_menu.add_command(label=format_name, command=partial(self._copy_all_pages_text, tease_match, formatter_creator(use_highlighting=True, ellipsis_max_width=_TEMP_ELLIPSIS_MAX_WIDTH if self._abbreviate_text.get() else None, show_pagerefs=self._show_page_refs.get())))
            popup_menu.add_cascade(label='Copy All Pages', menu=copy_all_pages_menu)
        else:
            popup_menu.add_command(label='Copy All Pages', state=tk.DISABLED)

        popup_menu.tk_popup(x_root, y_root)
        popup_menu.focus()
        popup_menu.bind('<FocusOut>', lambda _event: popup_menu.destroy())

    def _open_tease(self, tease: Tease) -> None:
        is_open_available: bool = self._command_open_launch_config.launch_option is not LaunchOption.NONE
        if not is_open_available:
            return
        log_dialog: LogDialog = LogDialog(self._window, debug_enabled=self._debug_launch.get())
        tease_id: int = tease.get_tease_id()
        log_dialog.log_text.normal_printer.writeln(f"Opening tease #{tease_id} '{tease.get_title()}'")
        tease_url: str = get_url_of_tease(tease_id)
        launch(self._command_open_launch_config, None, tease_url, log_dialog.log_text.normal_printer, log_dialog.log_text.warning_printer, log_dialog.log_text.error_printer, log_dialog.log_text.debug_printer)
        if log_dialog.log_text.any_warnings_or_errors or self._debug_launch.get():
            log_dialog.show_okay_button()
        else:
            log_dialog.destroy()

    def _open_author_profile(self, author: Author) -> None:
        is_open_available: bool = self._command_open_launch_config.launch_option is not LaunchOption.NONE
        if not is_open_available:
            return
        log_dialog: LogDialog = LogDialog(self._window, debug_enabled=self._debug_launch.get())
        if author.has_author:
            log_dialog.log_text.normal_printer.writeln(f"Opening author profile @{author.author_id} '{author.name}'")
            author_url: str = get_url_of_author(author.author_id)
            launch(self._command_open_launch_config, None, author_url, log_dialog.log_text.normal_printer, log_dialog.log_text.warning_printer, log_dialog.log_text.error_printer, log_dialog.log_text.debug_printer)
        else:
            log_dialog.log_text.error_printer.writeln('Cannot open author profile because the author is not known')
        if log_dialog.log_text.any_warnings_or_errors or self._debug_launch.get():
            log_dialog.show_okay_button()
        else:
            log_dialog.destroy()

    def _open_author_tease_list(self, author: Author) -> None:
        is_open_available: bool = self._command_open_launch_config.launch_option is not LaunchOption.NONE
        if not is_open_available:
            return
        log_dialog: LogDialog = LogDialog(self._window, debug_enabled=self._debug_launch.get())
        if author.has_author:
            log_dialog.log_text.normal_printer.writeln(f"Opening author @{author.author_id} '{author.name}' tease list")
            author_url: str = get_url_of_author_teases(author.author_id)
            launch(self._command_open_launch_config, None, author_url, log_dialog.log_text.normal_printer, log_dialog.log_text.warning_printer, log_dialog.log_text.error_printer, log_dialog.log_text.debug_printer)
        else:
            log_dialog.log_text.error_printer.writeln('Cannot open author tease list because the author is not known')
        if log_dialog.log_text.any_warnings_or_errors or self._debug_launch.get():
            log_dialog.show_okay_button()
        else:
            log_dialog.destroy()

    def _copy_url_of_tease(self, tease: Tease) -> None:
        tease_url: str = get_url_of_tease(tease.get_tease_id())
        self._copy_to_clipboard(tease_url)

    def _copy_url_of_author_profile(self, author: Author) -> None:
        if author.has_author:
            author_url: str = get_url_of_author(author.author_id)
            self._copy_to_clipboard(author_url)
        else:
            log_dialog: LogDialog = LogDialog(self._window)
            log_dialog.log_text.error_printer.writeln('Cannot copy URL of author profile because the author is not known')
            log_dialog.show_okay_button()

    def _copy_card(self, tease_match: TeaseMatch, formatter: IFormatter) -> None:
        formatter.print_summary_of_tease(tease_match)
        self._copy_to_clipboard(self._capturing_printer.text)
        self._capturing_printer.clear()

    def _copy_list_row(self, tease_match: TeaseMatch, formatter: IFormatter) -> None:
        formatter.print_list_of_teases([tease_match])
        self._copy_to_clipboard(self._capturing_printer.text)
        self._capturing_printer.clear()

    def _copy_page_text(self, tease_match: TeaseMatch, tease_page: TeasePage, formatter: IFormatter) -> None:
        formatter.print_text_of_page(tease_match, tease_page)
        self._copy_to_clipboard(self._capturing_printer.text)
        self._capturing_printer.clear()

    def _copy_matching_pages_text(self, tease_match: TeaseMatch, formatter: IFormatter) -> None:
        formatter.print_matching_text_of_tease(tease_match, include_header_and_footer=False)
        self._copy_to_clipboard(self._capturing_printer.text)
        self._capturing_printer.clear()

    def _copy_all_pages_text(self, tease_match: TeaseMatch, formatter: IFormatter) -> None:
        formatter.print_all_text_of_tease(tease_match, include_header_and_footer=False)
        self._copy_to_clipboard(self._capturing_printer.text)
        self._capturing_printer.clear()

    def _copy_to_clipboard(self, text: str) -> None:
        try:
            pyclip.copy(text)
        except pyclip.ClipboardSetupException as ex:
            log_dialog: LogDialog = LogDialog(self._window)
            log_dialog.log_text.error_printer.writeln(f'Unable to copy to clipboard: {ex}')
            log_dialog.show_okay_button()

    def _shutdown_app(self) -> None:
        self._window.destroy()

def _support_numpad_keys(widget: tk.Misc) -> None:
    widget.bind('<KP_Left>', lambda event: widget.event_generate('<Left>', state=event.state))
    widget.bind('<KP_Right>', lambda event: widget.event_generate('<Right>', state=event.state))
    widget.bind('<KP_Up>', lambda event: widget.event_generate('<Up>', state=event.state))
    widget.bind('<KP_Down>', lambda event: widget.event_generate('<Down>', state=event.state))
    widget.bind('<KP_Home>', lambda event: widget.event_generate('<Home>', state=event.state))
    widget.bind('<KP_End>', lambda event: widget.event_generate('<End>', state=event.state))
    widget.bind('<KP_Next>', lambda event: widget.event_generate('<Next>', state=event.state))
    widget.bind('<KP_Prior>', lambda event: widget.event_generate('<Prior>', state=event.state))
    widget.bind('<KP_Enter>', lambda event: widget.event_generate('<Return>', state=event.state))
    widget.bind('<KP_Insert>', lambda event: widget.event_generate('<Insert>', state=event.state))
    widget.bind('<KP_Delete>', lambda event: widget.event_generate('<Delete>', state=event.state))
