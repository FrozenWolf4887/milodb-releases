# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import tkinter as tk
from typing import Protocol
from milodb_client.view.gui.util.datum import IValueDatum

class _ValueChangedCallable[T](Protocol):
    def __call__(self, *, new_value: T) -> None:
        ...

class DatumBoolTkBinding:
    def __init__(self, datum: IValueDatum[bool], tk_var: tk.BooleanVar, on_change_callback: _ValueChangedCallable[bool] | None=None) -> None:
        self._datum: IValueDatum[bool] = datum
        self._tk_var: tk.BooleanVar = tk_var
        self._on_change_callback: _ValueChangedCallable[bool] | None = on_change_callback

        self._ignore_change_notification = False
        self._datum.add_new_value_listener(self._on_datum_value_changed)
        self._trace_id: str = self._tk_var.trace_add('write', self._on_tk_var_changed)
        self._is_active: bool = True

    def destroy(self) -> None:
        if self._is_active:
            self._datum.remove_listener(self._on_datum_value_changed)
            self._tk_var.trace_remove('write', self._trace_id)
            self._is_active = False

    def _on_datum_value_changed(self, new_value: bool) -> None: # noqa: FBT001 Boolean-typed positional argument in function definition
        if self._ignore_change_notification:
            return
        self._ignore_change_notification = True
        self._tk_var.set(new_value)
        self._ignore_change_notification = False
        if self._on_change_callback:
            self._on_change_callback(new_value=new_value)

    def _on_tk_var_changed(self, _dummy1: str, _dummy2: str, _dummy3: str) -> None:
        if self._ignore_change_notification:
            return
        value: bool = self._tk_var.get()
        self._ignore_change_notification = True
        self._datum.set(value)
        self._ignore_change_notification = False
        if self._on_change_callback:
            self._on_change_callback(new_value=value)
