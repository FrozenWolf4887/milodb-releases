# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import tkinter as tk
from pathlib import Path
from tkinter import ttk
from types import TracebackType
from typing import Self, override
from PIL import Image, ImageTk
from milodb_client.resources import resource_path
from milodb_client.view.gui import general_colours, general_layout, tk_type
from milodb_client.view.gui.log_text import LogText
from milodb_client.view.gui.theme import configure_ttk_styles
from milodb_client.view.i_log_display import ILogDisplay
from milodb_common.output.print.i_printer import IPrinter

_COL_PANEL_BACK: str = general_colours.PANEL_BACK
_LAYOUT_PANEL_RELIEF: tk_type.Relief = general_layout.PANEL_RELIEF
_LAYOUT_PANEL_BORDER_WIDTH: int = general_layout.PANEL_BORDER_WIDTH

class PopupLogDisplay(ILogDisplay):
    def __init__(self) -> None:
        self._window: tk.Tk = tk.Tk()
        self._window.config(background=_COL_PANEL_BACK, relief=_LAYOUT_PANEL_RELIEF, borderwidth=_LAYOUT_PANEL_BORDER_WIDTH)
        self._window.title('MiloDB')

        configure_ttk_styles(self._window)

        icon: Image.Image
        with Image.open(resource_path(Path('milodb-search-icon.ico'))) as icon:
            self._window.iconphoto(True, ImageTk.PhotoImage(icon)) # noqa: FBT003 Boolean positional value in function call
        self._window.geometry('400x300')

        self._log_text: LogText = LogText(self._window)
        self._log_text.pack(fill=tk.BOTH, expand=True)
        self._okay_flag: tk.BooleanVar = tk.BooleanVar(self._window)
        self._window.protocol("WM_DELETE_WINDOW", lambda: self._okay_flag.set(True))

    @property
    @override
    def normal_printer(self) -> IPrinter:
        return self._log_text.normal_printer

    @property
    @override
    def warning_printer(self) -> IPrinter:
        return self._log_text.warning_printer

    @property
    @override
    def error_printer(self) -> IPrinter:
        return self._log_text.error_printer

    @override
    def prompt_to_continue(self) -> None:
        button: ttk.Button = ttk.Button(self._window, text='OK', command=lambda: self._okay_flag.set(True))
        button.pack(side = tk.BOTTOM)
        button.focus()
        self._okay_flag.set(False)
        self._window.wait_variable(self._okay_flag)
        button.destroy()

    @override
    def print_warning_and_prompt_to_continue(self, message: str) -> None:
        self._log_text.warning_printer.writeln(message)
        self.prompt_to_continue()

    @override
    def print_fatal_and_prompt_to_continue(self, message: str) -> None:
        self._log_text.fatal_printer.writeln(message)
        self.prompt_to_continue()

    @override
    def __enter__(self) -> Self:
        self._window.wait_visibility()
        return self

    @override
    def __exit__(self, exc_type: type[BaseException] | None, exc_value: BaseException | None, traceback: TracebackType | None) -> None:
        self._window.destroy()
