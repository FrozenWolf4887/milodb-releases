# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import contextlib
import tkinter as tk
from collections.abc import Callable
from enum import Enum
from tkinter import ttk
from typing import Generic, TypeVar

E = TypeVar('E', bound=Enum)
class EnumOptionMenu(Generic[E], ttk.OptionMenu):
    def __init__(self, master: tk.Widget, default_enum: E, enum_type: type[E]) -> None:
        self._enum_type: type[E] = enum_type
        self._default_enum: E = default_enum
        self._variable = tk.StringVar()
        self._variable.set(default_enum.value)
        self._list_of_callbacks: list[Callable[[EnumOptionMenu[E]], None]] = []
        super().__init__(master, self._variable, None, *[enum.value for enum in self._enum_type], command=self._on_callback)

    def add_callback(self, callback: Callable[['EnumOptionMenu[E]'], None]) -> None:
        self._list_of_callbacks.append(callback)

    def remove_callback(self, callback: Callable[['EnumOptionMenu[E]'], None]) -> None:
        with contextlib.suppress(ValueError):
            self._list_of_callbacks.remove(callback)

    def _on_callback(self, _variable: tk.StringVar) -> None:
        for callback in self._list_of_callbacks:
            callback(self)

    @property
    def enum(self) -> E:
        current_value: str = self._variable.get()
        enum: E
        for enum in self._enum_type:
            if enum.value == current_value:
                return enum
        return self._default_enum
