# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from dataclasses import dataclass
from typing import override

@dataclass
class CharacterIndex:
    row: int = 1
    column: int = 0

    def move_with_text(self, text: str) -> None:
        line_count: int = text.count('\n')
        if line_count:
            self.row += line_count
            self.column = len(text) - (text.rfind('\n') + 1)
        else:
            self.column += len(text)

    @override
    def __str__(self) -> str:
        return f'{self.row}.{self.column}'
