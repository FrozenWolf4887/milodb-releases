# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from __future__ import annotations
import platform
import sys
import tkinter as tk
from tkinter import ttk
from typing import TYPE_CHECKING
import psutil
from milodb_client.util import app_info
from milodb_client.view.gui import general_style
from milodb_client.view.gui.frame_widgets import WrappingLabel
from milodb_client.view.gui.scrollable_frame import ScrollableFrame
from milodb_client.view.gui.window_widgets import ModalDialog
from milodb_common.util.get_url import get_url_of_author
from milodb_common.util.unit_size import UnitSizeText, unit_size
if TYPE_CHECKING:
    from collections.abc import Callable
    from milodb_client.updater.manifest.local_manifest import ILocalManifest

_TABLE_GRIDLINE_THICKNESS: int = 1

class AboutDialog(ModalDialog):
    def __init__(self, master: tk.Tk, local_manifest: ILocalManifest | None) -> None:
        super().__init__(master, width=680)

        virtual_memory = psutil.virtual_memory()
        process: psutil.Process = psutil.Process()
        process_memory = process.memory_info()
        total_memory_size: UnitSizeText = unit_size(virtual_memory.total)
        used_memory: UnitSizeText = unit_size(process_memory.rss)
        available_memory_size: UnitSizeText = unit_size(virtual_memory.available)
        core_count: int | None = psutil.cpu_count(logical=False)
        thread_count: int | None = psutil.cpu_count()

        map_of_heading_to_generator: dict[str, Callable[[], str]] = {
            'Name': lambda: app_info.APPLICATION_NAME,
            'Variant': lambda: local_manifest.variant_name if local_manifest else 'unknown',
            'Version': lambda: str(local_manifest.version_number) if local_manifest else 'unknown',
            'Date': lambda: local_manifest.date.isoformat() if local_manifest else 'unknown',
            'Author': lambda: app_info.AUTHOR_NAME,
            'Author Profile': lambda: get_url_of_author(app_info.AUTHOR_ID),
            'Machine': lambda: f'{platform.machine()}, {sys.platform}',
            'Platform': platform.platform,
            'Memory Total': lambda: f'{total_memory_size.size_text} {total_memory_size.unit_text}',
            'Memory Used': lambda: f'{used_memory.size_text} {used_memory.unit_text}',
            'Memory Free': lambda: f'{available_memory_size.size_text} {available_memory_size.unit_text}',
            'CPU': platform.processor,
            'CPU Cores': lambda: str(core_count) if core_count else 'unknown',
            'CPU Threads': lambda: str(thread_count) if thread_count else 'unknown',
            'Python': lambda: sys.version,
            'Software Licence': lambda: app_info.SOFTWARE_LICENCE_TEXT,
            'Tease Copyright': lambda: app_info.TEASE_COPYRIGHT_TEXT,
            'Support Topic': lambda: app_info.FORUM_THREAD_URL,
        }

        table_frame: ScrollableFrame = ScrollableFrame(self.content_frame)
        table_frame.top_frame.pack(fill=tk.BOTH, expand=True)

        row: int
        heading: str
        generator: Callable[[], str]
        for row, (heading, generator) in enumerate(map_of_heading_to_generator.items()):
            ttk.Label(table_frame.content_frame, text=heading, anchor=tk.W, justify=tk.LEFT, style=general_style.LABEL_TABLE_HEADER).grid(row=row, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            WrappingLabel(table_frame.content_frame, text=generator(), anchor=tk.W, justify=tk.LEFT, style=general_style.LABEL_TABLE_VALUE).grid(row=row, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)

        table_frame.content_frame.columnconfigure(1, weight=1)
        table_frame.set_child_bindtags_for_scrolling()

        self.add_button('Okay', column=0, command=self.destroy)
        self.focus_button(column=0)
