# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
NORMAL_FONT_SIZE: int = 11
NORMAL_FONT_TUPLE: tuple[str, int] = ('Liberation Sans', NORMAL_FONT_SIZE)
EDIT_FONT_TUPLE: tuple[str, int] = ('Liberation Sans', NORMAL_FONT_SIZE)
ITALIC_FONT_TUPLE: tuple[str, int, str] = ('Liberation Sans', NORMAL_FONT_SIZE, 'italic')
BANNER_FONT_TUPLE: tuple[str, int, str] = ('Liberation Sans', 14, 'italic')
MONO_FONT_TUPLE: tuple[str, int] = ('Liberation Mono', 11)
NORMAL_FONT_NAME: str = ' '.join(str(part) for part in NORMAL_FONT_TUPLE)
EDIT_FONT_NAME: str = ' '.join(str(part) for part in EDIT_FONT_TUPLE)
ITALIC_FONT_NAME: str = ' '.join(str(part) for part in ITALIC_FONT_TUPLE)
BANNER_FONT_NAME: str = ' '.join(str(part) for part in BANNER_FONT_TUPLE)
MONO_FONT_NAME: str = ' '.join(str(part) for part in MONO_FONT_TUPLE)
