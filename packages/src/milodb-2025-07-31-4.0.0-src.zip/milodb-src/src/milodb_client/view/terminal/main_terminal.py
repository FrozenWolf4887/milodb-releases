# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import json
from pathlib import Path
from typing import TYPE_CHECKING
from milodb_client.config.ansi_config import AnsiConfig
from milodb_client.config.bbcode_config import BBCodeConfig
from milodb_client.config.config_schema import CONFIG_SCHEMA
from milodb_client.config.html_config import HtmlConfig
from milodb_client.config.launch_config import BrowseLaunchConfig, OpenLaunchConfig
from milodb_client.config.migration import try_migrate_config
from milodb_client.config.update_config import UpdateConfig
from milodb_client.database.database import load_teases_from_database_file
from milodb_client.output.format.ansi_formatter import AnsiFormatter
from milodb_client.output.format.bbcode_formatter import BBCodeFormatter
from milodb_client.output.format.formatter_factory import FormatterCreator, FormatterFactory
from milodb_client.output.format.html_file_writer import HtmlFileWriter
from milodb_client.output.format.html_formatter import HtmlFormatter
from milodb_client.output.format.plain_formatter import PlainFormatter
from milodb_client.query.infix_query_parser import InfixQueryParser
from milodb_client.query.postfix_query_executor import PostfixQueryExecutor
from milodb_client.startup.shutdown_action import IShutdownAction
from milodb_client.updater.local_file_hasher import LocalFileHasher
from milodb_client.updater.local_file_tester import LocalFileTester
from milodb_client.updater.manifest.i_schema_types import SchemaLoadError
from milodb_client.updater.manifest.local_manifest_schema import LocalManifestSchema
from milodb_client.updater.temp_directory import TempDirectoryCreator
from milodb_client.util import app_info
from milodb_client.util.database_stats import DatabaseStats
from milodb_client.util.tease_match_sorter import ITeaseMatchSorter, TeaseMatchSorter
from milodb_client.view.terminal.commands import about_command
from milodb_client.view.terminal.commands import browse_command
from milodb_client.view.terminal.commands import config_command
from milodb_client.view.terminal.commands import copy_command
from milodb_client.view.terminal.commands import ellipsis_command
from milodb_client.view.terminal.commands import format_command
from milodb_client.view.terminal.commands import gui_upgrade_command
from milodb_client.view.terminal.commands import help_command
from milodb_client.view.terminal.commands import highlight_command
from milodb_client.view.terminal.commands import list_command
from milodb_client.view.terminal.commands import open_command
from milodb_client.view.terminal.commands import openauthor_command
from milodb_client.view.terminal.commands import pagerefs_command
from milodb_client.view.terminal.commands import query_command
from milodb_client.view.terminal.commands import show_command
from milodb_client.view.terminal.commands import sort_command
from milodb_client.view.terminal.commands import stats_command
from milodb_client.view.terminal.commands import summary_command
from milodb_client.view.terminal.commands import update_command
from milodb_client.view.terminal.commands import url_command
from milodb_client.view.terminal.commands import urlauthor_command
from milodb_client.view.terminal.commands.command_factory import CommandFactory
from milodb_client.view.terminal.util.named_sort_keys import LIST_OF_AVAILABLE_SORT_KEYS, NAMED_DATE_SORT_KEY, NAMED_TEASE_ID_SORT_KEY, OrderedNamedSortKey
from milodb_common.config.json_config_file import JsonConfigFile
from milodb_common.internet.url_scraper_factory import UrlScraperFactory
from milodb_common.output.print.debug_printer import DebugPrinter
from milodb_common.output.print.i_printer import IPrinter, IRedirectablePrinter
from milodb_common.output.print.normal_printer import NormalPrinter
from milodb_common.output.print.prefix_printer import PrefixPrinter
from milodb_common.util.ref import IRef, SimpleRef
from milodb_common.variables.file_user_variables import FileUserVariables
from milodb_common.view.terminal.command_framework.command_constructor import CommandConstructor
from milodb_common.view.terminal.command_framework.quit_flag import QuitFlag
from milodb_common.view.terminal.commands import debug_command
from milodb_common.view.terminal.commands import exit_command
from milodb_common.view.terminal.commands import var_command
from milodb_common.view.terminal.input.autoexec import run_autoexec
from milodb_common.view.terminal.input.default_input import DefaultInputText, IDefaultInputText
from milodb_common.view.terminal.input.process import process_user_input
from milodb_common.view.terminal.input.prompt import run_interactive_prompt
if TYPE_CHECKING:
    from collections.abc import Sequence
    from milodb_client.database.tease import Tease
    from milodb_client.output.format.i_formatter_factory import IFormatterCreator
    from milodb_client.query.tease_match import TeaseMatch
    from milodb_client.updater.i_file_hasher import IFileHasher
    from milodb_client.updater.i_file_tester import IFileTester
    from milodb_client.updater.i_temp_directory import ITempDirectoryCreator
    from milodb_common.config.i_launch_config import ILaunchConfig
    from milodb_common.internet.i_scraper import IUrlScraperFactory
    from milodb_common.variables.i_user_variables import IPersistentUserVariables
    from milodb_common.view.terminal.command_framework.i_command_constructor import ICommandConstructor

_IS_END_OF_LIFE: bool = True
_LOCAL_MANIFEST_FILENAME: Path = Path('milodb-manifest.ver')
_DATABASE_FILENAME: Path = Path('milodb-teases.dat')
_CONFIG_FILENAME: Path = Path('config.json')
_VARIABLES_FILENAME: Path = Path('variables.json')
_AUTOEXEC_FILENAME: Path = Path('autoexec.txt')

class MainTerminal:
    def __init__(self, output_printer: IPrinter, *, no_load: bool) -> None: # pylint: disable=too-many-statements # noqa: PLR0915 Too many statements
        self._normal_printer: IRedirectablePrinter = NormalPrinter(output_printer)
        self._warning_printer: IRedirectablePrinter = PrefixPrinter('Warning: ', output_printer)
        self._error_printer: IRedirectablePrinter = PrefixPrinter('Error: ', output_printer)
        self._fatal_printer: IRedirectablePrinter = PrefixPrinter('FATAL: ', output_printer)
        self._debug_printer: DebugPrinter = DebugPrinter(output_printer)

        local_manifest: LocalManifestSchema | None = _load_local_manifest(_LOCAL_MANIFEST_FILENAME, self._warning_printer, self._error_printer)
        self._normal_printer.writeln(app_info.get_version_one_line(local_manifest))

        system_config: JsonConfigFile = JsonConfigFile(_CONFIG_FILENAME, CONFIG_SCHEMA, try_migrate_config)
        system_config.load(self._normal_printer, self._warning_printer, self._error_printer)
        update_config: UpdateConfig = UpdateConfig(system_config)
        browse_launch_config: ILaunchConfig = BrowseLaunchConfig(system_config)
        open_launch_config: ILaunchConfig = OpenLaunchConfig(system_config)

        list_of_tease_matches: IRef[Sequence[TeaseMatch]] = SimpleRef([])
        use_highlighting: IRef[bool] = SimpleRef(True)
        use_ellipsis: IRef[bool] = SimpleRef(True)
        show_pagerefs: IRef[bool] = SimpleRef(False)
        ellipsis_max_width: IRef[int] = SimpleRef(40)
        tease_match_sorter: ITeaseMatchSorter = TeaseMatchSorter([OrderedNamedSortKey(NAMED_DATE_SORT_KEY, is_ascending=True), OrderedNamedSortKey(NAMED_TEASE_ID_SORT_KEY, is_ascending=True)])
        list_of_active_sort_keys: IRef[Sequence[OrderedNamedSortKey]] = SimpleRef([])
        infix_query_parser: InfixQueryParser = InfixQueryParser()
        postfix_query_executor: PostfixQueryExecutor = PostfixQueryExecutor()
        self._default_input_text: IDefaultInputText = DefaultInputText()
        self._user_variables: IPersistentUserVariables = FileUserVariables(_VARIABLES_FILENAME)
        self._user_variables.load(self._normal_printer, self._warning_printer, self._error_printer)
        self._quit_flag: QuitFlag = QuitFlag()

        plain_formatter_creator: IFormatterCreator = FormatterCreator(
            'plain', lambda printer: PlainFormatter(
                printer,
                ellipsis_max_width=ellipsis_max_width.get() if use_ellipsis.get() else None,
                show_pagerefs=show_pagerefs.get()))
        ansi_formatter_creator: IFormatterCreator = FormatterCreator(
            'ansi', lambda printer: AnsiFormatter(
                AnsiConfig(system_config),
                printer,
                use_highlighting=use_highlighting.get(),
                ellipsis_max_width=ellipsis_max_width.get() if use_ellipsis.get() else None,
                show_pagerefs=show_pagerefs.get()))
        bbcode_formatter_creator: IFormatterCreator = FormatterCreator(
            'bbcode', lambda printer: BBCodeFormatter(
                BBCodeConfig(system_config),
                printer,
                use_highlighting=use_highlighting.get(),
                ellipsis_max_width=ellipsis_max_width.get() if use_ellipsis.get() else None,
                show_pagerefs=show_pagerefs.get()))
        html_formatter_creator: IFormatterCreator = FormatterCreator(
            'html', lambda printer: HtmlFormatter(
                HtmlConfig(system_config),
                printer,
                use_highlighting=use_highlighting.get(),
                ellipsis_max_width=ellipsis_max_width.get() if use_ellipsis.get() else None,
                show_pagerefs=show_pagerefs.get()))

        formatter_factory: FormatterFactory = FormatterFactory()
        formatter_factory.register_formatter(ansi_formatter_creator)
        formatter_factory.register_formatter(plain_formatter_creator)
        formatter_factory.register_formatter(bbcode_formatter_creator)
        formatter_factory.register_formatter(html_formatter_creator)

        current_formatter_creator: IRef[IFormatterCreator] = SimpleRef(ansi_formatter_creator)
        html_file_writer: HtmlFileWriter = HtmlFileWriter(HtmlConfig(system_config), html_formatter_creator)

        url_scraper_factory: IUrlScraperFactory = UrlScraperFactory()
        file_hasher: IFileHasher = LocalFileHasher()
        file_tester: IFileTester = LocalFileTester()
        temp_directory_creator: ITempDirectoryCreator = TempDirectoryCreator()
        self._shutdown_action: IRef[IShutdownAction | None] = SimpleRef(None)

        list_of_teases: Sequence[Tease] = [] if no_load else load_teases_from_database_file(_DATABASE_FILENAME, self._normal_printer, self._error_printer)
        self._normal_printer.writeln(app_info.get_database_info_one_line(list_of_teases))
        self._normal_printer.writeln()

        database_stats: DatabaseStats = DatabaseStats(list_of_teases)

        command_factory: CommandFactory = CommandFactory()
        self._command_constructor: ICommandConstructor = CommandConstructor(command_factory)

        command_factory.register_command('about', lambda arg_token_stream: about_command.load(arg_token_stream, local_manifest, list_of_teases, self._normal_printer), about_command.Help)
        command_factory.register_command('browse', lambda arg_token_stream: browse_command.load(arg_token_stream, list_of_teases, list_of_tease_matches.get(), browse_launch_config, html_file_writer, self._normal_printer, self._warning_printer, self._error_printer, self._debug_printer, browse_all=False), browse_command.BrowseHelp)
        command_factory.register_command('browseall', lambda arg_token_stream: browse_command.load(arg_token_stream, list_of_teases, list_of_tease_matches.get(), browse_launch_config, html_file_writer, self._normal_printer, self._warning_printer, self._error_printer, self._debug_printer, browse_all=True), browse_command.BrowseAllHelp)
        command_factory.register_command('config', lambda arg_token_stream: config_command.load(arg_token_stream, system_config, CONFIG_SCHEMA, self._default_input_text, self._normal_printer, self._warning_printer, self._error_printer), config_command.Help)
        command_factory.register_command('copy', lambda arg_token_stream: copy_command.load(arg_token_stream, self._command_constructor, [self._normal_printer, self._warning_printer, self._error_printer, self._fatal_printer, self._debug_printer], self._error_printer), copy_command.Help)
        command_factory.register_command('debug', lambda arg_token_stream: debug_command.load(arg_token_stream, self._command_constructor, self._debug_printer), debug_command.Help)
        command_factory.register_command('ellipsis', lambda arg_token_stream: ellipsis_command.load(arg_token_stream, use_ellipsis, self._normal_printer), ellipsis_command.Help)
        command_factory.register_command('exit', lambda arg_token_stream: exit_command.load(arg_token_stream, self._quit_flag), exit_command.Help)
        command_factory.register_command('format', lambda arg_token_stream: format_command.load(arg_token_stream, current_formatter_creator, formatter_factory, self._normal_printer), lambda: format_command.Help(formatter_factory.get_list_of_formatter_names()))
        if _IS_END_OF_LIFE:
            command_factory.register_command('gui-upgrade', lambda arg_token_stream: gui_upgrade_command.load(arg_token_stream, local_manifest, update_config, file_hasher, file_tester, temp_directory_creator, url_scraper_factory, self._quit_flag, self._shutdown_action, self._normal_printer, self._warning_printer, self._error_printer), gui_upgrade_command.Help)
        command_factory.register_command('help', lambda arg_token_stream: help_command.load(arg_token_stream, command_factory, self._normal_printer), help_command.Help)
        command_factory.register_command('highlight', lambda arg_token_stream: highlight_command.load(arg_token_stream, use_highlighting, self._normal_printer), highlight_command.Help)
        command_factory.register_command('list', lambda arg_token_stream: list_command.load(arg_token_stream, list_of_teases, list_of_tease_matches.get(), current_formatter_creator.get(), self._normal_printer, self._error_printer), list_command.Help)
        command_factory.register_command('open', lambda arg_token_stream: open_command.load(arg_token_stream, list_of_teases, list_of_tease_matches.get(), open_launch_config, self._normal_printer, self._warning_printer, self._error_printer, self._debug_printer), open_command.Help)
        command_factory.register_command('openauthor', lambda arg_token_stream: openauthor_command.load(arg_token_stream, list_of_teases, list_of_tease_matches.get(), open_launch_config, self._normal_printer, self._warning_printer, self._error_printer, self._debug_printer), openauthor_command.Help)
        command_factory.register_command('pagerefs', lambda arg_token_stream: pagerefs_command.load(arg_token_stream, show_pagerefs, self._normal_printer), pagerefs_command.Help)
        command_factory.register_command('query', lambda arg_token_stream: query_command.load(arg_token_stream, list_of_teases, infix_query_parser, postfix_query_executor, list_of_tease_matches, tease_match_sorter, list_of_active_sort_keys.get(), current_formatter_creator.get(), self._normal_printer, self._warning_printer, self._error_printer), query_command.Help)
        command_factory.register_command('show', lambda arg_token_stream: show_command.load(arg_token_stream, list_of_teases, list_of_tease_matches.get(), current_formatter_creator.get(), self._normal_printer, self._error_printer, show_all=False), show_command.ShowHelp)
        command_factory.register_command('showall', lambda arg_token_stream: show_command.load(arg_token_stream, list_of_teases, list_of_tease_matches.get(), current_formatter_creator.get(), self._normal_printer, self._error_printer, show_all=True), show_command.ShowAllHelp)
        command_factory.register_command('sort', lambda arg_token_stream: sort_command.load(arg_token_stream, list_of_tease_matches, tease_match_sorter, list_of_active_sort_keys, LIST_OF_AVAILABLE_SORT_KEYS, self._normal_printer), lambda: sort_command.Help(LIST_OF_AVAILABLE_SORT_KEYS))
        command_factory.register_command('stats', lambda arg_token_stream: stats_command.load(arg_token_stream, database_stats, self._normal_printer), stats_command.Help)
        command_factory.register_command('summary', lambda arg_token_stream: summary_command.load(arg_token_stream, list_of_teases, list_of_tease_matches.get(), current_formatter_creator.get(), self._normal_printer, self._error_printer), summary_command.Help)
        command_factory.register_command('update', lambda arg_token_stream: update_command.load(arg_token_stream, local_manifest, update_config, file_hasher, file_tester, temp_directory_creator, url_scraper_factory, self._quit_flag, self._shutdown_action, self._normal_printer, self._warning_printer, self._error_printer), update_command.Help)
        command_factory.register_command('url', lambda arg_token_stream: url_command.load(arg_token_stream, list_of_teases, list_of_tease_matches.get(), self._normal_printer, self._error_printer), url_command.Help)
        command_factory.register_command('urlauthor', lambda arg_token_stream: urlauthor_command.load(arg_token_stream, list_of_teases, list_of_tease_matches.get(), self._normal_printer, self._error_printer), urlauthor_command.Help)
        command_factory.register_command('var', lambda arg_token_stream: var_command.load(arg_token_stream, self._user_variables, self._default_input_text, self._normal_printer, self._warning_printer, self._error_printer), var_command.Help)

    def run(self, *, autoexec: bool) -> IShutdownAction | None:
        if _IS_END_OF_LIFE:
            _warn_about_end_of_life(self._normal_printer)
        if autoexec:
            run_autoexec(_AUTOEXEC_FILENAME, self._command_constructor, self._user_variables, self._quit_flag, self._normal_printer, self._error_printer)
        if not self._quit_flag:
            run_interactive_prompt(self._command_constructor, self._user_variables, self._default_input_text, self._quit_flag, self._normal_printer, self._error_printer)
        return self._shutdown_action.get()

    def inject_command(self, command: str) -> bool:
        process_user_input(command, self._command_constructor, self._user_variables, self._quit_flag, self._normal_printer, self._error_printer)
        return not self._quit_flag

def _load_local_manifest(filename: Path, warning_printer: IPrinter, error_printer: IPrinter) -> LocalManifestSchema | None:
    try:
        json_root: object = json.loads(filename.read_bytes())
    except FileNotFoundError:
        warning_printer.writeln(f"Local manifest '{filename}' unavailable")
    except (OSError, json.JSONDecodeError, UnicodeDecodeError) as ex:
        error_printer.writeln(f"Unable to read from local manifest '{filename}': {ex}")
    else:
        manifest: LocalManifestSchema = LocalManifestSchema()
        try:
            manifest.load(json_root)
        except SchemaLoadError as ex:
            error_printer.writeln(f"Invalid local manifest '{filename}': {ex}")
        else:
            return manifest
    return None

def _warn_about_end_of_life(printer: IPrinter) -> None:
    printer.writeln(
        "\x1b[93;40;1;4mWarning\x1b[24m: This 'terminal' variant of MiloDB is now end-of-life and\x1b[K\n"
        "         will receive no further updates.\x1b[K\n"
        "   \x1b[94;4mNote\x1b[39;24m: \x1b[94mTo upgrade to the 'graphical' variant of MiloDB, use the\x1b[K\n"
        # spell-checker: disable-next-line
        "         command: '\x1b[97mgui-upgrade\x1b[94m'\x1b[K\x1b[0m",
    )
    printer.writeln()
