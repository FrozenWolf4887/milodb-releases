# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import platform
import sys
from collections.abc import Callable, Iterable, Sequence
from typing import TYPE_CHECKING, override
import psutil
from milodb_client.database.database import try_get_newest_tease_date, try_get_oldest_tease_date
from milodb_client.database.tease import Tease
from milodb_client.updater.manifest.local_manifest import ILocalManifest
from milodb_client.util import app_info
from milodb_client.view.terminal.util.text import indent_text, wrap_text
from milodb_common.output.print.i_printer import IPrinter
from milodb_common.parser import arg
from milodb_common.parser.arg_token_stream import ArgTokenStream
from milodb_common.parser.candidate_text import CandidateText
from milodb_common.util.get_url import get_url_of_author
from milodb_common.util.unit_size import UnitSizeText, unit_size
from milodb_common.view.terminal.command_framework.i_command import CommandLoaderResult
from milodb_common.view.terminal.command_framework.i_help_info import IHelpInfo
if TYPE_CHECKING:
    import datetime

def load(arg_token_stream: ArgTokenStream, local_manifest: ILocalManifest | None, list_of_teases: Sequence[Tease], normal_printer: IPrinter) -> CommandLoaderResult:
    map_of_subcommand_to_executor: dict[str, Callable[[], None]] = {
        'version': lambda: _print_version(local_manifest, normal_printer),
        'author': lambda: _print_author(normal_printer),
        'database': lambda: _print_database_info(list_of_teases, normal_printer),
        'platform': lambda: _print_platform_info(normal_printer),
        'memory': lambda: _print_memory_info(normal_printer),
        'cpu': lambda: _print_cpu_info(normal_printer),
        'python': lambda: _print_python_info(normal_printer),
        'licence': lambda: _print_licence_info(normal_printer),
        'forum': lambda: _print_forum_link(normal_printer),
    }

    list_of_executors: list[Callable[[], None]] = arg.pop_list(arg_token_stream, arg.DictValueAndRemoveEntry(map_of_subcommand_to_executor, 'item name'))
    if not list_of_executors:
        list_of_executors = list(map_of_subcommand_to_executor.values())

    return CommandLoaderResult(
        lambda: execute(list_of_executors),
        CandidateText.space_delimited_list(map_of_subcommand_to_executor),
    )

def execute(list_of_executors: Iterable[Callable[[], None]]) -> None:
    executor: Callable[[], None]
    for executor in list_of_executors:
        executor()

def _print_version(local_manifest: ILocalManifest | None, normal_printer: IPrinter) -> None:
    normal_printer.writeln('Application:')
    normal_printer.writeln(f'  {app_info.APPLICATION_NAME}')
    normal_printer.writeln(f"  Variant {f"'{local_manifest.variant_name}'" if local_manifest else "unknown"}")
    normal_printer.writeln(f"  Version {local_manifest.version_number if local_manifest else "unknown"}")
    normal_printer.writeln(f"  Date {local_manifest.date if local_manifest else "unknown"}")

def _print_author(normal_printer: IPrinter) -> None:
    normal_printer.writeln('Author:')
    normal_printer.writeln(f'  {app_info.AUTHOR_NAME}')
    normal_printer.writeln(f'  {get_url_of_author(app_info.AUTHOR_ID)}')

def _print_database_info(list_of_teases: Sequence[Tease], normal_printer: IPrinter) -> None:
    oldest_tease_date: datetime.date | None = try_get_oldest_tease_date(list_of_teases)
    newest_tease_date: datetime.date | None = try_get_newest_tease_date(list_of_teases)
    normal_printer.writeln('Database:')
    normal_printer.writeln(f'  {len(list_of_teases):,} teases')
    normal_printer.writeln(f"  Date from {oldest_tease_date or 'None'} to {newest_tease_date or 'None'}")

def _print_platform_info(normal_printer: IPrinter) -> None:
    normal_printer.writeln('Platform:')
    normal_printer.writeln(f'  {platform.machine()}, {sys.platform}')
    normal_printer.writeln(f'  {platform.platform()}')

def _print_memory_info(normal_printer: IPrinter) -> None:
    normal_printer.writeln('Memory:')
    virtual_memory = psutil.virtual_memory()
    process: psutil.Process = psutil.Process()
    process_memory = process.memory_info()
    total_memory: UnitSizeText = unit_size(virtual_memory.total)
    used_memory: UnitSizeText = unit_size(process_memory.rss)
    available_memory: UnitSizeText = unit_size(virtual_memory.available)
    normal_printer.writeln(f'  {total_memory.size_text:>4} {total_memory.unit_text} total')
    normal_printer.writeln(f'  {used_memory.size_text:>4} {used_memory.unit_text} used')
    normal_printer.writeln(f'  {available_memory.size_text:>4} {available_memory.unit_text} available')

def _print_cpu_info(normal_printer: IPrinter) -> None:
    normal_printer.writeln('CPU:')
    core_count: int | None = psutil.cpu_count(logical=False)
    thread_count: int | None = psutil.cpu_count()
    normal_printer.writeln(f'  {platform.processor()}')
    normal_printer.writeln(f'  {core_count or "Unknown"} cores')
    normal_printer.writeln(f'  {thread_count or "Unknown"} threads')

def _print_python_info(normal_printer: IPrinter) -> None:
    normal_printer.writeln('Python:')
    normal_printer.writeln(f'  {sys.version}')

def _print_licence_info(normal_printer: IPrinter) -> None:
    normal_printer.writeln('Software licence:')
    normal_printer.writeln(indent_text(wrap_text(app_info.SOFTWARE_LICENCE_TEXT, 80), 2))
    normal_printer.writeln('Tease copyright:')
    normal_printer.writeln(indent_text(wrap_text(app_info.TEASE_COPYRIGHT_TEXT, 80), 2))

def _print_forum_link(normal_printer: IPrinter) -> None:
    normal_printer.writeln('Support topic:')
    normal_printer.writeln(f'  {app_info.FORUM_THREAD_URL}')

class Help(IHelpInfo):
    @override
    def get_one_line_summary(self) -> str:
        return "Displays information about the application and platform"

    @override
    def get_detailed_summary(self) -> str:
        return (
            "Arguments: [version|author|database|platform|memory|cpu|python|licence|forum]\n"
            "When specified without arguments, will display all of the available information"
            " about the application and the platform that it's running on.\n"
            "Example:\r"
            "  \tShow all information\r"
            "  > \tabout\r"
            "Example:\r"
            "  \tShow the version information only\r"
            "  > \tabout version\n"
            "See also:\r"
            "  \tcopy"
        )
