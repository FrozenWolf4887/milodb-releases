# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from types import TracebackType
from typing import Self, override
from milodb_client.view.i_log_display import ILogDisplay
from milodb_common.output.print.i_printer import IPrinter
from milodb_common.output.print.prefix_printer import PrefixPrinter
from milodb_common.output.print.stdout_printer import StdoutPrinter

class TerminalLogDisplay(ILogDisplay):
    def __init__(self) -> None:
        self._stdout_printer: IPrinter = StdoutPrinter()
        self._warning_printer: IPrinter = PrefixPrinter('Warning: ', self._stdout_printer)
        self._error_printer: IPrinter = PrefixPrinter('Error: ', self._stdout_printer)
        self._fatal_printer: IPrinter = PrefixPrinter('FATAL: ', self._stdout_printer)

    @property
    @override
    def normal_printer(self) -> IPrinter:
        return self._stdout_printer

    @property
    @override
    def warning_printer(self) -> IPrinter:
        return self._warning_printer

    @property
    @override
    def error_printer(self) -> IPrinter:
        return self._error_printer

    @override
    def prompt_to_continue(self) -> None:
        input('Press return to continue...')

    @override
    def print_warning_and_prompt_to_continue(self, message: str) -> None:
        self._warning_printer.writeln(message)
        self.prompt_to_continue()

    @override
    def print_fatal_and_prompt_to_continue(self, message: str) -> None:
        self._fatal_printer.writeln(message)
        self.prompt_to_continue()

    @override
    def __enter__(self) -> Self:
        """Unused; the terminal should already be available at the start."""
        return self

    @override
    def __exit__(self, exc_type: type[BaseException] | None, exc_value: BaseException | None, traceback: TracebackType | None) -> None:
        """Unused; the terminal isn't shutdown explicitly at the end."""
