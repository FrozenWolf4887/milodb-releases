# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from collections.abc import Iterable, Sequence
from typing import override
from milodb_client.database.tease import Tease
from milodb_client.output.format.i_formatter_factory import IFormatterCreator
from milodb_client.query.tease_match import TeaseMatch
from milodb_client.view.terminal.commands.database_support import try_create_list_of_tease_matches_from_ref_ids
from milodb_common.output.print.i_printer import IPrinter
from milodb_common.parser import arg
from milodb_common.parser.arg_token_stream import ArgTokenStream
from milodb_common.parser.ref_id import RefId
from milodb_common.view.terminal.command_framework.i_command import CommandLoaderResult
from milodb_common.view.terminal.command_framework.i_help_info import IHelpInfo

def load(arg_token_stream: ArgTokenStream, list_of_teases: Sequence[Tease], list_of_tease_matches: Sequence[TeaseMatch], formatter_creator: IFormatterCreator, normal_printer: IPrinter, error_printer: IPrinter) -> CommandLoaderResult:
    list_of_ref_ids: Sequence[RefId] = arg.pop_list(arg_token_stream, arg.REF_ID)
    return CommandLoaderResult(
        lambda: execute(list_of_ref_ids, list_of_teases, list_of_tease_matches, formatter_creator, normal_printer, error_printer),
        [],
    )

def execute(list_of_ref_ids: Iterable[RefId], list_of_teases: Iterable[Tease], list_of_tease_matches: Sequence[TeaseMatch], formatter_creator: IFormatterCreator, normal_printer: IPrinter, error_printer: IPrinter) -> None:
    list_of_tease_matches_to_print: Sequence[TeaseMatch] | None = None
    if list_of_ref_ids:
        list_of_tease_matches_to_print = try_create_list_of_tease_matches_from_ref_ids(list_of_teases, list_of_tease_matches, list_of_ref_ids, error_printer)
    else:
        list_of_tease_matches_to_print = list_of_tease_matches

    if list_of_tease_matches_to_print:
        formatter_creator.create(normal_printer).print_list_of_teases(list_of_tease_matches_to_print)
    else:
        error_printer.writeln("No teases available to list")

class Help(IHelpInfo):
    @override
    def get_one_line_summary(self) -> str:
        return "Lists the current results, one per line"

    @override
    def get_detailed_summary(self) -> str:
        return (
            "Arguments: [list of RefIds]\n"
            "The formatting used in the list can be controlled with the format command.\n"
            "When used without arguments, all teases that were found from the last query are"
            " included. When one or more RefIds are specified, only those teases are included.\n"
            "RefIds can be an index into the list of matches such as '3', a teaseId such as"
            " '#38664', or an authorId such as '@43937'.\n"
            "The field shown as *n (e.g. *12) indicates how many field matches were made with"
            " the query to provide a guide to the possible relevance of that tease.\n"
            "Matching fields may be highlighted which can be controlled with the highlight"
            " command.\n"
            "Example:\r"
            "  \tList the results of the last query\r"
            "  > \tlist\r"
            "Example:\r"
            "  \tList some matched teases by index\r"
            "  > \tlist 3 7\r"
            "Example:\r"
            "  \tList some specific teaseIds\r"
            "  > \tlist #16830 #1465 #38664\r"
            "Example:\r"
            "  \tList teases for a specific authorId\r"
            "  > \tlist @43937\n"
            "See also:\r"
            "  \tformat, highlight, summary, show, sort\n"
        )
