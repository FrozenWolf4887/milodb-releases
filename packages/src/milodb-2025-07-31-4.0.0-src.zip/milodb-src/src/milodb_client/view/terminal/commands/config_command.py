# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from collections.abc import Callable, Mapping, Sequence
from typing import override
from milodb_client.config.config_schema import CONFIG_SCHEMA
from milodb_common.config.framework import IConfig, IConfigGroup, IConfigLeaf, IPersistentConfig
from milodb_common.output.print.i_printer import IPrinter
from milodb_common.parser import arg
from milodb_common.parser.arg_token_stream import ArgTokenStream
from milodb_common.parser.candidate_text import CandidateText
from milodb_common.parser.token import Token
from milodb_common.view.terminal.command_framework.i_command import CommandLoaderError, CommandLoaderResult
from milodb_common.view.terminal.command_framework.i_help_info import IHelpInfo
from milodb_common.view.terminal.input.default_input import IDefaultInputText

_PATH_DIVIDER_CHAR: str = '/'

def load(arg_token_stream: ArgTokenStream, config: IPersistentConfig, config_schema: IConfigGroup, default_input_text: IDefaultInputText, normal_printer: IPrinter, warning_printer: IPrinter, error_printer: IPrinter) -> CommandLoaderResult:
    map_of_action_to_subcommand_loader: Mapping[str, Callable[[], CommandLoaderResult]] = {
        'get': lambda: load_get(config, config_schema, normal_printer, arg_token_stream),
        'set': lambda: load_set(config, config_schema, normal_printer, warning_printer, error_printer, arg_token_stream),
        'edit': lambda: load_edit(config, config_schema, default_input_text, error_printer, arg_token_stream),
        'reset': lambda: load_reset(config, config_schema, normal_printer, warning_printer, error_printer, arg_token_stream),
        'purge': lambda: load_purge(config, normal_printer, warning_printer, error_printer, arg_token_stream),
    }
    loader: Callable[[], CommandLoaderResult] = arg.pop(arg_token_stream, arg.DictValue(map_of_action_to_subcommand_loader, 'subcommand'))
    return loader()

def load_get(config: IConfig, config_schema: IConfigGroup, normal_printer: IPrinter, arg_token_stream: ArgTokenStream) -> CommandLoaderResult:
    group: IConfigGroup
    leaf: IConfigLeaf | None
    group, leaf = _load_config_path(config_schema, arg_token_stream)
    return CommandLoaderResult(
        lambda: execute_get(config, group, leaf, normal_printer),
        _get_list_of_candidate_text_for_group(group) if not leaf else [],
    )

def load_set(config: IPersistentConfig, config_schema: IConfigGroup, normal_printer: IPrinter, warning_printer: IPrinter, error_printer: IPrinter, arg_token_stream: ArgTokenStream) -> CommandLoaderResult:
    arg_token_stream.set_keep_delimiters(_PATH_DIVIDER_CHAR + ' ')
    traverse_tree: _TraverseTree = _TraverseTree(config_schema, break_on_space_delimiter=False)
    arg.for_each(arg_token_stream, arg.TOKEN, traverse_tree.process_token)
    leaf: IConfigLeaf| None = traverse_tree.leaf
    if leaf is None:
        msg = 'Expected path to leaf config item'
        raise CommandLoaderError(msg, None, _get_list_of_candidate_text_for_group(traverse_tree.group))
    value: str = arg_token_stream.get_remaining_raw_text().lstrip()
    return CommandLoaderResult(
        lambda: execute_set(config, leaf, value, normal_printer, warning_printer, error_printer),
        _get_list_of_candidate_text_for_group(traverse_tree.group) if not traverse_tree.leaf else [],
    )

def load_edit(config: IPersistentConfig, config_schema: IConfigGroup, default_input_text: IDefaultInputText, error_printer: IPrinter, arg_token_stream: ArgTokenStream) -> CommandLoaderResult:
    group: IConfigGroup
    leaf: IConfigLeaf
    group, leaf = _load_config_path_leaf(config_schema, arg_token_stream)
    return CommandLoaderResult(
        lambda: execute_edit(config, leaf, default_input_text, error_printer),
        _get_list_of_candidate_text_for_group(group) if not leaf else [],
    )

def load_reset(config: IPersistentConfig, config_schema: IConfigGroup, normal_printer: IPrinter, warning_printer: IPrinter, error_printer: IPrinter, arg_token_stream: ArgTokenStream) -> CommandLoaderResult:
    group: IConfigGroup
    leaf: IConfigLeaf
    group, leaf = _load_config_path_leaf(config_schema, arg_token_stream)
    return CommandLoaderResult(
        lambda: execute_reset(config, leaf, normal_printer, warning_printer, error_printer),
        _get_list_of_candidate_text_for_group(group) if not leaf else [],
    )

def load_purge(config: IPersistentConfig, normal_printer: IPrinter, warning_printer: IPrinter, error_printer: IPrinter, arg_token_stream: ArgTokenStream) -> CommandLoaderResult:
    arg.fail_if_not_empty(arg_token_stream)
    return CommandLoaderResult(
        lambda: execute_purge(config, normal_printer, warning_printer, error_printer),
        [],
    )

def execute_get(config: IConfig, group: IConfigGroup, leaf: IConfigLeaf | None, normal_printer: IPrinter) -> None:
    _PrintTree(config, normal_printer).print(group, leaf)

def execute_set(config: IPersistentConfig, leaf: IConfigLeaf, value: str, normal_printer: IPrinter, warning_printer: IPrinter, error_printer: IPrinter) -> None:
    if leaf.is_protected:
        error_printer.writeln(f"Refusing to modify protected config item '{leaf.full_path}'")
    elif leaf.try_set_value(config, value):
        config.save(normal_printer, warning_printer, error_printer)
    else:
        error_printer.writeln('Failed to set config item')

def execute_edit(config: IConfig, leaf: IConfigLeaf, default_input_text: IDefaultInputText, error_printer: IPrinter) -> None:
    if leaf.is_protected:
        error_printer.writeln(f"Refusing to modify protected config item '{leaf.full_path}'")
    else:
        default_input_text.set(f'config set {leaf.full_path} {leaf.fetch_value_or_default(config)}')

def execute_reset(config: IPersistentConfig, leaf: IConfigLeaf, normal_printer: IPrinter, warning_printer: IPrinter, error_printer: IPrinter) -> None:
    if leaf.is_protected:
        error_printer.writeln(f"Refusing to modify protected config item '{leaf.full_path}'")
    else:
        normal_printer.writeln(f"Resetting value to '{leaf.default_value}'")
        if leaf.try_set_value(config, leaf.default_value):
            config.save(normal_printer, warning_printer, error_printer)
        else:
            error_printer.writeln('Failed to set config item')

def execute_purge(config: IPersistentConfig, normal_printer: IPrinter, warning_printer: IPrinter, error_printer: IPrinter) -> None:
    if config.try_purge(normal_printer):
        config.save(normal_printer, warning_printer, error_printer)
    else:
        normal_printer.writeln('No entries found to purge')

class Help(IHelpInfo):
    @override
    def get_one_line_summary(self) -> str:
        return "Views and edits entries within the configuration"

    @override
    def get_detailed_summary(self) -> str:
        return (
            "Arguments: get|set|edit|reset|purge\r"
            "  get   [path to config group/item]\r"
            "  set   <path to config item>       <...>\r"
            "  edit  <path to config item>\r"
            "  reset <path to config item>\r"
            "  purge\n"
            f"The path to a config group is a sequence of names separated by a '{_PATH_DIVIDER_CHAR}'."
            f" For example, '{CONFIG_SCHEMA.format.html.css_file_path.full_path}'.\n"
            "When a config item is 'set', all text following the path is accepted verbatim.\n"
            "The 'purge' subcommand removes redundant or unknown entries from the configuration file.\n"
            "Example:\r"
            "  \tShow the ANSI matching text highlight colour\r"
            f"  > \tconfig get {CONFIG_SCHEMA.format.ansi.colour.matching_text.full_path}\r"
            "Example:\r"
            "  \tChange the ANSI matching text highlight colour\r"
            f"  > \tconfig set {CONFIG_SCHEMA.format.ansi.colour.matching_text.full_path} 1;41\r"
            "Example:\r"
            "  \tEdit the ANSI matching text highlight colour\r"
            f"  > \tconfig edit {CONFIG_SCHEMA.format.ansi.colour.matching_text.full_path}\r"
            "Example:\r"
            "  \tReset the ANSI matching text highlight colour\r"
            f"  > \tconfig reset {CONFIG_SCHEMA.format.ansi.colour.matching_text.full_path}\r"
            "Example:\r"
            "  \tPurge redundant entries\r"
            f"  > \tconfig purge"
        )

class _PrintTree:
    def __init__(self, config: IConfig, normal_printer: IPrinter) -> None:
        self._config: IConfig = config
        self._normal_printer: IPrinter = normal_printer

    def print(self, group: IConfigGroup, leaf: IConfigLeaf | None) -> None:
        if leaf:
            self._normal_printer.writeln(f" Leaf: {leaf.full_path} = '{leaf.fetch_value_or_default(self._config)}'")
        else:
            self._normal_printer.writeln(f'Group: {group.full_path}')
            child_leaf: IConfigLeaf
            for child_leaf in group.list_of_child_leaves:
                self.print(group, child_leaf)
            child_group: IConfigGroup
            for child_group in group.list_of_child_groups:
                self.print(child_group, None)

def _load_config_path(config_schema: IConfigGroup, arg_token_stream: ArgTokenStream) -> tuple[IConfigGroup, IConfigLeaf | None]:
    arg_token_stream.set_keep_delimiters(_PATH_DIVIDER_CHAR + ' ')
    traverse_tree: _TraverseTree = _TraverseTree(config_schema, break_on_space_delimiter=True)
    arg.for_each(arg_token_stream, arg.TOKEN, traverse_tree.process_token)

    if traverse_tree.broke_on_space_delimiter:
        if arg_token_stream.get_remaining_raw_text().lstrip():
            msg = 'Unexpected redundant parameters after path'
            raise CommandLoaderError(msg, None, [])

        return traverse_tree.group, traverse_tree.leaf

    if arg_token_stream.get_remaining_raw_text().lstrip():
        msg = 'Unexpected redundant parameters after path'
        raise CommandLoaderError(msg, None, _get_list_of_candidate_text_for_group(traverse_tree.group) if not traverse_tree.leaf else [])

    return traverse_tree.group, traverse_tree.leaf

def _load_config_path_leaf(config_schema: IConfigGroup, arg_token_stream: ArgTokenStream) -> tuple[IConfigGroup, IConfigLeaf]:
    group: IConfigGroup
    leaf: IConfigLeaf | None
    group, leaf = _load_config_path(config_schema, arg_token_stream)
    if leaf is None:
        msg = 'Expected path to leaf config item'
        raise CommandLoaderError(msg, None, _get_list_of_candidate_text_for_group(group))

    return group, leaf

class _TraverseTree:
    def __init__(self, config_schema: IConfigGroup, *, break_on_space_delimiter: bool) -> None:
        self._current_group: IConfigGroup = config_schema
        self._break_on_space_delimiter: bool = break_on_space_delimiter
        self._broke_on_space_delimiter: bool = False
        self._last_token: Token | None = None
        self._last_non_delimiter_token: Token | None = None
        self._leaf: IConfigLeaf | None = None
        self._is_expecting_path_divider: bool = False

    def process_token(self, token: Token) -> bool:
        """Process the token to traverse the path.

        ### Raises:
        - CommandLoaderError
        """
        if self._last_token is None and token.is_delimiter and token.text == ' ':
            return True

        self._last_token = token

        if self._break_on_space_delimiter and token.is_delimiter and token.text == ' ':
            self._broke_on_space_delimiter = True
            return False

        if self._is_expecting_path_divider:
            if not token.is_delimiter or token.text != _PATH_DIVIDER_CHAR:
                msg = f"Expected path divider '{_PATH_DIVIDER_CHAR}' after '{self._current_group.full_path}'"
                raise CommandLoaderError(msg, token, [CandidateText(_PATH_DIVIDER_CHAR, '')])
            self._is_expecting_path_divider = False
            return True

        self._last_non_delimiter_token = token

        name_of_group_or_leaf: str = token.text
        leaf: IConfigLeaf | None = self._current_group.try_find_child_leaf(name_of_group_or_leaf)
        if leaf:
            self._leaf = leaf
            return False

        group: IConfigGroup | None = self._current_group.try_find_child_group(name_of_group_or_leaf)
        if group:
            self._current_group = group
            self._is_expecting_path_divider = True
        else:
            msg = f"Unrecognised config group or leaf '{name_of_group_or_leaf}' within '{self._current_group.full_path}'"
            raise CommandLoaderError(msg, token, _get_list_of_candidate_text_for_group(self._current_group))

        return True

    @property
    def last_token(self) -> Token | None:
        return self._last_token

    @property
    def last_non_delimiter_token(self) -> Token | None:
        return self._last_non_delimiter_token

    @property
    def group(self) -> IConfigGroup:
        return self._current_group

    @property
    def leaf(self) -> IConfigLeaf | None:
        return self._leaf

    @property
    def broke_on_space_delimiter(self) -> bool:
        return self._broke_on_space_delimiter

def _get_list_of_candidate_text_for_group(group: IConfigGroup) -> Sequence[CandidateText]:
    list_of_candidate_text: Sequence[CandidateText] = [
        CandidateText(child_group.key_name, _PATH_DIVIDER_CHAR) for child_group in group.list_of_child_groups
    ] + [
        CandidateText(leaf.key_name, ' ') for leaf in group.list_of_child_leaves
    ]
    return list_of_candidate_text
