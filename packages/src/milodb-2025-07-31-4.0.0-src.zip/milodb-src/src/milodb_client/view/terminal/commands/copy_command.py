# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from collections.abc import Callable, Iterable, Sequence
from dataclasses import dataclass
from types import TracebackType
from typing import override
import pyclip # type: ignore[import-untyped]
from milodb_common.output.print.capturing_printer import CapturingPrinter
from milodb_common.output.print.i_printer import IPrinter, IRedirectablePrinter
from milodb_common.output.print.split_printer import SplitPrinter
from milodb_common.parser.arg_token_stream import ArgTokenStream
from milodb_common.parser.candidate_text import CandidateText
from milodb_common.view.terminal.command_framework.i_command import CommandLoaderError, CommandLoaderResult
from milodb_common.view.terminal.command_framework.i_command_constructor import ICommandConstructor
from milodb_common.view.terminal.command_framework.i_help_info import IHelpInfo

def load(arg_token_stream: ArgTokenStream, command_constructor: ICommandConstructor, list_of_printers: Iterable[IRedirectablePrinter], error_printer: IPrinter) -> CommandLoaderResult:
    construct_result: ICommandConstructor.ConstructResult = command_constructor.try_construct(arg_token_stream)
    if isinstance(construct_result, ICommandConstructor.SuccessfulResult):
        return CommandLoaderResult(
            lambda: execute(construct_result.command, list_of_printers, error_printer),
            construct_result.list_of_candidate_text)
    if isinstance(construct_result, ICommandConstructor.EmptyInputResult):
        msg = 'Expecting a following command'
        raise CommandLoaderError(msg, None, CandidateText.space_delimited_list(construct_result.list_of_command_names))
    raise ICommandConstructor.DelegateError(construct_result)

def execute(delegate_command: Callable[[], None], list_of_printers: Iterable[IRedirectablePrinter], error_printer: IPrinter) -> None:
    with _Capture(list_of_printers, error_printer):
        delegate_command()

@dataclass
class _RedirectedPrinter:
    printer: IRedirectablePrinter
    previous_target: IPrinter

class _Capture:
    def __init__(self, list_of_printers: Iterable[IRedirectablePrinter], error_printer: IPrinter) -> None:
        self._list_of_printers: Iterable[IRedirectablePrinter] = list_of_printers
        self._list_of_redirected_printers: Sequence[_RedirectedPrinter]
        self._capturing_printer: CapturingPrinter
        self._error_printer: IPrinter = error_printer

    def __enter__(self) -> None:
        self._list_of_redirected_printers = []
        self._capturing_printer = CapturingPrinter()
        printer: IRedirectablePrinter
        for printer in self._list_of_printers:
            current_printer_target: IPrinter = printer.get_target_printer()
            self._list_of_redirected_printers.append(_RedirectedPrinter(printer, current_printer_target))
            printer.set_target_printer(SplitPrinter([current_printer_target, self._capturing_printer]))

    def __exit__(self, exc_type: type[BaseException] | None, exc_value: BaseException | None, traceback: TracebackType | None) -> None:
        redirected_printer: _RedirectedPrinter
        for redirected_printer in self._list_of_redirected_printers:
            redirected_printer.printer.set_target_printer(redirected_printer.previous_target)
        try:
            pyclip.copy(self._capturing_printer.text.rstrip())
        except pyclip.ClipboardSetupException as ex:
            self._error_printer.writeln(f'Unable to copy to clipboard: {ex}')

    @property
    def text(self) -> str:
        return self._capturing_printer.text

class Help(IHelpInfo):
    @override
    def get_one_line_summary(self) -> str:
        return "Copies the output of the subsequent command to the clipboard"

    @override
    def get_detailed_summary(self) -> str:
        return (
            "Arguments: <subsequent command...>\n"
            "The output of the subsequent command is copied to the clipboard in the currently"
            " selected format.\n"
            "Example:\r"
            "  \tList the current query results and copy the list to the clipboard\r"
            "  > \tcopy list\n"
            "Example:\r"
            "  \tCopy the url of the author of match #3 to the clipboard\r"
            "  > \tcopy urlauthor 3\n"
            "See also:\r"
            "  \tformat, ellipsis, highlight\n"
        )
