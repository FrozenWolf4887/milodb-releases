# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from collections.abc import Iterable
from typing import TYPE_CHECKING, override
from milodb_client.database.tease import Tease
from milodb_client.output.format.i_formatter_factory import IFormatterCreator
from milodb_client.query.tease_match import TeaseMatch
from milodb_client.view.terminal.commands.database_support import try_create_list_of_tease_matches_from_ref_ids
from milodb_common.output.print.i_printer import IPrinter
from milodb_common.parser import arg
from milodb_common.parser.arg_token_stream import ArgTokenStream
from milodb_common.parser.ref_id import RefId
from milodb_common.view.terminal.command_framework.i_command import CommandLoaderResult
from milodb_common.view.terminal.command_framework.i_help_info import IHelpInfo
if TYPE_CHECKING:
    from milodb_client.output.format.i_formatter import IFormatter

def load(arg_token_stream: ArgTokenStream, list_of_teases: Iterable[Tease], list_of_tease_matches: Iterable[TeaseMatch], formatter_creator: IFormatterCreator, normal_printer: IPrinter, error_printer: IPrinter) -> CommandLoaderResult:
    list_of_ref_ids: Iterable[RefId] = arg.pop_list(arg_token_stream, arg.REF_ID)
    return CommandLoaderResult(
        lambda: execute(list_of_ref_ids, list_of_teases, list_of_tease_matches, formatter_creator, normal_printer, error_printer),
        [],
    )

def execute(list_of_ref_ids: Iterable[RefId], list_of_teases: Iterable[Tease], list_of_tease_matches: Iterable[TeaseMatch], formatter_creator: IFormatterCreator, normal_printer: IPrinter, error_printer: IPrinter) -> None:
    if list_of_ref_ids:
        _print_summaries(
            try_create_list_of_tease_matches_from_ref_ids(list_of_teases, list_of_tease_matches, list_of_ref_ids, error_printer),
            formatter_creator, normal_printer, error_printer)
    else:
        _print_summaries(list_of_tease_matches, formatter_creator, normal_printer, error_printer)

def _print_summaries(list_of_tease_matches: Iterable[TeaseMatch] | None, formatter_creator: IFormatterCreator, normal_printer: IPrinter, error_printer: IPrinter) -> None:
    if list_of_tease_matches:
        formatter: IFormatter = formatter_creator.create(normal_printer)
        is_first_tease: bool = True
        tease_match: TeaseMatch
        for tease_match in list_of_tease_matches:
            if is_first_tease:
                is_first_tease = False
            else:
                normal_printer.writeln()
            formatter.print_summary_of_tease(tease_match)
    else:
        error_printer.writeln("No teases available to summarise")

class Help(IHelpInfo):
    @override
    def get_one_line_summary(self) -> str:
        return "Prints the summaries for the current results"

    @override
    def get_detailed_summary(self) -> str:
        return (
            "Arguments: [list of RefIds]\n"
            "Shows summary details for each tease without any matching text paragraphs. The"
            " formatting used for the details can be controlled with the format command.\n"
            "When used without arguments, all teases that were found from the last query are"
            " included. When one or more RefIds are specified, only those teases are included.\n"
            "RefIds can be an index into the list of matches such as '3', a teaseId such as"
            " '#38664', or an authorId such as '@43937'.\n"
            "Matching fields may be highlighted which can be controlled with the highlight"
            " command.\n"
            "Example:\r"
            "  \tShow details of the last query results\r"
            "  > \tsummary\r"
            "Example:\r"
            "  \tShow details of a tease by index in the match list\r"
            "  > \tsummary 3\r"
            "Example:\r"
            "  \tShow details for some specific teaseIds\r"
            "  > \tsummary #16830 #1465 #38664\r"
            "Example:\r"
            "  \tShow details of the teases from a specific authorId\r"
            "  > \topen @43937\n"
            "See also:\r"
            "  \tshow, format, highlight\n"
        )
