# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from collections.abc import Sequence
from typing import TYPE_CHECKING
from milodb_client.database.database import try_get_newest_tease_date, try_get_oldest_tease_date
from milodb_client.database.tease import Tease
from milodb_client.updater.manifest.local_manifest import ILocalManifest
if TYPE_CHECKING:
    import datetime

APPLICATION_NAME: str = 'MiloDB'
AUTHOR_NAME: str = 'FrozenWolf'
AUTHOR_ID: int = 102_759
FORUM_THREAD_URL: str = 'https://milovana.com/forum/viewtopic.php?t=25177'
SOFTWARE_LICENCE_TEXT: str = (
    'MiloDB by FrozenWolf is marked with CC0 1.0.\n'
    'To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/'
)
TEASE_COPYRIGHT_TEXT: str = (
    'The ownership/copyright of each tease remains with the respective author according to'
    ' the Milovana.com terms of service, https://milovana.com/pages/tos.php'
)

def get_version_one_line(local_manifest: ILocalManifest | None) -> str:
    return f'{APPLICATION_NAME} {local_manifest.version_number if local_manifest else "(Unknown Version)"}, {local_manifest.date if local_manifest else "(Unknown Date)"}'

def get_database_info_one_line(list_of_teases: Sequence[Tease]) -> str:
    oldest_tease_date: datetime.date | None = try_get_oldest_tease_date(list_of_teases)
    newest_tease_date: datetime.date | None = try_get_newest_tease_date(list_of_teases)
    return f"{len(list_of_teases):,} teases loaded ranging from {oldest_tease_date or 'None'} to {newest_tease_date or 'None'}"
