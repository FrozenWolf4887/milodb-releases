# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from collections.abc import Callable, Iterable, Mapping, MutableSequence, Sequence
from dataclasses import dataclass
from pathlib import Path
from milodb_common.util.ref import IRef, SimpleRef

class Argument:
    NO_AUTOEXEC: str = '-n'
    NO_LOAD: str = '--no-load'
    WAIT_PID: str = '--wait-pid'
    PERFORM_UPDATE: str = '--perform-update'
    PURGE_TEMP_DIRECTORY: str = '--purge-temp-dir'

@dataclass
class CommandLine:
    no_load: bool
    list_of_pids_to_wait_on: Sequence[int]
    list_of_temp_directories_to_purge: Sequence[Path]
    update_from_sequence_filepath: Path | None
    autoexec: bool

class CommandLineError(Exception):
    pass

def parse_command_line(sequence_of_args: Iterable[str]) -> CommandLine:
    """Parse the command line from the first argument.

    ### Raises:
    - CommandLineError
    """
    list_of_args: list[str] = list(sequence_of_args)

    switch_name: str = ''
    no_load: SimpleRef[bool] = SimpleRef(False)
    list_of_pids_to_wait_on: list[int] = []
    list_of_temp_directories_to_purge: list[str] = []
    ref_update_from_sequence_filepath: IRef[str | None] = SimpleRef(None)
    ref_autoexec: IRef[bool] = SimpleRef(True)

    map_of_switch_to_handler: Mapping[str, Callable[[], None]] = {
        Argument.NO_LOAD: lambda: _parse_no_load_switch(no_load),
        Argument.WAIT_PID: lambda: _parse_wait_pid_switch(switch_name, list_of_args, list_of_pids_to_wait_on),
        Argument.PURGE_TEMP_DIRECTORY: lambda: _parse_purge_temp_directory_switch(switch_name, list_of_args, list_of_temp_directories_to_purge),
        Argument.PERFORM_UPDATE: lambda: _parse_update_switch(switch_name, list_of_args, ref_update_from_sequence_filepath),
        Argument.NO_AUTOEXEC: lambda: _parse_no_autoexec_switch(ref_autoexec),
    }

    while list_of_args:
        switch_name = list_of_args.pop(0)
        switch_handler: Callable[[], None] | None = map_of_switch_to_handler.get(switch_name)
        if not switch_handler:
            msg: str
            if switch_name.startswith('-'):
                msg = f"Switch '{switch_name}' is not recognised"
            else:
                msg = f"Argument '{switch_name}' is unexpected"
            raise CommandLineError(msg)
        switch_handler()

    update_from_sequence_filepath: str | None = ref_update_from_sequence_filepath.get()

    return CommandLine(
        no_load.get(),
        list_of_pids_to_wait_on,
        [ Path(directory) for directory in list_of_temp_directories_to_purge ],
        Path(update_from_sequence_filepath) if update_from_sequence_filepath else None,
        ref_autoexec.get(),
    )

def _parse_no_load_switch(no_load: SimpleRef[bool]) -> None:
    no_load.set(True)

def _parse_wait_pid_switch(switch_name: str, list_of_args: MutableSequence[str], list_of_pids_to_wait_on: MutableSequence[int]) -> None:
    """Parse the wait PID switch.

    ### Raises:
    - CommandLineError
    """
    try:
        pid_text: str = list_of_args.pop(0)
    except IndexError as ex:
        msg: str = f"Switch '{switch_name}' missing parameter"
        raise CommandLineError(msg) from ex

    try:
        list_of_pids_to_wait_on.append(int(pid_text))
    except ValueError as ex:
        msg = f"Switch '{switch_name}' specified with invalid PID parameter '{pid_text}'"
        raise CommandLineError(msg) from ex

def _parse_purge_temp_directory_switch(switch_name: str, list_of_args: MutableSequence[str], list_of_temp_directories_to_purge: MutableSequence[str]) -> None:
    """Parse the purge temp directory switch.

    ### Raises:
    - CommandLineError
    """
    try:
        path: str = list_of_args.pop(0)
    except IndexError as ex:
        msg: str = f"Switch '{switch_name}' missing parameter"
        raise CommandLineError(msg) from ex

    list_of_temp_directories_to_purge.append(path)

def _parse_update_switch(switch_name: str, list_of_args: MutableSequence[str], ref_update_from_sequence_filepath: IRef[str | None]) -> None:
    """Parse the update switch.

    ### Raises:
    - CommandLineError
    """
    try:
        path: str = list_of_args.pop(0)
    except IndexError as ex:
        msg: str = f"Switch '{switch_name}' missing parameter"
        raise CommandLineError(msg) from ex

    if ref_update_from_sequence_filepath.get():
        msg = f"Switch '{switch_name}' has already been specified"
        raise CommandLineError(msg)

    ref_update_from_sequence_filepath.set(path)

def _parse_no_autoexec_switch(ref_autoexec: IRef[bool]) -> None:
    ref_autoexec.set(False)
