# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from __future__ import annotations
from abc import ABC, abstractmethod

class SchemaLoadError(Exception):
    pass

class KeyParseError(Exception):
    pass

class IKey(ABC):
    @property
    @abstractmethod
    def name(self) -> str:
        pass

class ITypedKey[K](IKey):
    @abstractmethod
    def get_key_value(self) -> K:
        pass

class IKeyCreator[K](ABC):
    @abstractmethod
    def parse(self, key_name: str) -> ITypedKey[K]:
        """Parse the key from the specified key_name.

        ### Raises
        - KeyParseError
            - If the key_name cannot be parsed to the base type
        """

    @abstractmethod
    def from_base_type(self, value: K) -> ITypedKey[K]:
        pass

class IItem(ABC):
    @property
    @abstractmethod
    def is_mandatory(self) -> bool:
        pass

    @property
    @abstractmethod
    def parent(self) -> IGroup | None:
        pass

    @property
    @abstractmethod
    def key(self) -> IKey:
        pass

    @property
    @abstractmethod
    def full_path(self) -> str:
        pass

    @abstractmethod
    def load(self, value: object) -> None:
        """Load this object from the given value.

        ### Raises
        - SchemaLoadError
            - If there are any issues loading the value
        """

    @abstractmethod
    def save(self) -> object:
        pass

class ITypedItem[T](IItem):
    @abstractmethod
    def get_item_value(self) -> T:
        pass

class IGroup(IItem):
    @abstractmethod
    def add_child(self, child: IItem) -> None:
        pass
