# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from abc import ABC, abstractmethod
from collections.abc import Mapping, Sequence
from pathlib import Path

class IMoveFile(ABC):
    @property
    @abstractmethod
    def must_exist(self) -> bool:
        pass

    @property
    @abstractmethod
    def original_filename(self) -> Path:
        pass

    @property
    @abstractmethod
    def new_filename(self) -> Path:
        pass

class IMoveFilesAction(ABC):
    @property
    @abstractmethod
    def priority(self) -> int:
        pass

    @property
    @abstractmethod
    def files(self) -> Sequence[IMoveFile]:
        pass

class IEmplaceFile(ABC):
    @property
    @abstractmethod
    def source_filename(self) -> Path:
        pass

    @property
    @abstractmethod
    def target_filename(self) -> Path:
        pass

class IEmplaceFilesAction(ABC):
    @property
    @abstractmethod
    def priority(self) -> int:
        pass

    @property
    @abstractmethod
    def files(self) -> Sequence[IEmplaceFile]:
        pass

class IDeleteFile(ABC):
    @property
    @abstractmethod
    def must_exist(self) -> bool:
        pass

    @property
    @abstractmethod
    def filename(self) -> Path:
        pass

class IDeleteFilesAction(ABC):
    @property
    @abstractmethod
    def priority(self) -> int:
        pass

    @property
    @abstractmethod
    def files(self) -> Sequence[IDeleteFile]:
        pass

class IDeleteDirectoryAction(ABC):
    @property
    @abstractmethod
    def priority(self) -> int:
        pass

    @property
    @abstractmethod
    def filename(self) -> Path:
        pass

class ISetFileAttribute(ABC):
    @property
    @abstractmethod
    def filename(self) -> Path:
        pass

    @property
    @abstractmethod
    def is_readonly(self) -> bool:
        pass

    @property
    @abstractmethod
    def is_executable(self) -> bool:
        pass

class ISetFilesAttributeAction(ABC):
    @property
    @abstractmethod
    def priority(self) -> int:
        pass

    @property
    @abstractmethod
    def files(self) -> Sequence[ISetFileAttribute]:
        pass

class IUpdateSequence(ABC):
    @property
    @abstractmethod
    def format(self) -> int:
        pass

    @property
    @abstractmethod
    def root_directory(self) -> Path:
        pass

    @property
    @abstractmethod
    def temp_directory(self) -> Path:
        pass

    @property
    @abstractmethod
    def move_files_actions(self) -> Mapping[int, IMoveFilesAction]:
        pass

    @property
    @abstractmethod
    def emplace_files_actions(self) -> Mapping[int, IEmplaceFilesAction]:
        pass

    @property
    @abstractmethod
    def delete_files_actions(self) -> Mapping[int, IDeleteFilesAction]:
        pass

    @property
    @abstractmethod
    def set_files_attribute_actions(self) -> Mapping[int, ISetFilesAttributeAction]:
        pass

    @property
    @abstractmethod
    def launch_filename(self) -> Path | None:
        pass
