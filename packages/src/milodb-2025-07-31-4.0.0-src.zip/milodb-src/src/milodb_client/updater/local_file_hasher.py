# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from hashlib import sha3_224
from pathlib import Path
from typing import override
from milodb_client.updater.i_file_hasher import HashError, HashFileNotFoundError, IFileHasher

_HASHING_BUFFER_SIZE: int = 64 * 1024

class LocalFileHasher(IFileHasher):
    @override
    def hash_file(self, filepath: Path) -> bytes:
        digest = sha3_224()
        try:
            end_of_file: bool = False
            with filepath.open('rb') as file:
                while not end_of_file:
                    data_chunk: bytes = file.read(_HASHING_BUFFER_SIZE)
                    if data_chunk:
                        digest.update(data_chunk)
                    else:
                        end_of_file = True
        except FileNotFoundError as ex:
            msg = f"File '{filepath}' not found"
            raise HashFileNotFoundError(msg) from ex
        except OSError as ex:
            msg = f"Error hashing '{filepath}': {ex}"
            raise HashError(msg) from ex
        return digest.digest()
