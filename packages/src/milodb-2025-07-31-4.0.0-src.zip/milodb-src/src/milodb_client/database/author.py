# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from collections.abc import Mapping
from enum import Enum
from milodb_client.database.metadata_getter import MetadataGetter

_KEY_AUTHOR_NAME: str = 'anm'
_KEY_AUTHOR_GONE: str = 'agn'

class AuthorStatus(Enum):
    ACTIVE = 0
    UNKNOWN = 1
    GONE = 2

class Author:
    class LoadError(Exception):
        pass

    def __init__(self, author_id: int, metadata: Mapping[object, object]) -> None:
        """Create an Author object from JSON metadata.

        ### Raises
        - Author.LoadError
        """
        self._author_id = author_id
        getter: MetadataGetter = MetadataGetter(metadata, Author.LoadError)
        self._author_name: str = getter.get_str_or_blank(_KEY_AUTHOR_NAME)
        self._has_author_gone: bool = getter.get_bool_or_default(_KEY_AUTHOR_GONE, default=False)

    @property
    def author_id(self) -> int:
        return self._author_id

    @property
    def has_author(self) -> bool:
        return bool(self._author_id)

    @property
    def name(self) -> str:
        return self._author_name

    @property
    def has_gone(self) -> bool:
        return self._has_author_gone

    @property
    def status(self) -> AuthorStatus:
        if self._author_id == 0:
            return AuthorStatus.UNKNOWN
        if self._has_author_gone:
            return AuthorStatus.GONE
        return AuthorStatus.ACTIVE
