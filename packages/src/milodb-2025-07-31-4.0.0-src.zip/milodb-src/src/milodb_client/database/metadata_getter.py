# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from __future__ import annotations
import datetime
from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from collections.abc import Callable, Mapping, Sequence

class MetadataGetter:
    def __init__(self, metadata: Mapping[object, object], exception_class: type[Exception]) -> None:
        self._metadata: Mapping[object, object] = metadata
        self._exception_class: type[Exception] = exception_class

    def sub_metadata(self, metadata: Mapping[object, object]) -> MetadataGetter:
        return MetadataGetter(metadata, self._exception_class)

    def try_get_str(self, key: str) -> str | None:
        value: object = self._metadata.get(key)
        if value is None:
            return None
        if isinstance(value, str):
            return value
        msg = f"Key '{key}' is not a string"
        raise self._exception_class(msg)

    def try_get_int(self, key: str, *, min_value: int | None, max_value: int | None) -> int | None:
        value: object = self._metadata.get(key)
        if value is None:
            return None
        if not isinstance(value, int):
            msg = f"Key '{key}' is not an integer"
            raise self._exception_class(msg)
        self._verify_number_range(key, value, min_value, max_value)
        return value

    def try_get_float(self, key: str, *, min_value: float | None, max_value: float | None) -> float | None:
        value: object = self._metadata.get(key)
        if value is None:
            return None
        if not isinstance(value, int | float):
            msg = f"Key '{key}' is not a decimal"
            raise self._exception_class(msg)
        value = float(value)
        self._verify_number_range(key, value, min_value, max_value)
        return value

    def try_get_date(self, key: str) -> datetime.date | None:
        value: object = self._metadata.get(key)
        if value is None:
            return None
        if not isinstance(value, str):
            msg = f"Key '{key}' is not a string"
            raise self._exception_class(msg)
        try:
            return datetime.date.fromisoformat(value)
        except ValueError as ex:
            msg = f"Key '{key}' value '{value}' is not a valid ISO date"
            raise self._exception_class(msg) from ex

    def try_get_bool(self, key: str) -> bool | None:
        value: object = self._metadata.get(key)
        if value is None or isinstance(value, bool):
            return value
        bool_value: bool | None = None
        if isinstance(value, str):
            bool_value = _MAP_OF_BOOLEAN_TEXT_TO_VALUE.get(value.lower())
        if bool_value is None:
            msg = f"Key '{key}' value '{value}' is not a valid boolean"
            raise self._exception_class(msg)
        return bool_value

    def try_get_dict_value[K, V](self, key: str, dict_key_getter: Callable[[str], K | None], dictionary: Mapping[K, V]) -> V | None:
        dict_key: K | None = dict_key_getter(key)
        if dict_key is None:
            return None
        value: V | None = dictionary.get(dict_key)
        if value is None:
            msg = f"Key '{key}' value '{dict_key}' is not a known value"
            raise self._exception_class(msg)
        return value

    def get_str(self, key: str) -> str:
        value: str | None = self.try_get_str(key)
        if value is None:
            msg = f"Key '{key}' is missing"
            raise self._exception_class(msg)
        return value

    def get_str_or_blank(self, key: str) -> str:
        value: str | None = self.try_get_str(key)
        return '' if value is None else value

    def get_dict_list_or_empty(self, key: str) -> Sequence[Mapping[object, object]]:
        value: object = self._metadata.get(key)
        if value is None:
            return []
        if not isinstance(value, list):
            msg = f"Key '{key}' is not a list"
            raise self._exception_class(msg)
        list_of_values: Sequence[object] = value
        list_of_dict: list[dict[object, object]] = []
        index: int
        for index, value in enumerate(list_of_values):
            if not isinstance(value, dict):
                msg = f"Key '{key}' list entry #{index} is not a dictionary"
                raise self._exception_class(msg)
            list_of_dict.append(value)
        return list_of_dict

    def get_str_list_or_empty(self, key: str) -> Sequence[str]:
        value: object = self._metadata.get(key)
        if value is None:
            return []
        if not isinstance(value, list):
            msg = f"Key '{key}' is not a list"
            raise self._exception_class(msg)
        list_of_values: Sequence[object] = value
        list_of_strings: list[str] = []
        index: int
        for index, value in enumerate(list_of_values):
            if not isinstance(value, str):
                msg = f"Key '{key}' list entry #{index} is not a string"
                raise self._exception_class(msg)
            list_of_strings.append(value)
        return list_of_strings

    def get_int(self, key: str, *, min_value: int | None, max_value: int | None, default_value_if_none: int | None) -> int:
        value: int | None = self.try_get_int(key, min_value=min_value, max_value=max_value)
        if value is None:
            if default_value_if_none is not None:
                return default_value_if_none
            msg = f"Key '{key}' is missing"
            raise self._exception_class(msg)
        return value

    def get_float(self, key: str, *, min_value: float | None, max_value: float | None, default_value_if_none: float | None) -> float:
        value: float | None = self.try_get_float(key, min_value=min_value, max_value=max_value)
        if value is None:
            if default_value_if_none is not None:
                return default_value_if_none
            msg = f"Key '{key}' is missing"
            raise self._exception_class(msg)
        return value

    def get_date(self, key: str) -> datetime.date:
        value: datetime.date | None = self.try_get_date(key)
        if value is None:
            msg = f"Key '{key}' is missing"
            raise self._exception_class(msg)
        return value

    def get_bool_or_default(self, key: str, default: bool) -> bool: # noqa: FBT001 Boolean-typed positional argument in function definition
        value: bool | None = self.try_get_bool(key)
        return default if value is None else value

    def get_dict_value[K, V](self, key: str, dict_key_getter: Callable[[str], K], dictionary: Mapping[K, V]) -> V:
        dict_key: K = dict_key_getter(key)
        value: V | None = dictionary.get(dict_key)
        if value is None:
            msg = f"Key '{key}' value '{dict_key}' is not recognised"
            raise self._exception_class(msg)
        return value

    def _verify_number_range[T: int | float](self, key: str, value: T, min_value: T | None, max_value: T | None) -> None:
        if (min_value is not None and value < min_value) or (max_value is not None and value > max_value): # type: ignore [operator] # False-Positive mypy 1.14.0: https://github.com/python/mypy/issues/18203
            if min_value is not None:
                if max_value is not None:
                    msg = f"Key '{key}' value '{value}' is out of range '{min_value}' to '{max_value}'"
                    raise self._exception_class(msg)
                msg = f"Key '{key}' value '{value}' should be '{min_value}' or greater"
                raise self._exception_class(msg)
            msg = f"Key '{key}' value '{value}' should be '{max_value}' or less"
            raise self._exception_class(msg)

_MAP_OF_BOOLEAN_TEXT_TO_VALUE: Mapping[str, bool] = {
    'true': True,
    'false': False,
}
