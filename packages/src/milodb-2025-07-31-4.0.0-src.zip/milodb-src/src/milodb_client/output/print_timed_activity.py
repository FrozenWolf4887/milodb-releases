# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import time
from types import TracebackType
from milodb_common.output.print.i_printer import IPrinter

class PrintTimedActivity:
    def __init__(self, printer: IPrinter, prefix_text: str, suffix_text: str = ': ', seconds_width: int = 1) -> None:
        self._printer: IPrinter = printer
        self._prefix_text: str = prefix_text
        self._suffix_text: str = suffix_text
        self._seconds_width: int = seconds_width
        self._start_millis: int = 0

    def __enter__(self) -> None:
        self._printer.write(f"{self._prefix_text}")
        self._start_millis = _now_millis()

    def __exit__(self, exc_type: type[BaseException] | None, exc_value: BaseException | None, traceback: TracebackType | None) -> None:
        duration_millis: int = _now_millis() - self._start_millis
        was_aborted: bool = exc_type is not None or exc_value is not None or traceback is not None
        self._printer.writeln(f"{self._suffix_text}{duration_millis // 1000:>{self._seconds_width}}.{duration_millis % 1000:>03}s{' (aborted)' if was_aborted else ''}")

def _now_millis() -> int:
    return round(time.time() * 1000)
