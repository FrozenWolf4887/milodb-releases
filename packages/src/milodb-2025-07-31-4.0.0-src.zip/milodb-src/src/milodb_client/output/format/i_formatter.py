# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from abc import ABC, abstractmethod
from collections.abc import Iterable
from milodb_client.database.tease_page import TeasePage
from milodb_client.query.tease_match import TeaseMatch

class IFormatter(ABC):
    @abstractmethod
    def print_list_of_teases(self, list_of_tease_matches: Iterable[TeaseMatch]) -> None:
        pass

    @abstractmethod
    def print_summary_of_tease(self, tease_match: TeaseMatch) -> None:
        pass

    @abstractmethod
    def print_text_of_page(self, tease_match: TeaseMatch, page: TeasePage) -> None:
        pass

    @abstractmethod
    def print_all_text_of_tease(self, tease_match: TeaseMatch, *, include_header_and_footer: bool) -> None:
        pass

    @abstractmethod
    def print_matching_text_of_tease(self, tease_match: TeaseMatch, *, include_header_and_footer: bool) -> None:
        pass

    @abstractmethod
    def print_all_text_of_list_of_teases(self, list_of_tease_matches: Iterable[TeaseMatch]) -> None:
        pass

    @abstractmethod
    def print_matching_text_of_list_of_teases(self, list_of_tease_matches: Iterable[TeaseMatch]) -> None:
        pass
