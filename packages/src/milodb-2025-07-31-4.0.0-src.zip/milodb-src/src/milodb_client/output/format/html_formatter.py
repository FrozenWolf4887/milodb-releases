# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from collections.abc import Iterable, Mapping
from typing import override
from milodb_client.config.html_config import HtmlConfig
from milodb_client.database.tease import Tease, TeaseProperty, TeaseStrListProperty, TotmStatus
from milodb_client.database.tease_page import TeasePage
from milodb_client.output.format.i_formatter import IFormatter
from milodb_client.output.support import EllipsisLocation, ellipsify_text, get_list_of_indexed_metadata_indices, get_list_of_metadata_indices, get_matching_indices_for_page, iterate_through_indices, iterate_through_lines
from milodb_client.query.field_match import IFieldMatch
from milodb_client.query.tease_match import TeaseMatch
from milodb_common.output.print.i_printer import IPrinter
from milodb_common.util.get_url import get_url_of_author, get_url_of_tease

_MAP_OF_TOTM_STATUS_TO_CSS_CLASS: Mapping[TotmStatus, str] = {
    TotmStatus.NOMINEE: 'totm-nominee',
    TotmStatus.WINNER: 'totm-winner',
}

class HtmlFormatter(IFormatter):
    def __init__(self, html_config: HtmlConfig, printer: IPrinter, *, use_highlighting: bool, ellipsis_max_width: int | None, show_pagerefs: bool) -> None:
        self._html_config: HtmlConfig = html_config
        self._printer: IPrinter = printer
        self._use_highlighting: bool = use_highlighting
        self._ellipsis_max_width: int | None = ellipsis_max_width
        self._show_pagerefs: bool = show_pagerefs

    @override
    def print_list_of_teases(self, list_of_tease_matches: Iterable[TeaseMatch]) -> None:
        self._printer.writeln(
            '<div class="listTable">\n'
            '<div class="th index"></div>'
            '<div class="th hits">Hits</div>'
            '<div class="th teaseId">Id</div>'
            '<div class="th type">Type</div>'
            '<div class="th rating">Rating</div>'
            '<div class="th date">Date</div>'
            '<div class="th title">Title</div>'
            '<div class="th author">Author</div>')
        count_of_tease_matches: int = 0
        tease_match: TeaseMatch
        for tease_match in list_of_tease_matches:
            self._print_oneline_of_tease(tease_match)
            count_of_tease_matches += 1
        self._printer.writeln('</div>') # NOSONAR Define a constant instead of duplicating this literal

        total_text = f"{count_of_tease_matches} match{'es' if count_of_tease_matches != 1 else ''}"
        self._printer.writeln(f'<div class="totalMatches">{total_text}</div>')

    @override
    def print_summary_of_tease(self, tease_match: TeaseMatch) -> None:
        match_index: str = str(tease_match.index_of_match) if tease_match.index_of_match else '-'
        hit_count: int = tease_match.get_match_count()
        tease_id: int = tease_match.tease.get_tease_id()
        author_id: int = tease_match.tease.author.author_id
        url_of_tease: str = get_url_of_tease(tease_id)
        url_of_author: str = get_url_of_author(author_id)
        formatted_tease_id: str = self._highlight_metadata(tease_match, Tease.get_tease_id)
        formatted_tease_title: str = self._highlight_metadata(tease_match, Tease.get_title)
        formatted_author_link: str = 'unknown'
        formatted_author_name: str = 'unknown'
        if tease_match.tease.author.has_author:
            formatted_author_id: str = self._highlight_metadata(tease_match, Tease.get_author_id)
            formatted_author_name = self._highlight_metadata(tease_match, Tease.get_author_name)
            formatted_author_link = f'<a href="{url_of_author}">{formatted_author_id}</a>'
        formatted_tease_date: str = self._highlight_metadata(tease_match, Tease.get_date)
        formatted_tease_type: str = self._highlight_metadata(tease_match, Tease.get_type)
        formatted_tags: str = ', '.join(self._highlight_metadata_string_list(tease_match, Tease.get_list_of_tags, include_matching_only=False))
        formatted_tease_rating: str = self._highlight_metadata(tease_match, Tease.get_rating_value)
        formatted_summary: str = self._highlight_metadata(tease_match, Tease.get_summary)
        totm_css_class: str | None = _MAP_OF_TOTM_STATUS_TO_CSS_CLASS.get(tease_match.tease.get_totm_status())
        totm_css_class_open: str = f'<div class="{totm_css_class}">' if totm_css_class else ''
        totm_css_class_close: str = '</div>' if totm_css_class else ''
        deleted_text: str = '[<span class="deleted">DELETED</span>] ' if tease_match.tease.is_deleted() else ''
        author_gone_text: str = '[<span class="authorGone">GONE</span>] ' if tease_match.tease.author.has_gone else ''
        self._printer.writeln(
            f'<div id="summary{tease_id}" class="summaryTable">\n'
            f'<div class="td thumbnail"><a href="{url_of_tease}"><img src="{tease_match.tease.get_thumbnail()}" alt="Thumbnail"></a></div>'
            '<div class="th index">Index</div>'
            '<div class="th hits">Hits</div>'
            '<div class="th teaseId">Tease</div>'
            '<div class="th teaseTitle">Title</div>'
            '<div class="th authorId">Author</div>'
            '<div class="th authorName">Name</div>'
            '<div class="th type">Type</div>'
            '<div class="th date">Date</div>'
            '<div class="th rating">Rating</div>'
            '<div class="th tags">Tags</div>'
            '<div class="th summary">Summary</div>\n'
            f'<div class="td index">{match_index}</div>'
            f'<div class="td hits">{hit_count}</div>'
            f'<div class="td teaseId"><a href="{url_of_tease}">{formatted_tease_id}</a></div>'
            f'<div class="td authorId">{formatted_author_link}</div>'
            f'<div class="td type">{formatted_tease_type}</div>'
            f'<div class="td rating">{formatted_tease_rating}</div>'
            f'<div class="td summary">{formatted_summary if formatted_summary else "None"}</div>'
            f'<div class="td title"><a class="toList" href="#list{tease_id}">{totm_css_class_open}{deleted_text}{formatted_tease_title}{totm_css_class_close}</a></div>'
            f'<div class="td authorName">{author_gone_text}{formatted_author_name}</div>'
            f'<div class="td date">{formatted_tease_date}</div>'
            f'<div class="td tags">{formatted_tags}</div>\n'
            '</div>')

    @override
    def print_text_of_page(self, tease_match: TeaseMatch, page: TeasePage) -> None:
        if self._show_pagerefs:
            self._printer.writeln('<div class="th pageRef">Page</div>')
        formatted_text: str | None = self._try_highlight_page_text(page, tease_match, abbreviate_text=True)
        if formatted_text is None:
            if self._ellipsis_max_width:
                formatted_text = _ellipsify_and_escape_text_item(page.text, is_first_item=True, is_last_item=True, ellipsis_max_width=self._ellipsis_max_width)
            else:
                formatted_text = _escape_text(page.text)
            formatted_text = _convert_lines_to_paragraphs(formatted_text)
        self._printer.writeln(f'<div class="td text">{formatted_text}</div>')

    @override
    def print_all_text_of_list_of_teases(self, list_of_tease_matches: Iterable[TeaseMatch]) -> None:
        tease_match: TeaseMatch
        for tease_match in list_of_tease_matches:
            self.print_summary_of_tease(tease_match)
            self.print_all_text_of_tease(tease_match, include_header_and_footer=True)

    @override
    def print_matching_text_of_list_of_teases(self, list_of_tease_matches: Iterable[TeaseMatch]) -> None:
        tease_match: TeaseMatch
        for tease_match in list_of_tease_matches:
            self.print_summary_of_tease(tease_match)
            self.print_matching_text_of_tease(tease_match, include_header_and_footer=True)

    def _print_oneline_of_tease(self, tease_match: TeaseMatch) -> None:
        match_index: str = str(tease_match.index_of_match) if tease_match.index_of_match else '-'
        hit_count: int = tease_match.get_match_count()
        tease_id: int = tease_match.tease.get_tease_id()
        author_id: int = tease_match.tease.author.author_id
        url_of_tease: str = get_url_of_tease(tease_id)
        url_of_author: str = get_url_of_author(author_id)
        formatted_tease_id: str = self._highlight_metadata(tease_match, Tease.get_tease_id)
        formatted_tease_type: str = self._highlight_metadata(tease_match, Tease.get_type)
        formatted_tease_rating: str = self._highlight_metadata(tease_match, Tease.get_rating_value)
        formatted_tease_date: str = self._highlight_metadata(tease_match, Tease.get_date)
        formatted_tease_title: str = self._highlight_metadata(tease_match, Tease.get_title)
        formatted_author_text: str = 'unknown'
        if tease_match.tease.author.has_author:
            formatted_author_name: str = self._highlight_metadata(tease_match, Tease.get_author_name)
            formatted_author_text = f'<a href="{url_of_author}">{formatted_author_name}</a>'
        totm_css_class: str | None = _MAP_OF_TOTM_STATUS_TO_CSS_CLASS.get(tease_match.tease.get_totm_status())
        totm_css_class_open: str = f'<div class="{totm_css_class}">' if totm_css_class else ''
        totm_css_class_close: str = '</div>' if totm_css_class else ''
        deleted_text: str = '[<span class="deleted">DELETED</span>] ' if tease_match.tease.is_deleted() else ''
        author_gone_text: str = '[<span class="authorGone">GONE</span>] ' if tease_match.tease.author.has_gone else ''
        self._printer.writeln(
            f'<div class="td index">{match_index}</div>'
            f'<div class="td hits">{hit_count}</div>'
            f'<div class="td teaseId"><a href="{url_of_tease}">{formatted_tease_id}</a></div>'
            f'<div class="td type">{formatted_tease_type}</div>'
            f'<div class="td rating">{formatted_tease_rating}</div>'
            f'<div class="td date">{formatted_tease_date}</div>'
            f'<div class="td title"><a id="list{tease_id}" class="toSummary" href="#summary{tease_id}">{totm_css_class_open}{deleted_text}{formatted_tease_title}{totm_css_class_close}</a></div>'
            f'<div class="td author">{author_gone_text}{formatted_author_text}</div>')

    @override
    def print_all_text_of_tease(self, tease_match: TeaseMatch, *, include_header_and_footer: bool) -> None:
        index: int
        page: TeasePage | None = None
        for index, page in enumerate(tease_match.tease.get_list_of_pages()):
            if not index and include_header_and_footer:
                self._printer.writeln('<text-table>')
                if self._show_pagerefs:
                    self._printer.writeln('<div class="th pageRef">Page</div>')
                self._printer.writeln('<div class="th text">Text</div>')
            if self._show_pagerefs:
                self._printer.writeln(f'<div class="td pageRef">{page.page_ref}</div>')
            formatted_text: str | None = self._try_highlight_page_text(page, tease_match, abbreviate_text=False)
            if formatted_text is None:
                formatted_text = _escape_text(page.text)
                formatted_text = _convert_lines_to_paragraphs(formatted_text)
            self._printer.writeln(f'<div class="td text">{formatted_text}</div>')
        if page and include_header_and_footer:
            self._printer.writeln('</text-table>')

    @override
    def print_matching_text_of_tease(self, tease_match: TeaseMatch, *, include_header_and_footer: bool) -> None:
        is_first_match: bool = True
        page: TeasePage | None = None
        for page in tease_match.tease.get_list_of_pages():
            formatted_text: str | None = self._try_highlight_page_text(page, tease_match, abbreviate_text=True)
            if formatted_text is not None:
                if is_first_match:
                    is_first_match = False
                    if include_header_and_footer:
                        self._printer.writeln('<text-table>')
                    if self._show_pagerefs:
                        self._printer.writeln('<div class="th pageRef">Page</div>')
                    self._printer.writeln('<div class="th text">Matching text</div>')
                if self._show_pagerefs:
                    self._printer.writeln(f'<div class="td pageRef">{page.page_ref}</div>')
                self._printer.writeln(f'<div class="td text">{formatted_text}</div>')
        if not is_first_match and include_header_and_footer:
            self._printer.writeln('</text-table>')

    def _highlight_metadata(self, tease_match: TeaseMatch, tease_property: TeaseProperty) -> str:
        field_value: str = tease_match.tease.get_text_of_property(tease_property)
        formatted_value: str = self._highlight_text(field_value, get_list_of_metadata_indices(tease_property, tease_match.list_of_field_matches), abbreviate_text=False)
        return formatted_value

    def _highlight_metadata_string_list(self, tease_match: TeaseMatch, tease_property: TeaseStrListProperty, *, include_matching_only: bool) -> list[str]:
        list_of_formatted_text: list[str] = []

        index_of_block: int
        text_block: str
        for index_of_block, text_block in enumerate(tease_property(tease_match.tease)):
            list_of_indices: Iterable[IFieldMatch.Indices] = get_list_of_indexed_metadata_indices(tease_property, index_of_block, tease_match.list_of_field_matches)
            formatted_text: str | None = None
            if list_of_indices:
                formatted_text = self._highlight_text(text_block, list_of_indices, abbreviate_text=include_matching_only and bool(self._ellipsis_max_width))
            elif not include_matching_only:
                formatted_text = _escape_text(text_block)
                formatted_text = _convert_lines_to_paragraphs(formatted_text)

            if formatted_text is not None:
                list_of_formatted_text.append(formatted_text)

        return list_of_formatted_text

    def _highlight_text(self, text: str, list_of_indices: Iterable[IFieldMatch.Indices], *, abbreviate_text: bool) -> str:
        formatted_text = ''

        def on_normal_text(text: str, *, is_first_item: bool, is_last_item: bool) -> None:
            nonlocal formatted_text
            if  abbreviate_text and self._ellipsis_max_width:
                formatted_text += _ellipsify_and_escape_text_item(text, is_first_item=is_first_item, is_last_item=is_last_item, ellipsis_max_width=self._ellipsis_max_width)
            else:
                formatted_text += _escape_text(text)

        def on_matched_text(text: str, *, is_first_item: bool, is_last_item: bool) -> None: # pylint: disable=W0613:unused-argument # noqa: ARG001 Unused function argument
            nonlocal formatted_text
            if self._use_highlighting:
                iterate_through_lines(text, on_highlight_text, on_end_of_line_text)
            else:
                formatted_text += _escape_text(text)

        def on_highlight_text(text: str) -> None:
            nonlocal formatted_text
            formatted_text += '<span class="matchingText">'
            formatted_text += _escape_text(text)
            formatted_text += '</span>'

        def on_end_of_line_text(text: str) -> None:
            nonlocal formatted_text
            formatted_text += text

        iterate_through_indices(text, list_of_indices, on_normal_text, on_matched_text)

        return _convert_lines_to_paragraphs(formatted_text)

    def _try_highlight_page_text(self, page: TeasePage, tease_match: TeaseMatch, *, abbreviate_text: bool) -> str | None:
        list_of_indices: Iterable[IFieldMatch.Indices] = get_matching_indices_for_page(page, tease_match.list_of_field_matches)
        if list_of_indices:
            return self._highlight_text(page.text, list_of_indices, abbreviate_text=abbreviate_text and bool(self._ellipsis_max_width))
        return None

def _ellipsify_and_escape_text_item(text: str, *, is_first_item: bool, is_last_item: bool, ellipsis_max_width: int) -> str:
    formatted_text: str = ''

    def on_text(text: str) -> None:
        nonlocal formatted_text
        formatted_text += _escape_text(text)

    def on_ellipsis() -> None:
        nonlocal formatted_text
        formatted_text += '<span class="ellipsis">&hellip;</span>'

    ellipsify_text(text, ellipsis_max_width, EllipsisLocation.from_position(is_first_item=is_first_item, is_last_item=is_last_item), on_text, on_ellipsis)

    return formatted_text

def _escape_text(text: str) -> str:
    return text.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')

def _convert_lines_to_paragraphs(text: str) -> str:
    paragraph_text: str = ''
    line: str
    for line in text.split('\n'):
        paragraph_text += f'<div>{line}</div>'
    return paragraph_text
