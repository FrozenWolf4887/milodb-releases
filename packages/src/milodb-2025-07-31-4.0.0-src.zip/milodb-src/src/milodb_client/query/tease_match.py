# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from collections.abc import Sequence
from milodb_client.database.tease import Tease
from milodb_client.query.field_match import IFieldMatch

class TeaseMatch:
    def __init__(self, index_of_match: int | None, tease: Tease, list_of_field_matches: Sequence[IFieldMatch]) -> None:
        self._index_of_match: int | None = index_of_match
        self._tease: Tease = tease
        self._list_of_field_matches: Sequence[IFieldMatch] = list_of_field_matches

    @property
    def index_of_match(self) -> int | None:
        return self._index_of_match

    @property
    def tease(self) -> Tease:
        return self._tease

    @property
    def list_of_field_matches(self) -> Sequence[IFieldMatch]:
        return self._list_of_field_matches

    def get_match_count(self) -> int:
        return sum(len(field_match.list_of_indices) for field_match in self._list_of_field_matches)
