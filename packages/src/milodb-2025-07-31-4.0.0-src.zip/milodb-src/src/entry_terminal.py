#!/usr/bin/env python3
# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/

import sys
if sys.version_info < (3, 12):
    print("Python version 3.12 or greater required")
    print("Actual version is " + sys.version)
    sys.exit(1)

# pylint: disable=wrong-import-position
from collections.abc import Sequence
from typing import NoReturn, TYPE_CHECKING
import colorama
from milodb_client.startup.startup import StartupResult, startup
from milodb_client.view.terminal.main_terminal import MainTerminal
from milodb_client.view.terminal.terminal_log_display import TerminalLogDisplay
from milodb_common.output.print.stdout_printer import StdoutPrinter
if TYPE_CHECKING:
    from milodb_client.startup.command_line import CommandLine
    from milodb_client.startup.shutdown_action import IShutdownAction
    from milodb_client.view.i_log_display import ILogDisplay
# pylint: enable=wrong-import-position

def _main(list_of_args: Sequence[str]) -> NoReturn:
    colorama.init(strip=False)
    exit_code: int = 0

    log_display: ILogDisplay
    with TerminalLogDisplay() as log_display:
        startup_result: StartupResult
        command_line: CommandLine | None
        startup_result, command_line = startup(list_of_args, log_display)
        if startup_result.shutdown_action:
            exit_code = startup_result.shutdown_action.perform_action(log_display)
        else:
            exit_code = startup_result.exit_code

    if startup_result.run_main_application:
        main_terminal: MainTerminal = MainTerminal(StdoutPrinter(), no_load=command_line.no_load if command_line else False)
        shutdown_action: IShutdownAction | None = main_terminal.run(autoexec=command_line.autoexec if command_line else False)
        if shutdown_action:
            exit_code = shutdown_action.perform_action(log_display)

    sys.exit(exit_code)

if __name__ == "__main__":
    _main(sys.argv[1:])
