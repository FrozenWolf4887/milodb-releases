#!/usr/bin/env python3
# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/

import sys
if sys.version_info < (3, 12):
    print("Python version 3.12 or greater required")
    print("Actual version is " + sys.version)
    sys.exit(1)

# pylint: disable=wrong-import-position
import contextlib
from pathlib import Path
from typing import NoReturn
from unittest import TestCase, TestLoader, TestResult, TestSuite
# pylint: enable=wrong-import-position

LIST_OF_TEST_PACKAGES: tuple[str, ...] = ('milodb_admin_test', 'milodb_client_test', 'milodb_common_test')
THIS_DIRECTORY: Path = Path(__file__).parent

def _test_package(package_name: str, *, suppress_output: bool) -> bool:
    if not suppress_output:
        print(f"Testing '\x1b[33m{package_name}\x1b[0m'")

    test_suite: TestSuite = TestLoader().discover(start_dir=package_name, top_level_dir=str(THIS_DIRECTORY), pattern='test_*.py')
    test_result: TestResult = TestResult()
    test_suite.run(test_result)
    if test_result.wasSuccessful():
        if not suppress_output:
            print(f'\x1b[32mPASS\x1b[0m: {test_result.testsRun} tests ran successfully')
        return True

    failed_test: tuple[TestCase, str]
    for failed_test in test_result.errors + test_result.failures:
        test_case: TestCase = failed_test[0]
        test_failure_text: str = failed_test[1]
        if not suppress_output:
            print(80 * '=')
            print(f'\x1b[35;1m{test_case}\x1b[0m')
            print(80 * '-')
            print(test_failure_text, end='')
    if not suppress_output:
        print(80 * '-')
        print(f'\x1b[31;1mFAIL\x1b[0m: {test_result.testsRun} tests run of which {len(test_result.errors)} errored and {len(test_result.failures)} failed\n')

    return False

def run_all_tests(*, suppress_output: bool = False) -> bool:
    result: bool = True
    package_name: str
    for package_name in LIST_OF_TEST_PACKAGES:
        package_path: Path = THIS_DIRECTORY/package_name
        if Path(package_path).is_dir():
            if not _test_package(package_name, suppress_output=suppress_output):
                result = False
        elif not suppress_output:
            print(f"Skipping '\x1b[33m{package_name}\x1b[0m' (not available)")
    return result

def _is_debugger_active() -> bool:
    with contextlib.suppress(AttributeError):
        if sys.gettrace() is not None:
            return True
    with contextlib.suppress(AttributeError):
        if sys.monitoring.get_tool(sys.monitoring.DEBUGGER_ID) is not None:
            return True
    return False

def main() -> NoReturn:
    exit_code: int = 0
    if not run_all_tests() and not _is_debugger_active():
        exit_code = 1
    sys.exit(exit_code)

if __name__ == "__main__":
    main()
