#!/usr/bin/env python3
# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/

import sys
if sys.version_info < (3, 12):
    print("Python version 3.12 or greater required")
    print("Actual version is " + sys.version)
    sys.exit(1)

# pylint: disable=wrong-import-position
from milodb_systest.command_line import CommandLine
from milodb_systest.main import Main
# pylint: enable=wrong-import-position

def _run() -> int:
    command_line: CommandLine = CommandLine(sys.argv[1:])
    exit_code: int = 1

    if command_line.is_help_requested():
        print(CommandLine.get_syntax_text())
        exit_code = 0
    elif command_line.is_valid():
        was_successful: bool = Main(command_line.get_options()).was_successful
        exit_code = 0 if was_successful else 1
    else:
        print(f'Error: {command_line.get_error_message()}')
        exit_code = 1

    return exit_code

if __name__ == "__main__":
    sys.exit(_run())
