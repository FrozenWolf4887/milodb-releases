# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from collections.abc import Sequence
from dataclasses import dataclass, field
from typing import override
from unittest.mock import Mock, call
from milodb_client.database.tease import Tease
from milodb_client.output.format.i_formatter import IFormatter
from milodb_client.output.format.i_formatter_factory import IFormatterCreator
from milodb_client.query.tease_match import TeaseMatch
from milodb_client.view.terminal.commands import show_command
from milodb_client_test.test import fake_teases
from milodb_client_test.test.matchers_teases import NonIndexedTeaseMatch
from milodb_common.output.print.i_printer import IPrinter
from milodb_common.parser.arg_token_stream import ArgTokenStream
from milodb_common.view.terminal.command_framework.i_command import CommandLoaderResult
from milodb_common_test.parser.error_messages import ErrorMessage
from milodb_common_test.test.strict_mock import InterfaceMock
from milodb_common_test.test.test_command_base import CommandTestBase

_DEFAULT_LIST_OF_TEASES: Sequence[Tease] = [
    fake_teases.TEASE_ID_1000_AUTHOR_ID_4567,
    fake_teases.TEASE_ID_1234_AUTHOR_ID_6431,
    fake_teases.TEASE_ID_5678_AUTHOR_ID_4567,
    fake_teases.TEASE_ID_2000_AUTHOR_ID_6431,
    fake_teases.TEASE_ID_8721_AUTHOR_ID_7213,
]

@dataclass
class _Args:
    list_of_teases: Sequence[Tease] = field(default_factory=lambda: list(_DEFAULT_LIST_OF_TEASES))
    list_of_tease_matches: Sequence[TeaseMatch] = field(default_factory=list)
    formatter_creator: InterfaceMock = field(default_factory=lambda: InterfaceMock(IFormatterCreator))
    normal_printer: InterfaceMock = field(default_factory=lambda: InterfaceMock(IPrinter))
    error_printer: InterfaceMock = field(default_factory=lambda: InterfaceMock(IPrinter))
    show_all: bool = False

class TestShowCommand(CommandTestBase):
    @override
    def setUp(self) -> None:
        self._args: _Args = _Args()
        return super().setUp()

    @override
    def load_command(self, arg_token_stream: ArgTokenStream) -> CommandLoaderResult:
        return show_command.load(
            arg_token_stream,
            self._args.list_of_teases,
            self._args.list_of_tease_matches,
            self._args.formatter_creator,
            self._args.normal_printer,
            self._args.error_printer,
            show_all = self._args.show_all,
        )

    def test_without_arguments_and_no_matches_outputs_error(self) -> None:
        for self._args.show_all in (True, False):
            with self.subTest(show_all=self._args.show_all):
                self._args.error_printer.writeln = Mock()
                self.command_load_and_execute([])
                self._args.error_printer.writeln.assert_called_once_with('No teases available to show')
                self.assert_next_text([])

    def test_without_arguments_and_some_matches_calls_formatter(self) -> None:
        for self._args.show_all in (True, False):
            with self.subTest(show_all=self._args.show_all):
                list_of_tease_matches: Sequence[TeaseMatch] = [
                    TeaseMatch(0, fake_teases.TEASE_ID_5678_AUTHOR_ID_4567, []),
                    TeaseMatch(1, fake_teases.TEASE_ID_8721_AUTHOR_ID_7213, []),
                ]
                self._args.list_of_tease_matches = list_of_tease_matches
                formatter: InterfaceMock = InterfaceMock(IFormatter)
                if self._args.show_all:
                    formatter.print_all_text_of_list_of_teases = Mock()
                else:
                    formatter.print_matching_text_of_list_of_teases = Mock()
                self._args.formatter_creator.create = Mock(return_value=formatter)
                self.command_load_and_execute([])
                self._args.formatter_creator.create.assert_called_once_with(self._args.normal_printer)
                if self._args.show_all:
                    formatter.print_all_text_of_list_of_teases.assert_called_once_with(list_of_tease_matches)
                else:
                    formatter.print_matching_text_of_list_of_teases.assert_called_once_with(list_of_tease_matches)
                self.assert_next_text([])

    def test_with_one_in_range_index_calls_formatter(self) -> None:
        for self._args.show_all in (True, False):
            with self.subTest(show_all=self._args.show_all):
                list_of_tease_matches: Sequence[TeaseMatch] = [
                    TeaseMatch(0, fake_teases.TEASE_ID_5678_AUTHOR_ID_4567, []),
                    TeaseMatch(1, fake_teases.TEASE_ID_8721_AUTHOR_ID_7213, []),
                ]
                self._args.list_of_tease_matches = list_of_tease_matches
                formatter: InterfaceMock = InterfaceMock(IFormatter)
                if self._args.show_all:
                    formatter.print_all_text_of_list_of_teases = Mock()
                else:
                    formatter.print_matching_text_of_list_of_teases = Mock()
                self._args.formatter_creator.create = Mock(return_value=formatter)
                self.command_load_and_execute(['1'])
                self._args.formatter_creator.create.assert_called_once_with(self._args.normal_printer)
                if self._args.show_all:
                    formatter.print_all_text_of_list_of_teases.assert_called_once_with([list_of_tease_matches[1]])
                else:
                    formatter.print_matching_text_of_list_of_teases.assert_called_once_with([list_of_tease_matches[1]])
                self.assert_next_text([])

    def test_with_one_out_of_range_index_outputs_error(self) -> None:
        for self._args.show_all in (True, False):
            with self.subTest(show_all=self._args.show_all):
                list_of_tease_matches: Sequence[TeaseMatch] = [
                    TeaseMatch(0, fake_teases.TEASE_ID_5678_AUTHOR_ID_4567, []),
                    TeaseMatch(1, fake_teases.TEASE_ID_8721_AUTHOR_ID_7213, []),
                ]
                self._args.list_of_tease_matches = list_of_tease_matches
                self._args.error_printer.writeln = Mock()
                self.command_load_and_execute(['2'])
                self._args.error_printer.writeln.assert_has_calls([call("Match index '2' is out of range"), call('No teases available to show')])
                self.assert_next_text([])

    def test_with_one_in_range_and_one_out_of_range_outputs_error(self) -> None:
        for self._args.show_all in (True, False):
            with self.subTest(show_all=self._args.show_all):
                list_of_tease_matches: Sequence[TeaseMatch] = [
                    TeaseMatch(0, fake_teases.TEASE_ID_5678_AUTHOR_ID_4567, []),
                    TeaseMatch(1, fake_teases.TEASE_ID_8721_AUTHOR_ID_7213, []),
                ]
                self._args.list_of_tease_matches = list_of_tease_matches
                self._args.error_printer.writeln = Mock()
                self.command_load_and_execute(['0', '2'])
                self._args.error_printer.writeln.assert_has_calls([call("Match index '2' is out of range"), call('No teases available to show')])
                self.assert_next_text([])

    def test_with_one_existing_teaseid_in_matches_calls_formatter(self) -> None:
        for self._args.show_all in (True, False):
            with self.subTest(show_all=self._args.show_all):
                list_of_tease_matches: Sequence[TeaseMatch] = [
                    TeaseMatch(0, fake_teases.TEASE_ID_5678_AUTHOR_ID_4567, []),
                    TeaseMatch(1, fake_teases.TEASE_ID_8721_AUTHOR_ID_7213, []),
                ]
                self._args.list_of_tease_matches = list_of_tease_matches
                formatter: InterfaceMock = InterfaceMock(IFormatter)
                if self._args.show_all:
                    formatter.print_all_text_of_list_of_teases = Mock()
                else:
                    formatter.print_matching_text_of_list_of_teases = Mock()
                self._args.formatter_creator.create = Mock(return_value=formatter)
                self.command_load_and_execute(['#8721'])
                self._args.formatter_creator.create.assert_called_once_with(self._args.normal_printer)
                if self._args.show_all:
                    formatter.print_all_text_of_list_of_teases.assert_called_once_with([list_of_tease_matches[1]])
                else:
                    formatter.print_matching_text_of_list_of_teases.assert_called_once_with([list_of_tease_matches[1]])
                self.assert_next_text([])

    def test_with_one_existing_teaseid_in_database_calls_formatter(self) -> None:
        for self._args.show_all in (True, False):
            with self.subTest(show_all=self._args.show_all):
                list_of_tease_matches: Sequence[TeaseMatch] = [
                    TeaseMatch(0, fake_teases.TEASE_ID_5678_AUTHOR_ID_4567, []),
                    TeaseMatch(1, fake_teases.TEASE_ID_8721_AUTHOR_ID_7213, []),
                ]
                self._args.list_of_tease_matches = list_of_tease_matches
                formatter: InterfaceMock = InterfaceMock(IFormatter)
                if self._args.show_all:
                    formatter.print_all_text_of_list_of_teases = Mock()
                else:
                    formatter.print_matching_text_of_list_of_teases = Mock()
                self._args.formatter_creator.create = Mock(return_value=formatter)
                self.command_load_and_execute(['#2000'])
                self._args.formatter_creator.create.assert_called_once_with(self._args.normal_printer)
                if self._args.show_all:
                    formatter.print_all_text_of_list_of_teases.assert_called_once_with([NonIndexedTeaseMatch(fake_teases.TEASE_ID_2000_AUTHOR_ID_6431)])
                else:
                    formatter.print_matching_text_of_list_of_teases.assert_called_once_with([NonIndexedTeaseMatch(fake_teases.TEASE_ID_2000_AUTHOR_ID_6431)])
                self.assert_next_text([])

    def test_with_one_non_existing_teaseid_outputs_error(self) -> None:
        for self._args.show_all in (True, False):
            with self.subTest(show_all=self._args.show_all):
                self._args.error_printer.writeln = Mock()
                self.command_load_and_execute(['#1235'])
                self._args.error_printer.writeln.assert_has_calls([call("Unable to find tease for tease id '1235'"), call('No teases available to show')])
                self.assert_next_text([])

    def test_with_one_teaseid_in_matches_and_one_in_database_calls_formatter(self) -> None:
        for self._args.show_all in (True, False):
            with self.subTest(show_all=self._args.show_all):
                list_of_tease_matches: Sequence[TeaseMatch] = [
                    TeaseMatch(0, fake_teases.TEASE_ID_5678_AUTHOR_ID_4567, []),
                    TeaseMatch(1, fake_teases.TEASE_ID_1234_AUTHOR_ID_6431, []),
                ]
                self._args.list_of_tease_matches = list_of_tease_matches
                formatter: InterfaceMock = InterfaceMock(IFormatter)
                if self._args.show_all:
                    formatter.print_all_text_of_list_of_teases = Mock()
                else:
                    formatter.print_matching_text_of_list_of_teases = Mock()
                self._args.formatter_creator.create = Mock(return_value=formatter)
                self.command_load_and_execute(['#2000', '#1234'])
                self._args.formatter_creator.create.assert_called_once_with(self._args.normal_printer)
                if self._args.show_all:
                    formatter.print_all_text_of_list_of_teases.assert_called_once_with([NonIndexedTeaseMatch(fake_teases.TEASE_ID_2000_AUTHOR_ID_6431), list_of_tease_matches[1]])
                else:
                    formatter.print_matching_text_of_list_of_teases.assert_called_once_with([NonIndexedTeaseMatch(fake_teases.TEASE_ID_2000_AUTHOR_ID_6431), list_of_tease_matches[1]])
                self.assert_next_text([])

    def test_with_one_authorid_from_matches_calls_formatter(self) -> None:
        for self._args.show_all in (True, False):
            with self.subTest(show_all=self._args.show_all):
                list_of_tease_matches: Sequence[TeaseMatch] = [
                    TeaseMatch(0, fake_teases.TEASE_ID_1234_AUTHOR_ID_6431, []),
                    TeaseMatch(1, fake_teases.TEASE_ID_1000_AUTHOR_ID_4567, []),
                    TeaseMatch(2, fake_teases.TEASE_ID_8721_AUTHOR_ID_7213, []),
                    TeaseMatch(3, fake_teases.TEASE_ID_5678_AUTHOR_ID_4567, []),
                ]
                self._args.list_of_tease_matches = list_of_tease_matches
                formatter: InterfaceMock = InterfaceMock(IFormatter)
                if self._args.show_all:
                    formatter.print_all_text_of_list_of_teases = Mock()
                else:
                    formatter.print_matching_text_of_list_of_teases = Mock()
                self._args.formatter_creator.create = Mock(return_value=formatter)
                self.command_load_and_execute(['@4567'])
                self._args.formatter_creator.create.assert_called_once_with(self._args.normal_printer)
                if self._args.show_all:
                    formatter.print_all_text_of_list_of_teases.assert_called_once_with([list_of_tease_matches[1], list_of_tease_matches[3]])
                else:
                    formatter.print_matching_text_of_list_of_teases.assert_called_once_with([list_of_tease_matches[1], list_of_tease_matches[3]])
                self.assert_next_text([])

    def test_with_one_existing_authorid_in_database_calls_formatter(self) -> None:
        for self._args.show_all in (True, False):
            with self.subTest(show_all=self._args.show_all):
                list_of_tease_matches: Sequence[TeaseMatch] = [
                    TeaseMatch(0, fake_teases.TEASE_ID_1234_AUTHOR_ID_6431, []),
                    TeaseMatch(1, fake_teases.TEASE_ID_1000_AUTHOR_ID_4567, []),
                ]
                self._args.list_of_tease_matches = list_of_tease_matches
                formatter: InterfaceMock = InterfaceMock(IFormatter)
                if self._args.show_all:
                    formatter.print_all_text_of_list_of_teases = Mock()
                else:
                    formatter.print_matching_text_of_list_of_teases = Mock()
                self._args.formatter_creator.create = Mock(return_value=formatter)
                self.command_load_and_execute(['@7213'])
                self._args.formatter_creator.create.assert_called_once_with(self._args.normal_printer)
                if self._args.show_all:
                    formatter.print_all_text_of_list_of_teases.assert_called_once_with([NonIndexedTeaseMatch(fake_teases.TEASE_ID_8721_AUTHOR_ID_7213)])
                else:
                    formatter.print_matching_text_of_list_of_teases.assert_called_once_with([NonIndexedTeaseMatch(fake_teases.TEASE_ID_8721_AUTHOR_ID_7213)])
                self.assert_next_text([])

    def test_with_one_existing_authorid_in_both_matches_and_database_calls_formatter(self) -> None:
        for self._args.show_all in (True, False):
            with self.subTest(show_all=self._args.show_all):
                list_of_tease_matches: Sequence[TeaseMatch] = [
                    TeaseMatch(0, fake_teases.TEASE_ID_1234_AUTHOR_ID_6431, []),
                    TeaseMatch(1, fake_teases.TEASE_ID_1000_AUTHOR_ID_4567, []),
                ]
                self._args.list_of_tease_matches = list_of_tease_matches
                formatter: InterfaceMock = InterfaceMock(IFormatter)
                if self._args.show_all:
                    formatter.print_all_text_of_list_of_teases = Mock()
                else:
                    formatter.print_matching_text_of_list_of_teases = Mock()
                self._args.formatter_creator.create = Mock(return_value=formatter)
                self.command_load_and_execute(['@6431'])
                self._args.formatter_creator.create.assert_called_once_with(self._args.normal_printer)
                if self._args.show_all:
                    formatter.print_all_text_of_list_of_teases.assert_called_once_with([list_of_tease_matches[0], NonIndexedTeaseMatch(fake_teases.TEASE_ID_2000_AUTHOR_ID_6431)])
                else:
                    formatter.print_matching_text_of_list_of_teases.assert_called_once_with([list_of_tease_matches[0], NonIndexedTeaseMatch(fake_teases.TEASE_ID_2000_AUTHOR_ID_6431)])
                self.assert_next_text([])

    def test_with_one_non_existing_authorid_outputs_error(self) -> None:
        for self._args.show_all in (True, False):
            with self.subTest(show_all=self._args.show_all):
                self._args.error_printer = Mock()
                self.command_load_and_execute(['@8312'])
                self._args.error_printer.writeln.assert_has_calls([call("Unable to find author id '8312'"), call('No teases available to show')])
                self.assert_next_text([])

    def test_with_mixed_refids_calls_formatter(self) -> None:
        for self._args.show_all in (True, False):
            with self.subTest(show_all=self._args.show_all):
                list_of_tease_matches: Sequence[TeaseMatch] = [
                    TeaseMatch(0, fake_teases.TEASE_ID_1234_AUTHOR_ID_6431, []),
                    TeaseMatch(1, fake_teases.TEASE_ID_1000_AUTHOR_ID_4567, []),
                    TeaseMatch(2, fake_teases.TEASE_ID_8721_AUTHOR_ID_7213, []),
                    TeaseMatch(3, fake_teases.TEASE_ID_5678_AUTHOR_ID_4567, []),
                ]
                self._args.list_of_tease_matches = list_of_tease_matches
                formatter: InterfaceMock = InterfaceMock(IFormatter)
                if self._args.show_all:
                    formatter.print_all_text_of_list_of_teases = Mock()
                else:
                    formatter.print_matching_text_of_list_of_teases = Mock()
                self._args.formatter_creator.create = Mock(return_value=formatter)
                self.command_load_and_execute(['2', '#2000', '#5678', '1', '@6431'])
                self._args.formatter_creator.create.assert_called_once_with(self._args.normal_printer)
                if self._args.show_all:
                    formatter.print_all_text_of_list_of_teases.assert_called_once_with(
                        [list_of_tease_matches[2],
                        NonIndexedTeaseMatch(fake_teases.TEASE_ID_2000_AUTHOR_ID_6431),
                        list_of_tease_matches[3],
                        list_of_tease_matches[1],
                        list_of_tease_matches[0],
                        NonIndexedTeaseMatch(fake_teases.TEASE_ID_2000_AUTHOR_ID_6431)])
                else:
                    formatter.print_matching_text_of_list_of_teases.assert_called_once_with(
                        [list_of_tease_matches[2],
                        NonIndexedTeaseMatch(fake_teases.TEASE_ID_2000_AUTHOR_ID_6431),
                        list_of_tease_matches[3],
                        list_of_tease_matches[1],
                        list_of_tease_matches[0],
                        NonIndexedTeaseMatch(fake_teases.TEASE_ID_2000_AUTHOR_ID_6431)])
                self.assert_next_text([])

    def test_with_signed_index_returns_failure(self) -> None:
        for self._args.show_all in (True, False):
            with self.subTest(show_all=self._args.show_all):
                self.command_load(['1234', '-5678', '9012'])
                self.assert_argument_error(2, ErrorMessage.INVALID_EXPECTING_REFID, [])

    def test_with_signed_teaseid_returns_failure(self) -> None:
        for self._args.show_all in (True, False):
            with self.subTest(show_all=self._args.show_all):
                self.command_load(['#1234', '#-5678', '#9012'])
                self.assert_argument_error(2, ErrorMessage.INVALID_EXPECTING_TEASEID, [])

    def test_with_signed_authorid_returns_failure(self) -> None:
        for self._args.show_all in (True, False):
            with self.subTest(show_all=self._args.show_all):
                self.command_load(['@1234', '@-5678', '@9012'])
                self.assert_argument_error(2, ErrorMessage.INVALID_EXPECTING_AUTHORID, [])

    def test_with_non_refid_returns_failure(self) -> None:
        for self._args.show_all in (True, False):
            with self.subTest(show_all=self._args.show_all):
                self.command_load(['mango', '5678', '9012'])
                self.assert_argument_error(1, ErrorMessage.INVALID_EXPECTING_REFID, [])
