# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from abc import ABC, abstractmethod

class IHelpInfo(ABC):
    @abstractmethod
    def get_one_line_summary(self) -> str:
        pass

    @abstractmethod
    def get_detailed_summary(self) -> str:
        pass
