# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import os
import sys
from prompt_toolkit import PromptSession
from prompt_toolkit.history import InMemoryHistory
from prompt_toolkit.shortcuts import CompleteStyle
from milodb_common.output.print.i_printer import IPrinter
from milodb_common.variables.i_user_variables import IUserVariables
from milodb_common.view.terminal.command_framework.i_command_constructor import ICommandConstructor
from milodb_common.view.terminal.command_framework.quit_flag import QuitFlag
from milodb_common.view.terminal.input.default_input import IDefaultInputText
from milodb_common.view.terminal.input.input_suggester import InputSuggester
from milodb_common.view.terminal.input.process import process_user_input
from milodb_common.view.terminal.input.tab_completer import TabCompleter

def run_interactive_prompt(command_constructor: ICommandConstructor, user_variables: IUserVariables, default_input_text: IDefaultInputText, quit_flag: QuitFlag, normal_printer: IPrinter, error_printer: IPrinter) -> None:
    default_input_text.clear()

    normal_printer.writeln('Enter command (or "help"):')

    if _is_dumb_terminal():
        _run_dumb_prompt(command_constructor, user_variables, default_input_text, quit_flag, normal_printer, error_printer)
    else:
        _run_smart_prompt(command_constructor, user_variables, default_input_text, quit_flag, normal_printer, error_printer)

def _is_dumb_terminal() -> bool:
    return not os.isatty(sys.stdin.fileno())

def _run_dumb_prompt(command_constructor: ICommandConstructor, user_variables: IUserVariables, default_input_text: IDefaultInputText, quit_flag: QuitFlag, normal_printer: IPrinter, error_printer: IPrinter) -> None:
    while not quit_flag:
        try:
            user_input: str = input('> ')
        except EOFError:
            quit_flag.set()
        else:
            default_input_text.clear()
            process_user_input(user_input, command_constructor, user_variables, quit_flag, normal_printer, error_printer)

def _run_smart_prompt(command_constructor: ICommandConstructor, user_variables: IUserVariables, default_input_text: IDefaultInputText, quit_flag: QuitFlag, normal_printer: IPrinter, error_printer: IPrinter) -> None:
    history: InMemoryHistory = InMemoryHistory()
    input_suggester: InputSuggester = InputSuggester(command_constructor, user_variables)
    tab_completer: TabCompleter = TabCompleter(input_suggester)

    prompt_session: PromptSession[str] = PromptSession(history=history, completer=tab_completer, complete_style=CompleteStyle.READLINE_LIKE)
    while not quit_flag:
        user_input: str = prompt_session.prompt('> ', default=default_input_text.get())
        default_input_text.clear()
        process_user_input(user_input, command_constructor, user_variables, quit_flag, normal_printer, error_printer)
