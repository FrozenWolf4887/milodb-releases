# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from collections.abc import Iterable
from typing import override
from prompt_toolkit.completion import CompleteEvent, Completer, Completion
from prompt_toolkit.document import Document
from milodb_common.view.terminal.input.input_suggester import InputSuggester

class TabCompleter(Completer):
    def __init__(self, input_suggester: InputSuggester) -> None:
        self._input_suggester: InputSuggester = input_suggester

    @override
    def get_completions(self, document: Document, complete_event: CompleteEvent) -> Iterable[Completion]:
        return self._input_suggester.get_possible_completions(document.text, document.cursor_position_col)
