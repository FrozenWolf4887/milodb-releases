# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from collections.abc import Callable
from typing import override
from milodb_common.output.print.debug_printer import DebugPrinter
from milodb_common.parser.arg_token_stream import ArgTokenStream
from milodb_common.parser.candidate_text import CandidateText
from milodb_common.view.terminal.command_framework.i_command import CommandLoaderError, CommandLoaderResult
from milodb_common.view.terminal.command_framework.i_command_constructor import ICommandConstructor
from milodb_common.view.terminal.command_framework.i_help_info import IHelpInfo

def load(arg_token_stream: ArgTokenStream, command_constructor: ICommandConstructor, debug_printer: DebugPrinter) -> CommandLoaderResult:
    construct_result: ICommandConstructor.ConstructResult = command_constructor.try_construct(arg_token_stream)
    if isinstance(construct_result, ICommandConstructor.SuccessfulResult):
        return CommandLoaderResult(
            lambda: execute(construct_result.command, debug_printer),
            construct_result.list_of_candidate_text)
    if isinstance(construct_result, ICommandConstructor.EmptyInputResult):
        msg = 'Expecting a following command'
        raise CommandLoaderError(msg, None, CandidateText.space_delimited_list(construct_result.list_of_command_names))
    raise ICommandConstructor.DelegateError(construct_result)

def execute(delegate_command: Callable[[], None], debug_printer: DebugPrinter) -> None:
    debug_printer.enabled = True
    delegate_command()
    debug_printer.enabled = False

class Help(IHelpInfo):
    @override
    def get_one_line_summary(self) -> str:
        return "Enables debug output for the subsequent command"

    @override
    def get_detailed_summary(self) -> str:
        return (
            "Arguments: <subsequent command...>\n"
            "If the subsequent command has additional debug output, it will be displayed.\n"
            "Example:\r"
            "  \tEnable debug output for the 'open' command\r"
            "  > \tdebug open 1\n"
            "Example:\r"
            "  \tEnable debug output for the 'browse' command\r"
            "  > \tdebug browse\n"
            "See also:\r"
            "  \topen, openauthor, browse, browseall\n"
        )
