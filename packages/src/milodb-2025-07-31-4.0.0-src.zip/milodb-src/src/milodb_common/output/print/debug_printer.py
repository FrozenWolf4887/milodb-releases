# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from typing import override
from milodb_common.output.print.i_printer import IPrinter
from milodb_common.output.print.redirectable_printer import RedirectablePrinter

class DebugPrinter(RedirectablePrinter):
    def __init__(self, target_printer: IPrinter) -> None:
        super().__init__(target_printer)
        self._is_debug_enabled: bool = False

    @override
    def write(self, text: str) -> None:
        if self._is_debug_enabled:
            self._target_printer.write(text)

    @override
    def writeln(self, text: str | None = None) -> None:
        if self._is_debug_enabled:
            self._target_printer.writeln(text)

    @property
    @override
    def is_on_new_line(self) -> bool:
        return self._target_printer.is_on_new_line

    @property
    def enabled(self) -> bool:
        return self._is_debug_enabled

    @enabled.setter
    def enabled(self, enable: bool) -> None:
        self._is_debug_enabled = enable
