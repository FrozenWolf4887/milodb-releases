# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from typing import NamedTuple

_ONE_HUNDRED_THOUSAND: int = 100_000
_TEN_THOUSAND: int = 10_000
_ONE_THOUSAND: int = 1_000

_SIZE_KB: int = _ONE_THOUSAND
_SIZE_MB: int = _SIZE_KB * _SIZE_KB
_SIZE_GB: int = _SIZE_KB * _SIZE_MB
_SIZE_TB: int = _SIZE_KB * _SIZE_GB
_SIZE_PB: int = _SIZE_KB * _SIZE_TB
_SIZE_EB: int = _SIZE_KB * _SIZE_PB

class UnitSizeText(NamedTuple):
    size_text: str
    unit_text: str

def unit_size(size_bytes: int) -> UnitSizeText:
    exabytes: int = size_bytes // _SIZE_EB
    petabytes: int = size_bytes // _SIZE_PB
    if exabytes > 0:
        return UnitSizeText(_kilo_str(petabytes), 'EB')
    terabytes: int = size_bytes // _SIZE_TB
    if petabytes > 0:
        return UnitSizeText(_kilo_str(terabytes), 'PB')
    gigabytes: int = size_bytes // _SIZE_GB
    if terabytes > 0:
        return UnitSizeText(_kilo_str(gigabytes), 'TB')
    megabytes: int = size_bytes // _SIZE_MB
    if gigabytes > 0:
        return UnitSizeText(_kilo_str(megabytes), 'GB')
    kilobytes: int = size_bytes // _SIZE_KB
    if megabytes > 0:
        return UnitSizeText(_kilo_str(kilobytes), 'MB')
    return UnitSizeText(_kilo_str(size_bytes), 'KB')

def _kilo_str(value: int) -> str:
    if value >= _ONE_HUNDRED_THOUSAND:
        return str((value + 500) // _ONE_THOUSAND)
    if value >= _TEN_THOUSAND:
        value += 50
        return f'{value // _ONE_THOUSAND}.{(value % _ONE_THOUSAND) // 100}'
    value += 9
    return f'{value // _ONE_THOUSAND}.{(value % _ONE_THOUSAND) // 10:02}'
