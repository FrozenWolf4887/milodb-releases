# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from dataclasses import dataclass

@dataclass
class StartEnd:
    start: int
    end: int

@dataclass
class Token:
    text: str
    token_number: int
    outer_indices: StartEnd
    inner_indices: StartEnd
    is_delimiter: bool
