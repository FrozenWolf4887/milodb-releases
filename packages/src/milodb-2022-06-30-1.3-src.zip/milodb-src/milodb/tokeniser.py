from dataclasses import dataclass
from typing import List, Union

@dataclass
class Token:
    text: str
    token_index: int
    start_character_index: int
    end_character_index: int

@dataclass
class SuccessfulTokenisationResult:
    list_of_tokens: List[Token]

@dataclass
class FailedTokenisationResult:
    cause_of_fault_text: str
    cause_of_fault_character_index: int

def tokenise(text: str) -> Union[SuccessfulTokenisationResult, FailedTokenisationResult]:
    return _Tokeniser(text).get_result()

class _Tokeniser:
    def __init__(self, text: str) -> None:
        self._text: str = text
        self._index: int = 0
        self._current_token_text: str = ""
        self._current_token_start_index: int = 0
        self._is_escaping: bool = False
        self._is_in_token: bool = False
        self._is_in_quoted_string: bool = False
        self._string_quote: str = ''
        self._expecting_delimiter: bool = False
        self._list_of_tokens: List[Token] = []
        self._result: Union[SuccessfulTokenisationResult, FailedTokenisationResult]

        try:
            self._process_all_characters()
            self._result = SuccessfulTokenisationResult(self._list_of_tokens)
        except _TokeniserError as ex:
            self._result = FailedTokenisationResult(ex.message, ex.index)

    def get_result(self) -> Union[SuccessfulTokenisationResult, FailedTokenisationResult]:
        return self._result

    def _process_all_characters(self) -> None:
        index: int
        for index in range(0, len(self._text)):
            self._index = index
            self._process_character(self._text[index])

        if self._is_escaping:
            raise(_TokeniserError('Trailing escape character at end of text', len(self._text)))

        if self._is_in_quoted_string:
            raise(_TokeniserError('String not terminated at end of text', len(self._text)))

        if self._current_token_text:
            self._append_token(self._current_token_text, self._current_token_start_index, len(self._text))

    def _process_character(self, c: str) -> None:
        if self._expecting_delimiter:
            if c not in [' ', '(', ')']:
                raise _TokeniserError('Expecting delimiter', self._index)
            self._expecting_delimiter = False

        if self._is_escaping:
            self._process_escaped_character(c)
        else:
            self._process_non_escaped_character(c)

    def _process_escaped_character(self, c: str) -> None:
        if c in ['"', "'"]:
            self._current_token_text += c
        else:
            self._current_token_text += '\\' + c
        self._is_escaping = False

    def _process_non_escaped_character(self, c: str) -> None:
        if c == '\\':
            self._is_escaping = True
        else:
            if self._is_in_quoted_string:
                self._process_character_in_string(c)
            else:
                self._process_character_out_of_string(c)

    def _process_character_in_string(self, c: str) -> None:
        if c == self._string_quote:
            self._is_in_quoted_string = False
            self._append_token(self._current_token_text, self._current_token_start_index, self._index)
            self._expecting_delimiter = True
        else:
            self._current_token_text += c

    def _process_character_out_of_string(self, c: str) -> None:
        if c in ['"', "'"]:
            self._is_in_quoted_string = True
            self._string_quote = c
            self._is_in_token = True
            self._current_token_start_index = self._index + 1
        else:
            if c in [' ', '(', ')']:
                if self._current_token_text:
                    self._append_token(self._current_token_text, self._current_token_start_index, self._index)
                if c in ['(', ')']:
                    self._append_token(c, self._index, self._index + 1)
            else:
                if not self._is_in_token:
                    self._is_in_token = True
                    self._current_token_start_index = self._index
                self._current_token_text += c

    def _append_token(self, text: str, start_index: int, end_index: int):
        token = Token(text, len(self._list_of_tokens), start_index, end_index)
        self._list_of_tokens.append(token)
        self._current_token_text = ""
        self._is_in_token = False

class _TokeniserError(Exception):
    def __init__(self, message: str, index: int):
        self.message: str = message
        self.index: int = index
