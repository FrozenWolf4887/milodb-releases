import milodb.query as query
from milodb.commands.parser import FailedCommandParseResult, parse, SuccessfulCommandParseResult
from milodb.commands.real_command_factory import RealCommandFactory
from milodb.commands.command import Command, CommandContext, CommandFactory
from milodb.commands.sort_keys import OrderedSortKey, default_list_of_active_sort_keys, list_of_available_sort_keys
from milodb.config import SystemConfig, UserConfig
from milodb.database import Database
from milodb.output.output_sink import OutputSink
from milodb.output.outputter import Outputter
from milodb.tokeniser import Token
from unittest import TestCase
from unittest.mock import Mock
from typing import List, Optional, Type, Union

class CommandTestBase(TestCase):
    def setUp(self):
        self.result: Union[SuccessfulCommandParseResult, FailedCommandParseResult]
        database = Mock(Database)
        command_factory: CommandFactory = RealCommandFactory()
        self.output_sink = Mock(OutputSink)
        self.user_config = UserConfig(self.output_sink)
        system_config = Mock(SystemConfig)
        list_of_tease_matches: Optional[List[query.TeaseMatch]] = None
        list_of_active_sort_keys: List[OrderedSortKey] = default_list_of_active_sort_keys.copy()
        self.mock_outputter = Mock(Outputter)
        list_of_outputters: List[Outputter] = [self.mock_outputter]
        self.context: CommandContext = CommandContext(
            False, database, command_factory,
            self.user_config, system_config,
            list_of_tease_matches,
            list_of_available_sort_keys, list_of_active_sort_keys,
            list_of_outputters, self.mock_outputter)
        self.list_of_tokens: List[Token] = []
        self.list_of_command_names: List[str] = self.context.command_factory.get_list_of_command_names()

    def parse_test(self, list_of_token_text: Optional[List[str]]) -> None:
        if list_of_token_text is None:
            self.list_of_tokens = []
            self.result = parse(None, self.context)
        elif len(list_of_token_text) == 0:
            self.list_of_tokens = []
            self.result = parse(self.list_of_tokens, self.context)
        else:
            self.list_of_tokens = self.create_fake_tokens(list_of_token_text)
            self.result = parse(self.list_of_tokens, self.context)

    def execute_test(self, list_of_token_text: Optional[List[str]]) -> None:
        self.parse_test(list_of_token_text)
        if isinstance(self.result, SuccessfulCommandParseResult):
            self.result.command.execute()
        else:
            self.fail("Parsing should have been successful but wasn't")

    def create_fake_tokens(self, list_of_token_text: List[str]) -> List[Token]:
        list_of_tokens = []
        token_index: int = 0
        token_start_character: int = 0
        for token_text in list_of_token_text:
            token_end_character: int = token_start_character + len(token_text)
            list_of_tokens.append(Token(token_text, token_index, token_start_character, token_end_character))
            token_start_character = token_end_character + 1
            token_index += 1
        return list_of_tokens

    def assert_successful(self, command_class: Type[Command]) -> None:
        if isinstance(self.result, SuccessfulCommandParseResult):
            self.assertIsInstance(self.result.command, command_class,
                'Incorrect class type returned from parsing')
        else:
            self.fail("Parsing should have been successful but wasn't")

    def assert_unsuccessful(self, command_class: Optional[Type[Command]], fault_token_index: Optional[int], fault_text: str, list_of_expected_text: Optional[List[str]]) -> None:
        if isinstance(self.result, FailedCommandParseResult):
            self.assertEquals(command_class, self.result.command_class)

            if fault_token_index is not None:
                self.assertEqual(self.list_of_tokens[fault_token_index], self.result.fault_token,
                    f'Unexpected fault token reported')
            else:
                self.assertEqual(None, self.result.fault_token,
                    f'Unexpected fault token reported')

            self.assertEqual(fault_text, self.result.fault_text,
                f"Expected error message of '{fault_text}' but got '{self.result.fault_text}'")

            if list_of_expected_text is not None:
                if self.result.list_of_expected_text is not None:
                    self.assert_lists_contain_same(list_of_expected_text, self.result.list_of_expected_text)
                else:
                    self.fail(f'List of expected text is missing when it should be {list_of_expected_text}')
            else:
                self.assertIsNone(self.result.list_of_expected_text,
                    'Got a list of expected next text when none was expected')
        else:
            self.fail("Tokenisation should have failed but was successful")

    def assert_lists_contain_same(self, list_expected: List[str], list_actual: List[str]):
        self.assertEqual(len(list_expected), len(list_actual),
            f'Two lists are of different lengths; expected {list_expected} but got {list_actual}')
        for expected in list_expected:
            if expected not in list_actual:
                self.fail(f"Expected to find '{expected}' in list but it is missing")
