from milodb.commands.argument_stream import ArgumentStream
from milodb.commands.command import Command, CommandContext
from milodb.commands.enums import OnOrOff
from typing import List, Optional

class EllipsisCommand(Command):
    def __init__(self, context: CommandContext) -> None:
        self._context = context
        self._new_ellipsis: Optional[OnOrOff] = None

    def load(self, argument_stream: ArgumentStream) -> Optional[List[str]]:
        if not argument_stream.is_empty():
            self._new_ellipsis = argument_stream.pop_enum(OnOrOff)
            argument_stream.fail_if_not_empty()
            return None
        else:
            return OnOrOff.lowercase_names()

    def execute(self) -> None:
        if self._new_ellipsis:
            self._context.user_config.is_ellipsis_enabled = self._new_ellipsis.value
            self._context.user_config.stream_writer.writeln(f"Changed ellipsis mode to '{self._new_ellipsis.name.lower()}'")
        else:
            self._context.user_config.stream_writer.writeln(f"Current ellipsis mode is '{OnOrOff(self._context.user_config.is_ellipsis_enabled).name.lower()}'")
            self._context.user_config.stream_writer.writeln(f"Available options are {OnOrOff.lowercase_names()}")

    @classmethod
    def get_one_line_summary(cls) -> str:
        return "Sets whether matching text paragraphs are abbreviated with an ellipsis"

    @classmethod
    def get_detailed_summary(cls, context: CommandContext) -> str:
        return (
            f"Arguments: [{'|'.join(OnOrOff.lowercase_names())}]\n"
            "Enables or disables the abbreviation for text in paragraph matches. Abbreviation"
            " is typically shown with the ellipsis character '\u2026'.\n"
            "When used without arguments, the current setting is shown.\n"
            "Example:\r"
            "  \tTurn off text abbreviation\r"
            "  > \tellipsis off\r"
            "Example:\r"
            "  \tShow the current setting\r"
            "  > \tellipsis\n"
            "See also:\r"
            "  \tshow, browse, format, highlight\n"
        )
