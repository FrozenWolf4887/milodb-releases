from milodb.commands.argument_stream import ArgumentStream
from milodb.commands.command import Command, CommandContext
from milodb.commands.command_support import sort_tease_matches
from milodb.commands.parse_results import LoadError
from milodb.commands.sort_keys import OrderedSortKey, SortKey
from milodb.tokeniser import Token
from typing import Dict, List, Optional

class SortCommand(Command):
    def __init__(self, context: CommandContext) -> None:
        self._context = context
        self._new_list_of_active_sort_keys: List[OrderedSortKey] = []

    def load(self, argument_stream: ArgumentStream) -> Optional[List[str]]:
        map_of_names_to_sort_keys: Dict[str, SortKey] = {}
        sort_key: SortKey
        for sort_key in self._context.list_of_available_sort_keys:
            map_of_names_to_sort_keys[sort_key.get_name()] = sort_key
            map_of_names_to_sort_keys['-' + sort_key.get_name()] = sort_key
        list_of_remaining_sort_keys: List[SortKey] = self._context.list_of_available_sort_keys.copy()

        while not argument_stream.is_empty():
            token: Token
            sort_key, token = argument_stream.pop_dict_value_and_token(map_of_names_to_sort_keys)
            if sort_key in list_of_remaining_sort_keys:
                list_of_remaining_sort_keys.remove(sort_key)
            else:
                raise LoadError('Duplicate sorting key', token, [ sort_key.get_name() for sort_key in list_of_remaining_sort_keys ])
            is_ascending: bool = token.text[0] != '-'
            self._new_list_of_active_sort_keys.append(OrderedSortKey(sort_key, is_ascending))

        if list_of_remaining_sort_keys:
            list_of_possible_next_text: List[str] = []
            for sort_key in list_of_remaining_sort_keys:
                list_of_possible_next_text.append(sort_key.get_name())
                list_of_possible_next_text.append('-' + sort_key.get_name())
            return list_of_possible_next_text
        else:
            return None

    def execute(self) -> None:
        if self._new_list_of_active_sort_keys:
            self._context.list_of_active_sort_keys = self._new_list_of_active_sort_keys
            self._context.user_config.stream_writer.writeln(f"Changed sorting keys to {[ ('' if sort_key.is_ascending() else '-') + sort_key.get_name() for sort_key in self._context.list_of_active_sort_keys ]}")
            sort_tease_matches(self._context)
        else:
            self._context.user_config.stream_writer.writeln(f"Current sorting keys are {[ ('' if sort_key.is_ascending() else '-') + sort_key.get_name() for sort_key in self._context.list_of_active_sort_keys ]}")
            self._context.user_config.stream_writer.writeln(f"Available keys are {sorted([ sort_key.get_name() for sort_key in self._context.list_of_available_sort_keys ])}")

    @classmethod
    def get_one_line_summary(cls) -> str:
        return "Sorts the output by specific fields"

    @classmethod
    def get_detailed_summary(cls, context: CommandContext) -> str:
        list_of_keys: List[str] = sorted([ sort_key.get_name() for sort_key in context.list_of_available_sort_keys ])
        return (
            "Arguments: [list of sort keys]\n"
            "Sets the sorting order for the display of teases. More than one key can be"
            " specified to determine secondary, tertiary, etc. ordering.\n"
            "Keys:\r"
            f"  \t{', '.join(list_of_keys)}\n"
            "Keys can be prefixed with '-' to indicate a descending order, otherwise the"
            " order defaults to ascending.\n"
            "When used without arguments, the current sorting keys are shown.\n"
            "Example:\r"
            "  \tSort by teaseId\r"
            "  > \tsort teaseId\r"
            "Example:\r"
            "  \tSort by rating (ascending) and date (descending)\r"
            "  > \tsort rating -date\n"
            "See also:\r"
            "  \tlist\n"
        )
