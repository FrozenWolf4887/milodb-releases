from abc import ABC, abstractmethod
from typing import Optional

class OutputSink(ABC):
    @abstractmethod
    def write(self, text: str) -> None:
        pass

    @abstractmethod
    def writeln(self, text: Optional[str] = None) -> None:
        pass
