import milodb.query as query
from milodb.config import UserConfig
from milodb.output.outputter import Outputter
from milodb.output.support import IterateThroughMatches, EllipsifyText, EllipsisLocation, get_list_of_indexed_metadata_matches, get_url_of_author, get_url_of_tease
from milodb.tease import Tease, TotmStatus
from typing import Dict, List

_MAP_OF_TOTM_STATUS_TO_TEXT: Dict[TotmStatus, str] = {
    TotmStatus.NONE: ' ',
    TotmStatus.NOMINEE: 'n',
    TotmStatus.WINNER: 'w'
}

class PlainOutputter(Outputter):
    def __init__(self, user_config: UserConfig) -> None:
        self._user_config: UserConfig = user_config

    def get_name(self) -> str:
        return 'plain'

    def print_list_of_teases(self, list_of_tease_matches: List[query.TeaseMatch]) -> None:
        tease_match: query.TeaseMatch
        for tease_match in list_of_tease_matches:
            self._print_oneline_of_tease(tease_match)

    def print_summary_of_tease(self, tease_match: query.TeaseMatch) -> None:
        match_index: str = str(tease_match.index_of_match) if tease_match.index_of_match else 'none'
        tease_id: int = tease_match.tease.tease_id
        author_id: int = tease_match.tease.author_id
        tease_id_text: str = f'#{tease_id}'
        tease_type: str = tease_match.tease.get_text_of_property(Tease.type)
        tease_rating: float = tease_match.tease.rating_value
        tease_tags: str = ', '.join(tease_match.tease.get_str_list_property(Tease.list_of_tags))
        tease_date: str = tease_match.tease.get_text_of_property(Tease.date)
        tease_title: str = tease_match.tease.title
        author_name: str = tease_match.tease.author_name
        author_id_text: str = f'@{author_id}'
        summary: str = tease_match.tease.summary
        url_of_tease: str = get_url_of_tease(tease_id)
        url_of_author: str = get_url_of_author(author_id)
        self._user_config.stream_writer.writeln(f"Index   {match_index:>7}")
        self._user_config.stream_writer.writeln(f"Tease   {tease_id_text:>7}   Title  '{tease_title}'")
        self._user_config.stream_writer.writeln(f"Author  {author_id_text:>7}   Name   '{author_name}'")
        self._user_config.stream_writer.writeln(f"Type    {tease_type:>7}   Date   {tease_date}")
        self._user_config.stream_writer.writeln(f"Rating  {tease_rating:>7}   Tags   {tease_tags}")
        self._user_config.stream_writer.writeln(f"Tease   {url_of_tease}")
        self._user_config.stream_writer.writeln(f"Author  {url_of_author}")
        self._user_config.stream_writer.writeln("Summary")
        self._user_config.stream_writer.writeln(summary or 'None')

    def print_all_text_of_list_of_teases(self, list_of_tease_matches: List[query.TeaseMatch]) -> None:
        index: int
        tease_match: query.TeaseMatch
        for index, tease_match in enumerate(list_of_tease_matches):
            if index > 0:
                self._user_config.stream_writer.writeln()
            self.print_summary_of_tease(tease_match)
            self._print_all_text_of_tease(tease_match)

    def print_matching_text_of_list_of_teases(self, list_of_tease_matches: List[query.TeaseMatch]) -> None:
        index: int
        tease_match: query.TeaseMatch
        for index, tease_match in enumerate(list_of_tease_matches):
            if index > 0:
                self._user_config.stream_writer.writeln()
            self.print_summary_of_tease(tease_match)
            self._print_matching_text_of_tease(tease_match)

    def _print_all_text_of_tease(self, tease_match: query.TeaseMatch) -> None:
        index_of_block: int
        text_block: str
        for index_of_block, text_block in enumerate(tease_match.tease.get_str_list_property(Tease.list_of_text_blocks)):
                if index_of_block == 0:
                    self._user_config.stream_writer.writeln('Text')
                    self._user_config.stream_writer.writeln(40 * '-')
                self._user_config.stream_writer.writeln(text_block)
                self._user_config.stream_writer.writeln(40 * '-')

    def _print_matching_text_of_tease(self, tease_match: query.TeaseMatch) -> None:
        is_first_match: bool = True
        index_of_block: int
        text_block: str
        for index_of_block, text_block in enumerate(tease_match.tease.get_str_list_property(Tease.list_of_text_blocks)):
            list_of_matches: List[query.MatchDetails] = get_list_of_indexed_metadata_matches(Tease.list_of_text_blocks, index_of_block, tease_match.list_of_query_matches)
            if list_of_matches:
                if is_first_match:
                    is_first_match = False
                    self._user_config.stream_writer.writeln('Matching text')
                    self._user_config.stream_writer.writeln(40 * '-')
                if self._user_config.is_ellipsis_enabled:
                    ellipsified_text_block: str = self._ellipsify_text(text_block, list_of_matches)
                    self._user_config.stream_writer.writeln(ellipsified_text_block)
                else:
                    self._user_config.stream_writer.writeln(text_block)
                self._user_config.stream_writer.writeln(40 * '-')

    def _print_oneline_of_tease(self, tease_match: query.TeaseMatch) -> None:
        match_index: str = str(tease_match.index_of_match) if tease_match.index_of_match else '-'
        tease_id: str = '#' + str(tease_match.tease.tease_id)
        tease_type: str = tease_match.tease.get_text_of_property(Tease.type)
        tease_rating: float = tease_match.tease.rating_value
        tease_date: str = tease_match.tease.get_text_of_property(Tease.date)
        tease_title: str = tease_match.tease.title
        author_name: str = tease_match.tease.author_name
        author_id: str = str(tease_match.tease.author_id)
        totm_text: str = _MAP_OF_TOTM_STATUS_TO_TEXT.get(tease_match.tease.totm_status, ' ')
        self._user_config.stream_writer.writeln((
            f'{match_index:>3}:'
            f'  {tease_id:>6}'
            f'  {tease_type}'
            f'  {tease_rating:>3}'
            f'  {totm_text}'
            f'  {tease_date}'
            f'  {tease_title}'
            f' : [{author_name}, @{author_id}]'))

    def _ellipsify_text(self, text: str, list_of_matches: List[query.MatchDetails]) -> str:
        formatted_text = ''

        def on_normal_text(text: str, is_first_item: bool, is_last_item: bool) -> None:
            nonlocal formatted_text
            formatted_text += self._ellipsify_text_item(text, is_first_item, is_last_item)

        def on_matched_text(text: str, is_first_item: bool, is_last_item: bool) -> None:
            nonlocal formatted_text
            formatted_text += text

        IterateThroughMatches(text, list_of_matches, on_normal_text, on_matched_text)

        return formatted_text

    def _ellipsify_text_item(self, text, is_first_item: bool, is_last_item: bool) -> str:
        formatted_text: str = ''

        def on_text(text: str):
            nonlocal formatted_text
            formatted_text += text

        def on_ellipsis():
            nonlocal formatted_text
            formatted_text += '\u2026'

        EllipsifyText(text, self._user_config.ellipsis_max_width, EllipsisLocation.from_position(is_first_item, is_last_item), on_text, on_ellipsis)

        return formatted_text
