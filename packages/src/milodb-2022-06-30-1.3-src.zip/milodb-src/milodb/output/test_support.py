from milodb.output.support import IterateThroughMatches
from milodb.query import MatchDetails
import unittest
from dataclasses import dataclass
from enum import Enum
from typing import List, Type, Union

TEXT: str = ("Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
             " Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.")
TEXT_LEN: int = len(TEXT)

@dataclass
class NormalText:
    text: str
    is_first_item: bool
    is_last_item: bool

@dataclass
class MatchedText:
    text: str
    is_first_item: bool
    is_last_item: bool

class TextType(Enum):
    NORMAL_TEXT: Union[Type[NormalText], Type[MatchedText]] = NormalText
    MATCHED_TEXT: Union[Type[NormalText], Type[MatchedText]] = MatchedText

    def toggle(self) -> 'TextType':
        if self.value == NormalText:
            return TextType.MATCHED_TEXT
        else:
            return TextType.NORMAL_TEXT

class TestSupport(unittest.TestCase):
    def setUp(self) -> None:
        self.list_of_captured_text: List[Union[NormalText, MatchedText]] = []

    def on_normal_text(self, text: str, is_first_item: bool, is_last_item: bool) -> None:
        self.list_of_captured_text.append(NormalText(text, is_first_item, is_last_item))

    def on_matched_text(self, text: str, is_first_item: bool, is_last_item: bool) -> None:
        self.list_of_captured_text.append(MatchedText(text, is_first_item, is_last_item))

    def execute(self, list_of_matches: List[MatchDetails], starts_with_type: TextType, *list_of_expected_text: str) -> None:
        IterateThroughMatches(TEXT, list_of_matches, self.on_normal_text, self.on_matched_text)
        self.assertEqual(len(list_of_expected_text), len(self.list_of_captured_text))
        text_type: TextType = starts_with_type
        index: int
        captured_text: Union[NormalText, MatchedText]
        for index, captured_text in enumerate(self.list_of_captured_text):
            self.assertEqual(index == 0, captured_text.is_first_item)
            self.assertEqual(index == len(list_of_expected_text) - 1, captured_text.is_last_item)
            self.assertIsInstance(captured_text, text_type.value)
            self.assertEqual(list_of_expected_text[index], captured_text.text)
            text_type = text_type.toggle()

    def test_empty_matches(self):
        self.execute(
            [],
            TextType.NORMAL_TEXT,
            TEXT)

    def test_single_match_at_start(self):
        self.execute(
            [MatchDetails(0, 5)],
            TextType.MATCHED_TEXT,
            TEXT[:5],
            TEXT[5:])

    def test_single_match_of_one_character_at_start(self):
        self.execute(
            [MatchDetails(0, 1)],
            TextType.MATCHED_TEXT,
            TEXT[:1],
            TEXT[1:])

    def test_single_match_at_end(self):
        self.execute(
            [MatchDetails(TEXT_LEN - 5, TEXT_LEN)],
            TextType.NORMAL_TEXT,
            TEXT[:-5],
            TEXT[-5:])

    def test_single_match_of_one_character_at_end(self):
        self.execute(
            [MatchDetails(TEXT_LEN - 1, TEXT_LEN)],
            TextType.NORMAL_TEXT,
            TEXT[:-1],
            TEXT[-1:])

    def test_single_match_in_middle(self):
        self.execute(
            [MatchDetails(40, 45)],
            TextType.NORMAL_TEXT,
            TEXT[:40],
            TEXT[40:45],
            TEXT[45:])

    def test_single_match_of_one_character_in_middle(self):
        self.execute(
            [MatchDetails(40, 41)],
            TextType.NORMAL_TEXT,
            TEXT[:40],
            TEXT[40:41],
            TEXT[41:])

    def test_two_matches_in_order_at_start_and_end(self):
        self.execute(
            [MatchDetails(0, 10), MatchDetails(TEXT_LEN - 10, TEXT_LEN)],
            TextType.MATCHED_TEXT,
            TEXT[:10],
            TEXT[10:-10],
            TEXT[-10:])

    def test_two_matches_in_order_in_middle(self):
        self.execute(
            [MatchDetails(20, 25), MatchDetails(TEXT_LEN - 20, TEXT_LEN - 15)],
            TextType.NORMAL_TEXT,
            TEXT[:20],
            TEXT[20:25],
            TEXT[25:-20],
            TEXT[-20:-15],
            TEXT[-15:])

    def test_two_matches_out_of_order_at_start_and_end(self):
        self.execute(
            [MatchDetails(TEXT_LEN - 10, TEXT_LEN), MatchDetails(0, 10)],
            TextType.MATCHED_TEXT,
            TEXT[:10],
            TEXT[10:-10],
            TEXT[-10:])

    def test_two_matches_out_of_order_in_middle(self):
        self.execute(
            [MatchDetails(TEXT_LEN - 20, TEXT_LEN - 15), MatchDetails(20, 25)],
            TextType.NORMAL_TEXT,
            TEXT[:20],
            TEXT[20:25],
            TEXT[25:-20],
            TEXT[-20:-15],
            TEXT[-15:])

    def test_two_consecutive_matches_in_order(self):
        self.execute(
            [MatchDetails(20, 25), MatchDetails(25, 35)],
            TextType.NORMAL_TEXT,
            TEXT[:20],
            TEXT[20:35],
            TEXT[35:])

    def test_two_consecutive_matches_out_of_order(self):
        self.execute(
            [MatchDetails(25, 35), MatchDetails(20, 25)],
            TextType.NORMAL_TEXT,
            TEXT[:20],
            TEXT[20:35],
            TEXT[35:])

    def test_two_overlapping_matches_in_order(self):
        self.execute(
            [MatchDetails(20, 25), MatchDetails(23, 33)],
            TextType.NORMAL_TEXT,
            TEXT[:20],
            TEXT[20:33],
            TEXT[33:])

    def test_two_overlapping_matches_out_of_order(self):
        self.execute(
            [MatchDetails(23, 33), MatchDetails(20, 25)],
            TextType.NORMAL_TEXT,
            TEXT[:20],
            TEXT[20:33],
            TEXT[33:])

    def test_two_completely_overlapping_matches_in_order(self):
        self.execute(
            [MatchDetails(20, 40), MatchDetails(25, 35)],
            TextType.NORMAL_TEXT,
            TEXT[:20],
            TEXT[20:40],
            TEXT[40:])

    def test_two_completely_overlapping_matches_out_of_order(self):
        self.execute(
            [MatchDetails(25, 35), MatchDetails(20, 40)],
            TextType.NORMAL_TEXT,
            TEXT[:20],
            TEXT[20:40],
            TEXT[40:])

    def test_single_match_before_start(self):
        self.execute(
            [MatchDetails(-5, 0)],
            TextType.NORMAL_TEXT,
            TEXT)

    def test_single_match_after_end(self):
        self.execute(
            [MatchDetails(TEXT_LEN, TEXT_LEN + 5)],
            TextType.NORMAL_TEXT,
            TEXT)

    def test_single_match_extending_before_start(self):
        self.execute(
            [MatchDetails(-5, 10)],
            TextType.MATCHED_TEXT,
            TEXT[:10],
            TEXT[10:])

    def test_single_match_extending_after_end(self):
        self.execute(
            [MatchDetails(TEXT_LEN - 10, TEXT_LEN + 5)],
            TextType.NORMAL_TEXT,
            TEXT[:-10],
            TEXT[-10:])
