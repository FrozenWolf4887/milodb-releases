from milodb.output.output_sink import OutputSink
import json
import sys
from typing import IO, Any, Callable, Dict, List, Optional, Union

class ConfigGroup:
    def __init__(self, parent_group: Optional['ConfigGroup'], key_name: str) -> None:
        self._parent_group: Optional[ConfigGroup] = parent_group
        self._key_name: str = key_name
        self._list_of_children: List[Union[ConfigGroup, ConfigItem]] = []
        if self._parent_group is not None:
            self._parent_group._list_of_children.append(self)

    @property
    def parent_group(self) -> Optional['ConfigGroup']:
        return self._parent_group

    @property
    def key_name(self) -> str:
        return self._key_name

    @property
    def list_of_children(self) -> List[Union['ConfigGroup', 'ConfigItem']]:
        return self._list_of_children

    def get_full_path(self) -> str:
        if self._parent_group is not None:
            return self._parent_group.get_full_path() + '/' + self._key_name
        else:
            return self._key_name

class ConfigRoot(ConfigGroup):
    def __init__(self) -> None:
        super().__init__(None, '')

class ConfigItem:
    def __init__(self, parent_group: ConfigGroup, key_name: str, default_value: str) -> None:
        self._parent_group: ConfigGroup = parent_group
        self._key_name: str = key_name
        self._default_value: str = default_value
        self._parent_group._list_of_children.append(self)

    @property
    def parent_group(self) -> ConfigGroup:
        return self._parent_group

    @property
    def key_name(self) -> str:
        return self._key_name

    @property
    def default_value(self) -> str:
        return self._default_value

    def get_full_path(self) -> str:
        return self._parent_group.get_full_path() + '/' + self._key_name

config_root = ConfigRoot()
config_version = ConfigItem(config_root, 'configVersion', '1')
config_format = ConfigGroup(config_root, 'format')
config_format_ansi = ConfigGroup(config_format, 'ansi')
config_format_ansi_colour = ConfigGroup(config_format_ansi, 'colour')
config_format_ansi_colour_index_heading = ConfigItem(config_format_ansi_colour, 'indexHeading', '0')
config_format_ansi_colour_tease_heading = ConfigItem(config_format_ansi_colour, 'teaseHeading', '34')
config_format_ansi_colour_author_heading = ConfigItem(config_format_ansi_colour, 'authorHeading', '32')
config_format_ansi_colour_type_heading = ConfigItem(config_format_ansi_colour, 'typeHeading', '33')
config_format_ansi_colour_date_heading = ConfigItem(config_format_ansi_colour, 'dateHeading', '33')
config_format_ansi_colour_rating_heading = ConfigItem(config_format_ansi_colour, 'ratingHeading', '35')
config_format_ansi_colour_tags_heading = ConfigItem(config_format_ansi_colour, 'tagsHeading', '35')
config_format_ansi_colour_summary_heading = ConfigItem(config_format_ansi_colour, 'summaryHeading', '36')
config_format_ansi_colour_matching_text_heading = ConfigItem(config_format_ansi_colour, 'matchingTextHeading', '34')
config_format_ansi_colour_matching_text = ConfigItem(config_format_ansi_colour, 'matchingText', '4;31')
config_format_ansi_colour_ellipsis = ConfigItem(config_format_ansi_colour, 'ellipsis', '30;1')
config_format_bbcode = ConfigGroup(config_format, 'bbcode')
config_format_bbcode_colour = ConfigGroup(config_format_bbcode, 'colour')
config_format_bbcode_colour_index_heading = ConfigItem(config_format_bbcode_colour, 'indexHeading', '#808080')
config_format_bbcode_colour_tease_heading = ConfigItem(config_format_bbcode_colour, 'teaseHeading', '#000060')
config_format_bbcode_colour_author_heading = ConfigItem(config_format_bbcode_colour, 'authorHeading', '#006000')
config_format_bbcode_colour_type_heading = ConfigItem(config_format_bbcode_colour, 'typeHeading', '#606000')
config_format_bbcode_colour_date_heading = ConfigItem(config_format_bbcode_colour, 'dateHeading', '#606000')
config_format_bbcode_colour_rating_heading = ConfigItem(config_format_bbcode_colour, 'ratingHeading', '#600060')
config_format_bbcode_colour_tags_heading = ConfigItem(config_format_bbcode_colour, 'tagsHeading', '#600060')
config_format_bbcode_colour_summary_heading = ConfigItem(config_format_bbcode_colour, 'summaryHeading', '#007070')
config_format_bbcode_colour_matching_text_heading = ConfigItem(config_format_bbcode_colour, 'matchingTextHeading', '#600060')
config_format_bbcode_colour_matching_text = ConfigItem(config_format_bbcode_colour, 'matchingText', '#FF0000')
config_format_bbcode_colour_ellipsis = ConfigItem(config_format_bbcode_colour, 'ellipsis', '#808080')
config_format_html = ConfigGroup(config_format, 'html')
config_format_html_css = ConfigGroup(config_format_html, 'css')
config_format_html_css_file_path = ConfigItem(config_format_html_css, 'filePath', 'default.css')
config_format_html_css_colour = ConfigGroup(config_format_html_css, 'colour')
config_format_html_css_colour_page_background = ConfigItem(config_format_html_css_colour, "pageBackground", '#F2CFCF')
config_format_html_css_colour_list_table_background = ConfigItem(config_format_html_css_colour, "listTableBackground", '#933737')
config_format_html_css_colour_list_table_header_background = ConfigItem(config_format_html_css_colour, "listTableHeaderBackground", '#933737')
config_format_html_css_colour_list_table_header_text_tease_id = ConfigItem(config_format_html_css_colour, "listTableHeaderTextTeaseId", 'white')
config_format_html_css_colour_list_table_header_text_type = ConfigItem(config_format_html_css_colour, "listTableHeaderTextType", 'yellow')
config_format_html_css_colour_list_table_header_text_rating = ConfigItem(config_format_html_css_colour, "listTableHeaderTextRating", '#CAF')
config_format_html_css_colour_list_table_header_text_date = ConfigItem(config_format_html_css_colour, "listTableHeaderTextDate", '#DDD')
config_format_html_css_colour_list_table_header_text_title = ConfigItem(config_format_html_css_colour, "listTableHeaderTextTitle", '#F2CFCF')
config_format_html_css_colour_list_table_header_text_author = ConfigItem(config_format_html_css_colour, "listTableHeaderTextAuthor", 'greenyellow')
config_format_html_css_colour_list_table_value_background = ConfigItem(config_format_html_css_colour, "listTableValueBackground", 'white')
config_format_html_css_colour_list_table_value_border = ConfigItem(config_format_html_css_colour, "listTableValueBorder", '#F2CFCF')
config_format_html_css_colour_list_table_value_text_tease_id = ConfigItem(config_format_html_css_colour, "listTableValueTextTeaseId", 'black')
config_format_html_css_colour_list_table_value_text_type = ConfigItem(config_format_html_css_colour, "listTableValueTextType", '#660')
config_format_html_css_colour_list_table_value_text_rating = ConfigItem(config_format_html_css_colour, "listTableValueTextRating", 'seagreen')
config_format_html_css_colour_list_table_value_text_date = ConfigItem(config_format_html_css_colour, "listTableValueTextDate", '#444')
config_format_html_css_colour_list_table_value_text_title = ConfigItem(config_format_html_css_colour, "listTableValueTextTitle", '#848')
config_format_html_css_colour_list_table_value_text_author = ConfigItem(config_format_html_css_colour, "listTableValueTextAuthor", 'black')
config_format_html_css_colour_list_table_value_text_total_matches = ConfigItem(config_format_html_css_colour, "listTableValueTextTotalMatches", 'black')
config_format_html_css_colour_list_table_matching_text_foreground = ConfigItem(config_format_html_css_colour, "listTableMatchingTextForeground", '#933737')
config_format_html_css_colour_list_table_matching_text_background = ConfigItem(config_format_html_css_colour, "listTableMatchingTextBackground", '#F2CFCF')
config_format_html_css_colour_list_table_matching_text_border = ConfigItem(config_format_html_css_colour, "listTableMatchingTextBorder", '#933737')
config_format_html_css_colour_summary_table_background = ConfigItem(config_format_html_css_colour, "summaryTableBackground", '#933737')
config_format_html_css_colour_summary_table_thumbnail_background = ConfigItem(config_format_html_css_colour, "summaryTableThumbnailBackground", '#744')
config_format_html_css_colour_summary_table_thumbnail_border = ConfigItem(config_format_html_css_colour, "summaryTableThumbnailBorder", '#C28F8F')
config_format_html_css_colour_summary_table_header_background = ConfigItem(config_format_html_css_colour, "summaryTableHeaderBackground", '#933737')
config_format_html_css_colour_summary_table_header_text_tease_id = ConfigItem(config_format_html_css_colour, "summaryTableHeaderTextTeaseId", 'white')
config_format_html_css_colour_summary_table_header_text_title = ConfigItem(config_format_html_css_colour, "summaryTableHeaderTextTitle", '#F2CFCF')
config_format_html_css_colour_summary_table_header_text_author_id = ConfigItem(config_format_html_css_colour, "summaryTableHeaderTextAuthorId", 'greenyellow')
config_format_html_css_colour_summary_table_header_text_author_name = ConfigItem(config_format_html_css_colour, "summaryTableHeaderTextAuthorName", 'greenyellow')
config_format_html_css_colour_summary_table_header_text_type = ConfigItem(config_format_html_css_colour, "summaryTableHeaderTextType", 'yellow')
config_format_html_css_colour_summary_table_header_text_date = ConfigItem(config_format_html_css_colour, "summaryTableHeaderTextDate", '#DDD')
config_format_html_css_colour_summary_table_header_text_rating = ConfigItem(config_format_html_css_colour, "summaryTableHeaderTextRating", '#CAF')
config_format_html_css_colour_summary_table_header_text_tags = ConfigItem(config_format_html_css_colour, "summaryTableHeaderTextTags", '#BDF')
config_format_html_css_colour_summary_table_header_text_summary = ConfigItem(config_format_html_css_colour, "summaryTableHeaderTextSummary", 'khaki')
config_format_html_css_colour_summary_table_value_background = ConfigItem(config_format_html_css_colour, "summaryTableValueBackground", 'white')
config_format_html_css_colour_summary_table_value_border = ConfigItem(config_format_html_css_colour, "summaryTableValueBorder", '#F2CFCF')
config_format_html_css_colour_summary_table_value_text_tease_id = ConfigItem(config_format_html_css_colour, "summaryTableValueTextTeaseId", 'white')
config_format_html_css_colour_summary_table_value_text_title = ConfigItem(config_format_html_css_colour, "summaryTableValueTextTitle", '#848')
config_format_html_css_colour_summary_table_value_text_author_id = ConfigItem(config_format_html_css_colour, "summaryTableValueTextAuthorId", 'black')
config_format_html_css_colour_summary_table_value_text_author_name = ConfigItem(config_format_html_css_colour, "summaryTableValueTextAuthorName", 'darkgreen')
config_format_html_css_colour_summary_table_value_text_type = ConfigItem(config_format_html_css_colour, "summaryTableValueTextType", '#660')
config_format_html_css_colour_summary_table_value_text_date = ConfigItem(config_format_html_css_colour, "summaryTableValueTextDate", 'black')
config_format_html_css_colour_summary_table_value_text_rating = ConfigItem(config_format_html_css_colour, "summaryTableValueTextRating", 'seagreen')
config_format_html_css_colour_summary_table_value_text_tags = ConfigItem(config_format_html_css_colour, "summaryTableValueTextTags", 'black')
config_format_html_css_colour_summary_table_value_text_summary = ConfigItem(config_format_html_css_colour, "summaryTableValueTextSummary", 'black')
config_format_html_css_colour_summary_table_matching_text_foreground = ConfigItem(config_format_html_css_colour, "summaryTableMatchingTextForeground", '#933737')
config_format_html_css_colour_summary_table_matching_text_background = ConfigItem(config_format_html_css_colour, "summaryTableMatchingTextBackground", '#F2CFCF')
config_format_html_css_colour_summary_table_matching_text_border = ConfigItem(config_format_html_css_colour, "summaryTableMatchingTextBorder", '#933737')
config_format_html_css_colour_text_table_background = ConfigItem(config_format_html_css_colour, "textTableBackground", '#933737')
config_format_html_css_colour_text_table_header_background = ConfigItem(config_format_html_css_colour, "textTableHeaderBackground", '#933737')
config_format_html_css_colour_text_table_header_foreground = ConfigItem(config_format_html_css_colour, "textTableHeaderForeground", 'white')
config_format_html_css_colour_text_table_content_background = ConfigItem(config_format_html_css_colour, "textTableContentBackground", 'white')
config_format_html_css_colour_text_table_content_foreground = ConfigItem(config_format_html_css_colour, "textTableContentForeground", 'black')
config_format_html_css_colour_text_table_content_border = ConfigItem(config_format_html_css_colour, "textTableContentBorder", '#F2CFCF')
config_format_html_css_colour_text_table_ellipsis_foreground = ConfigItem(config_format_html_css_colour, "textTableEllipsisForeground", 'white')
config_format_html_css_colour_text_table_ellipsis_background = ConfigItem(config_format_html_css_colour, "textTableEllipsisBackground", '#CCC')
config_format_html_css_colour_text_table_matching_text_foreground = ConfigItem(config_format_html_css_colour, "textTableMatchingTextForeground", '#933737')
config_format_html_css_colour_text_table_matching_text_background = ConfigItem(config_format_html_css_colour, "textTableMatchingTextBackground", '#F2CFCF')
config_format_html_css_colour_text_table_matching_text_border = ConfigItem(config_format_html_css_colour, "textTableMatchingTextBorder", '#933737')

class SystemConfig:
    def __init__(self, filepath: str) -> None:
        self._config_dict: dict = {}
        self._filepath: str = filepath
        next_action: Callable[[], None]

        try:
            with open(filepath, 'rt') as file:
                self._config_dict = json.load(file)
            print(f"Loaded config from '{filepath}'")
            next_action = self._validate_config
        except FileNotFoundError:
            next_action = self._generate_config_file
        except (IOError, json.JSONDecodeError) as ex:
            print(f"Error: Unable to load config from '{filepath}': {ex}")
            next_action = self._create_default_config

        next_action()

    def _validate_config(self) -> None:
        self._validate_existing_config(self._config_dict, config_root)
        self._report_redundant_config(self._config_dict, config_root)
        if self._add_missing_config(self._config_dict, config_root):
            self._save_config()

    def _validate_existing_config(self, group_dict: Dict[str, Any], config_group: ConfigGroup) -> None:
        group_or_item: Union[ConfigGroup, ConfigItem]
        for group_or_item in config_group._list_of_children:
            value: Optional[Any] = group_dict.get(group_or_item.key_name)
            if isinstance(group_or_item, ConfigItem):
                if value is not None and not isinstance(value, str):
                    print(f"Error: Config item '{group_or_item.get_full_path()}' is not text")
            else:
                if value is not None:
                    if isinstance(value, dict):
                        self._validate_existing_config(value, group_or_item)
                    else:
                        print(f"Error: Config item '{group_or_item.get_full_path()}' is not a group")

    def _report_redundant_config(self, group_dict: Dict[str, Any], config_group: ConfigGroup) -> None:
        key_name: str
        for key_name, value in group_dict.items():
            group_or_item: Union[ConfigGroup, ConfigItem]
            was_found_in_schema: bool = False
            for group_or_item in config_group._list_of_children:
                if key_name == group_or_item.key_name:
                    was_found_in_schema = True
                    break
            if not was_found_in_schema:
                print(f"Warning: Config {'group' if isinstance(value, dict) else 'item'} '{config_group.get_full_path()}/{key_name}' is not recognised")
            elif isinstance(value, dict) and isinstance(group_or_item, ConfigGroup):
                self._report_redundant_config(value, group_or_item)

    def _add_missing_config(self, group_dict: Dict[str, Any], config_group: ConfigGroup) -> bool:
        was_anything_added: bool = False
        group_or_item: Union[ConfigGroup, ConfigItem]
        for group_or_item in config_group._list_of_children:
            value: Optional[Any] = group_dict.get(group_or_item.key_name)
            if isinstance(group_or_item, ConfigItem):
                if value is None:
                    group_dict[group_or_item.key_name] = group_or_item.default_value
                    print(f"Added config item '{group_or_item.get_full_path()}'")
                    was_anything_added = True
            else:
                if value is None:
                    new_group: Dict[str, Any] = {}
                    group_dict[group_or_item.key_name] = new_group
                    was_anything_added = True
                    was_anything_added = self._add_missing_config(new_group, group_or_item) or was_anything_added
                else:
                    if isinstance(value, dict):
                        was_anything_added = self._add_missing_config(value, group_or_item) or was_anything_added
        return was_anything_added

    def _save_config(self):
        was_backup_successful: bool = False
        try:
            with open(self._filepath, 'rb') as file_in:
                with open(f'{self._filepath}.old', 'wb') as file_out:
                    file_out.write(file_in.read())
            was_backup_successful = True
        except FileNotFoundError:
            was_backup_successful = True
        except IOError:
                print(f"Error: Unable to backup config to file '{self._filepath}.old': {ex}")

        if was_backup_successful:
            try:
                with open(self._filepath, 'wt') as file:
                    json.dump(self._config_dict, file, indent=4, sort_keys=True)
                print(f"Saved config file '{self._filepath}'")
            except IOError as ex:
                print(f"Error: Unable to write config to file '{self._filepath}': {ex}")

    @staticmethod
    def _generate_config(config_group: ConfigGroup) -> Dict[str, Any]:
        group_dict: Dict[str, Any] = {}
        group_or_item: Union[ConfigGroup, ConfigItem]
        for group_or_item in config_group._list_of_children:
            if isinstance(group_or_item, ConfigItem):
                group_dict[group_or_item.key_name] = group_or_item.default_value
            else:
                group_dict[group_or_item.key_name] = SystemConfig._generate_config(group_or_item)
        return group_dict

    def _generate_config_file(self) -> None:
        self._config_dict = SystemConfig._generate_config(config_root)
        self._save_config()

    def _create_default_config(self) -> None:
        print('Using default config')
        self._config_dict = SystemConfig._generate_config(config_root)

    def _get_config_item(self, config_item: ConfigItem) -> str:
        hierarchy_of_keys: List[str] = [config_item.key_name]
        parent_group: Optional[ConfigGroup] = config_item.parent_group
        while parent_group is not None and not isinstance(parent_group, ConfigRoot):
            hierarchy_of_keys.insert(0, parent_group.key_name)
            parent_group = parent_group.parent_group
        return self._get_field_value(hierarchy_of_keys, config_item.default_value)

    def _get_field_value(self, hierarchy_of_keys: List[str], default_value: str) -> str:
        current_object: dict = self._config_dict
        try:
            key: str
            for key in hierarchy_of_keys:
                current_object = current_object[key]
            if isinstance(current_object, str):
                return current_object
            else:
                return default_value
        except KeyError:
            return default_value

class AnsiConfig:
    def __init__(self, system_config: SystemConfig) -> None:
        self._system_config = system_config

    @property
    def index_heading_colour(self) -> str:
        return self._system_config._get_config_item(config_format_ansi_colour_index_heading)

    @property
    def tease_heading_colour(self) -> str:
        return self._system_config._get_config_item(config_format_ansi_colour_tease_heading)

    @property
    def author_heading_colour(self) -> str:
        return self._system_config._get_config_item(config_format_ansi_colour_author_heading)

    @property
    def type_heading_colour(self) -> str:
        return self._system_config._get_config_item(config_format_ansi_colour_type_heading)

    @property
    def date_heading_colour(self) -> str:
        return self._system_config._get_config_item(config_format_ansi_colour_date_heading)

    @property
    def rating_heading_colour(self) -> str:
        return self._system_config._get_config_item(config_format_ansi_colour_rating_heading)

    @property
    def tags_heading_colour(self) -> str:
        return self._system_config._get_config_item(config_format_ansi_colour_tags_heading)

    @property
    def summary_heading_colour(self) -> str:
        return self._system_config._get_config_item(config_format_ansi_colour_summary_heading)

    @property
    def matching_text_heading_colour(self) -> str:
        return self._system_config._get_config_item(config_format_ansi_colour_matching_text_heading)

    @property
    def matching_text_colour(self) -> str:
        return self._system_config._get_config_item(config_format_ansi_colour_matching_text)

    @property
    def ellipsis_colour(self) -> str:
        return self._system_config._get_config_item(config_format_ansi_colour_ellipsis)

class BBCodeConfig:
    def __init__(self, system_config: SystemConfig) -> None:
        self._system_config = system_config

    @property
    def index_heading_colour(self) -> str:
        return self._system_config._get_config_item(config_format_bbcode_colour_index_heading)

    @property
    def tease_heading_colour(self) -> str:
        return self._system_config._get_config_item(config_format_bbcode_colour_tease_heading)

    @property
    def author_heading_colour(self) -> str:
        return self._system_config._get_config_item(config_format_bbcode_colour_author_heading)

    @property
    def type_heading_colour(self) -> str:
        return self._system_config._get_config_item(config_format_bbcode_colour_type_heading)

    @property
    def date_heading_colour(self) -> str:
        return self._system_config._get_config_item(config_format_bbcode_colour_date_heading)

    @property
    def rating_heading_colour(self) -> str:
        return self._system_config._get_config_item(config_format_bbcode_colour_rating_heading)

    @property
    def tags_heading_colour(self) -> str:
        return self._system_config._get_config_item(config_format_bbcode_colour_tags_heading)

    @property
    def summary_heading_colour(self) -> str:
        return self._system_config._get_config_item(config_format_bbcode_colour_summary_heading)

    @property
    def matching_text_heading_colour(self) -> str:
        return self._system_config._get_config_item(config_format_bbcode_colour_matching_text_heading)

    @property
    def matching_text_colour(self) -> str:
        return self._system_config._get_config_item(config_format_bbcode_colour_matching_text)

    @property
    def ellipsis_colour(self) -> str:
        return self._system_config._get_config_item(config_format_bbcode_colour_ellipsis)

class HtmlConfig:
    def __init__(self, system_config: SystemConfig) -> None:
        self._system_config = system_config

    @property
    def css_file_path(self) -> str:
        return self._system_config._get_config_item(config_format_html_css_file_path)

    def try_get_colour_field(self, key: str) -> Optional[str]:
        config_item: Union[ConfigGroup, ConfigItem]
        for config_item in config_format_html_css_colour.list_of_children:
            if isinstance(config_item, ConfigItem) and config_item.key_name == key:
                return self._system_config._get_config_item(config_item)
        return None

class UserConfig:
    def __init__(self, output_sink: OutputSink) -> None:
        self.is_highlighting_enabled: bool = True
        self.is_ellipsis_enabled: bool = True
        self.ellipsis_max_width: int = 40
        self.stream_writer: OutputSink = output_sink

    def copy(self) -> 'UserConfig':
        user_config = UserConfig(self.stream_writer)
        user_config.is_ellipsis_enabled = self.is_ellipsis_enabled
        user_config.is_highlighting_enabled = self.is_highlighting_enabled
        user_config.ellipsis_max_width = self.ellipsis_max_width
        return user_config
