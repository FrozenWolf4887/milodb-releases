from milodb.systest.logger import Logger
from milodb.systest.fifo import InputFifo, OutputFifo
from milodb.systest.formatting import Ansi
from milodb.systest.test_framework import TestFramework

class TestSuite(TestFramework):
    def __init__(self, logger: Logger, input_fifo: InputFifo, output_fifo: OutputFifo, is_development_test: bool) -> None:
        super().__init__(logger, input_fifo, output_fifo)
        self._is_development_test: bool = is_development_test
        self._run_tests()

    def _run_tests(self) -> None:
        self._logger.log_info('Starting tests')
        self._test_startup()
        self._test_format_default()
        self._test_ellipsis_default()
        self._test_highlight_default()
        self._test_query_no_matches()
        self._test_ansi_list_teaseid_highlighting()
        self._test_ansi_list_type_highlighting()
        self._test_ansi_list_rating_highlighting()
        self._test_ansi_list_date_highlighting()
        self._test_ansi_list_title_highlighting()
        self._test_ansi_list_author_highlighting()
        self._test_ansi_list_authorid_highlighting()
        self._test_exit()
        self._logger.log_info('Finished running tests')

    def _test_startup(self) -> None:
        if self._is_development_test:
            self._verify_line('Milovana Database (Development), (Undated)')
        else:
            self._verify_line(r'Milovana Database [1-9]\.[0-9]+, 202[2-9]-[0-1][0-9]-[0-3][0-9]', regex=True)
        self._verify_line("Loaded config from 'config.json'")
        self._verify_line('Load database')
        self._verify_line(r'  Read     : [0-1].[0-9]{3}s', regex=True)
        self._verify_line(r'  Unpack   : [0-1].[0-9]{3}s', regex=True)
        self._verify_line(r'  Parse    : [0-1].[0-9]{3}s', regex=True)
        self._verify_line(r'  Assemble : [0-1].[0-9]{3}s', regex=True)
        self._verify_line(r'Load completed: [0-2].[0-9]{3}s', regex=True)
        self._verify_line(r'[0-9],[0-9]{3} teases loaded ranging from 2006-08-15 to 202[2-9]-[0-1][0-9]-[0-3][0-9]', regex=True)
        self._verify_line('')
        self._verify_line('Enter command (or "help"):')
        self._verify_prompt()

    def _test_format_default(self) -> None:
        self._verify_command('format', [
            "Current format is 'ansi'",
            "Available formats are ['plain', 'ansi', 'bbcode', 'html']" ])

    def _test_ellipsis_default(self) -> None:
        self._verify_command('ellipsis', [
            "Current ellipsis mode is 'on'",
            "Available options are ['on', 'off']" ])

    def _test_highlight_default(self) -> None:
        self._verify_command('highlight', [
            "Current highlighting is 'on'",
            "Available options are ['on', 'off']" ])

    def _test_query_no_matches(self) -> None:
        self._verify_command('query teaseId = 1234', [
            "No matches" ])

    def _test_ansi_list_teaseid_highlighting(self) -> None:
        self._verify_command('query teaseId = 40134', [
            f"  1:  #{Ansi.highlighted('40134')}  eos  4.7  w  2019-06-11  Before Eternity : [Shattered, @29180]" ])

    def _test_ansi_list_type_highlighting(self) -> None:
        self._verify_command('query type is eos and summary contains "another soul guides you"', [
            f"  1:  #40134  {Ansi.highlighted('eos')}  4.7  w  2019-06-11  Before Eternity : [Shattered, @29180]" ])

    def _test_ansi_list_rating_highlighting(self) -> None:
        self._verify_command('query rating > 4 and summary contains "another soul guides you"', [
            f"  1:  #40134  eos  {Ansi.highlighted('4.7')}  w  2019-06-11  Before Eternity : [Shattered, @29180]" ])

    def _test_ansi_list_date_highlighting(self) -> None:
        self._verify_command('query date < 2020-01-01 and summary contains "another soul guides you"', [
            f"  1:  #40134  eos  4.7  w  {Ansi.highlighted('2019-06-11')}  Before Eternity : [Shattered, @29180]" ])

    def _test_ansi_list_title_highlighting(self) -> None:
        self._verify_command('query title contains fore and summary contains "another soul guides you"', [
            f"  1:  #40134  eos  4.7  w  2019-06-11  Be{Ansi.highlighted('fore')} Eternity : [Shattered, @29180]" ])

    def _test_ansi_list_author_highlighting(self) -> None:
        self._verify_command('query author contains hatter and summary contains "another soul guides you"', [
            f"  1:  #40134  eos  4.7  w  2019-06-11  Before Eternity : [S{Ansi.highlighted('hatter')}ed, @29180]" ])

    def _test_ansi_list_authorid_highlighting(self) -> None:
        self._verify_command('query authorId > 29000 and summary contains "another soul guides you"', [
            f"  1:  #40134  eos  4.7  w  2019-06-11  Before Eternity : [Shattered, @{Ansi.highlighted('29180')}]" ])

    def _test_exit(self) -> None:
        self._inject_line('exit')
        self._verify_line('')
        self._verify_line('')
        self._verify_none()
