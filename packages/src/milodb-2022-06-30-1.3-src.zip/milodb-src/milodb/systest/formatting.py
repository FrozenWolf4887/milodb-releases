class Ansi:
    @staticmethod
    def highlighted(text: str) -> str:
        return Ansi.coloured('4;31', text)

    @staticmethod
    def coloured(color_code: str, text: str) -> str:
        return f'\x1b[{color_code}m{text}\x1b[0m'
