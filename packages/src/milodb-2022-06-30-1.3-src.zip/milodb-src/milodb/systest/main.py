from milodb.systest.logger import Logger
from milodb.systest.fifo import InputFifo, OutputFifo
from milodb.systest.test_framework import TestFail
from milodb.systest.test_suite import TestSuite

class Main:
    def __init__(self, log_filepath: str, input_fifo_filepath: str, output_fifo_filepath: str, is_development_test: bool) -> None:
        self._was_successful: bool = False
        try:
            logger: Logger
            input_fifo: InputFifo
            output_fifo: OutputFifo
            with Logger(log_filepath) as logger:
                try:
                    with InputFifo(input_fifo_filepath) as input_fifo:
                        with OutputFifo(output_fifo_filepath) as output_fifo:
                            TestSuite(logger, input_fifo, output_fifo, is_development_test)
                            self._was_successful = True
                except TestFail:
                    logger.log_info('Test failed, aborting')
                    self._was_successful = False
        except IOError as ex:
            print(f'IOERROR: {ex}')

    @property
    def was_successful(self) -> bool:
        return self._was_successful
