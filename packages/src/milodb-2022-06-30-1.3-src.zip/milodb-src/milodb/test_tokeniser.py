from milodb.tokeniser import FailedTokenisationResult, SuccessfulTokenisationResult, Token, tokenise
import unittest
from typing import Union

class TestTokeniser(unittest.TestCase):
    def setUp(self):
        self.result: Union[SuccessfulTokenisationResult, FailedTokenisationResult]

    def execute(self, text: str):
        self.result = tokenise(text)

    def assert_successful(self) -> None:
        self.assertIsInstance(self.result, SuccessfulTokenisationResult,
            "Tokenisation should have been successful but wasn't")

    def assert_unsuccessful(self, error_msg: str, character_index: int) -> None:
        if isinstance(self.result, FailedTokenisationResult):
            self.assertEqual(error_msg, self.result.cause_of_fault_text,
                f"Expected error message of '{error_msg}' but got '{self.result.cause_of_fault_text}'")
            self.assertEqual(character_index, self.result.cause_of_fault_character_index,
                f'Expected character index of failed tokenisation at {character_index} but was {self.result.cause_of_fault_character_index}')
        else:
            self.fail("Tokenisation should have failed but was successful")

    def assert_token_count(self, expected_count: int) -> None:
        if isinstance(self.result, SuccessfulTokenisationResult):
            actual_count: int = len(self.result.list_of_tokens)
            self.assertEqual(expected_count, actual_count,
                f'Expected {expected_count} tokens but there are {actual_count} tokens')

    def assert_token_equals(self, token_index: int, text: str, start_character_index: int, end_character_index: int) -> None:
        if isinstance(self.result, SuccessfulTokenisationResult):
            token: Token = self.result.list_of_tokens[token_index]
            self.assertEqual(token_index, token.token_index,
                f'Token #{token_index}: Expected token index of {token_index} but was {token.token_index}')
            self.assertEqual(text, token.text,
                f"Token #{token_index}: Expected token text of '{text}' but was '{token.text}'")
            self.assertEqual(start_character_index, token.start_character_index,
                f'Token #{token_index}: Expected start character index of {start_character_index} but was {token.start_character_index}')
            self.assertEqual(end_character_index, token.end_character_index,
                f'Token #{token_index}: Expected end character index of {end_character_index} but was {token.end_character_index}')

    def test_empty_input_returns_successful_with_empty_token_list(self):
        self.execute('')
        self.assert_successful()
        self.assert_token_count(0)

    def test_one_word_returns_one_token(self):
        self.execute("hello_world")
        self.assert_successful()
        self.assert_token_count(1)
        self.assert_token_equals(0, "hello_world", 0, 11)

    def test_one_word_with_pre_padding_returns_one_token(self):
        self.execute(" hello_world")
        self.assert_successful()
        self.assert_token_count(1)
        self.assert_token_equals(0, "hello_world", 1, 12)

    def test_one_word_with_post_padding_returns_one_token(self):
        self.execute("hello_world ")
        self.assert_successful()
        self.assert_token_count(1)
        self.assert_token_equals(0, "hello_world", 0, 11)

    def test_one_word_with_pre_and_post_padding_returns_one_token(self):
        self.execute("  hello_world  ")
        self.assert_successful()
        self.assert_token_count(1)
        self.assert_token_equals(0, "hello_world", 2, 13)

    def test_one_double_quoted_string_returns_one_token(self):
        self.execute('"hello world"')
        self.assert_successful()
        self.assert_token_count(1)
        self.assert_token_equals(0, "hello world", 1, 12) # NOSONAR String literals should not be duplicated (python:S1192)

    def test_one_double_quoted_string_with_pre_padding_returns_one_token(self):
        self.execute(' "hello world"')
        self.assert_successful()
        self.assert_token_count(1)
        self.assert_token_equals(0, "hello world", 2, 13)

    def test_one_double_quoted_string_with_post_padding_returns_one_token(self):
        self.execute('"hello world" ')
        self.assert_successful()
        self.assert_token_count(1)
        self.assert_token_equals(0, "hello world", 1, 12)

    def test_one_double_quoted_string_with_pre_and_post_padding_returns_one_token(self):
        self.execute('  "hello world"  ')
        self.assert_successful()
        self.assert_token_count(1)
        self.assert_token_equals(0, "hello world", 3, 14)

    def test_one_double_quoted_string_with_single_quote_returns_one_token(self):
        self.execute('"isn\'t this nice"')
        self.assert_successful()
        self.assert_token_count(1)
        self.assert_token_equals(0, "isn't this nice", 1, 16)

    def test_one_single_quoted_string_returns_one_token(self):
        self.execute("'hello world'")
        self.assert_successful()
        self.assert_token_count(1)
        self.assert_token_equals(0, "hello world", 1, 12)

    def test_one_single_quoted_string_with_pre_padding_returns_one_token(self):
        self.execute(" 'hello world'")
        self.assert_successful()
        self.assert_token_count(1)
        self.assert_token_equals(0, "hello world", 2, 13)

    def test_one_single_quoted_string_with_post_padding_returns_one_token(self):
        self.execute("'hello world' ")
        self.assert_successful()
        self.assert_token_count(1)
        self.assert_token_equals(0, "hello world", 1, 12)

    def test_one_single_quoted_string_with_pre_and_post_padding_returns_one_token(self):
        self.execute("  'hello world'  ")
        self.assert_successful()
        self.assert_token_count(1)
        self.assert_token_equals(0, "hello world", 3, 14)

    def test_one_single_quoted_string_with_double_quote_returns_one_token(self):
        self.execute("'isn\"t this nice'")
        self.assert_successful()
        self.assert_token_count(1)
        self.assert_token_equals(0, 'isn"t this nice', 1, 16)

    def test_two_words_returns_two_tokens(self):
        self.execute("hello world")
        self.assert_successful()
        self.assert_token_count(2)
        self.assert_token_equals(0, 'hello', 0, 5)
        self.assert_token_equals(1, 'world', 6, 11)

    def test_two_words_with_padding_returns_two_tokens(self):
        self.execute("   hello  world ")
        self.assert_successful()
        self.assert_token_count(2)
        self.assert_token_equals(0, 'hello', 3, 8)
        self.assert_token_equals(1, 'world', 10, 15)

    def test_one_open_bracket_returns_one_token(self):
        self.execute("(")
        self.assert_successful()
        self.assert_token_count(1)
        self.assert_token_equals(0, '(', 0, 1)

    def test_one_open_bracket_with_pre_padding_returns_one_token(self):
        self.execute(" (")
        self.assert_successful()
        self.assert_token_count(1)
        self.assert_token_equals(0, '(', 1, 2)

    def test_one_open_bracket_with_post_padding_returns_one_token(self):
        self.execute("( ")
        self.assert_successful()
        self.assert_token_count(1)
        self.assert_token_equals(0, '(', 0, 1)

    def test_one_open_bracket_with_pre_and_post_padding_returns_one_token(self):
        self.execute("  (  ")
        self.assert_successful()
        self.assert_token_count(1)
        self.assert_token_equals(0, '(', 2, 3)

    def test_two_open_brackets_returns_two_tokens(self):
        self.execute("((")
        self.assert_successful()
        self.assert_token_count(2)
        self.assert_token_equals(0, '(', 0, 1)
        self.assert_token_equals(1, '(', 1, 2)

    def test_one_close_bracket_returns_one_token(self):
        self.execute(")")
        self.assert_successful()
        self.assert_token_count(1)
        self.assert_token_equals(0, ')', 0, 1)

    def test_one_close_bracket_with_pre_padding_returns_one_token(self):
        self.execute(" )")
        self.assert_successful()
        self.assert_token_count(1)
        self.assert_token_equals(0, ')', 1, 2)

    def test_one_close_bracket_with_post_padding_returns_one_token(self):
        self.execute(") ")
        self.assert_successful()
        self.assert_token_count(1)
        self.assert_token_equals(0, ')', 0, 1)

    def test_one_close_bracket_with_pre_and_post_padding_returns_one_token(self):
        self.execute("  )  ")
        self.assert_successful()
        self.assert_token_count(1)
        self.assert_token_equals(0, ')', 2, 3)

    def test_two_close_brackets_returns_two_tokens(self):
        self.execute("))")
        self.assert_successful()
        self.assert_token_count(2)
        self.assert_token_equals(0, ')', 0, 1)
        self.assert_token_equals(1, ')', 1, 2)

    def test_word_followed_by_open_bracket_returns_two_tokens(self):
        self.execute("hello(")
        self.assert_successful()
        self.assert_token_count(2)
        self.assert_token_equals(0, 'hello', 0, 5)
        self.assert_token_equals(1, '(', 5, 6)

    def test_word_followed_by_open_bracket_and_word_returns_three_tokens(self):
        self.execute("hello(world")
        self.assert_successful()
        self.assert_token_count(3)
        self.assert_token_equals(0, 'hello', 0, 5)
        self.assert_token_equals(1, '(', 5, 6)
        self.assert_token_equals(2, 'world', 6, 11)

    def test_word_followed_by_open_bracket_and_word_with_padding_returns_three_tokens(self):
        self.execute("    hello   (  world ")
        self.assert_successful()
        self.assert_token_count(3)
        self.assert_token_equals(0, 'hello', 4, 9)
        self.assert_token_equals(1, '(', 12, 13)
        self.assert_token_equals(2, 'world', 15, 20)

    def test_word_followed_by_close_bracket_returns_two_tokens(self):
        self.execute("hello)")
        self.assert_successful()
        self.assert_token_count(2)
        self.assert_token_equals(0, 'hello', 0, 5)
        self.assert_token_equals(1, ')', 5, 6)

    def test_word_followed_by_close_bracket_and_word_returns_three_tokens(self):
        self.execute("hello)world")
        self.assert_successful()
        self.assert_token_count(3)
        self.assert_token_equals(0, 'hello', 0, 5)
        self.assert_token_equals(1, ')', 5, 6)
        self.assert_token_equals(2, 'world', 6, 11)

    def test_word_followed_by_close_bracket_and_word_with_padding_returns_three_tokens(self):
        self.execute("    hello   )  world ")
        self.assert_successful()
        self.assert_token_count(3)
        self.assert_token_equals(0, 'hello', 4, 9)
        self.assert_token_equals(1, ')', 12, 13)
        self.assert_token_equals(2, 'world', 15, 20)

    def test_unterminated_double_quoted_string_returns_error(self):
        self.execute('"unterminated')
        self.assert_unsuccessful("String not terminated at end of text", 13) # NOSONAR String literals should not be duplicated (python:S1192)

    def test_unterminated_double_quoted_string_containing_single_quote_returns_error(self):
        self.execute('"isn\'t')
        self.assert_unsuccessful("String not terminated at end of text", 6)

    def test_unterminated_double_quoted_string_with_previous_tokens_returns_error(self):
        self.execute('hello world "unterminated')
        self.assert_unsuccessful("String not terminated at end of text", 25)

    def test_unterminated_single_quoted_string_returns_error(self):
        self.execute("'unterminated")
        self.assert_unsuccessful("String not terminated at end of text", 13)

    def test_unterminated_single_quoted_string_containing_double_quote_returns_error(self):
        self.execute("'isn\"t")
        self.assert_unsuccessful("String not terminated at end of text", 6)

    def test_unterminated_single_quoted_string_with_previous_tokens_returns_error(self):
        self.execute("hello world 'unterminated")
        self.assert_unsuccessful("String not terminated at end of text", 25)

    def test_word_following_double_quoted_text_returns_error(self):
        self.execute('"hello"world')
        self.assert_unsuccessful("Expecting delimiter", 7)

    def test_trailing_escape_character_returns_error(self):
        self.execute('hello\\')
        self.assert_unsuccessful("Trailing escape character at end of text", 6)
