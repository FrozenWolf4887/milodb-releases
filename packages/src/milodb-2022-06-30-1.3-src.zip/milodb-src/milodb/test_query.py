import milodb.query as query
from milodb.tease import Tease
from milodb.database import Database, PostfixQueryResult
from milodb.infix_to_postfix import convert, SuccessfulPostfixConversionResult, FailedPostfixConversionResult, Token, get_list_of_field_names, get_list_of_operators, get_list_of_verb_names
import unittest
from typing import Union, Optional, List

MAX_MATCH_COUNT: int = 1_000_000
FIELD_NAMES: List[str] = get_list_of_field_names()
VERB_NAMES: List[str] = get_list_of_verb_names()
HELP_OPERATORS: List[str] = get_list_of_operators()
BINARY_OPERATORS: List[str] = ['and', 'or']
UNARY_OPERATORS: List[str] = ['not']
TEASE_TYPES: List[str] = ['reg', 'aud', 'eos', 'nyx']

FAKE_THUMBNAIL = "https://media.milovana.com/timg/tb_s/73d0969cdbccbf0aa37a5dd2ac1c8962e53ff7a4.jpg"

tease_1: Tease = Tease(
    {
        "aid": 1000,
        "anm": "Miss Minogue",
        "dat": "2019-04-27",
        "rvl": 4.2,
        "sum": "Our problems should be shared.",
        "tgs": ":wonder:wheels-for-feels:with:free:minky:",
        "thm": FAKE_THUMBNAIL,
        "tid": 4801,
        "ttl": "Confide in me",
        "txt": [
            "Stick or twist",
            "What's mine is yours",
            "Hit or miss",
            "We all have a cross to bear"
        ],
        "typ": 2
    })

tease_2: Tease = Tease(
    {
        "aid": 2345,
        "anm": "Lewis",
        "dat": "2017-02-16",
        "rvl": 3.9,
        "sum": "Alice was beginning to get very tired of sitting by her sister on the bank, and of having nothing to do",
        "tgs": ":rabbit:hatter:alice:the-queen-of-hearts:",
        "thm": FAKE_THUMBNAIL,
        "tid": 5673,
        "ttl": "Alice's Adventures in Wonderland",
        "txt": [
            "Alice was not a bit hurt, and she jumped up on to her feet in a moment",
            "She looked up, but it was all dark overhead; before her was another long passage, and the White Rabbit was still in sight, hurrying down it.",
            'There was not a moment to be lost: away went Alice like the wind, and was just in time to hear it say, as it turned a corner, "Oh my ears and whiskers, how late it\'s getting!"',
            "She was close behind it when she turned the corner, but the Rabbit was no longer to be seen",
            "she found herself in a long, low hall, which was lit up by a row of lamps hanging from the roof."
        ],
        "typ": 0
    })

tease_3: Tease = Tease(
    {
        "aid": 7602,
        "anm": "Scott",
        "dat": "2022-03-13",
        "rvl": 1.8,
        "sum": "In a dystopian world, what will become of us all?",
        "tgs": ":dystopia:orwellian:2022:",
        "thm": FAKE_THUMBNAIL,
        "tid": 7129,
        "ttl": "Twenty Twenty Two",
        "txt": [
            "The Author of the Waverley Novels had hitherto proceeded in an unabated course of popularity, and might, in his peculiar district of literature, have been termed L’Enfant Gâté of success.",
            "It was plain, however, that frequent publication must finally wear out the public favour, unless some mode could be devised to give an appearance of novelty to subsequent productions.",
            "Scottish manners, Scottish dialect, and Scottish characters of note, being those with which the author was most intimately,",
            "and familiarly acquainted, were the groundwork upon which he had hitherto relied for giving effect to his narrative."
        ],
        "typ": 1
    })

fake_teases: List[Tease] = [
    tease_1,
    tease_2,
    tease_3
]

fake_database: Database = Database()
fake_database._list_of_teases = fake_teases

class TestQuery(unittest.TestCase):
    def setUp(self):
        self.convert_result: Union[SuccessfulPostfixConversionResult, FailedPostfixConversionResult]
        self.list_of_tokens: List[Token] = []
        self.list_of_tease_matches: List[query.TeaseMatch] = []

    def execute(self, list_of_token_text: Optional[List[str]]) -> None:
        if list_of_token_text is None:
            self.list_of_tokens = []
            self.convert_result = convert(None)
        elif len(list_of_token_text) == 0:
            self.list_of_tokens = []
            self.convert_result = convert(self.list_of_tokens)
        else:
            self.list_of_tokens = self.create_fake_tokens(list_of_token_text)
            self.convert_result = convert(self.list_of_tokens)
        if isinstance(self.convert_result, SuccessfulPostfixConversionResult):
            result: PostfixQueryResult = fake_database.run_postfix_query_chain(self.convert_result.postfix_query_chain, MAX_MATCH_COUNT)
            self.assertFalse(result.was_max_match_count_reached)
            self.list_of_tease_matches = result.list_of_matching_teases

    def create_fake_tokens(self, list_of_token_text: List[str]) -> List[Token]:
        list_of_tokens = []
        token_index: int = 0
        token_start_character: int = 0
        for token_text in list_of_token_text:
            token_end_character: int = token_start_character + len(token_text)
            list_of_tokens.append(Token(token_text, token_index, token_start_character, token_end_character))
            token_start_character = token_end_character + 1
            token_index += 1
        return list_of_tokens

    def assert_unsuccessful(self, error_message: str, error_token_index: Optional[int]) -> None:
        if isinstance(self.convert_result, FailedPostfixConversionResult):
            self.assertEqual(error_message, self.convert_result.cause_of_fault_text,
                f"Expected error message of '{error_message}' but got '{self.convert_result.cause_of_fault_text}'")
            if error_token_index is not None:
                error_token = self.list_of_tokens[error_token_index]
                self.assertIs(error_token, self.convert_result.cause_of_fault_token,
                    'Mismatched error token')
            else:
                self.assertIsNone(self.convert_result.cause_of_fault_token,
                    "Received an error token when one wasn't expected")
        else:
            self.fail("Conversion was successful when it shouldn't have been")

    def assert_successful(self, expected_list_of_tease_matches: List[query.TeaseMatch]) -> None:
        if isinstance(self.convert_result, SuccessfulPostfixConversionResult):
            self.assertEqual(len(expected_list_of_tease_matches), len(self.list_of_tease_matches),
                f'Resulting tease match list expected to contain {len(expected_list_of_tease_matches)} entries but contains {len(self.list_of_tease_matches)}')

            expected_index: int
            expected_tease_match: query.TeaseMatch
            for expected_index, expected_tease_match in enumerate(expected_list_of_tease_matches):
                was_match_found: bool = False
                actual_tease_match: query.TeaseMatch
                for actual_tease_match in self.list_of_tease_matches:
                    was_match_found = self.is_equal_tease_match(expected_tease_match, actual_tease_match)
                    if was_match_found:
                        break
                if not was_match_found:
                    self.fail(f"No match for expected tease match #{expected_index}")
        else:
            self.fail('Conversion failed when it should have succeeded')

    def is_equal_tease_match(self, left: query.TeaseMatch, right: query.TeaseMatch) -> bool:
        if left.tease == right.tease and len(left.list_of_query_matches) == len(right.list_of_query_matches):
            left_query_match: query.QueryMatch
            for left_query_match in left.list_of_query_matches:
                was_match_found: bool = False
                right_query_match: query.QueryMatch
                for right_query_match in right.list_of_query_matches:
                    if isinstance(left_query_match, query.FieldQueryMatch) and isinstance(right_query_match, query.FieldQueryMatch):
                        was_match_found = self.is_equal_field_query_match(left_query_match, right_query_match)
                    elif isinstance(left_query_match, query.FieldStrListQueryMatch) and isinstance(right_query_match, query.FieldStrListQueryMatch):
                        was_match_found = self.is_equal_field_str_list_query_match(left_query_match, right_query_match)
                    if was_match_found:
                        break
                if not was_match_found:
                    return False
            return True
        else:
            return False

    def is_equal_field_query_match(self, left: query.FieldQueryMatch, right: query.FieldQueryMatch) -> bool:
        if left.tease_property == right.tease_property:
            return self.is_equal_list_of_matches(left.list_of_matches, right.list_of_matches)
        else:
            return False

    def is_equal_field_str_list_query_match(self, left: query.FieldStrListQueryMatch, right: query.FieldStrListQueryMatch) -> bool:
        if left.tease_property == right.tease_property and left.index_of_block == right.index_of_block:
            return self.is_equal_list_of_matches(left.list_of_matches, right.list_of_matches)
        else:
            return False

    def is_equal_list_of_matches(self, left_list_of_matches: List[query.MatchDetails], right_list_of_matches: List[query.MatchDetails]) -> bool:
        left_match_details: query.MatchDetails
        for left_match_details in left_list_of_matches:
            was_match_found: bool = False
            right_match_details: query.MatchDetails
            for right_match_details in right_list_of_matches:
                was_match_found = left_match_details.start_index == right_match_details.start_index and left_match_details.end_index == right_match_details.end_index
                if was_match_found:
                    break
            if not was_match_found:
                return False
        return True

    def assert_expected_next_text(self, *expected_lists_of_next_text: Union[List[str], str]) -> None:
        expected_list_of_next_text: List[str] = []
        for arg in expected_lists_of_next_text:
            if isinstance(arg, List):
                expected_list_of_next_text.extend(arg)
            else:
                expected_list_of_next_text.append(arg)

        actual_list_of_next_text: List[str] = self.convert_result.list_of_expected_next_text
        extra_list_of_next_text: List[str] = actual_list_of_next_text.copy()
        missing_list_of_next_text: List[str] = []

        expected_text: str
        for expected_text in expected_list_of_next_text:
            if expected_text in extra_list_of_next_text:
                extra_list_of_next_text.remove(expected_text)
            else:
                missing_list_of_next_text.append(expected_text)

        self.assertFalse(extra_list_of_next_text or missing_list_of_next_text,
            f'Expected next text of {expected_list_of_next_text} but got {actual_list_of_next_text} with the additional items {extra_list_of_next_text} and missing items {missing_list_of_next_text}')

class TestInvalidInputs(TestQuery):
    def test_null_input_yields_error(self):
        self.execute(None)
        self.assert_unsuccessful('Unexpected end of input when expecting a query', None)

    def test_empty_input_yields_error(self):
        self.execute([])
        self.assert_unsuccessful('Unexpected end of input when expecting a query', None)

    def test_invalid_query_yields_error(self):
        self.execute(['mango'])
        self.assert_unsuccessful('Unknown field name or operator', 0)
        self.assert_expected_next_text(FIELD_NAMES, UNARY_OPERATORS, '(')

class TestTitle(TestQuery):
    field = 'title'
    verb_list = ['is', 'contains', 'matches']

    def test_fails_without_verb(self):
        self.execute([self.field])
        self.assert_unsuccessful('Expecting a verb for comparison to field', None)
        self.assert_expected_next_text(self.verb_list)

class TestTitleIs(TestQuery):
    field = 'title'
    verb = 'is'

    def test_fails_without_argument(self):
        self.execute([self.field, self.verb])
        self.assert_unsuccessful('Expecting some text to compare against field', None)

    def test_matches_nothing(self):
        self.execute([self.field, self.verb, 'mango'])
        self.assert_successful([])
        self.assert_expected_next_text(BINARY_OPERATORS)

    def test_matches_whole(self):
        self.execute([self.field, self.verb, 'confiDE in me'])
        matched_field_1: query.QueryMatch = query.FieldQueryMatch(Tease.title, [query.MatchDetails(0, 13)])
        matched_tease_1: query.TeaseMatch = query.TeaseMatch(None, tease_1, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_expected_next_text(BINARY_OPERATORS)

    def test_matches_plain_text_only(self):
        self.execute([self.field, self.verb, 'confiDE.in me'])
        self.assert_successful([])
        self.assert_expected_next_text(BINARY_OPERATORS)

    def test_matches_whole_text_only(self):
        self.execute([self.field, self.verb, 'fide'])
        self.assert_successful([])
        self.assert_expected_next_text(BINARY_OPERATORS)

class TestTitleContains(TestQuery):
    field = 'title'
    verb = 'contains'

    def test_fails_without_argument(self):
        self.execute([self.field, self.verb])
        self.assert_unsuccessful('Expecting some text to compare against field', None)

    def test_matches_nothing(self):
        self.execute([self.field, self.verb, 'mango'])
        self.assert_successful([])
        self.assert_expected_next_text(BINARY_OPERATORS)

    def test_matches_part(self):
        self.execute([self.field, self.verb, 'fIDe'])
        matched_field_1: query.QueryMatch = query.FieldQueryMatch(Tease.title, [query.MatchDetails(3, 7)])
        matched_tease_1: query.TeaseMatch = query.TeaseMatch(None, tease_1, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_expected_next_text(BINARY_OPERATORS)

    def test_matches_multiple_parts(self):
        self.execute([self.field, self.verb, 'wen'])
        matched_field_1: query.QueryMatch = query.FieldQueryMatch(Tease.title, [query.MatchDetails(1, 4), query.MatchDetails(8, 11)])
        matched_tease_1: query.TeaseMatch = query.TeaseMatch(None, tease_3, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_expected_next_text(BINARY_OPERATORS)

    def test_matches_plain_text_only(self):
        self.execute([self.field, self.verb, 'fi.e'])
        self.assert_successful([])
        self.assert_expected_next_text(BINARY_OPERATORS)

class TestTitleMatches(TestQuery):
    field = 'title'
    verb = 'matches'

    def test_fails_without_argument(self):
        self.execute([self.field, self.verb])
        self.assert_unsuccessful('Expecting a regular expression to match against field', None)
        self.assert_expected_next_text([])

    def test_matches_nothing(self):
        self.execute([self.field, self.verb, 'mango'])
        self.assert_successful([])
        self.assert_expected_next_text(BINARY_OPERATORS)

    def test_matches_part(self):
        self.execute([self.field, self.verb, 'fIDe'])
        matched_field_1: query.QueryMatch = query.FieldQueryMatch(Tease.title, [query.MatchDetails(3, 7)])
        matched_tease_1: query.TeaseMatch = query.TeaseMatch(None, tease_1, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_expected_next_text(BINARY_OPERATORS)

    def test_matches_regex(self):
        self.execute([self.field, self.verb, 'on.+in me'])
        matched_field_1: query.QueryMatch = query.FieldQueryMatch(Tease.title, [query.MatchDetails(1, 13)])
        matched_tease_1: query.TeaseMatch = query.TeaseMatch(None, tease_1, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_expected_next_text(BINARY_OPERATORS)

    def test_matches_multiple_regex(self):
        self.execute([self.field, self.verb, 't.+?ty'])
        matched_field_1: query.QueryMatch = query.FieldQueryMatch(Tease.title, [query.MatchDetails(0, 6), query.MatchDetails(7, 13)])
        matched_tease_1: query.TeaseMatch = query.TeaseMatch(None, tease_3, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_expected_next_text(BINARY_OPERATORS)

    def test_fails_with_invalid_regex(self):
        self.execute([self.field, self.verb, 'on(in'])
        self.assert_unsuccessful('Invalid regular expression: missing ), unterminated subpattern at position 2', 2)
        self.assert_expected_next_text([])

class TestRating(TestQuery):
    field = 'rating'
    verb_list = ['=', '>', '<', '>=', '<=']

    def test_fails_without_verb(self):
        self.execute([self.field])
        self.assert_unsuccessful('Expecting a verb for comparison to field', None)
        self.assert_expected_next_text(self.verb_list)

    def test_fails_without_argument(self):
        for verb in self.verb_list:
            with self.subTest(verb = verb):
                self.execute([self.field, verb])
                self.assert_unsuccessful('Expecting a decimal value to compare against field', None)
                self.assert_expected_next_text([])

    def test_fails_with_non_float_argument(self):
        for verb in self.verb_list:
            with self.subTest(verb = verb):
                self.execute([self.field, verb, 'frog'])
                self.assert_unsuccessful('Decimal value expected', 2)
                self.assert_expected_next_text([])

    def test_gt_matches_nothing(self):
        self.execute([self.field, '>', '4.2'])
        self.assert_successful([])
        self.assert_expected_next_text(BINARY_OPERATORS)

    def test_gt_matches_one_item(self):
        self.execute([self.field, '>', '3.9'])
        matched_field_1: query.QueryMatch = query.FieldQueryMatch(Tease.rating_value, [query.MatchDetails(0, 0)])
        matched_tease_1: query.TeaseMatch = query.TeaseMatch(None, tease_1, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_expected_next_text(BINARY_OPERATORS)

    def test_gt_matches_two_items(self):
        self.execute([self.field, '>', '1.8'])
        matched_field_1: query.QueryMatch = query.FieldQueryMatch(Tease.rating_value, [query.MatchDetails(0, 0)])
        matched_tease_1: query.TeaseMatch = query.TeaseMatch(None, tease_1, [matched_field_1])
        matched_tease_2: query.TeaseMatch = query.TeaseMatch(None, tease_2, [matched_field_1])
        self.assert_successful([matched_tease_1, matched_tease_2])
        self.assert_expected_next_text(BINARY_OPERATORS)

    def test_ge_matches_nothing(self):
        self.execute([self.field, '>=', '4.3'])
        self.assert_successful([])
        self.assert_expected_next_text(BINARY_OPERATORS)

    def test_ge_matches_one_item(self):
        self.execute([self.field, '>=', '4.2'])
        matched_field_1: query.QueryMatch = query.FieldQueryMatch(Tease.rating_value, [query.MatchDetails(0, 0)])
        matched_tease_1: query.TeaseMatch = query.TeaseMatch(None, tease_1, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_expected_next_text(BINARY_OPERATORS)

    def test_ge_matches_two_items(self):
        self.execute([self.field, '>=', '3.9'])
        matched_field_1: query.QueryMatch = query.FieldQueryMatch(Tease.rating_value, [query.MatchDetails(0, 0)])
        matched_tease_1: query.TeaseMatch = query.TeaseMatch(None, tease_1, [matched_field_1])
        matched_tease_2: query.TeaseMatch = query.TeaseMatch(None, tease_2, [matched_field_1])
        self.assert_successful([matched_tease_1, matched_tease_2])
        self.assert_expected_next_text(BINARY_OPERATORS)

    def test_lt_matches_nothing(self):
        self.execute([self.field, '<', '1.8'])
        self.assert_successful([])
        self.assert_expected_next_text(BINARY_OPERATORS)

    def test_lt_matches_one_item(self):
        self.execute([self.field, '<', '3.9'])
        matched_field_1: query.QueryMatch = query.FieldQueryMatch(Tease.rating_value, [query.MatchDetails(0, 0)])
        matched_tease_1: query.TeaseMatch = query.TeaseMatch(None, tease_3, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_expected_next_text(BINARY_OPERATORS)

    def test_lt_matches_two_items(self):
        self.execute([self.field, '<', '4.2'])
        matched_field_1: query.QueryMatch = query.FieldQueryMatch(Tease.rating_value, [query.MatchDetails(0, 0)])
        matched_tease_1: query.TeaseMatch = query.TeaseMatch(None, tease_2, [matched_field_1])
        matched_tease_2: query.TeaseMatch = query.TeaseMatch(None, tease_3, [matched_field_1])
        self.assert_successful([matched_tease_1, matched_tease_2])
        self.assert_expected_next_text(BINARY_OPERATORS)

    def test_le_matches_nothing(self):
        self.execute([self.field, '<=', '1.7'])
        self.assert_successful([])
        self.assert_expected_next_text(BINARY_OPERATORS)

    def test_le_matches_one_item(self):
        self.execute([self.field, '<=', '1.8'])
        matched_field_1: query.QueryMatch = query.FieldQueryMatch(Tease.rating_value, [query.MatchDetails(0, 0)])
        matched_tease_1: query.TeaseMatch = query.TeaseMatch(None, tease_3, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_expected_next_text(BINARY_OPERATORS)

    def test_le_matches_two_items(self):
        self.execute([self.field, '<=', '3.9'])
        matched_field_1: query.QueryMatch = query.FieldQueryMatch(Tease.rating_value, [query.MatchDetails(0, 0)])
        matched_tease_1: query.TeaseMatch = query.TeaseMatch(None, tease_2, [matched_field_1])
        matched_tease_2: query.TeaseMatch = query.TeaseMatch(None, tease_3, [matched_field_1])
        self.assert_successful([matched_tease_1, matched_tease_2])
        self.assert_expected_next_text(BINARY_OPERATORS)

    def test_eq_matches_nothing(self):
        self.execute([self.field, '=', '3.1'])
        self.assert_successful([])
        self.assert_expected_next_text(BINARY_OPERATORS)

    def test_eq_matches_one_item(self):
        self.execute([self.field, '=', '3.9'])
        matched_field_1: query.QueryMatch = query.FieldQueryMatch(Tease.rating_value, [query.MatchDetails(0, 0)])
        matched_tease_1: query.TeaseMatch = query.TeaseMatch(None, tease_2, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_expected_next_text(BINARY_OPERATORS)

class TestDate(TestQuery):
    field = 'date'
    verb_list = ['=', '>', '<', '>=', '<=']

    def test_fails_without_verb(self):
        self.execute([self.field])
        self.assert_unsuccessful('Expecting a verb for comparison to field', None)
        self.assert_expected_next_text(self.verb_list)

    def test_fails_without_argument(self):
        for verb in self.verb_list:
            with self.subTest(verb = verb):
                self.execute([self.field, verb])
                self.assert_unsuccessful("Expecting a date in the format 'yyyy-mm-dd' to compare against field", None)
                self.assert_expected_next_text([])

    def test_fails_with_non_float_argument(self):
        for verb in self.verb_list:
            with self.subTest(verb = verb):
                self.execute([self.field, verb, 'frog'])
                self.assert_unsuccessful("Date expected in the format 'yyyy-mm-dd'", 2)
                self.assert_expected_next_text([])

    def test_gt_matches_nothing(self):
        self.execute([self.field, '>', '2022-03-13'])
        self.assert_successful([])
        self.assert_expected_next_text(BINARY_OPERATORS)

    def test_gt_matches_one_item(self):
        self.execute([self.field, '>', '2022-03-12'])
        matched_field_1: query.QueryMatch = query.FieldQueryMatch(Tease.date, [query.MatchDetails(0, 0)])
        matched_tease_1: query.TeaseMatch = query.TeaseMatch(None, tease_3, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_expected_next_text(BINARY_OPERATORS)

    def test_gt_matches_two_items(self):
        self.execute([self.field, '>', '2019-04-26'])
        matched_field_1: query.QueryMatch = query.FieldQueryMatch(Tease.date, [query.MatchDetails(0, 0)])
        matched_tease_1: query.TeaseMatch = query.TeaseMatch(None, tease_1, [matched_field_1])
        matched_tease_2: query.TeaseMatch = query.TeaseMatch(None, tease_3, [matched_field_1])
        self.assert_successful([matched_tease_1, matched_tease_2])
        self.assert_expected_next_text(BINARY_OPERATORS)

    def test_ge_matches_nothing(self):
        self.execute([self.field, '>=', '2022-03-14'])
        self.assert_successful([])
        self.assert_expected_next_text(BINARY_OPERATORS)

    def test_ge_matches_one_item(self):
        self.execute([self.field, '>=', '2022-03-13'])
        matched_field_1: query.QueryMatch = query.FieldQueryMatch(Tease.date, [query.MatchDetails(0, 0)])
        matched_tease_1: query.TeaseMatch = query.TeaseMatch(None, tease_3, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_expected_next_text(BINARY_OPERATORS)

    def test_ge_matches_two_items(self):
        self.execute([self.field, '>=', '2019-04-27'])
        matched_field_1: query.QueryMatch = query.FieldQueryMatch(Tease.date, [query.MatchDetails(0, 0)])
        matched_tease_1: query.TeaseMatch = query.TeaseMatch(None, tease_1, [matched_field_1])
        matched_tease_2: query.TeaseMatch = query.TeaseMatch(None, tease_3, [matched_field_1])
        self.assert_successful([matched_tease_1, matched_tease_2])
        self.assert_expected_next_text(BINARY_OPERATORS)

    def test_lt_matches_nothing(self):
        self.execute([self.field, '<', '2017-02-16'])
        self.assert_successful([])
        self.assert_expected_next_text(BINARY_OPERATORS)

    def test_lt_matches_one_item(self):
        self.execute([self.field, '<', '2017-02-17'])
        matched_field_1: query.QueryMatch = query.FieldQueryMatch(Tease.date, [query.MatchDetails(0, 0)])
        matched_tease_1: query.TeaseMatch = query.TeaseMatch(None, tease_2, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_expected_next_text(BINARY_OPERATORS)

    def test_lt_matches_two_items(self):
        self.execute([self.field, '<', '2019-04-28'])
        matched_field_1: query.QueryMatch = query.FieldQueryMatch(Tease.date, [query.MatchDetails(0, 0)])
        matched_tease_1: query.TeaseMatch = query.TeaseMatch(None, tease_2, [matched_field_1])
        matched_tease_2: query.TeaseMatch = query.TeaseMatch(None, tease_1, [matched_field_1])
        self.assert_successful([matched_tease_1, matched_tease_2])
        self.assert_expected_next_text(BINARY_OPERATORS)

    def test_le_matches_nothing(self):
        self.execute([self.field, '<=', '2017-02-15'])
        self.assert_successful([])
        self.assert_expected_next_text(BINARY_OPERATORS)

    def test_le_matches_one_item(self):
        self.execute([self.field, '<=', '2017-02-16'])
        matched_field_1: query.QueryMatch = query.FieldQueryMatch(Tease.date, [query.MatchDetails(0, 0)])
        matched_tease_1: query.TeaseMatch = query.TeaseMatch(None, tease_2, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_expected_next_text(BINARY_OPERATORS)

    def test_le_matches_two_items(self):
        self.execute([self.field, '<=', '2019-04-27'])
        matched_field_1: query.QueryMatch = query.FieldQueryMatch(Tease.date, [query.MatchDetails(0, 0)])
        matched_tease_1: query.TeaseMatch = query.TeaseMatch(None, tease_2, [matched_field_1])
        matched_tease_2: query.TeaseMatch = query.TeaseMatch(None, tease_1, [matched_field_1])
        self.assert_successful([matched_tease_1, matched_tease_2])
        self.assert_expected_next_text(BINARY_OPERATORS)

    def test_eq_matches_nothing(self):
        self.execute([self.field, '=', '2018-07-02'])
        self.assert_successful([])
        self.assert_expected_next_text(BINARY_OPERATORS)

    def test_eq_matches_one_item(self):
        self.execute([self.field, '=', '2019-04-27'])
        matched_field_1: query.QueryMatch = query.FieldQueryMatch(Tease.date, [query.MatchDetails(0, 0)])
        matched_tease_1: query.TeaseMatch = query.TeaseMatch(None, tease_1, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_expected_next_text(BINARY_OPERATORS)

class TestTag(TestQuery):
    field = 'tag'
    verb_list = ['is', 'contains', 'matches']

    def test_fails_without_verb(self):
        self.execute([self.field])
        self.assert_unsuccessful('Expecting a verb for comparison to field', None)
        self.assert_expected_next_text(self.verb_list)

class TestTagIs(TestQuery):
    field = 'tag'
    verb = 'is'

    def test_fails_without_argument(self):
        self.execute([self.field, self.verb])
        self.assert_unsuccessful('Expecting some text to compare against field list', None)

    def test_matches_nothing(self):
        self.execute([self.field, self.verb, 'mango'])
        self.assert_successful([])
        self.assert_expected_next_text(BINARY_OPERATORS)

    def test_matches_whole(self):
        self.execute([self.field, self.verb, 'Alice'])
        matched_field_1: query.QueryMatch = query.FieldStrListQueryMatch(Tease.list_of_tags, 2, [query.MatchDetails(0, 5)])
        matched_tease_1: query.TeaseMatch = query.TeaseMatch(None, tease_2, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_expected_next_text(BINARY_OPERATORS)

    def test_matches_plain_text_only(self):
        self.execute([self.field, self.verb, 'Al.ce'])
        self.assert_successful([])
        self.assert_expected_next_text(BINARY_OPERATORS)

    def test_matches_whole_text_only(self):
        self.execute([self.field, self.verb, 'topia'])
        self.assert_successful([])
        self.assert_expected_next_text(BINARY_OPERATORS)

class TestTagContains(TestQuery):
    field = 'tag'
    verb = 'contains'

    def test_fails_without_argument(self):
        self.execute([self.field, self.verb])
        self.assert_unsuccessful('Expecting some text to compare against field list', None)

    def test_matches_nothing(self):
        self.execute([self.field, self.verb, 'mango'])
        self.assert_successful([])
        self.assert_expected_next_text(BINARY_OPERATORS)

    def test_matches_part(self):
        self.execute([self.field, self.verb, 'abbi'])
        matched_field_1: query.QueryMatch = query.FieldStrListQueryMatch(Tease.list_of_tags, 0, [query.MatchDetails(1, 5)])
        matched_tease_1: query.TeaseMatch = query.TeaseMatch(None, tease_2, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_expected_next_text(BINARY_OPERATORS)

    def test_matches_multiple_part(self):
        self.execute([self.field, self.verb, 'ee'])
        matched_field_1: query.QueryMatch = query.FieldStrListQueryMatch(Tease.list_of_tags, 1, [query.MatchDetails(2, 4), query.MatchDetails(12, 14)])
        matched_field_2: query.QueryMatch = query.FieldStrListQueryMatch(Tease.list_of_tags, 3, [query.MatchDetails(2, 4)])
        matched_field_3: query.QueryMatch = query.FieldStrListQueryMatch(Tease.list_of_tags, 3, [query.MatchDetails(6, 8)])
        matched_tease_1: query.TeaseMatch = query.TeaseMatch(None, tease_1, [matched_field_1, matched_field_2])
        matched_tease_2: query.TeaseMatch = query.TeaseMatch(None, tease_2, [matched_field_3])
        self.assert_successful([matched_tease_1, matched_tease_2])
        self.assert_expected_next_text(BINARY_OPERATORS)

    def test_matches_plain_text_only(self):
        self.execute([self.field, self.verb, 'ali.e'])
        self.assert_successful([])
        self.assert_expected_next_text(BINARY_OPERATORS)

class TestTagMatches(TestQuery):
    field = 'tag'
    verb = 'matches'

    def test_fails_without_argument(self):
        self.execute([self.field, self.verb])
        self.assert_unsuccessful('Expecting a regular expression to match against field list', None)
        self.assert_expected_next_text([])

    def test_matches_nothing(self):
        self.execute([self.field, self.verb, 'mango'])
        self.assert_successful([])
        self.assert_expected_next_text(BINARY_OPERATORS)

    def test_matches_part(self):
        self.execute([self.field, self.verb, 'fOR'])
        matched_field_1: query.QueryMatch = query.FieldStrListQueryMatch(Tease.list_of_tags, 1, [query.MatchDetails(7, 10)])
        matched_tease_1: query.TeaseMatch = query.TeaseMatch(None, tease_1, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_expected_next_text(BINARY_OPERATORS)

    def test_matches_regex(self):
        self.execute([self.field, self.verb, 'queen.+heart'])
        matched_field_1: query.QueryMatch = query.FieldStrListQueryMatch(Tease.list_of_tags, 3, [query.MatchDetails(4, 18)])
        matched_tease_1: query.TeaseMatch = query.TeaseMatch(None, tease_2, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_expected_next_text(BINARY_OPERATORS)

    def test_matches_multiple_regex(self):
        self.execute([self.field, self.verb, 'e{2}'])
        matched_field_1: query.QueryMatch = query.FieldStrListQueryMatch(Tease.list_of_tags, 1, [query.MatchDetails(2, 4), query.MatchDetails(12, 14)])
        matched_field_2: query.QueryMatch = query.FieldStrListQueryMatch(Tease.list_of_tags, 3, [query.MatchDetails(2, 4)])
        matched_field_3: query.QueryMatch = query.FieldStrListQueryMatch(Tease.list_of_tags, 3, [query.MatchDetails(6, 8)])
        matched_tease_1: query.TeaseMatch = query.TeaseMatch(None, tease_1, [matched_field_1, matched_field_2])
        matched_tease_2: query.TeaseMatch = query.TeaseMatch(None, tease_2, [matched_field_3])
        self.assert_successful([matched_tease_1, matched_tease_2])
        self.assert_expected_next_text(BINARY_OPERATORS)

    def test_fails_with_invalid_regex(self):
        self.execute([self.field, self.verb, 'on(in'])
        self.assert_unsuccessful('Invalid regular expression: missing ), unterminated subpattern at position 2', 2)
        self.assert_expected_next_text([])

class TestTypeIs(TestQuery):
    field = 'type'
    verb = 'is'

    def test_fails_without_argument(self):
        self.execute([self.field, self.verb])
        self.assert_unsuccessful('Expecting a tease type to compare against field', None)
        self.assert_expected_next_text(TEASE_TYPES)

    def test_fails_with_invalid_type(self):
        self.execute([self.field, self.verb, 'mango'])
        self.assert_unsuccessful('Unknown tease type', 2)
        self.assert_expected_next_text(TEASE_TYPES)

    def test_matches_entry(self):
        self.execute([self.field, self.verb, 'reg'])
        matched_field_1: query.QueryMatch = query.FieldQueryMatch(Tease.type, [query.MatchDetails(0, 0)])
        matched_tease_1: query.TeaseMatch = query.TeaseMatch(None, tease_2, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_expected_next_text(BINARY_OPERATORS)

class TestTextContains(TestQuery):
    field = 'text'
    verb = 'contains'

    def test_fails_without_argument(self):
        self.execute([self.field, self.verb])
        self.assert_unsuccessful('Expecting some text to compare against field list', None)

    def test_matches_nothing(self):
        self.execute([self.field, self.verb, 'mango'])
        self.assert_successful([])
        self.assert_expected_next_text(BINARY_OPERATORS)

    def test_matches_one_part_in_one_block_of_one_tease(self):
        self.execute([self.field, self.verb, 'herself'])
        matched_field_1: query.QueryMatch = query.FieldStrListQueryMatch(Tease.list_of_text_blocks, 4, [query.MatchDetails(10, 17)])
        matched_tease_1: query.TeaseMatch = query.TeaseMatch(None, tease_2, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_expected_next_text(BINARY_OPERATORS)

    def test_matches_one_parts_in_multiple_blocks_of_one_tease(self):
        self.execute([self.field, self.verb, 'hitherto'])
        matched_field_1: query.QueryMatch = query.FieldStrListQueryMatch(Tease.list_of_text_blocks, 0, [query.MatchDetails(38, 46)])
        matched_field_2: query.QueryMatch = query.FieldStrListQueryMatch(Tease.list_of_text_blocks, 3, [query.MatchDetails(65, 73)])
        matched_tease_1: query.TeaseMatch = query.TeaseMatch(None, tease_3, [matched_field_1, matched_field_2])
        self.assert_successful([matched_tease_1])
        self.assert_expected_next_text(BINARY_OPERATORS)

    def test_matches_multiple_parts_in_one_block_of_one_tease(self):
        self.execute([self.field, self.verb, 'public'])
        matched_field_1: query.QueryMatch = query.FieldStrListQueryMatch(Tease.list_of_text_blocks, 1, [query.MatchDetails(37, 43), query.MatchDetails(75, 81)])
        matched_tease_1: query.TeaseMatch = query.TeaseMatch(None, tease_3, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_expected_next_text(BINARY_OPERATORS)

    def test_matches_one_part_in_one_block_of_multiple_teases(self):
        self.execute([self.field, self.verb, 'have'])
        matched_field_1: query.QueryMatch = query.FieldStrListQueryMatch(Tease.list_of_text_blocks, 3, [query.MatchDetails(7, 11)])
        matched_field_2: query.QueryMatch = query.FieldStrListQueryMatch(Tease.list_of_text_blocks, 0, [query.MatchDetails(145, 149)])
        matched_tease_1: query.TeaseMatch = query.TeaseMatch(None, tease_1, [matched_field_1])
        matched_tease_2: query.TeaseMatch = query.TeaseMatch(None, tease_3, [matched_field_2])
        self.assert_successful([matched_tease_1, matched_tease_2])
        self.assert_expected_next_text(BINARY_OPERATORS)

    def test_matches_one_part_in_some_blocks_of_multiple_teases(self):
        self.execute([self.field, self.verb, 'which'])
        matched_field_1: query.QueryMatch = query.FieldStrListQueryMatch(Tease.list_of_text_blocks, 4, [query.MatchDetails(39, 44)])
        matched_field_2: query.QueryMatch = query.FieldStrListQueryMatch(Tease.list_of_text_blocks, 2, [query.MatchDetails(86, 91)])
        matched_field_3: query.QueryMatch = query.FieldStrListQueryMatch(Tease.list_of_text_blocks, 3, [query.MatchDetails(52, 57)])
        matched_tease_1: query.TeaseMatch = query.TeaseMatch(None, tease_2, [matched_field_1])
        matched_tease_2: query.TeaseMatch = query.TeaseMatch(None, tease_3, [matched_field_2, matched_field_3])
        self.assert_successful([matched_tease_1, matched_tease_2])
        self.assert_expected_next_text(BINARY_OPERATORS)

    def test_matches_regardless_of_case(self):
        self.execute([self.field, self.verb, 'auTHor'])
        matched_field_1: query.QueryMatch = query.FieldStrListQueryMatch(Tease.list_of_text_blocks, 0, [query.MatchDetails(4, 10)])
        matched_field_2: query.QueryMatch = query.FieldStrListQueryMatch(Tease.list_of_text_blocks, 2, [query.MatchDetails(96, 102)])
        matched_tease_1: query.TeaseMatch = query.TeaseMatch(None, tease_3, [matched_field_1, matched_field_2])
        self.assert_successful([matched_tease_1])
        self.assert_expected_next_text(BINARY_OPERATORS)

    def test_matches_plain_text_only(self):
        self.execute([self.field, self.verb, 'pub.ic'])
        self.assert_successful([])
        self.assert_expected_next_text(BINARY_OPERATORS)

class TestTextMatches(TestQuery):
    field = 'text'
    verb = 'matches'

    def test_fails_without_argument(self):
        self.execute([self.field, self.verb])
        self.assert_unsuccessful('Expecting a regular expression to match against field list', None)

    def test_matches_nothing(self):
        self.execute([self.field, self.verb, 'mango'])
        self.assert_successful([])
        self.assert_expected_next_text(BINARY_OPERATORS)

    def test_matches_one_part_in_one_block_of_one_tease(self):
        self.execute([self.field, self.verb, 'her.elf'])
        matched_field_1: query.QueryMatch = query.FieldStrListQueryMatch(Tease.list_of_text_blocks, 4, [query.MatchDetails(10, 17)])
        matched_tease_1: query.TeaseMatch = query.TeaseMatch(None, tease_2, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_expected_next_text(BINARY_OPERATORS)

    def test_matches_one_parts_in_multiple_blocks_of_one_tease(self):
        self.execute([self.field, self.verb, 'hi[th]{2}erto'])
        matched_field_1: query.QueryMatch = query.FieldStrListQueryMatch(Tease.list_of_text_blocks, 0, [query.MatchDetails(38, 46)])
        matched_field_2: query.QueryMatch = query.FieldStrListQueryMatch(Tease.list_of_text_blocks, 3, [query.MatchDetails(65, 73)])
        matched_tease_1: query.TeaseMatch = query.TeaseMatch(None, tease_3, [matched_field_1, matched_field_2])
        self.assert_successful([matched_tease_1])
        self.assert_expected_next_text(BINARY_OPERATORS)

    def test_matches_multiple_parts_in_one_block_of_one_tease(self):
        self.execute([self.field, self.verb, 'p[a-z]blic'])
        matched_field_1: query.QueryMatch = query.FieldStrListQueryMatch(Tease.list_of_text_blocks, 1, [query.MatchDetails(37, 43), query.MatchDetails(75, 81)])
        matched_tease_1: query.TeaseMatch = query.TeaseMatch(None, tease_3, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_expected_next_text(BINARY_OPERATORS)

    def test_matches_one_part_in_one_block_of_multiple_teases(self):
        self.execute([self.field, self.verb, 'ha[^z]e'])
        matched_field_1: query.QueryMatch = query.FieldStrListQueryMatch(Tease.list_of_text_blocks, 3, [query.MatchDetails(7, 11)])
        matched_field_2: query.QueryMatch = query.FieldStrListQueryMatch(Tease.list_of_text_blocks, 0, [query.MatchDetails(145, 149)])
        matched_tease_1: query.TeaseMatch = query.TeaseMatch(None, tease_1, [matched_field_1])
        matched_tease_2: query.TeaseMatch = query.TeaseMatch(None, tease_3, [matched_field_2])
        self.assert_successful([matched_tease_1, matched_tease_2])
        self.assert_expected_next_text(BINARY_OPERATORS)

    def test_matches_one_part_in_some_blocks_of_multiple_teases(self):
        self.execute([self.field, self.verb, 'which|witch'])
        matched_field_1: query.QueryMatch = query.FieldStrListQueryMatch(Tease.list_of_text_blocks, 4, [query.MatchDetails(39, 44)])
        matched_field_2: query.QueryMatch = query.FieldStrListQueryMatch(Tease.list_of_text_blocks, 2, [query.MatchDetails(86, 91)])
        matched_field_3: query.QueryMatch = query.FieldStrListQueryMatch(Tease.list_of_text_blocks, 3, [query.MatchDetails(52, 57)])
        matched_tease_1: query.TeaseMatch = query.TeaseMatch(None, tease_2, [matched_field_1])
        matched_tease_2: query.TeaseMatch = query.TeaseMatch(None, tease_3, [matched_field_2, matched_field_3])
        self.assert_successful([matched_tease_1, matched_tease_2])
        self.assert_expected_next_text(BINARY_OPERATORS)

    def test_matches_regardless_of_case(self):
        self.execute([self.field, self.verb, 'auTHo[A-Z]'])
        matched_field_1: query.QueryMatch = query.FieldStrListQueryMatch(Tease.list_of_text_blocks, 0, [query.MatchDetails(4, 10)])
        matched_field_2: query.QueryMatch = query.FieldStrListQueryMatch(Tease.list_of_text_blocks, 2, [query.MatchDetails(96, 102)])
        matched_tease_1: query.TeaseMatch = query.TeaseMatch(None, tease_3, [matched_field_1, matched_field_2])
        self.assert_successful([matched_tease_1])
        self.assert_expected_next_text(BINARY_OPERATORS)
