#!/bin/bash

set -e

if [ "$#" -ne 1 ]
then
    echo "Syntax: $(basename "$0") source-directory"
    exit 1
fi

which 7z > /dev/null || { echo "Error: 7zip is required to build the pack"; exit 1; }

sourceDirectory="$1"
databaseDirectory="$(dirname "$0")/../database"
tempDirectory="/tmp/$(date +"%s%N")"

echo "Reading from '$sourceDirectory'"
echo "Assembling in '$tempDirectory'"
echo "Storing in '$databaseDirectory'"

if [ ! -d "$sourceDirectory" ]
then
    echo "Error: '$sourceDirectory' is not a directory"
    exit 1
fi

if [ -e "$tempDirectory" ]
then
    echo "Error: '$tempDirectory' already exists"
    exit 1
fi

if [ ! -d "$databaseDirectory" ]
then
    echo "Error: '$databaseDirectory' is not a directory"
    exit 1
fi

packNumber=1
packFile=""
packAlreadyExists="true"
while [ "$packAlreadyExists" == "true" ]
do
    packName="$databaseDirectory/pack-$(printf %04d "$packNumber")"
    packFile="$packName.7z"
    packDirectory="$packName"
    if [ ! -e "$packDirectory" ] && [ ! -e "$packFile" ]
    then
        packAlreadyExists="false"
    else
        ((packNumber+=1))
    fi
done

echo "Saving to '$packFile'"

if [ -e "$packFile" ]
then
    echo "Error: '$packFile' already exists"
    exit 1
fi

mkdir "$tempDirectory" || exit 1

echo Copy...
cp -r "$sourceDirectory"/* -t "$tempDirectory" || exit 1

echo Index...
rename --filename 's/.+\.txt/metadata.json/' "$tempDirectory"/*.txt || exit 1

echo Renumber...
find "$tempDirectory" -mindepth 2 -maxdepth 2 -type f -name "[0-9].html" -print0 | xargs -0 -L 40 rename --filename 's/^/000/'
find "$tempDirectory" -mindepth 2 -maxdepth 2 -type f -name "[0-9][0-9].html" -print0 | xargs -0 -L 40 rename --filename 's/^/00/'
find "$tempDirectory" -mindepth 2 -maxdepth 2 -type f -name "[0-9][0-9][0-9].html" -print0 | xargs -0 -L 40 rename --filename 's/^/0/'

echo Convert...
find "$tempDirectory" -mindepth 1 -maxdepth 1 -type d -name "[0-9]*" -printf "%f\0" |
    while read -r -d $'\0' teaseId
    do
        echo "TeaseId: $teaseId"
        "$(dirname "$0")/../milodb_admin/plain-html-to-json.py" "$tempDirectory/$teaseId/" "$tempDirectory/$teaseId.reg"
        rm -r "${tempDirectory:?}/${teaseId:?}/"
    done

echo Clean...
rm -f "$tempDirectory"/*.log || exit 1

echo Pack...
7z a -mx9 -myx=9 -ms=on -mqs=on "$packFile" "$tempDirectory"/*

echo Done...
