# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import subprocess
import sys
from pathlib import Path

_THIS_DIRECTORY: Path = Path(__file__).parent.absolute()
_SRC_DIRECTORY: Path = _THIS_DIRECTORY/'src'
_ROOT_DIRECTORY: Path = _THIS_DIRECTORY/'root'

def _assert_directory(path: Path) -> None:
    if not path.is_dir():
        print(f"Error: '{path}' not found")
        sys.exit(1)

def _get_python_interpreter() -> Path:
    python_path: Path = Path(sys.executable)
    if python_path.name.startswith('python'):
        return python_path
    print(f"Error: '{python_path}' is not recognised as a python interpreter")
    sys.exit(1)

def run_from_root_dir(src_script_name: str) -> None:
    _assert_directory(_SRC_DIRECTORY)
    _assert_directory(_ROOT_DIRECTORY)
    python_path: Path = _get_python_interpreter()

    try:
        subprocess.run([ # noqa: S603 `subprocess` call: check for execution of untrusted input
                python_path,
                _SRC_DIRECTORY/src_script_name,
                *sys.argv[1:],
            ],
            cwd = _ROOT_DIRECTORY,
            check = True,
        )
    except subprocess.CalledProcessError as ex:
        print(f'Aborted: {ex}')
