#!/usr/bin/env python3
# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from run_ import run_from_root_dir
if __name__ == "__main__":
    run_from_root_dir('entry_gui.pyw')
