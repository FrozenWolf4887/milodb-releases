# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from dataclasses import dataclass, field
from typing import override
from unittest.mock import Mock, call
from milodb_client.view.terminal.commands import highlight_command
from milodb_common.output.print.i_printer import IPrinter
from milodb_common.parser.expanding_token_stream import ExpandingTokenStream
from milodb_common.util.ref import IRef, SimpleRef
from milodb_common.view.terminal.command_framework.i_command import CommandLoaderResult
from milodb_common_test.parser.error_messages import ErrorMessage
from milodb_common_test.test.strict_mock import InterfaceMock
from milodb_common_test.test.test_command_base import CommandTestBase

@dataclass
class _Args:
    use_highlighting: IRef[bool] = field(default_factory=lambda: SimpleRef(True))
    normal_printer: InterfaceMock = field(default_factory=lambda: InterfaceMock(IPrinter))

class TestHighlightCommand(CommandTestBase):
    @override
    def setUp(self) -> None:
        self._args: _Args = _Args()
        return super().setUp()

    @override
    def load_command(self, token_stream: ExpandingTokenStream) -> CommandLoaderResult:
        return highlight_command.load(
            token_stream,
            self._args.use_highlighting,
            self._args.normal_printer,
        )

    def test_without_arguments_prints_current_setting_without_change(self) -> None:
        for initial_use_highlighting in (True, False):
            with self.subTest(initial_use_highlighting=initial_use_highlighting):
                self.setUp()
                self._args.use_highlighting = SimpleRef(initial_use_highlighting)
                self._args.normal_printer.writeln = Mock()
                self.command_load_and_execute([])
                current_setting: str = 'on' if initial_use_highlighting else 'off'
                self._args.normal_printer.writeln.assert_has_calls([
                    call(f"Current highlighting is '{current_setting}'"),
                    call("Available options are ['on', 'off']")])
                self.assertEqual(initial_use_highlighting, self._args.use_highlighting.get())
                self.assert_next_text(['on', 'off'])

    def test_with_argument_changes_setting_regardless_of_initial_setting(self) -> None:
        for initial_use_highlighting in (True, False):
            for change_use_highlighting in (True, False):
                with self.subTest(initial_use_highlighting=initial_use_highlighting):
                    self.setUp()
                    self._args.use_highlighting = SimpleRef(initial_use_highlighting)
                    self._args.normal_printer.writeln = Mock()
                    new_setting: str = 'on' if change_use_highlighting else 'off'
                    self.command_load_and_execute([new_setting])
                    self._args.normal_printer.writeln.assert_called_once_with(f"Changed highlighting to '{new_setting}'")
                    self.assertEqual(change_use_highlighting, self._args.use_highlighting.get())
                    self.assert_next_text([])

    def test_with_invalid_argument_returns_failure(self) -> None:
        self.command_load(['mango'])
        self.assert_argument_error(1, ErrorMessage.INVALID_EXPECTING_ENUM, ['on', 'off'])

    def test_with_redundant_argument_returns_failure(self) -> None:
        self.command_load(['on', 'off'])
        self.assert_argument_error(2, ErrorMessage.UNEXPECTED, [])
