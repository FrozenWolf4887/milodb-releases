# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import tkinter as tk
from collections.abc import Iterable, Sequence
from tkinter import messagebox, ttk
from typing import TYPE_CHECKING, override
from PIL import ImageTk
from milodb_client.database.tease import Tease
from milodb_client.query.infix_query_parser import InfixError, InfixQueryParser, PostfixQuery
from milodb_client.query.postfix_query_executor import PostfixError, PostfixQueryExecutor, PostfixQueryResult
from milodb_client.query.query import IQuery
from milodb_client.query.tease_match import TeaseMatch
from milodb_client.util.sort_keys import OrderedSortKey
from milodb_client.util.tease_match_sorter import ITeaseMatchSorter
from milodb_client.view.gui import general_layout, general_style, generated_images
from milodb_client.view.gui.query_input_suggester import QueryInputSuggester
from milodb_client.view.gui.query_progress_dialog import QueryProgressDialog
from milodb_client.view.gui.styled_frame import StyledFrame
from milodb_client.view.gui.text_ex import TextEx
from milodb_client.view.gui.theme import get_font_of_themed_widget
from milodb_client.view.gui.util.datum import IDatum
from milodb_client.view.gui.wait_cursor import WaitCursor
from milodb_client.view.gui.wrapped_text import WrappedText
from milodb_common.parser.arg import ArgumentError
from milodb_common.parser.candidate_text import CandidateText
from milodb_common.parser.expanding_token_stream import ExpandedToken, ExpandingTokenStream
from milodb_common.parser.token_stream import TokenStreamError
from milodb_common.util.ref import IRef
from milodb_common.variables.i_user_variables import IUserVariables
if TYPE_CHECKING:
    from milodb_common.parser.token import Token

_LAYOUT_PADDING_X: int = general_layout.PANEL_PADDING_X

class RawQueryPanel(StyledFrame):
    def __init__(self, master: tk.Misc, list_of_teases: Sequence[Tease], user_variables: IUserVariables, list_of_tease_matches: IRef[Sequence[TeaseMatch]], selected_tease_index: IRef[int | None], tease_match_sorter: ITeaseMatchSorter, list_of_active_sort_keys: IRef[Sequence[OrderedSortKey]], variables_changed_event: IDatum) -> None:
        super().__init__(master, style=general_style.FRAME_PANEL)

        self._list_of_teases: Sequence[Tease] = list_of_teases
        self._user_variables: IUserVariables = user_variables
        self._list_of_tease_matches: IRef[Sequence[TeaseMatch]] = list_of_tease_matches
        self._selected_tease_index: IRef[int | None] = selected_tease_index
        self._tease_match_sorter: ITeaseMatchSorter = tease_match_sorter
        self._list_of_active_sort_keys: IRef[Sequence[OrderedSortKey]] = list_of_active_sort_keys
        self._variables_changed_event: IDatum = variables_changed_event

        self._infix_parser: InfixQueryParser = InfixQueryParser()
        self._postfix_executor: PostfixQueryExecutor = PostfixQueryExecutor()
        self._query_input_suggester: QueryInputSuggester = QueryInputSuggester(self._user_variables, self._infix_parser)
        self._last_postfix_query: PostfixQuery | None = None

        ttk.Label(self, text='Query', anchor=tk.W, justify=tk.LEFT, style=general_style.LABEL_TABLE_HEADER).grid(row=0, column=0, sticky=tk.NSEW)
        ttk.Label(self, text='Suggestion', anchor=tk.W, justify=tk.LEFT, style=general_style.LABEL_TABLE_HEADER).grid(row=1, column=0, sticky=tk.NSEW)
        ttk.Label(self, text='Expansion', anchor=tk.W, justify=tk.LEFT, style=general_style.LABEL_TABLE_HEADER).grid(row=2, column=0, sticky=tk.NSEW)
        ttk.Label(self, text='Status', anchor=tk.W, justify=tk.LEFT, style=general_style.LABEL_TABLE_HEADER).grid(row=3, column=0, sticky=tk.NSEW)
        ttk.Label(self, text='Expected', anchor=tk.W, justify=tk.LEFT, style=general_style.LABEL_TABLE_HEADER).grid(row=4, column=0, sticky=tk.NSEW)

        self._query_entry: TextEx = TextEx(self)
        self._query_entry.grid(row=0, column=2, sticky=tk.EW)
        self._query_entry.bind(TextEx.CARET_MOVED_BINDING, self._on_caret_moved)
        self._query_entry.bind(TextEx.TEXT_CHANGED_BINDING, self._on_text_changed)
        self._query_entry.bind('<Return>', self._on_return_pressed)
        self._query_entry.bind('<Tab>', self._on_tab_pressed)

        font_line_height: int = get_font_of_themed_widget(self, self._query_entry).metrics('linespace')

        self._input_valid_image: ImageTk.PhotoImage = ImageTk.PhotoImage(generated_images.render_input_valid_image(image_height=font_line_height))
        self._input_invalid_image: ImageTk.PhotoImage = ImageTk.PhotoImage(generated_images.render_input_invalid_image(image_height=font_line_height))

        self._query_icon: ttk.Label = ttk.Label(self, image=self._input_invalid_image)
        self._query_icon.grid(row=0, column=1, padx=_LAYOUT_PADDING_X)

        self._suggestions_label: ttk.Label = ttk.Label(self, anchor=tk.W, justify=tk.LEFT)
        self._suggestions_label.grid(row=1, column=1, columnspan=2, sticky=tk.EW)

        self._expansion_text: WrappedText = WrappedText(self, is_readonly=True, style=general_style.TEXT_BORDERLESS)
        self._expansion_text.grid(row=2, column=1, columnspan=2, sticky=tk.EW)
        self._expansion_text.tag_config('err', foreground='#F88', selectforeground='#800', underline=True, underlinefg='#F88')

        self._status_label: ttk.Label = ttk.Label(self, anchor=tk.W, justify=tk.LEFT)
        self._status_label.grid(row=3, column=1, columnspan=2, sticky=tk.EW)

        self._expected_label: ttk.Label = ttk.Label(self, anchor=tk.W, justify=tk.LEFT)
        self._expected_label.grid(row=4, column=1, columnspan=2, sticky=tk.EW)

        self.columnconfigure(2, weight=1)

        self._variables_changed_event.add_listener(self._on_variables_changed)

        self._provide_input_suggestions('', 0)
        self._validate_input('')

    @override
    def destroy(self) -> None:
        self._variables_changed_event.remove_listener(self._on_variables_changed)

    def set_focus(self) -> None:
        self._query_entry.focus()

    def _on_caret_moved(self, _: object) -> None:
        caret_index: int = self._query_entry.get_caret_index()
        user_input: str = self._query_entry.get_text()
        self._provide_input_suggestions(user_input, caret_index)

    def _on_text_changed(self, _: object) -> None:
        user_input: str = self._query_entry.get_text()
        self._validate_input(user_input)

    def _on_return_pressed(self, _: object) -> str:
        if self._last_postfix_query:
            self._execute_query(self._last_postfix_query.query_chain)
        return 'break'

    def _on_tab_pressed(self, _: object) -> str | None:
        if self._query_input_suggester.list_of_suggestions:
            list_of_completion_text: list[str] = [
                f'{candidate.text}{candidate.following_delimiter}'[self._query_input_suggester.suggestion_starting_index:]
                for candidate in self._query_input_suggester.list_of_suggestions
            ]

            completion_text: str
            if len(list_of_completion_text) > 1:
                length_of_shortest_completion_text: int = min(len(text) for text in list_of_completion_text)
                completion_length: int = 0
                for completion_length in range(length_of_shortest_completion_text):
                    if len({text[completion_length] for text in list_of_completion_text}) != 1:
                        break
                completion_text = list_of_completion_text[0][:completion_length]
            else:
                completion_text = list_of_completion_text[0]

            self._query_entry.selection_clear()
            self._query_entry.insert(tk.INSERT, completion_text)
        return 'break'

    def _execute_query(self, postfix_query_chain: Sequence[IQuery]) -> None:
        with WaitCursor(self.winfo_toplevel()), QueryProgressDialog(self.winfo_toplevel(), len(self._list_of_teases)) as query_progress_dialog:
            try:
                result: PostfixQueryResult = self._postfix_executor.execute(self._list_of_teases, postfix_query_chain, 10_000_000, query_progress_dialog.show_progress)
            except PostfixError as ex:
                messagebox.showerror(
                    title='Unexpected error',
                    message='Unexpected fault in postfix query chain',
                    detail=ex.message,
                )
                return

        self._selected_tease_index.set(None)
        self._list_of_tease_matches.set(self._tease_match_sorter.sort(result.list_of_tease_matches, self._list_of_active_sort_keys.get()))
        if result.list_of_tease_matches:
            self._selected_tease_index.set(0)

        if result.was_max_match_count_reached:
            percentage_searched: float = 0.0
            if result.queried_tease_count != 0:
                percentage_searched = 100.0 * result.queried_tease_count / result.total_tease_count
            messagebox.showwarning(
                title='Limit reached',
                message=f'Limit of {result.max_match_count:,} matching items was reached.',
                detail=(
                    f'Search stopped with {result.total_match_count:,} matching items.\n'
                    f'Searched {result.queried_tease_count:,} of {result.total_tease_count:,} teases ({percentage_searched:.1f}%).'
                ),
            )

    def _validate_input(self, text: str) -> None:
        token_stream: ExpandingTokenStream = ExpandingTokenStream(text, self._user_variables)
        token_stream.set_keep_delimiters('()')

        fault_token: Token | None = None

        self._last_postfix_query = None
        try:
            self._last_postfix_query = self._infix_parser.convert_to_postfix(token_stream)
        except TokenStreamError as ex:
            self._status_label.config(text=f'Token Error: {ex.cause_of_fault_text}')
            if not (fault_token := ex.cause_of_fault_token):
                self._query_entry.show_error(ex.cause_of_fault_character_index)
            self._expected_label.config(text=_get_expected_text(ex.list_of_candidate_text))
        except ArgumentError as ex:
            self._status_label.config(text=f"Argument Error: {ex.message}")
            if not (fault_token := ex.fault_token):
                self._query_entry.clear_error()
            self._expected_label.config(text=_get_expected_text(ex.list_of_candidate_text))
        except InfixError as ex:
            self._status_label.config(text=f'Infix Error: {ex.message}')
            if not (fault_token := ex.fault_token):
                self._query_entry.clear_error()
            self._expected_label.config(text=_get_expected_text(ex.list_of_candidate_text))
        else:
            self._query_entry.clear_error()
            self._status_label.config(text='Okay')
            self._expected_label.config(text=_get_expected_text(self._last_postfix_query.list_of_candidate_text))

        self._expansion_text.delete('1.0', tk.END)
        self._expansion_text.insert('1.0', token_stream.get_expanded_raw_text() + token_stream.get_remaining_raw_text())
        self._expansion_text.tag_remove('err', '1.0', tk.END)
        if fault_token:
            self._expansion_text.tag_add('err', f'1.{fault_token.inner_indices.start}', f'1.{fault_token.inner_indices.end}')
            topmost_fault_token: Token = fault_token.topmost_token if isinstance(fault_token, ExpandedToken) else fault_token
            self._query_entry.show_error(topmost_fault_token.inner_indices.start, topmost_fault_token.inner_indices.end)

        self._query_icon.config(image=self._input_valid_image if self._last_postfix_query else self._input_invalid_image)

    def _provide_input_suggestions(self, text: str, cursor_index: int) -> None:
        self._query_input_suggester.update(text, cursor_index)
        self._suggestions_label.config(text=_get_expected_text(self._query_input_suggester.list_of_suggestions))

    def _on_variables_changed(self) -> None:
        user_input: str = self._query_entry.get_text()
        self._validate_input(user_input)

def _get_expected_text(list_of_candidate_text: Iterable[CandidateText]) -> str:
    return ', '.join([
        f'{candidate_text.text}{candidate_text.following_delimiter}' for candidate_text in sorted(list_of_candidate_text, key=lambda ct: ct.text)
    ])
