# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import re
from abc import ABC, abstractmethod
from enum import Enum
from typing import override
from milodb_client.view.gui.text_ex import TextEx

class ValidationResult(Enum):
    EMPTY = 0
    VALID = 1
    INVALID = 2

class IValidator(ABC):
    @abstractmethod
    def validate(self) -> ValidationResult:
        pass

class TrueValidator(IValidator):
    def __init__(self, entry: TextEx) -> None:
        self._entry = entry

    @override
    def validate(self) -> ValidationResult:
        self._entry.clear_error()
        if self._entry.get_text():
            return ValidationResult.VALID
        return ValidationResult.EMPTY

class RegexValidator(IValidator):
    def __init__(self, entry: TextEx) -> None:
        self._entry = entry

    @override
    def validate(self) -> ValidationResult:
        text: str = self._entry.get_text()
        if text:
            try:
                re.compile(text)
            except re.error as ex:
                self._entry.show_error(ex.colno - 1)
                return ValidationResult.INVALID
            self._entry.clear_error()
            return ValidationResult.VALID
        return ValidationResult.EMPTY
