# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/

BANNER_NO_SELECTED_TEASE: str = 'no\nselected\ntease'
BANNER_NO_MATCHING_TEASES: str = 'no\nmatching\nteases'
BANNER_NO_MATCHING_TEXT: str = 'no\nmatching\ntext'
BANNER_NO_TEXT: str = 'no\ntext'
