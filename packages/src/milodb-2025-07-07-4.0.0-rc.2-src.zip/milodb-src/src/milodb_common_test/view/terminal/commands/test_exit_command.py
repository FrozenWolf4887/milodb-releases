# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from dataclasses import dataclass, field
from typing import override
from milodb_common.parser.expanding_token_stream import ExpandingTokenStream
from milodb_common.view.terminal.command_framework.i_command import CommandLoaderResult
from milodb_common.view.terminal.command_framework.quit_flag import QuitFlag
from milodb_common.view.terminal.commands import exit_command
from milodb_common_test.parser.error_messages import ErrorMessage
from milodb_common_test.test.test_command_base import CommandTestBase

@dataclass
class _Args:
    quit_flag: QuitFlag = field(default_factory=QuitFlag)

class TestExitCommand(CommandTestBase):
    @override
    def setUp(self) -> None:
        self._args: _Args = _Args()
        return super().setUp()

    @override
    def load_command(self, token_stream: ExpandingTokenStream) -> CommandLoaderResult:
        return exit_command.load(
            token_stream,
            self._args.quit_flag,
        )

    def test_without_arguments_sets_quit_flag(self) -> None:
        self.command_load_and_execute([])
        self.assertTrue(self._args.quit_flag)
        self.assert_next_text([])

    def test_with_redundant_argument_returns_failure(self) -> None:
        self.command_load(['now'])
        self.assert_argument_error(1, ErrorMessage.UNEXPECTED, [])
