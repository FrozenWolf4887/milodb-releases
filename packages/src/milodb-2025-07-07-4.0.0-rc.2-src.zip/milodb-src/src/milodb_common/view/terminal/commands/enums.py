# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from enum import Enum

class OnOrOff(Enum):
    ON = True
    OFF = False
