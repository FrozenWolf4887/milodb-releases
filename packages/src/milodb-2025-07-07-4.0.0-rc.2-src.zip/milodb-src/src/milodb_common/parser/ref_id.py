# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from dataclasses import dataclass

@dataclass
class MatchIndex:
    match_index: int

@dataclass
class TeaseId:
    tease_id: int

@dataclass
class AuthorId:
    author_id: int

type RefId = MatchIndex | TeaseId | AuthorId
