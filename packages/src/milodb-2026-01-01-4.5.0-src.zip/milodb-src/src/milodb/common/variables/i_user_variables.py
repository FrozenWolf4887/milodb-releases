# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import re
from abc import ABC, abstractmethod
from collections.abc import Sequence
from milodb.common.output.print.i_printer import IPrinter

VARIABLE_NAME_PATTERN: re.Pattern[str] = re.compile(r"[\w\-\+]+")
VARIABLE_FULL_NAME_PATTERN: re.Pattern[str] = re.compile(r'\$' + VARIABLE_NAME_PATTERN.pattern)

class IUserVariables(ABC):
    @abstractmethod
    def try_retrieve(self, name: str) -> str | None:
        pass

    @abstractmethod
    def get_list_of_names(self) -> Sequence[str]:
        pass

    @abstractmethod
    def get_list_of_variables(self) -> Sequence[tuple[str, str]]:
        pass

class IEditableUserVariables(IUserVariables):
    @abstractmethod
    def set(self, name: str, value: str) -> None:
        pass

    @abstractmethod
    def try_delete(self, name: str) -> bool:
        pass

    @abstractmethod
    def delete_all(self) -> None:
        pass

class IPersistentUserVariables(IEditableUserVariables):
    @abstractmethod
    def load(self, normal_printer: IPrinter, warning_printer: IPrinter, error_printer: IPrinter) -> None:
        pass

    @abstractmethod
    def save(self, normal_printer: IPrinter, warning_printer: IPrinter, error_printer: IPrinter) -> None:
        pass
