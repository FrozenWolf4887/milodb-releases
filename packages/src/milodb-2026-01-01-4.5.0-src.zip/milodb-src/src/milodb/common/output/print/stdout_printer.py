# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import sys
from typing import override
from milodb.common.output.print.i_printer import IPrinter

class StdoutPrinter(IPrinter):
    def __init__(self) -> None:
        self._is_on_new_line: bool = True

    @override
    def write(self, text: str) -> None:
        if text:
            print(text, end='') # noqa: T201 `print` found
            sys.stdout.flush()
            self._is_on_new_line = text[-1] == '\n'

    @override
    def writeln(self, text: str | None = None) -> None:
        if text:
            print(text) # noqa: T201 `print` found
        else:
            print() # noqa: T201 `print` found
        self._is_on_new_line = True

    @property
    @override
    def is_on_new_line(self) -> bool:
        return self._is_on_new_line
