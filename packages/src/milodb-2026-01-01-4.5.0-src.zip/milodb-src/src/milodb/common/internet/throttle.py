# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import time

class Throttle:
    def __init__(self, *, min_seconds_between_yields: float) -> None:
        self._min_seconds_between_yields: float = min_seconds_between_yields
        self._next_yield_time_seconds: float = 0.0

    def apply_throttle_delay(self) -> None:
        now_seconds: float = time.monotonic()
        if now_seconds < self._next_yield_time_seconds:
            time.sleep(self._next_yield_time_seconds - now_seconds)
        self._next_yield_time_seconds = now_seconds + self._min_seconds_between_yields
