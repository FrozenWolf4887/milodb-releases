# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from collections.abc import Mapping, Sequence
from milodb.common.parser.arg_type import ArgType
from milodb.common.parser.expanding_token_stream import ExpandedToken, ExpandingTokenStream
from milodb.common.parser.token import Token
from milodb.common.variables.i_user_variables import IUserVariables

class ArgTokenStream(ExpandingTokenStream):
    def __init__(self, text: str, variables: IUserVariables, discard_delimiters: str | None = None, keep_delimiters: str | None = None, stop_before_character_index: int | None = None) -> None:
        super().__init__(text, variables, discard_delimiters, keep_delimiters, stop_before_character_index)
        self._list_of_popped_tokens: list[ExpandedToken] = []
        self._map_of_token_to_arg_type: dict[int, ArgType] = {}

    def next_arg(self, arg_type: ArgType) -> ExpandedToken | None:
        token: ExpandedToken | None = self.next()
        if token:
            self._list_of_popped_tokens.append(token)
            self._map_of_token_to_arg_type[token.token_number] = arg_type
        return token

    def set_token_arg_type(self, token: Token, arg_type: ArgType) -> None:
        self._map_of_token_to_arg_type[token.token_number] = arg_type

    @property
    def list_of_popped_tokens(self) -> Sequence[ExpandedToken]:
        return self._list_of_popped_tokens

    @property
    def map_of_token_number_to_arg_type(self) -> Mapping[int, ArgType]:
        return self._map_of_token_to_arg_type
