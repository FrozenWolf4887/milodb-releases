# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from typing import override
from milodb.client.updater.manifest.common_manifest import IHexDigest

_SHA_HASHING_NAME: str = 'SHA3-224'
_SHA_DIGEST_LENGTH_BYTES: int = 28

class HexDigest(IHexDigest):
    def __init__(self, digest_bytes: bytes) -> None:
        self._digest_bytes: bytes = digest_bytes

    @override
    def __str__(self) -> str:
        return self._digest_bytes.hex()

    @override
    def __hash__(self) -> int:
        return hash(self._digest_bytes)

    @override
    def __eq__(self, other: object) -> bool:
        if isinstance(other, IHexDigest):
            return self._digest_bytes == other.digest_bytes
        return False

    @override
    def __ne__(self, other: object) -> bool:
        return not self.__eq__(other)

    @property
    @override
    def digest_bytes(self) -> bytes:
        return self._digest_bytes

    @staticmethod
    def parse(text: str) -> IHexDigest:
        """Parse the given text into a IHexDigest object.

        ### Format:
        The text should be a string of 56 hexadecimal characters with optional spaces.

        ### Raises:
        - HexDigestError
        """
        try:
            digest_bytes: bytes = bytes.fromhex(text)
        except ValueError:
            pass
        else:
            if len(digest_bytes) == _SHA_DIGEST_LENGTH_BYTES:
                return HexDigest(digest_bytes)

        msg = f"'{text}' is not a {_SHA_HASHING_NAME} hexadecimal digest"
        raise HexDigestError(msg)

class HexDigestError(Exception):
    pass
