# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import tkinter as tk
from io import StringIO
from milodb.client.output.ellipsis import EllipsisLocation, ellipsify_text
from milodb.client.output.match_indices import iterate_match_indices
from milodb.client.query.field_match import IFieldMatch
from milodb.client.view.gui.util.tk_index import TkIndex
from milodb.client.view.gui.widgets.styled_text import StyledText

_ELLIPSIS_TEXT: str = '\u2026'

def add_highlighted_text(*, text_widget: StyledText, text: str, list_of_indices: list[IFieldMatch.Indices], tag_highlight: str) -> None:
    tk_index: TkIndex = TkIndex.parse_str_index_or_default(text_widget.index(tk.INSERT))
    text_widget.insert(tk.INSERT, text)

    def on_normal_text(text: str, *, is_first_item: bool, is_last_item: bool) -> None: # pylint: disable=unused-argument # noqa: ARG001 Unused function argument
        nonlocal tk_index
        tk_index.move_with_text(text)

    def on_matched_text(text: str, *, is_first_item: bool, is_last_item: bool) -> None: # pylint: disable=unused-argument # noqa: ARG001 Unused function argument
        nonlocal tk_index
        start_character_index: str = str(tk_index)
        tk_index.move_with_text(text)
        text_widget.tag_add(tag_highlight, start_character_index, str(tk_index))

    iterate_match_indices(text, list_of_indices, on_normal_text, on_matched_text)

def add_abbreviated_and_highlighted_text(*, text_widget: StyledText, text: str, list_of_indices: list[IFieldMatch.Indices], tag_highlight: str, ellipsis_width: int, tag_ellipsis: str) -> None:
    list_of_highlight_index_pairs: list[str] = []
    list_of_ellipsis_index_pairs: list[str] = []
    tk_index: TkIndex = TkIndex.parse_str_index_or_default(text_widget.index(tk.INSERT))
    built_text: StringIO = StringIO()

    def on_normal_text(text: str, *, is_first_item: bool, is_last_item: bool) -> None:
        ellipsify_text(text, ellipsis_width, EllipsisLocation.from_position(is_first_item=is_first_item, is_last_item=is_last_item), on_text, on_ellipsis)

    def on_matched_text(text: str, *, is_first_item: bool, is_last_item: bool) -> None: # pylint: disable=unused-argument # noqa: ARG001 Unused function argument
        built_text.write(text)
        list_of_highlight_index_pairs.append(str(tk_index))
        tk_index.move_with_text(text)
        list_of_highlight_index_pairs.append(str(tk_index))

    def on_text(text: str) -> None:
        built_text.write(text)
        tk_index.move_with_text(text)

    def on_ellipsis() -> None:
        built_text.write(_ELLIPSIS_TEXT)
        list_of_ellipsis_index_pairs.append(str(tk_index))
        tk_index.move_with_text(_ELLIPSIS_TEXT)
        list_of_ellipsis_index_pairs.append(str(tk_index))

    iterate_match_indices(text, list_of_indices, on_normal_text, on_matched_text)

    text_widget.insert(tk.INSERT, built_text.getvalue())

    if list_of_highlight_index_pairs:
        text_widget.tag_add(tag_highlight, list_of_highlight_index_pairs[0], *list_of_highlight_index_pairs[1:])
    if list_of_ellipsis_index_pairs:
        text_widget.tag_add(tag_ellipsis, list_of_ellipsis_index_pairs[0], *list_of_ellipsis_index_pairs[1:])
