# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import tkinter as tk
from collections.abc import Callable
from threading import Thread

class _TkThread[T]:
    def __init__(self, worker: Callable[[], T], root: tk.Misc, name: str) -> None:
        self._worker: Callable[[], T] = worker
        self._root: tk.Misc = root

        self._result: T
        self._thread: Thread = Thread(target=self._execute, name=name)
        self._finished_flag: tk.BooleanVar = tk.BooleanVar()
        self._thread.start()
        self._root.wait_variable(self._finished_flag)
        self._thread.join()

    def _execute(self) -> None:
        self._result = self._worker()
        self._finished_flag.set(True)

    @property
    def result(self) -> T:
        return self._result

def run_tk_thread_routine[T](worker: Callable[[], T], root: tk.Misc, name: str) -> T:
    return _TkThread(worker, root, name).result
