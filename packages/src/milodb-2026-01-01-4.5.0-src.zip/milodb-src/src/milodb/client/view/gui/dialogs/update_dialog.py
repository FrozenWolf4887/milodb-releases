# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from __future__ import annotations
import functools
import time
import tkinter as tk
from pathlib import Path
from tkinter import ttk
from typing import TYPE_CHECKING
from milodb.client.updater.cached_remote_update_data import CachedRemoteUpdateData
from milodb.client.updater.i_temp_directory import ITempDirectory, ITempDirectoryCreator, TempDirectoryError
from milodb.client.updater.prepare_update import PrepareUpdateError, prepare_update
from milodb.client.updater.update_potential import UpdatePotential
from milodb.client.updater.update_strategy import FileRename, UpdateStrategy, UpdateStrategyError, determine_update_strategy
from milodb.client.view.gui.dialogs.modal_dialog import ModalDialog
from milodb.client.view.gui.dialogs.prompt_dialog import PromptDialog
from milodb.client.view.gui.theme import Style
from milodb.client.view.gui.widgets.log_text import LogText
from milodb.client.view.gui.widgets.scrollable_frame import ScrollableFrame
from milodb.client.view.gui.widgets.styled_frame import StyledFrame
from milodb.client.view.gui.widgets.wrapping_label import WrappingLabel
from milodb.common.util.unit_size import UnitSizeText, unit_size
if TYPE_CHECKING:
    from collections.abc import Callable
    from milodb.client.config.update_config import UpdateConfig
    from milodb.client.startup.shutdown_action import IShutdownAction
    from milodb.client.updater.i_file_hasher import IFileHasher
    from milodb.client.updater.i_file_tester import IFileTester
    from milodb.client.updater.manifest.local_manifest import ILocalManifest
    from milodb.client.updater.manifest.update_directory import IAsset, IAssetRegister
    from milodb.client.updater.manifest.version_manifest import ICoreFile, IVersion, IVariant
    from milodb.common.internet.i_scraper import IUrlScraperFactory
    from milodb.common.util.ref import IRef

_TABLE_GRIDLINE_THICKNESS: int = 1

_CANCEL_BUTTON_COLUMN: int = 0
_UPDATE_BUTTON_COLUMN: int = 1

class UpdateDialog(ModalDialog):
    def __init__(self, master: tk.Toplevel | tk.Tk, update_config: UpdateConfig, local_manifest: ILocalManifest | None, file_hasher: IFileHasher, file_tester: IFileTester, url_scraper_factory: IUrlScraperFactory, temp_directory_creator: ITempDirectoryCreator, ref_shutdown_action: IRef[IShutdownAction | None], shutdown_app: Callable[[], None]) -> None:
        super().__init__(master, title='Update')

        self._update_config: UpdateConfig = update_config
        self._local_manifest: ILocalManifest | None = local_manifest
        self._file_hasher: IFileHasher = file_hasher
        self._file_tester: IFileTester = file_tester
        self._url_scraper_factory: IUrlScraperFactory = url_scraper_factory
        self._temp_directory_creator: ITempDirectoryCreator = temp_directory_creator
        self._ref_shutdown_action: IRef[IShutdownAction | None] = ref_shutdown_action
        self._shutdown_app: Callable[[], None] = shutdown_app

        self._notebook: ttk.Notebook = ttk.Notebook(self.content_frame)
        self._notebook.pack(fill=tk.BOTH, expand=True)
        self._update_status_label: ttk.Label = ttk.Label(self.content_frame, justify=tk.CENTER, anchor=tk.N)
        self._update_status_label.pack(fill=tk.X)

        self.add_button('Cancel', column=_CANCEL_BUTTON_COLUMN, command=self._on_cancel_button)
        self.add_button('Update', column=_UPDATE_BUTTON_COLUMN, command=self._on_update_button, is_hidden=True)

        self._log_text: LogText = LogText(self._notebook)
        self._log_text.pack(fill=tk.BOTH, expand=True)
        self._log_tab_index: object = self._notebook.index(tk.END)
        self._notebook.add(self._log_text, text='Log')

        self._update_frame: ScrollableFrame = ScrollableFrame(self._notebook)
        self._update_frame.top_frame.pack(fill=tk.BOTH, expand=True)
        self._update_tab_index: object = self._notebook.index(tk.END)
        self._notebook.add(self._update_frame.top_frame, text='Update', state=tk.HIDDEN)

        self._analysis_frame: ScrollableFrame = ScrollableFrame(self._notebook)
        self._analysis_frame.top_frame.pack(fill=tk.BOTH, expand=True)
        self._analysis_tab_index: object = self._notebook.index(tk.END)
        self._notebook.add(self._analysis_frame.top_frame, text='Analysis', state=tk.HIDDEN)

        self._backup_frame: ScrollableFrame = ScrollableFrame(self._notebook)
        self._backup_frame.top_frame.pack(fill=tk.BOTH, expand=True)
        self._backup_tab_index: object = self._notebook.index(tk.END)
        self._notebook.add(self._backup_frame.top_frame, text='Backup', state=tk.HIDDEN)

        self._variants_frame: ScrollableFrame = ScrollableFrame(self._notebook)
        self._variants_frame.top_frame.pack(fill=tk.BOTH, expand=True)
        self._variants_tab_index: object = self._notebook.index(tk.END)
        self._notebook.add(self._variants_frame.top_frame, text='Variants', state=tk.HIDDEN)

        self._requested_variant_name: str | None = None

        if self._local_manifest:
            self._check_for_updates(self._local_manifest)
        else:
            self._update_status_label.config(text='Local manifest unavailable, update impossible', style=Style.OnDialog.StatusLabel.Error.STYLE_NAME)

    def _check_for_updates(self, local_manifest: ILocalManifest) -> None:
        self._notebook.select(self._log_tab_index)
        _hide_tabs(self._notebook, self._update_tab_index, self._analysis_tab_index, self._backup_tab_index, self._variants_tab_index)
        _clear_frames(self._variants_frame.content_frame, self._analysis_frame.content_frame, self._backup_frame.content_frame, self._update_frame.content_frame)
        self.hide_button(_UPDATE_BUTTON_COLUMN)

        remote_update_data: CachedRemoteUpdateData | None
        self._update_strategy: UpdateStrategy | None
        remote_update_data, self._update_strategy = self._try_get_update_strategy(
            self._update_config.update_directory_url,
            local_manifest,
            self._file_hasher,
            self._file_tester,
            self._url_scraper_factory,
            requested_variant_name = self._requested_variant_name,
        )

        if remote_update_data:
            self._init_variants_tab(local_manifest, remote_update_data)
            if self._update_strategy:
                update_potential: UpdatePotential = UpdatePotential(self._update_strategy)
                if update_potential.is_update_available:
                    self._init_analysis_tab(self._update_strategy)
                    self._init_backup_tab(self._update_strategy)
                    self._init_update_tab(self._update_strategy)
                    self._notebook.select(tab_id=self._update_tab_index)
                    self.show_button(_UPDATE_BUTTON_COLUMN)
                    self._update_status_label.config(text=update_potential.message, style=Style.OnDialog.StatusLabel.Ready.STYLE_NAME)
                else:
                    self._update_status_label.config(text=update_potential.message, style=Style.OnDialog.StatusLabel.Okay.STYLE_NAME)
            else:
                self._update_status_label.config(text='Unable to determine update strategy', style=Style.OnDialog.StatusLabel.Error.STYLE_NAME)
        else:
            self._update_status_label.config(text='Unable to fetch update manifests', style=Style.OnDialog.StatusLabel.Error.STYLE_NAME)

        self.focus_button(_CANCEL_BUTTON_COLUMN)

    def _init_variants_tab(self, local_manifest: ILocalManifest, remote_update_data: CachedRemoteUpdateData) -> None:
        table_frame: StyledFrame = StyledFrame(self._variants_frame.content_frame, style=Style.Generic.TableFrame.STYLE_NAME)
        table_frame.grid(row=0, column=0, sticky=tk.NSEW)
        self._variants_frame.content_frame.columnconfigure(0, weight=1)

        StyledFrame(table_frame, style=Style.InTable.CellFrame.STYLE_NAME).grid(row=0, column=0, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
        ttk.Label(table_frame, text='Variant Name', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.HeaderLabel.STYLE_NAME).grid(row=0, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
        ttk.Label(table_frame, text='Summary', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.HeaderLabel.STYLE_NAME).grid(row=0, column=2, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
        ttk.Label(table_frame, text='Status', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.HeaderLabel.STYLE_NAME).grid(row=0, column=3, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)

        row: int
        variant: IVariant
        for row, variant in enumerate(remote_update_data.version_manifest.variants.values()):
            StyledFrame(table_frame, style=Style.InTable.CellFrame.STYLE_NAME).grid(row=row+1, column=0, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            ttk.Label(table_frame, text=variant.name, anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row+1, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            WrappingLabel(table_frame, text=variant.summary, anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row+1, column=2, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            StyledFrame(table_frame, style=Style.InTable.CellFrame.STYLE_NAME).grid(row=row+1, column=3, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            if variant.name == local_manifest.variant_name:
                ttk.Label(table_frame, text='Current', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row+1, column=3, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
                if self._requested_variant_name is not None and self._requested_variant_name != local_manifest.variant_name:
                    ttk.Button(table_frame, text='Switch', command=functools.partial(self._on_switch_button_pressed, local_manifest, variant.name)).grid(row=row+1, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.EW)
            elif self._requested_variant_name is not None and variant.name == self._requested_variant_name:
                ttk.Label(table_frame, text='Selected', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row+1, column=3, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            else:
                ttk.Button(table_frame, text='Switch', command=functools.partial(self._on_switch_button_pressed, local_manifest, variant.name)).grid(row=row+1, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.EW)

        table_frame.columnconfigure(2, weight=1)
        self._variants_frame.set_child_bindtags_for_scrolling()

        self._notebook.tab(self._variants_tab_index, state=tk.NORMAL)

    def _on_switch_button_pressed(self, local_manifest: ILocalManifest, variant_name: str) -> None:
        self._requested_variant_name = variant_name
        self._check_for_updates(local_manifest)

    def _init_analysis_tab(self, update_strategy: UpdateStrategy) -> None: # pylint: disable=too-many-statements # noqa: PLR0915 Too many statements
        table_frame: StyledFrame = StyledFrame(self._analysis_frame.content_frame, style=Style.Generic.TableFrame.STYLE_NAME)
        table_frame.grid(row=0, column=0, sticky=tk.NSEW)
        self._analysis_frame.content_frame.columnconfigure(1, weight=1)

        ttk.Label(table_frame, text='Type', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.HeaderLabel.STYLE_NAME).grid(row=0, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
        ttk.Label(table_frame, text='File', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.HeaderLabel.STYLE_NAME).grid(row=0, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
        ttk.Label(table_frame, text='Status', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.HeaderLabel.STYLE_NAME).grid(row=0, column=2, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
        ttk.Label(table_frame, text='Action', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.HeaderLabel.STYLE_NAME).grid(row=0, column=3, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
        ttk.Label(table_frame, text='Size', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.HeaderLabel.STYLE_NAME).grid(row=0, column=4, columnspan=2, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)

        row: int = 1
        core_file: ICoreFile
        for core_file in update_strategy.core_file_changes.list_of_new_files_to_acquire:
            unit_text_size: UnitSizeText = _asset_file_size(core_file, update_strategy.asset_register)
            ttk.Label(table_frame, text='Core', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            ttk.Label(table_frame, text=str(core_file.filename), anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            ttk.Label(table_frame, text='New', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=2, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            ttk.Label(table_frame, text='Acquire', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=3, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            ttk.Label(table_frame, text=unit_text_size.size_text, anchor=tk.E, justify=tk.RIGHT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=4, padx=(_TABLE_GRIDLINE_THICKNESS, 0), pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            ttk.Label(table_frame, text=unit_text_size.unit_text, anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=5, padx=(0, _TABLE_GRIDLINE_THICKNESS), pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            row += 1

        for core_file in update_strategy.core_file_changes.list_of_changed_files_to_acquire:
            unit_text_size = _asset_file_size(core_file, update_strategy.asset_register)
            ttk.Label(table_frame, text='Core', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            ttk.Label(table_frame, text=str(core_file.filename), anchor=tk.NW, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            ttk.Label(table_frame, text='Changed', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=2, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            ttk.Label(table_frame, text='Acquire', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=3, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            ttk.Label(table_frame, text=unit_text_size.size_text, anchor=tk.E, justify=tk.RIGHT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=4, padx=(_TABLE_GRIDLINE_THICKNESS, 0), pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            ttk.Label(table_frame, text=unit_text_size.unit_text, anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=5, padx=(0, _TABLE_GRIDLINE_THICKNESS), pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            row += 1

        for core_file in update_strategy.core_file_changes.list_of_missing_files_to_acquire:
            unit_text_size = _asset_file_size(core_file, update_strategy.asset_register)
            ttk.Label(table_frame, text='Core', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            ttk.Label(table_frame, text=str(core_file.filename), anchor=tk.NW, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            ttk.Label(table_frame, text='Missing', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=2, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            ttk.Label(table_frame, text='Reacquire', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=3, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            ttk.Label(table_frame, text=unit_text_size.size_text, anchor=tk.E, justify=tk.RIGHT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=4, padx=(_TABLE_GRIDLINE_THICKNESS, 0), pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            ttk.Label(table_frame, text=unit_text_size.unit_text, anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=5, padx=(0, _TABLE_GRIDLINE_THICKNESS), pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            row += 1

        filename: Path
        for filename in update_strategy.core_file_changes.list_of_files_that_are_deprecated:
            ttk.Label(table_frame, text='Core', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            ttk.Label(table_frame, text=str(filename), anchor=tk.NW, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            ttk.Label(table_frame, text='Redundant', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=2, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            ttk.Label(table_frame, text='Delete', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=3, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            StyledFrame(table_frame, style=Style.InTable.CellFrame.STYLE_NAME).grid(row=row, column=4, columnspan=2, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            row += 1

        for core_file in update_strategy.core_file_changes.list_of_unchanged_files:
            ttk.Label(table_frame, text='Core', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            ttk.Label(table_frame, text=str(core_file.filename), anchor=tk.NW, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            ttk.Label(table_frame, text='Unchanged', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=2, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            ttk.Label(table_frame, text='None', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=3, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            StyledFrame(table_frame, style=Style.InTable.CellFrame.STYLE_NAME).grid(row=row, column=4, columnspan=2, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            row += 1

        file_rename: FileRename
        for file_rename in update_strategy.config_file_changes.list_of_files_to_rename:
            ttk.Label(table_frame, text='Config', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            ttk.Label(table_frame, text=str(file_rename.original_filename), anchor=tk.NW, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            ttk.Label(table_frame, text='Renamed', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=2, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            ttk.Label(table_frame, text=f'Rename to {file_rename.new_filename!s}', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=3, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            StyledFrame(table_frame, style=Style.InTable.CellFrame.STYLE_NAME).grid(row=row, column=4, columnspan=2, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            row += 1

        for filename in update_strategy.config_file_changes.list_of_files_that_are_deprecated:
            ttk.Label(table_frame, text='Config', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            ttk.Label(table_frame, text=str(filename), anchor=tk.NW, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            ttk.Label(table_frame, text='Redundant', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=2, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            ttk.Label(table_frame, text='Delete', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=3, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            StyledFrame(table_frame, style=Style.InTable.CellFrame.STYLE_NAME).grid(row=row, column=4, columnspan=2, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            row += 1

        for filename in update_strategy.config_file_changes.list_of_files_to_leave:
            ttk.Label(table_frame, text='Config', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            ttk.Label(table_frame, text=str(filename), anchor=tk.NW, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            ttk.Label(table_frame, text='Relevant', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=2, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            ttk.Label(table_frame, text='None', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=3, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            StyledFrame(table_frame, style=Style.InTable.CellFrame.STYLE_NAME).grid(row=row, column=4, columnspan=2, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            row += 1

        for filename in update_strategy.config_file_changes.list_of_new_files:
            ttk.Label(table_frame, text='Config', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            ttk.Label(table_frame, text=str(filename), anchor=tk.NW, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            ttk.Label(table_frame, text='New', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=2, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            ttk.Label(table_frame, text='None', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=3, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            StyledFrame(table_frame, style=Style.InTable.CellFrame.STYLE_NAME).grid(row=row, column=4, columnspan=2, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            row += 1

        self._analysis_frame.set_child_bindtags_for_scrolling()
        self._notebook.add(self._analysis_frame.top_frame)

    def _init_backup_tab(self, update_strategy: UpdateStrategy) -> None:
        table_frame: StyledFrame = StyledFrame(self._backup_frame.content_frame, style=Style.Generic.TableFrame.STYLE_NAME)
        table_frame.grid(row=0, column=0, sticky=tk.NSEW)
        self._backup_frame.content_frame.columnconfigure(1, weight=1)

        ttk.Label(table_frame, text='Type', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.HeaderLabel.STYLE_NAME).grid(row=0, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
        ttk.Label(table_frame, text='File', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.HeaderLabel.STYLE_NAME).grid(row=0, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)

        row: int = 1
        filename: Path
        for filename in update_strategy.backup_file_set.list_of_core_files_to_backup:
            ttk.Label(table_frame, text='Core', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            ttk.Label(table_frame, text=str(filename), anchor=tk.NW, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            row += 1

        for filename in update_strategy.backup_file_set.list_of_config_files_to_backup:
            ttk.Label(table_frame, text='Config', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            ttk.Label(table_frame, text=str(filename), anchor=tk.NW, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            row += 1

        for filename in update_strategy.backup_file_set.list_of_clobbered_files_to_backup:
            ttk.Label(table_frame, text='Unknown', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            ttk.Label(table_frame, text=str(filename), anchor=tk.NW, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            row += 1

        self._backup_frame.set_child_bindtags_for_scrolling()
        self._notebook.add(self._backup_frame.top_frame)

    def _init_update_tab(self, update_strategy: UpdateStrategy) -> None:
        table_frame: StyledFrame = StyledFrame(self._update_frame.content_frame, style=Style.Generic.TableFrame.STYLE_NAME)
        table_frame.grid(row=0, column=0, sticky=tk.NSEW)
        self._update_frame.content_frame.columnconfigure(0, weight=1)

        ttk.Label(table_frame, text='Version', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.HeaderLabel.STYLE_NAME).grid(row=0, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
        ttk.Label(table_frame, text='Date', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.HeaderLabel.STYLE_NAME).grid(row=0, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
        ttk.Label(table_frame, text='Changes', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.HeaderLabel.STYLE_NAME).grid(row=0, column=2, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)

        row: int = 1
        version: IVersion
        for version in sorted(update_strategy.list_of_newer_versions, key=lambda version: (version.date, version.number), reverse=True):
            ttk.Label(table_frame, text=str(version.number), anchor=tk.NW, justify=tk.LEFT, style=Style.InTable.NewValueLabel.STYLE_NAME).grid(row=row, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            ttk.Label(table_frame, text=str(version.date), anchor=tk.NW, justify=tk.LEFT, style=Style.InTable.NewValueLabel.STYLE_NAME).grid(row=row, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            WrappingLabel(table_frame, text=version.log, anchor=tk.NW, justify=tk.LEFT, style=Style.InTable.NewValueLabel.STYLE_NAME).grid(row=row, column=2, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            row += 1

        for version in sorted(update_strategy.list_of_previous_versions, key=lambda version: (version.date, version.number), reverse=True):
            ttk.Label(table_frame, text=str(version.number), anchor=tk.NW, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            ttk.Label(table_frame, text=str(version.date), anchor=tk.NW, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            WrappingLabel(table_frame, text=version.log, anchor=tk.NW, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=2, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            row += 1

        table_frame.columnconfigure(2, weight=1)
        self._update_frame.set_child_bindtags_for_scrolling()

    def _on_cancel_button(self) -> None:
        self.destroy()

    def _on_update_button(self) -> None:
        if self._update_strategy and self._try_prepare_update(self._update_strategy):
            self.destroy()
            self._shutdown_app()

    def _try_get_update_strategy(self, update_directory_url: str, local_manifest: ILocalManifest, file_hasher: IFileHasher, file_tester: IFileTester, url_scraper_factory: IUrlScraperFactory, *, requested_variant_name: str | None=None) -> tuple[CachedRemoteUpdateData | None, UpdateStrategy | None]:
        remote_update_data: CachedRemoteUpdateData | None = CachedRemoteUpdateData.fetch(update_directory_url, url_scraper_factory, self._log_text.normal_printer, self._log_text.error_printer)
        if not remote_update_data:
            return None, None

        try:
            update_strategy: UpdateStrategy = determine_update_strategy(Path(), None, requested_variant_name, local_manifest, remote_update_data.version_manifest, remote_update_data.update_directory.asset_register, file_hasher, file_tester)
        except UpdateStrategyError as ex:
            self._log_text.error_printer.writeln('Failed to determine update strategy')
            self._log_text.normal_printer.writeln(f'Cause: {ex}')
        else:
            return remote_update_data, update_strategy

        return remote_update_data, None

    def _try_prepare_update(self, update_strategy: UpdateStrategy) -> bool:
        if update_strategy.launch_executable is None:
            prompt: PromptDialog = PromptDialog(
                self,
                icon = PromptDialog.Icon.WARNING,
                title = 'Update Warning',
                headline_text = 'Unsupported target platform',
                detail_text = (
                    'There is no main executable for the current operating system in the chosen target variant / version.'
                    ' Following the update, the application will close and there can be no attempt to start the new application.'
                    ' This problem can occur if you upgrade to a variant or version that supports a different operating system.\n\n'
                    'Are you sure you want to continue?'
                ),
                buttons = PromptDialog.Buttons.YES_NO,
                height = 260,
            )
            if prompt.wait_response() != PromptDialog.Response.YES:
                return False

        self._notebook.select(tab_id=self._log_tab_index)

        try:
            temp_directory: ITempDirectory = self._temp_directory_creator.create()
        except TempDirectoryError as ex:
            self._log_text.normal_printer.writeln()
            self._log_text.error_printer.writeln(f'Failed to prepare update: {ex}')
            return False

        self._log_text.normal_printer.writeln(f"Created update temp directory '{temp_directory.path}'")

        try:
            shutdown_action: IShutdownAction = prepare_update(
                update_strategy = update_strategy,
                backup_directory = self._update_config.backup_directory,
                time_stamp = time.localtime(),
                directory_url = self._update_config.update_directory_url,
                asset_register = update_strategy.asset_register,
                temp_directory = temp_directory,
                url_scraper_factory = self._url_scraper_factory,
                normal_printer = self._log_text.normal_printer,
            )
        except PrepareUpdateError as ex:
            self._log_text.normal_printer.writeln()
            self._log_text.error_printer.writeln(f'Failed to prepare update: {ex}')
            return False

        self._ref_shutdown_action.set(shutdown_action)
        return True

def _asset_file_size(core_file: ICoreFile, asset_register: IAssetRegister) -> UnitSizeText:
    asset: IAsset | None = asset_register.assets.get(core_file.digest)
    if not asset:
        return UnitSizeText('unknown', '')
    return unit_size(asset.size)

def _hide_tabs(notebook: ttk.Notebook, *list_of_tab_indices: object) -> None:
    tab_index: object
    for tab_index in list_of_tab_indices:
        notebook.tab(tab_index, state=tk.HIDDEN)

def _clear_frames(*list_of_frames: tk.Misc) -> None:
    frame: tk.Misc
    for frame in list_of_frames:
        while frame.children:
            frame.children.popitem()[1].destroy()
