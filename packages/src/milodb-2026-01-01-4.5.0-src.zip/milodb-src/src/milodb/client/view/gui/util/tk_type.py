# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from collections.abc import Callable
from typing import Literal

type Relief = Literal['raised', 'sunken', 'flat', 'ridge', 'solid', 'groove']
type ScreenUnits = float | str
type TakeFocusValue = bool | Callable[[str], bool | None] | Literal[0, 1, '']
type XYScrollCommand = str | Callable[[float, float], object]
