# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from abc import ABC, abstractmethod
from math import ceil, pi
from typing import override
from PIL import Image, ImageDraw
from milodb.client.view.gui.graphics.geometric_shapes import make_star_points
from milodb.client.view.gui.graphics.turtle import Alignment, Flip, Turtle, TurtleShape
from milodb.client.view.gui.util.singleton import RaiiSingleton
from milodb.common.view.gui.metrics import Point, RelPoint

class _IImageGenerator(ABC):
    @abstractmethod
    def render(self, *, image_height: int) -> Image.Image:
        pass

class _RatingImageGenerator(_IImageGenerator):
    STAR_POINTS: int = 5
    OUTER_RADIUS: float = 500.0
    INNER_RADIUS: float = 200.0
    OUTER_ROTATION_RADIANS: float = pi / 4.2
    INNER_ROTATION_RADIANS: float = OUTER_ROTATION_RADIANS

    NUMBER_OF_STARS: int = 5
    WIDTH_OF_STAR: int = ceil(OUTER_RADIUS * 2)
    SPACING_BETWEEN_STARS: int = ceil(OUTER_RADIUS * 2 * 0.83)
    HEIGHT_OF_STAR: int = ceil(OUTER_RADIUS * 2)
    LINE_THICKNESS: int = 0

    ORIGINAL_IMAGE_WIDTH: int = SPACING_BETWEEN_STARS * (NUMBER_OF_STARS - 1) + WIDTH_OF_STAR
    ORIGINAL_IMAGE_HEIGHT: int = HEIGHT_OF_STAR

    def __init__(self) -> None:
        self.list_of_polygons: list[list[Point]] = []
        for star in range(self.NUMBER_OF_STARS):
            self.list_of_polygons.append(
                make_star_points(
                    left = star * self.SPACING_BETWEEN_STARS,
                    top = 0,
                    number_of_points = self.STAR_POINTS,
                    outer_radius = self.OUTER_RADIUS,
                    inner_radius = self.INNER_RADIUS,
                    outer_rotation_radians = self.OUTER_ROTATION_RADIANS,
                    inner_rotation_radians = self.INNER_ROTATION_RADIANS,
                ),
            )

    @property
    @abstractmethod
    def fill_colour(self) -> str:
        pass

    @property
    @abstractmethod
    def line_colour(self) -> str:
        pass

    @override
    def render(self, *, image_height: int) -> Image.Image:
        image: Image.Image = Image.new('RGBA', size=(self.ORIGINAL_IMAGE_WIDTH, self.ORIGINAL_IMAGE_HEIGHT))
        draw: ImageDraw.ImageDraw = ImageDraw.Draw(image)
        list_of_points: list[Point]
        for list_of_points in self.list_of_polygons:
            draw.polygon(list_of_points, fill=self.fill_colour, outline=self.line_colour, width=self.LINE_THICKNESS)
        image_width: int = image_height * self.ORIGINAL_IMAGE_WIDTH // self.ORIGINAL_IMAGE_HEIGHT
        return image.resize((image_width, image_height), resample=Image.Resampling.BICUBIC)

class _RatingFilledImageGenerator(_RatingImageGenerator):
    FILL_COLOUR: str = '#FD3'
    LINE_COLOUR: str = '#000'

    @property
    @override
    def fill_colour(self) -> str:
        return self.FILL_COLOUR

    @property
    @override
    def line_colour(self) -> str:
        return self.LINE_COLOUR

class _RatingHollowImageGenerator(_RatingImageGenerator):
    FILL_COLOUR: str = '#888'
    LINE_COLOUR: str = '#000'

    @property
    @override
    def fill_colour(self) -> str:
        return self.FILL_COLOUR

    @property
    @override
    def line_colour(self) -> str:
        return self.LINE_COLOUR

class _UnknownAuthorImageGenerator(_IImageGenerator):
    LINE_COLOUR: str = '#858'
    FILL_COLOUR: str = '#B8B'
    LINE_THICKNESS: int = 10
    DOT_RADIUS: int = 37

    def __init__(self) -> None:
        turtle: Turtle = Turtle()
        shape: TurtleShape = TurtleShape(turtle, Point(47, 78))
        shape \
            .bezier(Point(78, 9), Point(137, 58)) \
            .bezier(Point(204, 116), Point(118, 172)) \
            .bezier(Point(103, 187), Point(99, 205)) \
            .bezier(Point(88, 236), Point(65, 205)) \
            .bezier(Point(61, 190), Point(119, 131)) \
            .bezier(Point(152, 91), Point(102, 71)) \
            .bezier(Point(75, 67), Point(71, 91)) \
            .bezier(Point(71, 100), Point(63, 106)) \
            .bezier(Point(29, 116), shape.origin) \
            .scale(width = 1.8)

        self.original_image_width: int = ceil(shape.calc_width())
        self.original_image_height: int = ceil(shape.calc_height())
        self.dot_center: Point = Point(self.original_image_width / 2 - 30, self.original_image_height + 50)
        self.original_image_width += self.LINE_THICKNESS
        self.original_image_height = ceil(self.dot_center.y + self.DOT_RADIUS + self.LINE_THICKNESS / 2)
        self.list_of_points: list[Point] = shape.calc_points(Alignment.NORTH_WEST, align_x=ceil(self.LINE_THICKNESS / 2), align_y=ceil(self.LINE_THICKNESS / 2))

    @override
    def render(self, *, image_height: int) -> Image.Image:
        image = Image.new('RGBA', size=(self.original_image_width, self.original_image_height))
        draw: ImageDraw.ImageDraw = ImageDraw.Draw(image)
        draw.polygon(self.list_of_points, fill=self.FILL_COLOUR)
        draw.line(self.list_of_points, fill=self.LINE_COLOUR, width=self.LINE_THICKNESS, joint='curve')
        draw.ellipse((self.dot_center.x - self.DOT_RADIUS, self.dot_center.y - self.DOT_RADIUS, self.dot_center.x + self.DOT_RADIUS, self.dot_center.y + self.DOT_RADIUS), fill=self.FILL_COLOUR, outline=self.LINE_COLOUR, width=self.LINE_THICKNESS)
        image_width: int = image_height * self.original_image_width // self.original_image_height
        return image.resize((image_width, image_height), resample=Image.Resampling.BICUBIC)

class _DeletedImageGenerator(_IImageGenerator):
    ORIGINAL_IMAGE_WIDTH: int = 50
    ORIGINAL_IMAGE_HEIGHT: int = 50
    LINE_WIDTH: int = 10
    LINE_COLOUR: str = '#F31'
    BORDER_THICKNESS: int = ORIGINAL_IMAGE_WIDTH // 10

    @override
    def render(self, *, image_height: int) -> Image.Image:
        image: Image.Image = Image.new('RGBA', size=(self.ORIGINAL_IMAGE_WIDTH, self.ORIGINAL_IMAGE_HEIGHT))
        draw: ImageDraw.ImageDraw = ImageDraw.Draw(image)
        draw.line((self.BORDER_THICKNESS, self.BORDER_THICKNESS, self.ORIGINAL_IMAGE_WIDTH - self.BORDER_THICKNESS, self.ORIGINAL_IMAGE_HEIGHT - self.BORDER_THICKNESS), fill=self.LINE_COLOUR, width=self.LINE_WIDTH)
        draw.line((self.BORDER_THICKNESS, self.ORIGINAL_IMAGE_HEIGHT - self.BORDER_THICKNESS, self.ORIGINAL_IMAGE_WIDTH - self.BORDER_THICKNESS, self.BORDER_THICKNESS), fill=self.LINE_COLOUR, width=self.LINE_WIDTH)
        image_width: int = image_height * self.ORIGINAL_IMAGE_WIDTH // self.ORIGINAL_IMAGE_HEIGHT
        return image.resize((image_width, image_height), resample=Image.Resampling.BICUBIC)

class _StatusImageGenerator(_IImageGenerator):
    ORIGINAL_IMAGE_WIDTH: int = 50
    ORIGINAL_IMAGE_HEIGHT: int = 50
    LETTER_COLOUR: str = '#FFF'
    LETTER_WIDTH: int = 8
    DOT_TOP_OFFSET: int = 7
    STEM_TOP_OFFSET: int = 25
    STEM_HEIGHT: int = 15
    BACKGROUND_COLOUR: str = '#311'

    @override
    def render(self, *, image_height: int) -> Image.Image:
        image = Image.new('RGBA', size=(self.ORIGINAL_IMAGE_WIDTH, self.ORIGINAL_IMAGE_HEIGHT))
        draw: ImageDraw.ImageDraw = ImageDraw.Draw(image)
        draw.ellipse((0, 0, self.ORIGINAL_IMAGE_WIDTH, self.ORIGINAL_IMAGE_HEIGHT), self.BACKGROUND_COLOUR, width=0)
        draw.ellipse(((self.ORIGINAL_IMAGE_WIDTH - self.LETTER_WIDTH) / 2, self.DOT_TOP_OFFSET, (self.ORIGINAL_IMAGE_WIDTH + self.LETTER_WIDTH) / 2, self.DOT_TOP_OFFSET + self.LETTER_WIDTH), self.LETTER_COLOUR, width=0)
        _draw_capped_line(draw, self.ORIGINAL_IMAGE_WIDTH / 2, self.STEM_TOP_OFFSET, self.ORIGINAL_IMAGE_WIDTH / 2, self.STEM_TOP_OFFSET + self.STEM_HEIGHT, fill=self.LETTER_COLOUR, width=self.LETTER_WIDTH)
        return image.resize((image_height * self.ORIGINAL_IMAGE_WIDTH // self.ORIGINAL_IMAGE_HEIGHT, image_height), resample=Image.Resampling.BICUBIC)

class _TotmImageGenerator(_IImageGenerator):
    LINE_THICKNESS: int = 5

    def __init__(self) -> None:
        turtle: Turtle = Turtle()
        trophy_body: TurtleShape = TurtleShape(turtle, Point(60, 60))
        trophy_body \
            .line(Point(170, 60)) \
            .bezier(Point(170, 210), Point(60, 210), trophy_body.origin)

        right_handle: TurtleShape = TurtleShape(turtle, Point(159, 80))
        right_handle \
            .bezier(Point(181, 51), Point(225, 65), Point(205, 101)) \
            .bezier(Point(185, 132), Point(178, 116), Point(167, 140)) \
            .bezier(Point(154, 164), Point(148, 124), Point(159, 120)) \
            .bezier(Point(197, 105), Point(209, 70), Point(182, 80)) \
            .bezier(Point(170, 84), Point(159, 100)) \
            .line(right_handle.origin)

        left_handle: TurtleShape = right_handle.copy()
        left_handle.flip(Flip.HORIZONTAL_AT_LEFT)
        left_handle.translate(left=77)

        trophy_base: TurtleShape = TurtleShape(turtle, Point(70, 200))
        trophy_base \
            .bezier(Point(100, 190), Point(100, 160)) \
            .bezier(Point(100, 130), Point(130, 130), Point(130, 160)) \
            .bezier(Point(130, 190), Point(160, 200)) \
            .line(Point(160, 220)) \
            .line(Point(70, 220)) \
            .line(trophy_base.origin) \

        trophy_body.raise_to_top()

        self.original_image_width: int = ceil(turtle.calc_width()) + self.LINE_THICKNESS
        self.original_image_height: int = ceil(turtle.calc_height()) + self.LINE_THICKNESS
        self.list_of_polygons: list[list[Point]] = []
        shape: TurtleShape
        for shape in turtle.list_of_shapes:
            self.list_of_polygons.append(shape.calc_points(Alignment.NORTH_WEST, align_x=self.LINE_THICKNESS / 2, align_y=self.LINE_THICKNESS / 2))

    @property
    @abstractmethod
    def fill_colour(self) -> str:
        pass

    @property
    @abstractmethod
    def line_colour(self) -> str:
        pass

    @override
    def render(self, *, image_height: int) -> Image.Image:
        image: Image.Image = Image.new('RGBA', size=(self.original_image_width, self.original_image_height))
        draw: ImageDraw.ImageDraw = ImageDraw.Draw(image)
        list_of_points: list[Point]
        for list_of_points in self.list_of_polygons:
            draw.polygon(list_of_points, fill=self.fill_colour)
            draw.line(list_of_points, fill=self.line_colour, width=self.LINE_THICKNESS, joint='curve')
        return image.resize((image_height * self.original_image_width // self.original_image_height, image_height), resample=Image.Resampling.BICUBIC)

class _TotmNomineeImageGenerator(_TotmImageGenerator):
    FILL_COLOUR: str = '#CCC'
    LINE_COLOUR: str = '#444'

    @property
    @override
    def fill_colour(self) -> str:
        return self.FILL_COLOUR

    @property
    @override
    def line_colour(self) -> str:
        return self.LINE_COLOUR

class _TotmWinnerImageGenerator(_TotmImageGenerator):
    FILL_COLOUR: str = '#FF3'
    LINE_COLOUR: str = '#444'

    @property
    @override
    def fill_colour(self) -> str:
        return self.FILL_COLOUR

    @property
    @override
    def line_colour(self) -> str:
        return self.LINE_COLOUR

class _TotmHeaderImageGenerator(_IImageGenerator):
    @override
    def render(self, *, image_height: int) -> Image.Image:
        nominee_image: Image.Image = _TOTM_NOMINEE_IMAGE_GENERATOR_SINGLETON.instance.render(image_height=image_height)
        winner_image: Image.Image = _TOTM_WINNER_IMAGE_GENERATOR_SINGLETON.instance.render(image_height=image_height)
        nominee_image = nominee_image.crop((0, 0, nominee_image.width // 2, nominee_image.height))
        winner_image = winner_image.crop((winner_image.width // 2, 0, winner_image.width, nominee_image.height))
        mixed_image: Image.Image = Image.new('RGBA', size=(nominee_image.width + winner_image.width, max(nominee_image.height, winner_image.height)))
        mixed_image.paste(nominee_image, (0, 0))
        mixed_image.paste(winner_image, (nominee_image.width, 0))
        return mixed_image

class _EosImageGenerator(_IImageGenerator):
    FILL_COLOUR: str = '#FFF'
    LINE_COLOUR: str = '#78A'
    OUTLINE_THICKNESS: int = 9
    BONE_THICKNESS: int = 5

    def __init__(self) -> None:
        turtle: Turtle = Turtle()
        feather: TurtleShape = TurtleShape(turtle, Point(0, 132))
        feather \
            .bezier(Point(0, 32), Point(100, 47), Point(126, 0)) \
            .bezier(Point(126, 100), Point(26, 85), feather.origin)

        feather_bone: TurtleShape = TurtleShape(turtle, feather.origin)
        feather_bone.bezier(Point(0, 56), Point(126, 56), Point(126, 0))

        self.original_image_width: int = ceil(turtle.calc_width()) + self.OUTLINE_THICKNESS
        self.original_image_height: int = ceil(turtle.calc_height()) + self.OUTLINE_THICKNESS
        self.list_of_feather_poly_points: list[Point] = feather.calc_points(Alignment.NORTH_WEST, align_x=self.OUTLINE_THICKNESS / 2, align_y=self.OUTLINE_THICKNESS / 2)
        self.list_of_bone_poly_points = feather_bone.calc_points(Alignment.NORTH_WEST, align_x=self.OUTLINE_THICKNESS / 2, align_y=self.OUTLINE_THICKNESS / 2)

    @override
    def render(self, *, image_height: int) -> Image.Image:
        image: Image.Image = Image.new('RGBA', size=(self.original_image_width, self.original_image_height))
        draw: ImageDraw.ImageDraw = ImageDraw.Draw(image)
        draw.polygon(self.list_of_feather_poly_points, fill=_EosImageGenerator.FILL_COLOUR)
        draw.line(self.list_of_feather_poly_points, fill=_EosImageGenerator.LINE_COLOUR, width=_EosImageGenerator.OUTLINE_THICKNESS, joint='curve')
        draw.line(self.list_of_bone_poly_points, fill=_EosImageGenerator.LINE_COLOUR, width=_EosImageGenerator.BONE_THICKNESS, joint='curve')
        return image.resize((image_height * self.original_image_width // self.original_image_height, image_height), resample=Image.Resampling.BICUBIC)

class _FlashImageGenerator(_IImageGenerator):
    FILL_COLOUR: str = '#FFF'
    LINE_COLOUR: str = '#78A'
    LINE_THICKNESS: int = 9

    def __init__(self) -> None:
        turtle: Turtle = Turtle()
        shape: TurtleShape = TurtleShape(turtle, Point(0, 116))
        shape \
            .bezier(Point(78, 116), Point(27, 0), Point(135, 0)) \
            .line(Point(135, 34)) \
            .bezier(Point(91, 34), Point(91, 63)) \
            .line(Point(113, 63)) \
            .line(Point(113, 94)) \
            .line(Point(80, 94)) \
            .bezier(Point(41, 156), Point(15, 156)) \
            .line(Point(0, 156)) \
            .line(shape.origin)

        self.original_image_width: int = ceil(turtle.calc_width()) + self.LINE_THICKNESS
        self.original_image_height: int = ceil(turtle.calc_height()) + self.LINE_THICKNESS
        self.list_of_points: list[Point] = shape.calc_points(Alignment.NORTH_WEST, align_x=self.LINE_THICKNESS / 2, align_y=self.LINE_THICKNESS / 2)

    @override
    def render(self, *, image_height: int) -> Image.Image:
        image: Image.Image = Image.new('RGBA', size=(self.original_image_width, self.original_image_height))
        draw: ImageDraw.ImageDraw = ImageDraw.Draw(image)
        draw.polygon(self.list_of_points, fill=self.FILL_COLOUR)
        draw.line(self.list_of_points, fill=self.LINE_COLOUR, width=self.LINE_THICKNESS, joint='curve')
        return image.resize((image_height * self.original_image_width // self.original_image_height, image_height), resample=Image.Resampling.BICUBIC)

class _AudioImageGenerator(_IImageGenerator):
    FILL_COLOUR: str = '#78A'
    LINE_COLOUR: str = '#FFF'
    SHAPE_THICKNESS: int = 20
    LINE_THICKNESS: int = 7

    def __init__(self) -> None:
        turtle: Turtle = Turtle()
        shape: TurtleShape = TurtleShape(turtle, Point(8, 82))
        shape \
            .line(Point(23, 58)) \
            .line(Point(38, 101)) \
            .line(Point(68, 7)) \
            .line(Point(78, 119)) \
            .line(Point(94, 47)) \
            .line(Point(107, 81)) \
            .line(Point(122, 52)) \
            .line(Point(132, 70))

        self.original_image_width: int = ceil(turtle.calc_width()) + self.SHAPE_THICKNESS
        self.original_image_height: int = ceil(turtle.calc_height()) + self.SHAPE_THICKNESS
        self.list_of_points: list[Point] = shape.calc_points(Alignment.NORTH_WEST, align_x=self.SHAPE_THICKNESS / 2, align_y=self.SHAPE_THICKNESS / 2)

    @override
    def render(self, *, image_height: int) -> Image.Image:
        image: Image.Image = Image.new('RGBA', size=(self.original_image_width, self.original_image_height))
        draw: ImageDraw.ImageDraw = ImageDraw.Draw(image)
        draw.line(self.list_of_points, fill=self.FILL_COLOUR, width=self.SHAPE_THICKNESS, joint='curve')
        draw.line(self.list_of_points, fill=self.LINE_COLOUR, width=self.LINE_THICKNESS, joint='curve')
        return image.resize((image_height * self.original_image_width // self.original_image_height, image_height), resample=Image.Resampling.BICUBIC)

class _RegularImageGenerator(_IImageGenerator):
    FILL_COLOUR: str = '#FFF'
    LINE_COLOUR: str = '#78A'
    OUTLINE_THICKNESS: int = 6

    def __init__(self) -> None:
        turtle: Turtle = Turtle()

        left_page_top: TurtleShape = TurtleShape(turtle, Point(115, 161))
        left_page_top \
            .bezier(Point(88, 135), Point(50, 145)) \
            .line(Point(50, 237)) \
            .bezier(Point(88, 231), Point(115, 258)) \
            .line(left_page_top.origin)

        left_page_top.copy() \
            .scale(width=0.9, height=0.6) \
            .align(Alignment.SOUTH_EAST, left_page_top.calc_bottom_right()) \
            .lower_to_bottom()

        left_page_top.copy() \
            .scale(width=0.8, height=0.2) \
            .align(Alignment.SOUTH_EAST, left_page_top.calc_bottom_right()) \
            .lower_to_bottom()

        right_page_top: TurtleShape = left_page_top.copy() \
            .flip(Flip.HORIZONTAL_AT_RIGHT)

        right_page_top.copy() \
            .scale(width=0.9, height=0.6) \
            .align(Alignment.SOUTH_WEST, right_page_top.calc_bottom_left()) \
            .lower_to_bottom()

        right_page_top.copy() \
            .scale(width=0.8, height=0.2) \
            .align(Alignment.SOUTH_WEST, right_page_top.calc_bottom_left()) \
            .lower_to_bottom()

        left_text_line: TurtleShape = TurtleShape(turtle, Point(105, 167)) \
            .bezier(Point(83, 150), Point(62, 156))

        right_text_line: TurtleShape = left_text_line.copy() \
            .flip(Flip.HORIZONTAL_AT_RIGHT) \
            .translate(right = 2 * (left_page_top.calc_max_x() - left_text_line.calc_max_x()))

        for _ in range(6):
            left_text_line = left_text_line.copy().translate(down=11)
            right_text_line = right_text_line.copy().translate(down=11)

        self.original_image_width: int = ceil(turtle.calc_width()) + self.OUTLINE_THICKNESS
        self.original_image_height: int = ceil(turtle.calc_height()) + self.OUTLINE_THICKNESS
        self.list_of_polygons: list[list[Point]] = []
        shape: TurtleShape
        for shape in turtle.list_of_shapes:
            self.list_of_polygons.append(shape.calc_points(Alignment.NORTH_WEST, align_x=self.OUTLINE_THICKNESS / 2, align_y=self.OUTLINE_THICKNESS / 2))

    @override
    def render(self, *, image_height: int) -> Image.Image:
        image = Image.new('RGBA', size=(self.original_image_width, self.original_image_height))
        draw: ImageDraw.ImageDraw = ImageDraw.Draw(image)
        list_of_points: list[Point]
        for list_of_points in self.list_of_polygons:
            draw.polygon(list_of_points, fill=self.FILL_COLOUR)
            draw.line(list_of_points, fill=self.LINE_COLOUR, width=self.OUTLINE_THICKNESS, joint='curve')
        return image.resize((image_height * self.original_image_width // self.original_image_height, image_height), resample=Image.Resampling.BICUBIC)

class _InputInvalidImageGenerator(_IImageGenerator):
    FILL_COLOUR: str = '#800'
    OUTLINE_THICKNESS: int = 10
    OUTLINE_COLOUR: str = '#D88'
    LINE_COLOUR: str = '#FFF'
    LINE_THICKNESS: int = 30
    BAR_TOP: int = 45
    BAR_BOTTOM: int = 125
    DOT_TOP: int = 150
    ORIGINAL_IMAGE_WIDTH: int = 210
    ORIGINAL_IMAGE_HEIGHT: int = 210

    @override
    def render(self, *, image_height: int) -> Image.Image:
        image = Image.new('RGBA', size=(self.ORIGINAL_IMAGE_WIDTH, self.ORIGINAL_IMAGE_HEIGHT))
        draw: ImageDraw.ImageDraw = ImageDraw.Draw(image)
        draw.ellipse((self.OUTLINE_THICKNESS / 2, self.OUTLINE_THICKNESS / 2, self.ORIGINAL_IMAGE_WIDTH - self.OUTLINE_THICKNESS / 2, self.ORIGINAL_IMAGE_HEIGHT - self.OUTLINE_THICKNESS / 2), fill=self.FILL_COLOUR, outline=self.OUTLINE_COLOUR, width=self.OUTLINE_THICKNESS)
        _draw_capped_line(draw, self.ORIGINAL_IMAGE_WIDTH / 2, self.BAR_TOP, self.ORIGINAL_IMAGE_WIDTH / 2, self.BAR_BOTTOM, fill=self.LINE_COLOUR, width=self.LINE_THICKNESS)
        draw.ellipse(((self.ORIGINAL_IMAGE_WIDTH - self.LINE_THICKNESS) / 2, self.DOT_TOP, (self.ORIGINAL_IMAGE_WIDTH + self.LINE_THICKNESS) / 2, self.DOT_TOP + self.LINE_THICKNESS), fill=self.LINE_COLOUR)
        return image.resize((image_height * self.ORIGINAL_IMAGE_WIDTH // self.ORIGINAL_IMAGE_HEIGHT, image_height), resample=Image.Resampling.BICUBIC)

class _InputValidImageGenerator(_IImageGenerator):
    FILL_COLOUR: str = '#280'
    OUTLINE_THICKNESS: int = 10
    OUTLINE_COLOUR: str = '#8D9'
    LINE_COLOUR: str = '#FFF'
    LINE_THICKNESS: int = 25
    ORIGINAL_IMAGE_WIDTH: int = 210
    ORIGINAL_IMAGE_HEIGHT: int = 210

    def __init__(self) -> None:
        turtle: Turtle = Turtle()
        shape: TurtleShape = TurtleShape(turtle, Point(60, 120))
        shape \
            .bezier(Point(88, 132), Point(100, 160)) \
            .bezier(Point(100, 136), Point(118, 85), Point(150, 59))

        self.list_of_points: list[Point] = shape.calc_points(None)

    @override
    def render(self, *, image_height: int) -> Image.Image:
        image = Image.new('RGBA', size=(self.ORIGINAL_IMAGE_WIDTH, self.ORIGINAL_IMAGE_HEIGHT))
        draw: ImageDraw.ImageDraw = ImageDraw.Draw(image)
        draw.ellipse((self.OUTLINE_THICKNESS / 2, self.OUTLINE_THICKNESS / 2, self.ORIGINAL_IMAGE_WIDTH - self.OUTLINE_THICKNESS / 2, self.ORIGINAL_IMAGE_HEIGHT - self.OUTLINE_THICKNESS / 2), fill=self.FILL_COLOUR, outline=self.OUTLINE_COLOUR, width=self.OUTLINE_THICKNESS)
        draw.line(self.list_of_points, fill=self.LINE_COLOUR, width=self.LINE_THICKNESS, joint='curve')
        return image.resize((image_height * self.ORIGINAL_IMAGE_WIDTH // self.ORIGINAL_IMAGE_HEIGHT, image_height), resample=Image.Resampling.BICUBIC)

class _InputUnusedImageGenerator(_IImageGenerator):
    FILL_COLOUR: str = '#444'
    OUTLINE_THICKNESS: int = 10
    OUTLINE_COLOUR: str = '#AAA'
    LINE_COLOUR: str = '#AAA'
    LINE_THICKNESS: int = 30
    BAR_LEFT: int = 50
    BAR_RIGHT: int = 160
    ORIGINAL_IMAGE_WIDTH: int = 210
    ORIGINAL_IMAGE_HEIGHT: int = 210

    @override
    def render(self, *, image_height: int) -> Image.Image:
        image = Image.new('RGBA', size=(self.ORIGINAL_IMAGE_WIDTH, self.ORIGINAL_IMAGE_HEIGHT))
        draw: ImageDraw.ImageDraw = ImageDraw.Draw(image)
        draw.ellipse((self.OUTLINE_THICKNESS / 2, self.OUTLINE_THICKNESS / 2, self.ORIGINAL_IMAGE_WIDTH - self.OUTLINE_THICKNESS / 2, self.ORIGINAL_IMAGE_HEIGHT - self.OUTLINE_THICKNESS / 2), fill=self.FILL_COLOUR, outline=self.OUTLINE_COLOUR, width=self.OUTLINE_THICKNESS)
        _draw_capped_line(draw, self.BAR_LEFT, self.ORIGINAL_IMAGE_HEIGHT / 2, self.BAR_RIGHT, self.ORIGINAL_IMAGE_HEIGHT / 2, fill=self.LINE_COLOUR, width=self.LINE_THICKNESS)
        return image.resize((image_height * self.ORIGINAL_IMAGE_WIDTH // self.ORIGINAL_IMAGE_HEIGHT, image_height), resample=Image.Resampling.BICUBIC)

def _draw_capped_line(draw: ImageDraw.ImageDraw, x1: float, y1: float, x2: float, y2: float, *, fill: str, width: int) -> None:
    draw.line((x1, y1, x2, y2), fill=fill, width=width+1)
    draw.ellipse((x1 - width / 2, y1 - width / 2, x1 + width / 2, y1 + width / 2), fill=fill, width=0)
    draw.ellipse((x2 - width / 2, y2 - width / 2, x2 + width / 2, y2 + width / 2), fill=fill, width=0)

class _WarningImageGenerator(_IImageGenerator):
    FILL_COLOUR: str = '#660'
    OUTLINE_THICKNESS: int = 10
    OUTLINE_COLOUR: str = '#CC0'
    CORNER_CURVE_EXTENT: int = 30
    LINE_COLOUR: str = '#FFF'
    LINE_THICKNESS: int = 17
    BAR_TOP: int = 95
    BAR_BOTTOM: int = 135
    DOT_TOP: int = 155
    ORIGINAL_IMAGE_WIDTH: int = 200 + LINE_THICKNESS
    ORIGINAL_IMAGE_HEIGHT: int = 200 + LINE_THICKNESS

    def __init__(self) -> None:
        turtle: Turtle = Turtle()
        shape: TurtleShape = TurtleShape(turtle)
        shape \
            .line(RelPoint(left=100)) \
            .curve(RelPoint(right=100, up=200), extent=self.CORNER_CURVE_EXTENT) \
            .curve(RelPoint(right=100, down=200), extent=self.CORNER_CURVE_EXTENT) \
            .curve(RelPoint(left=100), extent=self.CORNER_CURVE_EXTENT)

        self.list_of_points: list[Point] = shape.calc_points(Alignment.NORTH_WEST, align_x=self.LINE_THICKNESS, align_y=self.LINE_THICKNESS)

    @override
    def render(self, *, image_height: int) -> Image.Image:
        image = Image.new('RGBA', size=(self.ORIGINAL_IMAGE_WIDTH, self.ORIGINAL_IMAGE_HEIGHT))
        draw: ImageDraw.ImageDraw = ImageDraw.Draw(image)
        draw.polygon(self.list_of_points, fill=self.FILL_COLOUR, outline=self.OUTLINE_COLOUR, width=self.LINE_THICKNESS)
        _draw_capped_line(draw, self.ORIGINAL_IMAGE_WIDTH / 2, self.BAR_TOP, self.ORIGINAL_IMAGE_WIDTH / 2, self.BAR_BOTTOM, fill=self.LINE_COLOUR, width=self.LINE_THICKNESS)
        draw.ellipse(((self.ORIGINAL_IMAGE_WIDTH - self.LINE_THICKNESS) / 2, self.DOT_TOP, (self.ORIGINAL_IMAGE_WIDTH + self.LINE_THICKNESS) / 2, self.DOT_TOP + self.LINE_THICKNESS), fill=self.LINE_COLOUR)
        return image.resize((image_height * self.ORIGINAL_IMAGE_WIDTH // self.ORIGINAL_IMAGE_HEIGHT, image_height), resample=Image.Resampling.BICUBIC)

_RATING_FILLED_IMAGE_GENERATOR_SINGLETON = RaiiSingleton(_RatingFilledImageGenerator)
_RATING_HOLLOW_IMAGE_GENERATOR_SINGLETON = RaiiSingleton(_RatingHollowImageGenerator)
_MISSING_AUTHOR_IMAGE_GENERATOR_SINGLETON = RaiiSingleton(_UnknownAuthorImageGenerator)
_DELETED_IMAGE_GENERATOR_SINGLETON = RaiiSingleton(_DeletedImageGenerator)
_STATUS_IMAGE_GENERATOR_SINGLETON = RaiiSingleton(_StatusImageGenerator)
_TOTM_NOMINEE_IMAGE_GENERATOR_SINGLETON = RaiiSingleton(_TotmNomineeImageGenerator)
_TOTM_WINNER_IMAGE_GENERATOR_SINGLETON = RaiiSingleton(_TotmWinnerImageGenerator)
_TOTM_HEADER_IMAGE_GENERATOR_SINGLETON = RaiiSingleton(_TotmHeaderImageGenerator)
_EOS_IMAGE_GENERATOR_SINGLETON = RaiiSingleton(_EosImageGenerator)
_FLASH_IMAGE_GENERATOR_SINGLETON = RaiiSingleton(_FlashImageGenerator)
_AUDIO_IMAGE_GENERATOR_SINGLETON = RaiiSingleton(_AudioImageGenerator)
_REGULAR_IMAGE_GENERATOR_SINGLETON = RaiiSingleton(_RegularImageGenerator)
_INPUT_INVALID_IMAGE_GENERATOR_SINGLETON = RaiiSingleton(_InputInvalidImageGenerator)
_INPUT_VALID_IMAGE_GENERATOR_SINGLETON = RaiiSingleton(_InputValidImageGenerator)
_INPUT_UNUSED_IMAGE_GENERATOR_SINGLETON = RaiiSingleton(_InputUnusedImageGenerator)
_WARNING_IMAGE_GENERATOR_SINGLETON = RaiiSingleton(_WarningImageGenerator)

def render_rating_filled_image(*, image_height: int) -> Image.Image:
    return _RATING_FILLED_IMAGE_GENERATOR_SINGLETON.instance.render(image_height = image_height)

def render_rating_hollow_image(*, image_height: int) -> Image.Image:
    return _RATING_HOLLOW_IMAGE_GENERATOR_SINGLETON.instance.render(image_height = image_height)

def render_unknown_author_image(*, image_height: int) -> Image.Image:
    return _MISSING_AUTHOR_IMAGE_GENERATOR_SINGLETON.instance.render(image_height = image_height)

def _render_deleted_image(*, image_height: int) -> Image.Image:
    return _DELETED_IMAGE_GENERATOR_SINGLETON.instance.render(image_height = image_height)

render_deleted_tease_image = _render_deleted_image
render_gone_author_image = _render_deleted_image

def render_status_image(*, image_height: int) -> Image.Image:
    return _STATUS_IMAGE_GENERATOR_SINGLETON.instance.render(image_height=image_height)

def render_totm_nominee_image(*, image_height: int) -> Image.Image:
    return _TOTM_NOMINEE_IMAGE_GENERATOR_SINGLETON.instance.render(image_height=image_height)

def render_totm_winner_image(*, image_height: int) -> Image.Image:
    return _TOTM_WINNER_IMAGE_GENERATOR_SINGLETON.instance.render(image_height=image_height)

def render_totm_header_image(*, image_height: int) -> Image.Image:
    return _TOTM_HEADER_IMAGE_GENERATOR_SINGLETON.instance.render(image_height=image_height)

def render_eos_image(*, image_height: int) -> Image.Image:
    return _EOS_IMAGE_GENERATOR_SINGLETON.instance.render(image_height=image_height)

def render_flash_image(*, image_height: int) -> Image.Image:
    return _FLASH_IMAGE_GENERATOR_SINGLETON.instance.render(image_height=image_height)

def render_audio_image(*, image_height: int) -> Image.Image:
    return _AUDIO_IMAGE_GENERATOR_SINGLETON.instance.render(image_height=image_height)

def render_regular_image(*, image_height: int) -> Image.Image:
    return _REGULAR_IMAGE_GENERATOR_SINGLETON.instance.render(image_height=image_height)

def render_input_invalid_image(*, image_height: int) -> Image.Image:
    return _INPUT_INVALID_IMAGE_GENERATOR_SINGLETON.instance.render(image_height=image_height)

def render_input_valid_image(*, image_height: int) -> Image.Image:
    return _INPUT_VALID_IMAGE_GENERATOR_SINGLETON.instance.render(image_height=image_height)

def render_input_unused_image(*, image_height: int) -> Image.Image:
    return _INPUT_UNUSED_IMAGE_GENERATOR_SINGLETON.instance.render(image_height=image_height)

def render_error_image(*, image_height: int) -> Image.Image:
    return _INPUT_INVALID_IMAGE_GENERATOR_SINGLETON.instance.render(image_height=image_height)

def render_warning_image(*, image_height: int) -> Image.Image:
    return _WARNING_IMAGE_GENERATOR_SINGLETON.instance.render(image_height=image_height)
