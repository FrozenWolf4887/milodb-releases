# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import tkinter as tk
import tkinter.font as tkfont
from collections.abc import Callable
from enum import Enum
from typing import Any, TYPE_CHECKING
from PIL import ImageTk
from milodb.client.output.match_indices import iterate_match_indices
from milodb.client.query.field_match import IFieldMatch
from milodb.client.view.gui.theme import get_font_of_themed_widget
from milodb.client.view.gui.widgets.styled_canvas import StyledCanvas
from milodb.client.view.gui.widgets.styled_text import StyledText
from milodb.common.view.gui.metrics import Bounds, MutableBounds, Padding, Point
if TYPE_CHECKING:
    from collections.abc import Sequence
    from milodb.client.view.gui.util.widget_id import WidgetId

def get_canvas_event_relative_coord(canvas: StyledCanvas, event: tk.Event) -> Point:
    """Translate the x, y coordinate of the event to the scrolled position.

    This also compensates for windowed widgets such as a Text widget where the
    coordinates of the event are relative to the upper left corner of the widget,
    not the canvas.
    """
    pos_x: float = canvas.canvasx(event.x)
    pos_y: float = canvas.canvasy(event.y)
    if not isinstance(event.widget, tk.Canvas):
        pos_x += event.widget.winfo_x()
        pos_y += event.widget.winfo_y()
    return Point(x = pos_x, y = pos_y)

class CanvasPlainText:
    def __init__(self, canvas: StyledCanvas, origin_x: int, origin_y: int, text: str, **kwargs: Any) -> None: # noqa: ANN401 Dynamically typed expressions (typing.Any) are disallowed:
        self._canvas: StyledCanvas = canvas
        self._widget_id: WidgetId = canvas.create_text(origin_x, origin_y, text=text, **kwargs)
        self._origin_x: int = origin_x
        self._origin_y: int = origin_y
        self._bounds: MutableBounds = Bounds.from_tuple(canvas.bbox(self._widget_id))

    @property
    def bounds(self) -> Bounds:
        return self._bounds

    def move_to(self, *, left: int | None = None, top: int | None = None) -> None:
        if left is None and top is None:
            return

        if left is None:
            left = self._origin_x
        if top is None:
            top = self._origin_y

        delta_x: int = left - self._origin_x
        delta_y: int = top - self._origin_y
        self._canvas.move(self._widget_id, delta_x, delta_y)
        self._bounds.translate(horizontal = delta_x, vertical = delta_y)
        self._origin_x += delta_x
        self._origin_y += delta_y

    def destroy(self) -> None:
        self._canvas.delete(self._widget_id)

class TextAlign(Enum):
    LEFT = 0
    CENTER = 1
    RIGHT = 2

class CanvasSequenceText:
    def __init__(self, canvas: StyledCanvas, origin_x: int, origin_y: int, text: str, align: TextAlign, font: tkfont.Font, foreground: str, highlight_foreground: str, highlight_background: str, highlight_padding: Padding, list_of_indices: list[IFieldMatch.Indices], tag: str) -> None:
        self._canvas: StyledCanvas = canvas
        self._list_of_widget_ids: list[WidgetId] = []

        text_height: int = font.metrics('linespace')
        start_x: int = origin_x

        def on_normal_text(text: str, *, is_first_item: bool, is_last_item: bool) -> None:
            _ = is_first_item
            _ = is_last_item

            nonlocal origin_x
            widget_id: WidgetId = self._canvas.create_text(
                origin_x, origin_y,
                text = text,
                anchor = tk.NW,
                font = font,
                fill = foreground,
                tags = tag,
            )
            self._list_of_widget_ids.append(widget_id)
            text_width: int = font.measure(text)
            origin_x += text_width

        def on_matched_text(text: str, *, is_first_item: bool, is_last_item: bool) -> None:
            _ = is_first_item
            _ = is_last_item

            nonlocal origin_x
            text_width: int = font.measure(text)
            widget_id: WidgetId = canvas.create_rectangle(
                origin_x - highlight_padding.left, origin_y - highlight_padding.top,
                origin_x + text_width - 1 + highlight_padding.right, origin_y + text_height - 1 + highlight_padding.bottom,
                fill = highlight_background,
                width = 0,
                tags = tag,
            )
            self._list_of_widget_ids.append(widget_id)
            widget_id = self._canvas.create_text(
                origin_x, origin_y,
                text = text,
                anchor = tk.NW,
                fill = highlight_foreground,
                font = font,
                tags = tag,
            )
            self._list_of_widget_ids.append(widget_id)
            origin_x += text_width

        iterate_match_indices(text, list_of_indices, on_normal_text, on_matched_text)

        self._bounds: MutableBounds = MutableBounds(start_x, origin_y, origin_x, origin_y + text_height)

        match align:
            case TextAlign.LEFT:
                pass
            case TextAlign.RIGHT:
                self.move_to(left = self._bounds.left - self._bounds.width)
            case TextAlign.CENTER:
                self.move_to(left = self._bounds.left - self._bounds.width // 2)

    @property
    def bounds(self) -> Bounds:
        return self._bounds

    def move_to(self, *, left: int | None = None, top: int | None = None) -> None:
        if left is None and top is None:
            return

        if left is None:
            left = self._bounds.left
        if top is None:
            top = self._bounds.top

        widget_id: WidgetId
        for widget_id in self._list_of_widget_ids:
            current_bounds: Bounds = Bounds.from_tuple(self._canvas.bbox(widget_id))
            new_left: int = (current_bounds.left - self._bounds.left) + left
            new_top: int = (current_bounds.top - self._bounds.top) + top
            self._canvas.move(widget_id, new_left - current_bounds.left, new_top - current_bounds.top)
        self._bounds.move_to(left, top)

    def destroy(self) -> None:
        self._canvas.delete(*self._list_of_widget_ids)

class CanvasStyledText:
    def __init__(self, canvas: StyledCanvas, text_widget: StyledText, *, origin_x: int, origin_y: int, width: int, call_on_height_changed: Callable[[], None] | None=None) -> None:
        self._canvas: StyledCanvas = canvas
        self._text_widget: StyledText = text_widget
        self._call_on_height_changed: Callable[[], None] | None = call_on_height_changed

        self._font_line_height: int = get_font_of_themed_widget(canvas, self._text_widget).metrics('linespace')
        self._bounds: MutableBounds = MutableBounds(origin_x, origin_y, origin_x + width, origin_y + self._text_widget.display_line_count * self._font_line_height)

        self._list_of_bindings: Sequence[str] = [
            self._text_widget.bind(StyledText.DISPLAY_LINE_COUNT_CHANGED_BINDING, self._on_display_line_count_changed),
        ]

        self._window_widget_id: WidgetId = canvas.create_window(
            self._bounds.left, self._bounds.top,
            width = self._bounds.width,
            height = self._bounds.height,
            window = self._text_widget,
            anchor = tk.NW,
        )

    @property
    def bounds(self) -> Bounds:
        return self._bounds

    @property
    def line_count(self) -> int:
        return self._text_widget.display_line_count

    def destroy(self) -> None:
        binding: str
        for binding in self._list_of_bindings:
            self._text_widget.unbind(binding)
        self._canvas.delete(self._window_widget_id)

    def move_to(self, *, left: int | None = None, top: int | None = None) -> None:
        if left is None and top is None:
            return

        if left is None:
            left = self._bounds.left
        if top is None:
            top = self._bounds.top

        self._canvas.move(self._window_widget_id, left - self._bounds.left, top - self._bounds.top)
        self._bounds.move_to(left, top)

    def resize(self, *, width: int) -> None:
        self._bounds.width = width
        self._canvas.itemconfig(self._window_widget_id, width=width)

    def _on_display_line_count_changed(self, _event: object) -> None:
        self._bounds.height = self._text_widget.display_line_count * self._font_line_height
        self._canvas.itemconfig(self._window_widget_id, height=self._bounds.height)
        if self._call_on_height_changed:
            self._call_on_height_changed()

class CanvasRoundedRectangle:
    def __init__(self, canvas: StyledCanvas, radius: int, *, left: int, top: int, right: int | None = None, bottom: int | None = None, width: int | None = None, height: int | None = None, outline_width: int = 0, **kwargs: Any) -> None: # noqa: ANN401 Dynamically typed expressions (typing.Any) are disallowed
        self._canvas = canvas
        self._bounds: MutableBounds = _resolve_bounds(
            left = left,
            top = top,
            right = right,
            bottom = bottom,
            width = width,
            height = height,
        )
        self._radius: int = radius
        points: tuple[float, ...] = CanvasRoundedRectangle._make_points(self._bounds, radius=self._radius)
        self._widget_id: int = canvas.create_polygon(points, smooth=True, width=outline_width, **kwargs)

    @property
    def widget_id(self) -> int:
        return self._widget_id

    @property
    def bounds(self) -> Bounds:
        return self._bounds

    def resize(self, *, width: int | None = None, height: int | None = None) -> None:
        if width is None and height is None:
            return

        if width is None:
            width = self._bounds.width
        if height is None:
            height = self._bounds.height

        self._bounds.resize(width, height)
        points: tuple[float, ...] = CanvasRoundedRectangle._make_points(self._bounds, radius=self._radius)
        self._canvas.coords(self._widget_id, *points)

    def change(self, *, left: int | None = None, top: int | None = None, right: int | None = None, bottom: int | None = None) -> None:
        if left is None and top is None and right is None and bottom is None:
            return

        if left is None:
            left = self._bounds.left
        if top is None:
            top = self._bounds.top
        if right is None:
            right = self._bounds.right
        if bottom is None:
            bottom = self._bounds.bottom

        self._bounds = MutableBounds(left, top, right, bottom)
        points: tuple[float, ...] = CanvasRoundedRectangle._make_points(self._bounds, radius=self._radius)
        self._canvas.coords(self._widget_id, *points)

    @staticmethod
    def _make_points(bounds: Bounds, *, radius: int) -> tuple[float, ...]:
        return (
            bounds.left + radius, bounds.top,
            bounds.left + radius, bounds.top,
            bounds.right - radius, bounds.top,
            bounds.right - radius, bounds.top,
            bounds.right, bounds.top,
            bounds.right, bounds.top + radius,
            bounds.right, bounds.top + radius,
            bounds.right, bounds.bottom - radius,
            bounds.right, bounds.bottom - radius,
            bounds.right, bounds.bottom,
            bounds.right - radius, bounds.bottom,
            bounds.right - radius, bounds.bottom,
            bounds.left + radius, bounds.bottom,
            bounds.left + radius, bounds.bottom,
            bounds.left, bounds.bottom,
            bounds.left, bounds.bottom - radius,
            bounds.left, bounds.bottom - radius,
            bounds.left, bounds.top + radius,
            bounds.left, bounds.top + radius,
            bounds.left, bounds.top,
        )

class CanvasChamferRectangle:
    def __init__(self, canvas: StyledCanvas, chamfer_size: int, *, left: int, top: int, right: int | None = None, bottom: int | None = None, width: int | None = None, height: int | None = None, outline_width: int = 0, **kwargs: Any) -> None: # noqa: ANN401 Dynamically typed expressions (typing.Any) are disallowed
        self._canvas = canvas
        self._bounds: MutableBounds = _resolve_bounds(
            left = left,
            top = top,
            right = right,
            bottom = bottom,
            width = width,
            height = height,
        )
        self._chamfer_size: int = chamfer_size
        points: tuple[float, ...] = CanvasChamferRectangle._make_points(self._bounds, chamfer_size=self._chamfer_size)
        self._widget_id: int = canvas.create_polygon(points, width=outline_width, **kwargs)

    @property
    def widget_id(self) -> int:
        return self._widget_id

    @property
    def bounds(self) -> Bounds:
        return self._bounds

    def move_to(self, *, left: int | None = None, top: int | None = None) -> None:
        if left is None and top is None:
            return

        if left is None:
            left = self._bounds.left
        if top is None:
            top = self._bounds.top

        self._canvas.move(self._widget_id, left - self._bounds.left, top - self._bounds.top)
        self._bounds.move_to(left, top)

    def resize(self, *, width: int | None = None, height: int | None = None) -> None:
        if width is None and height is None:
            return

        if width is None:
            width = self._bounds.width
        if height is None:
            height = self._bounds.height

        self._bounds.resize(width, height)
        points: tuple[float, ...] = CanvasChamferRectangle._make_points(self._bounds, chamfer_size=self._chamfer_size)
        self._canvas.coords(self._widget_id, *points)

    def change(self, *, left: int | None = None, top: int | None = None, right: int | None = None, bottom: int | None = None) -> None:
        if left is None and top is None and right is None and bottom is None:
            return

        if left is None:
            left = self._bounds.left
        if top is None:
            top = self._bounds.top
        if right is None:
            right = self._bounds.right
        if bottom is None:
            bottom = self._bounds.bottom

        self._bounds = MutableBounds(left, top, right, bottom)
        points: tuple[float, ...] = CanvasChamferRectangle._make_points(self._bounds, chamfer_size=self._chamfer_size)
        self._canvas.coords(self._widget_id, *points)

    def set_fill(self, fill: str) -> None:
        self._canvas.itemconfig(self._widget_id, fill=fill)

    @staticmethod
    def _make_points(bounds: Bounds, *, chamfer_size: int) -> tuple[float, ...]:
        return (
            bounds.left + chamfer_size, bounds.top,
            bounds.right - chamfer_size, bounds.top,
            bounds.right, bounds.top + chamfer_size,
            bounds.right, bounds.bottom - chamfer_size,
            bounds.right - chamfer_size, bounds.bottom,
            bounds.left + chamfer_size, bounds.bottom,
            bounds.left, bounds.bottom - chamfer_size,
            bounds.left, bounds.top + chamfer_size,
        )

class CanvasRectangle:
    def __init__(self, canvas: StyledCanvas, *, left: int, top: int, right: int | None = None, bottom: int | None = None, width: int | None = None, height: int | None = None, outline_width: int = 0, **kwargs: Any) -> None: # noqa: ANN401 Dynamically typed expressions (typing.Any) are disallowed
        self._canvas = canvas
        self._bounds: MutableBounds = _resolve_bounds(
            left = left,
            top = top,
            right = right,
            bottom = bottom,
            width = width,
            height = height,
        )
        self._widget_id: int = canvas.create_rectangle(self._bounds.left, self._bounds.top, self._bounds.right, self._bounds.bottom, width=outline_width, **kwargs)

    @property
    def widget_id(self) -> int:
        return self._widget_id

    @property
    def bounds(self) -> Bounds:
        return self._bounds

    def move_to(self, *, left: int | None = None, top: int | None = None) -> None:
        if left is None and top is None:
            return

        if left is None:
            left = self._bounds.left
        if top is None:
            top = self._bounds.top

        self._canvas.move(self._widget_id, left - self._bounds.left, top - self._bounds.top)
        self._bounds.move_to(left, top)

    def resize(self, *, width: int | None = None, height: int | None = None) -> None:
        if height is None and width is None:
            return

        if width is None:
            width = self._bounds.width
        if height is None:
            height = self._bounds.height

        self._bounds.resize(width, height)
        self._canvas.coords(self._widget_id, *self._bounds.to_tuple())

    def change(self, *, left: int | None = None, top: int | None = None, right: int | None = None, bottom: int | None = None) -> None:
        if left is None and top is None and right is None and bottom is None:
            return

        if left is None:
            left = self._bounds.left
        if top is None:
            top = self._bounds.top
        if right is None:
            right = self._bounds.right
        if bottom is None:
            bottom = self._bounds.bottom

        self._bounds = MutableBounds(left, top, right, bottom)
        self._canvas.coords(self._widget_id, *self._bounds.to_tuple())

    def set_fill(self, fill: str) -> None:
        self._canvas.itemconfig(self._widget_id, fill=fill)

class CanvasImage:
    def __init__(self, canvas: StyledCanvas, image: tk.PhotoImage | ImageTk.PhotoImage, x: int, y: int, **kwargs: Any) -> None: # noqa: ANN401 Dynamically typed expressions (typing.Any) are disallowed:
        self._image: tk.PhotoImage | ImageTk.PhotoImage = image
        self._widget_id : WidgetId= canvas.create_image(x, y, image=image, **kwargs)
        self._bounds: Bounds = Bounds.from_tuple(canvas.bbox(self._widget_id))

    @property
    def widget_id(self) -> int:
        return self._widget_id

    @property
    def bounds(self) -> Bounds:
        return self._bounds

def _resolve_bounds(*, left: int, top: int, right: int | None = None, bottom: int | None = None, width: int | None = None, height: int | None = None) -> MutableBounds:
    if right is None:
        if width is None:
            msg = "Must specify either 'right' or 'width'"
            raise AssertionError(msg)
        right = left + width
    elif width is not None:
        msg = "Specify either 'right' or 'width', not both"
        raise AssertionError(msg)

    if bottom is None:
        if height is None:
            msg = "Must specify either 'bottom' or 'height'"
            raise AssertionError(msg)
        bottom = top + height
    elif height is not None:
        msg = "Specify either 'bottom' or 'height', not both"
        raise AssertionError(msg)

    return MutableBounds(left, top, right, bottom)
