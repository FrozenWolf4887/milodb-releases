# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from math import cos, pi, sin
from milodb.common.view.gui.metrics import Point

def make_star_points(*, left: int, top: int, number_of_points: int, outer_radius: float, inner_radius: float, outer_rotation_radians: float, inner_rotation_radians: float) -> list[Point]:
    list_of_points: list[Point] = []

    for point in range(number_of_points * 2):
        angle: float
        x: float
        y: float
        if point & 1 == 0:
            angle = outer_rotation_radians + (2.0 * pi * point / (number_of_points * 2))
            x = left + outer_radius + outer_radius * cos(angle)
            y = top + outer_radius + outer_radius * sin(angle)
        else:
            angle = inner_rotation_radians + (2.0 * pi * point / (number_of_points * 2))
            x = left + outer_radius + inner_radius * cos(angle)
            y = top + outer_radius + inner_radius * sin(angle)
        list_of_points.append(Point(x, y))

    return list_of_points

def make_bezier_points(number_of_segments: int, point1: Point, point2: Point, point3: Point, point4: Point | None = None, *, include_first_point: bool=True, include_last_point: bool=True) -> list[Point]:
    if point4 is None:
        return make_quadratic_bezier_points(number_of_segments, point1, point2, point3, include_first_point=include_first_point, include_last_point=include_last_point)
    return make_cubic_bezier_points(number_of_segments, point1, point2, point3, point4, include_first_point=include_first_point, include_last_point=include_last_point)

def make_quadratic_bezier_points(number_of_segments: int, point1: Point, point2: Point, point3: Point, *, include_first_point: bool=True, include_last_point: bool=True) -> list[Point]:
    list_of_segments: list[Point] = []

    if include_first_point:
        list_of_segments.append(point1)

    offset: int
    for offset in range(1, number_of_segments):
        coeff: float = offset / number_of_segments
        q: Point = _interpolate(point1, point2, coeff)
        r: Point = _interpolate(point2, point3, coeff)
        s: Point = _interpolate(q, r, coeff)
        list_of_segments.append(s)

    if include_last_point:
        list_of_segments.append(point3)

    return list_of_segments

def make_cubic_bezier_points(number_of_segments: int, point1: Point, point2: Point, point3: Point, point4: Point, *, include_first_point: bool=True, include_last_point: bool=True) -> list[Point]:
    list_of_segments: list[Point] = []

    if include_first_point:
        list_of_segments.append(point1)

    offset: int
    for offset in range(1, number_of_segments):
        coeff: float = offset / number_of_segments
        q: Point = _interpolate(point1, point2, coeff)
        r: Point = _interpolate(point2, point3, coeff)
        s: Point = _interpolate(point3, point4, coeff)
        t: Point = _interpolate(q, r, coeff)
        u: Point = _interpolate(r, s, coeff)
        v: Point = _interpolate(t, u, coeff)
        list_of_segments.append(v)

    if include_last_point:
        list_of_segments.append(point4)

    return list_of_segments

def _interpolate(point1: Point, point2: Point, coeff: float) -> Point:
    return Point(
        point1.x + coeff * (point2.x - point1.x),
        point1.y + coeff * (point2.y - point1.y),
    )
