# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import tkinter as tk
from collections.abc import Sequence
from tkinter import ttk
from typing import Any

class WrappingLabel(ttk.Label):
    def __init__(self, master: tk.Misc, **kwargs: Any) -> None: # noqa: ANN401 Dynamically typed expressions (typing.Any) are disallowed:
        super().__init__(master, **kwargs)
        self._style = ttk.Style()
        self.bind("<Configure>", self._on_configure)
        self._current_width: int = -1

    def _on_configure(self, _: object) -> None:
        width: int = self._get_width_within_container()
        if width not in (-1, self._current_width):
            self._current_width = width
            self.configure(wraplength=width)

    def _get_width_within_container(self) -> int:
        if self.winfo_manager() != 'grid':
            return self.winfo_width()

        grid_info = self.grid_info()
        try:
            column: int = grid_info['column']
            column_span: int = grid_info['columnspan']
            row: int = grid_info['row']
            row_span: int = grid_info['rowspan']
            cell_padx: int | tuple[int, int] = grid_info['padx']
            cell_ipadx: int = grid_info['ipadx']
            style_name: str = self.cget('style')
            label_padding: object = self._style.lookup(style_name, 'padding')
            label_borderwidth: object = self._style.lookup(style_name, 'borderwidth')
        except (AttributeError, tk.TclError):
            return -1

        bounding_box: tuple[int, int, int, int] | None = self.master.grid_bbox(column, row, column + column_span - 1, row + row_span - 1)
        if bounding_box is None:
            return -1

        width: int = bounding_box[2]
        width -= cell_ipadx * 2

        if isinstance(label_padding, int):
            width -= label_padding * 2
        elif isinstance(label_padding, Sequence) and isinstance(label_padding[0], int):
            width -= label_padding[0] * 2

        if isinstance(cell_padx, int):
            width -= cell_padx * 2
        else:
            width -= sum(cell_padx)

        if isinstance(label_borderwidth, int):
            width -= label_borderwidth

        return width
