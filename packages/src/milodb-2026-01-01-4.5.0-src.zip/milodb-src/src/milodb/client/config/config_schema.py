# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from milodb.common.config.framework import ConfigEnumLeaf, ConfigGroup, ConfigTextLeaf, IConfigGroup
from milodb.common.config.i_launch_config import LaunchOption

# pylint: disable=too-many-statements
class _ConfigSchema(ConfigGroup):
    def __init__(self) -> None:
        super().__init__(None, '')
        self.version = ConfigTextLeaf(self, 'configVersion', '3', is_protected=True)
        self.update = self.UpdateGroup(self, 'update')
        self.commands = self.CommandsGroup(self, 'commands')
        self.format = self.FormatGroup(self, 'format')
    class UpdateGroup(ConfigGroup):
        def __init__(self, parent: IConfigGroup, key_name: str) -> None:
            super().__init__(parent, key_name)
            self.backup_directory = ConfigTextLeaf(self, 'backupDirectory', 'update-backup')
            self.update_directory_url = ConfigTextLeaf(self, 'updateDirectoryUri', 'https://raw.githubusercontent.com/FrozenWolf4887/milodb-releases/main/updater/directory.json')
    class CommandsGroup(ConfigGroup):
        def __init__(self, parent: IConfigGroup, key_name: str) -> None:
            super().__init__(parent, key_name)
            self.browse = self.PlatformLaunchGroup(self, 'browse')
            self.open = self.PlatformLaunchGroup(self, 'open')
        class PlatformLaunchGroup(ConfigGroup):
            def __init__(self, parent: IConfigGroup, key_name: str) -> None:
                super().__init__(parent, key_name)
                self.windows = self.LaunchGroup(self, 'windows')
                self.linux = self.LaunchGroup(self, 'linux')
            class LaunchGroup(ConfigGroup):
                def __init__(self, parent: IConfigGroup, key_name: str) -> None:
                    super().__init__(parent, key_name)
                    self.launch_option = ConfigEnumLeaf(self, 'launchOption', LaunchOption, LaunchOption.DEFAULT)
                    self.custom_launch_command = ConfigTextLeaf(self, 'customLaunchCommand', '')
    class FormatGroup(ConfigGroup):
        def __init__(self, parent: IConfigGroup, key_name: str) -> None:
            super().__init__(parent, key_name)
            self.ansi = self.AnsiGroup(self, 'ansi')
            self.bbcode = self.BBCodeGroup(self, 'bbcode')
            self.html = self.HtmlGroup(self, 'html')
        class AnsiGroup(ConfigGroup):
            def __init__(self, parent: IConfigGroup, key_name: str) -> None:
                super().__init__(parent, key_name)
                self.colour = self.ColourGroup(self, 'colour')
            class ColourGroup(ConfigGroup):
                def __init__(self, parent: IConfigGroup, key_name: str) -> None:
                    super().__init__(parent, key_name)
                    self.index_heading = ConfigTextLeaf(self, 'indexHeading', '0')
                    self.hits_heading = ConfigTextLeaf(self, 'hitsHeading', '0')
                    self.tease_heading = ConfigTextLeaf(self, 'teaseHeading', '34')
                    self.author_heading = ConfigTextLeaf(self, 'authorHeading', '32')
                    self.type_heading = ConfigTextLeaf(self, 'typeHeading', '33')
                    self.date_heading = ConfigTextLeaf(self, 'dateHeading', '33')
                    self.rating_heading = ConfigTextLeaf(self, 'ratingHeading', '35')
                    self.tags_heading = ConfigTextLeaf(self, 'tagsHeading', '35')
                    self.summary_heading = ConfigTextLeaf(self, 'summaryHeading', '36')
                    self.deleted_heading = ConfigTextLeaf(self, 'deletedHeading', '33;1')
                    self.author_gone_heading = ConfigTextLeaf(self, 'authorGoneHeading', '35;1')
                    self.page_heading = ConfigTextLeaf(self, 'pageHeading', '1')
                    self.page_name = ConfigTextLeaf(self, 'pageName', '1')
                    self.matching_text_heading = ConfigTextLeaf(self, 'matchingTextHeading', '34')
                    self.matching_text = ConfigTextLeaf(self, 'matchingText', '4;31')
                    self.ellipsis = ConfigTextLeaf(self, 'ellipsis', '30;1')
        class BBCodeGroup(ConfigGroup):
            def __init__(self, parent: IConfigGroup, key_name: str) -> None:
                super().__init__(parent, key_name)
                self.colour = self.ColourGroup(self, 'colour')
            class ColourGroup(ConfigGroup):
                def __init__(self, parent: IConfigGroup, key_name: str) -> None:
                    super().__init__(parent, key_name)
                    self.index_heading = ConfigTextLeaf(self, 'indexHeading', '#808080')
                    self.hits_heading = ConfigTextLeaf(self, 'hitsHeading', '#808080')
                    self.tease_heading = ConfigTextLeaf(self, 'teaseHeading', '#000060')
                    self.author_heading = ConfigTextLeaf(self, 'authorHeading', '#006000')
                    self.type_heading = ConfigTextLeaf(self, 'typeHeading', '#606000')
                    self.date_heading = ConfigTextLeaf(self, 'dateHeading', '#606000')
                    self.rating_heading = ConfigTextLeaf(self, 'ratingHeading', '#600060')
                    self.tags_heading = ConfigTextLeaf(self, 'tagsHeading', '#600060')
                    self.summary_heading = ConfigTextLeaf(self, 'summaryHeading', '#007070')
                    self.deleted_heading = ConfigTextLeaf(self, 'deletedHeading', '#909000')
                    self.author_gone_heading = ConfigTextLeaf(self, 'authorGoneHeading', '#900090')
                    self.page_heading = ConfigTextLeaf(self, 'pageHeading', '#808080')
                    self.page_name = ConfigTextLeaf(self, 'pageName', '#000000')
                    self.matching_text_heading = ConfigTextLeaf(self, 'matchingTextHeading', '#600060')
                    self.matching_text = ConfigTextLeaf(self, 'matchingText', '#FF0000')
                    self.ellipsis = ConfigTextLeaf(self, 'ellipsis', '#808080')
        class HtmlGroup(ConfigGroup):
            def __init__(self, parent: IConfigGroup, key_name: str) -> None:
                super().__init__(parent, key_name)
                self.css_file_path = ConfigTextLeaf(self, 'cssFilePath', 'default-light.css')

CONFIG_SCHEMA: _ConfigSchema = _ConfigSchema()
