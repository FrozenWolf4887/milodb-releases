# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import contextlib
import sys
from abc import ABC, abstractmethod
from collections.abc import MutableMapping
from typing import override
from milodb.client.config.config_schema import CONFIG_SCHEMA
from milodb.common.config.migration_result import ConfigMigrationResult
from milodb.common.output.print.i_printer import IPrinter

def try_migrate_config(config_dict: MutableMapping[object, object], normal_printer: IPrinter, error_printer: IPrinter) -> ConfigMigrationResult:
    config_version: object = config_dict.get(CONFIG_SCHEMA.version.key_name)
    if not isinstance(config_version, str):
        error_printer.writeln(f"Unable to identify current config version because key '{CONFIG_SCHEMA.version.full_path}' is missing or not text")
        return ConfigMigrationResult.FAILED

    map_of_version_to_migration_chain: dict[str, tuple[type[_MigrateConfig], ...]] = {
        '1': (_MigrateConfigV1toV2, _MigrateConfigV2toV3),
        '2': (_MigrateConfigV2toV3,),
        '3': (),
    }

    migration_chain: tuple[type[_MigrateConfig], ...] | None = map_of_version_to_migration_chain.get(config_version)
    if migration_chain is None:
        error_printer.writeln(f"Unknown config file version '{config_version}' specified by key '{CONFIG_SCHEMA.version.full_path}'")
        return ConfigMigrationResult.FAILED

    migration_result: ConfigMigrationResult = ConfigMigrationResult.NOT_NEEDED
    migrator_class: type[_MigrateConfig]
    for migrator_class in migration_chain:
        migration_result = migrator_class(normal_printer, error_printer).run(config_dict)
        if migration_result is not ConfigMigrationResult.SUCCESSFUL:
            break

    return migration_result

class _MigrateConfig(ABC):
    def __init__(self, normal_printer: IPrinter, error_printer: IPrinter) -> None:
        self._normal_printer: IPrinter = normal_printer
        self._error_printer: IPrinter = error_printer
        self._was_successful: bool = True

    @abstractmethod
    def run(self, config_dict: MutableMapping[object, object]) -> ConfigMigrationResult:
        pass

    def _create_group(self, config_dict: MutableMapping[object, object], path: str) -> None:
        current_group: MutableMapping[object, object] = config_dict
        part: str
        for part in path.split('/'):
            group: object = current_group.get(part)
            if group is None:
                group = {}
                current_group[part] = group
                self._normal_printer.writeln(f"- Created '{path}'")
            elif not isinstance(group, dict):
                self._was_successful = False
                self._error_printer.writeln(f"Failed to create group '{path}' because part '{part}' already exists and is not a group")
                return
            current_group = group

    def _delete_group(self, config_dict: MutableMapping[object, object], path: str) -> None:
        path_group: str | None
        path_key: str
        path_group, path_key = _split_group_and_key(path)
        group: MutableMapping[object, object] | None = self._try_find_group(config_dict, path_group)
        if group:
            with contextlib.suppress(KeyError):
                del group[path_key]
                self._normal_printer.writeln(f"- Removed '{path}'")

    def _move_key(self, config_dict: MutableMapping[object, object], source_path: str, target_path: str) -> None:
        source_path_group: str | None
        source_path_key: str
        source_path_group, source_path_key = _split_group_and_key(source_path)
        target_path_group: str | None
        target_path_key: str
        target_path_group, target_path_key = _split_group_and_key(target_path)

        source_group: MutableMapping[object, object] | None = self._try_find_group(config_dict, source_path_group)
        if source_group is not None:
            target_group: MutableMapping[object, object] | None = self._try_find_group(config_dict, target_path_group)
            if target_group is not None:
                value: object = source_group.pop(source_path_key, None)
                if value is not None:
                    target_group[target_path_key] = value
                    self._normal_printer.writeln(f"- Shifted '{source_path}' to '{target_path}'")
            else:
                self._was_successful = False
                self._error_printer.writeln(f"Failed to find group '{target_path}'")

    def _set_key(self, config_dict: MutableMapping[object, object], path: str, value: str) -> None:
        path_group: str | None
        path_key: str
        path_group, path_key = _split_group_and_key(path)
        group: MutableMapping[object, object] | None = self._try_find_group(config_dict, path_group)
        if group is not None:
            group[path_key] = value
            self._normal_printer.writeln(f"- Changed '{path}'")
        else:
            self._was_successful = False
            self._error_printer.writeln(f"Failed to find group '{path}'")

    def _update_key_if(self, config_dict: MutableMapping[object, object], path: str, *, if_value: str, change_to: str) -> None:
        path_group: str | None
        path_key: str
        path_group, path_key = _split_group_and_key(path)
        group: MutableMapping[object, object] | None = self._try_find_group(config_dict, path_group)
        if group is not None:
            value: object = group.get(path_key)
            if value == if_value:
                group[path_key] = change_to
                self._normal_printer.writeln(f"- Updated '{path}'")

    def _try_find_group(self, config_dict: MutableMapping[object, object], path: str | None) -> MutableMapping[object, object] | None:
        if not path:
            return config_dict

        current_group: MutableMapping[object, object] = config_dict
        part: str
        for part in path.split('/'):
            group: object = current_group.get(part)
            if group is None:
                return None
            if not isinstance(group, dict):
                self._was_successful = False
                self._error_printer.writeln(f"Failed to find group '{path}' because part '{part}' is not a group")
                return None
            current_group = group
        return current_group

class _MigrateConfigV1toV2(_MigrateConfig):
    @override
    def run(self, config_dict: MutableMapping[object, object]) -> ConfigMigrationResult:
        self._normal_printer.writeln('* Migrating config from v1 to v2')
        platform_key_name: str = 'windows' if sys.platform == 'win32' else 'linux'
        self._create_group(config_dict, f'commands/browse/{platform_key_name}')
        self._move_key(config_dict, 'commands/browse/customLaunchCommand', f'commands/browse/{platform_key_name}/customLaunchCommand')
        self._move_key(config_dict, 'commands/browse/launchOption', f'commands/browse/{platform_key_name}/launchOption')
        self._create_group(config_dict, f'commands/open/{platform_key_name}')
        self._move_key(config_dict, 'commands/open/customLaunchCommand', f'commands/open/{platform_key_name}/customLaunchCommand')
        self._move_key(config_dict, 'commands/open/launchOption', f'commands/open/{platform_key_name}/launchOption')
        self._set_key(config_dict, CONFIG_SCHEMA.version.full_path, '2')
        return ConfigMigrationResult.SUCCESSFUL if self._was_successful else ConfigMigrationResult.FAILED

class _MigrateConfigV2toV3(_MigrateConfig):
    @override
    def run(self, config_dict: MutableMapping[object, object]) -> ConfigMigrationResult:
        self._normal_printer.writeln('* Migrating config from v2 to v3')
        self._move_key(config_dict, 'format/html/css/filePath', 'format/html/cssFilePath')
        self._update_key_if(config_dict, 'format/html/cssFilePath', if_value='default.css', change_to='default-light.css')
        self._delete_group(config_dict, 'format/html/css')
        self._set_key(config_dict, CONFIG_SCHEMA.version.full_path, '3')
        return ConfigMigrationResult.SUCCESSFUL if self._was_successful else ConfigMigrationResult.FAILED

_TWO_PARTS: int = 2

def _split_group_and_key(path: str) -> tuple[str | None, str]:
    split: list[str] = path.rsplit('/', 1)
    if len(split) < _TWO_PARTS:
        return None, split[0]
    return split[0], split[1]
