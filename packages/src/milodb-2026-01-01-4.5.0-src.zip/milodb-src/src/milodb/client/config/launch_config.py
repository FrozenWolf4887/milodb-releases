# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import sys
from typing import override
from milodb.client.config.config_schema import CONFIG_SCHEMA
from milodb.common.config.framework import IConfig
from milodb.common.config.i_launch_config import ILaunchConfig, LaunchOption

_IS_WINDOWS: bool = sys.platform == 'win32'

class BrowseLaunchConfig(ILaunchConfig):
    def __init__(self, config: IConfig) -> None:
        self._config = config

    @property
    @override
    def launch_option(self) -> LaunchOption:
        return CONFIG_SCHEMA.commands.browse.windows.launch_option.fetch_enum_value_or_default(self._config) if _IS_WINDOWS else \
               CONFIG_SCHEMA.commands.browse.linux.launch_option.fetch_enum_value_or_default(self._config)

    @property
    @override
    def custom_launch_command(self) -> str:
        return CONFIG_SCHEMA.commands.browse.windows.custom_launch_command.fetch_value_or_default(self._config) if _IS_WINDOWS else \
               CONFIG_SCHEMA.commands.browse.linux.custom_launch_command.fetch_value_or_default(self._config)

    @property
    @override
    def custom_launch_as_shell(self) -> bool:
        return True

class OpenLaunchConfig(ILaunchConfig):
    def __init__(self, config: IConfig) -> None:
        self._config = config

    @property
    @override
    def launch_option(self) -> LaunchOption:
        return CONFIG_SCHEMA.commands.open.windows.launch_option.fetch_enum_value_or_default(self._config) if _IS_WINDOWS else \
               CONFIG_SCHEMA.commands.open.linux.launch_option.fetch_enum_value_or_default(self._config)

    @property
    @override
    def custom_launch_command(self) -> str:
        return CONFIG_SCHEMA.commands.open.windows.custom_launch_command.fetch_value_or_default(self._config) if _IS_WINDOWS else \
               CONFIG_SCHEMA.commands.open.linux.custom_launch_command.fetch_value_or_default(self._config)

    @property
    @override
    def custom_launch_as_shell(self) -> bool:
        return True
