# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from collections.abc import Mapping
from enum import Enum
from typing import NamedTuple
from milodb.client.database.metadata_getter import MetadataGetter

_KEY_AUTHOR_NAME: str = 'anm'
_KEY_AUTHOR_GONE: str = 'agn'

class AuthorStatus(Enum):
    ACTIVE = 0
    UNKNOWN = 1
    GONE = 2

class AuthorLoadError(Exception):
    pass

class Author(NamedTuple):
    author_id: int
    name: str
    has_gone: bool

    @property
    def status(self) -> AuthorStatus:
        if not self.name:
            return AuthorStatus.UNKNOWN
        if self.has_gone:
            return AuthorStatus.GONE
        return AuthorStatus.ACTIVE

def load_author(author_id: int, metadata: Mapping[object, object]) -> Author:
    """Create an Author object from JSON metadata.

    ### Raises
    - AuthorLoadError
    """
    getter: MetadataGetter = MetadataGetter(metadata, AuthorLoadError)
    author_name: str = getter.get_str_or_blank(_KEY_AUTHOR_NAME)
    has_author_gone: bool = getter.get_bool_or_default(_KEY_AUTHOR_GONE, default=False)
    return Author(
        author_id,
        author_name,
        has_author_gone,
    )
