# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import json
import lzma
from collections.abc import Mapping
from dataclasses import dataclass
from pathlib import Path
from milodb.client.output.print_timed_activity import PrintTimedActivity
from milodb.client.view.progress_display import IProgressDisplay, PercentageSlice
from milodb.common.output.print.i_printer import IPrinter

_DATABASE_HEADER_BYTE_COUNT: int = 4
_DATABASE_FORMAT_KEY: str = 'fmt'
_DATABASE_FORMAT_VALUE: int = 2
_DATABASE_INDEX_KEY: str = 'idx'

@dataclass
class _ThumbnailDataReference:
    begin_offset: int
    end_offset: int

class ThumbnailDatabase:
    def __init__(self, map_of_thumbnail_key_to_data_reference: dict[str, _ThumbnailDataReference], thumbnail_data: bytes) -> None:
        self._map_of_thumbnail_key_to_data_reference: dict[str, _ThumbnailDataReference] = map_of_thumbnail_key_to_data_reference
        self._thumbnail_data: bytes = thumbnail_data

    @property
    def number_of_thumbnails(self) -> int:
        return len(self._map_of_thumbnail_key_to_data_reference)

    def try_get_thumbnail_data(self, key: str) -> bytes | None:
        data_reference: _ThumbnailDataReference | None = self._map_of_thumbnail_key_to_data_reference.get(key)
        if data_reference:
            return self._thumbnail_data[data_reference.begin_offset:data_reference.end_offset]
        return None

def load_thumbnail_database(database_filepath: Path, progress_display: IProgressDisplay, percentage_slice: PercentageSlice) -> ThumbnailDatabase:
    with PrintTimedActivity(progress_display.normal_printer, 'Load thumbnails\n', 'Load completed: '):
        try:
            return _load_from_file(database_filepath, progress_display, percentage_slice)
        except _LoadError as ex:
            progress_display.error_printer.writeln(str(ex))
        return ThumbnailDatabase({}, b'')

class _LoadError(Exception):
    pass

def _load_from_file(database_filepath: Path, progress_display: IProgressDisplay, percentage_slice: PercentageSlice) -> ThumbnailDatabase:
    progress_display.set_activity_text('Thumbnails: Read')
    raw_file_bytes: bytes = _read_file(database_filepath, progress_display.normal_printer)
    size_of_json: int = int.from_bytes(raw_file_bytes[:_DATABASE_HEADER_BYTE_COUNT])
    data_begin_offset: int = _DATABASE_HEADER_BYTE_COUNT + size_of_json
    percentage_slice.set_progress_percentage(10)

    progress_display.set_activity_text('Thumbnails: Unpack index')
    packed_json_bytes: bytes = raw_file_bytes[_DATABASE_HEADER_BYTE_COUNT:data_begin_offset]
    json_bytes: bytes = _unpack_contents(packed_json_bytes, progress_display.normal_printer)
    percentage_slice.set_progress_percentage(12)

    progress_display.set_activity_text('Thumbnails: Parse index')
    json_dict: Mapping[object, object] = _parse_json(json_bytes, progress_display.normal_printer)
    _check_format(json_dict)
    map_of_thumbnails: Mapping[object, object] = _get_json_map_of_thumbnails(json_dict)
    percentage_slice.set_progress_percentage(13)

    progress_display.set_activity_text('Thumbnails: Unpack images')
    thumbnail_data: bytes = _unpack_contents(raw_file_bytes[data_begin_offset:], progress_display.normal_printer)
    percentage_slice.set_progress_percentage(99)

    progress_display.set_activity_text('Thumbnails: Assemble images')
    map_of_thumbnail_key_to_data_reference: dict[str, _ThumbnailDataReference] = _build_thumbnail_indices(map_of_thumbnails, progress_display.normal_printer)
    percentage_slice.set_progress_percentage(100)

    return ThumbnailDatabase(
        map_of_thumbnail_key_to_data_reference,
        thumbnail_data,
    )

def _read_file(database_filepath: Path, normal_printer: IPrinter) -> bytes:
    with PrintTimedActivity(normal_printer, '  Read', '     : '):
        try:
            return database_filepath.read_bytes()
        except OSError as ex:
            msg = f"File access error: {ex}"
            raise _LoadError(msg) from ex

def _unpack_contents(raw_file_contents: bytes, normal_printer: IPrinter) -> bytes:
    with PrintTimedActivity(normal_printer, '  Unpack', '   : '):
        try:
            return lzma.decompress(raw_file_contents)
        except lzma.LZMAError as ex:
            msg = f"Unpack failed: {ex}"
            raise _LoadError(msg) from ex

def _parse_json(file_contents: bytes, normal_printer: IPrinter) -> Mapping[object, object]:
    with PrintTimedActivity(normal_printer, '  Parse', '    : '):
        try:
            json_root: object = json.loads(file_contents)
        except json.JSONDecodeError as ex:
            msg = f"JSON decode error: {ex}"
            raise _LoadError(msg) from ex

        if not isinstance(json_root, Mapping):
            msg = 'Database root is not a dictionary'
            raise _LoadError(msg)

        return json_root

def _check_format(json_dict: Mapping[object, object]) -> None:
    raw_format: object = json_dict.get(_DATABASE_FORMAT_KEY)
    if raw_format is None:
        msg = f"Database format key '{_DATABASE_FORMAT_KEY}' missing"
        raise _LoadError(msg)
    if not isinstance(raw_format, int):
        msg = f"Database format key value '{_DATABASE_FORMAT_KEY}' is not an integer"
        raise _LoadError(msg)
    if raw_format != _DATABASE_FORMAT_VALUE:
        msg = f"Database has format '{raw_format}' which is not the expected format '{_DATABASE_FORMAT_VALUE}'"
        raise _LoadError(msg)

def _get_json_map_of_thumbnails(json_dict: Mapping[object, object]) -> dict[object, object]:
    json_list: object = json_dict.get(_DATABASE_INDEX_KEY)
    if json_list is None:
        msg = f"Database index key '{_DATABASE_INDEX_KEY}' missing"
        raise _LoadError(msg)
    if not isinstance(json_list, dict):
        msg = f"Database index key value '{_DATABASE_INDEX_KEY}' is not a dictionary"
        raise _LoadError(msg)
    return json_list

def _build_thumbnail_indices(map_of_thumbnails: Mapping[object, object], normal_printer: IPrinter) -> dict[str, _ThumbnailDataReference]:
    map_of_thumbnail_key_to_data_reference: dict[str, _ThumbnailDataReference] = {}

    with PrintTimedActivity(normal_printer, '  Assemble', ' : '):
        thumbnail_begin_offset: int = 0
        url: object
        file_size_bytes: object
        for url, file_size_bytes in map_of_thumbnails.items():
            if not isinstance(url, str):
                msg = f"Database thumbnail key type '{type(url)}' is not a string"
                raise _LoadError(msg)
            if not isinstance(file_size_bytes, int):
                msg = f"Database thumbnail value type '{type(file_size_bytes)}' is not an integer"
                raise _LoadError(msg)
            map_of_thumbnail_key_to_data_reference[url] = _ThumbnailDataReference(
                begin_offset = thumbnail_begin_offset,
                end_offset = thumbnail_begin_offset + file_size_bytes,
            )
            thumbnail_begin_offset += file_size_bytes

    return map_of_thumbnail_key_to_data_reference
