# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import shlex
import subprocess
import webbrowser
from pathlib import Path
from typing import TYPE_CHECKING
from milodb.common.config.i_launch_config import ILaunchConfig, LaunchOption
from milodb.common.output.print.i_printer import IPrinter
if TYPE_CHECKING:
    from collections.abc import Sequence

def launch(launch_config: ILaunchConfig, filepath: Path | None, url: str | None, normal_printer: IPrinter, warning_printer: IPrinter, error_printer: IPrinter, debug_printer: IPrinter) -> None:
    match launch_config.launch_option:
        case LaunchOption.DEFAULT:
            _launch_default(filepath, url, normal_printer, error_printer)
        case LaunchOption.CUSTOM:
            _launch_custom(launch_config, filepath, url, normal_printer, warning_printer, error_printer, debug_printer)
        case LaunchOption.NONE:
            pass

def _launch_default(filepath: Path | None, url: str | None, normal_printer: IPrinter, error_printer: IPrinter) -> None:
    target: str | None = None
    if filepath:
        normal_printer.writeln(f"Opening '{filepath}' in default web browser")
        target = str(filepath)
    elif url:
        normal_printer.writeln(f"Opening '{url}' in default web browser")
        target = url

    if target:
        try:
            was_successful: bool = webbrowser.open(target)
        except webbrowser.Error as ex:
            error_printer.writeln(f'Failed to launch default web browser: {ex}')
        else:
            if not was_successful:
                error_printer.writeln('Failed to identify default web browser')

def _launch_custom(launch_config: ILaunchConfig, filepath: Path | None, url: str | None, normal_printer: IPrinter, warning_printer: IPrinter, error_printer: IPrinter, debug_printer: IPrinter) -> None:
    expanded_command: str = launch_config.custom_launch_command
    if filepath:
        expanded_command = expanded_command.replace('$p', str(filepath))
    if url:
        expanded_command = expanded_command.replace('$u', url)
    normal_printer.writeln(f"Launching: {launch_config.custom_launch_command}")
    normal_printer.writeln(f"Expanded: {expanded_command}")
    debug_printer.writeln()

    try:
        list_of_arguments: Sequence[str] = shlex.split(expanded_command)
    except ValueError as ex:
        error_printer.writeln(f'Failed to parse custom launch command: {ex}')
    else:
        exit_code: int
        if launch_config.custom_launch_as_shell:
            debug_printer.writeln('Running as a shell command')
            exit_code = subprocess.run(expanded_command, check=False, shell=True).returncode # noqa: S602 `subprocess` call with `shell=True` identified, security issue
        else:
            debug_printer.writeln('Running as an executable command')
            arg_index: int
            arg: str
            for arg_index, arg in enumerate(list_of_arguments):
                debug_printer.writeln(f"Arg {arg_index}: '{arg}'")
            exit_code = subprocess.run(list_of_arguments, check=False).returncode # noqa: S603 `subprocess` call: check for execution of untrusted input
        exit_code_message: str = f'Execution returned with exit code {exit_code}'
        if exit_code:
            warning_printer.writeln(exit_code_message)
        else:
            debug_printer.writeln(exit_code_message)
