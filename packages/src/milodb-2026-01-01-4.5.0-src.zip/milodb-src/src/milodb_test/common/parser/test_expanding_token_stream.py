# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from abc import ABC, abstractmethod
from collections.abc import Iterable, Sequence
from dataclasses import dataclass
from typing import Generic, TypeGuard, TypeVar, override
from unittest.mock import Mock
from milodb.common.parser.candidate_text import CandidateText
from milodb.common.parser.expanding_token_stream import ExpandingTokenStream
from milodb.common.parser.token import StartEnd, Token
from milodb.common.parser.token_stream import TokenStream, TokenStreamError
from milodb.common.variables.i_user_variables import IUserVariables
from milodb_test.common.test.strict_mock import InterfaceMock
from milodb_test.common.test.test_case_ex import TestCaseEx

_MAX_READ_TOKEN_COUNT: int = 100

@dataclass
class SimpleToken:
    _text: str
    _start_index: int
    _end_index: int | None = None

    @property
    def text(self) -> str:
        return self._text

    @property
    def inner_indices(self) -> StartEnd:
        if self._end_index is not None:
            return StartEnd(self._start_index, self._end_index)
        return StartEnd(self._start_index, self._start_index + len(self._text))

    @property
    def outer_indices(self) -> StartEnd:
        return self.inner_indices

    @property
    def is_delimiter(self) -> bool:
        return False

@dataclass
class QuotedToken:
    _text: str
    _start_index: int
    _end_index: int | None = None

    @property
    def text(self) -> str:
        return self._text

    @property
    def inner_indices(self) -> StartEnd:
        if self._end_index is not None:
            return StartEnd(self._start_index + 1, self._end_index - 1)
        return StartEnd(self._start_index + 1, self._start_index + 1 + len(self._text))

    @property
    def outer_indices(self) -> StartEnd:
        if self._end_index is not None:
            return StartEnd(self._start_index, self._end_index)
        return StartEnd(self._start_index, self._start_index + len(self._text) + 2)

    @property
    def is_delimiter(self) -> bool:
        return False

@dataclass
class DelimiterToken:
    _text: str
    _start_index: int

    @property
    def text(self) -> str:
        return self._text

    @property
    def inner_indices(self) -> StartEnd:
        return StartEnd(self._start_index, self._start_index + len(self._text))

    @property
    def outer_indices(self) -> StartEnd:
        return self.inner_indices

    @property
    def is_delimiter(self) -> bool:
        return True

T = TypeVar('T', TokenStream, ExpandingTokenStream)

class Support:
    class Framework(ABC, TestCaseEx, Generic[T]):
        @override
        def setUp(self) -> None:
            self.token_stream: T | None = None
            self.discard_delimiters: str | None = None
            self.keep_delimiters: str | None = None
            self._list_of_tokens: list[Token] = []
            self._exception: TokenStreamError | None = None

        @abstractmethod
        def construct(self, text: str, discard_delimiters: str | None = None, keep_delimiters: str | None = None, stop_before_character_index: int | None = None) -> T:
            pass

        def init(self, text: str) -> None:
            self.assertIsNone(self.token_stream)
            stop_before_character_index: int = text.find('^')
            if stop_before_character_index != -1:
                text = text[:stop_before_character_index] + text[stop_before_character_index+1:]
                self.token_stream = self.construct(text, self.discard_delimiters, self.keep_delimiters, stop_before_character_index)
            else:
                self.token_stream = self.construct(text, self.discard_delimiters, self.keep_delimiters, None)

        def init_and_read_tokens(self, text: str, stop_after: int | None = None) -> None:
            self.init(text)
            self.read_tokens(stop_after)

        def read_tokens(self, stop_after: int | None = None) -> None:
            if self._assert_has_token_stream(self.token_stream):
                for _ in range(stop_after or _MAX_READ_TOKEN_COUNT):
                    try:
                        token: Token | None = self.token_stream.next()
                    except TokenStreamError as ex:
                        self._exception = ex
                        return
                    if token:
                        self._list_of_tokens.append(token)
                    else:
                        break

        def assert_successful(self) -> None:
            self.assertIsNone(
                self._exception,
                "Tokenisation should have been successful but wasn't")

        def assert_unsuccessful(self, error_msg: str, character_index: int, list_of_expected_text: Sequence[str] | None = None) -> None:
            if self._exception is not None:
                self.assertEqual(
                    error_msg, self._exception.cause_of_fault_text,
                    f"Expected error message of '{error_msg}' but got '{self._exception.cause_of_fault_text}'")
                self.assertEqual(
                    character_index, self._exception.fault_token.outer_indices.start,
                    f'Expected character index of failed tokenisation at {character_index} but was {self._exception.fault_token.outer_indices.start}')
                self._assert_candidate_text_list_equal(list_of_expected_text or [], self._exception.list_of_candidate_text)
            else:
                self.fail("Tokenisation should have failed but was successful")

        def assert_token_count(self, expected_count: int) -> None:
            actual_count: int = len(self._list_of_tokens)
            self.assertEqual(
                expected_count, actual_count,
                f'Expected {expected_count} tokens but there are {actual_count} tokens')

        def assert_tokens(self, list_of_expected_tokens: Sequence[SimpleToken | QuotedToken | DelimiterToken]) -> None:
            self.assert_token_count(len(list_of_expected_tokens))
            token_number: int
            token: Token
            for token_number, token in enumerate(self._list_of_tokens):
                self.assert_token(token_number, token, list_of_expected_tokens[token_number])

        def assert_token(self, expected_token_number: int, actual_token: Token, expected_token: SimpleToken | QuotedToken | DelimiterToken) -> None:
            self.assertEqual(
                expected_token_number, actual_token.token_number,
                f'Token #{expected_token_number}: Expected token number of {expected_token_number} but was {actual_token.token_number}')
            self.assertEqual(
                expected_token.text, actual_token.text,
                f"Token #{expected_token_number}: Expected token text of '{expected_token.text}' but was '{actual_token.text}'")
            self.assertEqual(
                expected_token.outer_indices, actual_token.outer_indices,
                f'Token #{expected_token_number}: Expected outer character indices of {expected_token.outer_indices} but was {actual_token.outer_indices}')
            self.assertEqual(
                expected_token.inner_indices, actual_token.inner_indices,
                f'Token #{expected_token_number}: Expected inner character indices of {expected_token.inner_indices} but was {actual_token.inner_indices}')
            self.assertEqual(
                expected_token.is_delimiter, actual_token.is_delimiter,
                f'Token #{expected_token_number}: Expected is_delimiter of {expected_token.is_delimiter} but was {actual_token.is_delimiter}')

        def assert_remaining_text(self, expected_text: str) -> None:
            if self._assert_has_token_stream(self.token_stream):
                text: str = self.token_stream.get_remaining_raw_text()
                self.assertEqual(
                    expected_text, text,
                    f"Expected remaining text of '{expected_text}' but was '{text}'")

        def assert_stopped_on_token(self, expected_token_number: int, expected_token: SimpleToken | QuotedToken) -> None:
            if self._assert_has_token_stream(self.token_stream):
                actual_token: Token | None = self.token_stream.get_stopped_on_token()
                if self.assert_is_not_none(actual_token, f"Stopped on token should be {expected_token} but was None"):
                    self.assert_token(expected_token_number, actual_token, expected_token) # pyright: ignore [reportArgumentType]

        def assert_stopped_on_token_is_none(self) -> None:
            if self._assert_has_token_stream(self.token_stream):
                actual_token: Token | None = self.token_stream.get_stopped_on_token()
                self.assertIsNone(actual_token, f"Stopped on token should be None but was {actual_token}")

        def _assert_has_token_stream(self, token_stream: T | None) -> TypeGuard[T]:
            return self.assert_is_not_none(token_stream, "TokenStream has not been initialised")

        def _assert_candidate_text_list_equal(self, expected_list_of_candidate_text: Iterable[str | CandidateText], actual_list_of_candidate_text: Iterable[CandidateText]) -> None:
            expected_list_of_text: list[str] = []
            candidate_text: str | CandidateText
            for candidate_text in expected_list_of_candidate_text:
                if isinstance(candidate_text, CandidateText):
                    expected_list_of_text.append(candidate_text.text + candidate_text.following_delimiter)
                else:
                    expected_list_of_text.append(candidate_text + ' ')

            actual_list_of_text: Sequence[str] = [candidate_text.text + candidate_text.following_delimiter for candidate_text in actual_list_of_candidate_text]

            self.assertSequenceEqual(sorted(expected_list_of_text), sorted(actual_list_of_text))

    class DefaultTests(Framework[T], ABC, Generic[T]):
        def test_empty_input_returns_successful_with_empty_token_list(self) -> None:
            self.init_and_read_tokens('')
            self.assert_successful()
            self.assert_tokens([])

        def test_one_word_returns_one_token(self) -> None:
            self.init_and_read_tokens("hello_world")
            self.assert_successful()
            self.assert_tokens([
                SimpleToken("hello_world", 0),
            ])

        def test_one_word_with_pre_padding_returns_one_token(self) -> None:
            self.init_and_read_tokens(" hello_world")
            self.assert_successful()
            self.assert_tokens([
                SimpleToken("hello_world", 1),
            ])

        def test_one_word_with_post_padding_returns_one_token(self) -> None:
            self.init_and_read_tokens("hello_world ")
            self.assert_successful()
            self.assert_tokens([
                SimpleToken("hello_world", 0),
            ])

        def test_one_word_with_pre_and_post_padding_returns_one_token(self) -> None:
            self.init_and_read_tokens("  hello_world  ")
            self.assert_successful()
            self.assert_tokens([
                SimpleToken("hello_world", 2),
            ])

        def test_one_double_quoted_string_returns_one_token(self) -> None:
            self.init_and_read_tokens('"hello world"')
            self.assert_successful()
            self.assert_tokens([
                QuotedToken("hello world", 0),
            ])

        def test_one_double_quoted_string_with_pre_padding_returns_one_token(self) -> None:
            self.init_and_read_tokens(' "hello world"')
            self.assert_successful()
            self.assert_tokens([
                QuotedToken("hello world", 1),
            ])

        def test_one_double_quoted_string_with_post_padding_returns_one_token(self) -> None:
            self.init_and_read_tokens('"hello world" ')
            self.assert_successful()
            self.assert_tokens([
                QuotedToken("hello world", 0),
            ])

        def test_one_double_quoted_string_with_pre_and_post_padding_returns_one_token(self) -> None:
            self.init_and_read_tokens('  "hello world"  ')
            self.assert_successful()
            self.assert_tokens([
                QuotedToken("hello world", 2),
            ])

        def test_one_double_quoted_string_with_single_quote_returns_one_token(self) -> None:
            self.init_and_read_tokens('"isn\'t this nice"')
            self.assert_successful()
            self.assert_tokens([
                QuotedToken("isn't this nice", 0),
            ])

        def test_one_single_quoted_string_returns_one_token(self) -> None:
            self.init_and_read_tokens("'hello world'")
            self.assert_successful()
            self.assert_tokens([
                QuotedToken("hello world", 0),
            ])

        def test_one_single_quoted_string_with_pre_padding_returns_one_token(self) -> None:
            self.init_and_read_tokens(" 'hello world'")
            self.assert_successful()
            self.assert_tokens([
                QuotedToken("hello world", 1),
            ])

        def test_one_single_quoted_string_with_post_padding_returns_one_token(self) -> None:
            self.init_and_read_tokens("'hello world' ")
            self.assert_successful()
            self.assert_tokens([
                QuotedToken("hello world", 0),
            ])

        def test_one_single_quoted_string_with_pre_and_post_padding_returns_one_token(self) -> None:
            self.init_and_read_tokens("  'hello world'  ")
            self.assert_successful()
            self.assert_tokens([
                QuotedToken("hello world", 2),
            ])

        def test_one_single_quoted_string_with_double_quote_returns_one_token(self) -> None:
            self.init_and_read_tokens("'isn\"t this nice'")
            self.assert_successful()
            self.assert_tokens([
                QuotedToken('isn"t this nice', 0),
            ])

        def test_one_single_quoted_string_with_escaped_quote_returns_one_token(self) -> None:
            self.init_and_read_tokens("'isn\\'t this nice'")
            self.assert_successful()
            self.assert_tokens([
                QuotedToken("isn't this nice", 0, 18),
            ])

        def test_one_double_quoted_string_with_escaped_quote_returns_one_token(self) -> None:
            self.init_and_read_tokens('"isn\\"t this nice"')
            self.assert_successful()
            self.assert_tokens([
                QuotedToken('isn"t this nice', 0, 18),
            ])

        def test_two_words_returns_two_tokens(self) -> None:
            self.init_and_read_tokens("hello world")
            self.assert_successful()
            self.assert_tokens([
                SimpleToken('hello', 0),
                SimpleToken('world', 6),
            ])

        def test_two_words_with_padding_returns_two_tokens(self) -> None:
            self.init_and_read_tokens("   hello  world ")
            self.assert_successful()
            self.assert_tokens([
                SimpleToken('hello', 3),
                SimpleToken('world', 10),
            ])

        def test_escaped_non_quote_character_at_start_returns_character_as_is(self) -> None:
            self.init_and_read_tokens(r'\Whello')
            self.assert_successful()
            self.assert_tokens([
                SimpleToken(r'\Whello', 0),
            ])

        def test_escaped_non_quote_character_in_middle_returns_character_as_is(self) -> None:
            self.init_and_read_tokens(r'wor\Wld')
            self.assert_successful()
            self.assert_tokens([
                SimpleToken(r'wor\Wld', 0),
            ])

        def test_escaped_non_quote_character_at_end_returns_character_as_is(self) -> None:
            self.init_and_read_tokens(r'world\W')
            self.assert_successful()
            self.assert_tokens([
                SimpleToken(r'world\W', 0),
            ])

        def test_escaped_quote_character_at_start_doesnt_start_quote(self) -> None:
            self.init_and_read_tokens(r'\"hello')
            self.assert_successful()
            self.assert_tokens([
                SimpleToken('"hello', 0, 7),
            ])

        def test_escaped_quote_character_in_middle_doesnt_end_quote(self) -> None:
            self.init_and_read_tokens(r'wor\"ld')
            self.assert_successful()
            self.assert_tokens([
                SimpleToken('wor"ld', 0, 7),
            ])

        def test_escaped_quote_character_at_end_doesnt_end_quote(self) -> None:
            self.init_and_read_tokens(r'hello\"')
            self.assert_successful()
            self.assert_tokens([
                SimpleToken('hello"', 0, 7),
            ])

    class DelimiterTests(Framework[T], ABC, Generic[T]):
        def test_discards_specific_delimiters(self) -> None:
            self.discard_delimiters = 'hz'
            self.keep_delimiters = ''
            self.init_and_read_tokens('  h zzhfoothhhto(psz)zhz')
            self.assert_successful()
            self.assert_tokens([
                SimpleToken('  ', 0),
                SimpleToken(' ', 3),
                SimpleToken('foot', 7),
                SimpleToken('to(ps', 14),
                SimpleToken(')', 20),
            ])

        def test_keeps_delimiters(self) -> None:
            self.discard_delimiters = ''
            self.keep_delimiters = 'hz'
            self.init_and_read_tokens('  h zzhfoothhhto(psz)zhz')
            self.assert_successful()
            self.assert_tokens([
                SimpleToken('  ', 0),
                DelimiterToken('h', 2),
                SimpleToken(' ', 3),
                DelimiterToken('z', 4),
                DelimiterToken('z', 5),
                DelimiterToken('h', 6),
                SimpleToken('foot', 7),
                DelimiterToken('h', 11),
                DelimiterToken('h', 12),
                DelimiterToken('h', 13),
                SimpleToken('to(ps', 14),
                DelimiterToken('z', 19),
                SimpleToken(')', 20),
                DelimiterToken('z', 21),
                DelimiterToken('h', 22),
                DelimiterToken('z', 23),
            ])

        def test_discards_and_keeps_delimiters(self) -> None:
            self.discard_delimiters = ' hz'
            self.keep_delimiters = '[}'
            self.init_and_read_tokens('  h zzh  hhhs]py[inghzz}zzz ')
            self.assert_successful()
            self.assert_tokens([
                SimpleToken('s]py', 12),
                DelimiterToken('[', 16),
                SimpleToken('ing', 17),
                DelimiterToken('}', 23),
            ])

        def test_one_open_bracket_returns_one_token(self) -> None:
            self.keep_delimiters = '('
            self.init_and_read_tokens("(")
            self.assert_successful()
            self.assert_tokens([
                DelimiterToken('(', 0),
            ])

        def test_one_open_bracket_with_pre_padding_returns_one_token(self) -> None:
            self.keep_delimiters = '('
            self.init_and_read_tokens(" (")
            self.assert_successful()
            self.assert_tokens([
                DelimiterToken('(', 1),
            ])

        def test_one_open_bracket_with_post_padding_returns_one_token(self) -> None:
            self.keep_delimiters = '('
            self.init_and_read_tokens("( ")
            self.assert_successful()
            self.assert_tokens([
                DelimiterToken('(', 0),
            ])

        def test_one_open_bracket_with_pre_and_post_padding_returns_one_token(self) -> None:
            self.keep_delimiters = '('
            self.init_and_read_tokens("  (  ")
            self.assert_successful()
            self.assert_tokens([
                DelimiterToken('(', 2),
            ])

        def test_two_open_brackets_returns_two_tokens(self) -> None:
            self.keep_delimiters = '('
            self.init_and_read_tokens("((")
            self.assert_successful()
            self.assert_tokens([
                DelimiterToken('(', 0),
                DelimiterToken('(', 1),
            ])

        def test_one_close_bracket_returns_one_token(self) -> None:
            self.keep_delimiters = ')'
            self.init_and_read_tokens(")")
            self.assert_successful()
            self.assert_tokens([
                DelimiterToken(')', 0),
            ])

        def test_one_close_bracket_with_pre_padding_returns_one_token(self) -> None:
            self.keep_delimiters = ')'
            self.init_and_read_tokens(" )")
            self.assert_successful()
            self.assert_tokens([
                DelimiterToken(')', 1),
            ])

        def test_one_close_bracket_with_post_padding_returns_one_token(self) -> None:
            self.keep_delimiters = ')'
            self.init_and_read_tokens(") ")
            self.assert_successful()
            self.assert_tokens([
                DelimiterToken(')', 0),
            ])

        def test_one_close_bracket_with_pre_and_post_padding_returns_one_token(self) -> None:
            self.keep_delimiters = ')'
            self.init_and_read_tokens("  )  ")
            self.assert_successful()
            self.assert_tokens([
                DelimiterToken(')', 2),
            ])

        def test_two_close_brackets_returns_two_tokens(self) -> None:
            self.keep_delimiters = ')'
            self.init_and_read_tokens("))")
            self.assert_successful()
            self.assert_tokens([
                DelimiterToken(')', 0),
                DelimiterToken(')', 1),
            ])

        def test_word_followed_by_open_bracket_returns_two_tokens(self) -> None:
            self.keep_delimiters = '('
            self.init_and_read_tokens("hello(")
            self.assert_successful()
            self.assert_tokens([
                SimpleToken('hello', 0),
                DelimiterToken('(', 5),
            ])

        def test_word_followed_by_open_bracket_and_word_returns_three_tokens(self) -> None:
            self.keep_delimiters = '('
            self.init_and_read_tokens("hello(world")
            self.assert_successful()
            self.assert_tokens([
                SimpleToken('hello', 0),
                DelimiterToken('(', 5),
                SimpleToken('world', 6),
            ])

        def test_word_followed_by_open_bracket_and_word_with_padding_returns_three_tokens(self) -> None:
            self.keep_delimiters = '('
            self.init_and_read_tokens("    hello   (  world ")
            self.assert_successful()
            self.assert_tokens([
                SimpleToken('hello', 4),
                DelimiterToken('(', 12),
                SimpleToken('world', 15),
            ])

        def test_word_followed_by_close_bracket_returns_two_tokens(self) -> None:
            self.keep_delimiters = ')'
            self.init_and_read_tokens("hello)")
            self.assert_successful()
            self.assert_tokens([
                SimpleToken('hello', 0),
                DelimiterToken(')', 5),
            ])

        def test_word_followed_by_close_bracket_and_word_returns_three_tokens(self) -> None:
            self.keep_delimiters = ')'
            self.init_and_read_tokens("hello)world")
            self.assert_successful()
            self.assert_tokens([
                SimpleToken('hello', 0),
                DelimiterToken(')', 5),
                SimpleToken('world', 6),
            ])

        def test_word_followed_by_close_bracket_and_word_with_padding_returns_three_tokens(self) -> None:
            self.keep_delimiters = ')'
            self.init_and_read_tokens("    hello   )  world ")
            self.assert_successful()
            self.assert_tokens([
                SimpleToken('hello', 4),
                DelimiterToken(')', 12),
                SimpleToken('world', 15),
            ])

    class StringTests(Framework[T], ABC, Generic[T]):
        def test_unterminated_double_quoted_string_returns_error(self) -> None:
            self.init_and_read_tokens('"unterminated')
            self.assert_unsuccessful("String not terminated at end of text", 0)
            self.assert_tokens([])

        def test_unterminated_double_quoted_string_containing_single_quote_returns_error(self) -> None:
            self.init_and_read_tokens('"isn\'t')
            self.assert_unsuccessful("String not terminated at end of text", 0)
            self.assert_tokens([])

        def test_unterminated_double_quoted_string_with_previous_tokens_returns_error(self) -> None:
            self.init_and_read_tokens('hello world "unterminated')
            self.assert_unsuccessful("String not terminated at end of text", 12)
            self.assert_tokens([
                SimpleToken('hello', 0),
                SimpleToken('world', 6),
            ])

        def test_unterminated_single_quoted_string_returns_error(self) -> None:
            self.init_and_read_tokens("'unterminated")
            self.assert_unsuccessful("String not terminated at end of text", 0)
            self.assert_tokens([])

        def test_unterminated_single_quoted_string_containing_double_quote_returns_error(self) -> None:
            self.init_and_read_tokens("'isn\"t")
            self.assert_unsuccessful("String not terminated at end of text", 0)
            self.assert_tokens([])

        def test_unterminated_single_quoted_string_with_previous_tokens_returns_error(self) -> None:
            self.init_and_read_tokens("hello world 'unterminated")
            self.assert_unsuccessful("String not terminated at end of text", 12)
            self.assert_tokens([
                SimpleToken('hello', 0),
                SimpleToken('world', 6),
            ])

        def test_word_following_double_quoted_text_returns_error(self) -> None:
            self.init_and_read_tokens('"hello"world')
            self.assert_unsuccessful("Expecting delimiter", 7)
            self.assert_token_count(1)
            self.assert_tokens([
                QuotedToken('hello', 0),
            ])

    class TrailingEscapeTests(Framework[T], ABC, Generic[T]):
        def test_trailing_escape_character_returns_error(self) -> None:
            self.init_and_read_tokens('hello\\')
            self.assert_unsuccessful("Trailing escape character at end of text", 6)
            self.assert_tokens([])

    class RemainingTextTests(Framework[T], ABC, Generic[T]):
        def test_get_remaining_after_no_tokens_on_empty_input(self) -> None:
            self.init('')
            self.assert_remaining_text('')

        def test_get_remaining_after_one_token_on_empty_input(self) -> None:
            self.init_and_read_tokens('', stop_after=1)
            self.assert_remaining_text('')

        def test_get_remaining_after_no_tokens_on_one_token_input(self) -> None:
            self.init('hello')
            self.assert_remaining_text('hello')

        def test_get_remaining_after_one_token_on_one_token_input(self) -> None:
            self.init_and_read_tokens('hello', stop_after=1)
            self.assert_remaining_text('')

        def test_get_remaining_after_no_tokens_on_two_token_input(self) -> None:
            self.init('hello world')
            self.assert_remaining_text('hello world')

        def test_get_remaining_after_one_token_on_two_token_input(self) -> None:
            self.init_and_read_tokens('hello world', stop_after=1)
            self.assert_remaining_text(' world')

        def test_get_remaining_after_two_tokens_on_two_token_input(self) -> None:
            self.init_and_read_tokens('hello world', stop_after=2)
            self.assert_remaining_text('')

        def test_get_remaining_after_one_token_on_two_spaced_token_input(self) -> None:
            self.init_and_read_tokens('hello   world ', stop_after=1)
            self.assert_remaining_text('   world ')

        def test_get_remaining_after_no_tokens_on_multi_token_input(self) -> None:
            self.init('mary  had   a    little     lamb')
            self.assert_remaining_text('mary  had   a    little     lamb')

        def test_get_remaining_after_one_token_on_multi_token_input(self) -> None:
            self.init_and_read_tokens('mary  had   a    little     lamb', stop_after=1)
            self.assert_remaining_text('  had   a    little     lamb')

        def test_get_remaining_after_no_tokens_on_bracketed_token_input(self) -> None:
            self.keep_delimiters = '('
            self.init('mary(had   a    little     lamb')
            self.assert_remaining_text('mary(had   a    little     lamb')

        def test_get_remaining_after_one_token_on_bracketed_token_input(self) -> None:
            self.keep_delimiters = '('
            self.init_and_read_tokens('mary(had   a    little     lamb', stop_after=1)
            self.assert_remaining_text('(had   a    little     lamb')

        def test_get_remaining_after_one_token_on_partly_quoted_token_input(self) -> None:
            self.init_and_read_tokens('mary had  "a    little     lamb', stop_after=1)
            self.assert_remaining_text(' had  "a    little     lamb')

    class StopAtCharTests(Framework[T], ABC, Generic[T]):
        def test_stop_on_empty_input(self) -> None:
            self.init_and_read_tokens('^')
            self.assert_tokens([])
            self.assert_stopped_on_token_is_none()

        def test_stop_at_start_of_token(self) -> None:
            self.init_and_read_tokens('^frog')
            self.assert_tokens([])
            self.assert_stopped_on_token(0, SimpleToken('frog', 0))

        def test_stop_in_middle_of_token(self) -> None:
            self.init_and_read_tokens('fr^og')
            self.assert_tokens([])
            self.assert_stopped_on_token(0, SimpleToken('frog', 0))

        def test_stop_at_end_of_token(self) -> None:
            self.init_and_read_tokens('frog^')
            self.assert_tokens([])
            self.assert_stopped_on_token(0, SimpleToken('frog', 0))

        def test_stop_after_end_of_token(self) -> None:
            self.init_and_read_tokens('frog ^')
            self.assert_tokens([
                SimpleToken('frog', 0)])
            self.assert_stopped_on_token_is_none()

        def test_stop_at_start_of_indented_token(self) -> None:
            self.init_and_read_tokens('  ^frog')
            self.assert_tokens([])
            self.assert_stopped_on_token(0, SimpleToken('frog', 2))

        def test_stop_in_middle_of_indented_token(self) -> None:
            self.init_and_read_tokens('  fr^og')
            self.assert_tokens([])
            self.assert_stopped_on_token(0, SimpleToken('frog', 2))

        def test_stop_at_end_of_indented_token(self) -> None:
            self.init_and_read_tokens('  frog^')
            self.assert_tokens([])
            self.assert_stopped_on_token(0, SimpleToken('frog', 2))

        def test_stop_after_end_of_indented_token(self) -> None:
            self.init_and_read_tokens('  frog ^')
            self.assert_tokens([
                SimpleToken('frog', 2)])
            self.assert_stopped_on_token_is_none()

        def test_stop_before_start_of_indented_token(self) -> None:
            self.init_and_read_tokens(' ^ frog')
            self.assert_tokens([])
            self.assert_stopped_on_token(0, SimpleToken('frog', 2))

        def test_stop_at_start_of_second_token(self) -> None:
            self.init_and_read_tokens('big ^frog')
            self.assert_tokens([
                SimpleToken('big', 0)])
            self.assert_stopped_on_token(1, SimpleToken('frog', 4))

        def test_stop_in_middle_of_second_token(self) -> None:
            self.init_and_read_tokens('big fr^og')
            self.assert_tokens([
                SimpleToken('big', 0)])
            self.assert_stopped_on_token(1, SimpleToken('frog', 4))

        def test_stop_at_end_of_second_token(self) -> None:
            self.init_and_read_tokens('big frog^')
            self.assert_tokens([
                SimpleToken('big', 0)])
            self.assert_stopped_on_token(1, SimpleToken('frog', 4))

        def test_stop_after_end_of_second_token(self) -> None:
            self.init_and_read_tokens('big frog ^')
            self.assert_tokens([
                SimpleToken('big', 0), SimpleToken('frog', 4)])
            self.assert_stopped_on_token_is_none()

        def test_stop_at_start_of_second_of_three_tokens(self) -> None:
            self.init_and_read_tokens('big ^frog man')
            self.assert_tokens([
                SimpleToken('big', 0)])
            self.assert_stopped_on_token(1, SimpleToken('frog', 4))

        def test_stop_in_middle_of_second_of_three_tokens(self) -> None:
            self.init_and_read_tokens('big fr^og man')
            self.assert_tokens([
                SimpleToken('big', 0)])
            self.assert_stopped_on_token(1, SimpleToken('frog', 4))

        def test_stop_at_end_of_second_of_three_tokens(self) -> None:
            self.init_and_read_tokens('big frog^ man')
            self.assert_tokens([
                SimpleToken('big', 0)])
            self.assert_stopped_on_token(1, SimpleToken('frog', 4))

        def test_stop_after_end_of_second_of_three_tokens(self) -> None:
            self.init_and_read_tokens('big frog ^ man')
            self.assert_tokens([
                SimpleToken('big', 0), SimpleToken('frog', 4)])
            self.assert_stopped_on_token(2, SimpleToken('man', 10))

        def test_stop_at_start_of_quoted_token(self) -> None:
            self.init_and_read_tokens('^"frog"')
            self.assert_tokens([])
            self.assert_stopped_on_token(0, QuotedToken('frog', 0))

        def test_stop_in_middle_of_quoted_token(self) -> None:
            self.init_and_read_tokens('"fr^og"')
            self.assert_tokens([])
            self.assert_stopped_on_token(0, QuotedToken('frog', 0))

        def test_stop_at_end_of_quoted_token(self) -> None:
            self.init_and_read_tokens('"frog"^')
            self.assert_tokens([])
            self.assert_stopped_on_token(0, QuotedToken('frog', 0))

        def test_stop_after_end_of_quoted_token(self) -> None:
            self.init_and_read_tokens('"frog" ^')
            self.assert_tokens([
                QuotedToken('frog', 0)])
            self.assert_stopped_on_token_is_none()

        def test_stop_at_start_of_indented_quoted_token(self) -> None:
            self.init_and_read_tokens('  ^"frog"')
            self.assert_tokens([])
            self.assert_stopped_on_token(0, QuotedToken('frog', 2))

        def test_stop_in_middle_of_indented_quoted_token(self) -> None:
            self.init_and_read_tokens('  "fr^og"')
            self.assert_tokens([])
            self.assert_stopped_on_token(0, QuotedToken('frog', 2))

        def test_stop_at_end_of_indented_quoted_token(self) -> None:
            self.init_and_read_tokens('  "frog"^')
            self.assert_tokens([])
            self.assert_stopped_on_token(0, QuotedToken('frog', 2))

        def test_stop_after_end_of_indented_quoted_token(self) -> None:
            self.init_and_read_tokens('  "frog" ^')
            self.assert_tokens([
                QuotedToken('frog', 2)])
            self.assert_stopped_on_token_is_none()

        def test_get_remaining_text_includes_stopped_on_token(self) -> None:
            self.init_and_read_tokens('these are    nor^mal  tokens')
            self.assert_remaining_text('    normal  tokens')

        def test_stop_on_keep_delimiter_includes_delimiter(self) -> None:
            self.keep_delimiters = ':'
            self.init_and_read_tokens('these is:^delimited')
            self.assert_tokens([
                SimpleToken('these', 0),
                SimpleToken('is', 6),
                DelimiterToken(':', 8),
                ])
            self.assert_stopped_on_token(3, SimpleToken('delimited', 9))

    # pylint: disable=too-many-ancestors
    class CommonTests(DefaultTests[T], DelimiterTests[T], StringTests[T], TrailingEscapeTests[T], RemainingTextTests[T], StopAtCharTests[T], ABC, Generic[T]):
        pass

# pylint: disable=too-many-ancestors
class TestTokenStream(Support.CommonTests[TokenStream]):
    @override
    def construct(self, text: str, discard_delimiters: str | None = None, keep_delimiters: str | None = None, stop_before_character_index: int | None = None) -> TokenStream:
        return TokenStream(text, discard_delimiters, keep_delimiters, stop_before_character_index)

# pylint: disable=too-many-ancestors
class TestExpandingTokenStream(Support.CommonTests[ExpandingTokenStream]):
    @override
    def setUp(self) -> None:
        super().setUp()
        self._dictionary_of_variables: dict[str, str] = {}

        self._mock_user_variables = InterfaceMock(IUserVariables,
            try_retrieve = Mock(side_effect=self._dictionary_of_variables.get),
            get_list_of_names = Mock(side_effect=lambda: list(self._dictionary_of_variables)),
        )

    @override
    def construct(self, text: str, discard_delimiters: str | None = None, keep_delimiters: str | None = None, stop_before_character_index: int | None = None) -> ExpandingTokenStream:
        return ExpandingTokenStream(text, self._mock_user_variables, discard_delimiters, keep_delimiters, stop_before_character_index)

    def add_variable(self, name: str, value: str) -> None:
        self._dictionary_of_variables[name] = value

    def disable_expansion(self) -> None:
        if self._assert_has_token_stream(self.token_stream):
            self.token_stream.disable_expansion()

    def assert_expanded_text(self, expected_text: str) -> None:
        if self.token_stream:
            self.assertEqual(expected_text, self.token_stream.get_expanded_raw_text())

    def test_single_variable_alone(self) -> None:
        self.add_variable('cheese', 'mango')
        self.init_and_read_tokens('$cheese')
        self.assert_successful()
        self.assert_tokens([
            SimpleToken('mango', 0),
        ])

    def test_single_variable_with_space(self) -> None:
        self.add_variable('apple', 'banana')
        self.init_and_read_tokens('   $apple   ')
        self.assert_successful()
        self.assert_tokens([
            SimpleToken('banana', 3),
        ])

    def test_single_variable_at_the_start_of_text(self) -> None:
        self.add_variable('pear', 'tomato')
        self.init_and_read_tokens('$pear soup')
        self.assert_successful()
        self.assert_tokens([
            SimpleToken('tomato', 0),
            SimpleToken('soup', 7),
        ])

    def test_single_variable_at_the_end_of_text(self) -> None:
        self.add_variable('d', 'fondant')
        self.init_and_read_tokens('chocolate $d')
        self.assert_successful()
        self.assert_tokens([
            SimpleToken('chocolate', 0),
            SimpleToken('fondant', 10),
        ])

    def test_single_variable_in_the_middle_of_text(self) -> None:
        self.add_variable('myvar', 'caffeine')
        self.init_and_read_tokens('I need $myvar please')
        self.assert_successful()
        self.assert_tokens([
            SimpleToken('I', 0),
            SimpleToken('need', 2),
            SimpleToken('caffeine', 7),
            SimpleToken('please', 16),
        ])

    def test_double_quoted_variable_is_expanded(self) -> None:
        self.add_variable('myvar', 'coffee')
        self.init_and_read_tokens('I need "$myvar" please')
        self.assert_successful()
        self.assert_tokens([
            SimpleToken('I', 0),
            SimpleToken('need', 2),
            SimpleToken('coffee', 7),
            SimpleToken('please', 14),
        ])

    def test_single_quoted_variable_is_expanded(self) -> None:
        self.add_variable('myvar', 'coffee')
        self.init_and_read_tokens("I need '$myvar' please")
        self.assert_successful()
        self.assert_tokens([
            SimpleToken('I', 0),
            SimpleToken('need', 2),
            SimpleToken('coffee', 7),
            SimpleToken('please', 14),
        ])

    def test_escaped_variable_is_not_expanded(self) -> None:
        self.add_variable('myvar', 'coffee')
        self.init_and_read_tokens("I need $$myvar please")
        self.assert_successful()
        self.assert_tokens([
            SimpleToken('I', 0),
            SimpleToken('need', 2),
            SimpleToken('$$myvar', 7),
            SimpleToken('please', 15),
        ])

    def test_variable_at_start_with_spaces_is_expanded(self) -> None:
        self.add_variable('listOfFruit', 'apple, orange and pear')
        self.init_and_read_tokens('$listOfFruit fruits')
        self.assert_successful()
        self.assert_tokens([
            SimpleToken('apple,', 0),
            SimpleToken('orange', 7),
            SimpleToken('and', 14),
            SimpleToken('pear', 18),
            SimpleToken('fruits', 23),
        ])

    def test_variable_at_end_with_spaces_is_expanded(self) -> None:
        self.add_variable('listOfFruit', 'apple, orange and pear')
        self.init_and_read_tokens('fruits: $listOfFruit')
        self.assert_successful()
        self.assert_tokens([
            SimpleToken('fruits:', 0),
            SimpleToken('apple,', 8),
            SimpleToken('orange', 15),
            SimpleToken('and', 22),
            SimpleToken('pear', 26),
        ])

    def test_variable_in_middle_with_spaces_is_expanded(self) -> None:
        self.add_variable('listOfFruit', 'apple, orange and pear')
        self.init_and_read_tokens('fruits: $listOfFruit with cheese')
        self.assert_successful()
        self.assert_tokens([
            SimpleToken('fruits:', 0),
            SimpleToken('apple,', 8),
            SimpleToken('orange', 15),
            SimpleToken('and', 22),
            SimpleToken('pear', 26),
            SimpleToken('with', 31),
            SimpleToken('cheese', 36),
        ])

    def test_variable_before_open_bracket_is_expanded(self) -> None:
        self.keep_delimiters = '('
        self.add_variable('oldFruit', 'mango')
        self.init_and_read_tokens('$oldFruit(rotting')
        self.assert_successful()
        self.assert_tokens([
            SimpleToken('mango', 0),
            DelimiterToken('(', 5),
            SimpleToken('rotting', 6),
        ])

    def test_variable_before_close_bracket_is_expanded(self) -> None:
        self.keep_delimiters = ')'
        self.add_variable('oldFruit', 'mango')
        self.init_and_read_tokens('$oldFruit)rotting')
        self.assert_successful()
        self.assert_tokens([
            SimpleToken('mango', 0),
            DelimiterToken(')', 5),
            SimpleToken('rotting', 6),
        ])

    def test_variable_expansion_handles_surrounding_spaces(self) -> None:
        self.add_variable('car', '  four  wheeler  ')
        self.init_and_read_tokens('I need a   $car  now')
        self.assert_successful()
        self.assert_tokens([
            SimpleToken('I', 0),
            SimpleToken('need', 2),
            SimpleToken('a', 7),
            SimpleToken('four', 13),
            SimpleToken('wheeler', 19),
            SimpleToken('now', 30),
        ])

    def test_variable_with_invalid_name_errors(self) -> None:
        self.add_variable('car', 'formula 1 car')
        self.init_and_read_tokens('I need a $c=ar  ')
        self.assert_unsuccessful(r"Invalid variable reference '$c=ar' does not match pattern '\$[\w\-\+]+'", 9, ['$car'])

    def test_multiple_identical_variables_are_expanded(self) -> None:
        self.add_variable('animal', 'dog')
        self.init_and_read_tokens('the $animal sat on the other $animal')
        self.assert_successful()
        self.assert_tokens([
            SimpleToken('the', 0),
            SimpleToken('dog', 4),
            SimpleToken('sat', 8),
            SimpleToken('on', 12),
            SimpleToken('the', 15),
            SimpleToken('other', 19),
            SimpleToken('dog', 25),
        ])

    def test_multiple_different_variables_are_expanded(self) -> None:
        self.add_variable('colour', 'ginger')
        self.add_variable('animal', 'cat')
        self.add_variable('action', 'sat')
        self.init_and_read_tokens('the $colour $animal $action on the mat')
        self.assert_successful()
        self.assert_tokens([
            SimpleToken('the', 0),
            SimpleToken('ginger', 4),
            SimpleToken('cat', 11),
            SimpleToken('sat', 15),
            SimpleToken('on', 19),
            SimpleToken('the', 22),
            SimpleToken('mat', 26),
        ])

    def test_expansion_is_recursive_once(self) -> None:
        self.add_variable('colouredAnimal', 'ginger $animal')
        self.add_variable('animal', 'cat')
        self.init_and_read_tokens('$colouredAnimal')
        self.assert_successful()
        self.assert_tokens([
            SimpleToken('ginger', 0),
            SimpleToken('cat', 7),
        ])

    def test_expansion_is_recursive_twice(self) -> None:
        self.add_variable('shape', 'rotund')
        self.add_variable('colour', 'grey')
        self.add_variable('animal', '$shape cat')
        self.add_variable('colouredAnimal', '$colour $animal')
        self.init_and_read_tokens('$colouredAnimal')
        self.assert_successful()
        self.assert_tokens([
            SimpleToken('grey', 0),
            SimpleToken('rotund', 5),
            SimpleToken('cat', 12),
        ])

    def test_unknown_variable_causes_an_error(self) -> None:
        self.init_and_read_tokens('my $mind hurts')
        self.assert_unsuccessful("Unknown variable reference '$mind'", 3, [])

    def test_unknown_second_variable_causes_an_error(self) -> None:
        self.add_variable('mind', 'mental capability')
        self.init_and_read_tokens('my $mind is $diminishing')
        self.assert_unsuccessful("Unknown variable reference '$diminishing'", 24, ['$mind'])

    def test_unknown_variable_lists_all_variables(self) -> None:
        self.add_variable('chair', 'upright')
        self.add_variable('book', 'gone with the wind')
        self.add_variable('music', 'jazz')
        self.init_and_read_tokens('the $tree')
        self.assert_unsuccessful("Unknown variable reference '$tree'", 4, ['$chair', '$book', '$music'])

    def test_flat_reentrant_expansion_causes_an_error(self) -> None:
        self.add_variable('shape', '$shape')
        self.init_and_read_tokens('$shape')
        self.assert_unsuccessful("Recursive variable reference detected: '$shape' -> '$shape'", 0)

    def test_deep_reentrant_expansion_causes_an_error(self) -> None:
        self.add_variable('onion', 'a $edible')
        self.add_variable('veg', '$onion')
        self.add_variable('edible', '$veg')
        self.init_and_read_tokens('$edible')
        self.assert_unsuccessful("Recursive variable reference detected: '$edible' -> '$veg' -> '$onion' -> '$edible'", 0)

    def test_disable_expansion_prevents_expansion_at_start(self) -> None:
        self.add_variable('tomato', 'potato')
        self.init('I like $tomato soup')
        self.disable_expansion()
        self.read_tokens()
        self.assert_successful()
        self.assert_tokens([
            SimpleToken('I', 0),
            SimpleToken('like', 2),
            SimpleToken('$tomato', 7),
            SimpleToken('soup', 15),
        ])

    def test_disable_expansion_prevents_expansion_before_variable(self) -> None:
        self.add_variable('tomato', 'potato')
        self.init('I eat $tomato pieces')
        self.read_tokens(2)
        self.disable_expansion()
        self.read_tokens()
        self.assert_successful()
        self.assert_tokens([
            SimpleToken('I', 0),
            SimpleToken('eat', 2),
            SimpleToken('$tomato', 6),
            SimpleToken('pieces', 14),
        ])

    def test_disable_expansion_allows_expansion_after_variable(self) -> None:
        self.add_variable('tomato', 'potato')
        self.add_variable('action', 'chew')
        self.init('I $action $tomato slices')
        self.read_tokens(2)
        self.disable_expansion()
        self.read_tokens()
        self.assert_successful()
        self.assert_tokens([
            SimpleToken('I', 0),
            SimpleToken('chew', 2),
            SimpleToken('$tomato', 7),
            SimpleToken('slices', 15),
        ])

    def test_get_remaining_after_no_tokens_and_before_variable_expansion_on_first_token(self) -> None:
        self.init('$people $action pizza')
        self.assert_successful()
        self.assert_remaining_text('$people $action pizza')

    def test_get_remaining_after_no_tokens_and_before_variable_expansion_on_second_token(self) -> None:
        self.init('We $action pizza')
        self.assert_successful()
        self.assert_remaining_text('We $action pizza')

    def test_get_remaining_after_one_token_and_before_variable_expansion_on_first_token(self) -> None:
        self.add_variable('people', 'They')
        self.init_and_read_tokens('$people $action pizza', 1)
        self.assert_successful()
        self.assert_remaining_text(' $action pizza')

    def test_get_remaining_after_one_token_and_before_variable_expansion_on_second_token(self) -> None:
        self.init_and_read_tokens('We $action pizza', 1)
        self.assert_successful()
        self.assert_remaining_text(' $action pizza')

    def test_get_remaining_after_one_token_and_one_token_variable(self) -> None:
        self.add_variable('action', 'chew')
        self.init_and_read_tokens('I $action $tomato slices', 2)
        self.assert_successful()
        self.assert_remaining_text(' $tomato slices')

    def test_get_remaining_after_two_tokens_within_multi_token_variable(self) -> None:
        self.add_variable('tomato', 'potato')
        self.add_variable('action', 'bite and chew')
        self.init_and_read_tokens('I $action $tomato slices', 2)
        self.assert_successful()
        self.assert_remaining_text(' and chew $tomato slices')

    def test_get_remaining_with_recursive_variables(self) -> None:
        self.add_variable('animal', '$colour $size cat')
        self.add_variable('colour', 'grey')
        self.init_and_read_tokens('The $animal slept', 2)
        self.assert_successful()
        self.assert_remaining_text(' $size cat slept')

    def test_get_remaining_preserves_spaces(self) -> None:
        self.add_variable('animal', '     $colour   $size  cat')
        self.add_variable('colour', ' grey  ')
        self.init_and_read_tokens('  The    $animal     slept        ', 2)
        self.assert_successful()
        self.assert_remaining_text('     $size  cat     slept        ')

    def test_stop_at_start_of_variable_does_not_expand_unknown_variable(self) -> None:
        self.init_and_read_tokens('^$drink')
        self.assert_successful()
        self.assert_tokens([])
        self.assert_stopped_on_token(0, SimpleToken('$drink', 0))

    def test_stop_before_start_of_variable_does_not_expand_unknown_variable(self) -> None:
        self.init_and_read_tokens('^ $drink')
        self.assert_successful()
        self.assert_tokens([])
        self.assert_stopped_on_token(0, SimpleToken('$drink', 1))

    def test_stop_in_middle_of_variable_does_not_expand_unknown_variable(self) -> None:
        self.init_and_read_tokens('$dr^ink')
        self.assert_successful()
        self.assert_tokens([])
        self.assert_stopped_on_token(0, SimpleToken('$drink', 0))

    def test_stop_at_end_of_variable_does_not_expand_unknown_variable(self) -> None:
        self.init_and_read_tokens('$drink^')
        self.assert_successful()
        self.assert_tokens([])
        self.assert_stopped_on_token(0, SimpleToken('$drink', 0))

    def test_stop_after_end_of_variable_does_not_expand_unknown_variable(self) -> None:
        self.init_and_read_tokens('$drink ^')
        self.assert_unsuccessful("Unknown variable reference '$drink'", 0, [])

    def test_stop_at_start_of_variable_does_not_expand_known_variable(self) -> None:
        self.add_variable('drink', 'champagne')
        self.init_and_read_tokens('^$drink')
        self.assert_successful()
        self.assert_tokens([])
        self.assert_stopped_on_token(0, SimpleToken('$drink', 0))

    def test_stop_before_start_of_variable_does_not_expand_known_variable(self) -> None:
        self.add_variable('drink', 'champagne')
        self.init_and_read_tokens('^ $drink')
        self.assert_successful()
        self.assert_tokens([])
        self.assert_stopped_on_token(0, SimpleToken('$drink', 1))

    def test_stop_in_middle_of_variable_does_not_expand_known_variable(self) -> None:
        self.add_variable('drink', 'champagne')
        self.init_and_read_tokens('$dr^ink')
        self.assert_successful()
        self.assert_tokens([])
        self.assert_stopped_on_token(0, SimpleToken('$drink', 0))

    def test_stop_at_end_of_variable_does_not_expand_known_variable(self) -> None:
        self.add_variable('drink', 'champagne')
        self.init_and_read_tokens('$drink^')
        self.assert_successful()
        self.assert_tokens([])
        self.assert_stopped_on_token(0, SimpleToken('$drink', 0))

    def test_stop_after_end_of_variable_does_expand_known_variable(self) -> None:
        self.add_variable('drink', 'champagne')
        self.init_and_read_tokens('$drink ^')
        self.assert_tokens([
            SimpleToken('champagne', 0)])
        self.assert_stopped_on_token_is_none()

    def test_stop_after_end_of_variable_and_before_next_token_has_stopped_token(self) -> None:
        self.add_variable('drink', 'champagne')
        self.init_and_read_tokens('$drink ^with')
        self.assert_tokens([
            SimpleToken('champagne', 0)])
        self.assert_stopped_on_token(1, SimpleToken('with', 10))

    def test_stop_after_end_of_variable_and_within_next_token_has_stopped_token(self) -> None:
        self.add_variable('drink', 'champagne')
        self.init_and_read_tokens('$drink w^ith')
        self.assert_tokens([
            SimpleToken('champagne', 0)])
        self.assert_stopped_on_token(1, SimpleToken('with', 10))

    def test_stop_when_variable_appears_in_middle_of_input_has_stopped_token(self) -> None:
        self.add_variable('drink', 'champagne')
        self.init_and_read_tokens('Some $drink w^')
        self.assert_tokens([
            SimpleToken('Some', 0),
            SimpleToken('champagne', 5)])
        self.assert_stopped_on_token(2, SimpleToken('w', 15))

    def test_stop_when_variable_is_surrounded_with_space_has_stopped_token(self) -> None:
        self.add_variable('drink', 'champagne')
        self.init_and_read_tokens(' Some  $drink   w^    ')
        self.assert_tokens([
            SimpleToken('Some', 1),
            SimpleToken('champagne', 7)])
        self.assert_stopped_on_token(2, SimpleToken('w', 19))

    def test_stop_when_value_is_surrounded_with_space_has_stopped_token(self) -> None:
        self.add_variable('drink', '  champagne   ')
        self.init_and_read_tokens('Some $drink w^')
        self.assert_tokens([
            SimpleToken('Some', 0),
            SimpleToken('champagne', 7)])
        self.assert_stopped_on_token(2, SimpleToken('w', 20))

    def test_stop_when_variable_and_value_is_surrounded_with_space_has_stopped_token(self) -> None:
        self.add_variable('drink', '  champagne   ')
        self.init_and_read_tokens(' Some   $drink    w^    ')
        self.assert_tokens([
            SimpleToken('Some', 1),
            SimpleToken('champagne', 10)])
        self.assert_stopped_on_token(2, SimpleToken('w', 26))

    def test_stop_with_recursive_expansion_has_stopped_token(self) -> None:
        self.add_variable('vessel', '        glass ')
        self.add_variable('drink', '  large    $vessel of   champagne   ')
        self.init_and_read_tokens(' Some   $drink    w^    ')
        self.assert_tokens([
            SimpleToken('Some', 1),
            SimpleToken('large', 10),
            SimpleToken('glass', 27),
            SimpleToken('of', 34),
            SimpleToken('champagne', 39)])
        self.assert_stopped_on_token(5, SimpleToken('w', 55))

    def test_get_expanded_text_provides_same_text_without_variables(self) -> None:
        self.init_and_read_tokens('these are normal tokens')
        self.assert_expanded_text('these are normal tokens')

    def test_get_expanded_text_provides_text_with_single_variable_expansion(self) -> None:
        self.add_variable('type', 'unusual')
        self.init_and_read_tokens('these are $type tokens')
        self.assert_expanded_text('these are unusual tokens')

    def test_get_expanded_text_provides_text_with_single_variable_expansion_and_surrounding_spaces(self) -> None:
        self.add_variable('type', ' unusual  ')
        self.init_and_read_tokens(' these   are    $type     tokens')
        self.assert_expanded_text(' these   are     unusual       tokens')

    def test_get_expanded_text_provides_text_with_multi_variable_expansion_in_the_middle(self) -> None:
        self.add_variable('colour', 'red')
        self.add_variable('material', 'brick')
        self.init_and_read_tokens('The $colour $material house')
        self.assert_expanded_text('The red brick house')

    def test_get_expanded_text_provides_text_with_multi_variable_expansion_at_the_ends(self) -> None:
        self.add_variable('count', 'Two')
        self.add_variable('structure', 'houses')
        self.init_and_read_tokens('$count red brick $structure')
        self.assert_expanded_text('Two red brick houses')

    def test_get_expanded_text_provides_text_with_recursive_variable_expansion(self) -> None:
        self.add_variable('colour', 'yellow')
        self.add_variable('material', 'straw')
        self.add_variable('structure', '$material hut')
        self.add_variable('home', 'big $colour $structure')
        self.init_and_read_tokens('There is a $home here')
        self.assert_expanded_text('There is a big yellow straw hut here')

    def test_get_expanded_text_provides_progressive_text_as_tokens_are_read(self) -> None:
        self.add_variable('colour', 'yellow')
        self.add_variable('material', 'straw')
        self.add_variable('structure', '$material hut')
        self.add_variable('home', 'big $colour $structure')
        self.init('There is a $home here')
        self.assert_expanded_text('')
        self.read_tokens(1)
        self.assert_expanded_text('There')
        self.read_tokens(1)
        self.assert_expanded_text('There is')
        self.read_tokens(1)
        self.assert_expanded_text('There is a')
        self.read_tokens(1)
        self.assert_expanded_text('There is a big')
        self.read_tokens(1)
        self.assert_expanded_text('There is a big yellow')
        self.read_tokens(1)
        self.assert_expanded_text('There is a big yellow straw')
        self.read_tokens(1)
        self.assert_expanded_text('There is a big yellow straw hut')
        self.read_tokens(1)
        self.assert_expanded_text('There is a big yellow straw hut here')

    def test_get_expanded_text_provides_text_up_to_stopped_token_with_no_variables(self) -> None:
        self.init_and_read_tokens('these are nor^mal tokens')
        self.assert_expanded_text('these are')

    def test_get_expanded_text_provides_text_up_to_stopped_token_with_expanded_variable(self) -> None:
        self.add_variable('car', 'blue sports car')
        self.init_and_read_tokens('there is a $car in t^he garage')
        self.assert_expanded_text('there is a blue sports car in')

    def test_get_remaining_text_provides_progressive_text_as_tokens_are_read(self) -> None:
        self.add_variable('colour', 'yellow')
        self.add_variable('material', 'straw')
        self.add_variable('structure', '$material hut')
        self.add_variable('home', 'big $colour $structure')
        self.init('There is a $home here')
        self.assert_remaining_text('There is a $home here')
        self.read_tokens(1)
        self.assert_remaining_text(' is a $home here')
        self.read_tokens(1)
        self.assert_remaining_text(' a $home here')
        self.read_tokens(1)
        self.assert_remaining_text(' $home here')
        self.read_tokens(1)
        self.assert_remaining_text(' $colour $structure here')
        self.read_tokens(1)
        self.assert_remaining_text(' $structure here')
        self.read_tokens(1)
        self.assert_remaining_text(' hut here')
        self.read_tokens(1)
        self.assert_remaining_text(' here')

    def test_get_remaining_text_includes_stopped_on_token_with_one_variable(self) -> None:
        self.add_variable('car', 'blue sports car')
        self.init_and_read_tokens('there is a $car in  t^he    garage ')
        self.assert_remaining_text('  the    garage ')

    def test_tokeniser_exception_at_root_has_correct_character_index(self) -> None:
        self.init_and_read_tokens('this text " is unterminated')
        self.assert_unsuccessful("String not terminated at end of text", 10)

    def test_tokeniser_exception_before_one_variable_has_correct_character_index(self) -> None:
        self.add_variable('x', 'unterminated')
        self.init_and_read_tokens('my text " is $x')
        self.assert_unsuccessful("String not terminated at end of text", 8)

    def test_tokeniser_exception_within_one_variable_has_correct_character_index(self) -> None:
        self.add_variable('x', 'text " is')
        self.init_and_read_tokens('why $x unterminated')
        self.assert_unsuccessful("String not terminated at end of text", 9)

    def test_tokeniser_exception_after_one_variable_has_correct_character_index(self) -> None:
        self.add_variable('x', 'this text')
        self.init_and_read_tokens('$x is " unterminated')
        self.assert_unsuccessful("String not terminated at end of text", 13)

    def test_tokeniser_exception_within_two_variables_has_correct_character_index(self) -> None:
        self.add_variable('colour', 'red and "green')
        self.add_variable('animal', 'strange $colour cat')
        self.init_and_read_tokens('a $animal sat')
        self.assert_unsuccessful("String not terminated at end of text", 18)

    def test_get_expanded_text_includes_missing_variable_on_exception(self) -> None:
        self.init_and_read_tokens('an  $animal  sat')
        self.assert_expanded_text('an  $animal')

    def test_get_expanded_text_includes_recursive_variable_on_exception(self) -> None:
        self.add_variable('animal', 'is there an $animal here')
        self.init_and_read_tokens('why  $animal  sat')
        self.assert_expanded_text('why  is there an $animal')

    def test_get_expanded_text_includes_invalid_variable_on_exception(self) -> None:
        self.add_variable('animal', 'is there an $#1234 here')
        self.init_and_read_tokens('why  $animal  sat')
        self.assert_expanded_text('why  is there an $#1234')
