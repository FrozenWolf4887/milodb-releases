# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import datetime
import unittest
from typing import override
from unittest.mock import Mock, PropertyMock
from milodb.client.updater.manifest.i_schema_types import IGroup, IItem, IKey, IKeyCreator, ITypedItem, ITypedKey, SchemaLoadError
from milodb.client.updater.manifest.schema_types import BooleanItem, DateItem, DynamicGroup, IntegerItem, ListGroup, StaticGroup, TextItem
from milodb_test.client.test.manifest_assertions import assert_typed_mapping_equal, assert_typed_sequence_equal
from milodb_test.common.test.strict_mock import InterfaceMock

class TestSchemaText(unittest.TestCase):
    @override
    def setUp(self) -> None:
        self.mock_parent = InterfaceMock(IGroup)
        self.mock_parent.add_child = Mock()

    def test_key_name_returns_name(self) -> None:
        self.assertEqual('dummy', TextItem(self.mock_parent, 'dummy').key.name)

    def test_full_path_returns_path(self) -> None:
        self.mock_parent.full_path = PropertyMock(return_value='root')
        self.assertEqual('root/dummy', TextItem(self.mock_parent, 'dummy').full_path)

    def test_parent_returns_parent(self) -> None:
        self.assertIs(self.mock_parent, TextItem(self.mock_parent, 'dummy').parent)

    def test_adds_to_parent_group(self) -> None:
        item = TextItem(self.mock_parent, 'dummy')
        self.mock_parent.add_child.assert_called_once_with(item)

    def test_value_before_load_returns_blank(self) -> None:
        self.mock_parent.full_path = PropertyMock(return_value='root')
        item = TextItem(self.mock_parent, 'dummy')
        self.assertEqual('', item.get_item_value())

    def test_load_non_text_value_throws(self) -> None:
        self.mock_parent.full_path = PropertyMock(return_value='root')
        item = TextItem(self.mock_parent, 'dummy')
        with self.assertRaises(SchemaLoadError) as capture:
            item.load(1234)
        self.assertEqual("Key 'root/dummy' value is not text", str(capture.exception))

    def test_load_empty_value_throws(self) -> None:
        self.mock_parent.full_path = PropertyMock(return_value='root')
        item = TextItem(self.mock_parent, 'dummy')
        with self.assertRaises(SchemaLoadError) as capture:
            item.load('')
        self.assertEqual("Key 'root/dummy' value is blank", str(capture.exception))

    def test_value_returns_loaded_text(self) -> None:
        self.mock_parent.full_path = PropertyMock(return_value='root')
        item = TextItem(self.mock_parent, 'dummy')
        item.load("abcd")
        self.assertEqual("abcd", item.get_item_value())

class TestSchemaInteger(unittest.TestCase):
    @override
    def setUp(self) -> None:
        self.mock_parent = InterfaceMock(IGroup)
        self.mock_parent.add_child = Mock()

    def test_key_name_returns_name(self) -> None:
        self.assertEqual('dummy', IntegerItem(self.mock_parent, 'dummy').key.name)

    def test_full_path_returns_path(self) -> None:
        self.mock_parent.full_path = PropertyMock(return_value='root')
        self.assertEqual('root/dummy', IntegerItem(self.mock_parent, 'dummy').full_path)

    def test_parent_returns_parent(self) -> None:
        self.assertIs(self.mock_parent, IntegerItem(self.mock_parent, 'dummy').parent)

    def test_adds_to_parent_group(self) -> None:
        item = IntegerItem(self.mock_parent, 'dummy')
        self.mock_parent.add_child.assert_called_once_with(item)

    def test_value_before_load_returns_zero(self) -> None:
        self.mock_parent.full_path = PropertyMock(return_value='root')
        item = IntegerItem(self.mock_parent, 'dummy')
        self.assertEqual(0, item.get_item_value())

    def test_load_non_integer_value_throws(self) -> None:
        self.mock_parent.full_path = PropertyMock(return_value='root')
        item = IntegerItem(self.mock_parent, 'dummy')
        with self.assertRaises(SchemaLoadError) as capture:
            item.load('fruit')
        self.assertEqual("Key 'root/dummy' value is not an integer", str(capture.exception))

    def test_load_empty_value_throws(self) -> None:
        self.mock_parent.full_path = PropertyMock(return_value='root')
        item = IntegerItem(self.mock_parent, 'dummy')
        with self.assertRaises(SchemaLoadError) as capture:
            item.load('')
        self.assertEqual("Key 'root/dummy' value is not an integer", str(capture.exception))

    def test_value_returns_loaded_integer(self) -> None:
        self.mock_parent.full_path = PropertyMock(return_value='root')
        item = IntegerItem(self.mock_parent, 'dummy')
        item.load(1234)
        self.assertEqual(1234, item.get_item_value())

class TestSchemaDate(unittest.TestCase):
    @override
    def setUp(self) -> None:
        self.mock_parent = InterfaceMock(IGroup)
        self.mock_parent.add_child = Mock()

    def test_key_name_returns_name(self) -> None:
        self.assertEqual('dummy', DateItem(self.mock_parent, 'dummy').key.name)

    def test_full_path_returns_path(self) -> None:
        self.mock_parent.full_path = PropertyMock(return_value='root')
        self.assertEqual('root/dummy', DateItem(self.mock_parent, 'dummy').full_path)

    def test_parent_returns_parent(self) -> None:
        self.assertIs(self.mock_parent, DateItem(self.mock_parent, 'dummy').parent)

    def test_adds_to_parent_group(self) -> None:
        item = DateItem(self.mock_parent, 'dummy')
        self.mock_parent.add_child.assert_called_once_with(item)

    def test_value_before_load_returns_minimum_date(self) -> None:
        self.mock_parent.full_path = PropertyMock(return_value='root')
        item = DateItem(self.mock_parent, 'dummy')
        self.assertEqual(datetime.date.min, item.get_item_value())

    def test_load_non_string_value_throws(self) -> None:
        self.mock_parent.full_path = PropertyMock(return_value='root')
        item = DateItem(self.mock_parent, 'dummy')
        with self.assertRaises(SchemaLoadError) as capture:
            item.load(1234)
        self.assertEqual("Key 'root/dummy' value is not text", str(capture.exception))

    def test_load_empty_value_throws(self) -> None:
        self.mock_parent.full_path = PropertyMock(return_value='root')
        item = DateItem(self.mock_parent, 'dummy')
        with self.assertRaises(SchemaLoadError) as capture:
            item.load('')
        self.assertEqual("Key 'root/dummy' value is blank", str(capture.exception))

    def test_load_non_date_value_throws(self) -> None:
        self.mock_parent.full_path = PropertyMock(return_value='root')
        item = DateItem(self.mock_parent, 'dummy')
        with self.assertRaises(SchemaLoadError) as capture:
            item.load('fruit')
        self.assertEqual("Key 'root/dummy' value 'fruit' is not an ISO date", str(capture.exception))

    def test_value_returns_loaded_date(self) -> None:
        self.mock_parent.full_path = PropertyMock(return_value='root')
        item = DateItem(self.mock_parent, 'dummy')
        item.load('2021-09-17')
        self.assertEqual(datetime.date(2021, 9, 17), item.get_item_value())

class TestSchemaBoolean(unittest.TestCase):
    @override
    def setUp(self) -> None:
        self.mock_parent = InterfaceMock(IGroup)
        self.mock_parent.add_child = Mock()

    def test_key_name_returns_name(self) -> None:
        self.assertEqual('dummy', BooleanItem(self.mock_parent, 'dummy').key.name)

    def test_full_path_returns_path(self) -> None:
        self.mock_parent.full_path = PropertyMock(return_value='root')
        self.assertEqual('root/dummy', BooleanItem(self.mock_parent, 'dummy').full_path)

    def test_parent_returns_parent(self) -> None:
        self.assertIs(self.mock_parent, BooleanItem(self.mock_parent, 'dummy').parent)

    def test_adds_to_parent_group(self) -> None:
        item = BooleanItem(self.mock_parent, 'dummy')
        self.mock_parent.add_child.assert_called_once_with(item)

    def test_value_before_load_returns_false(self) -> None:
        self.mock_parent.full_path = PropertyMock(return_value='root')
        item = BooleanItem(self.mock_parent, 'dummy')
        self.assertFalse(item.get_item_value())

    def test_load_non_boolean_value_throws(self) -> None:
        self.mock_parent.full_path = PropertyMock(return_value='root')
        item = BooleanItem(self.mock_parent, 'dummy')
        with self.assertRaises(SchemaLoadError) as capture:
            item.load('fruit')
        self.assertEqual("Key 'root/dummy' value is not a boolean", str(capture.exception))

    def test_load_empty_value_throws(self) -> None:
        self.mock_parent.full_path = PropertyMock(return_value='root')
        item = BooleanItem(self.mock_parent, 'dummy')
        with self.assertRaises(SchemaLoadError) as capture:
            item.load('')
        self.assertEqual("Key 'root/dummy' value is not a boolean", str(capture.exception))

    def test_value_returns_loaded_boolean(self) -> None:
        self.mock_parent.full_path = PropertyMock(return_value='root')
        for value in (True, False):
            with self.subTest(value=value):
                item = BooleanItem(self.mock_parent, 'dummy')
                item.load(value)
                self.assertEqual(value, item.get_item_value())

class TestSchemaStaticGroup(unittest.TestCase):
    @override
    def setUp(self) -> None:
        self.mock_parent = InterfaceMock(IGroup)
        self.mock_parent.add_child = Mock()

    def test_key_name_returns_name(self) -> None:
        self.assertEqual('dummy', StaticGroup(self.mock_parent, 'dummy').key.name)

    def test_full_path_returns_path(self) -> None:
        self.mock_parent.full_path = PropertyMock(return_value='root')
        self.assertEqual('root/dummy', StaticGroup(self.mock_parent, 'dummy').full_path)

    def test_parent_returns_parent(self) -> None:
        self.assertIs(self.mock_parent, StaticGroup(self.mock_parent, 'dummy').parent)

    def test_adds_to_parent_group(self) -> None:
        item = StaticGroup(self.mock_parent, 'dummy')
        self.mock_parent.add_child.assert_called_once_with(item)

    def test_load_non_dictionary_value_throws(self) -> None:
        self.mock_parent.full_path = PropertyMock(return_value='root')
        item = StaticGroup(self.mock_parent, 'dummy')
        with self.assertRaises(SchemaLoadError) as capture:
            item.load(1234)
        self.assertEqual("Key 'root/dummy' value is not a group", str(capture.exception))

    def test_load_empty_dictionary_without_children_does_nothing(self) -> None:
        item = StaticGroup(self.mock_parent, 'dummy')
        item.load({})

    def test_load_empty_dictionary_with_children_throws(self) -> None:
        self.mock_parent.full_path = PropertyMock(return_value='root')
        child = InterfaceMock(IItem)
        key = InterfaceMock(IKey)
        child.key = PropertyMock(return_value=key)
        child.is_mandatory = PropertyMock(return_value=True)
        key.name = PropertyMock(return_value='child-a')
        item = StaticGroup(self.mock_parent, 'dummy')
        item.add_child(child)
        with self.assertRaises(SchemaLoadError) as capture:
            item.load({})
        self.assertEqual("Key 'root/dummy/child-a' is missing", str(capture.exception))

    def test_load_dictionary_without_children_throws(self) -> None:
        self.mock_parent.full_path = PropertyMock(return_value='root')
        item = StaticGroup(self.mock_parent, 'dummy')
        with self.assertRaises(SchemaLoadError) as capture:
            item.load({'child-b': 1234})
        self.assertEqual("Key 'root/dummy/child-b' is unknown", str(capture.exception))

    def test_load_invalid_dictionary_throws(self) -> None:
        self.mock_parent.full_path = PropertyMock(return_value='root')
        item = StaticGroup(self.mock_parent, 'dummy')
        with self.assertRaises(SchemaLoadError) as capture:
            item.load({5678: 1234})
        self.assertEqual("Key 'root/dummy/5678' is not text", str(capture.exception))

    def test_load_calls_load_on_children(self) -> None:
        self.mock_parent.full_path = PropertyMock(return_value='root')

        child_a = InterfaceMock(IItem)
        key_a = InterfaceMock(IKey)
        child_a.key = PropertyMock(return_value=key_a)
        child_a.is_mandatory = PropertyMock(return_value=True)
        key_a.name = PropertyMock(return_value='child-a')
        child_a.load = Mock()

        child_b = InterfaceMock(IItem)
        key_b = InterfaceMock(IKey)
        child_b.key = PropertyMock(return_value=key_b)
        child_b.is_mandatory = PropertyMock(return_value=True)
        key_b.name = PropertyMock(return_value='child-b')
        child_b.load = Mock()

        item = StaticGroup(self.mock_parent, 'dummy')
        item.add_child(child_a)
        item.add_child(child_b)
        item.load({'child-a': 1234, 'child-b': '5678'})

        child_a.load.assert_called_once_with(1234)
        child_b.load.assert_called_once_with('5678')

class TestSchemaDynamicGroup(unittest.TestCase):
    @override
    def setUp(self) -> None:
        self.mock_parent = InterfaceMock(IGroup)
        self.mock_parent.add_child = Mock()
        self.mock_key_creator = InterfaceMock(IKeyCreator[int])
        self.mock_value_creator = Mock()

    def test_key_name_returns_name(self) -> None:
        self.assertEqual('dummy', DynamicGroup(self.mock_parent, 'dummy', self.mock_key_creator, self.mock_value_creator).key.name)

    def test_full_path_returns_path(self) -> None:
        self.mock_parent.full_path = PropertyMock(return_value='root')
        self.assertEqual('root/dummy', DynamicGroup(self.mock_parent, 'dummy', self.mock_key_creator, self.mock_value_creator).full_path)

    def test_parent_returns_parent(self) -> None:
        self.assertIs(self.mock_parent, DynamicGroup(self.mock_parent, 'dummy', self.mock_key_creator, self.mock_value_creator).parent)

    def test_adds_to_parent_group(self) -> None:
        item = DynamicGroup(self.mock_parent, 'dummy', self.mock_key_creator, self.mock_value_creator)
        self.mock_parent.add_child.assert_called_once_with(item)

    def test_load_non_dictionary_value_throws(self) -> None:
        self.mock_parent.full_path = PropertyMock(return_value='root')
        item = DynamicGroup(self.mock_parent, 'dummy', self.mock_key_creator, self.mock_value_creator)
        with self.assertRaises(SchemaLoadError) as capture:
            item.load(1234)
        self.assertEqual("Key 'root/dummy' value is not a group", str(capture.exception))

    def test_load_dictionary_calls_child_constructor(self) -> None:
        mock_key = InterfaceMock(IKey)
        self.mock_key_creator.parse = Mock(return_value=mock_key)
        item = DynamicGroup(self.mock_parent, 'dummy', self.mock_key_creator, self.mock_value_creator)
        item.load({'hello': 1234})
        self.mock_key_creator.parse.assert_called_once_with('hello')
        self.mock_value_creator.assert_called_once_with(item, mock_key)

    def test_load_dictionary_calls_load_on_child(self) -> None:
        mock_key = InterfaceMock(IKey)
        self.mock_key_creator.parse = Mock(return_value=mock_key)
        child = InterfaceMock(IItem)
        child.load = Mock()
        self.mock_value_creator = Mock(return_value=child)
        item = DynamicGroup(self.mock_parent, 'dummy', self.mock_key_creator, self.mock_value_creator)
        item.load({'hello': 1234})
        child.load.assert_called_once_with(1234)

    def test_get_returns_map_of_loaded_children(self) -> None:
        mock_key = InterfaceMock(ITypedKey[int])
        mock_key.get_key_value = Mock(return_value=5678)
        self.mock_key_creator.parse = Mock(return_value=mock_key)
        child = InterfaceMock(ITypedItem[str])
        child.load = Mock()
        child.get_item_value = Mock(return_value='banana')
        self.mock_value_creator = Mock(return_value=child)
        item = DynamicGroup(self.mock_parent, 'dummy', self.mock_key_creator, self.mock_value_creator)
        item.load({'hello': 1234})
        assert_typed_mapping_equal(self, {5678: 'banana'}, item.get())

class TestSchemaList(unittest.TestCase):
    @override
    def setUp(self) -> None:
        self.mock_parent = InterfaceMock(IGroup)
        self.mock_parent.add_child = Mock()
        self.mock_creator = Mock()

    def test_key_name_returns_name(self) -> None:
        self.assertEqual('dummy', ListGroup(self.mock_parent, 'dummy', self.mock_creator).key.name)

    def test_full_path_returns_path(self) -> None:
        self.mock_parent.full_path = PropertyMock(return_value='root')
        self.assertEqual('root/dummy', ListGroup(self.mock_parent, 'dummy', self.mock_creator).full_path)

    def test_parent_returns_parent(self) -> None:
        self.assertIs(self.mock_parent, ListGroup(self.mock_parent, 'dummy', self.mock_creator).parent)

    def test_adds_to_parent_group(self) -> None:
        item = ListGroup[int](self.mock_parent, 'dummy', self.mock_creator)
        self.mock_parent.add_child.assert_called_once_with(item)

    def test_load_non_list_value_throws(self) -> None:
        self.mock_parent.full_path = PropertyMock(return_value='root')
        item = ListGroup[int](self.mock_parent, 'dummy', self.mock_creator)
        with self.assertRaises(SchemaLoadError) as capture:
            item.load(1234)
        self.assertEqual("Key 'root/dummy' value is not a list", str(capture.exception))

    def test_load_list_calls_child_constructor(self) -> None:
        key = InterfaceMock(IKey)
        item = ListGroup[int](self.mock_parent, key, self.mock_creator)
        item.load(['hello'])
        self.mock_creator.assert_called_once_with(item, key)

    def test_load_list_calls_load_on_child(self) -> None:
        child = InterfaceMock(IItem)
        child.load = Mock()
        self.mock_creator = Mock(return_value=child)
        item = ListGroup[int](self.mock_parent, 'dummy', self.mock_creator)
        item.load(['hello'])
        child.load.assert_called_once_with('hello')

    def test_items_returns_list_of_loaded_children(self) -> None:
        child = InterfaceMock(ITypedItem[int])
        child.load = Mock()
        child.get_item_value = Mock(return_value=1234)
        self.mock_creator = Mock(return_value=child)
        item = ListGroup[int](self.mock_parent, 'dummy', self.mock_creator)
        item.load(['hello'])
        assert_typed_sequence_equal(self, [1234], item.get())
