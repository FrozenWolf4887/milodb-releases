# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
# spell-checker: disable
TEXT: str = ("Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
             " Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.")
# spell-checker: enable
TEXT_LEN: int = len(TEXT)

MULTILINE_TEXT: str = TEXT.replace(', ', '\n')
INDEX_OF_FIRST_EOL: int = MULTILINE_TEXT.find('\n')
INDEX_OF_FIRST_EOL_END: int = INDEX_OF_FIRST_EOL + 1
INDEX_OF_SECOND_EOL: int = MULTILINE_TEXT.find('\n', INDEX_OF_FIRST_EOL_END)
INDEX_OF_SECOND_EOL_END: int = INDEX_OF_SECOND_EOL + 1
INDEX_OF_THIRD_EOL: int = MULTILINE_TEXT.find('\n', INDEX_OF_SECOND_EOL_END)
INDEX_OF_THIRD_EOL_END: int = INDEX_OF_THIRD_EOL + 1

MULTI_EOL_TEXT: str = 'Hello\n\n\n\nWorld'
INDEX_OF_MULTI_EOL: int = MULTI_EOL_TEXT.find('\n')
INDEX_OF_MULTI_EOL_END: int = MULTI_EOL_TEXT.rfind('\n') + 1
