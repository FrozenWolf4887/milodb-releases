# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import os
import stat
import subprocess
import sys
from collections.abc import Iterable, Iterator, Sequence
from hashlib import sha3_224
from pathlib import Path, PurePath
from typing import override
from zipfile import ZIP_DEFLATED, ZipFile
from milodb.client.util.file_system import DirStat, FileStat, FileTest, IFileSystem
from milodb.common.output.print.i_printer import IPrinter
from milodb.common.system import IS_FROZEN_APP, PLATFORM, Platform

_HASH_BLOCK_SIZE_BYTES: int = 64 * 1024
_COPY_BLOCK_SIZE_BYTES: int = 64 * 1024

class RealFileSystem(IFileSystem):
    @override
    def get_absolute_path(self, path: PurePath) -> PurePath:
        return Path(path).absolute()

    @override
    def as_uri(self, path: PurePath | str) -> str | None:
        try:
            return Path(path).as_uri()
        except ValueError:
            return None

    @override
    def probe_file(self, path: PurePath, test: FileTest=FileTest.READABLE) -> FileStat:
        filepath: Path = Path(path)
        match test:
            case FileTest.READABLE:
                return _probe_file_readable(filepath)
            case FileTest.WRITABLE:
                return _probe_file_writeable(filepath)

    @override
    def probe_directory(self, path: PurePath) -> DirStat:
        dir_exists: bool
        is_empty: bool
        try:
            _ = next(Path(path).iterdir())
        except StopIteration:
            dir_exists = True
            is_empty = True
        except FileNotFoundError:
            dir_exists = False
            is_empty = True
        except OSError:
            dir_exists = False
            is_empty = True
        else:
            dir_exists = True
            is_empty = False
        return DirStat(path, dir_exists, is_empty)

    @override
    def read_file_bytes(self, path: PurePath) -> bytes:
        return Path(path).read_bytes()

    @override
    def write_file_bytes(self, path: PurePath, data: bytes) -> None:
        Path(path).write_bytes(data)

    @override
    def hash_file(self, path: PurePath) -> bytes:
        filepath: Path = Path(path)
        digest = sha3_224()
        end_of_file: bool = False
        with filepath.open('rb') as file:
            while not end_of_file:
                data_chunk: bytes = file.read(_HASH_BLOCK_SIZE_BYTES)
                if data_chunk:
                    digest.update(data_chunk)
                else:
                    end_of_file = True
        return digest.digest()

    @override
    def copy_file(self, source_path: PurePath, target_path: PurePath) -> None:
        with Path(source_path).open('rb') as source, Path(target_path).open('wb') as target:
            while block := source.read(_COPY_BLOCK_SIZE_BYTES):
                target.write(block)

    @override
    def move_file(self, original_path: PurePath, new_path: PurePath) -> None:
        Path(original_path).rename(new_path)

    @override
    def write_zip_file(self, zip_path: PurePath, source_path_iterator: Iterable[tuple[PurePath, PurePath]]) -> None:
        with Path(zip_path).open('wb') as raw_zip_file, ZipFile(raw_zip_file, mode='w', compression=ZIP_DEFLATED, compresslevel=9) as zip_file:
            source_path: PurePath
            target_path: PurePath
            for source_path, target_path in source_path_iterator:
                zip_file.write(source_path, target_path)

    @override
    def create_directory_and_parents_if_needed(self, path: PurePath) -> None:
        Path(path).mkdir(parents=True, exist_ok=True)

    @override
    def delete_file(self, path: PurePath) -> None:
        filepath: Path = Path(path)
        try:
            filepath.unlink()
        except PermissionError:
            current_mode: int = Path(path).stat().st_mode
            filepath.chmod(current_mode | stat.S_IWUSR)
            filepath.unlink()

    @override
    def delete_directory(self, path: PurePath) -> None:
        Path(path).rmdir()

    @override
    def set_file_attributes(self, path: PurePath, *, is_writeable: bool | None=None, is_executable: bool | None=None) -> Sequence[str]:
        original_mode: int = Path(path).stat().st_mode

        new_mode: int = original_mode
        list_of_mode_changes: list[str] = []

        if is_executable is not None:
            old_mode = new_mode
            if is_executable:
                new_mode = new_mode | stat.S_IXUSR
                if new_mode != old_mode:
                    list_of_mode_changes.append('+executable')
            else:
                new_mode = new_mode & ~stat.S_IXUSR
                if new_mode != old_mode:
                    list_of_mode_changes.append('-executable')

        if is_writeable is not None:
            old_mode = new_mode
            if is_writeable:
                new_mode = new_mode | stat.S_IWUSR
                if new_mode != old_mode:
                    list_of_mode_changes.append('+writable')
            else:
                new_mode = new_mode & ~stat.S_IWUSR
                if new_mode != old_mode:
                    list_of_mode_changes.append('-writable')

        if new_mode != original_mode:
            Path(path).chmod(new_mode)

        return list_of_mode_changes

    @override
    def iterate_directory(self, path: PurePath) -> Iterator[PurePath]:
        yield from Path(path).iterdir()

    @property
    @override
    def current_executable(self) -> PurePath:
        return PurePath(sys.executable)

    @override
    def launch(self, application_filepath: PurePath, command_line: Iterable[str | PurePath], normal_printer: IPrinter, error_printer: IPrinter) -> bool:
        if PLATFORM is Platform.UNKNOWN:
            error_printer.writeln(f"Unable to launch '{application_filepath}' because the platform is not recognised")
            return False

        all_launch_arguments: Sequence[PurePath | str] = [
            Path(application_filepath).absolute(),
            *command_line,
        ]
        normal_printer.writeln(f"Current directory is '{Path.cwd()}'")
        normal_printer.writeln(f"Launching '{application_filepath.name}' with [")
        normal_printer.writeln(f"{'\n  '.join(f"'{str(arg).replace("'", r"\'")}'" for arg in all_launch_arguments)}\n]")
        try:
            subprocess.Popen( # pylint: disable=consider-using-with # noqa: S603 `subprocess` call: check for execution of untrusted input
                args = all_launch_arguments,
                start_new_session = True,
            )
        except OSError as ex:
            error_printer.writeln(f'Failed to start application: {ex}')
            return False

        return True

    @override
    def get_list_of_process_ids(self) -> list[int]:
        if IS_FROZEN_APP:
            return [ os.getpid(), os.getppid() ]
        return [ os.getpid() ]

def _probe_file_readable(filepath: Path) -> FileStat:
    try:
        with filepath.open('rb'):
            pass
    except FileNotFoundError:
        return FileStat(filepath, does_exist=False, is_file=False, test_passed=False)
    except PermissionError:
        return FileStat(filepath, does_exist=True, is_file=filepath.is_file(), test_passed=False)
    except OSError:
        return FileStat(filepath, does_exist=True, is_file=False, test_passed=False)
    return FileStat(filepath, does_exist=True, is_file=True, test_passed=True)

def _probe_file_writeable(filepath: Path) -> FileStat:
    file_stat: FileStat = _probe_file_readable(filepath)
    if not file_stat.does_exist:
        return FileStat(filepath, does_exist=False, is_file=False, test_passed=True)

    tried_changing_attributes: bool = False
    while True:
        try:
            with filepath.open('ab'):
                pass
        except PermissionError:
            if tried_changing_attributes:
                return FileStat(filepath, does_exist=True, is_file=True, test_passed=False)
            tried_changing_attributes = True
            try:
                filepath.chmod(filepath.stat().st_mode | stat.S_IWUSR)
            except OSError:
                return FileStat(filepath, does_exist=True, is_file=False, test_passed=False)
        except OSError:
            return FileStat(filepath, does_exist=True, is_file=False, test_passed=False)
        else:
            return FileStat(filepath, does_exist=True, is_file=True, test_passed=True)
