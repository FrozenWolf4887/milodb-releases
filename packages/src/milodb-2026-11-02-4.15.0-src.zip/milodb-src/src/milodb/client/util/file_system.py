# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from abc import ABC, abstractmethod
from collections.abc import Iterable, Iterator, Sequence
from enum import Enum
from pathlib import PurePath
from typing import NamedTuple
from milodb.common.output.print.i_printer import IPrinter

class FileStat(NamedTuple):
    path: PurePath
    does_exist: bool
    is_file: bool
    test_passed: bool

class FileTest(Enum):
    READABLE = 0
    WRITABLE = 1

class DirStat(NamedTuple):
    path: PurePath
    does_exist: bool
    is_empty: bool

class IFileSystem(ABC):
    @abstractmethod
    def get_absolute_path(self, path: PurePath) -> PurePath:
        pass

    @abstractmethod
    def as_uri(self, path: PurePath | str) -> str | None:
        pass

    @abstractmethod
    def probe_file(self, path: PurePath, test: FileTest=FileTest.READABLE) -> FileStat:
        pass

    @abstractmethod
    def probe_directory(self, path: PurePath) -> DirStat:
        pass

    @abstractmethod
    def read_file_bytes(self, path: PurePath) -> bytes:
        """Read all bytes from the file.

        ### Raises
        - OSError
            - If the file cannot be read from
        """

    @abstractmethod
    def write_file_bytes(self, path: PurePath, data: bytes) -> None:
        """Write bytes to the file.

        If the file doesn't exist, it will be created.
        If the file exists, its contents will be replaced.

        ### Raises
        - OSError
            - If the file cannot be written to
        """

    @abstractmethod
    def hash_file(self, path: PurePath) -> bytes:
        """Hash the specified file and returns the digest.

        ### Raises:
        - OSError
            - If there was any error hashing the file
        """

    @abstractmethod
    def copy_file(self, source_path: PurePath, target_path: PurePath) -> None:
        """Copy the file.

        ### Raises
        - OSError
            - If the file cannot be copied
        """

    @abstractmethod
    def move_file(self, original_path: PurePath, new_path: PurePath) -> None:
        """Rename the file.

        ### Raises
        - OSError
            - If the file cannot be renamed
        """

    @abstractmethod
    def write_zip_file(self, zip_path: PurePath, source_path_iterator: Iterable[tuple[PurePath, PurePath]]) -> None:
        """Write a zip file with the list of provided files.

        ### Raises
        - OSError
            - If the zip file cannot be created, written to, or a source file cannot be read
        """

    @abstractmethod
    def create_directory_and_parents_if_needed(self, path: PurePath) -> None:
        """Create directory.

        Creates parent directories if needed.
        If the directory already exists, no error is returned.

        ### Raises
        - OSError
            - If the directory cannot be created.
        """

    @abstractmethod
    def delete_file(self, path: PurePath) -> None:
        """Delete the file.

        ### Raises
        - OSError
            - If the file cannot be deleted
        """

    @abstractmethod
    def delete_directory(self, path: PurePath) -> None:
        """Delete the directory.

        This will fail if the directory is not empty.

        ### Raises
        - OSError
            - If the directory cannot be deleted
        """

    @abstractmethod
    def set_file_attributes(self, path: PurePath, *, is_writeable: bool | None=None, is_executable: bool | None=None) -> Sequence[str]:
        """Set the file attributes of the specified file.

        ### Returns
        List of textual names of the modes that were actually changed on the file.
        If the list is empty, the mode is already set as required on the file.
        - '+executable' if the executable flag was set
        - '-executable' if the executable flag was cleared
        - '+writable' if the file is writable
        - '-writable' if the file is readonly

        ### Raises
        - OSError
            - If the file attributes cannot be retrieved or changed
        """

    @abstractmethod
    def iterate_directory(self, path: PurePath) -> Iterator[PurePath]:
        """Iterate over the files and directories in the given path.

        ### Raises
        - OSError
            - If the directory does not exist or cannot be iterated.
        """

    @property
    @abstractmethod
    def current_executable(self) -> PurePath:
        pass

    @abstractmethod
    def launch(self, application_filepath: PurePath, command_line: Iterable[str | PurePath], normal_printer: IPrinter, error_printer: IPrinter) -> bool:
        pass

    @abstractmethod
    def get_list_of_process_ids(self) -> list[int]:
        """Get the process ids for this process.

        Frozen applications, i.e. those running under pyinstaller, are child processes of the
        pyinstaller bootstrap:
        https://pyinstaller.org/en/v6.3.0/advanced-topics.html#the-bootstrap-process-in-detail

        When the child process terminates, the executable from which it was launched continues
        to be locked by the operating system until the parent bootstrap process terminates.
        Therefore, to ensure the frozen application has terminated it is necessary to wait for
        its parent process to terminate.
        """
