# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from abc import ABC, abstractmethod
from pathlib import PurePath
from typing import override
from milodb.client.startup.command_line import Argument
from milodb.client.util.file_system import IFileSystem
from milodb.client.view.progress_display import IProgressDisplay

class IShutdownAction(ABC):
    @abstractmethod
    def perform_action(self, progress_display: IProgressDisplay) -> bool:
        pass

class RestartToCompleteUpdateAction(IShutdownAction):
    def __init__(self, filesystem: IFileSystem, *, new_application_filepath: PurePath, temp_directory: PurePath) -> None:
        self._filesystem: IFileSystem = filesystem
        self._new_application_filepath: PurePath = new_application_filepath
        self._temp_directory: PurePath = temp_directory

    @override
    def perform_action(self, progress_display: IProgressDisplay) -> bool:
        progress_display.set_action_text('Updating')
        progress_display.set_activity_category('Restart')
        progress_display.set_activity_text('Launch')
        progress_display.normal_printer.writeln('Restarting application to complete update...')
        return self._filesystem.launch(
            self._new_application_filepath, [
                *_get_arguments_for_waiting_for_this_process_to_terminate(self._filesystem),
                Argument.PURGE_TEMP_DIRECTORY,
                self._temp_directory,
            ],
            progress_display.normal_printer,
            progress_display.error_printer,
        )

def _get_arguments_for_waiting_for_this_process_to_terminate(filesystem: IFileSystem) -> list[str]:
    arguments: list[str] = []
    for process_id in filesystem.get_list_of_process_ids():
        arguments.extend((Argument.WAIT_PID, str(process_id)))
    return arguments
