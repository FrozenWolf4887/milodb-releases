# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import json
import time
from collections.abc import Iterable
from dataclasses import dataclass
from pathlib import PurePath
import psutil
from milodb.client.startup.command_line import CommandLine, CommandLineError, parse_command_line
from milodb.client.startup.shutdown_action import IShutdownAction, RestartToCompleteUpdateAction
from milodb.client.updater.i_temp_directory import ITempDirectory, TempDirectoryError
from milodb.client.updater.manifest.i_schema_types import SchemaLoadError
from milodb.client.updater.manifest.update_sequence_schema import UpdateSequenceSchema
from milodb.client.updater.perform_pre_update_safety_check import PerformPreUpdateSafetyCheckError, perform_pre_update_safety_check
from milodb.client.updater.perform_update import PerformUpdateError, perform_update
from milodb.client.updater.temp_directory import TempDirectory
from milodb.client.util.file_system import IFileSystem
from milodb.client.view.progress_display import IProgressDisplay

_PID_WAIT_TIMEOUT_SECONDS: int = 10

@dataclass(kw_only=True)
class StartupResult:
    run_main_application: bool
    shutdown_action: IShutdownAction | None

def startup(list_of_args: Iterable[str], progress_display: IProgressDisplay, filesystem: IFileSystem) -> tuple[StartupResult, CommandLine | None]:
    progress_display.set_action_text('Startup')
    progress_display.set_activity_category('Command line')
    progress_display.set_activity_text('Parse')
    try:
        command_line: CommandLine = parse_command_line(list_of_args)
    except CommandLineError as ex:
        progress_display.print_fatal_and_prompt_on_exit(f'Command line error: {ex}')
        return StartupResult(run_main_application=False, shutdown_action=None), None

    if (_wait_for_list_of_pids_to_end(command_line.list_of_pids_to_wait_on, _PID_WAIT_TIMEOUT_SECONDS, progress_display) and
        _purge_list_of_temp_directories(command_line.list_of_temp_directories_to_purge, progress_display, filesystem)
    ):
        if command_line.update_from_sequence_filepath:
            return _process_perform_update(command_line.update_from_sequence_filepath, progress_display, filesystem), command_line

        return StartupResult(run_main_application=True, shutdown_action=None), command_line

    return StartupResult(run_main_application=False, shutdown_action=None), command_line

def _wait_for_list_of_pids_to_end(list_of_pids: Iterable[int], timeout_seconds: int, progress_display: IProgressDisplay) -> bool:
    progress_display.set_activity_category('Starting')
    return all(_wait_for_pid_to_end(pid, timeout_seconds, progress_display) for pid in list_of_pids)

def _wait_for_pid_to_end(pid: int, timeout_seconds: int, progress_display: IProgressDisplay) -> bool:
    progress_display.set_activity_text(f'Waiting for PID {pid}')
    progress_display.normal_printer.writeln(f'Waiting for PID {pid} to finish...')
    start_time_ns: int = time.monotonic_ns()
    while psutil.pid_exists(pid):
        time.sleep(0.5)
        elapsed_time_seconds: int = (time.monotonic_ns() - start_time_ns) // 1_000_000_000
        if elapsed_time_seconds >= timeout_seconds:
            progress_display.print_fatal_and_prompt_on_exit(f"PID {pid} didn't end within {timeout_seconds} seconds")
            return False
    progress_display.normal_printer.writeln(f'PID {pid} finished')
    return True

def _purge_list_of_temp_directories(list_of_directories: Iterable[PurePath], progress_display: IProgressDisplay, filesystem: IFileSystem) -> bool:
    if list_of_directories:
        progress_display.set_activity_category('Update')

    directory: PurePath
    for directory in list_of_directories:
        progress_display.set_activity_text('Cleaning up')
        progress_display.normal_printer.writeln(f"Purge temporary directory '{directory}'")
        try:
            TempDirectory(directory, filesystem).destroy()
        except TempDirectoryError as ex:
            progress_display.print_warning_and_prompt_on_exit(f"Couldn't purge directory '{directory}': {ex}")
            return False
    return True

def _process_perform_update(update_sequence_filepath: PurePath, progress_display: IProgressDisplay, filesystem: IFileSystem) -> StartupResult:
    progress_display.set_action_text('Updating')
    progress_display.set_activity_category('Upgrade')
    progress_display.set_activity_text('Load schema')
    progress_display.normal_printer.writeln(f"Load schema from '{update_sequence_filepath}'")
    try:
        update_strategy_json: object = json.loads(filesystem.read_file_bytes(update_sequence_filepath))
    except (OSError, json.JSONDecodeError, UnicodeDecodeError) as ex:
        progress_display.print_fatal_and_prompt_on_exit(f"Loading '{update_sequence_filepath}' failed: {ex}")
        return StartupResult(run_main_application=False, shutdown_action=None)
    progress_display.set_progress_percentage(10)

    progress_display.normal_printer.writeln('Parse schema')
    update_sequence: UpdateSequenceSchema = UpdateSequenceSchema()
    try:
        update_sequence.load(update_strategy_json)
    except SchemaLoadError as ex:
        progress_display.print_fatal_and_prompt_on_exit(f"Parsing '{update_sequence_filepath}' failed: {ex}")
        return StartupResult(run_main_application=False, shutdown_action=None)
    progress_display.set_progress_percentage(20)

    temp_directory: ITempDirectory = TempDirectory(update_sequence.temp_directory, filesystem)

    progress_display.set_activity_text('Pre-update safety check')
    progress_display.normal_printer.writeln('Pre-update safety check')
    try:
        perform_pre_update_safety_check(temp_directory, update_sequence, progress_display.normal_printer, filesystem)
    except PerformPreUpdateSafetyCheckError as ex:
        progress_display.print_fatal_and_prompt_on_exit(f"Failed pre-update safety check: {ex}")
        return StartupResult(run_main_application=False, shutdown_action=None)
    progress_display.set_progress_percentage(60)

    progress_display.set_activity_text('Updating files')
    progress_display.normal_printer.writeln('Updating files')
    try:
        perform_update(temp_directory, update_sequence, progress_display.normal_printer, progress_display.error_printer, filesystem)
    except PerformUpdateError as ex:
        progress_display.print_fatal_and_prompt_on_exit(f"Failed to update one or more files: {ex}")
        return StartupResult(run_main_application=False, shutdown_action=None)
    progress_display.set_progress_percentage(100)

    progress_display.set_activity_text('Restarting...')

    shutdown_action: IShutdownAction | None = None
    if update_sequence.launch_filename:
        shutdown_action = RestartToCompleteUpdateAction(
            filesystem,
            new_application_filepath = update_sequence.root_directory / update_sequence.launch_filename,
            temp_directory = update_sequence.temp_directory,
        )
    else:
        progress_display.print_warning_and_prompt_on_exit("There is no known new application that can be started")

    return StartupResult(run_main_application=False, shutdown_action=shutdown_action)
