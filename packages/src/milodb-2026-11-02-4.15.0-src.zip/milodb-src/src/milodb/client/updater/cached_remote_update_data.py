# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from __future__ import annotations
import json
import urllib.parse
from abc import ABC, abstractmethod
from typing import NamedTuple, TYPE_CHECKING, override
from milodb.client.updater.manifest.i_schema_types import IItem, SchemaLoadError
from milodb.client.updater.manifest.update_directory_schema import UpdateDirectorySchema
from milodb.client.updater.manifest.version_manifest_schema import VersionManifestSchema
if TYPE_CHECKING:
    from milodb.client.view.progress_display import IProgressDisplay
    from milodb.client.updater.manifest.update_directory import IUpdateDirectory
    from milodb.client.updater.manifest.version_manifest import IVersionManifest
    from milodb.common.internet.i_scraper import IUrlScraper, IUrlScraperFactory, ScrapeResult
    from milodb.common.output.print.i_printer import IPrinter

class RemoteUpdateData(NamedTuple):
    update_directory: IUpdateDirectory
    version_manifest: IVersionManifest

class ICachedRemoteUpdateData(ABC):
    @abstractmethod
    def try_get(self) -> RemoteUpdateData | None:
        pass

    @abstractmethod
    def fetch(self, update_directory_url: str, url_scraper_factory: IUrlScraperFactory, progress_display: IProgressDisplay) -> RemoteUpdateData | None:
        pass

class CachedRemoteUpdateData(ICachedRemoteUpdateData):
    def __init__(self) -> None:
        self._update_directory: IUpdateDirectory | None = None
        self._version_manifest: IVersionManifest | None = None

    @override
    def try_get(self) -> RemoteUpdateData | None:
        if self._update_directory and self._version_manifest:
            return RemoteUpdateData(self._update_directory, self._version_manifest)
        return None

    @override
    def fetch(self, update_directory_url: str, url_scraper_factory: IUrlScraperFactory, progress_display: IProgressDisplay) -> RemoteUpdateData | None:
        remote_update_data: RemoteUpdateData | None = self.try_get()
        if remote_update_data:
            return remote_update_data

        url_scraper: IUrlScraper
        with url_scraper_factory.new_pool(progress_display.normal_printer.writeln) as url_scraper:
            progress_display.set_activity_text('Directory')
            try:
                self._update_directory = _fetch_schema_file(UpdateDirectorySchema(), 'update directory', update_directory_url, url_scraper, progress_display.normal_printer)
            except _FetchSchemaError as ex:
                progress_display.error_printer.writeln(str(ex))
            else:
                progress_display.set_activity_text('Versions')
                version_manifest_url: str = urllib.parse.urljoin(update_directory_url, self._update_directory.version_manifest_url)
                try:
                    self._version_manifest = _fetch_schema_file(VersionManifestSchema(), 'version manifest', version_manifest_url, url_scraper, progress_display.normal_printer)
                except _FetchSchemaError as ex:
                    progress_display.error_printer.writeln(str(ex))

        return self.try_get()

class _FetchSchemaError(Exception):
    pass

def _fetch_schema_file[T: IItem](schema: T, name_of_schema: str, url: str, url_scraper: IUrlScraper, printer: IPrinter) -> T:
    printer.writeln(f'Fetching {name_of_schema}')

    def progress_callback(*, message: str | None, percentage_complete: int | None) -> None:
        _ = percentage_complete
        if message:
            printer.writeln(f'  {message}')
    scrape_result: ScrapeResult = url_scraper.try_scrape_url(url, progress_callback)
    if scrape_result.error_message:
        msg = f"Failed to fetch {name_of_schema} from '{url}': {scrape_result.error_message}"
        raise _FetchSchemaError(msg)

    try:
        json_root: object = json.loads(scrape_result.content)
    except json.JSONDecodeError as ex:
        msg = f"{name_of_schema.capitalize()} '{url}' could not be parsed as JSON: {ex}"
        raise _FetchSchemaError(msg) from ex

    try:
        schema.load(json_root)
    except SchemaLoadError as ex:
        msg = f"{name_of_schema.capitalize()} '{url}' error: {ex}"
        raise _FetchSchemaError(msg) from ex

    return schema
