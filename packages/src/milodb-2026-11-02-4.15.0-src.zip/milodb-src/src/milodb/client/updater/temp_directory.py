# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import tempfile
from pathlib import PurePath
from typing import override
from milodb.client.updater.i_temp_directory import ITempDirectory, ITempDirectoryCreator, TempDirectoryError
from milodb.client.util.file_system import IFileSystem

_FILENAME_PREFIX: str = 'mdbu-'

class TempDirectory(ITempDirectory):
    def __init__(self, path_to_directory: PurePath, filesystem: IFileSystem) -> None:
        self._path_to_directory: PurePath = path_to_directory
        self._filesystem: IFileSystem = filesystem

    @property
    @override
    def path(self) -> PurePath:
        return self._path_to_directory

    @override
    def path_of(self, filename: str) -> PurePath:
        return self._path_to_directory / f'{_FILENAME_PREFIX}{filename}'

    @override
    def store_file(self, filename: str, data: bytes, *, is_executable: bool=False) -> None:
        if len(PurePath(filename).parts) > 1:
            msg = f"Temporary filename '{filename}' may not contain directory components"
            raise TempDirectoryError(msg)

        filepath: PurePath = self.path_of(filename)
        try:
            self._filesystem.write_file_bytes(filepath, data)
        except OSError as ex:
            msg = f"Unable to store file '{filepath}': {ex}"
            raise TempDirectoryError(msg) from ex

        try:
            self._filesystem.set_file_attributes(filepath, is_executable=is_executable)
        except OSError as ex:
            msg = f"Unable to set attributes of file '{filepath}': {ex}"
            raise TempDirectoryError(msg) from ex

    @override
    def destroy(self) -> None:
        filepath: PurePath
        try:
            for filepath in self._filesystem.iterate_directory(self._path_to_directory):
                if filepath.name.startswith(_FILENAME_PREFIX):
                    self._filesystem.delete_file(filepath)
                else:
                    msg = f"Refusing to delete temp file '{filepath}' because it doesn't start with '{_FILENAME_PREFIX}'"
                    raise TempDirectoryError(msg)
            self._filesystem.delete_directory(self._path_to_directory)
        except OSError as ex:
            msg = f"Failed to delete temp directory '{self._path_to_directory}': {ex}"
            raise TempDirectoryError(msg) from ex

class SystemTempDirectoryCreator(ITempDirectoryCreator):
    def __init__(self, filesystem: IFileSystem) -> None:
        self._filesystem: IFileSystem = filesystem

    @override
    def create(self) -> ITempDirectory:
        try:
            path_to_directory: PurePath = PurePath(tempfile.mkdtemp(prefix='update-temp-', dir=PurePath()))
        except OSError as ex:
            msg = f"Cannot create temp directory: {ex}"
            raise TempDirectoryError(msg) from ex
        return TempDirectory(path_to_directory, self._filesystem)
