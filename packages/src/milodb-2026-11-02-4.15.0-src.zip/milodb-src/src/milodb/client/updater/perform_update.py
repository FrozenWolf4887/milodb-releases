# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from collections.abc import Mapping, MutableMapping, Set as AbstractSet
from pathlib import PurePath
from typing import TYPE_CHECKING
from milodb.client.updater.i_temp_directory import ITempDirectory
from milodb.client.updater.manifest.update_sequence import IDeleteFile, IDeleteFilesAction, IEmplaceFile, IEmplaceFilesAction, IMoveFile, IMoveFilesAction, ISetFileAttribute, ISetFilesAttributeAction, IUpdateSequence
from milodb.client.util.file_system import DirStat, IFileSystem
from milodb.common.output.print.i_printer import IPrinter
if TYPE_CHECKING:
    from collections.abc import Sequence

class PerformUpdateError(Exception):
    pass

def perform_update(temp_directory: ITempDirectory, update_sequence: IUpdateSequence, normal_printer: IPrinter, warning_printer: IPrinter, filesystem: IFileSystem) -> None:
    """Perform the update according to the specified update_sequence.

    ### Raises
    - PerformUpdateError
    """
    set_of_all_action_priorities: AbstractSet[int] = {
        *update_sequence.delete_files_actions.keys(),
        *update_sequence.move_files_actions.keys(),
        *update_sequence.emplace_files_actions.keys(),
        *update_sequence.set_files_attribute_actions.keys(),
    }

    priority: int
    for priority in sorted(set_of_all_action_priorities):
        delete_action: IDeleteFilesAction | None = update_sequence.delete_files_actions.get(priority)
        if delete_action:
            perform_delete_action(update_sequence.root_directory, delete_action, normal_printer, warning_printer, filesystem)
        move_action: IMoveFilesAction | None = update_sequence.move_files_actions.get(priority)
        if move_action:
            perform_move_action(update_sequence.root_directory, move_action, normal_printer, filesystem)
        emplace_action: IEmplaceFilesAction | None = update_sequence.emplace_files_actions.get(priority)
        if emplace_action:
            perform_emplace_action(update_sequence.root_directory, temp_directory, emplace_action, normal_printer, filesystem)
        set_attribute_action: ISetFilesAttributeAction | None = update_sequence.set_files_attribute_actions.get(priority)
        if set_attribute_action:
            perform_set_attribute_action(update_sequence.root_directory, set_attribute_action, normal_printer, filesystem)

def perform_delete_action(root_directory: PurePath, delete_action: IDeleteFilesAction, normal_printer: IPrinter, warning_printer: IPrinter, filesystem: IFileSystem) -> None:
    """Remove the specified list of files and their directories if empty.

    ### Raises
    - PerformUpdateError
    """
    normal_printer.writeln('Removing files')

    file: IDeleteFile
    for file in delete_action.files:
        filepath: PurePath = root_directory / file.filename
        normal_printer.writeln(f"  Removing '{filepath}'")
        try:
            filesystem.delete_file(filepath)
        except OSError as ex:
            if not isinstance(ex, FileNotFoundError) or file.must_exist:
                msg = f"Failed to remove file '{filepath}': {ex}"
                raise PerformUpdateError(msg) from ex

    normal_printer.writeln('Removing directories')

    map_of_directories: _MutableRecursiveDirectoryMap = {}
    for file in delete_action.files:
        sub_map: _MutableRecursiveDirectoryMap = map_of_directories
        for part in file.filename.parent.parts:
            sub_map = sub_map.setdefault(PurePath(part), {})

    _prune_directory_map(PurePath(root_directory), map_of_directories, normal_printer, warning_printer, filesystem)

def perform_move_action(root_directory: PurePath, move_action: IMoveFilesAction, printer: IPrinter, filesystem: IFileSystem) -> None:
    """Perform the specified file move action.

    ### Raises
    - PerformUpdateError
    """
    printer.writeln('Moving files')
    file: IMoveFile
    for file in move_action.files:
        printer.writeln(f"  Move '{file.original_filename}' to '{file.new_filename}'")
        original_path: PurePath = root_directory / file.original_filename
        new_path: PurePath = root_directory / file.new_filename
        try:
            filesystem.move_file(original_path, new_path)
        except OSError as ex:
            if not isinstance(ex, FileNotFoundError) or file.must_exist:
                msg = f"Failed to rename file '{original_path}' to '{new_path}': {ex}"
                raise PerformUpdateError(msg) from ex

def perform_emplace_action(root_directory: PurePath, temp_directory: ITempDirectory, emplace_action: IEmplaceFilesAction, printer: IPrinter, filesystem: IFileSystem) -> None:
    """Perform the specified emplace file action.

    ### Raises
    - PerformUpdateError
    """
    printer.writeln('Emplacing files')

    file: IEmplaceFile
    for file in emplace_action.files:
        source_path: PurePath = temp_directory.path_of(file.source_filename.name)
        target_path: PurePath = root_directory / file.target_filename

        printer.writeln(f"  Emplacing '{file.target_filename}'")

        try:
            filesystem.create_directory_and_parents_if_needed(target_path.parent)
        except OSError as ex:
            msg = f"Failed to create directory for asset '{target_path}': {ex}"
            raise PerformUpdateError(msg) from ex

        try:
            filesystem.copy_file(source_path, target_path)
        except OSError as ex:
            msg = f"Failed to copy asset '{source_path}' to '{target_path}': {ex}"
            raise PerformUpdateError(msg) from ex

def perform_set_attribute_action(root_directory: PurePath, set_attribute_action: ISetFilesAttributeAction, printer: IPrinter, filesystem: IFileSystem) -> None:
    """Perform the specified set file attribute action.

    ### Raises
    - PerformUpdateError
    """
    printer.writeln('Setting file attributes')

    file: ISetFileAttribute
    for file in set_attribute_action.files:
        path: PurePath = root_directory / file.filename
        try:
            list_of_mode_changes: Sequence[str] = filesystem.set_file_attributes(path, is_executable=file.is_executable, is_writeable=not file.is_readonly)
        except OSError as ex:
            msg = f"Failed to set attributes of file '{path}': {ex}"
            raise PerformUpdateError(msg) from ex
        if list_of_mode_changes:
            printer.writeln(f"  Changed '{file.filename}' to {','.join(list_of_mode_changes)}")

_MutableRecursiveDirectoryMap = MutableMapping[PurePath, '_MutableRecursiveDirectoryMap']
_RecursiveDirectoryMap = Mapping[PurePath, '_RecursiveDirectoryMap']

def _prune_directory_map(parent_path: PurePath, map_of_directories: _RecursiveDirectoryMap, normal_printer: IPrinter, warning_printer: IPrinter, filesystem: IFileSystem) -> None:
    dirname: PurePath
    sub_map: _RecursiveDirectoryMap
    for dirname, sub_map in map_of_directories.items():
        path: PurePath = parent_path / dirname
        if sub_map:
            _prune_directory_map(path, sub_map, normal_printer, warning_printer, filesystem)

        dir_stat: DirStat = filesystem.probe_directory(path)
        if dir_stat.does_exist and dir_stat.is_empty:
            normal_printer.writeln(f"  Removing '{path}'")
            try:
                filesystem.delete_directory(path)
            except OSError as ex:
                warning_printer.writeln(f"  Failed to remove directory '{path}': {ex}")
        else:
            normal_printer.writeln(f"  Leaving populated directory '{path}'")
