# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from milodb.client.startup.command_line import Argument
from milodb.client.updater.prepare_update import UpdateReady
from milodb.client.util.file_system import IFileSystem
from milodb.client.view.progress_display import IProgressDisplay

def try_start_update(update_ready: UpdateReady, filesystem: IFileSystem, progress_display: IProgressDisplay) -> bool:
    progress_display.set_action_text('Updating')
    progress_display.set_activity_category('Restart')
    progress_display.set_activity_text('Launch')
    progress_display.normal_printer.writeln('Restarting application to perform update...')
    return filesystem.launch(
        update_ready.temp_application_filepath, [
            *_get_arguments_for_waiting_for_this_process_to_terminate(filesystem),
            Argument.PERFORM_UPDATE,
            update_ready.update_sequence_filepath,
        ],
        progress_display.normal_printer,
        progress_display.error_printer,
    )

def _get_arguments_for_waiting_for_this_process_to_terminate(filesystem: IFileSystem) -> list[str]:
    arguments: list[str] = []
    for process_id in filesystem.get_list_of_process_ids():
        arguments.extend((Argument.WAIT_PID, str(process_id)))
    return arguments
