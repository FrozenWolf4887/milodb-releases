# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from collections.abc import Iterable
from enum import Enum
from pathlib import Path
from typing import NamedTuple
from milodb.client.updater.i_temp_directory import ITempDirectory
from milodb.client.updater.manifest.update_sequence import IUpdateSequence
from milodb.client.util.file_system import FileStat, FileTest, IFileSystem
from milodb.common.output.print.i_printer import IPrinter

class PerformPreUpdateSafetyCheckError(Exception):
    pass

def perform_pre_update_safety_check(temp_directory: ITempDirectory, update_sequence: IUpdateSequence, printer: IPrinter, filesystem: IFileSystem) -> None:
    """Perform the update according to the specified update_sequence.

    ### Raises
    - PerformUpdateError
    """
    _verify_list_of_files((
        _FileForVerification(Path(update_sequence.root_directory / file.filename), 'deletable', _VerifyAction.WRITABLE, file.must_exist)
            for action in update_sequence.delete_files_actions.values() for file in action.files
        ), printer, filesystem,
    )
    _verify_list_of_files((
        _FileForVerification(Path(update_sequence.root_directory / file.original_filename), 'readable', _VerifyAction.READABLE, file.must_exist)
            for action in update_sequence.move_files_actions.values() for file in action.files
        ), printer, filesystem,
    )
    _verify_list_of_files((
        _FileForVerification(Path(update_sequence.root_directory / file.new_filename), 'writable', _VerifyAction.WRITABLE, must_exist=False)
            for action in update_sequence.move_files_actions.values() for file in action.files
        ), printer, filesystem,
    )
    _verify_list_of_files((
        _FileForVerification(Path(temp_directory.path_of(file.source_filename.name)), 'readable', _VerifyAction.READABLE, must_exist=True)
            for action in update_sequence.emplace_files_actions.values() for file in action.files
        ), printer, filesystem,
    )
    _verify_list_of_files((
        _FileForVerification(Path(update_sequence.root_directory / file.target_filename), 'writable', _VerifyAction.WRITABLE, must_exist=False)
            for action in update_sequence.emplace_files_actions.values() for file in action.files
        ), printer, filesystem,
    )
    _verify_list_of_files((
        _FileForVerification(Path(update_sequence.root_directory / file.filename), 'writable', _VerifyAction.WRITABLE, must_exist=False)
            for action in update_sequence.set_files_attribute_actions.values() for file in action.files
        ), printer, filesystem,
    )

class _VerifyAction(Enum):
    READABLE = 'readable'
    WRITABLE = 'writable'

class _FileForVerification(NamedTuple):
    filepath: Path
    verb_name: str
    verify_action: _VerifyAction
    must_exist: bool

def _verify_list_of_files(list_of_files_for_verification: Iterable[_FileForVerification], printer: IPrinter, filesystem: IFileSystem) -> None:
    file: _FileForVerification
    for file in list_of_files_for_verification:
        printer.write(f"  Verify '{file.filepath}' is {file.verb_name} - ")

        file_test: FileTest
        match file.verify_action:
            case _VerifyAction.READABLE:
                file_test = FileTest.READABLE
            case _VerifyAction.WRITABLE:
                file_test = FileTest.WRITABLE

        file_stat: FileStat = filesystem.probe_file(file.filepath, file_test)
        if file_stat.does_exist:
            if not file_stat.test_passed:
                msg = f"'{file.filepath}' is not {file.verb_name}"
                raise PerformPreUpdateSafetyCheckError(msg)
            printer.write('PASS')
        else:
            if file.must_exist:
                msg = f"'{file.filepath}' is missing when it is mandatory"
                raise PerformPreUpdateSafetyCheckError(msg)
            printer.write('PASS (missing)')
