# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import functools
import hashlib
import json
import time
from collections.abc import Iterable, Iterator, Sequence
from dataclasses import dataclass
from pathlib import PurePath
from typing import NamedTuple, TYPE_CHECKING
from milodb.client.config.update_config import UpdateConfig
from milodb.client.updater.i_temp_directory import ITempDirectory, TempDirectoryError
from milodb.client.updater.manifest.update_directory import IAsset, IAssetRegister
from milodb.client.updater.manifest.update_sequence_schema import DeleteFile, DeleteFilesAction, EmplaceFile, EmplaceFilesAction, MoveFile, MoveFilesAction, SetFileAttribute, SetFilesAttributeAction, UpdateSequenceSchema
from milodb.client.updater.manifest.version_manifest import ICoreFile
from milodb.client.updater.update_strategy import FileRename, UpdateStrategy
from milodb.client.util.file_system import IFileSystem
from milodb.client.view.progress_display import IProgressDisplay, ProgressDisplaySlice
from milodb.common.internet.i_scraper import IUrlScraper, IUrlScraperFactory
if TYPE_CHECKING:
    from milodb.common.internet.i_scraper import ScrapeResult

class PrepareUpdateError(Exception):
    pass

class UpdateReady(NamedTuple):
    temp_application_filepath: PurePath
    update_sequence_filepath: PurePath

@dataclass
class _AssetFile:
    core_file: ICoreFile
    asset: IAsset
    asset_url: str
    percentage_start: int
    percentage_end: int

def prepare_update(
        update_config: UpdateConfig,
        update_strategy: UpdateStrategy,
        time_stamp: time.struct_time,
        temp_directory: ITempDirectory,
        url_scraper_factory: IUrlScraperFactory,
        progress_display: IProgressDisplay,
        filesystem: IFileSystem) -> UpdateReady:
    """Prepare the update.

    This fetches the new assets, backs up the existing files, saves the update sequence and application, and returns the
    information necessary to start the update.

    ### Raises
    - PrepareUpdateError
    """
    download_progress_display: IProgressDisplay = ProgressDisplaySlice(progress_display, 0, 75)
    backup_progress_display: IProgressDisplay = ProgressDisplaySlice(progress_display, 75, 95)

    url_scraper: IUrlScraper
    with url_scraper_factory.new_pool(progress_display.normal_printer.writeln) as url_scraper:
        list_of_files_to_emplace: Sequence[ICoreFile] = fetch_assets_to_temp_directory(update_strategy, update_config.update_directory_url, temp_directory, url_scraper, download_progress_display)
    backup_files(update_strategy, update_config.backup_directory, time_stamp, backup_progress_display, filesystem)

    progress_display.set_activity_category('Finalise')
    progress_display.set_activity_text('Create update sequence')
    update_sequence: UpdateSequenceSchema = determine_update_sequence(update_strategy, temp_directory, list_of_files_to_emplace)
    update_sequence_filepath: PurePath = _save_update_sequence(update_sequence, temp_directory)
    progress_display.normal_printer.writeln(f"Update sequence written to '{update_sequence_filepath}'")
    progress_display.set_progress_percentage(97)

    progress_display.set_activity_text('Save application')
    temp_application_filepath: PurePath = _save_copy_of_application(update_strategy, temp_directory, filesystem)
    progress_display.normal_printer.writeln(f"Temporary application saved to '{temp_application_filepath}'")
    progress_display.set_progress_percentage(100)

    return UpdateReady(
        temp_application_filepath = temp_application_filepath,
        update_sequence_filepath = update_sequence_filepath,
    )

def fetch_assets_to_temp_directory(update_strategy: UpdateStrategy, directory_url: str, temp_directory: ITempDirectory, url_scraper: IUrlScraper, progress_display: IProgressDisplay) -> Sequence[ICoreFile]:
    """Fetch the new assets to the temporary directory.

    ### Raises
    - PrepareUpdateError
    """
    list_of_files_to_acquire: Sequence[ICoreFile] = (
        *update_strategy.core_file_changes.list_of_new_files_to_acquire,
        *update_strategy.core_file_changes.list_of_missing_files_to_acquire,
        *update_strategy.core_file_changes.list_of_changed_files_to_acquire,
    )

    progress_display.normal_printer.writeln(f"Downloading {len(list_of_files_to_acquire)} assets")

    if not list_of_files_to_acquire:
        return []

    progress_display.set_activity_category('Downloading')

    list_of_assets_to_acquire: Sequence[_AssetFile] = _resolve_assets_for_files(list_of_files_to_acquire, directory_url, update_strategy.asset_register)

    asset_file: _AssetFile
    for asset_file in list_of_assets_to_acquire:
        _fetch_asset(asset_file, temp_directory, url_scraper, progress_display)

    return list_of_files_to_acquire

def backup_files(update_strategy: UpdateStrategy, backup_directory: PurePath, time_stamp: time.struct_time, progress_display: IProgressDisplay, filesystem: IFileSystem) -> None:
    """Backup the files.

    ### Raises
    - PrepareUpdateError
    """
    list_of_files_to_backup: Sequence[PurePath] = (
        *update_strategy.backup_file_set.list_of_core_files_to_backup,
        *update_strategy.backup_file_set.list_of_config_files_to_backup,
        *update_strategy.backup_file_set.list_of_clobbered_files_to_backup,
    )

    zip_filename: str = (
        f'{time.strftime("%Y-%m-%d_%H-%M-%S", time_stamp)}'
        f'_{update_strategy.local_manifest.variant_name}_{update_strategy.local_manifest.version_number}.zip'
    )
    zip_filepath: PurePath = update_strategy.root_directory / backup_directory / zip_filename
    progress_display.normal_printer.writeln(f"Backing up files to '{zip_filepath}'")
    progress_display.set_activity_category('Backup')

    try:
        filesystem.create_directory_and_parents_if_needed(zip_filepath.parent)
    except OSError as ex:
        msg = f"Failed to create directory for backup file '{zip_filepath}': {ex}"
        raise PrepareUpdateError(msg) from ex

    def file_iterator() -> Iterator[tuple[PurePath, PurePath]]:
        index: int
        source_filename: PurePath
        for index, source_filename in enumerate(list_of_files_to_backup):
            source_path: PurePath = update_strategy.root_directory / source_filename
            if filesystem.probe_file(source_path).does_exist:
                progress_display.normal_printer.writeln(f"  Saving '{source_path}'")
                progress_display.set_activity_text(str(source_filename))
                yield source_path, source_filename
            else:
                progress_display.normal_printer.writeln(f"  Skipping '{source_path}'")
            progress_display.set_progress_percentage((index + 1) * 100 // len(list_of_files_to_backup))

    try:
        filesystem.write_zip_file(zip_filepath, file_iterator())
    except OSError as ex:
        raise PrepareUpdateError(ex) from ex

def determine_update_sequence(update_strategy: UpdateStrategy, temp_directory: ITempDirectory, list_of_files_to_emplace: Iterable[ICoreFile]) -> UpdateSequenceSchema:
    list_of_files_to_remove: Iterable[PurePath] = [
        file.filename for file in update_strategy.core_file_changes.list_of_changed_files_to_acquire
    ] + [
        *update_strategy.core_file_changes.list_of_files_that_are_deprecated,
        *update_strategy.config_file_changes.list_of_files_that_are_deprecated,
    ]

    update_sequence: UpdateSequenceSchema = UpdateSequenceSchema()

    update_sequence.field_root_directory.set(update_strategy.root_directory)
    update_sequence.field_temp_directory.set(temp_directory.path)

    delete_action: DeleteFilesAction = update_sequence.field_delete_files_actions.add_key(1)
    filename: PurePath
    for filename in list_of_files_to_remove:
        delete_item: DeleteFile = delete_action.add_item()
        delete_item.field_must_exist.set(False)
        delete_item.field_filename.set(filename)

    move_action: MoveFilesAction = update_sequence.field_move_files_actions.add_key(2)
    file_rename: FileRename
    for file_rename in update_strategy.config_file_changes.list_of_files_to_rename:
        move_item: MoveFile = move_action.add_item()
        move_item.field_must_exist.set(False)
        move_item.field_original_filename.set(file_rename.original_filename)
        move_item.field_new_filename.set(file_rename.new_filename)

    emplace_action: EmplaceFilesAction = update_sequence.field_emplace_files_actions.add_key(3)
    set_attributes_action: SetFilesAttributeAction = update_sequence.field_set_files_attribute_actions.add_key(4)
    core_file: ICoreFile
    for core_file in list_of_files_to_emplace:
        emplace_item: EmplaceFile = emplace_action.add_item()
        emplace_item.field_source_filename.set(PurePath(str(core_file.digest)))
        emplace_item.field_target_filename.set(core_file.filename)
        if core_file.exe:
            set_item: SetFileAttribute = set_attributes_action.field_files.add_item()
            set_item.field_filename.set(core_file.filename)
            set_item.field_is_executable.set(True)

    if update_strategy.launch_executable:
        update_sequence.field_launch_filename.set(update_strategy.launch_executable.filename)

    return update_sequence

def _resolve_assets_for_files(list_of_files: Iterable[ICoreFile], directory_url: str, asset_register: IAssetRegister) -> list[_AssetFile]:
    list_of_assets: list[_AssetFile] = []
    total_assets_size: int = 0

    core_file: ICoreFile
    for core_file in list_of_files:
        asset: IAsset | None = asset_register.assets.get(core_file.digest)
        asset_url: str | None = asset_register.resolve_asset_url(directory_url, core_file.digest)
        if not asset or not asset_url:
            msg = f"Asset '{core_file.digest}' for file '{core_file.filename}' is not in the asset register"
            raise PrepareUpdateError(msg)
        list_of_assets.append(_AssetFile(core_file, asset, asset_url, 0, 0))
        total_assets_size += asset.size

    current_asset_size: int = 0
    asset_file: _AssetFile
    for asset_file in list_of_assets:
        asset_file.percentage_start = current_asset_size * 100 // total_assets_size
        current_asset_size += asset_file.asset.size
        asset_file.percentage_end = current_asset_size * 100 // total_assets_size

    return list_of_assets

def _fetch_asset(asset_file: _AssetFile, temp_directory: ITempDirectory, url_scraper: IUrlScraper, progress_display: IProgressDisplay) -> None:
    progress_display.set_activity_text(str(asset_file.core_file.filename))
    progress_display.normal_printer.writeln(f"Fetching asset '{asset_file.core_file.digest}' for file '{asset_file.core_file.filename}'")

    def progress_callback(asset_file: _AssetFile, *, message: str | None, percentage_complete: int | None) -> None:
        if message:
            progress_display.normal_printer.writeln(message)
        if percentage_complete is not None:
            adjusted_percentage: int = asset_file.percentage_start + (asset_file.percentage_end - asset_file.percentage_start) * percentage_complete // 100
            progress_display.set_progress_percentage(adjusted_percentage)

    scrape_result: ScrapeResult = url_scraper.try_scrape_url(asset_file.asset_url, functools.partial(progress_callback, asset_file))
    if scrape_result.error_message:
        msg = f"Asset '{asset_file.core_file.digest}' for file '{asset_file.core_file.filename}' with URL '{asset_file.asset_url}' download error: {scrape_result.error_message}"
        raise PrepareUpdateError(msg)

    if len(scrape_result.content) != asset_file.asset.size:
        msg = f"Asset '{asset_file.core_file.digest}' for file '{asset_file.core_file.filename}' size mismatch: Expected {asset_file.asset.size:,} bytes, got {len(scrape_result.content):,} bytes"
        raise PrepareUpdateError(msg)

    actual_digest: bytes = hashlib.sha3_224(scrape_result.content).digest()
    if asset_file.core_file.digest.digest_bytes != actual_digest:
        msg = f"Asset '{asset_file.core_file.digest}' for file '{asset_file.core_file.filename}' integrity failure: Actual '{actual_digest.hex()}'"
        raise PrepareUpdateError(msg)

    try:
        temp_directory.store_file(str(asset_file.core_file.digest), scrape_result.content)
    except TempDirectoryError as ex:
        msg = f"Asset '{asset_file.core_file.digest}' for file '{asset_file.core_file.filename}' failed to store in temp directory: {ex}"
        raise PrepareUpdateError(msg) from ex

def _save_update_sequence(update_sequence: UpdateSequenceSchema, temp_directory: ITempDirectory) -> PurePath:
    json_text: str = json.dumps(update_sequence.save(), indent=4, ensure_ascii=False, sort_keys=True)
    target_filename: str = 'update_sequence.json'
    target_filepath: PurePath = temp_directory.path_of(target_filename)
    try:
        temp_directory.store_file(target_filename, json_text.encode())
    except TempDirectoryError as ex:
        msg = f"Failed to save update sequence to '{target_filepath}': {ex}"
        raise PrepareUpdateError(msg) from ex

    return target_filepath

def _save_copy_of_application(update_strategy: UpdateStrategy, temp_directory: ITempDirectory, filesystem: IFileSystem) -> PurePath:
    source_filepath: PurePath = update_strategy.root_directory/update_strategy.current_executable_filename
    target_filename: str = f'milodb-update-{update_strategy.current_executable_filename.name}'
    target_filepath: PurePath = temp_directory.path_of(target_filename)
    try:
        temp_directory.store_file(target_filename, filesystem.read_file_bytes(source_filepath), is_executable=True)
    except (TempDirectoryError, OSError) as ex:
        msg = f"Failed to save copy of application '{source_filepath}' to '{target_filepath}': {ex}"
        raise PrepareUpdateError(msg) from ex

    return target_filepath
