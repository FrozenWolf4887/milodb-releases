# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from abc import ABC, abstractmethod
from typing import override
from milodb.common.output.print.i_printer import IPrinter

class IProgressDisplay(ABC):
    @abstractmethod
    def set_subtitle_text(self, text: str) -> None:
        pass

    @abstractmethod
    def set_action_text(self, text: str) -> None:
        pass

    @abstractmethod
    def set_activity_category(self, text: str) -> None:
        pass

    @abstractmethod
    def set_activity_text(self, text: str) -> None:
        pass

    @abstractmethod
    def set_progress_percentage(self, percentage: int) -> None:
        pass

    @property
    @abstractmethod
    def normal_printer(self) -> IPrinter:
        pass

    @property
    @abstractmethod
    def warning_printer(self) -> IPrinter:
        pass

    @property
    @abstractmethod
    def error_printer(self) -> IPrinter:
        pass

    @abstractmethod
    def prompt_on_exit(self, *, show_log: bool=True) -> None:
        pass

    @abstractmethod
    def print_error_and_prompt_on_exit(self, message: str) -> None:
        pass

    @abstractmethod
    def print_warning_and_prompt_on_exit(self, message: str) -> None:
        pass

    @abstractmethod
    def print_fatal_and_prompt_on_exit(self, message: str) -> None:
        pass

class ProgressDisplaySlice(IProgressDisplay):
    def __init__(self, parent: IProgressDisplay, min_percentage: int, max_percentage: int) -> None:
        self._parent: IProgressDisplay = parent
        self._min_percentage: int = min_percentage
        self._max_percentage: int = max_percentage

    @override
    def set_subtitle_text(self, text: str) -> None:
        self._parent.set_subtitle_text(text)

    @override
    def set_action_text(self, text: str) -> None:
        self._parent.set_action_text(text)

    @override
    def set_activity_category(self, text: str) -> None:
        self._parent.set_activity_category(text)

    @override
    def set_activity_text(self, text: str) -> None:
        self._parent.set_activity_text(text)

    @override
    def set_progress_percentage(self, percentage: int) -> None:
        self._parent.set_progress_percentage(self._min_percentage + percentage * (self._max_percentage - self._min_percentage) // 100)

    @property
    @override
    def normal_printer(self) -> IPrinter:
        return self._parent.normal_printer

    @property
    @override
    def warning_printer(self) -> IPrinter:
        return self._parent.warning_printer

    @property
    @override
    def error_printer(self) -> IPrinter:
        return self._parent.error_printer

    @override
    def prompt_on_exit(self, *, show_log: bool=True) -> None:
        self._parent.prompt_on_exit(show_log=show_log)

    @override
    def print_error_and_prompt_on_exit(self, message: str) -> None:
        self._parent.print_error_and_prompt_on_exit(message)

    @override
    def print_warning_and_prompt_on_exit(self, message: str) -> None:
        self._parent.print_warning_and_prompt_on_exit(message)

    @override
    def print_fatal_and_prompt_on_exit(self, message: str) -> None:
        self._parent.print_fatal_and_prompt_on_exit(message)
