# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from __future__ import annotations
import functools
import time
import tkinter as tk
from enum import Enum
from tkinter import ttk
from typing import TYPE_CHECKING, override
from milodb.client.updater.i_temp_directory import ITempDirectory, ITempDirectoryCreator, TempDirectoryError
from milodb.client.updater.prepare_update import PrepareUpdateError, UpdateReady, prepare_update
from milodb.client.updater.start_update import try_start_update
from milodb.client.updater.update_potential import UpdatePotential
from milodb.client.updater.update_strategy import FileRename, UpdateStrategy, UpdateStrategyError, determine_update_strategy
from milodb.client.view.gui.dialogs.dialog import Dialog
from milodb.client.view.gui.dialogs.progress_dialog import ProgressDialog
from milodb.client.view.gui.dialogs.prompt_dialog import PromptDialog
from milodb.client.view.gui.theme import Style
from milodb.client.view.gui.util.enum_var import EnumVar
from milodb.client.view.gui.util.format_text import FormatMarkdownIntoText
from milodb.client.view.gui.util.tk_thread import run_tk_thread_routine
from milodb.client.view.gui.widgets.scrollable_frame import ScrollableFrame
from milodb.client.view.gui.widgets.styled_frame import StyledFrame
from milodb.client.view.gui.widgets.styled_text import StyledText
from milodb.client.view.gui.widgets.wrapping_label import WrappingLabel
from milodb.common.util.unit_size import UnitSizeText, unit_size
if TYPE_CHECKING:
    from collections.abc import Callable
    from pathlib import PurePath
    from milodb.client.config.update_config import UpdateConfig
    from milodb.client.updater.cached_remote_update_data import ICachedRemoteUpdateData, RemoteUpdateData
    from milodb.client.util.file_system import IFileSystem
    from milodb.client.updater.manifest.local_manifest import ILocalManifest
    from milodb.client.updater.manifest.update_directory import IAsset, IAssetRegister
    from milodb.client.updater.manifest.version_manifest import ICoreFile, IVersion, IVariant
    from milodb.client.view.progress_display import IProgressDisplay
    from milodb.common.internet.i_scraper import IUrlScraperFactory

_TABLE_GRIDLINE_THICKNESS: int = 1

_CANCEL_BUTTON_COLUMN: int = 0
_UPDATE_BUTTON_COLUMN: int = 1

def show_update_dialog(master: tk.Toplevel | tk.Tk, root_path: PurePath, update_config: UpdateConfig, local_manifest: ILocalManifest, cached_remote_update_data: ICachedRemoteUpdateData, filesystem: IFileSystem, url_scraper_factory: IUrlScraperFactory, temp_directory_creator: ITempDirectoryCreator, shutdown_app: Callable[[], None]) -> None:
    update_checker: _UpdateChecker = _UpdateChecker(root_path, update_config, local_manifest, cached_remote_update_data, filesystem, url_scraper_factory)
    update_preparer: _UpdatePreparer = _UpdatePreparer(update_config, url_scraper_factory, temp_directory_creator, filesystem)
    requested_variant_name: str | None = None
    while True:
        remote_update_data: RemoteUpdateData | None
        update_strategy: UpdateStrategy | None
        remote_update_data, update_strategy = update_checker.try_check_for_updates(master, requested_variant_name)
        if remote_update_data and update_strategy:
            update_dialog: _UpdateDialog = _UpdateDialog(master, update_config, local_manifest, remote_update_data, update_strategy, requested_variant_name)
            match update_dialog.wait_response():
                case _UpdateDialog.Response.CANCEL:
                    pass
                case _UpdateDialog.Response.UPDATE:
                    if update_preparer.try_prepare_update(master, update_strategy):
                        shutdown_app()
                case _UpdateDialog.Response.SWITCH_VARIANT:
                    requested_variant_name = update_dialog.requested_variant_name
                    continue
        break

class _UpdateChecker:
    def __init__(self, root_directory: PurePath, update_config: UpdateConfig, local_manifest: ILocalManifest, cached_remote_update_data: ICachedRemoteUpdateData, filesystem: IFileSystem, url_scraper_factory: IUrlScraperFactory) -> None:
        self._root_directory: PurePath = root_directory
        self._update_config: UpdateConfig = update_config
        self._local_manifest: ILocalManifest = local_manifest
        self._cached_remote_update_data: ICachedRemoteUpdateData = cached_remote_update_data
        self._filesystem: IFileSystem = filesystem
        self._url_scraper_factory: IUrlScraperFactory = url_scraper_factory

        self._remote_update_data: RemoteUpdateData | None = None
        self._update_strategy: UpdateStrategy | None = None

    def try_check_for_updates(self, master: tk.Toplevel | tk.Tk, requested_variant_name: str | None) -> tuple[RemoteUpdateData | None, UpdateStrategy | None]:
        with ProgressDialog(master) as progress_dialog:
            progress_dialog.set_action_text('Checking for updates')
            run_tk_thread_routine(lambda: self._thread_check_for_updates(progress_dialog, requested_variant_name), progress_dialog, 'Update check')
        return self._remote_update_data, self._update_strategy

    def _thread_check_for_updates(self, progress_display: IProgressDisplay, requested_variant_name: str | None) -> None:
        self._remote_update_data = self._cached_remote_update_data.try_get()
        if self._remote_update_data:
            progress_display.normal_printer.writeln('Reusing cached remote manifest')
        else:
            progress_display.set_activity_category('Fetching remote manifest')
            self._remote_update_data = self._cached_remote_update_data.fetch(self._update_config.update_directory_url, self._url_scraper_factory, progress_display)
            if not self._remote_update_data:
                progress_display.prompt_on_exit()
                return

        progress_display.set_progress_percentage(50)
        progress_display.set_activity_category('Analysing')
        progress_display.normal_printer.writeln('Analysing version and file changes')

        try:
            self._update_strategy = determine_update_strategy(self._root_directory, None, requested_variant_name, self._local_manifest, self._remote_update_data.version_manifest, self._remote_update_data.update_directory.asset_register, self._filesystem)
        except UpdateStrategyError as ex:
            progress_display.error_printer.writeln('Failed to determine update strategy')
            progress_display.normal_printer.writeln(f'Cause: {ex}')
            progress_display.prompt_on_exit()
        else:
            progress_display.set_progress_percentage(100)
            progress_display.set_activity_category('Done')

class _UpdatePreparer:
    def __init__(self, update_config: UpdateConfig, url_scraper_factory: IUrlScraperFactory, temp_directory_creator: ITempDirectoryCreator, filesystem: IFileSystem) -> None:
        self._update_config: UpdateConfig = update_config
        self._url_scraper_factory: IUrlScraperFactory = url_scraper_factory
        self._temp_directory_creator: ITempDirectoryCreator = temp_directory_creator
        self._filesystem: IFileSystem = filesystem

    def try_prepare_update(self, master: tk.Toplevel | tk.Tk, update_strategy: UpdateStrategy) -> bool:
        with ProgressDialog(master) as progress_dialog:
            progress_dialog.set_action_text('Preparing update')
            return run_tk_thread_routine(lambda: self._thread_prepare_update(progress_dialog, update_strategy), progress_dialog, '')

    def _thread_prepare_update(self, progress_display: IProgressDisplay, update_strategy: UpdateStrategy) -> bool:
        try:
            temp_directory: ITempDirectory = self._temp_directory_creator.create()
        except TempDirectoryError as ex:
            progress_display.print_error_and_prompt_on_exit(f'Failed to prepare update: {ex}')
            return False

        progress_display.normal_printer.writeln(f"Created update temp directory '{temp_directory.path}'")

        try:
            update_ready: UpdateReady = prepare_update(
                update_config = self._update_config,
                update_strategy = update_strategy,
                time_stamp = time.localtime(),
                temp_directory = temp_directory,
                url_scraper_factory = self._url_scraper_factory,
                progress_display = progress_display,
                filesystem = self._filesystem,
            )
        except PrepareUpdateError as ex:
            progress_display.print_error_and_prompt_on_exit(f'Failed to prepare update: {ex}')
            return False

        return try_start_update(update_ready, self._filesystem, progress_display)

class _UpdateDialog(Dialog):
    class Response(Enum):
        CANCEL = 0
        UPDATE = 1
        SWITCH_VARIANT = 2

    def __init__(self, master: tk.Toplevel | tk.Tk, update_config: UpdateConfig, local_manifest: ILocalManifest, remote_update_date: RemoteUpdateData, update_strategy: UpdateStrategy, requested_variant_name: str | None) -> None:
        super().__init__(master, width=640, height=480, title='Update', is_modal=True)

        self._update_config: UpdateConfig = update_config
        self._local_manifest: ILocalManifest = local_manifest
        self._remote_update_data: RemoteUpdateData = remote_update_date
        self._update_strategy: UpdateStrategy = update_strategy
        self._requested_variant_name: str | None = requested_variant_name

        self._notebook: ttk.Notebook = ttk.Notebook(self.content_frame)
        self._notebook.pack(fill=tk.BOTH, expand=True)
        self._update_status_label: ttk.Label = ttk.Label(self.content_frame, justify=tk.CENTER, anchor=tk.N)
        self._update_status_label.pack(fill=tk.X)

        self.add_button('Cancel', column=_CANCEL_BUTTON_COLUMN, command=self._on_cancel_button)
        self.add_button('Update', column=_UPDATE_BUTTON_COLUMN, command=self._on_update_button, is_hidden=True)

        self._changelog_frame: ScrollableFrame = ScrollableFrame(self._notebook)
        self._changelog_frame.top_frame.pack(fill=tk.BOTH, expand=True)
        self._changelog_tab_index: object = self._notebook.index(tk.END)
        self._notebook.add(self._changelog_frame.top_frame, text='Changes')

        self._analysis_frame: ScrollableFrame = ScrollableFrame(self._notebook)
        self._analysis_frame.top_frame.pack(fill=tk.BOTH, expand=True)
        self._analysis_tab_index: object = self._notebook.index(tk.END)
        self._notebook.add(self._analysis_frame.top_frame, text='Analysis', state=tk.HIDDEN)

        self._backup_frame: ScrollableFrame = ScrollableFrame(self._notebook)
        self._backup_frame.top_frame.pack(fill=tk.BOTH, expand=True)
        self._backup_tab_index: object = self._notebook.index(tk.END)
        self._notebook.add(self._backup_frame.top_frame, text='Backup', state=tk.HIDDEN)

        self._variants_frame: ScrollableFrame = ScrollableFrame(self._notebook)
        self._variants_frame.top_frame.pack(fill=tk.BOTH, expand=True)
        self._variants_tab_index: object = self._notebook.index(tk.END)
        self._notebook.add(self._variants_frame.top_frame, text='Variants')

        self._response_variable: EnumVar[_UpdateDialog.Response] = EnumVar(self, self.Response.CANCEL)

        self._init_variants_tab(self._local_manifest, self._remote_update_data)
        self._init_changelog_tab(self._update_strategy)

        update_potential: UpdatePotential = UpdatePotential(self._update_strategy)
        if update_potential.is_update_available:
            self._init_analysis_tab(self._update_strategy)
            self._init_backup_tab(self._update_strategy)
            self._notebook.select(tab_id=self._changelog_tab_index)
            self.show_button(_UPDATE_BUTTON_COLUMN)
            self._update_status_label.config(text=update_potential.message, style=Style.OnDialog.StatusLabel.Ready.STYLE_NAME)
        else:
            self._update_status_label.config(text=update_potential.message, style=Style.OnDialog.StatusLabel.Okay.STYLE_NAME)

        self.focus_button(_CANCEL_BUTTON_COLUMN)

    @override
    def destroy(self) -> None:
        super().destroy()

    def wait_response(self) -> Response:
        self.wait_window(self)
        return self._response_variable.get()

    @property
    def requested_variant_name(self) -> str | None:
        return self._requested_variant_name

    def _init_variants_tab(self, local_manifest: ILocalManifest, remote_update_data: RemoteUpdateData) -> None:
        table_frame: StyledFrame = StyledFrame(self._variants_frame.content_frame, style=Style.Generic.TableFrame.STYLE_NAME)
        table_frame.grid(row=0, column=0, sticky=tk.NSEW)
        self._variants_frame.content_frame.columnconfigure(0, weight=1)

        StyledFrame(table_frame, style=Style.InTable.CellFrame.STYLE_NAME).grid(row=0, column=0, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
        ttk.Label(table_frame, text='Variant Name', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.HeaderLabel.STYLE_NAME).grid(row=0, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
        ttk.Label(table_frame, text='Summary', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.HeaderLabel.STYLE_NAME).grid(row=0, column=2, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
        ttk.Label(table_frame, text='Status', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.HeaderLabel.STYLE_NAME).grid(row=0, column=3, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)

        row: int
        variant: IVariant
        for row, variant in enumerate(remote_update_data.version_manifest.variants.values()):
            StyledFrame(table_frame, style=Style.InTable.CellFrame.STYLE_NAME).grid(row=row+1, column=0, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            ttk.Label(table_frame, text=variant.name, anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row+1, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            WrappingLabel(table_frame, text=variant.summary, anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row+1, column=2, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            StyledFrame(table_frame, style=Style.InTable.CellFrame.STYLE_NAME).grid(row=row+1, column=3, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            if variant.name == local_manifest.variant_name:
                ttk.Label(table_frame, text='Current', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row+1, column=3, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
                if self._requested_variant_name is not None and self._requested_variant_name != local_manifest.variant_name:
                    ttk.Button(table_frame, text='Switch', command=functools.partial(self._on_switch_button_pressed, variant.name)).grid(row=row+1, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.EW)
            elif self._requested_variant_name is not None and variant.name == self._requested_variant_name:
                ttk.Label(table_frame, text='Selected', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row+1, column=3, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            else:
                ttk.Button(table_frame, text='Switch', command=functools.partial(self._on_switch_button_pressed, variant.name)).grid(row=row+1, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.EW)

        table_frame.columnconfigure(2, weight=1)
        self._variants_frame.set_child_bindtags_for_scrolling(max_depth=2)

    def _init_analysis_tab(self, update_strategy: UpdateStrategy) -> None: # pylint: disable=too-many-statements # noqa: PLR0915 Too many statements
        table_frame: StyledFrame = StyledFrame(self._analysis_frame.content_frame, style=Style.Generic.TableFrame.STYLE_NAME)
        table_frame.grid(row=0, column=0, sticky=tk.NSEW)
        self._analysis_frame.content_frame.columnconfigure(1, weight=1)

        ttk.Label(table_frame, text='Type', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.HeaderLabel.STYLE_NAME).grid(row=0, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
        ttk.Label(table_frame, text='File', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.HeaderLabel.STYLE_NAME).grid(row=0, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
        ttk.Label(table_frame, text='Status', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.HeaderLabel.STYLE_NAME).grid(row=0, column=2, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
        ttk.Label(table_frame, text='Action', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.HeaderLabel.STYLE_NAME).grid(row=0, column=3, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
        ttk.Label(table_frame, text='Size', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.HeaderLabel.STYLE_NAME).grid(row=0, column=4, columnspan=2, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)

        row: int = 1
        core_file: ICoreFile
        for core_file in update_strategy.core_file_changes.list_of_new_files_to_acquire:
            unit_text_size: UnitSizeText = _asset_file_size(core_file, update_strategy.asset_register)
            ttk.Label(table_frame, text='Core', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            ttk.Label(table_frame, text=str(core_file.filename), anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            ttk.Label(table_frame, text='New', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=2, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            ttk.Label(table_frame, text='Acquire', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=3, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            ttk.Label(table_frame, text=unit_text_size.size_text, anchor=tk.E, justify=tk.RIGHT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=4, padx=(_TABLE_GRIDLINE_THICKNESS, 0), pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            ttk.Label(table_frame, text=unit_text_size.unit_text, anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=5, padx=(0, _TABLE_GRIDLINE_THICKNESS), pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            row += 1

        for core_file in update_strategy.core_file_changes.list_of_changed_files_to_acquire:
            unit_text_size = _asset_file_size(core_file, update_strategy.asset_register)
            ttk.Label(table_frame, text='Core', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            ttk.Label(table_frame, text=str(core_file.filename), anchor=tk.NW, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            ttk.Label(table_frame, text='Changed', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=2, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            ttk.Label(table_frame, text='Acquire', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=3, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            ttk.Label(table_frame, text=unit_text_size.size_text, anchor=tk.E, justify=tk.RIGHT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=4, padx=(_TABLE_GRIDLINE_THICKNESS, 0), pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            ttk.Label(table_frame, text=unit_text_size.unit_text, anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=5, padx=(0, _TABLE_GRIDLINE_THICKNESS), pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            row += 1

        for core_file in update_strategy.core_file_changes.list_of_missing_files_to_acquire:
            unit_text_size = _asset_file_size(core_file, update_strategy.asset_register)
            ttk.Label(table_frame, text='Core', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            ttk.Label(table_frame, text=str(core_file.filename), anchor=tk.NW, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            ttk.Label(table_frame, text='Missing', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=2, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            ttk.Label(table_frame, text='Reacquire', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=3, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            ttk.Label(table_frame, text=unit_text_size.size_text, anchor=tk.E, justify=tk.RIGHT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=4, padx=(_TABLE_GRIDLINE_THICKNESS, 0), pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            ttk.Label(table_frame, text=unit_text_size.unit_text, anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=5, padx=(0, _TABLE_GRIDLINE_THICKNESS), pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            row += 1

        filename: PurePath
        for filename in update_strategy.core_file_changes.list_of_files_that_are_deprecated:
            ttk.Label(table_frame, text='Core', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            ttk.Label(table_frame, text=str(filename), anchor=tk.NW, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            ttk.Label(table_frame, text='Redundant', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=2, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            ttk.Label(table_frame, text='Delete', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=3, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            StyledFrame(table_frame, style=Style.InTable.CellFrame.STYLE_NAME).grid(row=row, column=4, columnspan=2, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            row += 1

        for core_file in update_strategy.core_file_changes.list_of_unchanged_files:
            ttk.Label(table_frame, text='Core', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            ttk.Label(table_frame, text=str(core_file.filename), anchor=tk.NW, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            ttk.Label(table_frame, text='Unchanged', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=2, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            ttk.Label(table_frame, text='None', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=3, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            StyledFrame(table_frame, style=Style.InTable.CellFrame.STYLE_NAME).grid(row=row, column=4, columnspan=2, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            row += 1

        file_rename: FileRename
        for file_rename in update_strategy.config_file_changes.list_of_files_to_rename:
            ttk.Label(table_frame, text='Config', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            ttk.Label(table_frame, text=str(file_rename.original_filename), anchor=tk.NW, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            ttk.Label(table_frame, text='Renamed', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=2, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            ttk.Label(table_frame, text=f'Rename to {file_rename.new_filename!s}', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=3, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            StyledFrame(table_frame, style=Style.InTable.CellFrame.STYLE_NAME).grid(row=row, column=4, columnspan=2, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            row += 1

        for filename in update_strategy.config_file_changes.list_of_files_that_are_deprecated:
            ttk.Label(table_frame, text='Config', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            ttk.Label(table_frame, text=str(filename), anchor=tk.NW, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            ttk.Label(table_frame, text='Redundant', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=2, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            ttk.Label(table_frame, text='Delete', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=3, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            StyledFrame(table_frame, style=Style.InTable.CellFrame.STYLE_NAME).grid(row=row, column=4, columnspan=2, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            row += 1

        for filename in update_strategy.config_file_changes.list_of_files_to_leave:
            ttk.Label(table_frame, text='Config', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            ttk.Label(table_frame, text=str(filename), anchor=tk.NW, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            ttk.Label(table_frame, text='Relevant', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=2, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            ttk.Label(table_frame, text='None', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=3, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            StyledFrame(table_frame, style=Style.InTable.CellFrame.STYLE_NAME).grid(row=row, column=4, columnspan=2, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            row += 1

        for filename in update_strategy.config_file_changes.list_of_new_files:
            ttk.Label(table_frame, text='Config', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            ttk.Label(table_frame, text=str(filename), anchor=tk.NW, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            ttk.Label(table_frame, text='New', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=2, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            ttk.Label(table_frame, text='None', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=3, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            StyledFrame(table_frame, style=Style.InTable.CellFrame.STYLE_NAME).grid(row=row, column=4, columnspan=2, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            row += 1

        self._analysis_frame.set_child_bindtags_for_scrolling(max_depth=2)
        self._notebook.add(self._analysis_frame.top_frame)

    def _init_backup_tab(self, update_strategy: UpdateStrategy) -> None:
        table_frame: StyledFrame = StyledFrame(self._backup_frame.content_frame, style=Style.Generic.TableFrame.STYLE_NAME)
        table_frame.grid(row=0, column=0, sticky=tk.NSEW)
        self._backup_frame.content_frame.columnconfigure(1, weight=1)

        ttk.Label(table_frame, text='Type', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.HeaderLabel.STYLE_NAME).grid(row=0, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
        ttk.Label(table_frame, text='File', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.HeaderLabel.STYLE_NAME).grid(row=0, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)

        row: int = 1
        filename: PurePath
        for filename in update_strategy.backup_file_set.list_of_core_files_to_backup:
            ttk.Label(table_frame, text='Core', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            ttk.Label(table_frame, text=str(filename), anchor=tk.NW, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            row += 1

        for filename in update_strategy.backup_file_set.list_of_config_files_to_backup:
            ttk.Label(table_frame, text='Config', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            ttk.Label(table_frame, text=str(filename), anchor=tk.NW, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            row += 1

        for filename in update_strategy.backup_file_set.list_of_clobbered_files_to_backup:
            ttk.Label(table_frame, text='Unknown', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            ttk.Label(table_frame, text=str(filename), anchor=tk.NW, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            row += 1

        self._backup_frame.set_child_bindtags_for_scrolling(max_depth=2)
        self._notebook.add(self._backup_frame.top_frame)

    def _init_changelog_tab(self, update_strategy: UpdateStrategy) -> None:
        table_frame: StyledFrame = StyledFrame(self._changelog_frame.content_frame, style=Style.Generic.TableFrame.STYLE_NAME)
        table_frame.grid(row=0, column=0, sticky=tk.NSEW)
        self._changelog_frame.content_frame.columnconfigure(0, weight=1)

        ttk.Label(table_frame, text='Version', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.HeaderLabel.STYLE_NAME).grid(row=0, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
        ttk.Label(table_frame, text='Date', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.HeaderLabel.STYLE_NAME).grid(row=0, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
        ttk.Label(table_frame, text='Changes', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.HeaderLabel.STYLE_NAME).grid(row=0, column=2, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)

        row: int = 1
        version: IVersion
        for version in sorted(update_strategy.list_of_newer_versions, key=lambda version: (version.date, version.number), reverse=True):
            ttk.Label(table_frame, text=str(version.number), anchor=tk.NW, justify=tk.LEFT, style=Style.InTable.NewValueLabel.STYLE_NAME).grid(row=row, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            ttk.Label(table_frame, text=str(version.date), anchor=tk.NW, justify=tk.LEFT, style=Style.InTable.NewValueLabel.STYLE_NAME).grid(row=row, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            log_text = StyledText(table_frame, line_count='dynamic', wrap=tk.WORD, style=Style.InTable.NewValueText.STYLE_NAME)
            log_text.grid(row=row, column=2, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            FormatMarkdownIntoText(version.log, log_text)
            row += 1

        for version in sorted(update_strategy.list_of_previous_versions, key=lambda version: (version.date, version.number), reverse=True):
            ttk.Label(table_frame, text=str(version.number), anchor=tk.NW, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            ttk.Label(table_frame, text=str(version.date), anchor=tk.NW, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            log_text = StyledText(table_frame, line_count='dynamic', wrap=tk.WORD, style=Style.InTable.ReadonlyText.STYLE_NAME)
            log_text.grid(row=row, column=2, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            FormatMarkdownIntoText(version.log, log_text)
            row += 1

        table_frame.columnconfigure(2, weight=1)
        self._changelog_frame.set_child_bindtags_for_scrolling(max_depth=2)

    def _on_cancel_button(self) -> None:
        self._response_variable.set(self.Response.CANCEL)
        self.destroy()

    def _on_update_button(self) -> None:
        if self._update_strategy.launch_executable is None:
            prompt: PromptDialog = PromptDialog(
                self,
                icon = PromptDialog.Icon.WARNING,
                title = 'Update Warning',
                headline_text = 'Unsupported target platform',
                detail_text = (
                    'There is no main executable for the current operating system in the chosen target variant / version.'
                    ' Following the update, the application will close and there can be no attempt to start the new application.'
                    ' This problem can occur if you upgrade to a variant or version that supports a different operating system.\n\n'
                    'Are you sure you want to continue?'
                ),
                buttons = PromptDialog.Buttons.YES_NO,
                height = 260,
            )
            if prompt.wait_response() != PromptDialog.Response.YES:
                return

        self._response_variable.set(self.Response.UPDATE)
        self.destroy()

    def _on_switch_button_pressed(self, variant_name: str) -> None:
        self._requested_variant_name = variant_name
        self._response_variable.set(self.Response.SWITCH_VARIANT)
        self.destroy()

def _asset_file_size(core_file: ICoreFile, asset_register: IAssetRegister) -> UnitSizeText:
    asset: IAsset | None = asset_register.assets.get(core_file.digest)
    if not asset:
        return UnitSizeText('unknown', '')
    return unit_size(asset.size)
