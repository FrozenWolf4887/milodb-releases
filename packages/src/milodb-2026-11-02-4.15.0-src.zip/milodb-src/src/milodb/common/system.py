# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import sys
from enum import Enum
from pathlib import Path
from typing import NamedTuple

IS_FROZEN_APP: bool = getattr(sys, 'frozen', False) and hasattr(sys, '_MEIPASS')
FROZEN_APP_PATH: Path = (
    Path(str(sys._MEIPASS)) if IS_FROZEN_APP  # type: ignore [attr-defined] # pylint: disable=protected-access # noqa: SLF001 Private member accessed # pyright: ignore[reportAttributeAccessIssue]
    else Path()
)

class PlatformName(NamedTuple):
    system_name: str
    friendly_name: str

class Platform(Enum):
    LINUX = PlatformName('linux', 'Linux')
    MACOS = PlatformName('darwin', 'MacOS')
    WINDOWS = PlatformName('win32', 'Windows')
    UNKNOWN = PlatformName('unknown', 'Unknown')

def _determine_platform() -> Platform:
    platform: Platform
    for platform in Platform:
        if platform.value.system_name == sys.platform:
            return platform
    return Platform.UNKNOWN

PLATFORM: Platform = _determine_platform()
