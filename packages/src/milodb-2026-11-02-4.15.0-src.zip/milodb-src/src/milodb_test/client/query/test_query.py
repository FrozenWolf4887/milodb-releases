# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import unittest
from collections.abc import Iterable, Sequence
from typing import TYPE_CHECKING, override
from milodb.client.database.author import Author, load_author
from milodb.client.database.tease import Tease, TeaseProperty, load_tease
from milodb.client.query.boolean_operator import And, Not, Or
from milodb.client.query.field_comparators import FieldStrContains, FieldTypeIs, FieldUnsignedFloatCompare
from milodb.client.query.field_match import FieldItemMatch, FieldMatch, FieldMatchIndices, FieldPageListMatch, FieldStrListMatch, WHOLE_FIELD_MATCH
from milodb.client.query.infix_query_parser import InfixError, InfixQueryParser, PostfixQuery
from milodb.client.query.postfix_query_executor import PostfixError, PostfixQueryResult, execute_postfix_query
from milodb.client.query.syntax import LIST_OF_FIELD_NAMES
from milodb.client.query.tease_match import TeaseMatch
from milodb.common.parser.arg import ArgumentError
from milodb.common.parser.candidate_text import CandidateText
from milodb.common.parser.token_stream import TokenStreamError
from milodb_test.client.test.mock_tokens import create_arg_token_stream, create_tokens_and_arg_token_stream
from milodb_test.common.parser.error_messages import ErrorMessage
if TYPE_CHECKING:
    from milodb.common.parser.arg_token_stream import ArgTokenStream
    from milodb.common.parser.token import Token

MAX_MATCH_COUNT: int = 1_000_000
BINARY_OPERATORS: Sequence[str] = ('and', 'or')
UNARY_OPERATORS: Sequence[str] = ('not',)
TEASE_TYPES: Sequence[str] = ('reg', 'aud', 'eos', 'nyx')

FAKE_THUMBNAIL: str = "https://media.milovana.com/timg/tb_s/73d0969cdbccbf0aa37a5dd2ac1c8962e53ff7a4.jpg"

AUTHOR_ID_1000: Author = load_author(
    1000, {
        "anm": "Miss Minogue",
    })

AUTHOR_ID_2345: Author = load_author(
    2345, {
        "anm": "Lewis",
    })

AUTHOR_ID_7602: Author = load_author(
    7602, {
        "anm": "Scott",
    })

TEASE_1: Tease = load_tease(
    4801,
    {
        "aid": 1000,
        "dat": "2019-04-27",
        "rvl": 4.2,
        "sum": "Our problems should be shared.",
        "tgs": ":wonder:wheels-for-feels:with:free:minky:",
        "thm": FAKE_THUMBNAIL,
        "ttl": "Confide in me",
        "pgs": [ {
            "ref": "chorus-start",
            "txt": "Stick or twist",
            }, {
            "ref": "line2",
            "txt": "What's mine is yours",
            }, {
            "ref": "line3",
            "txt": "Hit or miss",
            }, {
            "ref": "end",
            "txt": "We all have a cross to bear",
            },
        ],
        "typ": 2,
    }, {
        1000: AUTHOR_ID_1000,
    })

TEASE_2: Tease = load_tease(
    5673,
    {
        "aid": 2345,
        "dat": "2017-02-16",
        "rvl": 3.9,
        "sum": "Alice was beginning to get very tired of sitting by her sister on the bank, and of having nothing to do",
        "tgs": ":rabbit:hatter:alice:the-queen-of-hearts:",
        "thm": FAKE_THUMBNAIL,
        "ttl": "Alice's Adventures in Wonderland",
        "pgs": [ {
            "ref": "line1",
            "txt": "Alice was not a bit hurt, and she jumped up on to her feet in a moment",
            }, {
            "ref": "line2",
            "txt": "She looked up, but it was all dark overhead; before her was another long passage, and the White Rabbit was still in sight, hurrying down it.",
            }, {
            "ref": "line2",
            "txt": 'There was not a moment to be lost: away went Alice like the wind, and was just in time to hear it say, as it turned a corner, "Oh my ears and whiskers, how late it\'s getting!"',
            }, {
            "ref": "line3",
            "txt": "She was close behind it when she turned the corner, but the Rabbit was no longer to be seen",
            }, {
            "ref": "line4",
            "txt": "she found herself in a long, low hall, which was lit up by a row of lamps hanging from the roof.",
            },
        ],
        "typ": 0,
    }, {
        2345: AUTHOR_ID_2345,
    })

TEASE_3: Tease = load_tease(
    7129,
    {
        "aid": 7602,
        "dat": "2022-03-13",
        "rvl": 1.8,
        "sum": "In a dystopian world, what will become of us all?",
        "tgs": ":dystopia:orwellian:2022:",
        "thm": FAKE_THUMBNAIL,
        "ttl": "Twenty Twenty Two",
        "pgs": [ {
            "ref": "intro",
            "txt": "The Author of the Waverley Novels had hitherto proceeded in an unabated course of popularity, and might, in his peculiar district of literature, have been termed L'Enfant Gâté of success.",
            }, {
            "ref": "preface",
            "txt": "It was plain, however, that frequent publication must finally wear out the public favour, unless some mode could be devised to give an appearance of novelty to subsequent productions.",
            }, {
            "ref": "appendixA",
            "txt": "Scottish manners, Scottish dialect, and Scottish characters of note, being those with which the author was most intimately,",
            }, {
            "ref": "appendixB",
            "txt": "and familiarly acquainted, were the groundwork upon which he had hitherto relied for giving effect to his narrative.",
            },
        ],
        "typ": 1,
    }, {
        7602: AUTHOR_ID_7602,
    })

FAKE_LIST_OF_TEASES: Sequence[Tease] = (
    TEASE_1,
    TEASE_2,
    TEASE_3,
)

def is_equal_list_of_indices(left_list_indices: Iterable[FieldMatchIndices], right_list_of_indices: Iterable[FieldMatchIndices]) -> bool:
    left_indices: FieldMatchIndices
    for left_indices in left_list_indices:
        was_match_found: bool = False
        right_indices: FieldMatchIndices
        for right_indices in right_list_of_indices:
            was_match_found = left_indices.start_index == right_indices.start_index and left_indices.end_index == right_indices.end_index
            if was_match_found:
                break
        if not was_match_found:
            return False
    return True

def is_equal_field_item_match(left: FieldItemMatch, right: FieldItemMatch) -> bool:
    if left.tease_property == right.tease_property:
        return is_equal_list_of_indices(left.list_of_indices, right.list_of_indices)
    return False

def is_equal_field_list_match(left: FieldStrListMatch, right: FieldStrListMatch) -> bool:
    if left.tease_property == right.tease_property and left.index_of_block == right.index_of_block:
        return is_equal_list_of_indices(left.list_of_indices, right.list_of_indices)
    return False

def is_equal_field_page_list_match(left: FieldPageListMatch, right: FieldPageListMatch) -> bool:
    if left.page is right.page and left.index_of_page == right.index_of_page:
        return is_equal_list_of_indices(left.list_of_indices, right.list_of_indices)
    return False

def is_equal_tease_match(left: TeaseMatch, right: TeaseMatch) -> bool:
    if left.tease == right.tease and len(left.list_of_field_matches) == len(right.list_of_field_matches):
        left_field_match: FieldMatch
        for left_field_match in left.list_of_field_matches:
            was_match_found: bool = False
            right_field_match: FieldMatch
            for right_field_match in right.list_of_field_matches:
                if isinstance(left_field_match, FieldItemMatch) and isinstance(right_field_match, FieldItemMatch):
                    was_match_found = is_equal_field_item_match(left_field_match, right_field_match)
                elif isinstance(left_field_match, FieldStrListMatch) and isinstance(right_field_match, FieldStrListMatch):
                    was_match_found = is_equal_field_list_match(left_field_match, right_field_match)
                elif isinstance(left_field_match, FieldPageListMatch) and isinstance(right_field_match, FieldPageListMatch):
                    was_match_found = is_equal_field_page_list_match(left_field_match, right_field_match)
                if was_match_found:
                    break
            if not was_match_found:
                return False
        return True
    return False

class TestQueryPrecedence(unittest.TestCase):
    def test_simple_comparison(self) -> None:
        arg_token_stream: ArgTokenStream = create_arg_token_stream([
            "title",
            "contains",
            "Twenty",
        ])

        postfix: PostfixQuery = InfixQueryParser().convert_to_postfix(arg_token_stream)

        self.assertEqual(1, len(postfix.query_chain))
        self.assertIsInstance(postfix.query_chain[0], FieldStrContains)

    def test_and_operator(self) -> None:
        arg_token_stream: ArgTokenStream = create_arg_token_stream([
            "title",
            "contains",
            "Twenty",
            "and",
            "type",
            "is",
            "eos",
        ])

        postfix: PostfixQuery = InfixQueryParser().convert_to_postfix(arg_token_stream)

        self.assertEqual(3, len(postfix.query_chain))
        self.assertIsInstance(postfix.query_chain[0], FieldStrContains)
        self.assertIsInstance(postfix.query_chain[1], FieldTypeIs)
        self.assertIsInstance(postfix.query_chain[2], And)

    def test_or_operator(self) -> None:
        arg_token_stream: ArgTokenStream = create_arg_token_stream([
            "title",
            "contains",
            "Twenty",
            "or",
            "type",
            "is",
            "eos",
        ])

        postfix: PostfixQuery = InfixQueryParser().convert_to_postfix(arg_token_stream)

        self.assertEqual(3, len(postfix.query_chain))
        self.assertIsInstance(postfix.query_chain[0], FieldStrContains)
        self.assertIsInstance(postfix.query_chain[1], FieldTypeIs)
        self.assertIsInstance(postfix.query_chain[2], Or)

    def test_and_has_same_precendece_as_or(self) -> None:
        arg_token_stream: ArgTokenStream = create_arg_token_stream([
            "title",
            "contains",
            "Twenty",
            "or",
            "type",
            "is",
            "eos",
            "and",
            "rating",
            ">=",
            "4",
        ])

        postfix: PostfixQuery = InfixQueryParser().convert_to_postfix(arg_token_stream)

        self.assertEqual(5, len(postfix.query_chain))
        self.assertIsInstance(postfix.query_chain[0], FieldStrContains)
        self.assertIsInstance(postfix.query_chain[1], FieldTypeIs)
        self.assertIsInstance(postfix.query_chain[2], Or)
        self.assertIsInstance(postfix.query_chain[3], FieldUnsignedFloatCompare)
        self.assertIsInstance(postfix.query_chain[4], And)

    def test_or_has_same_precendece_as_and(self) -> None:
        arg_token_stream: ArgTokenStream = create_arg_token_stream([
            "title",
            "contains",
            "Twenty",
            "and",
            "type",
            "is",
            "eos",
            "or",
            "rating",
            ">=",
            "4",
        ])

        postfix: PostfixQuery = InfixQueryParser().convert_to_postfix(arg_token_stream)

        self.assertEqual(5, len(postfix.query_chain))
        self.assertIsInstance(postfix.query_chain[0], FieldStrContains)
        self.assertIsInstance(postfix.query_chain[1], FieldTypeIs)
        self.assertIsInstance(postfix.query_chain[2], And)
        self.assertIsInstance(postfix.query_chain[3], FieldUnsignedFloatCompare)
        self.assertIsInstance(postfix.query_chain[4], Or)

    def test_not_has_higher_precendece_than_and(self) -> None:
        arg_token_stream: ArgTokenStream = create_arg_token_stream([
            "not",
            "title",
            "contains",
            "Twenty",
            "and",
            "type",
            "is",
            "eos",
        ])

        postfix: PostfixQuery = InfixQueryParser().convert_to_postfix(arg_token_stream)

        self.assertEqual(4, len(postfix.query_chain))
        self.assertIsInstance(postfix.query_chain[0], FieldStrContains)
        self.assertIsInstance(postfix.query_chain[1], Not)
        self.assertIsInstance(postfix.query_chain[2], FieldTypeIs)
        self.assertIsInstance(postfix.query_chain[3], And)

    def test_not_has_higher_precendece_than_or(self) -> None:
        arg_token_stream: ArgTokenStream = create_arg_token_stream([
            "not",
            "title",
            "contains",
            "Twenty",
            "or",
            "type",
            "is",
            "eos",
        ])

        postfix: PostfixQuery = InfixQueryParser().convert_to_postfix(arg_token_stream)

        self.assertEqual(4, len(postfix.query_chain))
        self.assertIsInstance(postfix.query_chain[0], FieldStrContains)
        self.assertIsInstance(postfix.query_chain[1], Not)
        self.assertIsInstance(postfix.query_chain[2], FieldTypeIs)
        self.assertIsInstance(postfix.query_chain[3], Or)

    def test_parentheses_has_highest_precendece(self) -> None:
        arg_token_stream: ArgTokenStream = create_arg_token_stream([
            "title",
            "contains",
            "Twenty",
            "or",
            "(",
            "type",
            "is",
            "eos",
            "and",
            "rating",
            ">=",
            "4",
            ")",
        ])

        postfix: PostfixQuery = InfixQueryParser().convert_to_postfix(arg_token_stream)

        self.assertEqual(5, len(postfix.query_chain))
        self.assertIsInstance(postfix.query_chain[0], FieldStrContains)
        self.assertIsInstance(postfix.query_chain[1], FieldTypeIs)
        self.assertIsInstance(postfix.query_chain[2], FieldUnsignedFloatCompare)
        self.assertIsInstance(postfix.query_chain[3], And)
        self.assertIsInstance(postfix.query_chain[4], Or)

    def test_not_parentheses_has_highest_precendece_earlier(self) -> None:
        arg_token_stream: ArgTokenStream = create_arg_token_stream([
            "not",
            "(",
            "type",
            "is",
            "eos",
            "and",
            "rating",
            ">=",
            "4",
            ")",
            "or",
            "title",
            "contains",
            "Twenty",
        ])

        postfix: PostfixQuery = InfixQueryParser().convert_to_postfix(arg_token_stream)

        self.assertEqual(6, len(postfix.query_chain))
        self.assertIsInstance(postfix.query_chain[0], FieldTypeIs)
        self.assertIsInstance(postfix.query_chain[1], FieldUnsignedFloatCompare)
        self.assertIsInstance(postfix.query_chain[2], And)
        self.assertIsInstance(postfix.query_chain[3], Not)
        self.assertIsInstance(postfix.query_chain[4], FieldStrContains)
        self.assertIsInstance(postfix.query_chain[5], Or)

    def test_not_parentheses_has_highest_precendece_later(self) -> None:
        arg_token_stream: ArgTokenStream = create_arg_token_stream([
            "title",
            "contains",
            "Twenty",
            "or",
            "not",
            "(",
            "type",
            "is",
            "eos",
            "and",
            "rating",
            ">=",
            "4",
            ")",
        ])

        postfix: PostfixQuery = InfixQueryParser().convert_to_postfix(arg_token_stream)

        self.assertEqual(6, len(postfix.query_chain))
        self.assertIsInstance(postfix.query_chain[0], FieldStrContains)
        self.assertIsInstance(postfix.query_chain[1], FieldTypeIs)
        self.assertIsInstance(postfix.query_chain[2], FieldUnsignedFloatCompare)
        self.assertIsInstance(postfix.query_chain[3], And)
        self.assertIsInstance(postfix.query_chain[4], Not)
        self.assertIsInstance(postfix.query_chain[5], Or)

class TestQuery(unittest.TestCase):
    @override
    def setUp(self) -> None:
        self.postfix_query: PostfixQuery
        self.list_of_tokens: Sequence[Token] = []
        self.list_of_tease_matches: Sequence[TeaseMatch] = []
        self.exception: InfixError | ArgumentError | TokenStreamError | PostfixError | None = None

    def execute(self, list_of_token_text: Iterable[str]) -> None:
        arg_token_stream: ArgTokenStream
        self.list_of_tokens, arg_token_stream = create_tokens_and_arg_token_stream(list_of_token_text)
        try:
            self.postfix_query = InfixQueryParser().convert_to_postfix(arg_token_stream)
        except (InfixError, ArgumentError, TokenStreamError) as ex:
            self.exception = ex
            return
        try:
            result: PostfixQueryResult = execute_postfix_query(FAKE_LIST_OF_TEASES, self.postfix_query.query_chain, MAX_MATCH_COUNT)
        except PostfixError as ex:
            self.exception = ex
            return
        self.assertFalse(result.was_max_match_count_reached)
        self.list_of_tease_matches = result.list_of_tease_matches

    def assert_error(self, exception_type: type[InfixError | ArgumentError | TokenStreamError], error_message: str, error_token_index: int | None) -> None:
        self.assertIsInstance(self.exception, exception_type)
        if isinstance(self.exception, InfixError | ArgumentError):
            self.assertEqual(
                error_message, self.exception.message,
                f"Expected error message of '{error_message}' but got '{self.exception.message}'")
            if error_token_index is not None:
                error_token = self.list_of_tokens[error_token_index]
                self.assertIs(
                    error_token, self.exception.fault_token,
                    'Mismatched error token')
            else:
                self.assertIsNone(
                    self.exception.fault_token,
                    "Received an error token when one wasn't expected")
        elif isinstance(self.exception, TokenStreamError):
            self.assertEqual(
                error_message, self.exception.cause_of_fault_text,
                f"Expected error message of '{error_message}' but got '{self.exception.cause_of_fault_text}'")
            if error_token_index is not None:
                error_token = self.list_of_tokens[error_token_index]
                self.assertIs(
                    error_token, self.exception.fault_token,
                    'Mismatched error token')
            else:
                self.assertIsNone(
                    self.exception.fault_token,
                    "Received an error token when one wasn't expected")

    def assert_successful(self, expected_list_of_tease_matches: Sequence[TeaseMatch]) -> None:
        self.assertIsNone(self.exception)
        if self.exception is None:
            self.assertEqual(
                len(expected_list_of_tease_matches), len(self.list_of_tease_matches),
                f'Resulting tease match list expected to contain {len(expected_list_of_tease_matches)} entries but contains {len(self.list_of_tease_matches)}')

            expected_index: int
            expected_tease_match: TeaseMatch
            for expected_index, expected_tease_match in enumerate(expected_list_of_tease_matches):
                was_match_found: bool = False
                actual_tease_match: TeaseMatch
                for actual_tease_match in self.list_of_tease_matches:
                    was_match_found = is_equal_tease_match(expected_tease_match, actual_tease_match)
                    if was_match_found:
                        break
                if not was_match_found:
                    self.fail(f"No match for expected tease match #{expected_index}")
        else:
            self.fail('Conversion failed when it should have succeeded')

    def assert_candidate_text(self, *expected_lists_of_next_text: Iterable[str] | Iterable[CandidateText] | str | CandidateText| None) -> None:
        actual_list_of_candidate_text: Sequence[CandidateText]
        if isinstance(self.exception, PostfixError):
            actual_list_of_candidate_text = []
        elif self.exception is not None:
            actual_list_of_candidate_text = self.exception.list_of_candidate_text
        else:
            actual_list_of_candidate_text = self.postfix_query.list_of_candidate_text

        expected_list_of_candidate_text: Sequence[CandidateText] = _collect_lists_of_candidate_text(*expected_lists_of_next_text)

        actual_candidate_text_block: str = '\n'.join(str(candidate_text) for candidate_text in sorted(actual_list_of_candidate_text, key=lambda ct: ct.text)) + '\n'
        expected_candidate_text_block: str = '\n'.join(str(candidate_text) for candidate_text in sorted(expected_list_of_candidate_text, key=lambda ct: ct.text)) + '\n'
        self.assertEqual(expected_candidate_text_block, actual_candidate_text_block)

def _collect_lists_of_candidate_text(*lists_of_candidate_text: Iterable[str] | Iterable[CandidateText] | str | CandidateText | None) -> Sequence[CandidateText]:
    list_of_candidate_text: list[CandidateText] = []
    for arg in lists_of_candidate_text:
        if isinstance(arg, Iterable):
            item: str | CandidateText
            for item in arg:
                if isinstance(item, str):
                    list_of_candidate_text.append(CandidateText(item, '' if item in '()' else ' '))
                else:
                    list_of_candidate_text.append(item)
        elif isinstance(arg, str):
            list_of_candidate_text.append(CandidateText(arg, '' if arg in '()' else ' '))
        elif arg is not None:
            list_of_candidate_text.append(arg)
    return list_of_candidate_text

class TestInvalidInputs(TestQuery):
    def test_empty_input_yields_error(self) -> None:
        self.execute([])
        self.assert_error(InfixError, 'Unexpected end of input when expecting a query', None)

    def test_invalid_query_yields_error(self) -> None:
        self.execute(['mango'])
        self.assert_error(InfixError, 'Unknown field name or operator', 0)
        self.assert_candidate_text(LIST_OF_FIELD_NAMES, UNARY_OPERATORS, '(')

class TestTitle(TestQuery):
    FIELD: str = 'title'
    VERB_LIST: tuple[str, ...] = ('is', 'contains', 'matches')

    def test_fails_without_verb(self) -> None:
        self.execute([self.FIELD])
        self.assert_error(ArgumentError, ErrorMessage.INSUFFICIENT_EXPECTING_FIELD_VERB, None)
        self.assert_candidate_text(self.VERB_LIST)

class TestTitleIs(TestQuery):
    FIELD: str = 'title'
    VERB: str = 'is'

    def test_fails_without_argument(self) -> None:
        self.execute([self.FIELD, self.VERB])
        self.assert_error(ArgumentError, ErrorMessage.INSUFFICIENT_EXPECTING_PLAIN_TEXT, None)

    def test_matches_nothing(self) -> None:
        self.execute([self.FIELD, self.VERB, 'mango'])
        self.assert_successful([])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_matches_whole(self) -> None:
        self.execute([self.FIELD, self.VERB, 'confiDE in me'])
        matched_field_1: FieldMatch = FieldItemMatch(TeaseProperty.title, [FieldMatchIndices(0, 13)])
        matched_tease_1: TeaseMatch = TeaseMatch(None, TEASE_1, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_matches_plain_text_only(self) -> None:
        self.execute([self.FIELD, self.VERB, 'confiDE.in me'])
        self.assert_successful([])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_matches_whole_text_only(self) -> None:
        self.execute([self.FIELD, self.VERB, 'fide'])
        self.assert_successful([])
        self.assert_candidate_text(BINARY_OPERATORS)

class TestTitleContains(TestQuery):
    FIELD: str = 'title'
    VERB: str = 'contains'

    def test_fails_without_argument(self) -> None:
        self.execute([self.FIELD, self.VERB])
        self.assert_error(ArgumentError, ErrorMessage.INSUFFICIENT_EXPECTING_PLAIN_TEXT, None)

    def test_matches_nothing(self) -> None:
        self.execute([self.FIELD, self.VERB, 'mango'])
        self.assert_successful([])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_matches_part(self) -> None:
        self.execute([self.FIELD, self.VERB, 'fIDe'])
        matched_field_1: FieldMatch = FieldItemMatch(TeaseProperty.title, [FieldMatchIndices(3, 7)])
        matched_tease_1: TeaseMatch = TeaseMatch(None, TEASE_1, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_matches_multiple_parts(self) -> None:
        self.execute([self.FIELD, self.VERB, 'wen'])
        matched_field_1: FieldMatch = FieldItemMatch(TeaseProperty.title, [FieldMatchIndices(1, 4), FieldMatchIndices(8, 11)])
        matched_tease_1: TeaseMatch = TeaseMatch(None, TEASE_3, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_matches_plain_text_only(self) -> None:
        self.execute([self.FIELD, self.VERB, 'fi.e'])
        self.assert_successful([])
        self.assert_candidate_text(BINARY_OPERATORS)

class TestTitleMatches(TestQuery):
    FIELD: str = 'title'
    VERB: str = 'matches'

    def test_fails_without_argument(self) -> None:
        self.execute([self.FIELD, self.VERB])
        self.assert_error(ArgumentError, ErrorMessage.INSUFFICIENT_EXPECTING_REGEX, None)
        self.assert_candidate_text(None)

    def test_matches_nothing(self) -> None:
        self.execute([self.FIELD, self.VERB, 'mango'])
        self.assert_successful([])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_matches_part(self) -> None:
        self.execute([self.FIELD, self.VERB, 'fIDe'])
        matched_field_1: FieldMatch = FieldItemMatch(TeaseProperty.title, [FieldMatchIndices(3, 7)])
        matched_tease_1: TeaseMatch = TeaseMatch(None, TEASE_1, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_matches_regex(self) -> None:
        self.execute([self.FIELD, self.VERB, 'on.+in me'])
        matched_field_1: FieldMatch = FieldItemMatch(TeaseProperty.title, [FieldMatchIndices(1, 13)])
        matched_tease_1: TeaseMatch = TeaseMatch(None, TEASE_1, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_matches_multiple_regex(self) -> None:
        self.execute([self.FIELD, self.VERB, 't.+?ty'])
        matched_field_1: FieldMatch = FieldItemMatch(TeaseProperty.title, [FieldMatchIndices(0, 6), FieldMatchIndices(7, 13)])
        matched_tease_1: TeaseMatch = TeaseMatch(None, TEASE_3, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_fails_with_invalid_regex(self) -> None:
        self.execute([self.FIELD, self.VERB, 'on(in'])
        self.assert_error(ArgumentError, 'Invalid regular expression, missing ), unterminated subpattern at position 2', 2)
        self.assert_candidate_text(None)

class TestRating(TestQuery):
    FIELD: str = 'rating'
    VERB_LIST: tuple[str, ...] = ('=', '>', '<', '>=', '<=')

    def test_fails_without_verb(self) -> None:
        self.execute([self.FIELD])
        self.assert_error(ArgumentError, ErrorMessage.INSUFFICIENT_EXPECTING_FIELD_VERB, None)
        self.assert_candidate_text(self.VERB_LIST)

    def test_fails_without_argument(self) -> None:
        for verb in self.VERB_LIST:
            with self.subTest(verb=verb):
                self.execute([self.FIELD, verb])
                self.assert_error(ArgumentError, ErrorMessage.INSUFFICIENT_EXPECTING_UNSIGNED_DECIMAL, None)
                self.assert_candidate_text(None)

    def test_fails_with_non_float_argument(self) -> None:
        for verb in self.VERB_LIST:
            with self.subTest(verb=verb):
                self.execute([self.FIELD, verb, 'frog'])
                self.assert_error(ArgumentError, ErrorMessage.INVALID_EXPECTING_UNSIGNED_DECIMAL, 2)
                self.assert_candidate_text(None)

    def test_fails_with_negative_argument(self) -> None:
        for verb in self.VERB_LIST:
            with self.subTest(verb=verb):
                for value in ('-1', '-0.1'):
                    with self.subTest(value=value):
                        self.execute([self.FIELD, verb, value])
                        self.assert_error(ArgumentError, ErrorMessage.INVALID_EXPECTING_UNSIGNED_DECIMAL, 2)
                        self.assert_candidate_text(None)

    def test_gt_matches_nothing(self) -> None:
        self.execute([self.FIELD, '>', '4.2'])
        self.assert_successful([])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_gt_matches_one_item(self) -> None:
        self.execute([self.FIELD, '>', '3.9'])
        matched_field_1: FieldMatch = FieldItemMatch(TeaseProperty.rating, [WHOLE_FIELD_MATCH])
        matched_tease_1: TeaseMatch = TeaseMatch(None, TEASE_1, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_gt_matches_two_items(self) -> None:
        self.execute([self.FIELD, '>', '1.8'])
        matched_field_1: FieldMatch = FieldItemMatch(TeaseProperty.rating, [WHOLE_FIELD_MATCH])
        matched_tease_1: TeaseMatch = TeaseMatch(None, TEASE_1, [matched_field_1])
        matched_tease_2: TeaseMatch = TeaseMatch(None, TEASE_2, [matched_field_1])
        self.assert_successful([matched_tease_1, matched_tease_2])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_gt_matches_all_items(self) -> None:
        self.execute([self.FIELD, '>', '0'])
        matched_field_1: FieldMatch = FieldItemMatch(TeaseProperty.rating, [WHOLE_FIELD_MATCH])
        matched_tease_1: TeaseMatch = TeaseMatch(None, TEASE_1, [matched_field_1])
        matched_tease_2: TeaseMatch = TeaseMatch(None, TEASE_2, [matched_field_1])
        matched_tease_3: TeaseMatch = TeaseMatch(None, TEASE_3, [matched_field_1])
        self.assert_successful([matched_tease_1, matched_tease_2, matched_tease_3])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_ge_matches_nothing(self) -> None:
        self.execute([self.FIELD, '>=', '4.3'])
        self.assert_successful([])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_ge_matches_one_item(self) -> None:
        self.execute([self.FIELD, '>=', '4.2'])
        matched_field_1: FieldMatch = FieldItemMatch(TeaseProperty.rating, [WHOLE_FIELD_MATCH])
        matched_tease_1: TeaseMatch = TeaseMatch(None, TEASE_1, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_ge_matches_two_items(self) -> None:
        self.execute([self.FIELD, '>=', '3.9'])
        matched_field_1: FieldMatch = FieldItemMatch(TeaseProperty.rating, [WHOLE_FIELD_MATCH])
        matched_tease_1: TeaseMatch = TeaseMatch(None, TEASE_1, [matched_field_1])
        matched_tease_2: TeaseMatch = TeaseMatch(None, TEASE_2, [matched_field_1])
        self.assert_successful([matched_tease_1, matched_tease_2])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_ge_matches_all_items(self) -> None:
        self.execute([self.FIELD, '>=', '0'])
        matched_field_1: FieldMatch = FieldItemMatch(TeaseProperty.rating, [WHOLE_FIELD_MATCH])
        matched_tease_1: TeaseMatch = TeaseMatch(None, TEASE_1, [matched_field_1])
        matched_tease_2: TeaseMatch = TeaseMatch(None, TEASE_2, [matched_field_1])
        matched_tease_3: TeaseMatch = TeaseMatch(None, TEASE_3, [matched_field_1])
        self.assert_successful([matched_tease_1, matched_tease_2, matched_tease_3])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_lt_matches_nothing(self) -> None:
        self.execute([self.FIELD, '<', '1.8'])
        self.assert_successful([])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_lt_matches_one_item(self) -> None:
        self.execute([self.FIELD, '<', '3.9'])
        matched_field_1: FieldMatch = FieldItemMatch(TeaseProperty.rating, [WHOLE_FIELD_MATCH])
        matched_tease_1: TeaseMatch = TeaseMatch(None, TEASE_3, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_lt_matches_two_items(self) -> None:
        self.execute([self.FIELD, '<', '4.2'])
        matched_field_1: FieldMatch = FieldItemMatch(TeaseProperty.rating, [WHOLE_FIELD_MATCH])
        matched_tease_1: TeaseMatch = TeaseMatch(None, TEASE_2, [matched_field_1])
        matched_tease_2: TeaseMatch = TeaseMatch(None, TEASE_3, [matched_field_1])
        self.assert_successful([matched_tease_1, matched_tease_2])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_le_matches_nothing(self) -> None:
        self.execute([self.FIELD, '<=', '1.7'])
        self.assert_successful([])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_le_matches_one_item(self) -> None:
        self.execute([self.FIELD, '<=', '1.8'])
        matched_field_1: FieldMatch = FieldItemMatch(TeaseProperty.rating, [WHOLE_FIELD_MATCH])
        matched_tease_1: TeaseMatch = TeaseMatch(None, TEASE_3, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_le_matches_two_items(self) -> None:
        self.execute([self.FIELD, '<=', '3.9'])
        matched_field_1: FieldMatch = FieldItemMatch(TeaseProperty.rating, [WHOLE_FIELD_MATCH])
        matched_tease_1: TeaseMatch = TeaseMatch(None, TEASE_2, [matched_field_1])
        matched_tease_2: TeaseMatch = TeaseMatch(None, TEASE_3, [matched_field_1])
        self.assert_successful([matched_tease_1, matched_tease_2])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_eq_matches_nothing(self) -> None:
        self.execute([self.FIELD, '=', '3.1'])
        self.assert_successful([])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_eq_matches_one_item(self) -> None:
        self.execute([self.FIELD, '=', '3.9'])
        matched_field_1: FieldMatch = FieldItemMatch(TeaseProperty.rating, [WHOLE_FIELD_MATCH])
        matched_tease_1: TeaseMatch = TeaseMatch(None, TEASE_2, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_candidate_text(BINARY_OPERATORS)

class TestDate(TestQuery):
    FIELD: str = 'date'
    VERB_LIST: tuple[str, ...] = ('=', '>', '<', '>=', '<=')

    def test_fails_without_verb(self) -> None:
        self.execute([self.FIELD])
        self.assert_error(ArgumentError, ErrorMessage.INSUFFICIENT_EXPECTING_FIELD_VERB, None)
        self.assert_candidate_text(self.VERB_LIST)

    def test_fails_without_argument(self) -> None:
        for verb in self.VERB_LIST:
            with self.subTest(verb=verb):
                self.execute([self.FIELD, verb])
                self.assert_error(ArgumentError, ErrorMessage.INSUFFICIENT_EXPECTING_PARTIAL_DATE, None)
                self.assert_candidate_text(None)

    def test_fails_with_non_float_argument(self) -> None:
        for verb in self.VERB_LIST:
            with self.subTest(verb=verb):
                self.execute([self.FIELD, verb, 'frog'])
                self.assert_error(ArgumentError, ErrorMessage.INVALID_EXPECTING_PARTIAL_DATE, 2)
                self.assert_candidate_text(None)

    def test_gt_matches_nothing(self) -> None:
        self.execute([self.FIELD, '>', '2022-03-13'])
        self.assert_successful([])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_gt_matches_one_item(self) -> None:
        self.execute([self.FIELD, '>', '2022-03-12'])
        matched_field_1: FieldMatch = FieldItemMatch(TeaseProperty.date, [WHOLE_FIELD_MATCH])
        matched_tease_1: TeaseMatch = TeaseMatch(None, TEASE_3, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_gt_matches_two_items(self) -> None:
        self.execute([self.FIELD, '>', '2019-04-26'])
        matched_field_1: FieldMatch = FieldItemMatch(TeaseProperty.date, [WHOLE_FIELD_MATCH])
        matched_tease_1: TeaseMatch = TeaseMatch(None, TEASE_1, [matched_field_1])
        matched_tease_2: TeaseMatch = TeaseMatch(None, TEASE_3, [matched_field_1])
        self.assert_successful([matched_tease_1, matched_tease_2])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_ge_matches_nothing(self) -> None:
        self.execute([self.FIELD, '>=', '2022-03-14'])
        self.assert_successful([])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_ge_matches_one_item(self) -> None:
        self.execute([self.FIELD, '>=', '2022-03-13'])
        matched_field_1: FieldMatch = FieldItemMatch(TeaseProperty.date, [WHOLE_FIELD_MATCH])
        matched_tease_1: TeaseMatch = TeaseMatch(None, TEASE_3, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_ge_matches_two_items(self) -> None:
        self.execute([self.FIELD, '>=', '2019-04-27'])
        matched_field_1: FieldItemMatch = FieldItemMatch(TeaseProperty.date, [WHOLE_FIELD_MATCH])
        matched_tease_1: TeaseMatch = TeaseMatch(None, TEASE_1, [matched_field_1])
        matched_tease_2: TeaseMatch = TeaseMatch(None, TEASE_3, [matched_field_1])
        self.assert_successful([matched_tease_1, matched_tease_2])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_lt_matches_nothing(self) -> None:
        self.execute([self.FIELD, '<', '2017-02-16'])
        self.assert_successful([])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_lt_matches_one_item(self) -> None:
        self.execute([self.FIELD, '<', '2017-02-17'])
        matched_field_1: FieldMatch = FieldItemMatch(TeaseProperty.date, [WHOLE_FIELD_MATCH])
        matched_tease_1: TeaseMatch = TeaseMatch(None, TEASE_2, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_lt_matches_two_items(self) -> None:
        self.execute([self.FIELD, '<', '2019-04-28'])
        matched_field_1: FieldMatch = FieldItemMatch(TeaseProperty.date, [WHOLE_FIELD_MATCH])
        matched_tease_1: TeaseMatch = TeaseMatch(None, TEASE_2, [matched_field_1])
        matched_tease_2: TeaseMatch = TeaseMatch(None, TEASE_1, [matched_field_1])
        self.assert_successful([matched_tease_1, matched_tease_2])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_le_matches_nothing(self) -> None:
        self.execute([self.FIELD, '<=', '2017-02-15'])
        self.assert_successful([])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_le_matches_one_item(self) -> None:
        self.execute([self.FIELD, '<=', '2017-02-16'])
        matched_field_1: FieldMatch = FieldItemMatch(TeaseProperty.date, [WHOLE_FIELD_MATCH])
        matched_tease_1: TeaseMatch = TeaseMatch(None, TEASE_2, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_le_matches_two_items(self) -> None:
        self.execute([self.FIELD, '<=', '2019-04-27'])
        matched_field_1: FieldMatch = FieldItemMatch(TeaseProperty.date, [WHOLE_FIELD_MATCH])
        matched_tease_1: TeaseMatch = TeaseMatch(None, TEASE_2, [matched_field_1])
        matched_tease_2: TeaseMatch = TeaseMatch(None, TEASE_1, [matched_field_1])
        self.assert_successful([matched_tease_1, matched_tease_2])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_eq_matches_nothing(self) -> None:
        self.execute([self.FIELD, '=', '2018-07-02'])
        self.assert_successful([])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_eq_matches_one_item(self) -> None:
        self.execute([self.FIELD, '=', '2019-04-27'])
        matched_field_1: FieldMatch = FieldItemMatch(TeaseProperty.date, [WHOLE_FIELD_MATCH])
        matched_tease_1: TeaseMatch = TeaseMatch(None, TEASE_1, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_eq_matches_partial_date_by_year(self) -> None:
        self.execute([self.FIELD, '=', '2019'])
        matched_field_1: FieldMatch = FieldItemMatch(TeaseProperty.date, [WHOLE_FIELD_MATCH])
        matched_tease_1: TeaseMatch = TeaseMatch(None, TEASE_1, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_eq_matches_partial_date_by_month(self) -> None:
        self.execute([self.FIELD, '=', '2019-04'])
        matched_field_1: FieldMatch = FieldItemMatch(TeaseProperty.date, [WHOLE_FIELD_MATCH])
        matched_tease_1: TeaseMatch = TeaseMatch(None, TEASE_1, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_eq_doesnt_match_partial_date_by_year(self) -> None:
        self.execute([self.FIELD, '=', '2018'])
        self.assert_successful([])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_eq_doesnt_match_partial_date_by_month(self) -> None:
        self.execute([self.FIELD, '=', '2019-03'])
        self.assert_successful([])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_gt_matches_partial_date_by_year(self) -> None:
        self.execute([self.FIELD, '>', '2019'])
        matched_field_1: FieldMatch = FieldItemMatch(TeaseProperty.date, [WHOLE_FIELD_MATCH])
        matched_tease_1: TeaseMatch = TeaseMatch(None, TEASE_3, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_gt_matches_partial_date_by_month(self) -> None:
        self.execute([self.FIELD, '>', '2019-04'])
        matched_field_1: FieldMatch = FieldItemMatch(TeaseProperty.date, [WHOLE_FIELD_MATCH])
        matched_tease_1: TeaseMatch = TeaseMatch(None, TEASE_3, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_lt_matches_partial_date_by_year(self) -> None:
        self.execute([self.FIELD, '<', '2019'])
        matched_field_1: FieldMatch = FieldItemMatch(TeaseProperty.date, [WHOLE_FIELD_MATCH])
        matched_tease_1: TeaseMatch = TeaseMatch(None, TEASE_2, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_lt_matches_partial_date_by_month(self) -> None:
        self.execute([self.FIELD, '<', '2019-04'])
        matched_field_1: FieldMatch = FieldItemMatch(TeaseProperty.date, [WHOLE_FIELD_MATCH])
        matched_tease_1: TeaseMatch = TeaseMatch(None, TEASE_2, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_ge_matches_partial_date_by_year(self) -> None:
        self.execute([self.FIELD, '>=', '2019'])
        matched_field_1: FieldMatch = FieldItemMatch(TeaseProperty.date, [WHOLE_FIELD_MATCH])
        matched_tease_1: TeaseMatch = TeaseMatch(None, TEASE_1, [matched_field_1])
        matched_tease_2: TeaseMatch = TeaseMatch(None, TEASE_3, [matched_field_1])
        self.assert_successful([matched_tease_1, matched_tease_2])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_ge_matches_partial_date_by_month(self) -> None:
        self.execute([self.FIELD, '>=', '2019-04'])
        matched_field_1: FieldMatch = FieldItemMatch(TeaseProperty.date, [WHOLE_FIELD_MATCH])
        matched_tease_1: TeaseMatch = TeaseMatch(None, TEASE_1, [matched_field_1])
        matched_tease_2: TeaseMatch = TeaseMatch(None, TEASE_3, [matched_field_1])
        self.assert_successful([matched_tease_1, matched_tease_2])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_le_matches_partial_date_by_year(self) -> None:
        self.execute([self.FIELD, '<=', '2019'])
        matched_field_1: FieldMatch = FieldItemMatch(TeaseProperty.date, [WHOLE_FIELD_MATCH])
        matched_tease_1: TeaseMatch = TeaseMatch(None, TEASE_1, [matched_field_1])
        matched_tease_2: TeaseMatch = TeaseMatch(None, TEASE_2, [matched_field_1])
        self.assert_successful([matched_tease_1, matched_tease_2])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_le_matches_partial_date_by_month(self) -> None:
        self.execute([self.FIELD, '<=', '2019-04'])
        matched_field_1: FieldMatch = FieldItemMatch(TeaseProperty.date, [WHOLE_FIELD_MATCH])
        matched_tease_1: TeaseMatch = TeaseMatch(None, TEASE_1, [matched_field_1])
        matched_tease_2: TeaseMatch = TeaseMatch(None, TEASE_2, [matched_field_1])
        self.assert_successful([matched_tease_1, matched_tease_2])
        self.assert_candidate_text(BINARY_OPERATORS)

class TestTag(TestQuery):
    FIELD: str = 'tag'
    VERB_LIST: tuple[str, ...] = ('is', 'contains', 'matches')

    def test_fails_without_verb(self) -> None:
        self.execute([self.FIELD])
        self.assert_error(ArgumentError, ErrorMessage.INSUFFICIENT_EXPECTING_FIELD_VERB, None)
        self.assert_candidate_text(self.VERB_LIST)

class TestTagIs(TestQuery):
    FIELD: str = 'tag'
    VERB: str = 'is'

    def test_fails_without_argument(self) -> None:
        self.execute([self.FIELD, self.VERB])
        self.assert_error(ArgumentError, ErrorMessage.INSUFFICIENT_EXPECTING_PLAIN_TEXT, None)

    def test_matches_nothing(self) -> None:
        self.execute([self.FIELD, self.VERB, 'mango'])
        self.assert_successful([])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_matches_whole(self) -> None:
        self.execute([self.FIELD, self.VERB, 'Alice'])
        matched_field_1: FieldMatch = FieldStrListMatch(TeaseProperty.list_of_tags, [FieldMatchIndices(0, 5)], 2)
        matched_tease_1: TeaseMatch = TeaseMatch(None, TEASE_2, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_matches_plain_text_only(self) -> None:
        self.execute([self.FIELD, self.VERB, 'Al.ce'])
        self.assert_successful([])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_matches_whole_text_only(self) -> None:
        self.execute([self.FIELD, self.VERB, 'topia'])
        self.assert_successful([])
        self.assert_candidate_text(BINARY_OPERATORS)

class TestTagContains(TestQuery):
    FIELD: str = 'tag'
    VERB: str = 'contains'

    def test_fails_without_argument(self) -> None:
        self.execute([self.FIELD, self.VERB])
        self.assert_error(ArgumentError, ErrorMessage.INSUFFICIENT_EXPECTING_PLAIN_TEXT, None)

    def test_matches_nothing(self) -> None:
        self.execute([self.FIELD, self.VERB, 'mango'])
        self.assert_successful([])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_matches_part(self) -> None:
        self.execute([self.FIELD, self.VERB, 'abbi'])
        matched_field_1: FieldMatch = FieldStrListMatch(TeaseProperty.list_of_tags, [FieldMatchIndices(1, 5)], 0)
        matched_tease_1: TeaseMatch = TeaseMatch(None, TEASE_2, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_matches_multiple_part(self) -> None:
        self.execute([self.FIELD, self.VERB, 'ee'])
        matched_field_1: FieldMatch = FieldStrListMatch(TeaseProperty.list_of_tags, [FieldMatchIndices(2, 4), FieldMatchIndices(12, 14)], 1)
        matched_field_2: FieldMatch = FieldStrListMatch(TeaseProperty.list_of_tags, [FieldMatchIndices(2, 4)], 3)
        matched_field_3: FieldMatch = FieldStrListMatch(TeaseProperty.list_of_tags, [FieldMatchIndices(6, 8)], 3)
        matched_tease_1: TeaseMatch = TeaseMatch(None, TEASE_1, [matched_field_1, matched_field_2])
        matched_tease_2: TeaseMatch = TeaseMatch(None, TEASE_2, [matched_field_3])
        self.assert_successful([matched_tease_1, matched_tease_2])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_matches_plain_text_only(self) -> None:
        self.execute([self.FIELD, self.VERB, 'ali.e'])
        self.assert_successful([])
        self.assert_candidate_text(BINARY_OPERATORS)

class TestTagMatches(TestQuery):
    FIELD: str = 'tag'
    VERB: str = 'matches'

    def test_fails_without_argument(self) -> None:
        self.execute([self.FIELD, self.VERB])
        self.assert_error(ArgumentError, ErrorMessage.INSUFFICIENT_EXPECTING_REGEX, None)
        self.assert_candidate_text(None)

    def test_matches_nothing(self) -> None:
        self.execute([self.FIELD, self.VERB, 'mango'])
        self.assert_successful([])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_matches_part(self) -> None:
        self.execute([self.FIELD, self.VERB, 'fOR'])
        matched_field_1: FieldMatch = FieldStrListMatch(TeaseProperty.list_of_tags, [FieldMatchIndices(7, 10)], 1)
        matched_tease_1: TeaseMatch = TeaseMatch(None, TEASE_1, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_matches_regex(self) -> None:
        self.execute([self.FIELD, self.VERB, 'queen.+heart'])
        matched_field_1: FieldMatch = FieldStrListMatch(TeaseProperty.list_of_tags, [FieldMatchIndices(4, 18)], 3)
        matched_tease_1: TeaseMatch = TeaseMatch(None, TEASE_2, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_matches_multiple_regex(self) -> None:
        self.execute([self.FIELD, self.VERB, 'e{2}'])
        matched_field_1: FieldMatch = FieldStrListMatch(TeaseProperty.list_of_tags, [FieldMatchIndices(2, 4), FieldMatchIndices(12, 14)], 1)
        matched_field_2: FieldMatch = FieldStrListMatch(TeaseProperty.list_of_tags, [FieldMatchIndices(2, 4)], 3)
        matched_field_3: FieldMatch = FieldStrListMatch(TeaseProperty.list_of_tags, [FieldMatchIndices(6, 8)], 3)
        matched_tease_1: TeaseMatch = TeaseMatch(None, TEASE_1, [matched_field_1, matched_field_2])
        matched_tease_2: TeaseMatch = TeaseMatch(None, TEASE_2, [matched_field_3])
        self.assert_successful([matched_tease_1, matched_tease_2])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_fails_with_invalid_regex(self) -> None:
        self.execute([self.FIELD, self.VERB, 'on(in'])
        self.assert_error(ArgumentError, 'Invalid regular expression, missing ), unterminated subpattern at position 2', 2)
        self.assert_candidate_text(None)

class TestTypeIs(TestQuery):
    FIELD: str = 'type'
    VERB: str = 'is'

    def test_fails_without_argument(self) -> None:
        self.execute([self.FIELD, self.VERB])
        self.assert_error(ArgumentError, f'{ErrorMessage.INSUFFICIENT}, expecting TeaseType', None)
        self.assert_candidate_text(TEASE_TYPES)

    def test_fails_with_invalid_type(self) -> None:
        self.execute([self.FIELD, self.VERB, 'mango'])
        self.assert_error(ArgumentError, ErrorMessage.INVALID_EXPECTING_ENUM, 2)
        self.assert_candidate_text(TEASE_TYPES)

    def test_matches_entry(self) -> None:
        self.execute([self.FIELD, self.VERB, 'reg'])
        matched_field_1: FieldMatch = FieldItemMatch(TeaseProperty.tease_type, [WHOLE_FIELD_MATCH])
        matched_tease_1: TeaseMatch = TeaseMatch(None, TEASE_2, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_candidate_text(BINARY_OPERATORS)

class TestTextContains(TestQuery):
    FIELD: str = 'text'
    VERB: str = 'contains'

    def test_fails_without_argument(self) -> None:
        self.execute([self.FIELD, self.VERB])
        self.assert_error(ArgumentError, ErrorMessage.INSUFFICIENT_EXPECTING_PLAIN_TEXT, None)

    def test_matches_nothing(self) -> None:
        self.execute([self.FIELD, self.VERB, 'mango'])
        self.assert_successful([])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_matches_one_part_in_one_block_of_one_tease(self) -> None:
        self.execute([self.FIELD, self.VERB, 'herself'])
        matched_field_1: FieldMatch = FieldPageListMatch(TeaseProperty.list_of_pages, [FieldMatchIndices(10, 17)], TEASE_2.list_of_pages[4], 4)
        matched_tease_1: TeaseMatch = TeaseMatch(None, TEASE_2, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_matches_one_parts_in_multiple_blocks_of_one_tease(self) -> None:
        self.execute([self.FIELD, self.VERB, 'hitherto'])
        matched_field_1: FieldMatch = FieldPageListMatch(TeaseProperty.list_of_pages, [FieldMatchIndices(38, 46)], TEASE_3.list_of_pages[0], 0)
        matched_field_2: FieldMatch = FieldPageListMatch(TeaseProperty.list_of_pages, [FieldMatchIndices(65, 73)], TEASE_3.list_of_pages[3], 3)
        matched_tease_1: TeaseMatch = TeaseMatch(None, TEASE_3, [matched_field_1, matched_field_2])
        self.assert_successful([matched_tease_1])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_matches_multiple_parts_in_one_block_of_one_tease(self) -> None:
        self.execute([self.FIELD, self.VERB, 'public'])
        matched_field_1: FieldMatch = FieldPageListMatch(TeaseProperty.list_of_pages, [FieldMatchIndices(37, 43), FieldMatchIndices(75, 81)], TEASE_3.list_of_pages[1], 1)
        matched_tease_1: TeaseMatch = TeaseMatch(None, TEASE_3, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_matches_one_part_in_one_block_of_multiple_teases(self) -> None:
        self.execute([self.FIELD, self.VERB, 'have'])
        matched_field_1: FieldMatch = FieldPageListMatch(TeaseProperty.list_of_pages, [FieldMatchIndices(7, 11)], TEASE_1.list_of_pages[3], 3)
        matched_field_2: FieldMatch = FieldPageListMatch(TeaseProperty.list_of_pages, [FieldMatchIndices(145, 149)], TEASE_3.list_of_pages[0], 0)
        matched_tease_1: TeaseMatch = TeaseMatch(None, TEASE_1, [matched_field_1])
        matched_tease_2: TeaseMatch = TeaseMatch(None, TEASE_3, [matched_field_2])
        self.assert_successful([matched_tease_1, matched_tease_2])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_matches_one_part_in_some_blocks_of_multiple_teases(self) -> None:
        self.execute([self.FIELD, self.VERB, 'which'])
        matched_field_1: FieldMatch = FieldPageListMatch(TeaseProperty.list_of_pages, [FieldMatchIndices(39, 44)], TEASE_2.list_of_pages[4], 4)
        matched_field_2: FieldMatch = FieldPageListMatch(TeaseProperty.list_of_pages, [FieldMatchIndices(86, 91)], TEASE_3.list_of_pages[2], 2)
        matched_field_3: FieldMatch = FieldPageListMatch(TeaseProperty.list_of_pages, [FieldMatchIndices(52, 57)], TEASE_3.list_of_pages[3], 3)
        matched_tease_1: TeaseMatch = TeaseMatch(None, TEASE_2, [matched_field_1])
        matched_tease_2: TeaseMatch = TeaseMatch(None, TEASE_3, [matched_field_2, matched_field_3])
        self.assert_successful([matched_tease_1, matched_tease_2])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_matches_regardless_of_case(self) -> None:
        self.execute([self.FIELD, self.VERB, 'auTHor'])
        matched_field_1: FieldMatch = FieldPageListMatch(TeaseProperty.list_of_pages, [FieldMatchIndices(4, 10)], TEASE_3.list_of_pages[0], 0)
        matched_field_2: FieldMatch = FieldPageListMatch(TeaseProperty.list_of_pages, [FieldMatchIndices(96, 102)], TEASE_3.list_of_pages[2], 2)
        matched_tease_1: TeaseMatch = TeaseMatch(None, TEASE_3, [matched_field_1, matched_field_2])
        self.assert_successful([matched_tease_1])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_matches_plain_text_only(self) -> None:
        self.execute([self.FIELD, self.VERB, 'pub.ic'])
        self.assert_successful([])
        self.assert_candidate_text(BINARY_OPERATORS)

class TestTextMatches(TestQuery):
    FIELD: str = 'text'
    VERB: str = 'matches'

    def test_fails_without_argument(self) -> None:
        self.execute([self.FIELD, self.VERB])
        self.assert_error(ArgumentError, ErrorMessage.INSUFFICIENT_EXPECTING_REGEX, None)

    def test_matches_nothing(self) -> None:
        self.execute([self.FIELD, self.VERB, 'mango'])
        self.assert_successful([])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_matches_one_part_in_one_block_of_one_tease(self) -> None:
        self.execute([self.FIELD, self.VERB, 'her.elf'])
        matched_field_1: FieldMatch = FieldPageListMatch(TeaseProperty.list_of_pages, [FieldMatchIndices(10, 17)], TEASE_2.list_of_pages[4], 4)
        matched_tease_1: TeaseMatch = TeaseMatch(None, TEASE_2, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_matches_one_parts_in_multiple_blocks_of_one_tease(self) -> None:
        self.execute([self.FIELD, self.VERB, 'hi[th]{2}erto'])
        matched_field_1: FieldMatch = FieldPageListMatch(TeaseProperty.list_of_pages, [FieldMatchIndices(38, 46)], TEASE_3.list_of_pages[0], 0)
        matched_field_2: FieldMatch = FieldPageListMatch(TeaseProperty.list_of_pages, [FieldMatchIndices(65, 73)], TEASE_3.list_of_pages[3], 3)
        matched_tease_1: TeaseMatch = TeaseMatch(None, TEASE_3, [matched_field_1, matched_field_2])
        self.assert_successful([matched_tease_1])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_matches_multiple_parts_in_one_block_of_one_tease(self) -> None:
        self.execute([self.FIELD, self.VERB, 'p[a-z]blic'])
        matched_field_1: FieldMatch = FieldPageListMatch(TeaseProperty.list_of_pages, [FieldMatchIndices(37, 43), FieldMatchIndices(75, 81)], TEASE_3.list_of_pages[1], 1)
        matched_tease_1: TeaseMatch = TeaseMatch(None, TEASE_3, [matched_field_1])
        self.assert_successful([matched_tease_1])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_matches_one_part_in_one_block_of_multiple_teases(self) -> None:
        self.execute([self.FIELD, self.VERB, 'ha[^z]e'])
        matched_field_1: FieldMatch = FieldPageListMatch(TeaseProperty.list_of_pages, [FieldMatchIndices(7, 11)], TEASE_1.list_of_pages[3], 3)
        matched_field_2: FieldMatch = FieldPageListMatch(TeaseProperty.list_of_pages, [FieldMatchIndices(145, 149)], TEASE_3.list_of_pages[0], 0)
        matched_tease_1: TeaseMatch = TeaseMatch(None, TEASE_1, [matched_field_1])
        matched_tease_2: TeaseMatch = TeaseMatch(None, TEASE_3, [matched_field_2])
        self.assert_successful([matched_tease_1, matched_tease_2])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_matches_one_part_in_some_blocks_of_multiple_teases(self) -> None:
        self.execute([self.FIELD, self.VERB, 'which|witch'])
        matched_field_1: FieldMatch = FieldPageListMatch(TeaseProperty.list_of_pages, [FieldMatchIndices(39, 44)], TEASE_2.list_of_pages[4], 4)
        matched_field_2: FieldMatch = FieldPageListMatch(TeaseProperty.list_of_pages, [FieldMatchIndices(86, 91)], TEASE_3.list_of_pages[2], 2)
        matched_field_3: FieldMatch = FieldPageListMatch(TeaseProperty.list_of_pages, [FieldMatchIndices(52, 57)], TEASE_3.list_of_pages[3], 3)
        matched_tease_1: TeaseMatch = TeaseMatch(None, TEASE_2, [matched_field_1])
        matched_tease_2: TeaseMatch = TeaseMatch(None, TEASE_3, [matched_field_2, matched_field_3])
        self.assert_successful([matched_tease_1, matched_tease_2])
        self.assert_candidate_text(BINARY_OPERATORS)

    def test_matches_regardless_of_case(self) -> None:
        self.execute([self.FIELD, self.VERB, 'auTHo[A-Z]'])
        matched_field_1: FieldMatch = FieldPageListMatch(TeaseProperty.list_of_pages, [FieldMatchIndices(4, 10)], TEASE_3.list_of_pages[0], 0)
        matched_field_2: FieldMatch = FieldPageListMatch(TeaseProperty.list_of_pages, [FieldMatchIndices(96, 102)], TEASE_3.list_of_pages[2], 2)
        matched_tease_1: TeaseMatch = TeaseMatch(None, TEASE_3, [matched_field_1, matched_field_2])
        self.assert_successful([matched_tease_1])
        self.assert_candidate_text(BINARY_OPERATORS)

class TestAndOperator(TestQuery):
    def test_matches_one_part_in_some_blocks_of_multiple_teases(self) -> None:
        self.execute(['text', 'contains', 'which', 'and', 'teaseId', '=', '5673'])
        matched_field_1: FieldMatch = FieldItemMatch(TeaseProperty.tease_id, [WHOLE_FIELD_MATCH])
        matched_field_2: FieldMatch = FieldPageListMatch(TeaseProperty.list_of_pages, [FieldMatchIndices(39, 44)], TEASE_2.list_of_pages[4], 4)
        matched_tease_1: TeaseMatch = TeaseMatch(None, TEASE_2, [matched_field_1, matched_field_2])
        self.assert_successful([matched_tease_1])
        self.assert_candidate_text(BINARY_OPERATORS)
