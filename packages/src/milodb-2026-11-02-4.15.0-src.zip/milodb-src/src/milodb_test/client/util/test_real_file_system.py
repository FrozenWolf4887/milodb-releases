# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import unittest
from pathlib import PurePath
from typing import TYPE_CHECKING
from zipfile import ZipFile
from milodb.client.util.file_system import FileTest
from milodb.client.util.real_file_system import RealFileSystem
from milodb.common.system import PLATFORM, Platform
from milodb_test.client.test.fake_data import FAKE_DATA_A, FAKE_DATA_B, FAKE_DATA_C, FAKE_DATA_D, FAKE_DIGEST_BYTES_A, FAKE_DIGEST_BYTES_B
from milodb_test.client.test.test_directory import FakeFile, TestDirectory
if TYPE_CHECKING:
    from milodb.client.util.file_system import DirStat, FileStat, IFileSystem

class TestProbeFile(unittest.TestCase):
    def test_probe_readable_missing_file(self) -> None:
        with TestDirectory(self) as root_dir:
            file_stat: FileStat = RealFileSystem().probe_file(root_dir.path / 'not-a-file')

            self.assertEqual(root_dir.path / 'not-a-file', file_stat.path, FileTest.READABLE)
            self.assertFalse(file_stat.does_exist)
            self.assertFalse(file_stat.is_file)
            self.assertFalse(file_stat.test_passed)

            root_dir.assert_empty()

    def test_probe_readable_existing_file(self) -> None:
        with TestDirectory(self) as root_dir:
            file = FakeFile(root_dir, 'a-file', FAKE_DATA_A)

            file_stat: FileStat = RealFileSystem().probe_file(file.filepath, FileTest.READABLE)

            self.assertEqual(file.filepath, file_stat.path)
            self.assertTrue(file_stat.does_exist)
            self.assertTrue(file_stat.is_file)
            self.assertTrue(file_stat.test_passed)

            root_dir.assert_contains([
                file,
            ], [
            ])
            root_dir.assert_file_exists(file, FAKE_DATA_A)

    def test_probe_readable_existing_non_writeable_file(self) -> None:
        with TestDirectory(self) as root_dir:
            file = FakeFile(root_dir, 'a-file', FAKE_DATA_A, is_writeable=False)

            file_stat: FileStat = RealFileSystem().probe_file(file.filepath, FileTest.READABLE)

            self.assertEqual(file.filepath, file_stat.path)
            self.assertTrue(file_stat.does_exist)
            self.assertTrue(file_stat.is_file)
            self.assertTrue(file_stat.test_passed)

            root_dir.assert_contains([
                file,
            ], [
            ])
            root_dir.assert_file_exists(file, FAKE_DATA_A, is_writeable=False)

    def test_probe_readable_existing_non_readable_file(self) -> None:
        if PLATFORM is Platform.WINDOWS:
            return # Files cannot be set as non-readable on Windows

        with TestDirectory(self) as root_dir:
            file = FakeFile(root_dir, 'a-file', FAKE_DATA_A, is_readable=False)

            file_stat: FileStat = RealFileSystem().probe_file(file.filepath, FileTest.READABLE)

            self.assertEqual(file.filepath, file_stat.path)
            self.assertTrue(file_stat.does_exist)
            self.assertTrue(file_stat.is_file)
            self.assertFalse(file_stat.test_passed)

            root_dir.assert_contains([
                file,
            ], [
            ])
            root_dir.assert_file_exists(file, FAKE_DATA_A, is_readable=False)

    def test_probe_readable_existing_directory(self) -> None:
        with TestDirectory(self) as root_dir:
            directory: PurePath = root_dir.create_subdirectory('a-dir')

            file_stat: FileStat = RealFileSystem().probe_file(directory, FileTest.READABLE)

            self.assertEqual(directory, file_stat.path)
            self.assertTrue(file_stat.does_exist)
            self.assertFalse(file_stat.is_file)
            self.assertFalse(file_stat.test_passed)

            root_dir.assert_contains([
            ], [
                directory,
            ])

    def test_probe_writable_missing_file(self) -> None:
        with TestDirectory(self) as root_dir:
            file_stat: FileStat = RealFileSystem().probe_file(root_dir.path / 'not-a-file', FileTest.WRITABLE)

            self.assertEqual(root_dir.path / 'not-a-file', file_stat.path)
            self.assertFalse(file_stat.does_exist)
            self.assertFalse(file_stat.is_file)
            self.assertTrue(file_stat.test_passed)

            root_dir.assert_empty()

    def test_probe_writeable_existing_file(self) -> None:
        with TestDirectory(self) as root_dir:
            file = FakeFile(root_dir, 'a-file', FAKE_DATA_A)

            file_stat: FileStat = RealFileSystem().probe_file(file.filepath, FileTest.WRITABLE)

            self.assertEqual(file.filepath, file_stat.path)
            self.assertTrue(file_stat.does_exist)
            self.assertTrue(file_stat.is_file)
            self.assertTrue(file_stat.test_passed)

            root_dir.assert_contains([
                file,
            ], [
            ])
            root_dir.assert_file_exists(file, FAKE_DATA_A)

    def test_probe_writeable_existing_non_writeable_file_makes_writeable(self) -> None:
        with TestDirectory(self) as root_dir:
            file = FakeFile(root_dir, 'a-file', FAKE_DATA_A, is_writeable=False)

            file_stat: FileStat = RealFileSystem().probe_file(file.filepath, FileTest.WRITABLE)

            self.assertEqual(file.filepath, file_stat.path)
            self.assertTrue(file_stat.does_exist)
            self.assertTrue(file_stat.is_file)
            self.assertTrue(file_stat.test_passed)

            root_dir.assert_contains([
                file,
            ], [
            ])
            root_dir.assert_file_exists(file, FAKE_DATA_A, is_writeable=True)

    def test_probe_writeable_existing_non_readable_file(self) -> None:
        if PLATFORM is Platform.WINDOWS:
            return # Files cannot be set as non-readable on Windows

        with TestDirectory(self) as root_dir:
            file = FakeFile(root_dir, 'a-file', FAKE_DATA_A, is_readable=False)

            file_stat: FileStat = RealFileSystem().probe_file(file.filepath, FileTest.READABLE)

            self.assertEqual(file.filepath, file_stat.path)
            self.assertTrue(file_stat.does_exist)
            self.assertTrue(file_stat.is_file)
            self.assertFalse(file_stat.test_passed)

            root_dir.assert_contains([
                file,
            ], [
            ])
            root_dir.assert_file_exists(file, FAKE_DATA_A, is_readable=False)

class TestProbeDirectory(unittest.TestCase):
    def test_probe_missing_directory_does_not_raise(self) -> None:
        with TestDirectory(self) as root_dir:
            dir_stat: DirStat = RealFileSystem().probe_directory(root_dir.path / 'not-a-directory')

            self.assertEqual(root_dir.path / 'not-a-directory', dir_stat.path)
            self.assertFalse(dir_stat.does_exist)
            self.assertTrue(dir_stat.is_empty)

    def test_probe_existing_empty_directory(self) -> None:
        with TestDirectory(self) as root_dir:
            directory = root_dir.create_subdirectory('a-dir')

            dir_stat: DirStat = RealFileSystem().probe_directory(directory)

            self.assertEqual(directory, dir_stat.path)
            self.assertTrue(dir_stat.does_exist)
            self.assertTrue(dir_stat.is_empty)

    def test_probe_existing_directory_with_content(self) -> None:
        with TestDirectory(self) as root_dir:
            directory: PurePath = root_dir.create_subdirectory('a-dir')
            FakeFile(root_dir, PurePath(directory.name) / 'something', 8)

            dir_stat: DirStat = RealFileSystem().probe_directory(directory)

            self.assertEqual(directory, dir_stat.path)
            self.assertTrue(dir_stat.does_exist)
            self.assertFalse(dir_stat.is_empty)

    def test_probe_existing_file(self) -> None:
        with TestDirectory(self) as root_dir:
            file = FakeFile(root_dir, 'a-file', 8)

            dir_stat: DirStat = RealFileSystem().probe_directory(file.filepath)

            self.assertEqual(file.filepath, dir_stat.path)
            self.assertFalse(dir_stat.does_exist)
            self.assertTrue(dir_stat.is_empty)

class TestReadFileBytes(unittest.TestCase):
    def test_existing_file_returns_data(self) -> None:
        with TestDirectory(self) as root_dir:
            file = FakeFile(root_dir, 'test-file', FAKE_DATA_A)

            data = RealFileSystem().read_file_bytes(file.filepath)

            self.assertEqual(FAKE_DATA_A, data)

    def test_missing_file_raises_error(self) -> None:
        with TestDirectory(self) as root_dir:
            file = PurePath(root_dir.path, 'missing-file')

        with self.assertRaises(FileNotFoundError):
            RealFileSystem().read_file_bytes(file)

    def test_directory_raises_error(self) -> None:
        with TestDirectory(self) as root_dir, self.assertRaises(OSError):
            RealFileSystem().read_file_bytes(root_dir.path)

class TestWriteFileBytes(unittest.TestCase):
    def test_new_file_is_created(self) -> None:
        with TestDirectory(self) as root_dir:
            file = PurePath(root_dir.path, 'test-file')

            RealFileSystem().write_file_bytes(file, FAKE_DATA_A)

            root_dir.assert_file_exists(file, FAKE_DATA_A)

    def test_existing_file_is_overwritten(self) -> None:
        with TestDirectory(self) as root_dir:
            file = FakeFile(root_dir, 'test-file', FAKE_DATA_A)

            RealFileSystem().write_file_bytes(file.filepath, FAKE_DATA_B)

            root_dir.assert_file_exists(file, FAKE_DATA_B)

    def test_directory_raises_error(self) -> None:
        with TestDirectory(self) as root_dir, self.assertRaises(OSError):
            RealFileSystem().write_file_bytes(root_dir.path, FAKE_DATA_A)

class TestHashFile(unittest.TestCase):
    def test_existing_file_returns_digest(self) -> None:
        with TestDirectory(self) as root_dir:
            file_a = FakeFile(root_dir, 'test-file-a', FAKE_DATA_A)
            file_b = FakeFile(root_dir, 'test-file-b', FAKE_DATA_B)

            digest_a: bytes = RealFileSystem().hash_file(file_a.filepath)
            digest_b: bytes = RealFileSystem().hash_file(file_b.filepath)

            self.assertEqual(FAKE_DIGEST_BYTES_A, digest_a)
            self.assertEqual(FAKE_DIGEST_BYTES_B, digest_b)

    def test_missing_file_raises_error(self) -> None:
        with TestDirectory(self) as root_dir, self.assertRaises(FileNotFoundError):
            RealFileSystem().hash_file(root_dir.path / 'test-file-a')

    def test_directory_raises_error(self) -> None:
        with TestDirectory(self) as root_dir, self.assertRaises(OSError):
            RealFileSystem().hash_file(root_dir.path)

class TestCopyFile(unittest.TestCase):
    def test_copy_to_same_directory(self) -> None:
        with TestDirectory(self) as root_dir:
            file_a = FakeFile(root_dir, 'test-file-a', FAKE_DATA_A)
            file_b = PurePath(root_dir.path, 'test-file-b')

            RealFileSystem().copy_file(file_a.filepath, file_b)

            root_dir.assert_file_exists(file_a, FAKE_DATA_A)
            root_dir.assert_file_exists(file_b, FAKE_DATA_A)

    def test_copy_to_different_directory(self) -> None:
        with TestDirectory(self) as root_dir_1, TestDirectory(self) as root_dir_2:
            file_a = FakeFile(root_dir_1, 'test-file-a', FAKE_DATA_A)
            file_b = PurePath(root_dir_2.path, 'test-file-b')

            RealFileSystem().copy_file(file_a.filepath, file_b)

            root_dir_1.assert_file_exists(file_a, FAKE_DATA_A)
            root_dir_2.assert_file_exists(file_b, FAKE_DATA_A)

    def test_copy_missing_file_raises_error(self) -> None:
        with TestDirectory(self) as root_dir:
            file_a = PurePath(root_dir.path, 'missing-file')
            file_b = PurePath(root_dir.path, 'test-file-b')

            with self.assertRaises(FileNotFoundError):
                RealFileSystem().copy_file(file_a, file_b)

    def test_copy_directory_raises_error(self) -> None:
        with TestDirectory(self) as root_dir:
            dir_a = root_dir.create_subdirectory('a-directory')
            file_b = PurePath(root_dir.path, 'test-file-b')

            with self.assertRaises(OSError):
                RealFileSystem().copy_file(dir_a, file_b)

class TestMoveFile(unittest.TestCase):
    def test_move_within_same_directory(self) -> None:
        with TestDirectory(self) as root_dir:
            file_a = FakeFile(root_dir, 'test-file-a', FAKE_DATA_A)
            file_b = PurePath(root_dir.path, 'test-file-b')

            RealFileSystem().move_file(file_a.filepath, file_b)

            root_dir.assert_file_missing(file_a)
            root_dir.assert_file_exists(file_b, FAKE_DATA_A)

    def test_move_to_different_directory(self) -> None:
        with TestDirectory(self) as root_dir_1, TestDirectory(self) as root_dir_2:
            file_a = FakeFile(root_dir_1, 'test-file-a', FAKE_DATA_A)
            file_b = PurePath(root_dir_2.path, 'test-file-b')

            RealFileSystem().move_file(file_a.filepath, file_b)

            root_dir_1.assert_file_missing(file_a)
            root_dir_2.assert_file_exists(file_b, FAKE_DATA_A)

    def test_move_missing_file_raises_error(self) -> None:
        with TestDirectory(self) as root_dir:
            file_a = PurePath(root_dir.path, 'missing-file')
            file_b = PurePath(root_dir.path, 'test-file-b')

            with self.assertRaises(FileNotFoundError):
                RealFileSystem().move_file(file_a, file_b)

class TestWriteZipFile(unittest.TestCase):
    def test_zips_existing_files(self) -> None:
        with TestDirectory(self) as root_dir:
            zip_filename = PurePath(root_dir.path, 'file.zip')
            file_a = FakeFile(root_dir, 'test-file-a', FAKE_DATA_A)
            file_b = FakeFile(root_dir, 'test-file-b', FAKE_DATA_B)

            RealFileSystem().write_zip_file(zip_filename, (
                (file_a.filepath, file_a.relpath),
                (file_b.filepath, file_b.relpath),
            ))

            with TestDirectory(self) as extract_dir, ZipFile(zip_filename) as zip_file:
                zip_file.extractall(extract_dir.path)

                extract_dir.assert_contains(
                    expected_list_of_files=(
                        file_a,
                        file_b,
                    ),
                    expected_list_of_dirpaths=(),
                )

    def test_raises_error_on_missing_file(self) -> None:
        with TestDirectory(self) as root_dir:
            zip_filename = PurePath(root_dir.path, 'file.zip')
            file_a = FakeFile(root_dir, 'test-file-a', FAKE_DATA_A)
            file_b = PurePath(root_dir.path, 'missing-file')

            with self.assertRaises(FileNotFoundError):
                RealFileSystem().write_zip_file(zip_filename, (
                    (file_a.filepath, file_a.relpath),
                    (file_b, PurePath(file_b.name)),
                ))

class TestCreateDirectoryAndParentsIfNeeded(unittest.TestCase):
    def test_creates_top_level_subdirectory(self) -> None:
        with TestDirectory(self) as root_dir:
            directory: PurePath = root_dir.path / 'new-directory'

            RealFileSystem().create_directory_and_parents_if_needed(directory)

            root_dir.assert_contains(
                expected_list_of_files=(),
                expected_list_of_dirpaths=(directory,),
            )

    def test_ignores_existing_top_level_subdirectory(self) -> None:
        with TestDirectory(self) as root_dir:
            root_dir.create_subdirectory('new-directory')
            directory: PurePath = root_dir.path / 'new-directory'

            RealFileSystem().create_directory_and_parents_if_needed(directory)

            root_dir.assert_contains(
                expected_list_of_files=(),
                expected_list_of_dirpaths=(directory,),
            )

    def test_creates_multi_level_subdirectory(self) -> None:
        with TestDirectory(self) as root_dir:
            directory: PurePath = root_dir.path / 'new-1' / 'new-2' / 'new-3'

            RealFileSystem().create_directory_and_parents_if_needed(directory)

            root_dir.assert_contains(
                expected_list_of_files=(),
                expected_list_of_dirpaths=(
                    directory,
                    directory.parent,
                    directory.parent.parent,
                ),
            )

    def test_creates_multi_level_subdirectory_when_top_level_directories_exist(self) -> None:
        with TestDirectory(self) as root_dir:
            root_dir.create_subdirectory(PurePath('new-1', 'new-2'))
            directory: PurePath = root_dir.path / 'new-1' / 'new-2' / 'new-3'

            RealFileSystem().create_directory_and_parents_if_needed(directory)

            root_dir.assert_contains(
                expected_list_of_files=(),
                expected_list_of_dirpaths=(
                    directory,
                    directory.parent,
                    directory.parent.parent,
                ),
            )

    def test_raises_error_when_file_would_be_clobbered(self) -> None:
        with TestDirectory(self) as root_dir:
            FakeFile(root_dir, PurePath('new-1', 'new-2'), FAKE_DATA_A)
            directory: PurePath = root_dir.path / 'new-1' / 'new-2' / 'new-3'

            with self.assertRaises(OSError):
                RealFileSystem().create_directory_and_parents_if_needed(directory)

class TestDeleteFile(unittest.TestCase):
    def test_removes_readonly_file_from_directory(self) -> None:
        with TestDirectory(self) as root_dir:
            file_1 = FakeFile(root_dir, 'mango.txt', 123, is_writeable=True)

            RealFileSystem().delete_file(file_1.filepath)

            root_dir.assert_empty()

    def test_removes_single_file_and_leaves_existing_file_in_directory(self) -> None:
        with TestDirectory(self) as root_dir:
            file_1 = FakeFile(root_dir, 'mango.txt', 821)
            file_2 = FakeFile(root_dir, 'banana.dat', FAKE_DATA_A)

            RealFileSystem().delete_file(file_1.filepath)

            root_dir.assert_contains(
                expected_list_of_files = [
                    file_2,
                ],
                expected_list_of_dirpaths = [
                ])
            root_dir.assert_file_exists(file_2, FAKE_DATA_A)

    def test_raises_error_when_file_not_found(self) -> None:
        with TestDirectory(self) as root_dir, self.assertRaises(FileNotFoundError):
            RealFileSystem().delete_file(root_dir.path / 'does-not-exist')

    def test_raises_error_when_file_is_a_directory(self) -> None:
        with TestDirectory(self) as root_dir:
            dirpath: PurePath = root_dir.create_subdirectory('foo')
            with self.assertRaises(OSError):
                RealFileSystem().delete_file(dirpath)

class TestDeleteDirectory(unittest.TestCase):
    def test_removes_single_empty_directory(self) -> None:
        with TestDirectory(self) as root_dir:
            directory = root_dir.create_subdirectory('test-dir')

            RealFileSystem().delete_directory(directory)

            root_dir.assert_empty()

    def test_raises_error_if_deleting_file(self) -> None:
        with TestDirectory(self) as root_dir:
            file = FakeFile(root_dir, 'test-file', FAKE_DATA_A)

            with self.assertRaises(OSError):
                RealFileSystem().delete_directory(file.filepath)

    def test_raises_error_if_deleting_non_empty_directory(self) -> None:
        with TestDirectory(self) as root_dir:
            directory = root_dir.create_subdirectory('test-dir')
            FakeFile(root_dir, PurePath(directory.name) / 'test-file', FAKE_DATA_A)

            with self.assertRaises(OSError):
                RealFileSystem().delete_directory(directory)

class TestSetFileAttributes(unittest.TestCase):
    def test_file_attributes_are_set(self) -> None:
        with TestDirectory(self) as root_dir:
            file_1 = FakeFile(root_dir, 'file1.txt', FAKE_DATA_A)
            file_2 = FakeFile(root_dir, 'mango.log', FAKE_DATA_B)
            file_3 = FakeFile(root_dir, 'config.dat', FAKE_DATA_C)
            file_4 = FakeFile(root_dir, 'apple.cue', FAKE_DATA_D)

            filesystem: IFileSystem = RealFileSystem()
            filesystem.set_file_attributes(file_1.filepath, is_writeable=True, is_executable=False)
            filesystem.set_file_attributes(file_2.filepath, is_writeable=False, is_executable=False)
            filesystem.set_file_attributes(file_3.filepath, is_writeable=True, is_executable=True)
            filesystem.set_file_attributes(file_4.filepath, is_writeable=False, is_executable=True)

            root_dir.assert_contains(
                expected_list_of_files = [
                    file_1,
                    file_2,
                    file_3,
                    file_4,
                ],
                expected_list_of_dirpaths = [
                ])
            root_dir.assert_file_exists(file_1, FAKE_DATA_A, is_writeable=True, is_executable=False)
            root_dir.assert_file_exists(file_2, FAKE_DATA_B, is_writeable=False, is_executable=False)
            root_dir.assert_file_exists(file_3, FAKE_DATA_C, is_writeable=True, is_executable=True)
            root_dir.assert_file_exists(file_4, FAKE_DATA_D, is_writeable=False, is_executable=True)

    def test_raises_error_if_attribute_cannot_be_set(self) -> None:
        with TestDirectory(self) as root_dir:
            file_1: PurePath = root_dir.path / 'missing.txt'

            with self.assertRaises(FileNotFoundError):
                RealFileSystem().set_file_attributes(file_1, is_executable=False, is_writeable=True)
            with self.assertRaises(FileNotFoundError):
                RealFileSystem().set_file_attributes(file_1, is_executable=False, is_writeable=False)
            with self.assertRaises(FileNotFoundError):
                RealFileSystem().set_file_attributes(file_1, is_executable=True, is_writeable=True)
            with self.assertRaises(FileNotFoundError):
                RealFileSystem().set_file_attributes(file_1, is_executable=True, is_writeable=False)

class TestIterateDirectory(unittest.TestCase):
    def test_empty_directory_yields_nothing(self) -> None:
        with TestDirectory(self) as root_dir:
            list_of_files: list[PurePath] = list(RealFileSystem().iterate_directory(root_dir.path))

            self.assertListEqual([], list_of_files)

    def test_directory_with_one_file(self) -> None:
        with TestDirectory(self) as root_dir:
            file = FakeFile(root_dir, 'test-file', FAKE_DATA_A)

            list_of_files: list[PurePath] = list(RealFileSystem().iterate_directory(root_dir.path))

            self.assertListEqual([file.filepath], list_of_files)

    def test_directory_with_multiple_files_and_directories(self) -> None:
        with TestDirectory(self) as root_dir:
            file_1 = FakeFile(root_dir, 'test-file-1', FAKE_DATA_A)
            file_2 = FakeFile(root_dir, 'test-file-2', FAKE_DATA_B)
            file_3 = FakeFile(root_dir, 'test-file-3', FAKE_DATA_C)
            dir_1 = root_dir.create_subdirectory('test-dir-1')
            dir_2 = root_dir.create_subdirectory('test-dir-2')

            list_of_files: list[PurePath] = list(RealFileSystem().iterate_directory(root_dir.path))

            self.assertCountEqual([
                file_1.filepath,
                file_2.filepath,
                file_3.filepath,
                dir_1,
                dir_2,
            ], list_of_files)

    def test_missing_directory_raises_error(self) -> None:
        with TestDirectory(self) as root_dir:
            dir_1 = PurePath(root_dir.path, 'missing-dir')

            with self.assertRaises(OSError):
                list(RealFileSystem().iterate_directory(dir_1))

    def test_file_as_directory_raises_error(self) -> None:
        with TestDirectory(self) as root_dir:
            file_1 = FakeFile(root_dir, 'missing-dir', FAKE_DATA_A)

            with self.assertRaises(OSError):
                list(RealFileSystem().iterate_directory(file_1.filepath))
