# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import tkinter as tk
from collections.abc import Callable
from types import TracebackType
from typing import Self
from milodb.client.view.gui import theme

class TkinterTestEnvironment:
    def __init__(self) -> None:
        self._tk_root = tk.Tk()
        theme.configure_ttk_styles(self._tk_root)
        self._tk_root.geometry("100x50")
        tk.Label(self._tk_root, text="Main Window").pack()

    def execute_within(self, method: Callable[[tk.Tk], None]) -> None:
        self._tk_root.update()
        self._tk_root.after_idle(method, self._tk_root)
        self._tk_root.mainloop()
        self._tk_root.destroy()

    def __enter__(self) -> Self:
        return self

    def __exit__(self, exc_type: type[BaseException] | None, exc_value: BaseException | None, traceback: TracebackType | None) -> None:
        self._tk_root.quit()
