# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from __future__ import annotations
import os
import stat
import tempfile
from pathlib import Path, PurePath
from typing import NoReturn, TYPE_CHECKING

from milodb.common.system import PLATFORM, Platform
if TYPE_CHECKING:
    import unittest
    from collections.abc import Iterable, Sequence
    from types import TracebackType

class TestDirectory:
    def __init__(self, test_case: unittest.TestCase, debug_name: str | None = None) -> None:
        self._test_case: unittest.TestCase = test_case
        self._debug_name: str | None = debug_name
        self._path: Path | None = None

    def __enter__(self) -> TestDirectoryInstance:
        self._path = Path(tempfile.mkdtemp())
        return TestDirectoryInstance(self._test_case, self._path)

    def __exit__(self, exc_type: type[BaseException] | None, exc_value: BaseException | None, traceback: TracebackType | None) -> None:
        if not self._path:
            return
        if exc_value is not None:
            print(f"WARNING: Exception detected in '{self._test_case.id()}'")
            print(f"Showing contents of directory '{self._path}'{f' ({self._debug_name})' if self._debug_name else ''}:")
            _display_directory_contents(self._path)
        _delete_directory_recursively(self._path)
        self._path = None

class FakeFile:
    def __init__(self, directory: TestDirectoryInstance, filename_or_path: str | PurePath, size_or_data: int | bytes, *, is_readable: bool = True, is_writeable: bool = True, is_executable: bool = False) -> None:
        self._filepath: Path = Path(directory.path_of(filename_or_path))
        self._relpath: PurePath = PurePath(filename_or_path)
        self._size: int
        self._data: bytes
        self._is_executable = is_executable

        self._filepath.parent.mkdir(parents=True, exist_ok=True)

        if isinstance(size_or_data, int):
            self._size = size_or_data
            self._data = bytes(index % 256 for index in range(self._size))
            with self._filepath.open('wb') as file:
                file.write(self._data)
        else:
            self._size = len(size_or_data)
            self._data = size_or_data
            with self._filepath.open('wb') as file:
                file.write(size_or_data)

        file_mode: int = self._filepath.stat().st_mode
        file_mode = file_mode | stat.S_IRUSR if is_readable else file_mode & ~stat.S_IRUSR
        file_mode = file_mode | stat.S_IWUSR if is_writeable else file_mode & ~stat.S_IWUSR
        file_mode = file_mode | stat.S_IXUSR if is_executable else file_mode & ~stat.S_IXUSR
        self._filepath.chmod(file_mode)

    @property
    def relpath(self) -> PurePath:
        return self._relpath

    @property
    def filepath(self) -> PurePath:
        return self._filepath

    @property
    def size(self) -> int:
        return self._size

    @property
    def data(self) -> bytes:
        return self._data

    @property
    def parent(self) -> PurePath:
        return self._filepath.parent

    @property
    def is_executable(self) -> bool:
        return self._is_executable

class FakeTempFile:
    def __init__(self, dirpath: TestDirectoryInstance, filename: str, size_or_data: int | bytes, *, is_executable: bool = False) -> None:
        self._filename: str = filename
        self._relpath: PurePath = PurePath(f'mdbu-{filename}')
        self._filepath: Path = Path(dirpath.path_of(self._relpath))
        self._size: int
        self._data: bytes
        self._is_executable = is_executable

        self._filepath.parent.mkdir(parents=True, exist_ok=True)

        if isinstance(size_or_data, int):
            self._size = size_or_data
            self._data = bytes(index % 256 for index in range(self._size))
            with self._filepath.open('wb') as file:
                file.write(self._data)
        else:
            self._size = len(size_or_data)
            self._data = size_or_data
            with self._filepath.open('wb') as file:
                file.write(size_or_data)

        file_mode: int = self._filepath.stat().st_mode
        file_mode = file_mode | stat.S_IXUSR if is_executable else file_mode & ~stat.S_IXUSR
        self._filepath.chmod(file_mode)

    @property
    def filename(self) -> PurePath:
        return PurePath(self._filename)

    @property
    def relpath(self) -> PurePath:
        return self._relpath

    @property
    def filepath(self) -> PurePath:
        return self._filepath

    @property
    def size(self) -> int:
        return self._size

    @property
    def data(self) -> bytes:
        return self._data

    @property
    def is_executable(self) -> bool:
        return self._is_executable

class TestDirectoryInstance:
    def __init__(self, test_case: unittest.TestCase, dirpath: PurePath) -> None:
        self._test_case: unittest.TestCase = test_case
        self._path: PurePath = dirpath

    @property
    def path(self) -> PurePath:
        if self._has_path() and self._path:
            return self._path
        return PurePath()

    def create_subdirectory(self, path: str | PurePath) -> PurePath:
        dirpath: Path = Path(self._path / path)
        dirpath.mkdir(parents=True)
        return dirpath

    def path_of(self, filename: str | PurePath) -> PurePath:
        if self._has_path() and self._path:
            return self._path / filename
        return PurePath()

    def assert_file_exists(self, filename: str | PurePath | FakeFile, expected_data_or_size: bytes | int | None = None, *, is_readable: bool = True, is_writeable: bool = True, is_executable: bool = False) -> None:
        """On Windows, the executable mode is not checked as all files are considered executable."""
        if not (self._has_path() and self._path):
            return

        filepath: Path = Path(self._path.joinpath(filename.relpath) if isinstance(filename, FakeFile) else self._path.joinpath(filename))

        self.assert_file_access(filepath, is_readable=is_readable, is_writeable=is_writeable, is_executable=is_executable)

        if expected_data_or_size is None or isinstance(expected_data_or_size, int):
            self._test_case.assertTrue(filepath.exists(), f"File '{filepath}' does not exist")
            self._test_case.assertTrue(filepath.is_file(), f"File '{filepath}' is not a file")
            if isinstance(expected_data_or_size, int):
                self._test_case.assertEqual(filepath.stat().st_size, expected_data_or_size, f"Path '{filepath}' file size should be {expected_data_or_size} bytes")
        else:
            try:
                filepath.chmod(filepath.stat().st_mode | stat.S_IRUSR)
                actual_data: bytes = filepath.read_bytes()
            except FileNotFoundError:
                self._test_case.fail(f"File '{filepath}' does not exist")
            except OSError as ex:
                self._test_case.fail(f"File '{filepath}' cannot be read: {ex}")
            else:
                self._test_case.assertEqual(expected_data_or_size, actual_data)

    def assert_file_access(self, filename: str | PurePath | FakeFile, *, is_readable: bool | None = None, is_writeable: bool | None = None, is_executable: bool | None = None) -> None:
        """On Windows, the executable mode is not checked as all files are considered executable."""
        if not (self._has_path() and self._path):
            return

        filepath: Path = Path(self._path.joinpath(filename.relpath) if isinstance(filename, FakeFile) else self._path.joinpath(filename))

        if is_readable is not None:
            self._test_case.assertEqual(is_readable, os.access(filepath, os.R_OK), f"File '{filepath}' is_readable != {is_readable}")
        if is_writeable is not None:
            self._test_case.assertEqual(is_writeable, os.access(filepath, os.W_OK), f"File '{filepath}' is_writeable != {is_writeable}")
        if PLATFORM is not Platform.WINDOWS and is_executable is not None:
            self._test_case.assertEqual(is_executable, os.access(filepath, os.X_OK), f"File '{filepath}' is_executable != {is_executable}")

    def assert_file_missing(self, filename: str | PurePath | FakeFile) -> None:
        if self._has_path() and self._path:
            filepath: Path = Path(filename.filepath if isinstance(filename, FakeFile) else self._path / filename)
            self._test_case.assertFalse(filepath.exists(), f"File '{filepath}' exists when it shouldn't")

    def assert_empty(self) -> None:
        self.assert_contains([], [])

    def assert_contains(self, expected_list_of_files: Iterable[str | PurePath | FakeFile], expected_list_of_dirpaths: Iterable[str | PurePath]) -> None:
        if self._has_path() and self._path:
            root_path: Path = Path(self._path)

            def fail(ex: OSError) -> NoReturn:
                self._test_case.fail(f"Error walking directory: {ex}")

            actual_list_of_filepaths: list[str] = []
            actual_list_of_dirpaths: list[str] = []

            dirpath: str
            list_of_dirnames: Sequence[str]
            list_of_filenames: Sequence[str]
            for dirpath, list_of_dirnames, list_of_filenames in os.walk(root_path, onerror=fail):
                actual_list_of_dirpaths.extend( [ str(Path(dirpath, dirname)) for dirname in list_of_dirnames ] )
                actual_list_of_filepaths.extend( [ str(Path(dirpath, filename)) for filename in list_of_filenames ] )

            self._test_case.assertCountEqual([ str(root_path.joinpath(file)) if isinstance(file, str | PurePath) else str(root_path.joinpath(file.relpath)) for file in expected_list_of_files ], actual_list_of_filepaths)
            self._test_case.assertCountEqual([ str(root_path.joinpath(dirpath)) for dirpath in expected_list_of_dirpaths ], actual_list_of_dirpaths)

    def _has_path(self) -> bool:
        if self._path:
            return True
        self._test_case.fail('TEST ERROR: TestDirectory has not been created or has been destroyed')
        return Path()

def _display_directory_contents(starting_path: Path) -> None:
    def warning(ex: OSError) -> None:
        print(f'WARNING: {ex}')

    dirpath: str
    list_of_directories: Sequence[str]
    list_of_filenames: Sequence[str]
    for dirpath, list_of_directories, list_of_filenames in os.walk(starting_path, onerror=warning):
        path: Path
        for filename in list_of_filenames:
            path = Path(dirpath, filename)
            stats: os.stat_result = path.stat()
            print(f"  {stats.st_size:10,} bytes  {'EXE' if os.access(path, os.X_OK) else '   '} '{path}'")
        for directory_name in list_of_directories:
            path = Path(dirpath, directory_name)
            print(f"  {'<DIR>':10}            '{path}'")

def _delete_directory_recursively(starting_path: Path) -> None:
    def fail(ex: OSError) -> NoReturn:
        raise ex

    dirpath: str
    list_of_directory_names: Sequence[str]
    list_of_filenames: Sequence[str]
    for dirpath, list_of_directory_names, list_of_filenames in os.walk(starting_path, topdown=False, onerror=fail):
        for filename in list_of_filenames:
            Path(dirpath, filename).chmod(stat.S_IWUSR | stat.S_IWGRP | stat.S_IWOTH)
            Path(dirpath, filename).unlink()
        for directory_name in list_of_directory_names:
            Path(dirpath, directory_name).rmdir()
    starting_path.rmdir()
