# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import time
import tkinter as tk
import unittest
from collections.abc import Callable
from milodb.client.view.gui.dialogs.progress_dialog import ProgressDialog
from milodb.client.view.gui.util.tk_thread import run_tk_thread_routine
from milodb_test.client.test.tkinter_test_environment import TkinterTestEnvironment

class TestProgressDialog(unittest.TestCase):
    @staticmethod
    def test_closes_immediately_without_interactions() -> None:
        _run_test(lambda _: None)

    @staticmethod
    def test_closes_immediately_after_normal_text() -> None:
        _run_test(lambda progress_dialog: progress_dialog.normal_printer.writeln('Normal text'))

    @staticmethod
    def test_closes_immediately_after_warning_text() -> None:
        _run_test(lambda progress_dialog: progress_dialog.normal_printer.writeln('Warning text'))

    @staticmethod
    def test_closes_immediately_after_error_text() -> None:
        _run_test(lambda progress_dialog: progress_dialog.normal_printer.writeln('Error text'))

    @staticmethod
    def test_closes_after_delay() -> None:
        _run_test(lambda _: time.sleep(1.0))

    @staticmethod
    def test_closes_after_normal_text_and_delay() -> None:
        def test(progress_dialog: ProgressDialog) -> None:
            progress_dialog.normal_printer.writeln('Normal text')
            time.sleep(1.0)
        _run_test(test)

    @staticmethod
    def test_closes_after_warning_text_and_delay() -> None:
        def test(progress_dialog: ProgressDialog) -> None:
            progress_dialog.warning_printer.writeln('Warning text')
            time.sleep(1.0)
        _run_test(test)

    @staticmethod
    def test_closes_after_error_text_and_delay() -> None:
        def test(progress_dialog: ProgressDialog) -> None:
            progress_dialog.error_printer.writeln('Error text')
            time.sleep(1.0)
        _run_test(test)

    @staticmethod
    def test_prompts_with_details_after_request() -> None:
        _run_test(ProgressDialog.prompt_on_exit)

    @staticmethod
    def test_prompts_with_details_and_text_after_request() -> None:
        def test(progress_dialog: ProgressDialog) -> None:
            progress_dialog.normal_printer.writeln('Normal text')
            progress_dialog.warning_printer.writeln('Warning text')
            progress_dialog.error_printer.writeln('Error text')
            progress_dialog.prompt_on_exit()
        _run_test(test)

    @staticmethod
    def test_prompts_after_warning_text_and_request() -> None:
        _run_test(lambda progress_dialog: progress_dialog.print_warning_and_prompt_on_exit('Warning text'))

    @staticmethod
    def test_prompts_after_error_text_and_request() -> None:
        _run_test(lambda progress_dialog: progress_dialog.print_error_and_prompt_on_exit('Error text'))

    @staticmethod
    def test_prompts_after_fatal_text_and_request() -> None:
        _run_test(lambda progress_dialog: progress_dialog.print_fatal_and_prompt_on_exit('Fatal text'))

    @staticmethod
    def test_prompts_after_warning_text_and_other_text_and_request() -> None:
        def test(progress_dialog: ProgressDialog) -> None:
            progress_dialog.print_warning_and_prompt_on_exit('Warning text')
            progress_dialog.normal_printer.writeln('Normal text')
        _run_test(test)

    @staticmethod
    def test_prompts_after_error_text_and_other_text_and_request() -> None:
        def test(progress_dialog: ProgressDialog) -> None:
            progress_dialog.print_error_and_prompt_on_exit('Error text')
            progress_dialog.normal_printer.writeln('Normal text')
        _run_test(test)

    @staticmethod
    def test_prompts_after_fatal_text_and_other_text_and_request() -> None:
        def test(progress_dialog: ProgressDialog) -> None:
            progress_dialog.print_fatal_and_prompt_on_exit('Fatal text')
            progress_dialog.normal_printer.writeln('Normal text')
        _run_test(test)

    @staticmethod
    def test_set_subtitle() -> None:
        def test(progress_dialog: ProgressDialog) -> None:
            progress_dialog.set_subtitle_text('hello')
            time.sleep(1.0)
            progress_dialog.set_subtitle_text('world')
            time.sleep(1.0)
        _run_test(test)

    @staticmethod
    def test_set_action_text() -> None:
        def test(progress_dialog: ProgressDialog) -> None:
            progress_dialog.set_action_text('hello')
            time.sleep(1.0)
            progress_dialog.set_action_text('world')
            time.sleep(1.0)
        _run_test(test)

    @staticmethod
    def test_set_activity_category() -> None:
        def test(progress_dialog: ProgressDialog) -> None:
            progress_dialog.set_activity_category('HELLO')
            time.sleep(1.0)
            progress_dialog.set_activity_category('WORLD')
            time.sleep(1.0)
        _run_test(test)

    @staticmethod
    def test_set_activity_text() -> None:
        def test(progress_dialog: ProgressDialog) -> None:
            progress_dialog.set_activity_text('hello')
            time.sleep(1.0)
            progress_dialog.set_activity_text('world')
            time.sleep(1.0)
        _run_test(test)

    @staticmethod
    def test_set_activity_category_and_text() -> None:
        def test(progress_dialog: ProgressDialog) -> None:
            progress_dialog.set_activity_category('HELLO')
            progress_dialog.set_activity_text('hello')
            time.sleep(1.0)
            progress_dialog.set_activity_category('WORLD')
            progress_dialog.set_activity_text('world')
            time.sleep(1.0)
        _run_test(test)

    @staticmethod
    def test_set_activity_category_clears_activity_text() -> None:
        def test(progress_dialog: ProgressDialog) -> None:
            progress_dialog.set_activity_text('hello')
            time.sleep(1.0)
            progress_dialog.set_activity_category('WORLD')
            time.sleep(1.0)
        _run_test(test)

    @staticmethod
    def test_set_action_text_clears_activity() -> None:
        def test(progress_dialog: ProgressDialog) -> None:
            progress_dialog.set_activity_category('HELLO')
            progress_dialog.set_activity_text('hello')
            time.sleep(1.0)
            progress_dialog.set_action_text('world')
            time.sleep(1.0)
        _run_test(test)

    @staticmethod
    def test_set_percentage_can_go_upwards_to_100() -> None:
        def test(progress_dialog: ProgressDialog) -> None:
            for percentage in range(101):
                progress_dialog.set_action_text(f'{percentage}')
                progress_dialog.set_progress_percentage(percentage)
                time.sleep(0.1)
            time.sleep(1.0)
        _run_test(test)

    @staticmethod
    def test_set_percentage_can_go_downwards_to_0() -> None:
        def test(progress_dialog: ProgressDialog) -> None:
            for percentage in range(100, -1, -1):
                progress_dialog.set_action_text(f'{percentage}')
                progress_dialog.set_progress_percentage(percentage)
                time.sleep(0.1)
            time.sleep(1.0)
        _run_test(test)

def _run_test(thread_test: Callable[[ProgressDialog], None]) -> None:
    with TkinterTestEnvironment() as env:
        def test(tk_root: tk.Tk) -> None:
            with ProgressDialog(tk_root) as dialog:
                run_tk_thread_routine(lambda: thread_test(dialog), dialog, 'progress-dialog-test-thread')
            tk_root.quit()
        env.execute_within(test)
