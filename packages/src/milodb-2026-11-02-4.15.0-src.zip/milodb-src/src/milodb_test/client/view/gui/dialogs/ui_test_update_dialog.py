# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import datetime
import time
import tkinter as tk
import unittest
from collections.abc import Iterable
from pathlib import PurePath
from typing import NamedTuple, override
from unittest.mock import ANY, Mock, PropertyMock
from mockito import when # type: ignore[import-untyped]
from milodb.client.config.update_config import UpdateConfig
from milodb.client.updater.cached_remote_update_data import ICachedRemoteUpdateData, RemoteUpdateData
from milodb.client.updater.i_temp_directory import ITempDirectory, ITempDirectoryCreator
from milodb.client.updater.manifest.common_manifest import IConfigFile, IHexDigest, ILaunchFile
from milodb.client.updater.manifest.hex_digest import HexDigest
from milodb.client.updater.manifest.local_manifest import ILocalManifest
from milodb.client.updater.manifest.update_directory import IAsset, IAssetRegister, IUpdateDirectory
from milodb.client.updater.manifest.version_manifest import ICoreFile, IVariant, IVersion, IVersionManifest
from milodb.client.updater.manifest.version_number import VersionNumber
from milodb.client.util.file_system import FileStat, IFileSystem
from milodb.client.view.gui.dialogs.update_dialog import show_update_dialog
from milodb.client.view.progress_display import IProgressDisplay
from milodb.common.config.framework import IConfig
from milodb.common.internet.i_scraper import IUrlScraper, IUrlScraperFactory, IUrlScraperPool, ScrapeProgressCallback, ScrapeResult
from milodb_test.client.test.tkinter_test_environment import TkinterTestEnvironment
from milodb_test.common.test.strict_mock import InterfaceMock

_UPDATE_DIRECTORY_URL: str = 'https://remote/update/direct.json'
_ASSET_URL_PREFIX: str = 'https://remote/assets'
_BACKUP_DIRECTORY: PurePath = PurePath('backup')

_ROOT_APP_RELPATH: PurePath = PurePath('app')
_ROOT_APP_DATA: bytes = b'poiuytrewq'
_ROOT_APP_DIGEST: bytes = bytes.fromhex('97fb5b3edd0e04fa1e56a0e510f3b4f1f61e5d5a6221b1b58547b752')
_ROOT_INFO_TXT_PATH: PurePath = PurePath('info.txt')
_ROOT_INFO_TXT_DATA: bytes = b'qzwxecrvtbynum'
_ROOT_INFO_TXT_DIGEST: bytes = bytes.fromhex('14779470e56ebd596be9f6d4d6651d7d0210d92792f664dd4a10df9b')
_ROOT_CONFIG_JSON_PATH: PurePath = PurePath('config.json')

_NEW_ASSET_DATA: bytes = b'qwertyuiop'
_NEW_ASSET_DIGEST: bytes = bytes.fromhex('1151277f52cafb7d500b3b29507badc6522672b361a6271099b9581c')
_NEW_ASSET_URL: str = f'{_ASSET_URL_PREFIX}/{_NEW_ASSET_DIGEST.hex()}'

class _StoredFile(NamedTuple):
    data: bytes
    is_executable: bool

class UiTestUpdateDialog(unittest.TestCase):
    @override
    def setUp(self) -> None:
        super().setUp()

        self.root_dir = PurePath('not-a-real-root-dir')
        self.absolute_root_dir = PurePath('/') / 'temp' / self.root_dir

        self._init_config_mocks()
        self._init_local_manifest_mocks()
        self._init_remote_update_data_mocks()
        self._init_filesystem_mock()
        self._init_url_scraper_mocks()
        self._init_temp_update_directory_mocks()
        self._init_shutdown_mocks()

    @override
    def tearDown(self) -> None:
        return super().tearDown()

    def _init_config_mocks(self) -> None:
        self.mock_update_config = UpdateConfig(InterfaceMock(IConfig,
            dictionary = PropertyMock(return_value={
                'update': {
                    'backupDirectory': str(_BACKUP_DIRECTORY),
                    'updateDirectoryUri': str(_UPDATE_DIRECTORY_URL),
                },
            }),
        ))

    def _init_local_manifest_mocks(self) -> None:
        self.mock_local_manifest = InterfaceMock(ILocalManifest,
            variant_name = PropertyMock(return_value='var1'),
            version_number = PropertyMock(return_value=VersionNumber(4, 0, 0, None)),
            core_files = PropertyMock(return_value=(_ROOT_INFO_TXT_PATH, _ROOT_APP_RELPATH)),
            config_files = PropertyMock(return_value={
                0: InterfaceMock(IConfigFile, config_key=PropertyMock(return_value=0), filename=PropertyMock(return_value=_ROOT_CONFIG_JSON_PATH)),
            }),
        )

    def _init_remote_update_data_mocks(self) -> None:
        def mock_resolve_asset_url(_host_url: str, digest: IHexDigest) -> str | None:
            self.assertIn(digest.digest_bytes, (_NEW_ASSET_DIGEST,))
            return f'{_ASSET_URL_PREFIX}/{digest}'

        self.mock_update_directory = InterfaceMock(IUpdateDirectory,
            asset_register = PropertyMock(return_value=InterfaceMock(IAssetRegister,
                assets = PropertyMock(return_value={
                    HexDigest(_ROOT_APP_DIGEST): InterfaceMock(IAsset,
                        digest = PropertyMock(return_value=HexDigest(_ROOT_APP_DIGEST)),
                        url = PropertyMock(return_value=None),
                        identifier = PropertyMock(return_value=None),
                        size = PropertyMock(return_value=len(_ROOT_APP_DATA)),
                    ),
                    HexDigest(_ROOT_INFO_TXT_DIGEST): InterfaceMock(IAsset,
                        digest = PropertyMock(return_value=HexDigest(_ROOT_INFO_TXT_DIGEST)),
                        url = PropertyMock(return_value=None),
                        identifier = PropertyMock(return_value=None),
                        size = PropertyMock(return_value=len(_ROOT_INFO_TXT_DATA)),
                    ),
                    HexDigest(_NEW_ASSET_DIGEST): InterfaceMock(IAsset,
                        digest = PropertyMock(return_value=HexDigest(_NEW_ASSET_DIGEST)),
                        url = PropertyMock(return_value=None),
                        identifier = PropertyMock(return_value=None),
                        size = PropertyMock(return_value=len(_NEW_ASSET_DATA)),
                    ),
                }),
                resolve_asset_url = Mock(side_effect=mock_resolve_asset_url),
            )),
        )

        self.mock_variant_var1 = InterfaceMock(IVariant,
            name = PropertyMock(return_value='var1'),
            summary = PropertyMock(return_value='This is a summary'),
            versions = PropertyMock(return_value={
                VersionNumber(4, 0, 0, None): InterfaceMock(IVersion,
                    number = PropertyMock(return_value=VersionNumber(4, 0, 0, None)),
                    date = PropertyMock(return_value=datetime.date(2025, 7, 31)),
                    config_files = PropertyMock(return_value={
                        0: InterfaceMock(IConfigFile,
                            config_key = PropertyMock(return_value=0),
                            filename = PropertyMock(return_value=_ROOT_CONFIG_JSON_PATH),
                        ),
                    }),
                    core_files = PropertyMock(return_value={
                        _ROOT_INFO_TXT_PATH: InterfaceMock(ICoreFile,
                            filename = PropertyMock(return_value=_ROOT_INFO_TXT_PATH),
                            digest = PropertyMock(return_value=HexDigest(_ROOT_INFO_TXT_DIGEST)),
                            exe = PropertyMock(return_value=False),
                        ),
                        _ROOT_APP_RELPATH: InterfaceMock(ICoreFile,
                            filename = PropertyMock(return_value=_ROOT_APP_RELPATH),
                            digest = PropertyMock(return_value=HexDigest(_ROOT_APP_DIGEST)),
                            exe = PropertyMock(return_value=True),
                        ),
                    }),
                    launch_files = PropertyMock(return_value={
                        'linux': InterfaceMock(ILaunchFile,
                            operating_system = PropertyMock(return_value='linux'),
                            filename = PropertyMock(return_value=_ROOT_APP_RELPATH),
                        ),
                    }),
                    log = PropertyMock(return_value='* Version 4.0.0 test log entry'),
                ),
                VersionNumber(4, 1, 0, None): InterfaceMock(IVersion,
                    number = PropertyMock(return_value=VersionNumber(4, 1, 0, None)),
                    date = PropertyMock(return_value=datetime.date(2025, 8, 31)),
                    config_files = PropertyMock(return_value={
                        0: InterfaceMock(IConfigFile,
                            config_key = PropertyMock(return_value=0),
                            filename = PropertyMock(return_value=_ROOT_CONFIG_JSON_PATH),
                        ),
                    }),
                    core_files = PropertyMock(return_value={
                        PurePath('info.txt'): InterfaceMock(ICoreFile,
                            filename = PropertyMock(return_value=_ROOT_INFO_TXT_PATH),
                            digest = PropertyMock(return_value=HexDigest(_NEW_ASSET_DIGEST)),
                            exe = PropertyMock(return_value=False),
                        ),
                        PurePath('app'): InterfaceMock(ICoreFile,
                            filename = PropertyMock(return_value=_ROOT_APP_RELPATH),
                            digest = PropertyMock(return_value=HexDigest(_NEW_ASSET_DIGEST)),
                            exe = PropertyMock(return_value=True),
                        ),
                    }),
                    launch_files = PropertyMock(return_value={
                        'linux': InterfaceMock(ILaunchFile,
                            operating_system = PropertyMock(return_value='linux'),
                            filename = PropertyMock(return_value=_ROOT_APP_RELPATH),
                        ),
                    }),
                    log = PropertyMock(return_value='* Version 4.1.0 test log entry'),
                ),
            }),
        )

        self.mock_version_manifest = InterfaceMock(IVersionManifest,
            variants = PropertyMock(return_value={
                'var1': self.mock_variant_var1,
            }),
        )

        self.mock_remote_update_data: RemoteUpdateData = RemoteUpdateData(
            self.mock_update_directory,
            self.mock_version_manifest,
        )

        def mock_fetch(update_directory_url: str, url_scraper_factory: IUrlScraperFactory, progress_display: IProgressDisplay) -> RemoteUpdateData | None:
            self.assertEqual(_UPDATE_DIRECTORY_URL, update_directory_url)
            self.assertIs(self.mock_url_scraper_factory, url_scraper_factory)
            progress_display.normal_printer.writeln('Getting first bit')
            for progress in range(1, 50):
                time.sleep(0.02)
                progress_display.set_progress_percentage(progress)
            time.sleep(0.5)
            progress_display.normal_printer.writeln('Getting another bit')
            for progress in range(50, 100):
                time.sleep(0.02)
                progress_display.set_progress_percentage(progress)
            time.sleep(0.5)
            progress_display.set_progress_percentage(100)
            return self.mock_remote_update_data

        self.mock_cached_remote_update_data = InterfaceMock(ICachedRemoteUpdateData,
            try_get = Mock(return_value=None),
            fetch = Mock(side_effect=mock_fetch),
        )

    def _init_filesystem_mock(self) -> None:
        def mock_write_zip_file(zip_path: PurePath, source_path_iterator: Iterable[tuple[PurePath, PurePath]]) -> None:
            self.assertEqual(self.root_dir / _BACKUP_DIRECTORY, zip_path.parent)
            self.assertEqual('.zip', zip_path.suffix)
            list_of_source_paths: list[tuple[PurePath, PurePath]] = []
            origin_path: PurePath
            target_path: PurePath
            for origin_path, target_path in source_path_iterator:
                list_of_source_paths.append((origin_path, target_path))
                time.sleep(0.5)
            self.assertCountEqual([
                (self.root_dir / _ROOT_INFO_TXT_PATH, _ROOT_INFO_TXT_PATH),
                (self.root_dir / _ROOT_APP_RELPATH, _ROOT_APP_RELPATH),
            ], list_of_source_paths)

        self.mock_filesystem = InterfaceMock(IFileSystem,
            get_absolute_path = Mock(),
            probe_file = Mock(),
            hash_file = Mock(),
            read_file_bytes = Mock(),
            create_directory_and_parents_if_needed = Mock(),
            write_zip_file = Mock(side_effect=mock_write_zip_file),
        )

        when(self.mock_filesystem).get_absolute_path(self.root_dir).thenReturn(self.absolute_root_dir)
        when(self.mock_filesystem).get_absolute_path(self.root_dir / _ROOT_APP_RELPATH).thenReturn(self.absolute_root_dir / _ROOT_APP_RELPATH)
        when(self.mock_filesystem).probe_file(self.root_dir / _ROOT_INFO_TXT_PATH).thenReturn(FileStat(self.root_dir / _ROOT_INFO_TXT_PATH, does_exist=True, is_file=True, test_passed=True))
        when(self.mock_filesystem).probe_file(self.root_dir / _ROOT_APP_RELPATH).thenReturn(FileStat(self.root_dir / _ROOT_APP_RELPATH, does_exist=True, is_file=True, test_passed=True))
        when(self.mock_filesystem).probe_file(self.root_dir / _ROOT_CONFIG_JSON_PATH).thenReturn(FileStat(self.root_dir / _ROOT_CONFIG_JSON_PATH, does_exist=False, is_file=False, test_passed=False))
        when(self.mock_filesystem).hash_file(self.root_dir / _ROOT_INFO_TXT_PATH).thenReturn(_ROOT_INFO_TXT_DIGEST)
        when(self.mock_filesystem).hash_file(self.root_dir / _ROOT_APP_RELPATH).thenReturn(_ROOT_APP_DIGEST)
        when(self.mock_filesystem).read_file_bytes(self.root_dir / _ROOT_APP_RELPATH).thenReturn(_ROOT_APP_DATA)
        when(self.mock_filesystem).create_directory_and_parents_if_needed(self.root_dir / _BACKUP_DIRECTORY)

    def _init_url_scraper_mocks(self) -> None:
        def mock_try_scrape_url(url: str, progress_callback: ScrapeProgressCallback) -> ScrapeResult:
            if url != _NEW_ASSET_URL:
                self.fail("Trying to scrape unexpected asset URL '{url}'")
            time.sleep(1)
            progress_callback(message='Connecting', percentage_complete=0)
            time.sleep(0.5)
            progress_callback(message='Downloading', percentage_complete=None)
            for progress in range(10, 101):
                progress_callback(message=None, percentage_complete=progress)
                time.sleep(0.01)
            return ScrapeResult(None, None, _NEW_ASSET_DATA)

        self.url_scraper = InterfaceMock(IUrlScraper,
            try_scrape_url = Mock(side_effect=mock_try_scrape_url),
            close = Mock(),
        )
        self.mock_url_scraper_factory = InterfaceMock(IUrlScraperFactory,
            new_pool = Mock(return_value=InterfaceMock(IUrlScraperPool,
                __enter__ = Mock(return_value=self.url_scraper),
                __exit__ = Mock(return_value=None),
            )),
        )

    def _init_temp_update_directory_mocks(self) -> None:
        self.temp_update_dir = PurePath('not-a-real-temp-update-path')
        self.map_of_temp_stored_files: dict[PurePath, _StoredFile] = {}
        def temp_store_file(filename: PurePath, data: bytes, *, is_executable: bool = False) -> None:
            self.map_of_temp_stored_files[filename] = _StoredFile(data, is_executable)
            time.sleep(0.5)
        self.mock_temp_directory_creator = InterfaceMock(ITempDirectoryCreator,
            create = Mock(return_value=InterfaceMock(ITempDirectory,
                path = PropertyMock(return_value=self.temp_update_dir),
                path_of = Mock(side_effect=lambda filename: self.temp_update_dir / filename),
                store_file = Mock(side_effect=temp_store_file),
            )),
        )

    def _init_shutdown_mocks(self) -> None:
        self.mock_shutdown_app = Mock()

    def _run_test(self, *, sys_executable: str | None = None) -> None:
        def test(tk_root: tk.Tk) -> None:
            show_update_dialog(tk_root, self.root_dir, self.mock_update_config, self.mock_local_manifest, self.mock_cached_remote_update_data, self.mock_filesystem, self.mock_url_scraper_factory, self.mock_temp_directory_creator, self.mock_shutdown_app)
            tk_root.quit()

        self.mock_filesystem.current_executable = PropertyMock(return_value=PurePath(sys_executable or self.root_dir / _ROOT_APP_RELPATH))

        with TkinterTestEnvironment() as env:
            env.execute_within(test)

    def test_failure_to_download_remote_manifest_prompts_and_quits(self) -> None:
        def mock_fetch(_update_directory_url: str, _url_scraper_factory: IUrlScraperFactory, progress_display: IProgressDisplay) -> None:
            progress_display.normal_printer.writeln('Getting first bit')
            time.sleep(1)
            progress_display.error_printer.writeln('Simulated fault')
        self.mock_cached_remote_update_data.fetch = Mock(side_effect=mock_fetch)
        self._run_test()

    def test_uses_cached_remote_manifest_when_available(self) -> None:
        self.mock_cached_remote_update_data.try_get = Mock(return_value=self.mock_remote_update_data)
        self.mock_cached_remote_update_data.fetch = Mock(side_effect=AssertionError('should not be called'))
        self._run_test()

    def test_fetches_remote_manifest_if_cached_not_available(self) -> None:
        self._run_test()

    def test_failure_of_analysis_to_match_current_executable_against_core_files_prompts_and_quits(self) -> None:
        unknown_root_app = PurePath('unknown')
        when(self.mock_filesystem).get_absolute_path(unknown_root_app).thenReturn(self.root_dir / unknown_root_app)
        self._run_test(sys_executable=str(unknown_root_app))

    def test_failure_of_analysis_to_match_current_executable_with_file_under_root_dir_prompts_and_quits(self) -> None:
        unknown_dir = PurePath('/', 'foo')
        when(self.mock_filesystem).get_absolute_path(_ROOT_APP_RELPATH).thenReturn(unknown_dir / _ROOT_APP_RELPATH)
        self._run_test(sys_executable=str(_ROOT_APP_RELPATH))

    def test_failure_of_analysis_to_hash_a_core_file_prompts_and_quits(self) -> None:
        when(self.mock_filesystem).hash_file(self.root_dir / _ROOT_APP_RELPATH).thenRaise(PermissionError('Simulated error'))
        self._run_test()

    def test_no_newer_version_shows_variants_tab_only(self) -> None:
        self.mock_local_manifest.version_number = PropertyMock(return_value=VersionNumber(4, 1, 0, None))
        self._run_test()

    def test_multiple_variants_provides_switch_option(self) -> None:
        mock_variant_var2 = InterfaceMock(IVariant,
            name = PropertyMock(return_value='var2'),
            summary = PropertyMock(return_value='New variant'),
            versions = PropertyMock(return_value={
                VersionNumber(5, 0, 0, None): InterfaceMock(IVersion,
                    number = PropertyMock(return_value=VersionNumber(5, 0, 0, None)),
                    date = PropertyMock(return_value=datetime.date(2026, 1, 1)),
                    config_files = PropertyMock(return_value={}),
                    core_files = PropertyMock(return_value={
                        _ROOT_APP_RELPATH: InterfaceMock(ICoreFile,
                            filename = PropertyMock(return_value=_ROOT_APP_RELPATH),
                            digest = PropertyMock(return_value=HexDigest(_ROOT_APP_DIGEST)),
                            exe = PropertyMock(return_value=True),
                        ),
                    }),
                    launch_files = PropertyMock(return_value={
                        'linux': InterfaceMock(ILaunchFile,
                            operating_system = PropertyMock(return_value='linux'),
                            filename = PropertyMock(return_value=_ROOT_APP_RELPATH),
                        ),
                    }),
                    log = PropertyMock(return_value='* Version 5.0.0 test log entry'),
                ),
            }),
        )
        self.mock_cached_remote_update_data.try_get = Mock(return_value=RemoteUpdateData(
            self.mock_update_directory,
            InterfaceMock(IVersionManifest,
                variants = PropertyMock(return_value={
                    'var1': self.mock_variant_var1,
                    'var2': mock_variant_var2,
                }),
            ),
        ))
        self._run_test()

    def test_no_newer_version_and_multiple_variants_provides_switch_option(self) -> None:
        self.mock_local_manifest.version_number = PropertyMock(return_value=VersionNumber(4, 1, 0, None))

        mock_variant_var2 = InterfaceMock(IVariant,
            name = PropertyMock(return_value='var2'),
            summary = PropertyMock(return_value='New variant'),
            versions = PropertyMock(return_value={
                VersionNumber(5, 0, 0, None): InterfaceMock(IVersion,
                    number = PropertyMock(return_value=VersionNumber(5, 0, 0, None)),
                    date = PropertyMock(return_value=datetime.date(2026, 1, 1)),
                    config_files = PropertyMock(return_value={}),
                    core_files = PropertyMock(return_value={
                        _ROOT_APP_RELPATH: InterfaceMock(ICoreFile,
                            filename = PropertyMock(return_value=_ROOT_APP_RELPATH),
                            digest = PropertyMock(return_value=HexDigest(_ROOT_APP_DIGEST)),
                            exe = PropertyMock(return_value=True),
                        ),
                    }),
                    launch_files = PropertyMock(return_value={
                        'linux': InterfaceMock(ILaunchFile,
                            operating_system = PropertyMock(return_value='linux'),
                            filename = PropertyMock(return_value=_ROOT_APP_RELPATH),
                        ),
                    }),
                    log = PropertyMock(return_value='* Version 5.0.0 test log entry'),
                ),
            }),
        )
        self.mock_cached_remote_update_data.try_get = Mock(return_value=RemoteUpdateData(
            self.mock_update_directory,
            InterfaceMock(IVersionManifest,
                variants = PropertyMock(return_value={
                    'var1': self.mock_variant_var1,
                    'var2': mock_variant_var2,
                }),
            ),
        ))
        self._run_test()

    def test_calls_launch_and_shutdown_app_on_update(self) -> None:
        self.mock_filesystem.launch = Mock()
        self.mock_filesystem.get_list_of_process_ids = Mock(return_value=[1234])

        self._run_test()

        self.mock_filesystem.launch.assert_called_once_with(
            self.temp_update_dir / 'milodb-update-app', [
                '--wait-pid', '1234',
                '--perform-update', self.temp_update_dir / 'update_sequence.json',
            ],
            ANY,
            ANY,
        )
        self.mock_shutdown_app.assert_called_once()
