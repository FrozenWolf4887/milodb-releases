# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import unittest
from pathlib import PurePath
from typing import override
from unittest.mock import Mock, PropertyMock, call
from mockito import when # type: ignore[import-untyped]
from milodb.client.updater.i_temp_directory import ITempDirectory
from milodb.client.updater.manifest.update_sequence import IDeleteFile, IDeleteFilesAction, IEmplaceFile, IEmplaceFilesAction, IMoveFile, IMoveFilesAction, ISetFileAttribute, ISetFilesAttributeAction, IUpdateSequence
from milodb.client.updater.perform_update import PerformUpdateError, perform_delete_action, perform_emplace_action, perform_move_action, perform_set_attribute_action, perform_update
from milodb.client.util.file_system import DirStat, IFileSystem
from milodb.common.output.print.i_printer import IPrinter
from milodb_test.common.test.strict_mock import InterfaceMock

_TEMP_FILE_PREFIX: str = 'mdbu-'

class TestPerformDeleteAction(unittest.TestCase):
    @override
    def setUp(self) -> None:
        super().setUp()
        self.root_dir: PurePath = PurePath('not-a-real-root-path')
        self.normal_printer = InterfaceMock(IPrinter,
            writeln = Mock(),
        )
        self.warning_printer = InterfaceMock(IPrinter)
        self.filesystem = InterfaceMock(IFileSystem)

    def test_removes_nothing_from_empty_list(self) -> None:
        delete_action = InterfaceMock(IDeleteFilesAction,
            files = PropertyMock(return_value=[]),
        )

        perform_delete_action(self.root_dir, delete_action, self.normal_printer, self.warning_printer, self.filesystem)

    def test_removes_single_file_from_directory(self) -> None:
        file_1: PurePath = PurePath('file-1')
        delete_action = InterfaceMock(IDeleteFilesAction,
            files = PropertyMock(return_value=[
                InterfaceMock(IDeleteFile,
                    must_exist = PropertyMock(return_value=True),
                    filename = PropertyMock(return_value=file_1),
                ),
            ]),
        )
        self.filesystem.delete_file = Mock()

        perform_delete_action(self.root_dir, delete_action, self.normal_printer, self.warning_printer, self.filesystem)

        self.filesystem.delete_file.assert_called_once_with(self.root_dir / file_1)

    def test_removes_files_from_subdirectories_and_empty_directories(self) -> None:
        subdir_1: PurePath = PurePath('subdir1')
        subdir_2: PurePath = PurePath('subdir2')
        subdir_3: PurePath = subdir_2 / 'subdir3'
        file_1: PurePath = PurePath('mango.txt')
        file_2: PurePath = subdir_1 / 'banana.dat'
        file_3: PurePath = subdir_3 / 'changes.txt'
        file_4: PurePath = subdir_3 / 'details.log'

        delete_action = InterfaceMock(IDeleteFilesAction,
            files = PropertyMock(return_value=[
                InterfaceMock(IDeleteFile,
                    must_exist = PropertyMock(return_value=True),
                    filename = PropertyMock(return_value=file_1),
                ),
                InterfaceMock(IDeleteFile,
                    must_exist = PropertyMock(return_value=True),
                    filename = PropertyMock(return_value=file_2),
                ),
                InterfaceMock(IDeleteFile,
                    must_exist = PropertyMock(return_value=True),
                    filename = PropertyMock(return_value=file_3),
                ),
                InterfaceMock(IDeleteFile,
                    must_exist = PropertyMock(return_value=True),
                    filename = PropertyMock(return_value=file_4),
                ),
            ]),
        )

        list_of_deleted_files: set[PurePath] = set()
        list_of_deleted_directories: set[PurePath] = set()
        def mock_delete_file(path: PurePath) -> None:
            list_of_deleted_files.add(path)
        def mock_delete_directory(path: PurePath) -> None:
            list_of_deleted_directories.add(path)
        def mock_probe_directory(path: PurePath) -> DirStat: # noqa: RET503 Ruff false-positive, Missing explicit `return` at the end of function
            if path == self.root_dir / subdir_1:
                self.assertNotIn(self.root_dir / subdir_1, list_of_deleted_directories)
                self.assertIn(self.root_dir / file_2, list_of_deleted_files)
                return DirStat(path, does_exist=True, is_empty=True)
            if path == self.root_dir / subdir_2:
                self.assertNotIn(self.root_dir / subdir_2, list_of_deleted_directories)
                self.assertIn(self.root_dir / subdir_3, list_of_deleted_directories)
                self.assertIn(self.root_dir / file_2, list_of_deleted_files)
                self.assertIn(self.root_dir / file_3, list_of_deleted_files)
                self.assertIn(self.root_dir / file_4, list_of_deleted_files)
                return DirStat(path, does_exist=True, is_empty=True)
            if path == self.root_dir / subdir_3:
                self.assertNotIn(self.root_dir / subdir_3, list_of_deleted_directories)
                self.assertIn(self.root_dir / file_3, list_of_deleted_files)
                self.assertIn(self.root_dir / file_4, list_of_deleted_files)
                return DirStat(path, does_exist=True, is_empty=True)
            self.fail(f"Unexpected probe of directory '{path}'")

        self.filesystem.delete_file = Mock(side_effect=mock_delete_file)
        self.filesystem.delete_directory = Mock(side_effect=mock_delete_directory)
        self.filesystem.probe_directory = Mock(side_effect=mock_probe_directory)

        perform_delete_action(self.root_dir, delete_action, self.normal_printer, self.warning_printer, self.filesystem)

        self.filesystem.delete_file.assert_has_calls([
            call(self.root_dir / file_1),
            call(self.root_dir / file_2),
            call(self.root_dir / file_3),
            call(self.root_dir / file_4),
        ])
        self.filesystem.delete_directory.assert_has_calls([
            call(self.root_dir / subdir_1),
            call(self.root_dir / subdir_3),
            call(self.root_dir / subdir_2),
        ])

    def test_removes_files_from_subdirectories_and_leaves_populated_directories(self) -> None:
        subdir_1: PurePath = PurePath('subdir1')
        subdir_2: PurePath = PurePath('subdir2')
        subdir_3: PurePath = subdir_2 / 'subdir3'
        file_1: PurePath = PurePath('mango.txt')
        file_2: PurePath = subdir_1 / 'banana.dat'
        file_3: PurePath = subdir_3 / 'changes.txt'
        file_4: PurePath = subdir_3 / 'details.log'

        delete_action = InterfaceMock(IDeleteFilesAction,
            files = PropertyMock(return_value=[
                InterfaceMock(IDeleteFile,
                    must_exist = PropertyMock(return_value=True),
                    filename = PropertyMock(return_value=file_1),
                ),
                InterfaceMock(IDeleteFile,
                    must_exist = PropertyMock(return_value=True),
                    filename = PropertyMock(return_value=file_2),
                ),
                InterfaceMock(IDeleteFile,
                    must_exist = PropertyMock(return_value=True),
                    filename = PropertyMock(return_value=file_3),
                ),
                InterfaceMock(IDeleteFile,
                    must_exist = PropertyMock(return_value=True),
                    filename = PropertyMock(return_value=file_4),
                ),
            ]),
        )

        list_of_deleted_files: set[PurePath] = set()
        list_of_deleted_directories: set[PurePath] = set()
        def mock_delete_file(path: PurePath) -> None:
            list_of_deleted_files.add(path)
        def mock_delete_directory(path: PurePath) -> None:
            list_of_deleted_directories.add(path)
        def mock_probe_directory(path: PurePath) -> DirStat: # noqa: RET503 Ruff false-positive, Missing explicit `return` at the end of function
            if path == self.root_dir / subdir_1:
                self.assertNotIn(self.root_dir / subdir_1, list_of_deleted_directories)
                self.assertIn(self.root_dir / file_2, list_of_deleted_files)
                return DirStat(path, does_exist=True, is_empty=True)
            if path == self.root_dir / subdir_2:
                self.assertNotIn(self.root_dir / subdir_2, list_of_deleted_directories)
                self.assertIn(self.root_dir / subdir_3, list_of_deleted_directories)
                self.assertIn(self.root_dir / file_2, list_of_deleted_files)
                self.assertIn(self.root_dir / file_3, list_of_deleted_files)
                self.assertIn(self.root_dir / file_4, list_of_deleted_files)
                return DirStat(path, does_exist=True, is_empty=False)
            if path == self.root_dir / subdir_3:
                self.assertNotIn(self.root_dir / subdir_3, list_of_deleted_directories)
                self.assertIn(self.root_dir / file_3, list_of_deleted_files)
                self.assertIn(self.root_dir / file_4, list_of_deleted_files)
                return DirStat(path, does_exist=True, is_empty=True)
            self.fail(f"Unexpected probe of directory '{path}'")

        self.filesystem.delete_file = Mock(side_effect=mock_delete_file)
        self.filesystem.delete_directory = Mock(side_effect=mock_delete_directory)
        self.filesystem.probe_directory = Mock(side_effect=mock_probe_directory)

        perform_delete_action(self.root_dir, delete_action, self.normal_printer, self.warning_printer, self.filesystem)

        self.filesystem.delete_file.assert_has_calls([
            call(self.root_dir / file_1),
            call(self.root_dir / file_2),
            call(self.root_dir / file_3),
            call(self.root_dir / file_4),
        ])
        self.filesystem.delete_directory.assert_has_calls([
            call(self.root_dir / subdir_1),
            call(self.root_dir / subdir_3),
        ])

    def test_raises_error_when_deleting_missing_mandatory_file(self) -> None:
        missing_file: PurePath = PurePath('does-not-exist.dat')

        delete_action = InterfaceMock(IDeleteFilesAction,
            files = PropertyMock(return_value=[
                InterfaceMock(IDeleteFile,
                    must_exist = PropertyMock(return_value=True),
                    filename = PropertyMock(return_value=missing_file),
                ),
            ]),
        )

        self.filesystem.delete_file = Mock(side_effect=FileNotFoundError())

        with self.assertRaises(PerformUpdateError) as ex:
            perform_delete_action(self.root_dir, delete_action, self.normal_printer, self.warning_printer, self.filesystem)

        self.assertTrue(str(ex.exception).startswith(f"Failed to remove file '{self.root_dir / missing_file}': "))
        self.filesystem.delete_file.assert_called_once_with(self.root_dir / missing_file)

    def test_ignores_missing_optional_file_when_removing_single_file_from_directory(self) -> None:
        missing_file: PurePath = PurePath('does-not-exist.dat')

        delete_action = InterfaceMock(IDeleteFilesAction,
            files = PropertyMock(return_value=[
                InterfaceMock(IDeleteFile,
                    must_exist = PropertyMock(return_value=False),
                    filename = PropertyMock(return_value=missing_file),
                ),
            ]),
        )

        self.filesystem.delete_file = Mock(side_effect=FileNotFoundError())

        perform_delete_action(self.root_dir, delete_action, self.normal_printer, self.warning_printer, self.filesystem)

        self.filesystem.delete_file.assert_called_once_with(self.root_dir / missing_file)

    def test_ignores_missing_optional_file_when_removing_multiple_files_from_directory(self) -> None:
        file_1: PurePath = PurePath('mango.txt')
        file_2: PurePath = PurePath('banana.dat')
        missing_file: PurePath = PurePath('does-not-exist.dat')

        delete_action = InterfaceMock(IDeleteFilesAction,
            files = PropertyMock(return_value=[
                InterfaceMock(IDeleteFile,
                    must_exist = PropertyMock(return_value=True),
                    filename = PropertyMock(return_value=file_1),
                ),
                InterfaceMock(IDeleteFile,
                    must_exist = PropertyMock(return_value=False),
                    filename = PropertyMock(return_value=missing_file),
                ),
                InterfaceMock(IDeleteFile,
                    must_exist = PropertyMock(return_value=False),
                    filename = PropertyMock(return_value=file_2),
                ),
            ]),
        )

        self.filesystem.delete_file = Mock()
        when(self.filesystem).delete_file(self.root_dir / file_1).thenReturn(None)
        when(self.filesystem).delete_file(self.root_dir / file_2).thenReturn(None)
        when(self.filesystem).delete_file(self.root_dir / missing_file).thenRaise(FileNotFoundError)

        perform_delete_action(self.root_dir, delete_action, self.normal_printer, self.warning_printer, self.filesystem)

    def test_ignores_missing_directories_when_deleting_optional_missing_file(self) -> None:
        missing_file: PurePath = PurePath('subdir1', 'subdir2', 'does-not-exist.dat')

        delete_action = InterfaceMock(IDeleteFilesAction,
            files = PropertyMock(return_value=[
                InterfaceMock(IDeleteFile,
                    must_exist = PropertyMock(return_value=False),
                    filename = PropertyMock(return_value=missing_file),
                ),
            ]),
        )

        def mock_delete_file(path: PurePath) -> None:
            if path == self.root_dir / missing_file:
                raise FileNotFoundError
        def mock_probe_directory(path: PurePath) -> DirStat:
            return DirStat(path, does_exist=False, is_empty=True)
        self.filesystem.delete_file = Mock(side_effect=mock_delete_file)
        self.filesystem.probe_directory = Mock(side_effect=mock_probe_directory)

        perform_delete_action(self.root_dir, delete_action, self.normal_printer, self.warning_printer, self.filesystem)

        self.filesystem.delete_file.assert_has_calls([
            call(self.root_dir / missing_file),
        ])
        self.filesystem.probe_directory.assert_has_calls([
            call(self.root_dir / missing_file.parent),
            call(self.root_dir / missing_file.parent.parent),
        ])

class TestPerformEmplaceAction(unittest.TestCase):
    @override
    def setUp(self) -> None:
        self.root_dir: PurePath = PurePath('not-a-real-root-path')
        self.temp_dir: PurePath = PurePath('not-a-real-temp-path')
        self.mock_temp_directory = InterfaceMock(ITempDirectory)
        self.printer = InterfaceMock(IPrinter,
            writeln = Mock(),
        )
        self.filesystem = InterfaceMock(IFileSystem)

    def test_empty_list_of_files_does_nothing(self) -> None:
        emplace_action = InterfaceMock(IEmplaceFilesAction,
            files = PropertyMock(return_value=[]),
        )
        temp_directory = InterfaceMock(ITempDirectory)

        perform_emplace_action(self.root_dir, temp_directory, emplace_action, self.printer, self.filesystem)

    def test_files_without_subdirectories_are_emplaced(self) -> None:
        file_1_source_name: str = 'abcd'
        file_1_target = PurePath('mango.txt')
        file_2_source_name: str = '1234'
        file_2_target = PurePath('something.dat')

        emplace_action = InterfaceMock(IEmplaceFilesAction,
            files = PropertyMock(return_value=[
                InterfaceMock(IEmplaceFile,
                    source_filename = PropertyMock(return_value=PurePath(file_1_source_name)),
                    target_filename = PropertyMock(return_value=file_1_target),
                ),
                InterfaceMock(IEmplaceFile,
                    source_filename = PropertyMock(return_value=PurePath(file_2_source_name)),
                    target_filename = PropertyMock(return_value=file_2_target),
                ),
            ]),
        )

        self.filesystem.copy_file = Mock()
        self.filesystem.create_directory_and_parents_if_needed = Mock()
        self.mock_temp_directory.path_of = Mock()
        when(self.mock_temp_directory).path_of(file_1_source_name).thenReturn(self.temp_dir / file_1_source_name)
        when(self.mock_temp_directory).path_of(file_2_source_name).thenReturn(self.temp_dir / file_2_source_name)

        perform_emplace_action(self.root_dir, self.mock_temp_directory, emplace_action, self.printer, self.filesystem)

        self.filesystem.create_directory_and_parents_if_needed.assert_has_calls([
            call(self.root_dir / file_1_target.parent),
            call(self.root_dir / file_2_target.parent),
        ])
        self.filesystem.copy_file.assert_has_calls([
            call(self.temp_dir / file_1_source_name, self.root_dir / file_1_target),
            call(self.temp_dir / file_2_source_name, self.root_dir / file_2_target),
        ])

    def test_files_with_subdirectories_are_emplaced(self) -> None:
        file_1_source_name: str = 'abxd'
        file_1_target = PurePath('fruit', 'apple', 'mango.txt')
        file_2_source_name: str = '1234'
        file_2_target = PurePath('fruit', 'banana', 'something.dat')
        file_3_source_name: str = 'abe4'
        file_3_target= PurePath('pear', 'changes.txt')

        emplace_action = InterfaceMock(IEmplaceFilesAction,
            files = PropertyMock(return_value=[
                InterfaceMock(IEmplaceFile,
                    source_filename = PropertyMock(return_value=PurePath(file_1_source_name)),
                    target_filename = PropertyMock(return_value=file_1_target),
                ),
                InterfaceMock(IEmplaceFile,
                    source_filename = PropertyMock(return_value=PurePath(file_2_source_name)),
                    target_filename = PropertyMock(return_value=file_2_target),
                ),
                InterfaceMock(IEmplaceFile,
                    source_filename = PropertyMock(return_value=PurePath(file_3_source_name)),
                    target_filename = PropertyMock(return_value=file_3_target),
                ),
            ]),
        )

        self.filesystem.copy_file = Mock()
        self.filesystem.create_directory_and_parents_if_needed = Mock()
        self.mock_temp_directory.path_of = Mock()
        when(self.mock_temp_directory).path_of(file_1_source_name).thenReturn(self.temp_dir / file_1_source_name)
        when(self.mock_temp_directory).path_of(file_2_source_name).thenReturn(self.temp_dir / file_2_source_name)
        when(self.mock_temp_directory).path_of(file_3_source_name).thenReturn(self.temp_dir / file_3_source_name)

        perform_emplace_action(self.root_dir, self.mock_temp_directory, emplace_action, self.printer, self.filesystem)

        self.filesystem.create_directory_and_parents_if_needed.assert_has_calls([
            call(self.root_dir / file_1_target.parent),
            call(self.root_dir / file_2_target.parent),
            call(self.root_dir / file_3_target.parent),
        ])
        self.filesystem.copy_file.assert_has_calls([
            call(self.temp_dir / file_1_source_name, self.root_dir / file_1_target),
            call(self.temp_dir / file_2_source_name, self.root_dir / file_2_target),
            call(self.temp_dir / file_3_source_name, self.root_dir / file_3_target),
        ])

    def test_raises_error_when_source_file_doesnt_exist(self) -> None:
        file_1_source_name: str = 'missing'
        file_1_target = PurePath('mango.txt')

        emplace_action = InterfaceMock(IEmplaceFilesAction,
            files = PropertyMock(return_value=[
                InterfaceMock(IEmplaceFile,
                    source_filename = PropertyMock(return_value=PurePath(file_1_source_name)),
                    target_filename = PropertyMock(return_value=file_1_target),
                ),
            ]),
        )

        self.filesystem.copy_file = Mock()
        self.filesystem.create_directory_and_parents_if_needed = Mock()
        self.mock_temp_directory.path_of = Mock()
        when(self.filesystem).copy_file(self.temp_dir / file_1_source_name, self.root_dir / file_1_target).thenRaise(FileNotFoundError)
        when(self.mock_temp_directory).path_of(file_1_source_name).thenReturn(self.temp_dir / file_1_source_name)

        with self.assertRaises(PerformUpdateError) as ex:
            perform_emplace_action(self.root_dir, self.mock_temp_directory, emplace_action, self.printer, self.filesystem)

        self.assertTrue(str(ex.exception).startswith(f"Failed to copy asset '{self.temp_dir / file_1_source_name}' to '{self.root_dir / file_1_target}': "))

    def test_raises_error_when_file_cannot_be_written(self) -> None:
        file_1_source_name: str = 'something.txt'
        file_1_target = PurePath('mango.txt')

        emplace_action = InterfaceMock(IEmplaceFilesAction,
            files = PropertyMock(return_value=[
                InterfaceMock(IEmplaceFile,
                    source_filename = PropertyMock(return_value=PurePath(file_1_source_name)),
                    target_filename = PropertyMock(return_value=file_1_target),
                ),
            ]),
        )

        self.filesystem.copy_file = Mock()
        self.filesystem.create_directory_and_parents_if_needed = Mock()
        self.mock_temp_directory.path_of = Mock()
        when(self.filesystem).copy_file(self.temp_dir / file_1_source_name, self.root_dir / file_1_target).thenRaise(PermissionError)
        when(self.mock_temp_directory).path_of(file_1_source_name).thenReturn(self.temp_dir / file_1_source_name)

        with self.assertRaises(PerformUpdateError) as ex:
            perform_emplace_action(self.root_dir, self.mock_temp_directory, emplace_action, self.printer, self.filesystem)

        self.assertTrue(str(ex.exception).startswith(f"Failed to copy asset '{self.temp_dir / file_1_source_name}' to '{self.root_dir / file_1_target}': "))

class TestPerformMoveAction(unittest.TestCase):
    @override
    def setUp(self) -> None:
        self.root_dir: PurePath = PurePath('not-a-real-root-path')
        super().setUp()
        self.printer = InterfaceMock(IPrinter,
            writeln = Mock(),
        )
        self.filesystem = InterfaceMock(IFileSystem)

    def test_empty_list_of_renames_does_nothing(self) -> None:
        move_action = InterfaceMock(IMoveFilesAction,
            files = PropertyMock(return_value=[]),
        )

        perform_move_action(self.root_dir, move_action, self.printer, self.filesystem)

    def test_list_of_files_to_rename(self) -> None:
        file_1_source: PurePath = PurePath('file1.txt')
        file_1_target: PurePath = file_1_source.with_name('newFilename.dat')
        file_2_source: PurePath = PurePath('something.org')
        file_2_target: PurePath = file_2_source.with_name('config.json')

        move_action = InterfaceMock(IMoveFilesAction,
            files = PropertyMock(return_value=[
                InterfaceMock(IMoveFile,
                    must_exist = PropertyMock(return_value=True),
                    original_filename = PropertyMock(return_value=file_1_source),
                    new_filename = PropertyMock(return_value=file_1_target),
                ),
                InterfaceMock(IMoveFile,
                    must_exist = PropertyMock(return_value=True),
                    original_filename = PropertyMock(return_value=file_2_source),
                    new_filename = PropertyMock(return_value=file_2_target),
                ),
            ]),
        )

        self.filesystem.move_file = Mock()

        perform_move_action(self.root_dir, move_action, self.printer, self.filesystem)

        self.filesystem.move_file.assert_has_calls([
            call(self.root_dir / file_1_source, self.root_dir / file_1_target),
            call(self.root_dir / file_2_source, self.root_dir / file_2_target),
        ])

    def test_raises_error_if_mandatory_file_cannot_be_renamed(self) -> None:
        file_1_source: PurePath = PurePath('missing.log')
        file_1_target: PurePath = file_1_source.with_name('newFilename.dat')

        move_action = InterfaceMock(IMoveFilesAction,
            files = PropertyMock(return_value=[
                InterfaceMock(IMoveFile,
                    must_exist = PropertyMock(return_value=True),
                    original_filename = PropertyMock(return_value=file_1_source),
                    new_filename = PropertyMock(return_value=file_1_target),
                ),
            ]),
        )

        self.filesystem.move_file = Mock()
        when(self.filesystem).move_file(self.root_dir / file_1_source, self.root_dir / file_1_target).thenRaise(FileNotFoundError)

        with self.assertRaises(PerformUpdateError) as ex:
            perform_move_action(self.root_dir, move_action, self.printer, self.filesystem)

        self.assertTrue(str(ex.exception).startswith(f"Failed to rename file '{self.root_dir / file_1_source}' to '{self.root_dir / file_1_target}': "))

    def test_ignores_optional_missing_file_cannot_be_renamed(self) -> None:
        file_1_source: PurePath = PurePath('missing.log')
        file_1_target: PurePath = file_1_source.with_name('newFilename.dat')

        move_action = InterfaceMock(IMoveFilesAction,
            files = PropertyMock(return_value=[
                InterfaceMock(IMoveFile,
                    must_exist = PropertyMock(return_value=False),
                    original_filename = PropertyMock(return_value=file_1_source),
                    new_filename = PropertyMock(return_value=file_1_target),
                ),
            ]),
        )

        self.filesystem.move_file = Mock()
        when(self.filesystem).move_file(self.root_dir / file_1_source, self.root_dir / file_1_target).thenRaise(FileNotFoundError)

        perform_move_action(self.root_dir, move_action, self.printer, self.filesystem)

class TestPerformSetAttributeAction(unittest.TestCase):
    @override
    def setUp(self) -> None:
        super().setUp()
        self.root_dir: PurePath = PurePath('not-a-real-root-path')
        self.printer = InterfaceMock(IPrinter,
            writeln = Mock(),
        )
        self.filesystem = InterfaceMock(IFileSystem)

    def test_file_attributes_are_set(self) -> None:
        file_1: PurePath = PurePath('file1.txt')
        file_2: PurePath = PurePath('mango.log')
        file_3: PurePath = PurePath('config.dat')
        file_4: PurePath = PurePath('apple.cue')

        set_attributes_action = InterfaceMock(ISetFilesAttributeAction,
            files = PropertyMock(return_value=[
                InterfaceMock(ISetFileAttribute,
                    filename = PropertyMock(return_value=file_1),
                    is_readonly = PropertyMock(return_value=False),
                    is_executable = PropertyMock(return_value=False),
                ),
                InterfaceMock(ISetFileAttribute,
                    filename = PropertyMock(return_value=file_2),
                    is_readonly = PropertyMock(return_value=True),
                    is_executable = PropertyMock(return_value=False),
                ),
                InterfaceMock(ISetFileAttribute,
                    filename = PropertyMock(return_value=file_3),
                    is_readonly = PropertyMock(return_value=False),
                    is_executable = PropertyMock(return_value=True),
                ),
                InterfaceMock(ISetFileAttribute,
                    filename = PropertyMock(return_value=file_4),
                    is_readonly = PropertyMock(return_value=True),
                    is_executable = PropertyMock(return_value=True),
                ),
            ]),
        )

        self.filesystem.set_file_attributes = Mock(return_value=[])

        perform_set_attribute_action(self.root_dir, set_attributes_action, self.printer, self.filesystem)

        self.filesystem.set_file_attributes.assert_has_calls([
            call(self.root_dir / file_1, is_executable=False, is_writeable=True),
            call(self.root_dir / file_2, is_executable=False, is_writeable=False),
            call(self.root_dir / file_3, is_executable=True, is_writeable=True),
            call(self.root_dir / file_4, is_executable=True, is_writeable=False),
        ])

    def test_raises_error_if_attribute_cannot_be_set(self) -> None:
        file_1: PurePath = PurePath('file1.txt')

        set_attributes_action = InterfaceMock(ISetFilesAttributeAction,
            files = PropertyMock(return_value=[
                InterfaceMock(ISetFileAttribute,
                    filename = PropertyMock(return_value=file_1),
                    is_readonly = PropertyMock(return_value=False),
                    is_executable = PropertyMock(return_value=True),
                ),
            ]),
        )

        self.filesystem.set_file_attributes = Mock()
        when(self.filesystem).set_file_attributes(self.root_dir / file_1, is_executable=True, is_writeable=True).thenRaise(FileNotFoundError)

        with self.assertRaises(PerformUpdateError) as ex:
            perform_set_attribute_action(self.root_dir, set_attributes_action, self.printer, self.filesystem)

        self.assertTrue(str(ex.exception).startswith(f"Failed to set attributes of file '{self.root_dir / file_1}': "))

class TestPerformUpdate(unittest.TestCase):
    @staticmethod
    def test_performs_actions_in_key_order() -> None:
        """Test a sequence of actions are performed according to their key order.

                      1                 2                 3                 4                 5                 6                 7
        --------------------------------------------------------------------------------------------------------------------------------------------
                DEL file1.txt     MOV mango.log     ATR config.dat    MOV config.dat    EMP config.dat    MOV apple.cue     ATR orange.exe
                                   -> file1.txt      -> +exe           -> mango.log      -> (E)            -> orange.exe     -> +exe
        --------------------------------------------------------------------------------------------------------------------------------------------
        file1.txt(A)                        file1.txt(B)      file1.txt(B)      file1.txt(B)      file1.txt(B)      file1.txt(B)      file1.txt(B)
        mango.log(B)      mango.log(B)                                          mango.log(C)x     mango.log(C)x     mango.log(C)x     mango.log(C)x
        config.dat(C)     config.dat(C)     config.dat(C)     config.dat(C)x                      config.dat(E)     config.dat(E)     config.dat(E)
        apple.cue(D)      apple.cue(D)      apple.cue(D)      apple.cue(D)      apple.cue(D)      apple.cue(D)      orange.exe(D)     orange.exe(D)x
        """
        root_dir = PurePath('not-a-real-root-path')
        temp_dir = PurePath('not-a-real-temp-path')

        file_new = PurePath('87f4g0gA')
        file_1 = PurePath('file1.txt')
        file_2 = PurePath('mango.log')
        file_3 = PurePath('config.dat')
        file_4 = PurePath('apple.cue')
        file_5 = PurePath('orange.exe')

        update_sequence = InterfaceMock(IUpdateSequence,
            root_directory = PropertyMock(return_value=root_dir),
            temp_directory = PropertyMock(return_value=temp_dir),
            move_files_actions = PropertyMock(return_value={
                2: InterfaceMock(IMoveFilesAction,
                    files = PropertyMock(return_value=[
                        InterfaceMock(IMoveFile,
                            original_filename = PropertyMock(return_value=file_2),
                            new_filename = PropertyMock(return_value=file_1),
                            must_exist = PropertyMock(return_value=True),
                        ),
                    ]),
                ),
                4: InterfaceMock(IMoveFilesAction,
                    files = PropertyMock(return_value=[
                        InterfaceMock(IMoveFile,
                            original_filename = PropertyMock(return_value=file_3),
                            new_filename = PropertyMock(return_value=file_2),
                            must_exist = PropertyMock(return_value=True),
                        ),
                    ]),
                ),
                6: InterfaceMock(IMoveFilesAction,
                    files = PropertyMock(return_value=[
                        InterfaceMock(IMoveFile,
                            original_filename = PropertyMock(return_value=file_4),
                            new_filename = PropertyMock(return_value=file_5),
                            must_exist = PropertyMock(return_value=False),
                        ),
                    ]),
                ),
            }),
            emplace_files_actions = PropertyMock(return_value={
                5: InterfaceMock(IEmplaceFilesAction,
                    files = PropertyMock(return_value=[
                        InterfaceMock(IEmplaceFile,
                            source_filename = PropertyMock(return_value=file_new),
                            target_filename = PropertyMock(return_value=file_3),
                        ),
                    ]),
                ),
            }),
            delete_files_actions = PropertyMock(return_value={
                1: InterfaceMock(IDeleteFilesAction,
                    files = PropertyMock(return_value=[
                        InterfaceMock(IDeleteFile,
                            filename = PropertyMock(return_value=file_1),
                        ),
                    ]),
                ),
            }),
            set_files_attribute_actions = PropertyMock(return_value={
                3: InterfaceMock(ISetFilesAttributeAction,
                    files = PropertyMock(return_value=[
                        InterfaceMock(ISetFileAttribute,
                            filename = PropertyMock(return_value=file_3),
                            is_readonly = PropertyMock(return_value=False),
                            is_executable = PropertyMock(return_value=True),
                        ),
                    ]),
                ),
                7: InterfaceMock(ISetFilesAttributeAction,
                    files = PropertyMock(return_value=[
                        InterfaceMock(ISetFileAttribute,
                            filename = PropertyMock(return_value=file_5),
                            is_readonly = PropertyMock(return_value=False),
                            is_executable = PropertyMock(return_value=True),
                        ),
                    ]),
                ),
            }),
        )

        normal_printer = InterfaceMock(IPrinter,
            writeln = Mock(),
        )
        warning_printer = InterfaceMock(IPrinter)
        filesystem = InterfaceMock(IFileSystem,
            copy_file = Mock(),
            move_file = Mock(),
            delete_file = Mock(),
            set_file_attributes = Mock(return_value=[]),
            create_directory_and_parents_if_needed = Mock(),
        )
        temp_directory = InterfaceMock(ITempDirectory,
            path_of = Mock(),
        )
        when(temp_directory).path_of(str(file_new)).thenReturn(temp_dir / f'{_TEMP_FILE_PREFIX}{file_new}')
        parent_mock = Mock()
        parent_mock.attach_mock(filesystem.copy_file, 'copy_file')
        parent_mock.attach_mock(filesystem.move_file, 'move_file')
        parent_mock.attach_mock(filesystem.delete_file, 'delete_file')
        parent_mock.attach_mock(filesystem.set_file_attributes, 'set_file_attributes')
        parent_mock.attach_mock(filesystem.create_directory_and_parents_if_needed, 'create_directory_and_parents_if_needed')

        when(parent_mock).set_file_attributes(root_dir / file_3, is_executable=True, is_writeable=True).thenReturn(['executable'])
        when(parent_mock).set_file_attributes(root_dir / file_5, is_executable=True, is_writeable=True).thenReturn(['executable'])

        perform_update(temp_directory, update_sequence, normal_printer, warning_printer, filesystem)

        parent_mock.assert_has_calls([
            call.delete_file(root_dir / file_1),
            call.move_file(root_dir / file_2, root_dir / file_1),
            call.set_file_attributes(root_dir / file_3, is_executable=True, is_writeable=True),
            call.move_file(root_dir / file_3, root_dir / file_2),
            call.create_directory_and_parents_if_needed((root_dir / file_3).parent),
            call.copy_file(temp_dir / f'{_TEMP_FILE_PREFIX}{file_new}', root_dir / file_3),
            call.move_file(root_dir / file_4, root_dir / file_5),
            call.set_file_attributes(root_dir / file_5, is_executable=True, is_writeable=True),
        ])
