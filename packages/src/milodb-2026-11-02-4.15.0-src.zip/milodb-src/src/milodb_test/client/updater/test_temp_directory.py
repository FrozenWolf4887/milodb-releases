# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import unittest
from pathlib import PurePath
from typing import override
from unittest.mock import Mock, call
from mockito import when # type: ignore[import-untyped]
from milodb.client.updater.i_temp_directory import TempDirectoryError
from milodb.client.updater.temp_directory import TempDirectory
from milodb.client.util.file_system import IFileSystem
from milodb_test.client.test.fake_data import FAKE_DATA_A, FAKE_DATA_B
from milodb_test.common.test.strict_mock import InterfaceMock

_FILE_PREFIX: str = 'mdbu-'

class TestPerformDeleteAction(unittest.TestCase):
    @override
    def setUp(self) -> None:
        self.temp_dir: PurePath = PurePath('not-a-real-temp-dir')
        self.filesystem = InterfaceMock(IFileSystem)

    def test_directory_remains_empty_on_construction(self) -> None:
        TempDirectory(self.temp_dir, self.filesystem)

    def test_stored_files_are_prefixed(self) -> None:
        self.filesystem.write_file_bytes = Mock()
        self.filesystem.set_file_attributes = Mock(return_value=[])

        temp_directory: TempDirectory = TempDirectory(self.temp_dir, self.filesystem)
        temp_directory.store_file('test.file', FAKE_DATA_A)
        temp_directory.store_file('something', FAKE_DATA_B)

        self.filesystem.write_file_bytes.assert_has_calls([
            call(self.temp_dir / f'{_FILE_PREFIX}test.file', FAKE_DATA_A),
            call(self.temp_dir / f'{_FILE_PREFIX}something', FAKE_DATA_B),
        ])

    def test_store_file_with_directory_raises_error(self) -> None:
        temp_directory: TempDirectory = TempDirectory(self.temp_dir, self.filesystem)

        filename: str = 'test/file'
        with self.assertRaises(TempDirectoryError) as ex:
            temp_directory.store_file(filename, FAKE_DATA_A)

        self.assertEqual(f"Temporary filename '{filename}' may not contain directory components", str(ex.exception))

    def test_stored_files_can_be_set_as_executable(self) -> None:
        self.filesystem.write_file_bytes = Mock()
        self.filesystem.set_file_attributes = Mock()

        temp_directory: TempDirectory = TempDirectory(self.temp_dir, self.filesystem)
        temp_directory.store_file('test.file', FAKE_DATA_A)
        temp_directory.store_file('something', FAKE_DATA_B, is_executable=True)

        self.filesystem.set_file_attributes.assert_has_calls([
            call(self.temp_dir / f'{_FILE_PREFIX}test.file', is_executable=False),
            call(self.temp_dir / f'{_FILE_PREFIX}something', is_executable=True),
        ])

    def test_destroy_will_remove_empty_directory(self) -> None:
        self.filesystem.iterate_directory = Mock()
        self.filesystem.delete_directory = Mock()
        when(self.filesystem).iterate_directory(self.temp_dir).thenReturn(())

        temp_directory: TempDirectory = TempDirectory(self.temp_dir, self.filesystem)
        temp_directory.destroy()

        self.filesystem.delete_directory.assert_called_once_with(self.temp_dir)

    def test_destroy_will_remove_directory_with_stored_existing_files_with_prefix(self) -> None:
        self.filesystem.iterate_directory = Mock()
        self.filesystem.delete_directory = Mock()
        self.filesystem.delete_file = Mock()
        when(self.filesystem).iterate_directory(self.temp_dir).thenReturn((
            self.temp_dir / f'{_FILE_PREFIX}test.file',
            self.temp_dir / f'{_FILE_PREFIX}something',
        ))

        temp_directory: TempDirectory = TempDirectory(self.temp_dir, self.filesystem)
        temp_directory.destroy()

        self.filesystem.delete_file.assert_has_calls([
            call(self.temp_dir / f'{_FILE_PREFIX}test.file'),
            call(self.temp_dir / f'{_FILE_PREFIX}something'),
        ])
        self.filesystem.delete_directory.assert_called_once_with(self.temp_dir)

    def test_destroy_raises_error_when_file_exists_without_prefix(self) -> None:
        self.filesystem.iterate_directory = Mock()
        self.filesystem.delete_directory = Mock()
        self.filesystem.delete_file = Mock()
        when(self.filesystem).iterate_directory(self.temp_dir).thenReturn((
            self.temp_dir / f'{_FILE_PREFIX}test.file',
            self.temp_dir / 'something',
        ))

        temp_directory: TempDirectory = TempDirectory(self.temp_dir, self.filesystem)

        with self.assertRaises(TempDirectoryError) as ex:
            temp_directory.destroy()

        self.assertEqual(f"Refusing to delete temp file '{self.temp_dir / 'something'}' because it doesn't start with '{_FILE_PREFIX}'", str(ex.exception))
