# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import time
import unittest
from collections.abc import Iterable
from pathlib import PurePath
from typing import TYPE_CHECKING, override
from unittest.mock import ANY, Mock, PropertyMock, call
from mockito import when # type: ignore[import-untyped]
from milodb.client.updater.i_temp_directory import ITempDirectory, TempDirectoryError
from milodb.client.updater.manifest.common_manifest import IVersionNumber
from milodb.client.updater.manifest.local_manifest import ILocalManifest
from milodb.client.updater.manifest.update_directory import IAsset, IAssetRegister
from milodb.client.updater.manifest.version_manifest import ICoreFile
from milodb.client.updater.prepare_update import PrepareUpdateError, backup_files, determine_update_sequence, fetch_assets_to_temp_directory
from milodb.client.updater.update_strategy import BackupFileSet, ConfigFileChanges, CoreFileChanges, FileRename, UpdateStrategy
from milodb.client.util.file_system import FileStat, IFileSystem
from milodb.client.view.progress_display import IProgressDisplay
from milodb.common.internet.i_scraper import IUrlScraper, ScrapeResult
from milodb.common.output.print.i_printer import IPrinter
from milodb_test.client.test.fake_data import FAKE_DATA_A, FAKE_DATA_B, FAKE_DATA_C, FAKE_DATA_D, FAKE_DATA_F, FAKE_DATA_G, FAKE_HEXDIGEST_A, FAKE_HEXDIGEST_B, FAKE_HEXDIGEST_C, FAKE_HEXDIGEST_D, FAKE_HEXDIGEST_G
from milodb_test.common.test.strict_mock import DataclassMock, InterfaceMock
if TYPE_CHECKING:
    from collections.abc import Sequence
    from milodb.client.updater.manifest.update_sequence_schema import UpdateSequenceSchema

FAKE_DIRECTORY_URL: str = 'https://example.com'

FAKE_URL_A: str = 'Morbi tincidunt augue interdum velit euismod in'
FAKE_URL_B: str = 'Elementum sagittis vitae et leo. Erat pellentesque adipiscing commodo elit at imperdiet dui'
FAKE_URL_C: str = 'Dui vivamus arcu felis bibendum ut tristique'
FAKE_URL_D: str = 'Consectetur a erat nam at lectus urna duis. Lacinia at quis risus sed vulputate odio'
FAKE_URL_E: str = 'Turpis nunc eget lorem dolor sed viverra'
FAKE_URL_F: str = 'Vitae justo eget magna fermentum iaculis'
FAKE_URL_FILEPATH_A: str = 'euismod'
FAKE_URL_FILEPATH_B: str = 'sagittis'
FAKE_URL_FILEPATH_C: str = 'tristique'
FAKE_URL_FILEPATH_D: str = 'lectus'
FAKE_URL_FILEPATH_E: str = 'vulputate'
FAKE_URL_FILEPATH_F: str = 'justo'

_STUB_DATETIME_2020: time.struct_time = time.strptime('2020-12-31 13:45:28', '%Y-%m-%d %H:%M:%S')

class TestPrepareUpdateFetchAssetsToTempDirectory(unittest.TestCase):
    @override
    def setUp(self) -> None:
        super().setUp()
        self.asset_register = InterfaceMock(IAssetRegister)
        self.temp_directory = InterfaceMock(ITempDirectory)
        self.url_scraper = InterfaceMock(IUrlScraper)
        self.progress_display = InterfaceMock(IProgressDisplay,
            normal_printer = PropertyMock(return_value=InterfaceMock(IPrinter)),
        )

        self.core_file_1 = InterfaceMock(ICoreFile,
            digest = PropertyMock(return_value=FAKE_HEXDIGEST_A),
            filename = PropertyMock(return_value=PurePath('mango.txt')),
        )
        self.core_file_2 = InterfaceMock(ICoreFile,
            digest = PropertyMock(return_value=FAKE_HEXDIGEST_B),
            filename = PropertyMock(return_value=PurePath('fruit.dat')),
        )
        self.core_file_3 = InterfaceMock(ICoreFile,
            digest = PropertyMock(return_value=FAKE_HEXDIGEST_C),
            filename = PropertyMock(return_value=PurePath('apple.exe')),
        )
        self.core_file_4 = InterfaceMock(ICoreFile,
            digest = PropertyMock(return_value=FAKE_HEXDIGEST_D),
            filename = PropertyMock(return_value=PurePath('pear.log')),
        )

    def test_given_no_file_changes_does_nothing(self) -> None:
        self.progress_display.normal_printer.writeln = Mock()

        update_strategy = DataclassMock(UpdateStrategy,
            core_file_changes = DataclassMock(CoreFileChanges,
                list_of_new_files_to_acquire = [],
                list_of_missing_files_to_acquire = [],
                list_of_changed_files_to_acquire = [],
            ),
            asset_register = self.asset_register,
        )

        list_of_files: Sequence[ICoreFile] = fetch_assets_to_temp_directory(update_strategy, FAKE_DIRECTORY_URL, self.temp_directory, self.url_scraper, self.progress_display)

        self.assertFalse(list_of_files)
        self.progress_display.normal_printer.writeln.assert_called_once_with('Downloading 0 assets')

    def test_downloads_and_stores_file_to_temp_directory(self) -> None:
        self.progress_display.normal_printer.writeln = Mock()
        self.progress_display.set_activity_category = Mock()
        self.progress_display.set_activity_text = Mock()
        self.asset_register.resolve_asset_url = Mock()
        self.asset_register.assets = PropertyMock()
        self.asset_register.assets.get = Mock()
        self.url_scraper.try_scrape_url = Mock()
        self.temp_directory.store_file = Mock()
        asset_a = InterfaceMock(IAsset,
            size = PropertyMock(return_value=len(FAKE_DATA_A)),
        )
        when(self.asset_register).resolve_asset_url(FAKE_DIRECTORY_URL, self.core_file_1.digest).thenReturn(FAKE_URL_A)
        when(self.asset_register.assets).get(self.core_file_1.digest).thenReturn(asset_a)
        when(self.url_scraper).try_scrape_url(FAKE_URL_A, ANY).thenReturn(ScrapeResult(None, None, FAKE_DATA_A))

        update_strategy = DataclassMock(UpdateStrategy,
            core_file_changes = DataclassMock(CoreFileChanges,
                list_of_new_files_to_acquire = [self.core_file_1],
                list_of_missing_files_to_acquire = [],
                list_of_changed_files_to_acquire = [],
            ),
            asset_register = self.asset_register,
        )

        list_of_files: Sequence[ICoreFile] = fetch_assets_to_temp_directory(update_strategy, FAKE_DIRECTORY_URL, self.temp_directory, self.url_scraper, self.progress_display)

        self.assertSequenceEqual([self.core_file_1], list_of_files)
        self.progress_display.set_activity_category.assert_called_once_with('Downloading')
        self.progress_display.set_activity_text.assert_called_once_with(str(self.core_file_1.filename))
        self.progress_display.normal_printer.writeln.assert_has_calls([
            call('Downloading 1 assets'),
            call(f"Fetching asset '{self.core_file_1.digest}' for file '{self.core_file_1.filename}'"),
        ])
        self.temp_directory.store_file.assert_called_once_with(str(self.core_file_1.digest), FAKE_DATA_A)

    def test_downloads_and_stores_multiple_files_to_temp_directory(self) -> None:
        self.progress_display.normal_printer.writeln = Mock()
        self.progress_display.set_activity_category = Mock()
        self.progress_display.set_activity_text = Mock()
        self.asset_register.resolve_asset_url = Mock()
        self.asset_register.assets = PropertyMock()
        self.asset_register.assets.get = Mock()
        self.url_scraper.try_scrape_url = Mock()
        self.temp_directory.store_file = Mock()
        asset_a = InterfaceMock(IAsset,
            size = PropertyMock(return_value=len(FAKE_DATA_A)),
        )
        asset_b = InterfaceMock(IAsset,
            size = PropertyMock(return_value=len(FAKE_DATA_B)),
        )
        asset_c = InterfaceMock(IAsset,
            size = PropertyMock(return_value=len(FAKE_DATA_C)),
        )
        asset_d = InterfaceMock(IAsset,
            size = PropertyMock(return_value=len(FAKE_DATA_D)),
        )
        when(self.asset_register).resolve_asset_url(FAKE_DIRECTORY_URL, self.core_file_1.digest).thenReturn(FAKE_URL_A)
        when(self.asset_register).resolve_asset_url(FAKE_DIRECTORY_URL, self.core_file_2.digest).thenReturn(FAKE_URL_B)
        when(self.asset_register).resolve_asset_url(FAKE_DIRECTORY_URL, self.core_file_3.digest).thenReturn(FAKE_URL_C)
        when(self.asset_register).resolve_asset_url(FAKE_DIRECTORY_URL, self.core_file_4.digest).thenReturn(FAKE_URL_D)
        when(self.asset_register.assets).get(self.core_file_1.digest).thenReturn(asset_a)
        when(self.asset_register.assets).get(self.core_file_2.digest).thenReturn(asset_b)
        when(self.asset_register.assets).get(self.core_file_3.digest).thenReturn(asset_c)
        when(self.asset_register.assets).get(self.core_file_4.digest).thenReturn(asset_d)
        when(self.url_scraper).try_scrape_url(FAKE_URL_A, ANY).thenReturn(ScrapeResult(None, None, FAKE_DATA_A))
        when(self.url_scraper).try_scrape_url(FAKE_URL_B, ANY).thenReturn(ScrapeResult(None, None, FAKE_DATA_B))
        when(self.url_scraper).try_scrape_url(FAKE_URL_C, ANY).thenReturn(ScrapeResult(None, None, FAKE_DATA_C))
        when(self.url_scraper).try_scrape_url(FAKE_URL_D, ANY).thenReturn(ScrapeResult(None, None, FAKE_DATA_D))

        update_strategy = DataclassMock(UpdateStrategy,
            core_file_changes = DataclassMock(CoreFileChanges,
                list_of_new_files_to_acquire = [
                    self.core_file_4,
                ],
                list_of_missing_files_to_acquire = [
                    self.core_file_1,
                ],
                list_of_changed_files_to_acquire = [
                    self.core_file_2,
                    self.core_file_3,
                ],
            ),
            asset_register = self.asset_register,
        )

        list_of_files: Sequence[ICoreFile] = fetch_assets_to_temp_directory(update_strategy, FAKE_DIRECTORY_URL, self.temp_directory, self.url_scraper, self.progress_display)

        self.assertCountEqual( [
                self.core_file_1,
                self.core_file_2,
                self.core_file_3,
                self.core_file_4,
            ], list_of_files)
        self.progress_display.set_activity_category.assert_called_once_with('Downloading')
        self.progress_display.set_activity_text.assert_has_calls([
            call(str(self.core_file_1.filename)),
            call(str(self.core_file_2.filename)),
            call(str(self.core_file_3.filename)),
            call(str(self.core_file_4.filename)),
        ], any_order=True)
        self.progress_display.normal_printer.writeln.assert_has_calls([
            call('Downloading 4 assets'),
            call(f"Fetching asset '{self.core_file_1.digest}' for file '{self.core_file_1.filename}'"),
            call(f"Fetching asset '{self.core_file_2.digest}' for file '{self.core_file_2.filename}'"),
            call(f"Fetching asset '{self.core_file_3.digest}' for file '{self.core_file_3.filename}'"),
            call(f"Fetching asset '{self.core_file_4.digest}' for file '{self.core_file_4.filename}'"),
        ], any_order=True)
        self.temp_directory.store_file.assert_has_calls([
            call(str(self.core_file_1.digest), FAKE_DATA_A),
            call(str(self.core_file_2.digest), FAKE_DATA_B),
            call(str(self.core_file_3.digest), FAKE_DATA_C),
            call(str(self.core_file_4.digest), FAKE_DATA_D),
        ], any_order=True)

    def test_raises_error_when_web_scraper_cannot_download_file(self) -> None:
        self.progress_display.normal_printer.writeln = Mock()
        self.progress_display.set_activity_category = Mock()
        self.progress_display.set_activity_text = Mock()
        self.asset_register.resolve_asset_url = Mock()
        self.asset_register.assets = PropertyMock()
        self.asset_register.assets.get = Mock()
        self.url_scraper.try_scrape_url = Mock()
        when(self.asset_register).resolve_asset_url(FAKE_DIRECTORY_URL, self.core_file_1.digest).thenReturn(FAKE_URL_A)
        when(self.asset_register.assets).get(self.core_file_1.digest).thenReturn(InterfaceMock(IAsset, size=PropertyMock(return_value=len(FAKE_DATA_A))))
        when(self.url_scraper).try_scrape_url(FAKE_URL_A, ANY).thenReturn(ScrapeResult('error during scrape', None, b''))

        update_strategy = DataclassMock(UpdateStrategy,
            core_file_changes = DataclassMock(CoreFileChanges,
                list_of_new_files_to_acquire = [self.core_file_1],
                list_of_missing_files_to_acquire = [],
                list_of_changed_files_to_acquire = [],
            ),
            asset_register = self.asset_register,
        )

        with self.assertRaises(PrepareUpdateError) as ex:
            fetch_assets_to_temp_directory(update_strategy, FAKE_DIRECTORY_URL, self.temp_directory, self.url_scraper, self.progress_display)

        self.assertEqual(f"Asset '{self.core_file_1.digest}' for file '{self.core_file_1.filename}' with URL '{FAKE_URL_A}' download error: error during scrape", str(ex.exception))

    def test_raises_error_when_file_cannot_be_stored_in_temp_directory(self) -> None:
        self.progress_display.normal_printer.writeln = Mock()
        self.progress_display.set_activity_category = Mock()
        self.progress_display.set_activity_text = Mock()
        self.asset_register.resolve_asset_url = Mock()
        self.asset_register.assets = PropertyMock()
        self.asset_register.assets.get = Mock()
        self.url_scraper.try_scrape_url = Mock()
        self.temp_directory.store_file = Mock()
        asset_a = InterfaceMock(IAsset,
            size = PropertyMock(return_value=len(FAKE_DATA_A)),
        )
        when(self.asset_register).resolve_asset_url(FAKE_DIRECTORY_URL, self.core_file_1.digest).thenReturn(FAKE_URL_A)
        when(self.asset_register.assets).get(self.core_file_1.digest).thenReturn(asset_a)
        when(self.url_scraper).try_scrape_url(FAKE_URL_A, ANY).thenReturn(ScrapeResult(None, None, FAKE_DATA_A))
        when(self.temp_directory).store_file(str(self.core_file_1.digest), FAKE_DATA_A).thenRaise(TempDirectoryError('some issue'))

        update_strategy = DataclassMock(UpdateStrategy,
            core_file_changes = DataclassMock(CoreFileChanges,
                list_of_new_files_to_acquire = [self.core_file_1],
                list_of_missing_files_to_acquire = [],
                list_of_changed_files_to_acquire = [],
            ),
            asset_register = self.asset_register,
        )

        with self.assertRaises(PrepareUpdateError) as ex:
            fetch_assets_to_temp_directory(update_strategy, FAKE_DIRECTORY_URL, self.temp_directory, self.url_scraper, self.progress_display)

        self.assertEqual(f"Asset '{self.core_file_1.digest}' for file '{self.core_file_1.filename}' failed to store in temp directory: some issue", str(ex.exception))

    def test_raises_error_when_download_asset_has_size_mismatch(self) -> None:
        self.progress_display.normal_printer.writeln = Mock()
        self.progress_display.set_activity_category = Mock()
        self.progress_display.set_activity_text = Mock()
        self.asset_register.resolve_asset_url = Mock()
        self.asset_register.assets = PropertyMock()
        self.asset_register.assets.get = Mock()
        self.url_scraper.try_scrape_url = Mock()
        asset_f = InterfaceMock(IAsset,
            size = PropertyMock(return_value=len(FAKE_DATA_A) + 1),
        )
        when(self.asset_register).resolve_asset_url(FAKE_DIRECTORY_URL, self.core_file_1.digest).thenReturn(FAKE_URL_A)
        when(self.asset_register.assets).get(self.core_file_1.digest).thenReturn(asset_f)
        when(self.url_scraper).try_scrape_url(FAKE_URL_A, ANY).thenReturn(ScrapeResult(None, None, FAKE_DATA_A))

        update_strategy = DataclassMock(UpdateStrategy,
            core_file_changes = DataclassMock(CoreFileChanges,
                list_of_new_files_to_acquire = [self.core_file_1],
                list_of_missing_files_to_acquire = [],
                list_of_changed_files_to_acquire = [],
            ),
            asset_register = self.asset_register,
        )

        with self.assertRaises(PrepareUpdateError) as ex:
            fetch_assets_to_temp_directory(update_strategy, FAKE_DIRECTORY_URL, self.temp_directory, self.url_scraper, self.progress_display)

        self.assertEqual(f"Asset '{self.core_file_1.digest}' for file '{self.core_file_1.filename}' size mismatch: Expected {len(FAKE_DATA_A)+1:,} bytes, got {len(FAKE_DATA_A):,} bytes", str(ex.exception))

    def test_raises_error_when_download_asset_has_digest_mismatch(self) -> None:
        self.progress_display.normal_printer.writeln = Mock()
        self.progress_display.set_activity_category = Mock()
        self.progress_display.set_activity_text = Mock()
        self.asset_register.resolve_asset_url = Mock()
        self.asset_register.assets = PropertyMock()
        self.asset_register.assets.get = Mock()
        self.url_scraper.try_scrape_url = Mock()
        asset_f = InterfaceMock(IAsset,
            size = PropertyMock(return_value=len(FAKE_DATA_F)),
        )
        when(self.asset_register).resolve_asset_url(FAKE_DIRECTORY_URL, self.core_file_1.digest).thenReturn(FAKE_URL_F)
        when(self.asset_register.assets).get(self.core_file_1.digest).thenReturn(asset_f)
        when(self.url_scraper).try_scrape_url(FAKE_URL_F, ANY).thenReturn(ScrapeResult(None, None, FAKE_DATA_G))

        update_strategy = DataclassMock(UpdateStrategy,
            core_file_changes = DataclassMock(CoreFileChanges,
                list_of_new_files_to_acquire = [self.core_file_1],
                list_of_missing_files_to_acquire = [],
                list_of_changed_files_to_acquire = [],
            ),
            asset_register = self.asset_register,
        )

        with self.assertRaises(PrepareUpdateError) as ex:
            fetch_assets_to_temp_directory(update_strategy, FAKE_DIRECTORY_URL, self.temp_directory, self.url_scraper, self.progress_display)

        self.assertEqual(f"Asset '{self.core_file_1.digest}' for file '{self.core_file_1.filename}' integrity failure: Actual '{FAKE_HEXDIGEST_G}'", str(ex.exception))

class TestPrepareUpdateBackupFiles(unittest.TestCase):
    @override
    def setUp(self) -> None:
        super().setUp()

        self.root_dir: PurePath = PurePath('not-a-real-root-dir')
        self.timestamp: time.struct_time = _STUB_DATETIME_2020
        self.variant_name: str = 'bar'
        self.version_number = InterfaceMock(IVersionNumber,
            __str__ = Mock(return_value='hello-world'),
        )
        self.progress_display = InterfaceMock(IProgressDisplay,
            normal_printer = PropertyMock(return_value=InterfaceMock(IPrinter,
               writeln = Mock(),
            )),
            set_activity_category = Mock(),
            set_activity_text = Mock(),
            set_progress_percentage = Mock(),
        )
        self.filesystem = InterfaceMock(IFileSystem)

        self.expected_zip_filename: str = f'{_date_text(self.timestamp)}_{self.variant_name}_{self.version_number}.zip'

    def test_creates_empty_backup_zip_file_in_current_directory(self) -> None:
        update_strategy = DataclassMock(UpdateStrategy,
            root_directory = self.root_dir,
            local_manifest = InterfaceMock(ILocalManifest,
                variant_name = PropertyMock(return_value=self.variant_name),
                version_number = PropertyMock(return_value=self.version_number),
            ),
            backup_file_set = DataclassMock(BackupFileSet,
                list_of_core_files_to_backup = [],
                list_of_config_files_to_backup = [],
                list_of_clobbered_files_to_backup = [],
            ),
        )

        backup_subdir: PurePath = PurePath()
        def mock_write_zip_file(_zip_path: PurePath, source_path_iterator: Iterable[tuple[PurePath, PurePath]]) -> None:
            self.assertListEqual([], list(source_path_iterator))
        self.filesystem.write_zip_file = Mock(side_effect=mock_write_zip_file)
        self.filesystem.create_directory_and_parents_if_needed = Mock()

        backup_files(update_strategy, backup_subdir, self.timestamp, self.progress_display, self.filesystem)

        self.filesystem.create_directory_and_parents_if_needed.assert_called_once_with(self.root_dir / backup_subdir)
        self.filesystem.write_zip_file.assert_called_once_with(self.root_dir / backup_subdir / self.expected_zip_filename, ANY)
        self.progress_display.normal_printer.writeln.assert_called_once_with(f"Backing up files to '{self.root_dir / backup_subdir / self.expected_zip_filename}'")

    def test_creates_empty_backup_zip_file_in_subdirectory(self) -> None:
        update_strategy = DataclassMock(UpdateStrategy,
            root_directory = self.root_dir,
            local_manifest = InterfaceMock(ILocalManifest,
                variant_name = PropertyMock(return_value=self.variant_name),
                version_number = PropertyMock(return_value=self.version_number),
            ),
            backup_file_set = DataclassMock(BackupFileSet,
                list_of_core_files_to_backup = [],
                list_of_config_files_to_backup = [],
                list_of_clobbered_files_to_backup = [],
            ),
        )

        backup_subdir: PurePath = PurePath('backups')
        def mock_write_zip_file(_zip_path: PurePath, source_path_iterator: Iterable[tuple[PurePath, PurePath]]) -> None:
            self.assertListEqual([], list(source_path_iterator))
        self.filesystem.write_zip_file = Mock(side_effect=mock_write_zip_file)
        self.filesystem.create_directory_and_parents_if_needed = Mock()

        backup_files(update_strategy, backup_subdir, self.timestamp, self.progress_display, self.filesystem)

        self.filesystem.create_directory_and_parents_if_needed.assert_called_once_with(self.root_dir / backup_subdir)
        self.filesystem.write_zip_file.assert_called_once_with(self.root_dir / backup_subdir / self.expected_zip_filename, ANY)
        self.progress_display.normal_printer.writeln.assert_called_once_with(f"Backing up files to '{self.root_dir / backup_subdir / self.expected_zip_filename}'")

    def test_saves_files_to_zip_file(self) -> None:
        filepath_1 = PurePath('bongo.txt')
        filepath_2 = PurePath('fruit.exe')
        filepath_3 = PurePath('subdir1', 'something.dat')
        filepath_4 = PurePath('subdir2', 'subdir3', 'apple.map')

        update_strategy = DataclassMock(UpdateStrategy,
            root_directory = self.root_dir,
            local_manifest = InterfaceMock(ILocalManifest,
                variant_name = PropertyMock(return_value=self.variant_name),
                version_number = PropertyMock(return_value=self.version_number),
            ),
            backup_file_set = DataclassMock(BackupFileSet,
                list_of_core_files_to_backup = [filepath_1],
                list_of_config_files_to_backup = [filepath_2, filepath_3],
                list_of_clobbered_files_to_backup = [filepath_4],
            ),
        )

        backup_subdir: PurePath = PurePath('backups')
        def mock_write_zip_file(_zip_path: PurePath, source_path_iterator: Iterable[tuple[PurePath, PurePath]]) -> None:
            self.assertCountEqual([
                (self.root_dir / filepath_1, filepath_1),
                (self.root_dir / filepath_2, filepath_2),
                (self.root_dir / filepath_3, filepath_3),
                (self.root_dir / filepath_4, filepath_4),
            ], list(source_path_iterator))
        self.filesystem.write_zip_file = Mock(side_effect=mock_write_zip_file)
        self.filesystem.create_directory_and_parents_if_needed = Mock()
        self.filesystem.probe_file = Mock(side_effect=lambda filepath: FileStat(filepath, does_exist=True, is_file=True, test_passed=True))

        backup_files(update_strategy, backup_subdir, self.timestamp, self.progress_display, self.filesystem)

        self.filesystem.create_directory_and_parents_if_needed.assert_called_once_with(self.root_dir / backup_subdir)
        self.filesystem.write_zip_file.assert_called_once_with(self.root_dir / backup_subdir / self.expected_zip_filename, ANY)

    def test_raises_error_when_backup_directory_cannot_be_created(self) -> None:
        update_strategy = DataclassMock(UpdateStrategy,
            root_directory = self.root_dir,
            local_manifest = InterfaceMock(ILocalManifest,
                variant_name = PropertyMock(return_value=self.variant_name),
                version_number = PropertyMock(return_value=self.version_number),
            ),
            backup_file_set = DataclassMock(BackupFileSet,
                list_of_core_files_to_backup = [],
                list_of_config_files_to_backup = [],
                list_of_clobbered_files_to_backup = [],
            ),
        )

        backup_subdir: PurePath = PurePath('backups')
        self.filesystem.create_directory_and_parents_if_needed = Mock(side_effect=PermissionError)

        with self.assertRaises(PrepareUpdateError) as ex:
            backup_files(update_strategy, backup_subdir, self.timestamp, self.progress_display, self.filesystem)

        self.assertTrue(str(ex.exception).startswith(f"Failed to create directory for backup file '{self.root_dir / backup_subdir / self.expected_zip_filename}': "))

    def test_skips_files_that_do_not_exist(self) -> None:
        filepath_1 = PurePath('bongo.txt')
        filepath_2 = PurePath('fruit.exe')
        filepath_3 = PurePath('subdir1', 'something.dat')
        filepath_4 = PurePath('subdir2', 'subdir3', 'apple.map')
        missingpath_1 = PurePath('missing.txt')
        missingpath_2 = PurePath('subdir1', 'missing.txt')
        missingpath_3 = PurePath('some', 'missing', 'directory', 'missing3.txt')

        update_strategy = DataclassMock(UpdateStrategy,
            root_directory = self.root_dir,
            local_manifest = InterfaceMock(ILocalManifest,
                variant_name = PropertyMock(return_value=self.variant_name),
                version_number = PropertyMock(return_value=self.version_number),
            ),
            backup_file_set = DataclassMock(BackupFileSet,
                list_of_core_files_to_backup = [filepath_1, missingpath_1, filepath_2],
                list_of_config_files_to_backup = [filepath_3, missingpath_2],
                list_of_clobbered_files_to_backup = [missingpath_3, filepath_4],
            ),
        )

        backup_subdir = PurePath('backups')
        def mock_write_zip_file(_zip_path: PurePath, source_path_iterator: Iterable[tuple[PurePath, PurePath]]) -> None:
            self.assertCountEqual([
                (self.root_dir / filepath_1, filepath_1),
                (self.root_dir / filepath_2, filepath_2),
                (self.root_dir / filepath_3, filepath_3),
                (self.root_dir / filepath_4, filepath_4),
            ], list(source_path_iterator))
        self.filesystem.write_zip_file = Mock(side_effect=mock_write_zip_file)
        self.filesystem.create_directory_and_parents_if_needed = Mock()
        self.filesystem.probe_file = Mock()
        when(self.filesystem).probe_file(self.root_dir / filepath_1).thenReturn(FileStat(path=filepath_1, does_exist=True, is_file=True, test_passed=True))
        when(self.filesystem).probe_file(self.root_dir / filepath_2).thenReturn(FileStat(path=filepath_2, does_exist=True, is_file=True, test_passed=True))
        when(self.filesystem).probe_file(self.root_dir / filepath_3).thenReturn(FileStat(path=filepath_3, does_exist=True, is_file=True, test_passed=True))
        when(self.filesystem).probe_file(self.root_dir / filepath_4).thenReturn(FileStat(path=filepath_4, does_exist=True, is_file=True, test_passed=True))
        when(self.filesystem).probe_file(self.root_dir / missingpath_1).thenReturn(FileStat(path=missingpath_1, does_exist=False, is_file=False, test_passed=False))
        when(self.filesystem).probe_file(self.root_dir / missingpath_2).thenReturn(FileStat(path=missingpath_2, does_exist=False, is_file=False, test_passed=False))
        when(self.filesystem).probe_file(self.root_dir / missingpath_3).thenReturn(FileStat(path=missingpath_3, does_exist=False, is_file=False, test_passed=False))

        backup_files(update_strategy, backup_subdir, self.timestamp, self.progress_display, self.filesystem)

class TestPrepareUpdateDetermineUpdateSequence(unittest.TestCase):
    @override
    def setUp(self) -> None:
        super().setUp()
        self.update_strategy = DataclassMock(UpdateStrategy,
            root_directory = PurePath('test-directory'),
            core_file_changes = DataclassMock(CoreFileChanges,
                list_of_changed_files_to_acquire = [
                    InterfaceMock(ICoreFile,
                        filename = PropertyMock(return_value=PurePath('orange.txt')),
                    ),
                    InterfaceMock(ICoreFile,
                        filename = PropertyMock(return_value=PurePath('mango.dat')),
                    ),
                ],
                list_of_files_that_are_deprecated = [
                    PurePath('cheese.exe'),
                    PurePath('salad.log'),
                ],
            ),
            config_file_changes = DataclassMock(ConfigFileChanges,
                list_of_files_that_are_deprecated = [
                    PurePath('setup.cfg'),
                    PurePath('settings.json'),
                ],
                list_of_files_to_rename = [
                    DataclassMock(FileRename,
                        original_filename = PurePath('config.ini'),
                        new_filename = PurePath('config.toml'),
                    ),
                    DataclassMock(FileRename,
                        original_filename = PurePath('default.css'),
                        new_filename = PurePath('light.css'),
                    ),
                ],
            ),
            launch_executable = None,
        )

        self.list_of_files_to_emplace: Sequence[ICoreFile] = [
            InterfaceMock(ICoreFile,
                filename = PropertyMock(return_value=PurePath('winApp.exe')),
                digest = PropertyMock(return_value=FAKE_HEXDIGEST_A),
                exe = PropertyMock(return_value=False),
            ),
            InterfaceMock(ICoreFile,
                filename = PropertyMock(return_value=PurePath('linApp')),
                digest = PropertyMock(return_value=FAKE_HEXDIGEST_B),
                exe = PropertyMock(return_value=True),
            ),
        ]

        self.temp_directory = InterfaceMock(ITempDirectory,
            path = PropertyMock(return_value=PurePath('example', 'temp_directory')),
        )

    def test_records_root_directory_and_temp_directory(self) -> None:
        update_sequence: UpdateSequenceSchema = determine_update_sequence(self.update_strategy, self.temp_directory, self.list_of_files_to_emplace)

        self.assertEqual(self.update_strategy.root_directory, update_sequence.root_directory)
        self.assertEqual(self.temp_directory.path, update_sequence.temp_directory)

    def test_creates_delete_action_for_deleted_files(self) -> None:
        update_sequence: UpdateSequenceSchema = determine_update_sequence(self.update_strategy, self.temp_directory, self.list_of_files_to_emplace)

        list_of_actual_files_to_delete: Sequence[PurePath] = [
            file.filename for action in update_sequence.delete_files_actions.values() for file in action.files
        ]

        for action in update_sequence.delete_files_actions.values():
            for file in action.files:
                self.assertFalse(file.must_exist)

        self.assertCountEqual([
                PurePath('orange.txt'),
                PurePath('mango.dat'),
                PurePath('cheese.exe'),
                PurePath('salad.log'),
                PurePath('setup.cfg'),
                PurePath('settings.json'),
            ],
            list_of_actual_files_to_delete,
        )

    def test_creates_move_action_for_renamed_files(self) -> None:
        update_sequence: UpdateSequenceSchema = determine_update_sequence(self.update_strategy, self.temp_directory, self.list_of_files_to_emplace)

        list_of_actual_files_to_move: Sequence[tuple[PurePath, PurePath]] = [
            (file.original_filename, file.new_filename) for action in update_sequence.move_files_actions.values() for file in action.files
        ]

        for action in update_sequence.move_files_actions.values():
            for file in action.files:
                self.assertFalse(file.must_exist)

        self.assertCountEqual([
                (PurePath('config.ini'), PurePath('config.toml')),
                (PurePath('default.css'), PurePath('light.css')),
            ],
            list_of_actual_files_to_move)

    def test_creates_emplace_action_for_new_and_changed_files(self) -> None:
        update_sequence: UpdateSequenceSchema = determine_update_sequence(self.update_strategy, self.temp_directory, self.list_of_files_to_emplace)

        list_of_actual_files_to_emplace: Sequence[tuple[PurePath, PurePath]] = [
            (file.source_filename, file.target_filename) for action in update_sequence.emplace_files_actions.values() for file in action.files
        ]

        self.assertCountEqual([
                (PurePath(str(FAKE_HEXDIGEST_A)), PurePath('winApp.exe')),
                (PurePath(str(FAKE_HEXDIGEST_B)), PurePath('linApp')),
            ],
            list_of_actual_files_to_emplace)

    def test_actions_are_in_correct_key_order(self) -> None:
        update_sequence: UpdateSequenceSchema = determine_update_sequence(self.update_strategy, self.temp_directory, self.list_of_files_to_emplace)

        list_of_delete_action_keys: Sequence[int] = list(update_sequence.delete_files_actions)
        list_of_move_action_keys: Sequence[int] = list(update_sequence.move_files_actions)
        list_of_emplace_action_keys: Sequence[int] = list(update_sequence.emplace_files_actions)

        self.assertLess(max(list_of_delete_action_keys), min(list_of_move_action_keys))
        self.assertLess(max(list_of_move_action_keys), min(list_of_emplace_action_keys))

def _date_text(date: time.struct_time) -> str:
    return time.strftime("%Y-%m-%d_%H-%M-%S", date)
