# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import unittest
from pathlib import PurePath
from typing import override
from unittest.mock import Mock, PropertyMock
from mockito import expect, verifyExpectedInteractions, when # type: ignore[import-untyped]
from milodb.client.updater.i_temp_directory import ITempDirectory
from milodb.client.updater.manifest.update_sequence import IDeleteFile, IDeleteFilesAction, IEmplaceFile, IEmplaceFilesAction, IMoveFile, IMoveFilesAction, ISetFileAttribute, ISetFilesAttributeAction, IUpdateSequence
from milodb.client.updater.perform_pre_update_safety_check import PerformPreUpdateSafetyCheckError, perform_pre_update_safety_check
from milodb.client.util.file_system import FileStat, FileTest, IFileSystem
from milodb.common.output.print.i_printer import IPrinter
from milodb_test.common.test.strict_mock import InterfaceMock

class TestPerformPreUpdateSafetyCheck(unittest.TestCase):
    @override
    def setUp(self) -> None:
        super().setUp()
        self.printer = InterfaceMock(IPrinter,
            write = Mock(),
            writeln = Mock(),
        )

    def test_move_files_succeeds_if_the_source_does_and_must_exist(self) -> None:
        fake_root_dir = PurePath('not-a-real-root-dir')
        source_relpath = PurePath('mango.txt')
        target_relpath = PurePath('target.txt')

        temp_directory = InterfaceMock(ITempDirectory)

        update_sequence = InterfaceMock(IUpdateSequence,
            root_directory = PropertyMock(return_value=fake_root_dir),
            move_files_actions = PropertyMock(return_value={
                1: InterfaceMock(IMoveFilesAction,
                    files = PropertyMock(return_value=[
                        InterfaceMock(IMoveFile,
                            must_exist = PropertyMock(return_value=True),
                            original_filename = PropertyMock(return_value=source_relpath),
                            new_filename = PropertyMock(return_value=target_relpath),
                        ),
                    ]),
                ),
            }),
            emplace_files_actions = PropertyMock(return_value={}),
            delete_files_actions = PropertyMock(return_value={}),
            set_files_attribute_actions = PropertyMock(return_value={}),
        )

        filesystem = InterfaceMock(IFileSystem,
            probe_file = Mock(),
        )
        expect(filesystem, times=1).probe_file(fake_root_dir / source_relpath, FileTest.READABLE).thenReturn(FileStat(fake_root_dir / source_relpath, does_exist=True, is_file=True, test_passed=True))
        expect(filesystem, times=1).probe_file(fake_root_dir / target_relpath, FileTest.WRITABLE).thenReturn(FileStat(fake_root_dir / target_relpath, does_exist=False, is_file=False, test_passed=True))

        perform_pre_update_safety_check(temp_directory, update_sequence, self.printer, filesystem)

        verifyExpectedInteractions()

    def test_move_files_succeeds_if_the_source_does_and_may_not_exist(self) -> None:
        fake_root_dir = PurePath('not-a-real-root-dir')
        source_relpath = PurePath('mango.txt')
        target_relpath = PurePath('target.txt')

        temp_directory = InterfaceMock(ITempDirectory)

        update_sequence = InterfaceMock(IUpdateSequence,
            root_directory = PropertyMock(return_value=fake_root_dir),
            move_files_actions = PropertyMock(return_value={
                1: InterfaceMock(IMoveFilesAction,
                    files = PropertyMock(return_value=[
                        InterfaceMock(IMoveFile,
                            must_exist = PropertyMock(return_value=False),
                            original_filename = PropertyMock(return_value=source_relpath),
                            new_filename = PropertyMock(return_value=target_relpath),
                        ),
                    ]),
                ),
            }),
            emplace_files_actions = PropertyMock(return_value={}),
            delete_files_actions = PropertyMock(return_value={}),
            set_files_attribute_actions = PropertyMock(return_value={}),
        )

        filesystem = InterfaceMock(IFileSystem,
            probe_file = Mock(),
        )
        expect(filesystem, times=1).probe_file(fake_root_dir / source_relpath, FileTest.READABLE).thenReturn(FileStat(fake_root_dir / source_relpath, does_exist=True, is_file=True, test_passed=True))
        expect(filesystem, times=1).probe_file(fake_root_dir / target_relpath, FileTest.WRITABLE).thenReturn(FileStat(fake_root_dir / target_relpath, does_exist=False, is_file=False, test_passed=True))

        perform_pre_update_safety_check(temp_directory, update_sequence, self.printer, filesystem)

        verifyExpectedInteractions()

    def test_move_files_succeeds_if_the_source_doesnt_and_may_not_exist(self) -> None:
        fake_root_dir = PurePath('not-a-real-root-dir')
        source_relpath = PurePath('mango.txt')
        target_relpath = PurePath('target.txt')

        temp_directory = InterfaceMock(ITempDirectory)

        update_sequence = InterfaceMock(IUpdateSequence,
            root_directory = PropertyMock(return_value=fake_root_dir),
            move_files_actions = PropertyMock(return_value={
                1: InterfaceMock(IMoveFilesAction,
                    files = PropertyMock(return_value=[
                        InterfaceMock(IMoveFile,
                            must_exist = PropertyMock(return_value=False),
                            original_filename = PropertyMock(return_value=source_relpath),
                            new_filename = PropertyMock(return_value=target_relpath),
                        ),
                    ]),
                ),
            }),
            emplace_files_actions = PropertyMock(return_value={}),
            delete_files_actions = PropertyMock(return_value={}),
            set_files_attribute_actions = PropertyMock(return_value={}),
        )

        filesystem = InterfaceMock(IFileSystem,
            probe_file = Mock(),
        )
        expect(filesystem, times=1).probe_file(fake_root_dir / source_relpath, FileTest.READABLE).thenReturn(FileStat(fake_root_dir / source_relpath, does_exist=False, is_file=False, test_passed=False))
        expect(filesystem, times=1).probe_file(fake_root_dir / target_relpath, FileTest.WRITABLE).thenReturn(FileStat(fake_root_dir / target_relpath, does_exist=False, is_file=False, test_passed=True))

        perform_pre_update_safety_check(temp_directory, update_sequence, self.printer, filesystem)

        verifyExpectedInteractions()

    def test_move_files_fails_if_the_source_doesnt_and_must_exist(self) -> None:
        fake_root_dir = PurePath('not-a-real-root-dir')
        source_relpath = PurePath('mango.txt')
        target_relpath = PurePath('target.txt')

        temp_directory = InterfaceMock(ITempDirectory)

        update_sequence = InterfaceMock(IUpdateSequence,
            root_directory = PropertyMock(return_value=fake_root_dir),
            move_files_actions = PropertyMock(return_value={
                1: InterfaceMock(IMoveFilesAction,
                    files = PropertyMock(return_value=[
                        InterfaceMock(IMoveFile,
                            must_exist = PropertyMock(return_value=True),
                            original_filename = PropertyMock(return_value=source_relpath),
                            new_filename = PropertyMock(return_value=target_relpath),
                        ),
                    ]),
                ),
            }),
            emplace_files_actions = PropertyMock(return_value={}),
            delete_files_actions = PropertyMock(return_value={}),
            set_files_attribute_actions = PropertyMock(return_value={}),
        )

        filesystem = InterfaceMock(IFileSystem,
            probe_file = Mock(),
        )
        expect(filesystem, times=1).probe_file(fake_root_dir / source_relpath, FileTest.READABLE).thenReturn(FileStat(fake_root_dir / source_relpath, does_exist=False, is_file=False, test_passed=False))
        when(filesystem).probe_file(fake_root_dir / target_relpath, FileTest.WRITABLE).thenReturn(FileStat(fake_root_dir / target_relpath, does_exist=False, is_file=False, test_passed=True))

        with self.assertRaises(PerformPreUpdateSafetyCheckError) as ex:
            perform_pre_update_safety_check(temp_directory, update_sequence, self.printer, filesystem)

        verifyExpectedInteractions()

        self.assertEqual(f"'{fake_root_dir / source_relpath}' is missing when it is mandatory", str(ex.exception))

    def test_move_files_succeeds_if_the_target_file_exists(self) -> None:
        fake_root_dir = PurePath('not-a-real-root-dir')
        source_relpath = PurePath('mango.txt')
        target_relpath = PurePath('target.txt')

        temp_directory = InterfaceMock(ITempDirectory)

        update_sequence = InterfaceMock(IUpdateSequence,
            root_directory = PropertyMock(return_value=fake_root_dir),
            move_files_actions = PropertyMock(return_value={
                1: InterfaceMock(IMoveFilesAction,
                    files = PropertyMock(return_value=[
                        InterfaceMock(IMoveFile,
                            must_exist = PropertyMock(return_value=False),
                            original_filename = PropertyMock(return_value=source_relpath),
                            new_filename = PropertyMock(return_value=target_relpath),
                        ),
                    ]),
                ),
            }),
            emplace_files_actions = PropertyMock(return_value={}),
            delete_files_actions = PropertyMock(return_value={}),
            set_files_attribute_actions = PropertyMock(return_value={}),
        )

        filesystem = InterfaceMock(IFileSystem,
            probe_file = Mock(),
        )
        expect(filesystem, times=1).probe_file(fake_root_dir / source_relpath, FileTest.READABLE).thenReturn(FileStat(fake_root_dir / source_relpath, does_exist=True, is_file=True, test_passed=True))
        expect(filesystem, times=1).probe_file(fake_root_dir / target_relpath, FileTest.WRITABLE).thenReturn(FileStat(fake_root_dir / target_relpath, does_exist=True, is_file=True, test_passed=True))

        perform_pre_update_safety_check(temp_directory, update_sequence, self.printer, filesystem)

        verifyExpectedInteractions()

    def test_move_files_fails_if_the_target_file_exists_and_cannot_be_written(self) -> None:
        fake_root_dir = PurePath('not-a-real-root-dir')
        source_relpath = PurePath('mango.txt')
        target_relpath = PurePath('target.txt')

        temp_directory = InterfaceMock(ITempDirectory)

        update_sequence = InterfaceMock(IUpdateSequence,
            root_directory = PropertyMock(return_value=fake_root_dir),
            move_files_actions = PropertyMock(return_value={
                1: InterfaceMock(IMoveFilesAction,
                    files = PropertyMock(return_value=[
                        InterfaceMock(IMoveFile,
                            must_exist = PropertyMock(return_value=False),
                            original_filename = PropertyMock(return_value=source_relpath),
                            new_filename = PropertyMock(return_value=target_relpath),
                        ),
                    ]),
                ),
            }),
            emplace_files_actions = PropertyMock(return_value={}),
            delete_files_actions = PropertyMock(return_value={}),
            set_files_attribute_actions = PropertyMock(return_value={}),
        )

        filesystem = InterfaceMock(IFileSystem,
            probe_file = Mock(),
        )
        when(filesystem).probe_file(fake_root_dir / source_relpath, FileTest.READABLE).thenReturn(FileStat(fake_root_dir / source_relpath, does_exist=True, is_file=True, test_passed=True))
        expect(filesystem, times=1).probe_file(fake_root_dir / target_relpath, FileTest.WRITABLE).thenReturn(FileStat(fake_root_dir / target_relpath, does_exist=True, is_file=True, test_passed=False))

        with self.assertRaises(PerformPreUpdateSafetyCheckError) as ex:
            perform_pre_update_safety_check(temp_directory, update_sequence, self.printer, filesystem)

        verifyExpectedInteractions()

        self.assertEqual(f"'{fake_root_dir / target_relpath}' is not writable", str(ex.exception))

    def test_emplace_files_succeeds_if_the_target_file_exists(self) -> None:
        fake_root_dir = PurePath('not-a-real-root-dir')
        fake_temp_dir = PurePath('not-a-real-temp-dir')
        source_relpath = PurePath('mango.txt')
        target_relpath = PurePath('target.txt')

        temp_directory = InterfaceMock(ITempDirectory,
            path_of = Mock(),
        )
        when(temp_directory).path_of(str(source_relpath)).thenReturn(fake_temp_dir / source_relpath)

        update_sequence = InterfaceMock(IUpdateSequence,
            root_directory = PropertyMock(return_value=fake_root_dir),
            temp_directory = PropertyMock(return_value=fake_temp_dir),
            move_files_actions = PropertyMock(return_value={}),
            emplace_files_actions = PropertyMock(return_value={
                1: InterfaceMock(IEmplaceFilesAction,
                    files = PropertyMock(return_value=[
                        InterfaceMock(IEmplaceFile,
                            source_filename = PropertyMock(return_value=source_relpath),
                            target_filename = PropertyMock(return_value=target_relpath),
                        ),
                    ]),
                ),
            }),
            delete_files_actions = PropertyMock(return_value={}),
            set_files_attribute_actions = PropertyMock(return_value={}),
        )

        filesystem = InterfaceMock(IFileSystem,
            probe_file = Mock(),
        )
        expect(filesystem, times=1).probe_file(fake_temp_dir / source_relpath, FileTest.READABLE).thenReturn(FileStat(fake_temp_dir / source_relpath, does_exist=True, is_file=True, test_passed=True))
        expect(filesystem, times=1).probe_file(fake_root_dir / target_relpath, FileTest.WRITABLE).thenReturn(FileStat(fake_root_dir / target_relpath, does_exist=True, is_file=True, test_passed=True))

        perform_pre_update_safety_check(temp_directory, update_sequence, self.printer, filesystem)

        verifyExpectedInteractions()

    def test_emplace_files_fails_if_the_target_file_exists_and_is_not_writeable(self) -> None:
        fake_root_dir = PurePath('not-a-real-root-dir')
        fake_temp_dir = PurePath('not-a-real-temp-dir')
        source_relpath = PurePath('mango.txt')
        target_relpath = PurePath('target.txt')

        temp_directory = InterfaceMock(ITempDirectory,
            path_of = Mock(),
        )
        when(temp_directory).path_of(str(source_relpath)).thenReturn(fake_temp_dir / source_relpath)

        update_sequence = InterfaceMock(IUpdateSequence,
            root_directory = PropertyMock(return_value=fake_root_dir),
            temp_directory = PropertyMock(return_value=fake_temp_dir),
            move_files_actions = PropertyMock(return_value={}),
            emplace_files_actions = PropertyMock(return_value={
                1: InterfaceMock(IEmplaceFilesAction,
                    files = PropertyMock(return_value=[
                        InterfaceMock(IEmplaceFile,
                            source_filename = PropertyMock(return_value=source_relpath),
                            target_filename = PropertyMock(return_value=target_relpath),
                        ),
                    ]),
                ),
            }),
            delete_files_actions = PropertyMock(return_value={}),
            set_files_attribute_actions = PropertyMock(return_value={}),
        )

        filesystem = InterfaceMock(IFileSystem,
            probe_file = Mock(),
        )
        when(filesystem).probe_file(fake_temp_dir / source_relpath, FileTest.READABLE).thenReturn(FileStat(fake_temp_dir / source_relpath, does_exist=True, is_file=True, test_passed=True))
        expect(filesystem, times=1).probe_file(fake_root_dir / target_relpath, FileTest.WRITABLE).thenReturn(FileStat(fake_root_dir / target_relpath, does_exist=True, is_file=True, test_passed=False))

        with self.assertRaises(PerformPreUpdateSafetyCheckError) as ex:
            perform_pre_update_safety_check(temp_directory, update_sequence, self.printer, filesystem)

        verifyExpectedInteractions()

        self.assertEqual(f"'{fake_root_dir / target_relpath}' is not writable", str(ex.exception))

    def test_emplace_files_succeeds_if_target_file_doesnt_exist(self) -> None:
        fake_root_dir = PurePath('not-a-real-root-dir')
        fake_temp_dir = PurePath('not-a-real-temp-dir')
        source_relpath = PurePath('mango.txt')
        target_relpath = PurePath('target.txt')

        temp_directory = InterfaceMock(ITempDirectory,
            path_of = Mock(),
        )
        when(temp_directory).path_of(str(source_relpath)).thenReturn(fake_temp_dir / source_relpath)

        update_sequence = InterfaceMock(IUpdateSequence,
            root_directory = PropertyMock(return_value=fake_root_dir),
            temp_directory = PropertyMock(return_value=fake_temp_dir),
            move_files_actions = PropertyMock(return_value={}),
            emplace_files_actions = PropertyMock(return_value={
                1: InterfaceMock(IEmplaceFilesAction,
                    files = PropertyMock(return_value=[
                        InterfaceMock(IEmplaceFile,
                            source_filename = PropertyMock(return_value=source_relpath),
                            target_filename = PropertyMock(return_value=target_relpath),
                        ),
                    ]),
                ),
            }),
            delete_files_actions = PropertyMock(return_value={}),
            set_files_attribute_actions = PropertyMock(return_value={}),
        )

        filesystem = InterfaceMock(IFileSystem,
            probe_file = Mock(),
        )
        expect(filesystem, times=1).probe_file(fake_temp_dir / source_relpath, FileTest.READABLE).thenReturn(FileStat(fake_temp_dir / source_relpath, does_exist=True, is_file=True, test_passed=True))
        expect(filesystem, times=1).probe_file(fake_root_dir / target_relpath, FileTest.WRITABLE).thenReturn(FileStat(fake_root_dir / target_relpath, does_exist=False, is_file=False, test_passed=True))

        perform_pre_update_safety_check(temp_directory, update_sequence, self.printer, filesystem)

        verifyExpectedInteractions()

    def test_emplace_files_fails_if_source_file_doesnt_exist(self) -> None:
        fake_root_dir = PurePath('not-a-real-root-dir')
        fake_temp_dir = PurePath('not-a-real-temp-dir')
        source_relpath = PurePath('mango.txt')
        target_relpath = PurePath('target.txt')

        temp_directory = InterfaceMock(ITempDirectory,
            path_of = Mock(),
        )
        when(temp_directory).path_of(str(source_relpath)).thenReturn(fake_temp_dir / source_relpath)

        update_sequence = InterfaceMock(IUpdateSequence,
            root_directory = PropertyMock(return_value=fake_root_dir),
            temp_directory = PropertyMock(return_value=fake_temp_dir),
            move_files_actions = PropertyMock(return_value={}),
            emplace_files_actions = PropertyMock(return_value={
                1: InterfaceMock(IEmplaceFilesAction,
                    files = PropertyMock(return_value=[
                        InterfaceMock(IEmplaceFile,
                            source_filename = PropertyMock(return_value=source_relpath),
                            target_filename = PropertyMock(return_value=target_relpath),
                        ),
                    ]),
                ),
            }),
            delete_files_actions = PropertyMock(return_value={}),
            set_files_attribute_actions = PropertyMock(return_value={}),
        )

        filesystem = InterfaceMock(IFileSystem,
            probe_file = Mock(),
        )
        expect(filesystem, times=1).probe_file(fake_temp_dir / source_relpath, FileTest.READABLE).thenReturn(FileStat(fake_temp_dir / source_relpath, does_exist=False, is_file=False, test_passed=False))
        when(filesystem).probe_file(fake_root_dir / target_relpath, FileTest.WRITABLE).thenReturn(FileStat(fake_root_dir / target_relpath, does_exist=False, is_file=False, test_passed=True))

        with self.assertRaises(PerformPreUpdateSafetyCheckError) as ex:
            perform_pre_update_safety_check(temp_directory, update_sequence, self.printer, filesystem)

        verifyExpectedInteractions()

        self.assertEqual(f"'{fake_temp_dir / source_relpath}' is missing when it is mandatory", str(ex.exception))

    def test_delete_files_succeeds_if_target_exists_and_is_optional(self) -> None:
        fake_root_dir = PurePath('not-a-real-root-dir')
        file_relpath = PurePath('mango.txt')

        temp_directory = InterfaceMock(ITempDirectory)

        update_sequence = InterfaceMock(IUpdateSequence,
            root_directory = PropertyMock(return_value=fake_root_dir),
            move_files_actions = PropertyMock(return_value={}),
            emplace_files_actions = PropertyMock(return_value={}),
            delete_files_actions = PropertyMock(return_value={
                1: InterfaceMock(IDeleteFilesAction,
                    files = PropertyMock(return_value=[
                        InterfaceMock(IDeleteFile,
                            filename = PropertyMock(return_value=file_relpath),
                            must_exist = PropertyMock(return_value=False),
                        ),
                    ]),
                ),
            }),
            set_files_attribute_actions = PropertyMock(return_value={}),
        )

        filesystem = InterfaceMock(IFileSystem,
            probe_file = Mock(),
        )
        expect(filesystem, times=1).probe_file(fake_root_dir / file_relpath, FileTest.WRITABLE).thenReturn(FileStat(fake_root_dir / file_relpath, does_exist=True, is_file=True, test_passed=True))

        perform_pre_update_safety_check(temp_directory, update_sequence, self.printer, filesystem)

        verifyExpectedInteractions()

    def test_delete_files_succeeds_if_target_doesnt_exist_and_is_optional(self) -> None:
        fake_root_dir = PurePath('not-a-real-root-dir')
        file_relpath = PurePath('mango.txt')

        temp_directory = InterfaceMock(ITempDirectory)

        update_sequence = InterfaceMock(IUpdateSequence,
            root_directory = PropertyMock(return_value=fake_root_dir),
            move_files_actions = PropertyMock(return_value={}),
            emplace_files_actions = PropertyMock(return_value={}),
            delete_files_actions = PropertyMock(return_value={
                1: InterfaceMock(IDeleteFilesAction,
                    files = PropertyMock(return_value=[
                        InterfaceMock(IDeleteFile,
                            filename = PropertyMock(return_value=file_relpath),
                            must_exist = PropertyMock(return_value=False),
                        ),
                    ]),
                ),
            }),
            set_files_attribute_actions = PropertyMock(return_value={}),
        )

        filesystem = InterfaceMock(IFileSystem,
            probe_file = Mock(),
        )
        expect(filesystem, times=1).probe_file(fake_root_dir / file_relpath, FileTest.WRITABLE).thenReturn(FileStat(fake_root_dir / file_relpath, does_exist=False, is_file=False, test_passed=True))

        perform_pre_update_safety_check(temp_directory, update_sequence, self.printer, filesystem)

        verifyExpectedInteractions()

    def test_delete_files_fails_if_target_doesnt_exist_and_is_mandatory(self) -> None:
        fake_root_dir = PurePath('not-a-real-root-dir')
        file_relpath = PurePath('mango.txt')

        temp_directory = InterfaceMock(ITempDirectory)

        update_sequence = InterfaceMock(IUpdateSequence,
            root_directory = PropertyMock(return_value=fake_root_dir),
            move_files_actions = PropertyMock(return_value={}),
            emplace_files_actions = PropertyMock(return_value={}),
            delete_files_actions = PropertyMock(return_value={
                1: InterfaceMock(IDeleteFilesAction,
                    files = PropertyMock(return_value=[
                        InterfaceMock(IDeleteFile,
                            filename = PropertyMock(return_value=file_relpath),
                            must_exist = PropertyMock(return_value=True),
                        ),
                    ]),
                ),
            }),
            set_files_attribute_actions = PropertyMock(return_value={}),
        )

        filesystem = InterfaceMock(IFileSystem,
            probe_file = Mock(),
        )
        expect(filesystem, times=1).probe_file(fake_root_dir / file_relpath, FileTest.WRITABLE).thenReturn(FileStat(fake_root_dir / file_relpath, does_exist=False, is_file=False, test_passed=True))

        with self.assertRaises(PerformPreUpdateSafetyCheckError) as ex:
            perform_pre_update_safety_check(temp_directory, update_sequence, self.printer, filesystem)

        verifyExpectedInteractions()

        self.assertEqual(f"'{fake_root_dir / file_relpath}' is missing when it is mandatory", str(ex.exception))

    def test_set_files_attributes_succeeds_if_the_file_exists(self) -> None:
        fake_root_dir = PurePath('not-a-real-root-dir')
        file_relpath = PurePath('mango.txt')

        temp_directory = InterfaceMock(ITempDirectory)

        update_sequence = InterfaceMock(IUpdateSequence,
            root_directory = PropertyMock(return_value=fake_root_dir),
            move_files_actions = PropertyMock(return_value={}),
            emplace_files_actions = PropertyMock(return_value={}),
            delete_files_actions = PropertyMock(return_value={}),
            set_files_attribute_actions = PropertyMock(return_value={
                1: InterfaceMock(ISetFilesAttributeAction,
                    files = PropertyMock(return_value=[
                        InterfaceMock(ISetFileAttribute,
                            filename = PropertyMock(return_value=file_relpath),
                            is_readonly = PropertyMock(return_value=True),
                            is_executable = PropertyMock(return_value=True),
                        ),
                    ]),
                ),
            }),
        )

        filesystem = InterfaceMock(IFileSystem,
            probe_file = Mock(),
        )
        expect(filesystem, times=1).probe_file(fake_root_dir / file_relpath, FileTest.WRITABLE).thenReturn(FileStat(fake_root_dir / file_relpath, does_exist=True, is_file=True, test_passed=True))

        perform_pre_update_safety_check(temp_directory, update_sequence, self.printer, filesystem)

        verifyExpectedInteractions()

    def test_set_files_attributes_fails_if_the_file_is_not_writeable(self) -> None:
        fake_root_dir = PurePath('not-a-real-root-dir')
        file_relpath = PurePath('mango.txt')

        temp_directory = InterfaceMock(ITempDirectory)

        update_sequence = InterfaceMock(IUpdateSequence,
            root_directory = PropertyMock(return_value=fake_root_dir),
            move_files_actions = PropertyMock(return_value={}),
            emplace_files_actions = PropertyMock(return_value={}),
            delete_files_actions = PropertyMock(return_value={}),
            set_files_attribute_actions = PropertyMock(return_value={
                1: InterfaceMock(ISetFilesAttributeAction,
                    files = PropertyMock(return_value=[
                        InterfaceMock(ISetFileAttribute,
                            filename = PropertyMock(return_value=file_relpath),
                            is_readonly = PropertyMock(return_value=True),
                            is_executable = PropertyMock(return_value=True),
                        ),
                    ]),
                ),
            }),
        )

        filesystem = InterfaceMock(IFileSystem,
            probe_file = Mock(),
        )
        expect(filesystem, times=1).probe_file(fake_root_dir / file_relpath, FileTest.WRITABLE).thenReturn(FileStat(fake_root_dir / file_relpath, does_exist=True, is_file=True, test_passed=False))

        with self.assertRaises(PerformPreUpdateSafetyCheckError) as ex:
            perform_pre_update_safety_check(temp_directory, update_sequence, self.printer, filesystem)

        verifyExpectedInteractions()

        self.assertEqual(f"'{fake_root_dir / file_relpath}' is not writable", str(ex.exception))

    def test_set_files_attributes_succeeds_if_the_file_doesnt_exist(self) -> None:
        fake_root_dir = PurePath('not-a-real-root-dir')
        file_relpath = PurePath('mango.txt')

        temp_directory = InterfaceMock(ITempDirectory)

        update_sequence = InterfaceMock(IUpdateSequence,
            root_directory = PropertyMock(return_value=fake_root_dir),
            move_files_actions = PropertyMock(return_value={}),
            emplace_files_actions = PropertyMock(return_value={}),
            delete_files_actions = PropertyMock(return_value={}),
            set_files_attribute_actions = PropertyMock(return_value={
                1: InterfaceMock(ISetFilesAttributeAction,
                    files = PropertyMock(return_value=[
                        InterfaceMock(ISetFileAttribute,
                            filename = PropertyMock(return_value=file_relpath),
                            is_readonly = PropertyMock(return_value=True),
                            is_executable = PropertyMock(return_value=True),
                        ),
                    ]),
                ),
            }),
        )

        filesystem = InterfaceMock(IFileSystem,
            probe_file = Mock(),
        )
        expect(filesystem, times=1).probe_file(fake_root_dir / file_relpath, FileTest.WRITABLE).thenReturn(FileStat(fake_root_dir / file_relpath, does_exist=False, is_file=False, test_passed=True))

        perform_pre_update_safety_check(temp_directory, update_sequence, self.printer, filesystem)

        verifyExpectedInteractions()
