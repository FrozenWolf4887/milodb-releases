#!/usr/bin/env python3
# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import sys
import tkinter as tk
from collections.abc import Sequence
from typing import TYPE_CHECKING
import pip_system_certs.wrapt_requests # type: ignore[import-untyped]
from milodb.client.startup.dataset import DataSet, load_dataset
from milodb.client.startup.startup import StartupResult, startup
from milodb.client.util.file_system import IFileSystem
from milodb.client.util.real_file_system import RealFileSystem
from milodb.client.view.gui.dialogs.progress_dialog import ProgressDialog
from milodb.client.view.gui.main_window import MainWindow
from milodb.client.view.gui.theme import configure_ttk_styles
from milodb.client.view.gui.util.tk_thread import run_tk_thread_routine
if TYPE_CHECKING:
    from milodb.client.startup.command_line import CommandLine

class _Main:
    def __init__(self, list_of_args: Sequence[str]) -> None:
        self._list_of_args: Sequence[str] = list_of_args

        self._dataset: DataSet | None = None
        self._quit_after_startup: bool = False

        self._root: tk.Tk = tk.Tk()
        self._root.wm_withdraw()
        configure_ttk_styles(self._root)
        self._root.after_idle(self._main_tk)
        self._root.mainloop()

    def _main_tk(self) -> None:
        filesystem: IFileSystem = RealFileSystem()

        with ProgressDialog(None) as progress_dialog:
            run_tk_thread_routine(lambda: self._startup(progress_dialog, filesystem), progress_dialog, 'GUI startup')
            if progress_dialog.any_warnings_or_errors:
                progress_dialog.prompt_on_exit()

        if self._dataset and not self._quit_after_startup:
            MainWindow(self._dataset, filesystem).wait_window()

        self._root.quit()

    def _startup(self, progress_dialog: ProgressDialog, filesystem: IFileSystem) -> None:
        all_good: bool = True

        startup_result: StartupResult
        command_line: CommandLine | None
        startup_result, command_line = startup(self._list_of_args, progress_dialog, filesystem)
        if startup_result.shutdown_action:
            all_good = startup_result.shutdown_action.perform_action(progress_dialog)

        if all_good and startup_result.run_main_application:
            self._dataset = load_dataset(progress_dialog, no_load=command_line.no_load if command_line else False)

        if command_line:
            if command_line.startup_pause:
                progress_dialog.prompt_on_exit()
            if command_line.startup_quit:
                self._quit_after_startup = True

if __name__ == "__main__":
    pip_system_certs.wrapt_requests.inject_truststore()
    _Main(sys.argv[1:])
