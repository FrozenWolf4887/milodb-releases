# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from typing import override
from milodb_common.command_framework.argument_stream import ArgumentStream, ArgumentStreamError
from milodb_common.command_framework.candidate_text import CandidateText
from milodb_common.command_framework.i_command import CommandLoader, CommandLoaderError, CommandLoaderResult
from milodb_common.command_framework.i_command_constructor import ICommandConstructor
from milodb_common.command_framework.i_command_factory import ICommandFactory
from milodb_common.parser.token import Token
from milodb_common.parser.token_stream import TokenStreamError

class CommandConstructor(ICommandConstructor):
    def __init__(self, command_factory: ICommandFactory) -> None:
        self._command_factory: ICommandFactory = command_factory

    @override
    def try_construct(self, argument_stream: ArgumentStream) -> ICommandConstructor.ConstructResult:
        command_token: Token | None = argument_stream.pop_optional_token()
        if command_token:
            return self._try_create_from_command_name(argument_stream, command_token)
        return ICommandConstructor.EmptyInputResult(list(self._command_factory.get_list_of_command_names()))

    def _try_create_from_command_name(self, argument_stream: ArgumentStream, command_token: Token) -> ICommandConstructor.ConstructResult:
        command_name: str = command_token.text
        command_loader: CommandLoader | None = self._command_factory.try_get_command_loader_from_name(command_name)
        if command_loader:
            return _try_load_command(argument_stream, command_name, command_loader)
        return ICommandConstructor.FailedResult(
            command_name = None,
            fault_token = command_token,
            fault_text = 'Unknown command',
            input_text = _get_expanded_input_text(argument_stream),
            list_of_candidate_text = CandidateText.space_delimited_list(self._command_factory.get_list_of_command_names()))

def _try_load_command(argument_stream: ArgumentStream, command_name: str, command_loader: CommandLoader) -> ICommandConstructor.ConstructResult:
    result: ICommandConstructor.ConstructResult

    try:
        load_result: CommandLoaderResult = command_loader(argument_stream)
    except TokenStreamError as ex:
        result = ICommandConstructor.FailedResult(
            command_name = command_name,
            fault_token = ex.cause_of_fault_token,
            fault_text = f"Parsing error at character #{ex.cause_of_fault_character_index} '{ex.cause_of_fault_text}'",
            input_text = _get_expanded_input_text(argument_stream),
            list_of_candidate_text = ex.list_of_candidate_text)
    except ArgumentStreamError as ex:
        result = ICommandConstructor.FailedResult(
            command_name = command_name,
            fault_token = ex.fault_token,
            fault_text = f"Argument error '{ex.message}'",
            input_text = _get_expanded_input_text(argument_stream),
            list_of_candidate_text = ex.list_of_candidate_text)
    except CommandLoaderError as ex:
        result = ICommandConstructor.FailedResult(
            command_name = command_name,
            fault_token = ex.fault_token,
            fault_text = ex.message,
            input_text = _get_expanded_input_text(argument_stream),
            list_of_candidate_text = ex.list_of_candidate_text)
    except ICommandConstructor.DelegateError as ex:
        result = ex.construct_result
    else:
        result = ICommandConstructor.SuccessfulResult(load_result.command, load_result.list_of_candidate_text)

    return result

def _get_expanded_input_text(argument_stream: ArgumentStream) -> str:
    return argument_stream.get_expanded_raw_text() + argument_stream.get_remaining_raw_text()
