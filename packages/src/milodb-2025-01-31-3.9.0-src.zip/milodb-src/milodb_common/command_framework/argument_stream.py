# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
import datetime
import re
from collections.abc import Callable, Iterable, Mapping, MutableMapping, Sequence
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from milodb_common.command_framework.candidate_text import CandidateText
from milodb_common.command_framework.ref_id import AuthorId, MatchIndex, RefId, TeaseId
from milodb_common.commands import enums
from milodb_common.parser.expanding_token_stream import ExpandingTokenStream
from milodb_common.parser.token import Token
from milodb_common.types.partial_date import PartialDate
from milodb_common.variables.i_user_variables import VARIABLE_NAME_PATTERN

_DATE_FORMAT: str = 'yyyy-mm-dd'
_MSG_INSUFFICIENT_PARAMETERS: str = 'Insufficient parameters'

@dataclass
class ArgumentStreamError(Exception):
    message: str
    fault_token: Token | None
    list_of_candidate_text: Sequence[CandidateText]

class ArgumentStream:
    def __init__(self, token_stream: ExpandingTokenStream) -> None:
        self._token_stream: ExpandingTokenStream = token_stream

    def disable_expansion(self) -> None:
        self._token_stream.disable_expansion()

    def get_remaining_raw_text(self) -> str:
        return self._token_stream.get_remaining_raw_text()

    def get_expanded_raw_text(self) -> str:
        return self._token_stream.get_expanded_raw_text()

    def set_discard_delimiters(self, delimiters: str) -> None:
        self._token_stream.set_discard_delimiters(delimiters)

    def set_keep_delimiters(self, delimiters: str) -> None:
        self._token_stream.set_keep_delimiters(delimiters)

    @staticmethod
    def pop_list[T](pop_optional_handler: Callable[[], T | None]) -> list[T]:
        list_of_arguments: list[T] = []

        end_of_input: bool = False
        while not end_of_input:
            argument: T | None = pop_optional_handler()
            if argument:
                list_of_arguments.append(argument)
            else:
                end_of_input = True

        return list_of_arguments

    @staticmethod
    def pop_minimum_list[T](minimum_number: int, pop_handler: Callable[[], T], pop_optional_handler: Callable[[], T | None]) -> list[T]:
        list_of_arguments: list[T] = [ pop_handler() for _ in range(minimum_number) ]
        list_of_arguments.extend(ArgumentStream.pop_list(pop_optional_handler))
        return list_of_arguments

    @staticmethod
    def for_each[T](pop_optional_handler: Callable[[], T | None], argument_handler: Callable[[T], bool]) -> None:
        end_of_input: bool = False
        while not end_of_input:
            argument: T | None = pop_optional_handler()
            if argument:
                if not argument_handler(argument):
                    break
            else:
                end_of_input = True

    def pop_token(self) -> Token:
        token: Token | None = self._token_stream.next()
        if token:
            return token
        raise ArgumentStreamError(
            message = _MSG_INSUFFICIENT_PARAMETERS,
            fault_token = None,
            list_of_candidate_text = [])

    def pop_optional_token(self) -> Token | None:
        return self._token_stream.next()

    def pop_optional_ref_id(self) -> RefId | None:
        ref_id: RefId | None = None
        token: Token | None = self._token_stream.next()
        if token:
            value: int
            if token.text.startswith('#'):
                value = _parse_uint(token, token.text[1:], 'TeaseId is not a positive integer')
                ref_id = TeaseId(value)
            elif token.text.startswith('@'):
                value = _parse_uint(token, token.text[1:], 'AuthorId is not a positive integer')
                ref_id = AuthorId(value)
            elif token.text[0:1].isdigit():
                value = _parse_uint(token, token.text, 'Match index is not a positive integer')
                ref_id = MatchIndex(value)
            else:
                raise ArgumentStreamError(
                    message = "Invalid RefId. Expecting 'value', '#value', or '@value'",
                    fault_token = token,
                    list_of_candidate_text = [])

        return ref_id

    def pop_ref_id(self) -> RefId:
        ref_id: RefId | None = self.pop_optional_ref_id()
        if ref_id is None:
            raise ArgumentStreamError(
                message = f'{_MSG_INSUFFICIENT_PARAMETERS}. Expecting a RefId',
                fault_token = None,
                list_of_candidate_text = [])
        return ref_id

    def pop_optional_tease_id(self) -> int | None:
        tease_id: int | None = None
        token: Token | None = self._token_stream.next()
        if token:
            if token.text.startswith('#'):
                tease_id = _parse_uint(token, token.text[1:], 'TeaseId is not a positive integer')
            else:
                raise ArgumentStreamError(
                    message = "Invalid TeaseId. Expecting '#value'",
                    fault_token = token,
                    list_of_candidate_text = [])

        return tease_id

    def pop_tease_id(self) -> int:
        tease_id: int | None = self.pop_optional_tease_id()
        if tease_id is None:
            raise ArgumentStreamError(
                message = f'{_MSG_INSUFFICIENT_PARAMETERS}. Expecting a TeaseId',
                fault_token = None,
                list_of_candidate_text = [])
        return tease_id

    def pop_dict_value[V](self, dictionary: Mapping[str, V]) -> V:
        value: V | None = self.pop_optional_dict_value(dictionary)
        if value is None:
            list_of_keys = list(dictionary)
            raise ArgumentStreamError(
                message = _MSG_INSUFFICIENT_PARAMETERS,
                fault_token = None,
                list_of_candidate_text = CandidateText.space_delimited_list(list_of_keys))
        return value

    def pop_dict_value_and_token[V](self, dictionary: Mapping[str, V]) -> tuple[V, Token]:
        value_and_token: tuple[V, Token] | None = self.pop_optional_dict_value_and_token(dictionary)
        if value_and_token is None:
            list_of_keys = list(dictionary)
            raise ArgumentStreamError(
                message = _MSG_INSUFFICIENT_PARAMETERS,
                fault_token = None,
                list_of_candidate_text = CandidateText.space_delimited_list(list_of_keys))
        return value_and_token

    def pop_optional_dict_value[V](self, dictionary: Mapping[str, V]) -> V | None:
        value_and_token: tuple[V, Token] | None = self.pop_optional_dict_value_and_token(dictionary)
        if value_and_token:
            return value_and_token[0]
        return None

    def pop_optional_dict_value_and_remove[V](self, dictionary: MutableMapping[str, V]) -> V | None:
        value_and_token: tuple[V, Token] | None = self.pop_optional_dict_value_and_token_and_remove(dictionary)
        if value_and_token:
            return value_and_token[0]
        return None

    def pop_optional_dict_value_and_token[V](self, dictionary: Mapping[str, V]) -> tuple[V, Token] | None:
        token: Token | None = self._token_stream.next()
        if token:
            try:
                return dictionary[token.text], token
            except KeyError as ex:
                raise ArgumentStreamError(
                    message = 'Invalid parameter',
                    fault_token = token,
                    list_of_candidate_text = CandidateText.space_delimited_list(dictionary)) from ex
        return None

    def pop_optional_dict_value_and_token_and_remove[V](self, dictionary: MutableMapping[str, V]) -> tuple[V, Token] | None:
        token: Token | None = self._token_stream.next()
        if token:
            try:
                return dictionary.pop(token.text), token
            except KeyError as ex:
                raise ArgumentStreamError(
                    message = 'Invalid parameter',
                    fault_token = token,
                    list_of_candidate_text = CandidateText.space_delimited_list(dictionary)) from ex
        return None

    def pop_enum[E: Enum](self, enum_class: type[E]) -> E:
        enum: E | None = self.pop_optional_enum(enum_class)
        if enum:
            return enum
        raise ArgumentStreamError(
            message = _MSG_INSUFFICIENT_PARAMETERS,
            fault_token = None,
            list_of_candidate_text = CandidateText.space_delimited_list(enums.lowercase_names(enum_class)))

    def pop_optional_enum[E: Enum](self, enum_class: type[E]) -> E | None:
        enum_and_token: tuple[E, Token] | None = self.pop_optional_enum_and_token(enum_class)
        if enum_and_token:
            return enum_and_token[0]
        return None

    def pop_optional_enum_and_token[E: Enum](self, enum_class: type[E]) -> tuple[E, Token] | None:
        token: Token | None = self._token_stream.next()
        if token:
            try:
                return enum_class[token.text.upper()], token
            except KeyError as ex:
                raise ArgumentStreamError(
                    message = 'Unknown keyword or value',
                    fault_token = token,
                    list_of_candidate_text = CandidateText.space_delimited_list(enums.lowercase_names(enum_class))) from ex
        return None

    def pop_enum_by_value[E: Enum](self, enum_class: type[E]) -> E:
        enum: E | None = self.pop_optional_enum_by_value(enum_class)
        if enum:
            return enum
        raise ArgumentStreamError(
            message = _MSG_INSUFFICIENT_PARAMETERS,
            fault_token = None,
            list_of_candidate_text = CandidateText.space_delimited_list(enums.text_of_values(enum_class)))

    def pop_optional_enum_by_value[E: Enum](self, enum_class: type[E]) -> E | None:
        enum_and_token: tuple[E, Token] | None = self.pop_optional_enum_and_token_by_value(enum_class)
        if enum_and_token:
            return enum_and_token[0]
        return None

    def pop_optional_enum_and_token_by_value[E: Enum](self, enum_class: type[E]) -> tuple[E, Token] | None:
        token: Token | None = self._token_stream.next()
        if token:
            try:
                return enum_class(token.text), token
            except ValueError as ex:
                raise ArgumentStreamError(
                    message = 'Unknown keyword or value',
                    fault_token = token,
                    list_of_candidate_text = CandidateText.space_delimited_list(enums.text_of_values(enum_class))) from ex
        return None

    def pop_variable_name(self, list_of_variable_names: Iterable[str]) -> str:
        variable_name: str | None = self.pop_optional_variable_name(list_of_variable_names)
        if not variable_name:
            raise ArgumentStreamError(
                message = f'{_MSG_INSUFFICIENT_PARAMETERS}. Expecting a variable name',
                fault_token = None,
                list_of_candidate_text = CandidateText.space_delimited_list(list_of_variable_names))
        return variable_name

    def pop_optional_variable_name(self, list_of_variable_names: Iterable[str]) -> str | None:
        token: Token | None = self._token_stream.next()
        if token:
            if VARIABLE_NAME_PATTERN.fullmatch(token.text):
                return token.text
            raise ArgumentStreamError(
                message = f"Variable name '{token.text}' does not match pattern '{VARIABLE_NAME_PATTERN.pattern}'",
                fault_token = token,
                list_of_candidate_text = CandidateText.space_delimited_list(list_of_variable_names))
        return None

    def pop_date(self) -> datetime.date:
        date: datetime.date | None = self.pop_optional_date()
        if date:
            return date
        raise ArgumentStreamError(
            message = f'{_MSG_INSUFFICIENT_PARAMETERS}. Expecting a date',
            fault_token = None,
            list_of_candidate_text = [])

    def pop_optional_date(self) -> datetime.date | None:
        token: Token | None = self._token_stream.next()
        if token:
            try:
                return datetime.date.fromisoformat(token.text)
            except ValueError as ex:
                raise ArgumentStreamError(
                    message = f"Invalid date. Expected format '{_DATE_FORMAT}'",
                    fault_token = token,
                    list_of_candidate_text = []) from ex
        return None

    def pop_partial_date(self) -> PartialDate:
        date: PartialDate | None = self.pop_optional_partial_date()
        if date:
            return date
        raise ArgumentStreamError(
            message = f'{_MSG_INSUFFICIENT_PARAMETERS}. Expecting a date or partial date',
            fault_token = None,
            list_of_candidate_text = [])

    def pop_optional_partial_date(self) -> PartialDate | None:
        token: Token | None = self._token_stream.next()
        if token:
            try:
                return PartialDate.parse(token.text)
            except ValueError as ex:
                raise ArgumentStreamError(
                    message = f"Invalid date or partial date: {ex}",
                    fault_token = token,
                    list_of_candidate_text = []) from ex
        return None

    def pop_fixed_text(self, expected_text: str) -> None:
        if not self.pop_optional_fixed_text(expected_text):
            raise ArgumentStreamError(
                message = f"Expecting fixed text '{expected_text}'",
                fault_token = None,
                list_of_candidate_text = [CandidateText(expected_text, ' ')])

    def pop_optional_fixed_text(self, expected_text: str) -> bool:
        token: Token | None = self._token_stream.next()
        if token:
            if token.text != expected_text:
                raise ArgumentStreamError(
                    message = f"Expecting fixed text '{expected_text}'",
                    fault_token = token,
                    list_of_candidate_text = [CandidateText(expected_text, ' ')])
            return True
        return False

    def pop_any_fixed_text(self, list_of_text: Iterable[str]) -> str:
        token: Token | None = self._token_stream.next()
        if token:
            if token.text in list_of_text:
                return token.text
            raise ArgumentStreamError(
                message = 'Expecting a keyword',
                fault_token = token,
                list_of_candidate_text = CandidateText.space_delimited_list(list_of_text))
        raise ArgumentStreamError(
            message = f'{_MSG_INSUFFICIENT_PARAMETERS}. Expecting a keyword',
            fault_token = None,
            list_of_candidate_text = CandidateText.space_delimited_list(list_of_text))

    def pop_int(self) -> int:
        value: int | None = self.pop_optional_int()
        if value is not None:
            return value
        raise ArgumentStreamError(
            message = f'{_MSG_INSUFFICIENT_PARAMETERS}. Expecting an integer value',
            fault_token = None,
            list_of_candidate_text = [])

    def pop_optional_int(self) -> int | None:
        token: Token | None = self._token_stream.next()
        if token:
            return _parse_int(token, token.text, 'Expecting an integer value')
        return None

    def pop_uint(self) -> int:
        value: int | None = self.pop_optional_uint()
        if value is not None:
            return value
        raise ArgumentStreamError(
            message = f'{_MSG_INSUFFICIENT_PARAMETERS}. Expecting an unsigned integer value',
            fault_token = None,
            list_of_candidate_text = [])

    def pop_optional_uint(self) -> int | None:
        token: Token | None = self._token_stream.next()
        if token:
            return _parse_uint(token, token.text, 'Expecting an unsigned integer value')
        return None

    def pop_float(self) -> float:
        value: float | None = self.pop_optional_float()
        if value is not None:
            return value
        raise ArgumentStreamError(
            message = f'{_MSG_INSUFFICIENT_PARAMETERS}. Expecting an integer or decimal value',
            fault_token = None,
            list_of_candidate_text = [])

    def pop_optional_float(self) -> float | None:
        token: Token | None = self._token_stream.next()
        if token:
            return _parse_float(token, token.text, 'Expecting an integer or decimal value')
        return None

    def pop_ufloat(self) -> float:
        value: float | None = self.pop_optional_ufloat()
        if value is not None:
            return value
        raise ArgumentStreamError(
            message = f'{_MSG_INSUFFICIENT_PARAMETERS}. Expecting an unsigned integer or decimal value',
            fault_token = None,
            list_of_candidate_text = [])

    def pop_optional_ufloat(self) -> float | None:
        token: Token | None = self._token_stream.next()
        if token:
            return _parse_ufloat(token, token.text, 'Expecting an unsigned integer or decimal value')
        return None

    def pop_text(self) -> str:
        token: Token | None = self._token_stream.next()
        if token:
            return token.text
        raise ArgumentStreamError(
            message = f'{_MSG_INSUFFICIENT_PARAMETERS}. Expecting some text',
            fault_token = None,
            list_of_candidate_text = [])

    def pop_optional_text(self) -> str | None:
        token: Token | None = self._token_stream.next()
        if token:
            return token.text
        return None

    def pop_path(self) -> Path:
        token: Token | None = self._token_stream.next()
        if token:
            return Path(token.text)
        raise ArgumentStreamError(
            message = f'{_MSG_INSUFFICIENT_PARAMETERS}. Expecting a filepath',
            fault_token = None,
            list_of_candidate_text = [])

    def pop_regex(self, flags: int) -> re.Pattern[str]:
        pattern: re.Pattern[str] | None = self.pop_optional_regex(flags)
        if pattern:
            return pattern
        raise ArgumentStreamError(
            message = f'{_MSG_INSUFFICIENT_PARAMETERS}. Expecting a regular expression',
            fault_token = None,
            list_of_candidate_text = [])

    def pop_optional_regex(self, flags: int) -> re.Pattern[str] | None:
        token: Token | None = self._token_stream.next()
        if token:
            try:
                return re.compile(token.text, flags)
            except re.error as ex:
                raise ArgumentStreamError(
                    message = f"Invalid regular expression: {ex}",
                    fault_token = token,
                    list_of_candidate_text = []) from ex
        return None

    def fail_if_not_empty(self) -> None:
        token: Token | None = self._token_stream.next()
        if token is not None:
            raise ArgumentStreamError(
                message = 'Unexpected additional parameter',
                fault_token = token,
                list_of_candidate_text = [])

def _parse_int(token: Token, text: str, error_text: str) -> int:
    try:
        return int(text)
    except ValueError as ex:
        raise ArgumentStreamError(
            message = error_text,
            fault_token = token,
            list_of_candidate_text = []) from ex

def _parse_uint(token: Token, text: str, error_text: str) -> int:
    value: int = _parse_int(token, text, error_text)
    if value < 0:
        raise ArgumentStreamError(
            message = error_text,
            fault_token = token,
            list_of_candidate_text = [])
    return value

def _parse_float(token: Token, text: str, error_text: str) -> float:
    try:
        return float(text)
    except ValueError as ex:
        raise ArgumentStreamError(
            message = error_text,
            fault_token = token,
            list_of_candidate_text = []) from ex

def _parse_ufloat(token: Token, text: str, error_text: str) -> float:
    value: float = _parse_float(token, text, error_text)
    if value < 0:
        raise ArgumentStreamError(
            message = error_text,
            fault_token = token,
            list_of_candidate_text = [])
    return value
