# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
import platform
import sys
from collections.abc import Callable, Iterable, Sequence
from typing import TYPE_CHECKING, override
import psutil
from milodb_client.database.database import try_get_newest_tease_date, try_get_oldest_tease_date
from milodb_client.database.tease import Tease
from milodb_client.output.support import get_url_of_author
from milodb_client.updater.manifest.local_manifest import ILocalManifest
from milodb_common.command_framework.argument_stream import ArgumentStream
from milodb_common.command_framework.candidate_text import CandidateText
from milodb_common.command_framework.i_command import CommandLoaderResult
from milodb_common.command_framework.i_help_info import IHelpInfo
from milodb_common.output.print.i_printer import IPrinter
from milodb_common.output.unit_file_size import unit_file_size
if TYPE_CHECKING:
    import datetime

_APPLICATION_NAME: str = 'MiloDB'
_AUTHOR_NAME: str = 'FrozenWolf'
_AUTHOR_ID: int = 102_759
_FORUM_THREAD_URL: str = 'https://milovana.com/forum/viewtopic.php?t=25177'
_LIST_OF_SOFTWARE_LICENCE_LINES: list[str] = [
    'MiloDB by FrozenWolf is marked with CC0 1.0.',
    'To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0',
]
_LIST_OF_TEASE_COPYRIGHT_LINES: list[str] = [
    'The ownership/copyright of each tease remains with the respective author according to',
    'the Milovana.com terms of service, https://milovana.com/pages/tos.php',
]

def load(argument_stream: ArgumentStream, local_manifest: ILocalManifest | None, list_of_teases: Sequence[Tease], normal_printer: IPrinter) -> CommandLoaderResult:
    map_of_subcommand_to_executor: dict[str, Callable[[], None]] = {
        'version': lambda: _print_version(local_manifest, normal_printer),
        'author': lambda: _print_author(normal_printer),
        'database': lambda: _print_database_info(list_of_teases, normal_printer),
        'platform': lambda: _print_platform_info(normal_printer),
        'memory': lambda: _print_memory_info(normal_printer),
        'cpu': lambda: _print_cpu_info(normal_printer),
        'python': lambda: _print_python_info(normal_printer),
        'licence': lambda: _print_licence_info(normal_printer),
        'forum': lambda: _print_forum_link(normal_printer),
    }

    list_of_executors: list[Callable[[], None]] = argument_stream.pop_list(lambda: argument_stream.pop_optional_dict_value_and_remove(map_of_subcommand_to_executor))
    if not list_of_executors:
        list_of_executors = list(map_of_subcommand_to_executor.values())

    return CommandLoaderResult(
        lambda: execute(list_of_executors),
        CandidateText.space_delimited_list(map_of_subcommand_to_executor),
    )

def execute(list_of_executors: Iterable[Callable[[], None]]) -> None:
    executor: Callable[[], None]
    for executor in list_of_executors:
        executor()

def print_version_one_line(local_manifest: ILocalManifest | None, normal_printer: IPrinter) -> None:
    normal_printer.writeln(f'{_APPLICATION_NAME} {local_manifest.version_number if local_manifest else "(Unknown Version)"}, {local_manifest.date if local_manifest else "(Unknown Date)"}')

def print_database_info_one_line(list_of_teases: Sequence[Tease], normal_printer: IPrinter) -> None:
    oldest_tease_date: datetime.date | None = try_get_oldest_tease_date(list_of_teases)
    newest_tease_date: datetime.date | None = try_get_newest_tease_date(list_of_teases)
    normal_printer.writeln(f"{len(list_of_teases):,} teases loaded ranging from {oldest_tease_date or 'None'} to {newest_tease_date or 'None'}")

def _print_version(local_manifest: ILocalManifest | None, normal_printer: IPrinter) -> None:
    normal_printer.writeln('Application:')
    normal_printer.writeln(f'  {_APPLICATION_NAME}')
    normal_printer.writeln(f"  Variant {f"'{local_manifest.variant_name}'" if local_manifest else "unknown"}")
    normal_printer.writeln(f"  Version {local_manifest.version_number if local_manifest else "unknown"}")
    normal_printer.writeln(f"  Date {local_manifest.date if local_manifest else "unknown"}")

def _print_author(normal_printer: IPrinter) -> None:
    normal_printer.writeln('Author:')
    normal_printer.writeln(f'  {_AUTHOR_NAME}')
    normal_printer.writeln(f'  {get_url_of_author(_AUTHOR_ID)}')

def _print_database_info(list_of_teases: Sequence[Tease], normal_printer: IPrinter) -> None:
    oldest_tease_date: datetime.date | None = try_get_oldest_tease_date(list_of_teases)
    newest_tease_date: datetime.date | None = try_get_newest_tease_date(list_of_teases)
    normal_printer.writeln('Database:')
    normal_printer.writeln(f'  {len(list_of_teases):,} teases')
    normal_printer.writeln(f"  Date from {oldest_tease_date or 'None'} to {newest_tease_date or 'None'}")

def _print_platform_info(normal_printer: IPrinter) -> None:
    normal_printer.writeln('Platform:')
    normal_printer.writeln(f'  {platform.machine()}, {sys.platform}')
    normal_printer.writeln(f'  {platform.platform()}')

def _print_memory_info(normal_printer: IPrinter) -> None:
    normal_printer.writeln('Memory:')
    memory = psutil.virtual_memory()
    normal_printer.writeln(f'  {unit_file_size(memory.total)} total')
    normal_printer.writeln(f'  {unit_file_size(memory.available)} available')

def _print_cpu_info(normal_printer: IPrinter) -> None:
    normal_printer.writeln('CPU:')
    core_count: int | None = psutil.cpu_count(logical=False)
    thread_count: int | None = psutil.cpu_count()
    normal_printer.writeln(f'  {platform.processor()}')
    normal_printer.writeln(f'  {core_count or "Unknown"} cores')
    normal_printer.writeln(f'  {thread_count or "Unknown"} threads')

def _print_python_info(normal_printer: IPrinter) -> None:
    normal_printer.writeln('Python:')
    normal_printer.writeln(f'  {sys.version}')

def _print_licence_info(normal_printer: IPrinter) -> None:
    normal_printer.writeln('Software licence:')
    normal_printer.writeln('  ' + '\n  '.join(_LIST_OF_SOFTWARE_LICENCE_LINES))
    normal_printer.writeln('Tease copyright:')
    normal_printer.writeln('  ' + '\n  '.join(_LIST_OF_TEASE_COPYRIGHT_LINES))

def _print_forum_link(normal_printer: IPrinter) -> None:
    normal_printer.writeln('Support topic:')
    normal_printer.writeln(f'  {_FORUM_THREAD_URL}')

class Help(IHelpInfo):
    @override
    def get_one_line_summary(self) -> str:
        return "Displays information about the application and platform"

    @override
    def get_detailed_summary(self) -> str:
        return (
            "Arguments: [version|author|database|platform|memory|cpu|python|licence|forum]\n"
            "When specified without arguments, will display all of the available information"
            " about the application and the platform that it's running on.\n"
            "Example:\r"
            "  \tShow all information\r"
            "  > \tabout\r"
            "Example:\r"
            "  \tShow the version information only\r"
            "  > \tabout version\n"
            "See also:\r"
            "  \tcopy"
        )
