# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from typing import override
from milodb_common.command_framework.argument_stream import ArgumentStream
from milodb_common.command_framework.candidate_text import CandidateText
from milodb_common.command_framework.i_command import CommandLoaderResult
from milodb_common.command_framework.i_help_info import IHelpInfo
from milodb_common.commands import enums
from milodb_common.commands.enums import OnOrOff
from milodb_common.datum.ref_datum import RefDatum
from milodb_common.output.print.i_printer import IPrinter

def load(argument_stream: ArgumentStream, ref_use_ellipsis: RefDatum[bool], normal_printer: IPrinter) -> CommandLoaderResult:
    new_ellipsis: OnOrOff | None = argument_stream.pop_optional_enum(OnOrOff)
    if new_ellipsis is not None:
        argument_stream.fail_if_not_empty()
        return CommandLoaderResult(
            lambda: execute_change(new_ellipsis, ref_use_ellipsis, normal_printer),
            [],
        )
    return CommandLoaderResult(
        lambda: execute_print(normal_printer, use_ellipsis=ref_use_ellipsis.get()),
        CandidateText.space_delimited_list(enums.lowercase_names(OnOrOff)),
    )

def execute_print(normal_printer: IPrinter, *, use_ellipsis: bool) -> None:
    normal_printer.writeln(f"Current ellipsis mode is '{OnOrOff(use_ellipsis).name.lower()}'")
    normal_printer.writeln(f"Available options are {enums.lowercase_names(OnOrOff)}")

def execute_change(new_use_ellipsis: OnOrOff, ref_use_ellipsis: RefDatum[bool], normal_printer: IPrinter) -> None:
    ref_use_ellipsis.set(new_use_ellipsis.value)
    normal_printer.writeln(f"Changed ellipsis mode to '{new_use_ellipsis.name.lower()}'")

class Help(IHelpInfo):
    @override
    def get_one_line_summary(self) -> str:
        return "Sets whether matching text paragraphs are abbreviated with an ellipsis"

    @override
    def get_detailed_summary(self) -> str:
        return (
            f"Arguments: [{'|'.join(enums.lowercase_names(OnOrOff))}]\n"
            "Enables or disables the abbreviation for text in paragraph matches. Abbreviation"
            " is typically shown with the ellipsis character '\u2026'.\n"
            "When used without arguments, the current setting is shown.\n"
            "Example:\r"
            "  \tTurn off text abbreviation\r"
            "  > \tellipsis off\r"
            "Example:\r"
            "  \tShow the current setting\r"
            "  > \tellipsis\n"
            "See also:\r"
            "  \tshow, browse, format, highlight, pagerefs\n"
        )
