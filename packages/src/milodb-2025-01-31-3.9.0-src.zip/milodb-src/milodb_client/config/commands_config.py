# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
import sys
from abc import ABC, abstractmethod
from typing import override
from milodb_client.config.config_schema import CONFIG_SCHEMA, CommandLaunchOption
from milodb_client.config.framework import IConfig

class ILaunchConfig(ABC):
    @property
    @abstractmethod
    def launch_option(self) -> CommandLaunchOption:
        pass

    @property
    @abstractmethod
    def custom_launch_command(self) -> str:
        pass

class CommandBrowseLaunchConfig(ILaunchConfig):
    def __init__(self, config: IConfig) -> None:
        self._config = config

    @property
    @override
    def launch_option(self) -> CommandLaunchOption:
        return CONFIG_SCHEMA.commands.browse.windows.launch_option.fetch_enum_value_or_default(self._config) if sys.platform == 'win32' else \
               CONFIG_SCHEMA.commands.browse.linux.launch_option.fetch_enum_value_or_default(self._config)
    @property
    @override
    def custom_launch_command(self) -> str:
        return CONFIG_SCHEMA.commands.browse.windows.custom_launch_command.fetch_value_or_default(self._config) if sys.platform == 'win32' else \
               CONFIG_SCHEMA.commands.browse.linux.custom_launch_command.fetch_value_or_default(self._config)

class CommandOpenLaunchConfig(ILaunchConfig):
    def __init__(self, config: IConfig) -> None:
        self._config = config

    @property
    @override
    def launch_option(self) -> CommandLaunchOption:
        return CONFIG_SCHEMA.commands.open.windows.launch_option.fetch_enum_value_or_default(self._config) if sys.platform == 'win32' else \
               CONFIG_SCHEMA.commands.open.linux.launch_option.fetch_enum_value_or_default(self._config)

    @property
    @override
    def custom_launch_command(self) -> str:
        return CONFIG_SCHEMA.commands.open.windows.custom_launch_command.fetch_value_or_default(self._config) if sys.platform == 'win32' else \
               CONFIG_SCHEMA.commands.open.linux.custom_launch_command.fetch_value_or_default(self._config)
