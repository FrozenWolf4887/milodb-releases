# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from milodb_common.output.print.i_printer import IPrinter

def print_fatal_and_prompt_to_continue(message: str, fatal_printer: IPrinter) -> None:
    fatal_printer.writeln(message)
    prompt_to_continue()

def print_warning_and_prompt_to_continue(message: str, warning_printer: IPrinter) -> None:
    warning_printer.writeln(message)
    prompt_to_continue()

def prompt_to_continue() -> None:
    input('Press return to continue...')
