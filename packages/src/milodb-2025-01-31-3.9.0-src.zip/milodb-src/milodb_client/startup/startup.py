# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
import json
import sys
import time
from collections.abc import Iterable
from dataclasses import dataclass
from pathlib import Path
import psutil
from milodb_client.startup.command_line import CommandLine, CommandLineError, parse_command_line
from milodb_client.startup.main import Main
from milodb_client.startup.output import print_fatal_and_prompt_to_continue, print_warning_and_prompt_to_continue
from milodb_client.startup.shutdown_action import IShutdownAction, RestartToCompleteUpdateAction
from milodb_client.updater.i_temp_directory import TempDirectoryError
from milodb_client.updater.manifest.i_schema_types import SchemaLoadError
from milodb_client.updater.manifest.update_sequence_schema import UpdateSequenceSchema
from milodb_client.updater.perform_update import PerformUpdateError, perform_update
from milodb_client.updater.temp_directory import TempDirectory
from milodb_common.output.print.i_printer import IPrinter
from milodb_common.output.print.normal_printer import NormalPrinter
from milodb_common.output.print.prefix_printer import PrefixPrinter
from milodb_common.output.print.stdout_printer import StdoutPrinter

_PID_WAIT_TIMEOUT_SECONDS: int = 10

@dataclass(kw_only=True)
class StartupResult:
    exit_code: int
    shutdown_action: IShutdownAction | None

def startup(list_of_args: Iterable[str]) -> StartupResult:
    stdout_printer: IPrinter = StdoutPrinter()
    normal_printer: IPrinter = NormalPrinter(stdout_printer)
    warning_printer: IPrinter = PrefixPrinter('Warning: ', stdout_printer)
    error_printer: IPrinter = PrefixPrinter('Error: ', stdout_printer)
    fatal_printer: IPrinter = PrefixPrinter('FATAL: ', stdout_printer)

    try:
        command_line: CommandLine = parse_command_line(list_of_args)
    except CommandLineError as ex:
        print_fatal_and_prompt_to_continue(f'Command line error: {ex}', fatal_printer)
        return StartupResult(exit_code=1, shutdown_action=None)

    if (_wait_for_list_of_pids_to_end(command_line.list_of_pids_to_wait_on, _PID_WAIT_TIMEOUT_SECONDS, normal_printer, fatal_printer) and
        _purge_list_of_temp_directories(command_line.list_of_temp_directories_to_purge, normal_printer, warning_printer)
    ):
        if command_line.update_from_sequence_filepath:
            return _process_perform_update(command_line.update_from_sequence_filepath, normal_printer, warning_printer, error_printer, fatal_printer)

        shutdown_action: IShutdownAction | None = Main(stdout_printer).run(autoexec=command_line.autoexec)
        return StartupResult(exit_code=0, shutdown_action=shutdown_action)

    return StartupResult(exit_code=1, shutdown_action=None)

def _wait_for_list_of_pids_to_end(list_of_pids: Iterable[int], timeout_seconds: int, normal_printer: IPrinter, fatal_printer: IPrinter) -> bool:
    return all(_wait_for_pid_to_end(pid, timeout_seconds, normal_printer, fatal_printer) for pid in list_of_pids)

def _wait_for_pid_to_end(pid: int, timeout_seconds: int, normal_printer: IPrinter, fatal_printer: IPrinter) -> bool:
    normal_printer.writeln(f'Waiting for PID {pid} to finish...')
    start_time_ns: int = time.monotonic_ns()
    while psutil.pid_exists(pid):
        time.sleep(0.5)
        elapsed_time_seconds: int = (time.monotonic_ns() - start_time_ns) // 1_000_000_000
        if elapsed_time_seconds >= timeout_seconds:
            print_fatal_and_prompt_to_continue(f"PID {pid} didn't end within {timeout_seconds} seconds", fatal_printer)
            return False
    normal_printer.writeln(f'PID {pid} finished')
    return True

def _purge_list_of_temp_directories(list_of_directories: Iterable[Path], normal_printer: IPrinter, warning_printer: IPrinter) -> bool:
    directory: Path
    for directory in list_of_directories:
        normal_printer.writeln(f"Purge temporary directory '{directory}'")
        try:
            TempDirectory(directory).destroy()
        except TempDirectoryError as ex:
            print_warning_and_prompt_to_continue(f"Couldn't purge directory '{directory}': {ex}", warning_printer)
            return False
    return True

def _process_perform_update(update_sequence_filepath: Path, normal_printer: IPrinter, warning_printer: IPrinter, error_printer: IPrinter, fatal_printer: IPrinter) -> StartupResult:
    try:
        update_strategy_json: object = json.loads(update_sequence_filepath.read_bytes())
    except (OSError, json.JSONDecodeError, UnicodeDecodeError) as ex:
        print_fatal_and_prompt_to_continue(f"Loading '{update_sequence_filepath}' failed: {ex}", fatal_printer)
        return StartupResult(exit_code=1, shutdown_action=None)

    update_sequence: UpdateSequenceSchema = UpdateSequenceSchema()
    try:
        update_sequence.load(update_strategy_json)
    except SchemaLoadError as ex:
        print_fatal_and_prompt_to_continue(f"Parsing '{update_sequence_filepath}' failed: {ex}", fatal_printer)
        return StartupResult(exit_code=1, shutdown_action=None)

    try:
        perform_update(update_sequence, normal_printer, error_printer)
    except PerformUpdateError as ex:
        print_fatal_and_prompt_to_continue(f"Failed to perform update: {ex}", fatal_printer)
        return StartupResult(exit_code=1, shutdown_action=None)

    shutdown_action: IShutdownAction | None = None
    if update_sequence.launch_filename:
        shutdown_action = RestartToCompleteUpdateAction(
            new_application_filepath=Path(update_sequence.launch_filename),
            temp_application_filepath=Path(sys.executable),
            update_sequence_filepath=Path(update_sequence_filepath),
            temp_directory=Path(update_sequence.temp_directory),
            normal_printer=normal_printer,
            fatal_printer=fatal_printer,
        )
    else:
        print_warning_and_prompt_to_continue("There is no known new application that can be started", warning_printer)

    return StartupResult(exit_code=0, shutdown_action=shutdown_action)
