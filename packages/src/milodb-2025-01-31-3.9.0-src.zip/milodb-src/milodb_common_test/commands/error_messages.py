# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
class ErrorMessage:
    EXPECTING_TEXT: str = 'Expecting some text'
    EXPECTING_FIXED_TEXT: str = "Expecting fixed text '{}'"
    EXPECTING_REGEX: str = 'Expecting a regular expression'
    EXPECTING_DECIMAL: str = 'Expecting an integer or decimal value'
    EXPECTING_UNSIGNED_DECIMAL: str = 'Expecting an unsigned integer or decimal value'
    EXPECTING_DATE: str = 'Expecting a date'
    EXPECTING_PARTIAL_DATE: str = 'Expecting a date or partial date'
    EXPECTING_REFID: str = 'Expecting a RefId'
    EXPECTING_SOME_REFID: str = 'Expecting at least 1 RefId'
    EXPECTING_VARIABLE: str = 'Expecting a variable name'

    INSUFFICIENT: str = 'Insufficient parameters'
    INSUFFICIENT_EXPECTING_TEXT: str = f'{INSUFFICIENT}. {EXPECTING_TEXT}'
    INSUFFICIENT_EXPECTING_REGEX: str = f'{INSUFFICIENT}. {EXPECTING_REGEX}'
    INSUFFICIENT_EXPECTING_DECIMAL: str = f'{INSUFFICIENT}. {EXPECTING_DECIMAL}'
    INSUFFICIENT_EXPECTING_UNSIGNED_DECIMAL: str = f'{INSUFFICIENT}. {EXPECTING_UNSIGNED_DECIMAL}'
    INSUFFICIENT_EXPECTING_DATE: str = f'{INSUFFICIENT}. {EXPECTING_DATE}'
    INSUFFICIENT_EXPECTING_PARTIAL_DATE: str = f'{INSUFFICIENT}. {EXPECTING_PARTIAL_DATE}'
    INSUFFICIENT_EXPECTING_REFID: str = f'{INSUFFICIENT}. {EXPECTING_REFID}'
    INSUFFICIENT_EXPECTING_VARIABLE: str = f'{INSUFFICIENT}. {EXPECTING_VARIABLE}'

    INVALID: str = 'Invalid parameter'
    INVALID_DATE: str = "Invalid date. Expected format 'yyyy-mm-dd'"
    INVALID_PARTIAL_DATE: str = "Invalid date or partial date: Expected format 'yyyy' or 'yyyy-mm' or 'yyyy-mm-dd'"
    INVALID_REFID: str = "Invalid RefId. Expecting 'value', '#value', or '@value'"
    INVALID_TEASEID: str = 'TeaseId is not a positive integer'
    INVALID_AUTHORID: str = 'AuthorId is not a positive integer'
    INVALID_ENUM: str = 'Unknown keyword or value'
    INVALID_COMMAND: str = 'Unrecognised command name'

    UNEXPECTED: str = 'Unexpected additional parameter'
