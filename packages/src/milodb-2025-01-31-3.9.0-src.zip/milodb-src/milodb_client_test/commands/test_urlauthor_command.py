# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from collections.abc import Sequence
from dataclasses import dataclass, field
from typing import override
from unittest.mock import Mock, call
from milodb_client.commands import urlauthor_command
from milodb_client.database.tease import Tease
from milodb_client.query.tease_match import TeaseMatch
from milodb_client_test.test import fake_teases
from milodb_common.command_framework.argument_stream import ArgumentStream
from milodb_common.command_framework.i_command import CommandLoaderResult
from milodb_common.output.print.i_printer import IPrinter
from milodb_common_test.commands.error_messages import ErrorMessage
from milodb_common_test.commands.test_command_base import CommandTestBase
from milodb_common_test.test.strict_mock import InterfaceMock

def _get_author_url(tease_id: int) -> str:
    return f'https://milovana.com/forum/memberlist.php?mode=viewprofile&u={tease_id}'

_DEFAULT_LIST_OF_TEASES: Sequence[Tease] = [
    fake_teases.TEASE_ID_1000_AUTHOR_ID_4567,
    fake_teases.TEASE_ID_1234_AUTHOR_ID_6431,
    fake_teases.TEASE_ID_5678_AUTHOR_ID_4567,
]

_DEFAULT_LIST_OF_TEASE_MATHCES: Sequence[TeaseMatch] = [
    TeaseMatch(0, fake_teases.TEASE_ID_5678_AUTHOR_ID_4567, []),
    TeaseMatch(1, fake_teases.TEASE_ID_1234_AUTHOR_ID_6431, []),
    TeaseMatch(2, fake_teases.TEASE_ID_1000_AUTHOR_ID_4567, []),
]

@dataclass
class _Args:
    list_of_teases: Sequence[Tease] = field(default_factory=lambda: list(_DEFAULT_LIST_OF_TEASES))
    list_of_tease_matches: Sequence[TeaseMatch] = field(default_factory=lambda: list(_DEFAULT_LIST_OF_TEASE_MATHCES))
    normal_printer: InterfaceMock = field(default_factory=lambda: InterfaceMock(IPrinter))
    error_printer: InterfaceMock = field(default_factory=lambda: InterfaceMock(IPrinter))

class TestUrlAuthorCommand(CommandTestBase):
    @override
    def setUp(self) -> None:
        self._args = _Args()
        return super().setUp()

    @override
    def load_command(self, argument_stream: ArgumentStream) -> CommandLoaderResult:
        return urlauthor_command.load(
            argument_stream,
            self._args.list_of_teases,
            self._args.list_of_tease_matches,
            self._args.normal_printer,
            self._args.error_printer,
        )

    def test_without_arguments_returns_failure(self) -> None:
        self.command_load([])
        self.assert_argument_error(None, ErrorMessage.INSUFFICIENT_EXPECTING_REFID, [])

    def test_with_matching_index_prints_url(self) -> None:
        self._args.normal_printer.writeln = Mock()
        self.command_load_and_execute(['1'])
        self._args.normal_printer.writeln.assert_called_once_with(_get_author_url(6431))
        self.assert_next_text([])

    def test_with_two_indices_prints_urls(self) -> None:
        self._args.normal_printer.writeln = Mock()
        self.command_load_and_execute(['2', '1'])
        self._args.normal_printer.writeln.assert_has_calls([
            call(_get_author_url(fake_teases.AUTHOR_ID_4567.author_id)),
            call(_get_author_url(fake_teases.AUTHOR_ID_6431.author_id))])

    def test_with_out_of_range_index_prints_error(self) -> None:
        self._args.error_printer.writeln = Mock()
        self.command_load_and_execute(['3'])
        self._args.error_printer.writeln.assert_called_once_with("Match index '3' is out of range")
        self.assert_next_text([])

    def test_with_negative_index_returns_failure(self) -> None:
        self.command_load(['-1'])
        self.assert_argument_error(1, ErrorMessage.INVALID_REFID, [])

    def test_with_one_teaseid_prints_url(self) -> None:
        self._args.normal_printer.writeln = Mock()
        self.command_load_and_execute(['#1234'])
        self._args.normal_printer.writeln.assert_called_once_with(_get_author_url(fake_teases.AUTHOR_ID_6431.author_id))
        self.assert_next_text([])

    def test_with_two_teaseids_prints_urls(self) -> None:
        self._args.normal_printer.writeln = Mock()
        self.command_load_and_execute(['#1234', '#5678'])
        self._args.normal_printer.writeln.assert_has_calls([
            call(_get_author_url(fake_teases.AUTHOR_ID_6431.author_id)),
            call(_get_author_url(fake_teases.AUTHOR_ID_4567.author_id))])
        self.assert_next_text([])

    def test_with_signed_teaseid_returns_failure(self) -> None:
        self.command_load(['#-5678'])
        self.assert_argument_error(1, ErrorMessage.INVALID_TEASEID, [])

    def test_with_unknown_teaseid_returns_failure(self) -> None:
        self._args.error_printer.writeln = Mock()
        self.command_load_and_execute(['#5001'])
        self._args.error_printer.writeln.assert_called_once_with("Unable to find tease for tease id '5001'")
        self.assert_next_text([])

    def test_with_one_authorid_prints_url(self) -> None:
        self._args.normal_printer.writeln = Mock()
        self.command_load_and_execute(['@75310'])
        self._args.normal_printer.writeln.assert_called_once_with(_get_author_url(75310))
        self.assert_next_text([])

    def test_with_two_authorids_prints_urls(self) -> None:
        self._args.normal_printer.writeln = Mock()
        self.command_load_and_execute(['@75310', '@8642'])
        self._args.normal_printer.writeln.assert_has_calls([
            call(_get_author_url(75310)),
            call(_get_author_url(8642))])
        self.assert_next_text([])

    def test_with_signed_authorid_returns_failure(self) -> None:
        self.command_load(['@-8642'])
        self.assert_argument_error(1, ErrorMessage.INVALID_AUTHORID, [])

    def test_with_non_refid_returns_failure(self) -> None:
        self.command_load(['mango'])
        self.assert_argument_error(1, ErrorMessage.INVALID_REFID, [])

    def test_with_mixed_refids_prints_urls(self) -> None:
        self._args.normal_printer.writeln = Mock()
        self.command_load_and_execute(['@75310', '#1234', '2'])
        self._args.normal_printer.writeln.assert_has_calls([
            call(_get_author_url(75310)),
            call(_get_author_url(fake_teases.AUTHOR_ID_6431.author_id)),
            call(_get_author_url(fake_teases.AUTHOR_ID_4567.author_id))])
        self.assert_next_text([])
