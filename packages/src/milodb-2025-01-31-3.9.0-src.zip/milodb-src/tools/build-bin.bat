@REM MiloDB by FrozenWolf is marked with CC0 1.0.
@REM To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0

@echo off
setlocal

echo ** Prepare virtual environment
python -m venv "%TEMP%\mvdb\venv" --clear --upgrade-deps
call "%TEMP%\mvdb\venv\Scripts\activate.bat"

echo ** Install packages
pip install -r requirements-build.txt

echo ** Build executable
set PYTHONOPTIMIZE=2
pyinstaller --distpath bin --workpath "%TEMP%\mvdb\build" --clean ..\milodb.spec

echo ** Dump requirements
pip freeze

call "%TEMP%\mvdb\venv\Scripts\deactivate.bat"
