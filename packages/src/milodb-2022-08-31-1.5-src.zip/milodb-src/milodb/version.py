from typing import Optional

MILODB_VERSION: Optional[str] = '1.5'
MILODB_DATE: Optional[str] = '2022-08-31'
