import milodb.query as query
from milodb.tease import TeaseProperty, TeaseStrListProperty
from enum import Enum
from typing import Callable, List, Optional

class EllipsisLocation(Enum):
    LEFT = 0
    MIDDLE = 1
    RIGHT = 2

    @classmethod
    def from_position(cls, is_first_item: bool, is_last_item: bool) -> 'EllipsisLocation':
        if is_first_item:
            if is_last_item:
                return EllipsisLocation.MIDDLE
            else:
                return EllipsisLocation.LEFT
        else:
            if is_last_item:
                return EllipsisLocation.RIGHT
            else:
                return EllipsisLocation.MIDDLE

def get_url_of_tease(tease_id: int) -> str:
    return f"https://milovana.com/webteases/showtease.php?id={tease_id}"

def get_url_of_author(author_id: int) -> str:
    return f"https://milovana.com/forum/memberlist.php?mode=viewprofile&u={author_id}"

def get_list_of_metadata_matches(tease_property: TeaseProperty, list_of_query_matches: List[query.QueryMatch]) -> List[query.MatchDetails]:
    list_of_matches: List[query.MatchDetails] = []

    query_match: query.QueryMatch
    for query_match in list_of_query_matches:
        if isinstance(query_match, query.FieldQueryMatch) and query_match.tease_property == tease_property:
            list_of_matches.extend(query_match.list_of_matches)

    return list_of_matches

def get_list_of_indexed_metadata_matches(tease_property: TeaseStrListProperty, index: int, list_of_query_matches: List[query.QueryMatch]) -> List[query.MatchDetails]:
    list_of_matches: List[query.MatchDetails] = []

    query_match: query.QueryMatch
    for query_match in list_of_query_matches:
        if isinstance(query_match, query.FieldStrListQueryMatch) and query_match.tease_property == tease_property and query_match.index_of_block == index:
            list_of_matches.extend(query_match.list_of_matches)

    return list_of_matches

def abbrev_text_with_ellipsis(text: str, max_length: int, ellipsis_location: EllipsisLocation, ellipsis_text: str):
    if len(text) > max_length:
        if ellipsis_location == EllipsisLocation.RIGHT:
            text = ellipsis_text + text[len(text) - max_length + 1:]
        elif ellipsis_location == EllipsisLocation.MIDDLE:
            text = text[:max_length // 2] + ellipsis_text + text[len(text) - (max_length - 1) // 2:]
        else:
            text = text[:max_length - 1] + ellipsis_text

    return text

class EllipsifyText:
    def __init__(self, text: str, max_length: int, ellipsis_location: EllipsisLocation, callback_normal_text: Callable[[str], None], callback_ellipsis: Callable[[], None]):
        if ellipsis_location == EllipsisLocation.MIDDLE:
            max_length *= 2
        if len(text) > max_length:
            if ellipsis_location == EllipsisLocation.LEFT:
                callback_ellipsis()
                callback_normal_text(text[len(text) - max_length + 1:])
            elif ellipsis_location == EllipsisLocation.MIDDLE:
                callback_normal_text(text[:max_length // 2])
                callback_ellipsis()
                callback_normal_text(text[len(text) - (max_length - 1) // 2:])
            else:
                callback_normal_text(text[:max_length - 1])
                callback_ellipsis()
        else:
            callback_normal_text(text)

class IterateThroughMatches:
    def __init__(self, text: str, list_of_matches: List[query.MatchDetails], callback_normal_text: Callable[[str, bool, bool], None], callback_matched_text: Callable[[str, bool, bool], None]) -> None:
        self._text: str = text
        self._callback_normal_text: Callable[[str, bool, bool], None] = callback_normal_text
        self._callback_matched_text: Callable[[str, bool, bool], None] = callback_matched_text

        self._match_start_index: int = 0
        self._match_end_index: int = 0
        self._is_currently_in_match: bool = False
        self._is_first_callback: bool = True
        self._list_of_index_match_toggles: List[int] = []

        self._preprocess_match_list(list_of_matches)

        self._index: int = 0
        for self._index in range(0, len(text)):
            self._process_index()

        if self._is_currently_in_match:
            self._callback_matched_text(text[self._match_start_index:], self._is_first_callback, True)
        else:
            self._callback_normal_text(text[self._match_end_index:], self._is_first_callback, True)

    def _preprocess_match_list(self, list_of_matches: List[query.MatchDetails]) -> None:
        if not list_of_matches:
            return

        match: query.MatchDetails
        for match in list_of_matches:
            if match.is_whole_match:
                self._is_currently_in_match = True
                return

        list_of_sorted_matches: List[query.MatchDetails] = sorted(list_of_matches, key=lambda match: (match.start_index, -match.end_index))

        list_of_pruned_matches: List[query.MatchDetails] = []
        current_start_index: Optional[int] = None
        for match in list_of_sorted_matches:
            if current_start_index is None or (current_start_index != match.start_index):
                list_of_pruned_matches.append(match)
                current_start_index = match.start_index

        current_start_index = None
        current_end_index: int = 0
        for match in list_of_pruned_matches:
            if current_start_index is None:
                self._list_of_index_match_toggles.append(match.start_index)
                current_start_index = match.start_index
                current_end_index = match.end_index
            else:
                if current_end_index < match.start_index:
                    self._list_of_index_match_toggles.append(current_end_index)
                    self._list_of_index_match_toggles.append(match.start_index)
                    current_start_index = match.start_index
                    current_end_index = match.end_index
                elif current_end_index < match.end_index:
                    current_end_index = match.end_index
        self._list_of_index_match_toggles.append(current_end_index)

    def _process_index(self) -> None:
        if self._is_index_in_match():
            if not self._is_currently_in_match:
                if self._index > self._match_end_index:
                    self._callback_normal_text(self._text[self._match_end_index:self._index], self._is_first_callback, False)
                    self._is_first_callback = False
                self._is_currently_in_match = True
                self._match_start_index = self._index
        else:
            if self._is_currently_in_match:
                if self._index > self._match_start_index:
                    self._callback_matched_text(self._text[self._match_start_index:self._index], self._is_first_callback, False)
                self._is_first_callback = False
                self._is_currently_in_match = False
                self._match_end_index = self._index

    def _is_index_in_match(self) -> bool:
        if self._text[self._index] == '\n':
            return False

        if self._list_of_index_match_toggles and self._list_of_index_match_toggles[0] == self._index:
            self._list_of_index_match_toggles.pop(0)
            return not self._is_currently_in_match

        return self._is_currently_in_match
