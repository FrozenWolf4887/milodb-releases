# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
import gzip
import sys
from collections.abc import Callable, Mapping
from http import HTTPStatus
from http.client import HTTPException, HTTPResponse, HTTPSConnection, IncompleteRead
from typing import override
from milodb_common.internet.i_path_scraper import IPathScraper
from milodb_common.internet.scrape_result import ScrapeResult

_DEFAULT_TIMEOUT_SECONDS: int = 60
_GET_REQUEST: str = 'GET'
_GZIP_ENCODING: str = 'gzip'
_REQUEST_HEADERS: Mapping[str, str] = {
    'Accept': '*/*',
    'Accept-Encoding': _GZIP_ENCODING,
    'Connection': 'keep-alive',
    'User-Agent': f'MiloDB ({sys.platform})',
}

class HttpsPathScraper(IPathScraper):
    def __init__(self, host_name: str, host_port: int | None = None) -> None:
        self._connection: HTTPSConnection = HTTPSConnection(host_name, host_port or HTTPSConnection.default_port, timeout=_DEFAULT_TIMEOUT_SECONDS)
        self._error_message: str | None = None

    @override
    def try_scrape(self, filepath: str, progress_callback: Callable[[str], None] | None) -> ScrapeResult:
        self._error_message = None
        if self._connect_to_host(progress_callback) and self._send_request(filepath, progress_callback):
            response: HTTPResponse | None = self._receive_response(progress_callback)
            if response:
                if response.status in {HTTPStatus.MOVED_PERMANENTLY, HTTPStatus.FOUND}:
                    self._error_message = f'Redirection response: {response.status} {response.reason}'
                    redirection_uri: str | None = response.getheader('Location')
                    if redirection_uri:
                        self._error_message += f": to '{redirection_uri}'"
                        return ScrapeResult(self._error_message, redirection_uri, b'')
                    self._error_message += ': without location URI'
                    return ScrapeResult(self._error_message, None, b'')

                content: bytes | None = self._read_data(response, progress_callback)
                if content is not None:
                    return ScrapeResult(None, None, content)

        return ScrapeResult(self._error_message, None, b'')

    @override
    def close(self, progress_callback: Callable[[str], None] | None) -> None:
        if self._is_connected:
            if progress_callback:
                progress_callback(f"Disconnecting from '{self._connection.host}:{self._connection.port}'")
            self._connection.close()

    @property
    def _is_connected(self) -> bool:
        return self._connection.sock is not None

    def _connect_to_host(self, progress_callback: Callable[[str], None] | None) -> bool:
        if not self._is_connected:
            if progress_callback:
                progress_callback(f"Connecting to '{self._connection.host}:{self._connection.port}'")
            try:
                self._connection.connect()
            except OSError as ex:
                self._error_message = str(ex)
                return False
        return True

    def _send_request(self, filepath: str, progress_callback: Callable[[str], None] | None) -> bool:
        if progress_callback:
            progress_callback(f"Sending {_GET_REQUEST} request '{filepath}'")
        try:
            self._connection.request(_GET_REQUEST, filepath, headers=_REQUEST_HEADERS)
        except (OSError, HTTPException) as ex:
            self._error_message = str(ex)
            return False
        return True

    def _receive_response(self, progress_callback: Callable[[str], None] | None) -> HTTPResponse | None:
        if progress_callback:
            progress_callback('Receiving response')
        try:
            response: HTTPResponse = self._connection.getresponse()
        except (OSError, HTTPException) as ex:
            self._error_message = str(ex)
            return None

        if response.status in {HTTPStatus.MOVED_PERMANENTLY, HTTPStatus.FOUND, HTTPStatus.OK}:
            return response

        self._error_message = f'Request failed with response: {response.status} {response.reason}'
        try:
            response.read()
        except (OSError, HTTPException) as ex:
            self._error_message += f' and {ex}'

        return None

    def _read_data(self, response: HTTPResponse, progress_callback: Callable[[str], None] | None) -> bytes | None:
        if progress_callback:
            progress_callback('Reading received data')

        content: bytes | None = self._read_data_loop(response, progress_callback)
        if content is None:
            return None

        content_type: str = response.getheader('Content-Type') or 'unspecified'
        content_encoding: str = response.getheader('Content-Encoding') or 'unspecified'
        if progress_callback:
            progress_callback(f"Received {len(content):,} bytes of type '{content_type}' encoded as '{content_encoding}'")

        if response.getheader('Connection') == 'close':
            if progress_callback:
                progress_callback(f"Disconnecting from '{self._connection.host}:{self._connection.port}' at request of server")
            self._connection.close()

        if _GZIP_ENCODING in content_encoding:
            decompressed_data: bytes | None = self._decompress_data(content, progress_callback)
            if decompressed_data is None:
                return None
            content = decompressed_data

        return content

    def _read_data_loop(self, response: HTTPResponse, progress_callback: Callable[[str], None] | None) -> bytes | None:
        content: bytes = b''
        while True:
            try:
                content = content + response.read()
            except IncompleteRead as ex:
                if progress_callback:
                    progress_callback(f'Received partial {len(ex.partial):,} bytes')
                content = content + ex.partial
                continue
            except (OSError, HTTPException) as ex:
                self._error_message = str(ex)
                return None
            else:
                return content

    def _decompress_data(self, content: bytes, progress_callback: Callable[[str], None] | None) -> bytes | None:
        if progress_callback:
            progress_callback('Decompressing received data')

        try:
            content = gzip.decompress(content)
        except gzip.BadGzipFile as ex:
            self._error_message = str(ex)
            return None

        if progress_callback:
            progress_callback(f"Decompressed data is {len(content):,} bytes")

        return content
