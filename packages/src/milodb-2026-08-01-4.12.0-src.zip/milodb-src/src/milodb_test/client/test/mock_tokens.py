# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from collections.abc import Iterable, Sequence
from unittest.mock import Mock
from milodb.common.parser.arg_token_stream import ArgTokenStream
from milodb.common.parser.expanding_token_stream import ExpandedToken
from milodb.common.parser.token import StartEnd, Token
from milodb_test.common.test.strict_mock import ClassMock

def create_fake_tokens(list_of_token_text: Iterable[str]) -> Sequence[ExpandedToken]:
    list_of_tokens: list[ExpandedToken] = []
    token_start_character: int = 0
    token_index: int
    token_text: str
    for token_index, token_text in enumerate(list_of_token_text):
        token_end_character: int = token_start_character + len(token_text)
        topmost_token: Token = Token(token_text, token_index, StartEnd(token_start_character, token_end_character), StartEnd(token_start_character, token_end_character), token_text in '()')
        expanded_token: ExpandedToken = ExpandedToken(token_text, token_index, StartEnd(token_start_character, token_end_character), StartEnd(token_start_character, token_end_character), token_text in '()', topmost_token=topmost_token, variable_depth=0)
        list_of_tokens.append(expanded_token)
        token_start_character = token_end_character + 1
    return list_of_tokens

def create_tokens_and_arg_token_stream(list_of_token_text: Iterable[str]) -> tuple[Sequence[ExpandedToken], ArgTokenStream]:
    list_of_tokens: Sequence[ExpandedToken] = create_fake_tokens(list_of_token_text)
    sequencer: _Sequencer[ExpandedToken] = _Sequencer(list_of_tokens)
    def get_marked_tokens() -> Sequence[Token]:
        return list_of_tokens[sequencer.marked_index:sequencer.current_index]
    mock_arg_token_stream = ClassMock(ArgTokenStream,
        next = Mock(side_effect=sequencer.pop_item),
        next_arg = Mock(side_effect=lambda _: sequencer.pop_item()),
        set_token_arg_type = Mock(),
        mark_token_index = Mock(side_effect=sequencer.mark_index),
        get_popped_tokens_since_mark = Mock(side_effect=get_marked_tokens),
    )
    return list_of_tokens, mock_arg_token_stream

def create_arg_token_stream(list_of_token_text: Iterable[str]) -> ArgTokenStream:
    arg_token_stream: ArgTokenStream
    _, arg_token_stream = create_tokens_and_arg_token_stream(list_of_token_text)
    return arg_token_stream

class _Sequencer[T]:
    def __init__(self, list_of_items: Sequence[T]) -> None:
        self._list_of_items: Sequence[T] = list_of_items
        self._index: int = 0
        self._marked_index: int = 0

    def pop_item(self) -> T | None:
        item: T | None = None
        if self._index < len(self._list_of_items):
            item = self._list_of_items[self._index]
            self._index += 1
        return item

    @property
    def current_index(self) -> int:
        return self._index

    def mark_index(self) -> None:
        self._marked_index = self._index

    @property
    def marked_index(self) -> int:
        return self._marked_index
