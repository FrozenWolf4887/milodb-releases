# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import functools
from collections.abc import Callable, Sequence
from typing import override
from milodb.client.database.tease import Tease
from milodb.client.query.field_match import FieldItemMatch, FieldMatch, FieldMatchIndices, FieldPageListMatch, FieldStrListMatch
from milodb.client.query.tease_match import TeaseMatch

class NonIndexedTeaseMatch:
    def __init__(self, expected_tease: Tease) -> None:
        self._expected_tease: Tease = expected_tease

    @override
    def __eq__(self, other: object) -> bool:
        return isinstance(other, TeaseMatch) and other.index_of_match is None and len(other.list_of_field_matches) == 0 and other.tease == self._expected_tease

    @override
    def __hash__(self) -> int:
        return hash(self._expected_tease)

    @override
    def __repr__(self) -> str:
        return f"TeaseMatch(None, {self._expected_tease}, [])"

class ListOfTeaseMatchesMatch:
    def __init__(self, list_of_expected_tease_matches: Sequence[TeaseMatch], *, debug: bool = False) -> None:
        self._list_of_expected_tease_matches: Sequence[TeaseMatch] = list_of_expected_tease_matches
        self._debug: bool = debug

    @override
    def __eq__(self, other: object) -> bool:
        is_equal: bool = True

        if isinstance(other, list) and len(other) == len(self._list_of_expected_tease_matches):
            index: int
            expected_tease_match: TeaseMatch
            for index, expected_tease_match in enumerate(self._list_of_expected_tease_matches):
                actual_tease_match: object = other[index]
                if isinstance(actual_tease_match, TeaseMatch):
                    if not is_equal_tease_match(expected_tease_match, actual_tease_match, debug=self._debug):
                        is_equal = False
                else:
                    is_equal = False
        else:
            is_equal = False

        return is_equal

    @override
    def __hash__(self) -> int:
        return hash(self._list_of_expected_tease_matches)

    @override
    def __repr__(self) -> str:
        return f"<TeaseMatch List> '{self._list_of_expected_tease_matches}'"

def is_equal_list_of_tease_matches(left: Sequence[TeaseMatch], right: Sequence[TeaseMatch], *, debug: bool = False) -> bool:
    if left is right:
        return True

    is_equal: bool = True

    if len(left) == len(right):
        index: int
        left_tease_match: TeaseMatch
        for index, left_tease_match in enumerate(left):
            right_tease_match: TeaseMatch = right[index]
            if not is_equal_tease_match(left_tease_match, right_tease_match, debug=debug):
                _debug_print(debug=debug, msg=functools.partial(lambda index: f'Mismatched TeaseMatch[{index}]', index))
                is_equal = False
    else:
        _debug_print(debug=debug, msg=lambda: f'Mismatched len(Sequence[TeaseMatch]): left={len(left)}, right={len(right)}')
        is_equal = False

    return is_equal

def is_equal_tease_match(left: TeaseMatch, right: TeaseMatch, *, debug: bool = False) -> bool:
    if left is right:
        return True

    is_equal: bool = True

    if left.index_of_match != right.index_of_match:
        _debug_print(debug=debug, msg=lambda: f'Mismatched TeaseMatch.index_of_match: left={left.index_of_match}, right={right.index_of_match}')
        is_equal = False

    if left.tease is not right.tease:
        _debug_print(debug=debug, msg=lambda: f'Mismatched TeaseMatch.tease: left={left.tease}, right={right.tease}')
        is_equal = False

    if not is_equal_list_of_field_matches(left.list_of_field_matches, right.list_of_field_matches, debug=debug):
        _debug_print(debug=debug, msg=lambda: 'Mismatched TeaseMatch.list_of_field_matches')
        is_equal = False

    return is_equal

def is_equal_list_of_field_matches(left: Sequence[FieldMatch], right: Sequence[FieldMatch], *, debug: bool = False) -> bool:
    if left is right:
        return True

    is_equal: bool = True

    if len(left) == len(right):
        index: int
        left_field_match: FieldMatch
        for index, left_field_match in enumerate(left):
            right_field_match: FieldMatch = right[index]
            if not is_equal_field_match(left_field_match, right_field_match, debug=debug):
                _debug_print(debug=debug, msg=functools.partial(lambda index: f'Mismatched IFieldMatch[{index}]', index))
                is_equal = False
    else:
        _debug_print(debug=debug, msg=lambda: f'Mismatched len(Sequence[IFieldMatch]): left={len(left)}, right={len(right)}')
        is_equal = False

    return is_equal

def is_equal_field_match(left: FieldMatch, right: FieldMatch, *, debug: bool = False) -> bool:
    if left is right:
        return True

    is_equal: bool = True

    if isinstance(right, type(left)):
        if isinstance(left, FieldItemMatch | FieldStrListMatch) and isinstance(right, FieldItemMatch | FieldStrListMatch):
            if left.tease_property != right.tease_property:
                is_equal = False
                _debug_print(debug=debug, msg=lambda: f'Mismatched FieldItemMatch.tease_property: left={left.tease_property}, right={right.tease_property}')
        elif isinstance(left, FieldPageListMatch) and isinstance(right, FieldPageListMatch) and (left.index_of_page != right.index_of_page or left.page is not right.page):
            is_equal = False
            _debug_print(debug=debug, msg=lambda: f'Mismatched FieldPageListMatch: left={left.page}, {left.index_of_page}, right={right.page}, {right.index_of_page}')
    else:
        is_equal = False
        _debug_print(debug=debug, msg=lambda: 'Mismatched Type[FieldMatch]: left={type(left)}, right={type(right)}')

    if not is_equal_list_of_indices(left.list_of_indices, right.list_of_indices, debug=debug):
        is_equal = False
        _debug_print(debug=debug, msg=lambda: 'Mismatched FieldMatch.list_of_indices')

    return is_equal

def is_equal_list_of_indices(left: Sequence[FieldMatchIndices], right: Sequence[FieldMatchIndices], *, debug: bool = False) -> bool:
    if left is right:
        return True

    is_equal: bool = True

    if len(left) == len(right):
        index: int
        left_indices: FieldMatchIndices
        for index, left_indices in enumerate(left):
            right_indices: FieldMatchIndices = right[index]
            if not is_equal_indices(left_indices, right_indices, debug=debug):
                _debug_print(debug=debug, msg=functools.partial(lambda index: f'Mismatched FieldMatch.Indices[{index}]', index))
                is_equal = False
    else:
        _debug_print(debug=debug, msg=lambda: f'Mismatched len(Sequence[FieldMatchIndices]): left={len(left)}, right={len(right)}')
        is_equal = False

    return is_equal

def is_equal_indices(left: FieldMatchIndices, right: FieldMatchIndices, *, debug: bool = False) -> bool:
    if left is right:
        return True

    is_equal: bool = True

    if left.start_index != right.start_index:
        _debug_print(debug=debug, msg=lambda: f'Mismatched IFieldMatch.Indices.start_index: left={left.start_index}, right={right.start_index}')
        is_equal = False

    if left.end_index != right.end_index:
        _debug_print(debug=debug, msg=lambda: f'Mismatched IFieldMatch.Indices.end_index: left={left.end_index}, right={right.end_index}')
        is_equal = False

    return is_equal

def _debug_print(*, debug: bool, msg: Callable[[], str]) -> None:
    if debug:
        print(msg())
