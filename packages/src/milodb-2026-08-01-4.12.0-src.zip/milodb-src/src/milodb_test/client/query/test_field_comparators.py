# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import unittest
from collections.abc import Callable
from typing import TYPE_CHECKING
from unittest.mock import Mock
from milodb.client.database.tease import TeaseProperty
from milodb.client.query.field_comparators import FieldAuthorStatusIs, FieldDateCompare, FieldPageListContains, FieldPageListMatches, FieldStatusIs, FieldStrContains, FieldStrIs, FieldStrListContains, FieldStrListIs, FieldStrListMatches, FieldStrMatches, FieldTotmIs, FieldTypeIs, FieldUnsignedFloatCompare, FieldUnsignedIntCompare
from milodb.client.query.field_predicate import IFieldPredicate
from milodb.common.parser.arg_token_stream import ArgTokenStream
from milodb.common.parser.arg_type import ArgType
from milodb_test.client.test.mock_tokens import create_tokens_and_arg_token_stream
if TYPE_CHECKING:
    from collections.abc import Sequence
    from milodb.common.parser.expanding_token_stream import ExpandedToken

class TestFieldComparatorsCaptureAssociatedTokens(unittest.TestCase):
    LIST_OF_FIELD_PREDICATE_BUILDERS: tuple[tuple[type, str, Callable[[ArgTokenStream], IFieldPredicate]], ...] = (
        (FieldStrIs, 'text', lambda arg_token_stream: FieldStrIs(TeaseProperty.title, arg_token_stream)),
        (FieldStrContains, 'text', lambda arg_token_stream: FieldStrContains(TeaseProperty.title, arg_token_stream)),
        (FieldStrMatches, 'text', lambda arg_token_stream: FieldStrMatches(TeaseProperty.title, arg_token_stream)),
        (FieldStrListIs, 'text', lambda arg_token_stream: FieldStrListIs(TeaseProperty.list_of_tags, arg_token_stream)),
        (FieldStrListContains, 'text', lambda arg_token_stream: FieldStrListContains(TeaseProperty.list_of_tags, arg_token_stream)),
        (FieldStrListMatches, 'text', lambda arg_token_stream: FieldStrListMatches(TeaseProperty.list_of_tags, arg_token_stream)),
        (FieldUnsignedIntCompare, '10', lambda arg_token_stream: FieldUnsignedIntCompare(TeaseProperty.tease_id, arg_token_stream, Mock())),
        (FieldUnsignedFloatCompare, '1.0', lambda arg_token_stream: FieldUnsignedFloatCompare(TeaseProperty.rating, arg_token_stream, Mock())),
        (FieldTypeIs, 'reg', lambda arg_token_stream: FieldTypeIs(TeaseProperty.tease_type, arg_token_stream)),
        (FieldDateCompare, '2000-01-01', lambda arg_token_stream: FieldDateCompare(TeaseProperty.date, arg_token_stream, Mock())),
        (FieldTotmIs, 'winner', FieldTotmIs),
        (FieldStatusIs, 'active', FieldStatusIs),
        (FieldAuthorStatusIs, 'active', FieldAuthorStatusIs),
        (FieldPageListMatches, 'text', FieldPageListMatches),
        (FieldPageListContains, 'text', FieldPageListContains),
    )

    def test_associates_tokens_from_starting_mark(self) -> None:
        field_predicate_type: type
        argument_value: str
        field_predicate_constructor: Callable[[ArgTokenStream], IFieldPredicate]
        for field_predicate_type, argument_value, field_predicate_constructor in self.LIST_OF_FIELD_PREDICATE_BUILDERS:
            with self.subTest(f"{field_predicate_type.__name__} '{argument_value}'"):
                list_of_tokens: Sequence[ExpandedToken]
                arg_token_stream: ArgTokenStream
                list_of_tokens, arg_token_stream = create_tokens_and_arg_token_stream([
                    argument_value,
                    argument_value,
                    "mango",
                ])

                arg_token_stream.mark_token_index()

                field_predicate = field_predicate_constructor(arg_token_stream)

                self.assertSequenceEqual(list_of_tokens[:1], field_predicate.list_of_associated_tokens)

                field_predicate = field_predicate_constructor(arg_token_stream)

                self.assertSequenceEqual(list_of_tokens[:2], field_predicate.list_of_associated_tokens)

    def test_associates_tokens_from_middle_mark(self) -> None:
        field_predicate_type: type
        argument_value: str
        field_predicate_constructor: Callable[[ArgTokenStream], IFieldPredicate]
        for field_predicate_type, argument_value, field_predicate_constructor in self.LIST_OF_FIELD_PREDICATE_BUILDERS:
            with self.subTest(f"{field_predicate_type.__name__} '{argument_value}'"):
                list_of_tokens: Sequence[ExpandedToken]
                arg_token_stream: ArgTokenStream
                list_of_tokens, arg_token_stream = create_tokens_and_arg_token_stream([
                    "mango",
                    argument_value,
                    argument_value,
                ])

                arg_token_stream.next_arg(ArgType.ARG_UNKNOWN)
                arg_token_stream.mark_token_index()

                predicate = field_predicate_constructor(arg_token_stream)

                self.assertSequenceEqual(list_of_tokens[1:2], predicate.list_of_associated_tokens)

                predicate = field_predicate_constructor(arg_token_stream)

                self.assertSequenceEqual(list_of_tokens[1:3], predicate.list_of_associated_tokens)
