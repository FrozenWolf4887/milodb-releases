# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from collections import defaultdict
from collections.abc import Iterable, Sequence
from dataclasses import dataclass
from typing import Protocol, TYPE_CHECKING
from milodb.client.database.tease import Tease, TeaseProperty
from milodb.client.query.field_match import FieldItemMatch, FieldMatch, FieldMatchIndices, FieldPageListMatch, FieldStrListMatch
from milodb.client.query.match_result import MatchResult, TrueMatchResult
from milodb.client.query.query import IQuery
from milodb.client.query.tease_match import TeaseMatch
if TYPE_CHECKING:
    from milodb.client.database.tease_page import TeasePage

@dataclass
class PostfixError(Exception):
    message: str

@dataclass
class PostfixQueryResult:
    total_match_count: int
    max_match_count: int
    was_max_match_count_reached: bool
    total_tease_count: int
    queried_tease_count: int
    list_of_tease_matches: Sequence[TeaseMatch]

class _QueryProgressCallback(Protocol):
    def __call__(self, *, percentage_complete: int) -> None:
        pass

def execute_postfix_query(list_of_teases: Sequence[Tease], chain_of_postfix_queries: Iterable[IQuery], max_match_count: int, progress_callback: _QueryProgressCallback | None = None) -> PostfixQueryResult:
    list_of_tease_matches: list[TeaseMatch] = []
    queried_tease_count: int

    percentage_complete: int = -1
    total_match_count: int = 0
    was_max_match_count_reached: bool = False

    index_of_tease: int
    tease: Tease
    for index_of_tease, tease in enumerate(list_of_teases):
        if progress_callback:
            new_percentage_complete: int = 100 * index_of_tease // len(list_of_teases)
            if new_percentage_complete != percentage_complete:
                percentage_complete = new_percentage_complete
                progress_callback(percentage_complete=percentage_complete)

        stack_of_match_results: list[MatchResult] = []

        query_object: IQuery
        for query_object in chain_of_postfix_queries:
            query_object.perform_query(stack_of_match_results, tease)

        if len(stack_of_match_results) == 1:
            match_result: MatchResult = stack_of_match_results[0]
            if isinstance(match_result, TrueMatchResult):
                match_count: int = sum(len(field_match.list_of_indices) for field_match in match_result.list_of_field_matches)
                if total_match_count + match_count <= max_match_count:
                    merged_list_of_field_matches: Sequence[FieldMatch] = _merge_list_of_field_matches(match_result.list_of_field_matches)
                    list_of_tease_matches.append(TeaseMatch(len(list_of_tease_matches) + 1, tease, merged_list_of_field_matches))
                    total_match_count += match_count
                else:
                    was_max_match_count_reached = True
                    queried_tease_count = index_of_tease
                    break
        else:
            msg = "Bad expression: Expected a single result remaining on the stack"
            raise PostfixError(msg)
    else:
        queried_tease_count = len(list_of_teases)

    if progress_callback:
        progress_callback(percentage_complete=100)

    return PostfixQueryResult(total_match_count, max_match_count, was_max_match_count_reached, len(list_of_teases), queried_tease_count, list_of_tease_matches)

def _merge_list_of_field_matches(list_of_field_matches: Iterable[FieldMatch]) -> list[FieldMatch]:
    return [
        *_merge_list_of_field_item_matches(match for match in list_of_field_matches if isinstance(match, FieldItemMatch)),
        *_merge_list_of_field_str_list_matches(match for match in list_of_field_matches if isinstance(match, FieldStrListMatch)),
        *_merge_list_of_field_page_list_matches(match for match in list_of_field_matches if isinstance(match, FieldPageListMatch)),
    ]

def _merge_list_of_field_item_matches(list_of_field_item_matches: Iterable[FieldItemMatch]) -> list[FieldItemMatch]:
    merged_list: list[FieldItemMatch] = []

    map_of_tease_property_to_list_of_matches: dict[TeaseProperty.Any, list[FieldItemMatch]] = defaultdict(list)
    match: FieldItemMatch
    for match in list_of_field_item_matches:
        map_of_tease_property_to_list_of_matches[match.tease_property].append(match)

    tease_property: TeaseProperty.Any
    list_of_matches: Sequence[FieldItemMatch]
    for tease_property, list_of_matches in map_of_tease_property_to_list_of_matches.items():
        list_of_indices: list[FieldMatchIndices] = []
        for match in list_of_matches:
            list_of_indices.extend(match.list_of_indices)
        merged_list.append(FieldItemMatch(tease_property, list_of_indices))

    return merged_list

def _merge_list_of_field_str_list_matches(list_of_field_matches: Iterable[FieldStrListMatch]) -> list[FieldStrListMatch]:
    merged_list: list[FieldStrListMatch] = []

    map_of_tease_property_to_block_index_to_list_of_matches: dict[TeaseProperty.StrList, dict[int, list[FieldStrListMatch]]] = defaultdict(lambda: defaultdict(list))
    match: FieldStrListMatch
    for match in list_of_field_matches:
        map_of_tease_property_to_block_index_to_list_of_matches[match.tease_property][match.index_of_block].append(match)

    tease_property: TeaseProperty.StrList
    map_of_block_index_to_list_of_matches: dict[int, list[FieldStrListMatch]]
    for tease_property, map_of_block_index_to_list_of_matches in map_of_tease_property_to_block_index_to_list_of_matches.items():
        block_index: int
        list_of_matches: Sequence[FieldStrListMatch]
        for block_index, list_of_matches in map_of_block_index_to_list_of_matches.items():
            merged_list.append(FieldStrListMatch(tease_property, [ indices for match in list_of_matches for indices in match.list_of_indices ], block_index))

    return merged_list

def _merge_list_of_field_page_list_matches(list_of_field_matches: Iterable[FieldPageListMatch]) -> list[FieldPageListMatch]:
    merged_list: list[FieldPageListMatch] = []

    map_of_page_index_to_list_of_matches: dict[int, list[FieldPageListMatch]] = defaultdict(list)
    match: FieldPageListMatch
    for match in list_of_field_matches:
        map_of_page_index_to_list_of_matches[match.index_of_page].append(match)

    page_index: int
    list_of_matches: Sequence[FieldPageListMatch]
    for page_index, list_of_matches in map_of_page_index_to_list_of_matches.items():
        page: TeasePage = list_of_matches[0].page
        merged_list.append(FieldPageListMatch(TeaseProperty.list_of_pages, [ indices for match in list_of_matches for indices in match.list_of_indices ], page, page_index))

    return merged_list
