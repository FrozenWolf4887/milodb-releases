# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import datetime
from abc import abstractmethod
from collections.abc import Callable, Sequence
from milodb.client.database.tease import TeaseProperty
from milodb.client.query.query import IQuery
from milodb.common.parser.expanding_token_stream import ExpandingTokenStream
from milodb.common.parser.token import Token
from milodb.common.types.partial_date import PartialDate

class IFieldPredicate(IQuery):
    @property
    @abstractmethod
    def tease_property(self) -> TeaseProperty.Any:
        pass

    @property
    @abstractmethod
    def list_of_associated_tokens(self) -> Sequence[Token]:
        pass

class IFieldFloatPredicate(IFieldPredicate):
    @abstractmethod
    def __init__(self, tease_property: TeaseProperty.Float, token_stream: ExpandingTokenStream, compare_func: Callable[[float, float], bool]) -> None:
        pass

class IFieldIntPredicate(IFieldPredicate):
    @abstractmethod
    def __init__(self, tease_property: TeaseProperty.Int, token_stream: ExpandingTokenStream, compare_func: Callable[[int, int], bool]) -> None:
        pass

class IFieldStrPredicate(IFieldPredicate):
    @abstractmethod
    def __init__(self, tease_property: TeaseProperty.Str, token_stream: ExpandingTokenStream) -> None:
        pass

class IFieldStrListPredicate(IFieldPredicate):
    @abstractmethod
    def __init__(self, tease_property: TeaseProperty.StrList, token_stream: ExpandingTokenStream) -> None:
        pass

class IFieldTypePredicate(IFieldPredicate):
    @abstractmethod
    def __init__(self, tease_property: TeaseProperty.TeaseTyp, token_stream: ExpandingTokenStream) -> None:
        pass

class IFieldDatePredicate(IFieldPredicate):
    @abstractmethod
    def __init__(self, tease_property: TeaseProperty.Date, token_stream: ExpandingTokenStream, compare_func: Callable[[datetime.date, PartialDate], bool]) -> None:
        pass

class IFieldTotmPredicate(IFieldPredicate):
    @abstractmethod
    def __init__(self, token_stream: ExpandingTokenStream) -> None:
        pass

class IFieldStatusPredicate(IFieldPredicate):
    @abstractmethod
    def __init__(self, token_stream: ExpandingTokenStream) -> None:
        pass

class IFieldAuthorStatusPredicate(IFieldPredicate):
    @abstractmethod
    def __init__(self, token_stream: ExpandingTokenStream) -> None:
        pass

class IFieldPageListPredicate(IFieldPredicate):
    @abstractmethod
    def __init__(self, token_stream: ExpandingTokenStream) -> None:
        pass
