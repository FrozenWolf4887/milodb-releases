# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from collections.abc import MutableSequence, Sequence
from typing import TYPE_CHECKING, override
from milodb.client.database.tease import Tease
from milodb.client.query.match_result import FALSE_MATCH_RESULT, MatchResult, TrueMatchResult
from milodb.client.query.postfix_query_executor import PostfixError
from milodb.client.query.query import IQuery
if TYPE_CHECKING:
    from milodb.client.query.field_match import FieldMatch

class And(IQuery):
    @override
    def perform_query(self, stack_of_match_results: MutableSequence[MatchResult], tease: Tease) -> None:
        try:
            right: MatchResult = stack_of_match_results.pop()
            left: MatchResult = stack_of_match_results.pop()
        except IndexError as ex:
            msg = "Bad expression: AND requires at least two match results on the stack"
            raise PostfixError(msg) from ex

        if isinstance(left, TrueMatchResult) and isinstance(right, TrueMatchResult):
            combined: Sequence[FieldMatch] = [ *left.list_of_field_matches, *right.list_of_field_matches ]
            stack_of_match_results.append(TrueMatchResult(combined))
        else:
            stack_of_match_results.append(FALSE_MATCH_RESULT)

class Not(IQuery):
    @override
    def perform_query(self, stack_of_match_results: MutableSequence[MatchResult], tease: Tease) -> None:
        try:
            result: MatchResult = stack_of_match_results.pop()
        except IndexError as ex:
            msg = "Bad expression: NOT requires at least one match result on the stack"
            raise PostfixError(msg) from ex

        if isinstance(result, TrueMatchResult):
            stack_of_match_results.append(FALSE_MATCH_RESULT)
        else:
            stack_of_match_results.append(TrueMatchResult([]))

class Or(IQuery):
    @override
    def perform_query(self, stack_of_match_results: MutableSequence[MatchResult], tease: Tease) -> None:
        try:
            right: MatchResult = stack_of_match_results.pop()
            left: MatchResult = stack_of_match_results.pop()
        except IndexError as ex:
            msg = "Bad expression: OR requires at least two match results on the stack"
            raise PostfixError(msg) from ex

        if isinstance(left, TrueMatchResult):
            if isinstance(right, TrueMatchResult):
                combined: Sequence[FieldMatch] = [ *left.list_of_field_matches, *right.list_of_field_matches ]
                stack_of_match_results.append(TrueMatchResult(combined))
            else:
                stack_of_match_results.append(left)
        elif isinstance(right, TrueMatchResult):
            stack_of_match_results.append(right)
        else:
            stack_of_match_results.append(FALSE_MATCH_RESULT)
