# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from collections.abc import Sequence
from typing import NamedTuple
from milodb.client.database.tease import Tease
from milodb.client.query.field_match import FieldMatch

class TeaseMatch(NamedTuple):
    index_of_match: int | None
    tease: Tease
    list_of_field_matches: Sequence[FieldMatch]

    def get_match_count(self) -> int:
        return sum(len(field_match.list_of_indices) for field_match in self.list_of_field_matches)
