# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from collections.abc import Sequence
from typing import NamedTuple
from milodb.client.query.field_match import FieldMatch

type MatchResult = TrueMatchResult | _FalseMatchResult

class TrueMatchResult(NamedTuple):
    list_of_field_matches: Sequence[FieldMatch]

class _FalseMatchResult:
    pass

FALSE_MATCH_RESULT = _FalseMatchResult()
