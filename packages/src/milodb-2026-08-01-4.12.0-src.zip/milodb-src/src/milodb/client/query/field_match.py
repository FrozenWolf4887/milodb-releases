# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from collections.abc import Sequence
from typing import NamedTuple
from milodb.client.database.tease import TeaseProperty
from milodb.client.database.tease_page import TeasePage

class FieldMatchIndices(NamedTuple):
    start_index: int
    end_index: int

WHOLE_FIELD_MATCH: FieldMatchIndices = FieldMatchIndices(0, 0)

class FieldItemMatch(NamedTuple):
    tease_property: TeaseProperty.Any
    list_of_indices: Sequence[FieldMatchIndices]

class FieldStrListMatch(NamedTuple):
    tease_property: TeaseProperty.StrList
    list_of_indices: Sequence[FieldMatchIndices]
    index_of_block: int

class FieldPageListMatch(NamedTuple):
    tease_property: TeaseProperty.PageList
    list_of_indices: Sequence[FieldMatchIndices]
    page: TeasePage
    index_of_page: int

type FieldMatch = FieldItemMatch | FieldStrListMatch | FieldPageListMatch
