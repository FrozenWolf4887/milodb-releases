# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from typing import NamedTuple

class TeasePage(NamedTuple):
    page_ref: str
    text: str
