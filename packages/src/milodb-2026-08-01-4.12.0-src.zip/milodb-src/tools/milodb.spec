# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
# -*- mode: python ; coding: utf-8 -*-
# spell-checker: disable
import platform
import sys
from pathlib import Path
from PyInstaller.building.build_main import Analysis
from PyInstaller.building.datastruct import TOC
from PyInstaller.building.api import EXE, PYZ

_SRC_PATH: Path = Path('..')/'src'
_RESOURCE_PATH: Path = _SRC_PATH/'milodb'/'client'/'resources'
_APP_ICON: Path = _RESOURCE_PATH/'app-icon.ico'
_APP_IMAGE: Path = _RESOURCE_PATH/'app-icon.png'
_IS_WINDOWS_BUILD: bool = sys.platform == 'win32'
_STRIP_LIBRARIES: bool = not _IS_WINDOWS_BUILD
_EXCLUDE_BINARIES: tuple[str, ...] = ()
_TARGET_NAME: str = f'milodb-{sys.platform}-{platform.machine()}-gui'.lower()

_analysis = Analysis(
    [_SRC_PATH/'entry_gui.pyw'],
    pathex = [],
    binaries = [],
    datas = [
        (_APP_ICON, 'resources'),
        (_APP_IMAGE, 'resources'),
    ],
    hiddenimports = ['PIL._tkinter_finder'],
    hookspath = [],
    hooksconfig = {},
    runtime_hooks = [],
    excludes = ['pdb', 'pydoc', 'pkg_resources', 'unittest'],
    win_no_prefer_redirects = False,
    win_private_assemblies = False,
    cipher = None,
    noarchive = False,
    optimize = 2,
)

def any_starts_with(text: str, list_of_text: tuple[str, ...]) -> bool:
    return any(text.startswith(value) for value in list_of_text)

_analysis.binaries = TOC([binary for binary in _analysis.binaries if not any_starts_with(binary[0], _EXCLUDE_BINARIES)])

_pyz = PYZ(
    _analysis.pure,
    _analysis.zipped_data,
    cipher = None,
)

EXE(
    _pyz,
    _analysis.scripts,
    _analysis.binaries,
    _analysis.zipfiles,
    _analysis.datas,
    [],
    name = _TARGET_NAME,
    icon = _APP_ICON,
    debug = False,
    bootloader_ignore_signals = False,
    strip = _STRIP_LIBRARIES,
    upx = False,
    upx_exclude = [],
    runtime_tmpdir = None,
    console = False,
    disable_windowed_traceback = False,
    target_arch = None,
    codesign_identity = None,
    entitlements_file = None,
)
