# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from urllib.parse import ParseResult
from milodb_common.internet.https_web_scraper import HttpsWebScraper
from milodb_common.internet.i_uri_scraper_factory import UriScraperFactoryError
from milodb_common.internet.i_uri_scraper_parser import IUriScraperParser
from milodb_common.internet.i_web_scraper import IWebScraper

_HTTPS_URI_SCHEME: str = 'https'

class HttpsUriScraperParser(IUriScraperParser):
    def get_scheme_name(self) -> str:
        return _HTTPS_URI_SCHEME

    def try_get_scraper_and_filepath(self, uri_parse_result: ParseResult) -> tuple[IWebScraper, str] | None:
        if uri_parse_result.scheme != _HTTPS_URI_SCHEME:
            return None
        if not uri_parse_result.hostname:
            raise UriScraperFactoryError('has no hostname')
        try:
            port: int | None = uri_parse_result.port
        except ValueError as ex:
            raise UriScraperFactoryError(f'has invalid port number: {ex}') from ex

        if not uri_parse_result.path:
            raise UriScraperFactoryError('has no path')

        scraper: IWebScraper
        if port is not None:
            scraper = HttpsWebScraper(uri_parse_result.hostname, port)
        else:
            scraper = HttpsWebScraper(uri_parse_result.hostname)

        return scraper, uri_parse_result._replace(scheme='', netloc='').geturl()
