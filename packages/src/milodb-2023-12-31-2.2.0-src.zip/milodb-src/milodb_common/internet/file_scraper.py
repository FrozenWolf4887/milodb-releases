# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from collections.abc import Callable
from urllib.request import url2pathname
from milodb_common.internet.i_web_scraper import IWebScraper, ScrapeResult

_SCHEME_NAME: str = 'file'

class FileScraper(IWebScraper):
    def __init__(self) -> None:
        self._progress_callback: Callable[[str], None] | None = None

    def get_path_text(self, filepath: str) -> str:
        return f'{_SCHEME_NAME}://{filepath}'

    def try_scrape(self, filepath: str, progress_callback: Callable[[str], None]) -> ScrapeResult:
        self._progress_callback = progress_callback

        decoded_filepath: str = url2pathname(filepath)
        self._progress_callback(f"Reading file '{decoded_filepath}'")

        try:
            with open(decoded_filepath, 'rb') as file:
                content: bytes = file.read()
                self._progress_callback(f'Read {len(content):,} bytes')
                return ScrapeResult(None, content)
        except IOError as ex:
            return ScrapeResult(f"Cannot read from file '{decoded_filepath}': {ex}", bytes())

    def close(self) -> None:
        """There is no connection to close"""
