# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from urllib.parse import ParseResult, urlparse
from milodb_common.internet.i_uri_scraper_factory import IUriScraperFactory, UriScraperFactoryError
from milodb_common.internet.i_uri_scraper_parser import IUriScraperParser
from milodb_common.internet.i_web_scraper import IWebScraper

class UriScraperFactory(IUriScraperFactory):
    def __init__(self, list_of_parsers: list[IUriScraperParser]) -> None:
        self._list_of_parsers: list[IUriScraperParser] = list_of_parsers

    def get_scraper_and_filepath(self, uri: str) -> tuple[IWebScraper, str]:
        uri_parse_result: ParseResult = urlparse(uri) # NOSONAR: Assign to "uri_parse_result" a value of type "ParseResult" instead of "tuple" or update its type hint
        parser: IUriScraperParser
        for parser in self._list_of_parsers:
            scraper_and_filepath: tuple[IWebScraper, str] | None = parser.try_get_scraper_and_filepath(uri_parse_result)
            if scraper_and_filepath:
                return scraper_and_filepath[0], scraper_and_filepath[1]
        raise UriScraperFactoryError(f'Scheme is not one of {[parser.get_scheme_name() for parser in self._list_of_parsers]}')
