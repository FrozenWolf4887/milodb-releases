# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from abc import ABC, abstractmethod
from milodb_common.internet.i_web_scraper import IWebScraper

class UriScraperFactoryError(Exception):
    pass

class IUriScraperFactory(ABC):
    @abstractmethod
    def get_scraper_and_filepath(self, uri: str) -> tuple[IWebScraper, str]:
        """
        ### Raises
        - UriScraperFactoryError
            - If there are no web scrapers available for the given URI
        """
