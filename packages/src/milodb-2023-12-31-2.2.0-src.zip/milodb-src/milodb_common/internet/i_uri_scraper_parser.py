# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from abc import ABC, abstractmethod
from urllib.parse import ParseResult
from milodb_common.internet.i_web_scraper import IWebScraper

class IUriScraperParser(ABC):
    @abstractmethod
    def get_scheme_name(self) -> str:
        pass

    @abstractmethod
    def try_get_scraper_and_filepath(self, uri_parse_result: ParseResult) -> tuple[IWebScraper, str] | None:
        pass
