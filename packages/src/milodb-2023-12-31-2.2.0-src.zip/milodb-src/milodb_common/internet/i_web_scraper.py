# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from abc import ABC, abstractmethod
from collections.abc import Callable
from dataclasses import dataclass

@dataclass
class ScrapeResult:
    error_message: (str | None)
    content: bytes

class IWebScraper(ABC):
    @abstractmethod
    def get_path_text(self, filepath: str) -> str:
        pass

    @abstractmethod
    def try_scrape(self, filepath: str, progress_callback: Callable[[str], None]) -> ScrapeResult:
        pass

    @abstractmethod
    def close(self) -> None:
        pass
