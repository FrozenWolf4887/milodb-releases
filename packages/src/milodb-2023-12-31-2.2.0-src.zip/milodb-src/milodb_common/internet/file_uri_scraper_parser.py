# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from urllib.parse import ParseResult
from milodb_common.internet.file_scraper import FileScraper
from milodb_common.internet.i_uri_scraper_factory import UriScraperFactoryError
from milodb_common.internet.i_uri_scraper_parser import IUriScraperParser
from milodb_common.internet.i_web_scraper import IWebScraper

_FILE_URI_SCHEME: str = 'file'

class FileUriScraperParser(IUriScraperParser):
    def get_scheme_name(self) -> str:
        return _FILE_URI_SCHEME

    def try_get_scraper_and_filepath(self, uri_parse_result: ParseResult) -> tuple[IWebScraper, str] | None:
        if uri_parse_result.scheme != _FILE_URI_SCHEME:
            return None
        if uri_parse_result.hostname is not None:
            raise UriScraperFactoryError('has a redundant hostname')
        try:
            if uri_parse_result.port is not None:
                raise UriScraperFactoryError('has a redundant port')
        except ValueError as ex:
            raise UriScraperFactoryError('has an invalid and redundant port') from ex

        if not uri_parse_result.path:
            raise UriScraperFactoryError('has no path')

        return FileScraper(), uri_parse_result._replace(scheme='', netloc='').geturl()
