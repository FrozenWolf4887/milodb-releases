#!/bin/bash
# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0

set -e

echo "** Prepare virtual environment"
python -m venv /tmp/mvdb/venv --clear --upgrade-deps
source /tmp/mvdb/venv/bin/activate

echo "** Install packages"
pip install -r requirements-linux.txt

echo "** Build executable"
PYTHONOPTIMIZE=2 pyinstaller --distpath bin --workpath /tmp/mvdb/build --clean ../milodb.spec

echo "** Save requirements"
pip freeze | tee requirements-linux.txt
