# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from abc import ABC, abstractmethod
from milodb_client.updater.manifest.common_manifest import IHexDigest

class AssetCacheError(Exception):
    pass

class IAssetCache(ABC):
    @abstractmethod
    def has_asset(self, digest: IHexDigest) -> bool:
        pass

    @abstractmethod
    def try_load_asset(self, digest: IHexDigest) -> bytes | None:
        pass

    @abstractmethod
    def store_asset(self, data: bytes) -> None:
        pass
