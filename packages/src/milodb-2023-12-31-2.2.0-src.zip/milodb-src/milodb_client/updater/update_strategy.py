# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
import sys
from collections.abc import Mapping, Sequence, Set
from dataclasses import dataclass
from milodb_client.updater.i_file_hasher import HashError, HashFileNotFoundError, IFileHasher
from milodb_client.updater.i_file_tester import FileStat, IFileTester
from milodb_client.updater.manifest.common_manifest import IConfigFile, IHexDigest, ILaunchFile, IVersionNumber
from milodb_client.updater.manifest.local_manifest import ILocalManifest
from milodb_client.updater.manifest.update_directory import IAssetRegister
from milodb_client.updater.manifest.version_manifest import ICoreFile, IVariant, IVersion, IVersionManifest

@dataclass
class CoreFileChanges:
    list_of_new_files_to_acquire: list[ICoreFile]
    list_of_missing_files_to_acquire: list[ICoreFile]
    list_of_changed_files_to_acquire: list[ICoreFile]
    list_of_unchanged_files: list[ICoreFile]
    list_of_files_that_are_deprecated: list[str]

@dataclass
class FileRename:
    original_filename: str
    new_filename: str

@dataclass
class ConfigFileChanges:
    list_of_files_that_are_deprecated: list[str]
    list_of_files_to_rename: list[FileRename]
    list_of_files_to_leave: list[str]
    list_of_new_files: list[str]

@dataclass
class BackupFileSet:
    list_of_core_files_to_backup: list[str]
    list_of_config_files_to_backup: list[str]
    list_of_clobbered_files_to_backup: list[str]

@dataclass
class UpdateStrategy:
    local_manifest: ILocalManifest
    version_manifest: IVersionManifest
    asset_register: IAssetRegister
    target_variant: IVariant
    target_version: IVersion
    core_file_changes: CoreFileChanges
    config_file_changes: ConfigFileChanges
    list_of_newer_versions: list[IVersion]
    backup_file_set: BackupFileSet
    launch_executable: ILaunchFile | None

class UpdateStrategyError(Exception):
    pass

def determine_update_strategy(requested_version_number: IVersionNumber | None, requested_variant: str | None, local_manifest: ILocalManifest, version_manifest: IVersionManifest, asset_register: IAssetRegister, file_hasher: IFileHasher, file_tester: IFileTester) -> UpdateStrategy:
    """
    ### Arguments:
    - requested_version_number
        - If None, find the latest version within the variant
    - requested_variant
        - If None, uses the variant specified in the local manifest
    ### Raises:
    - UpdateStrategyError
        - If a non recoverable error occurred that would indicate that the update should not be attempted.
    """
    target_variant: IVariant
    target_version: IVersion
    target_variant, target_version = find_target_variant_and_version(requested_version_number, requested_variant or local_manifest.variant_name, version_manifest.variants)
    core_file_changes: CoreFileChanges = determine_core_file_changes(local_manifest.core_files, target_version.core_files, asset_register.assets.keys(), file_hasher)
    config_file_changes: ConfigFileChanges = determine_config_file_changes(local_manifest.config_files, target_version.config_files)
    list_of_newer_versions: list[IVersion] = determine_newer_versions(local_manifest.variant_name, local_manifest.version_number, target_variant, target_version.number)
    backup_file_set: BackupFileSet = determine_files_to_backup(core_file_changes, config_file_changes, file_tester)
    launch_executable: ILaunchFile | None = target_version.launch_files.get(sys.platform)

    return UpdateStrategy(
        local_manifest,
        version_manifest,
        asset_register,
        target_variant,
        target_version,
        core_file_changes,
        config_file_changes,
        list_of_newer_versions,
        backup_file_set,
        launch_executable)

def find_target_variant_and_version(requested_version_number: IVersionNumber | None, requested_variant_name: str, map_of_variants: Mapping[str, IVariant]) -> tuple[IVariant, IVersion]:
    """
    ### Arguments:
    - requested_version_number
        - If None, find the latest version within the variant
    ### Raises:
    - UpdateStrategyError
        - If the requested variant does not exist in the version manifest.
        - If the requested version does not exist in the variant.
    """
    variant: IVariant | None = map_of_variants.get(requested_variant_name)
    if not variant:
        raise UpdateStrategyError(f"Requested variant '{requested_variant_name}' does not exist in the version manifest")

    version: IVersion | None

    if requested_version_number:
        version = variant.versions.get(requested_version_number)
        if not version:
            raise UpdateStrategyError(f"Requested version '{requested_version_number}' in variant '{requested_variant_name}' does not exist in the version manifest")
    else:
        version = _get_latest_version(variant)

    return variant, version

def _get_latest_version(variant: IVariant) -> IVersion:
    sorted_list_of_versions: list[IVersion] = sorted(variant.versions.values(), key=lambda version: version.number)
    if not sorted_list_of_versions:
        raise UpdateStrategyError(f"Requested variant '{variant.name}' has no versions in the version manifest")
    return sorted_list_of_versions[-1]

def determine_core_file_changes(list_of_local_files: Sequence[str], map_of_target_core_files: Mapping[str, ICoreFile], set_of_asset_digests: Set[IHexDigest], file_hasher: IFileHasher) -> CoreFileChanges:
    """
    ### Raises:
    - UpdateStrategyError
        - If there was an error hashing local files or an asset is not available.
    """
    core_file: ICoreFile
    for core_file in map_of_target_core_files.values():
        if core_file.digest not in set_of_asset_digests:
            raise UpdateStrategyError(f"Core file '{core_file.filename}' with digest '{core_file.digest}' does not appear in the asset register")

    list_of_local_only_files: list[str] = [ local_file for local_file in list_of_local_files if local_file not in map_of_target_core_files ]
    list_of_shared_files: list[ICoreFile] = [ core_file for core_file in map_of_target_core_files.values() if core_file.filename in list_of_local_files ]
    list_of_target_only_files: list[ICoreFile] = [ core_file for core_file in map_of_target_core_files.values() if core_file.filename not in list_of_local_files ]

    list_of_missing_files_to_acquire: list[ICoreFile] = []
    list_of_changed_files_to_acquire: list[ICoreFile] = []
    list_of_unchanged_files: list[ICoreFile] = []

    shared_file: ICoreFile
    for shared_file in list_of_shared_files:
        try:
            local_file_digest_bytes: bytes = file_hasher.hash_file(shared_file.filename)
        except HashFileNotFoundError:
            list_of_missing_files_to_acquire.append(shared_file)
        except HashError as ex:
            raise UpdateStrategyError(ex) from ex
        else:
            if local_file_digest_bytes == shared_file.digest.digest_bytes:
                list_of_unchanged_files.append(shared_file)
            else:
                list_of_changed_files_to_acquire.append(shared_file)

    return CoreFileChanges(
        list_of_new_files_to_acquire = list_of_target_only_files,
        list_of_missing_files_to_acquire = list_of_missing_files_to_acquire,
        list_of_changed_files_to_acquire = list_of_changed_files_to_acquire,
        list_of_unchanged_files = list_of_unchanged_files,
        list_of_files_that_are_deprecated = list_of_local_only_files
    )

def determine_config_file_changes(map_of_local_config_files: Mapping[int, IConfigFile], map_of_target_config_files: Mapping[int, IConfigFile]) -> ConfigFileChanges:
    list_of_local_only_files: list[str] = [ config_file.filename for config_file in map_of_local_config_files.values() if config_file.config_key not in map_of_target_config_files ]
    set_of_shared_config_keys: set[int] = set(map_of_local_config_files.keys()).intersection(set(map_of_target_config_files.keys()))
    list_of_target_only_files: list[str] = [ config_file.filename for config_file in map_of_target_config_files.values() if config_file.config_key not in map_of_local_config_files ]

    list_of_same_shared_files: list[str] = []
    list_of_files_to_rename: list[FileRename] = []

    shared_key: int
    for shared_key in set_of_shared_config_keys:
        local_config_file: IConfigFile = map_of_local_config_files[shared_key]
        target_config_file: IConfigFile = map_of_target_config_files[shared_key]
        if local_config_file.filename == target_config_file.filename:
            list_of_same_shared_files.append(local_config_file.filename)
        else:
            list_of_files_to_rename.append(FileRename(local_config_file.filename, target_config_file.filename))

    return ConfigFileChanges(
        list_of_files_that_are_deprecated = list_of_local_only_files,
        list_of_files_to_rename = list_of_files_to_rename,
        list_of_files_to_leave = list_of_same_shared_files,
        list_of_new_files = list_of_target_only_files
    )

def determine_newer_versions(starting_variant_name: str, starting_version_number: IVersionNumber, target_variant: IVariant, target_version_number: IVersionNumber) -> list[IVersion]:
    if starting_variant_name != target_variant.name:
        return []
    list_of_newer_versions: list[IVersion] = [ version for version in target_variant.versions.values() if version.number > starting_version_number and version.number <= target_version_number ]
    return sorted(list_of_newer_versions, key=lambda version: version.number)

def determine_files_to_backup(core_file_changes: CoreFileChanges, config_file_changes: ConfigFileChanges, file_tester: IFileTester) -> BackupFileSet:
    """
    ### Raises:
    - UpdateStrategyError
        - If a destination file to be clobbered is a directory.
    """
    list_of_core_filenames: list[str] = [ file.filename for file in core_file_changes.list_of_changed_files_to_acquire ]
    list_of_core_filenames.extend([ file.filename for file in core_file_changes.list_of_unchanged_files ])
    list_of_core_filenames.extend(core_file_changes.list_of_files_that_are_deprecated)
    list_of_clobbered_filenames: list[str] = []

    list_of_config_files_to_backup: list[str] = [ rename_file.original_filename for rename_file in config_file_changes.list_of_files_to_rename ]
    list_of_config_files_to_backup.extend(config_file_changes.list_of_files_to_leave)
    list_of_config_files_to_backup.extend(config_file_changes.list_of_files_that_are_deprecated)

    new_file: ICoreFile
    for new_file in core_file_changes.list_of_new_files_to_acquire:
        file_stat: FileStat = file_tester.stat_file(new_file.filename)
        if file_stat.does_exist:
            if not file_stat.is_file:
                raise UpdateStrategyError(f"Destination file '{new_file.filename}' already exists and is a directory")
            list_of_clobbered_filenames.append(new_file.filename)

    return BackupFileSet(
        list_of_core_files_to_backup = list_of_core_filenames,
        list_of_config_files_to_backup = list_of_config_files_to_backup,
        list_of_clobbered_files_to_backup = list_of_clobbered_filenames)
