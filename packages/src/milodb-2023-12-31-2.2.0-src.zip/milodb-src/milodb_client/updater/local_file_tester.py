# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from pathlib import Path
from milodb_client.updater.i_file_tester import FileStat, IFileTester

class LocalFileTester(IFileTester):
    def stat_file(self, filepath: str) -> FileStat:
        path: Path = Path(filepath)
        exists: bool = path.exists()
        is_file: bool = exists and path.is_file()
        return FileStat(filepath, exists, is_file)
