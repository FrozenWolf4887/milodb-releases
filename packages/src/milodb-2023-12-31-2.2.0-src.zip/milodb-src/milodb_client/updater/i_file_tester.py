# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from abc import ABC, abstractmethod
from dataclasses import dataclass

@dataclass
class FileStat:
    filepath: str
    does_exist: bool
    is_file: bool

class IFileTester(ABC):
    @abstractmethod
    def stat_file(self, filepath: str) -> FileStat:
        pass
