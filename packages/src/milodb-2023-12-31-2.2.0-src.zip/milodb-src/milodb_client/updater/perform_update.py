# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
import os
import pathlib
import shutil
import stat
from collections.abc import Sequence
from datetime import datetime
from typing import Any
from milodb_client.updater.i_asset_cache import AssetCacheError, IAssetCache
from milodb_client.updater.manifest.common_manifest import IVersionNumber
from milodb_client.updater.manifest.update_directory import IAssetRegister
from milodb_client.updater.manifest.version_manifest import ICoreFile
from milodb_client.updater.update_strategy import BackupFileSet, ConfigFileChanges, CoreFileChanges, FileRename
from milodb_common.internet.i_uri_scraper_factory import IUriScraperFactory, UriScraperFactoryError
from milodb_common.internet.i_web_scraper import IWebScraper, ScrapeResult
from milodb_common.output.print.i_printer import IPrinter

_RENAME_ADDED_EXTENSION: str = 'deleteMe'

class PerformUpdateError(Exception):
    pass

def perform_update(
        root_directory: str,
        backup_directory: str,
        time_stamp: datetime,
        current_variant_name: str,
        current_version_number: IVersionNumber,
        core_file_changes: CoreFileChanges,
        config_file_changes: ConfigFileChanges,
        backup_file_set: BackupFileSet,
        asset_register: IAssetRegister,
        asset_cache: IAssetCache,
        web_scraper_factory: IUriScraperFactory,
        normal_printer: IPrinter) -> None:
    """
    ### Raises
    - PerformUpdateError
    """
    list_of_files_to_acquire: list[ICoreFile] = \
        core_file_changes.list_of_new_files_to_acquire + \
        core_file_changes.list_of_missing_files_to_acquire + \
        core_file_changes.list_of_changed_files_to_acquire

    list_of_files_to_backup: list[str] = \
        backup_file_set.list_of_core_files_to_backup + \
        backup_file_set.list_of_config_files_to_backup + \
        backup_file_set.list_of_clobbered_files_to_backup

    list_of_files_to_remove: list[str] = \
        [ file.filename for file in core_file_changes.list_of_changed_files_to_acquire ] + \
        core_file_changes.list_of_files_that_are_deprecated + \
        config_file_changes.list_of_files_that_are_deprecated

    fetch_assets_to_cache(list_of_files_to_acquire, asset_register, asset_cache, web_scraper_factory, normal_printer)
    backup_files(root_directory, backup_directory, time_stamp, current_variant_name, current_version_number, list_of_files_to_backup, normal_printer)
    remove_files_and_directories(root_directory, list_of_files_to_remove, normal_printer)
    rename_config_files(root_directory, config_file_changes.list_of_files_to_rename, normal_printer)
    emplace_files_from_cache(root_directory, list_of_files_to_acquire, asset_cache, normal_printer)

def fetch_assets_to_cache(list_of_files_to_acquire: Sequence[ICoreFile], asset_register: IAssetRegister, asset_cache: IAssetCache, web_scraper_factory: IUriScraperFactory, normal_printer: IPrinter) -> None:
    """
    ### Raises
    - PerformUpdateError
    """
    core_file: ICoreFile
    for core_file in list_of_files_to_acquire:
        if asset_cache.has_asset(core_file.digest):
            normal_printer.writeln(f"Asset '{core_file.digest}' for file '{core_file.filename}': Already in cache")
            continue

        asset_uri: str | None = asset_register.resolve_asset_uri(core_file.digest)
        if not asset_uri:
            raise PerformUpdateError(f"Asset '{core_file.digest}' for file '{core_file.filename}' is not in the asset register")

        normal_printer.writeln(f"Asset '{core_file.digest}' for file '{core_file.filename}': Fetching...")

        web_scraper: IWebScraper
        asset_path: str
        try:
            web_scraper, asset_path = web_scraper_factory.get_scraper_and_filepath(asset_uri)
        except UriScraperFactoryError as ex:
            raise PerformUpdateError(f"Asset '{core_file.digest}' for file '{core_file.filename}' with URI '{asset_uri}' is inaccessible: {ex}") from ex

        scrape_result: ScrapeResult = web_scraper.try_scrape(asset_path, normal_printer.writeln)
        if scrape_result.error_message:
            raise PerformUpdateError(f"Asset '{core_file.digest}' for file '{core_file.filename}' with URI '{asset_uri}' download error: {scrape_result.error_message}")

        try:
            asset_cache.store_asset(scrape_result.content)
        except AssetCacheError as ex:
            raise PerformUpdateError(f"Asset '{core_file.digest}' for file '{core_file.filename}' failed to store in cache: {ex}") from ex

def backup_files(root_directory: str, backup_directory: str, time_stamp: datetime, variant_name: str, version_number: IVersionNumber, list_of_files_to_backup: Sequence[str], normal_printer: IPrinter) -> None:
    """
    ### Raises
    - PerformUpdateError
    """
    directory_name: str = f'{time_stamp.year:04}-{time_stamp.month:02}-{time_stamp.day:02}_{time_stamp.hour:02}-{time_stamp.minute:02}-{time_stamp.second:02}_{variant_name}_{version_number}'
    backup_path: pathlib.Path = pathlib.Path(root_directory, backup_directory, directory_name)
    _create_backup_directory(backup_path, normal_printer)
    _save_files(pathlib.Path(root_directory), backup_path, list_of_files_to_backup, normal_printer)

def _create_backup_directory(backup_path: pathlib.Path, normal_printer: IPrinter) -> None:
    normal_printer.writeln(f"Backing up files to '{backup_path}'")
    try:
        backup_path.mkdir(parents = True)
    except OSError as ex:
        raise PerformUpdateError(ex) from ex

def _save_files(root_path: pathlib.Path, backup_path: pathlib.Path, list_of_files_to_backup: Sequence[str], normal_printer: IPrinter) -> None:
    source_filename: str
    for source_filename in list_of_files_to_backup:
        source_path: pathlib.Path = pathlib.Path(root_path, source_filename)
        target_path: pathlib.Path = backup_path.joinpath(source_filename)
        normal_printer.writeln(f"  Saving '{source_path}'")
        try:
            target_path.parent.mkdir(parents = True, exist_ok = True)
            shutil.copy2(source_path, target_path)
        except FileNotFoundError:
            normal_printer.writeln("    (skipped, does not exist)")
        except OSError as ex:
            raise PerformUpdateError(ex) from ex

def remove_files_and_directories(root_directory: str, list_of_files_to_remove: Sequence[str], printer: IPrinter) -> None:
    """
    Remove the specified list of files and their directories if empty.

    Before removing the file, the file is first renamed. This is to avoid a permission error in Windows
    when trying to remove the active executable; however, if the file is renamed to something else first,
    it can then be deleted.

    ### Raises
    - PerformUpdateError
    """
    printer.writeln('Removing files')

    filename: str
    for filename in list_of_files_to_remove:
        original_path: pathlib.Path = pathlib.Path(root_directory, filename)
        renamed_path: pathlib.Path = pathlib.Path(root_directory, f'{filename}.{_RENAME_ADDED_EXTENSION}')
        printer.writeln(f"  Removing file '{original_path}'")
        try:
            original_path.rename(renamed_path).unlink()
        except OSError as ex:
            raise PerformUpdateError(f"Failed to remove file '{original_path} as '{renamed_path}': {ex}") from ex

    printer.writeln('Removing directories')

    map_of_directories: dict[str, dict[str, Any]] = {}
    for filename in list_of_files_to_remove:
        sub_map: dict[str, dict[str, Any]] = map_of_directories
        for part in pathlib.Path(filename).parent.parts:
            sub_map = sub_map.setdefault(part, {})

    _prune_directory_map(pathlib.Path(root_directory), map_of_directories, printer)

def _prune_directory_map(parent_path: pathlib.Path, map_of_directories: dict[str, dict[str, Any]], printer: IPrinter) -> None:
    dirname: str
    sub_map: dict[str, dict[str, Any]]
    for dirname, sub_map in map_of_directories.items():
        path: pathlib.Path = parent_path.joinpath(dirname)
        if sub_map:
            _prune_directory_map(path, sub_map, printer)
        has_contents: bool = False
        for _ in path.iterdir():
            has_contents = True
            break
        if not has_contents:
            printer.writeln(f"  Removing directory '{path}'")
            try:
                path.rmdir()
            except OSError as ex:
                raise PerformUpdateError(f"Failed to remove directory '{path}': {ex}") from ex
        else:
            printer.writeln(f"  Leaving populated directory '{path}'")

def emplace_files_from_cache(root_directory: str, list_of_files: Sequence[ICoreFile], asset_cache: IAssetCache, printer: IPrinter) -> None:
    """
    ### Raises
    - PerformUpdateError
    """
    printer.writeln('Installing files')

    core_file: ICoreFile
    for core_file in list_of_files:
        file_data: bytes | None = asset_cache.try_load_asset(core_file.digest)
        if file_data is None:
            raise PerformUpdateError(f"Asset '{core_file.digest}' for file '{core_file.filename}' is not in the asset cache")
        printer.writeln(f"  Emplacing file '{core_file.filename}'")
        path: pathlib.Path = pathlib.Path(root_directory, core_file.filename)
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            with path.open('wb') as file:
                file.write(file_data)
            if core_file.exe:
                stat_result: os.stat_result = os.stat(path)
                os.chmod(path, stat_result.st_mode | stat.S_IXUSR)
        except OSError as ex:
            raise PerformUpdateError(f"Failed to write file '{path}': {ex}") from ex

def rename_config_files(root_directory: str, list_of_files_to_rename: Sequence[FileRename], printer: IPrinter) -> None:
    """
    ### Raises
    - PerformUpdateError
    """
    printer.writeln('Renaming config files')
    file_rename: FileRename
    for file_rename in list_of_files_to_rename:
        printer.writeln(f"  Rename '{file_rename.original_filename}' to '{file_rename.new_filename}'")
        original_path: pathlib.Path = pathlib.Path(root_directory, file_rename.original_filename)
        new_path: pathlib.Path = pathlib.Path(root_directory, file_rename.new_filename)
        try:
            original_path.rename(new_path)
        except OSError as ex:
            raise PerformUpdateError(f"Failed to rename file '{original_path}' to '{new_path}': {ex}") from ex
