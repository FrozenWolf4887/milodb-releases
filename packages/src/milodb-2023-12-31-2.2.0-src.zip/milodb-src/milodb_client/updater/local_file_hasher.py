# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from hashlib import sha3_224
from milodb_client.updater.i_file_hasher import HashError, HashFileNotFoundError, IFileHasher

_HASHING_BUFFER_SIZE: int = 64 * 1024

class LocalFileHasher(IFileHasher):
    def hash_file(self, filepath: str) -> bytes:
        digest = sha3_224()
        try:
            end_of_file: bool = False
            with open(filepath, 'rb') as file:
                while not end_of_file:
                    data_chunk: bytes = file.read(_HASHING_BUFFER_SIZE)
                    if data_chunk:
                        digest.update(data_chunk)
                    else:
                        end_of_file = True
        except FileNotFoundError as ex:
            raise HashFileNotFoundError(f"File '{filepath}' not found") from ex
        except IOError as ex:
            raise HashError(f"Error hashing '{filepath}': {ex}") from ex
        return digest.digest()
