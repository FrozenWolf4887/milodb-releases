# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from typing import Any
from milodb_client.updater.manifest.common_manifest import IHexDigest

_SHA_HASHING_NAME: str = 'SHA3-224'
_SHA_DIGEST_LENGTH_BYTES: int = 28

class HexDigest(IHexDigest):
    def __init__(self, digest_bytes: bytes) -> None:
        self._digest_bytes: bytes = digest_bytes

    def __str__(self) -> str:
        return self._digest_bytes.hex()

    def __hash__(self) -> int:
        return hash(self._digest_bytes)

    def __eq__(self, other: Any) -> bool:
        if isinstance(other, IHexDigest):
            return self._digest_bytes == other.digest_bytes
        return False

    def __ne__(self, other: Any) -> bool:
        return not self.__eq__(other)

    @property
    def digest_bytes(self) -> bytes:
        return self._digest_bytes

    @staticmethod
    def parse(text: str) -> IHexDigest:
        """
        ### Raises:
        - HexDigestError
        """
        try:
            digest_bytes: bytes = bytes.fromhex(text)
        except ValueError:
            pass
        else:
            if len(digest_bytes) == _SHA_DIGEST_LENGTH_BYTES:
                return HexDigest(digest_bytes)

        raise HexDigestError(f"'{text}' is not a {_SHA_HASHING_NAME} hexadecimal digest")

class HexDigestError(Exception):
    pass
