# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from collections.abc import Mapping
from typing import Any
from milodb_client.updater.manifest.common_manifest import IHexDigest
from milodb_client.updater.manifest.common_manifest_schema import HexDigestKey
from milodb_client.updater.manifest.cooked_schema_types import CookedDictionary
from milodb_client.updater.manifest.i_schema_types import IGroup, IKey, ITypedKey, SchemaLoadError
from milodb_client.updater.manifest.schema_types import DynamicGroup, IntegerItem, OptionalTextItem, StaticGroup, TextItem, root_key
from milodb_client.updater.manifest.update_directory import IAsset, IAssetRegister, IUpdateDirectory

_ASSET_URI_PLACEHOLDER: str = '<>'

class UpdateDirectorySchema(StaticGroup, IUpdateDirectory):
    def __init__(self) -> None:
        super().__init__(None, root_key())
        self.field_format = IntegerItem(self, 'format')
        self.field_version_manifest_uri = TextItem(self, 'versionManifestUri')
        self.field_asset_register = AssetRegisterItem(self, 'assetRegister')

    @property
    def format(self) -> int:
        return self.field_format.get()

    @property
    def version_manifest_uri(self) -> str:
        return self.field_version_manifest_uri.get()

    @property
    def asset_register(self) -> IAssetRegister:
        return self.field_asset_register

class AssetRegisterItem(StaticGroup, IAssetRegister):
    def __init__(self, parent: IGroup | None, key: IKey | str) -> None:
        super().__init__(parent, key)
        self.field_template_asset_uri = OptionalTextItem(self, 'templateAssetUri')
        self.field_assets = DynamicGroup(self, 'assets', HexDigestKey.Creator(), AssetItem)

    def load(self, value: Any) -> None:
        super().load(value)

        template_uri: str | None = self.template_asset_uri
        if template_uri and _ASSET_URI_PLACEHOLDER not in template_uri:
            raise SchemaLoadError(f"'{self.field_template_asset_uri.full_path}' value '{template_uri}' does not include the '{_ASSET_URI_PLACEHOLDER}' placeholder")

        asset: AssetItem
        for asset in self.field_assets.get().values():
            if not template_uri and not asset.uri:
                raise SchemaLoadError(f"Asset '{asset.digest}' must specify a URI when there is no template URI")

    @property
    def template_asset_uri(self) -> str | None:
        return self.field_template_asset_uri.get()

    @property
    def assets(self) -> Mapping[IHexDigest, IAsset]:
        return CookedDictionary(self.field_assets.get())

    def resolve_asset_uri(self, digest: IHexDigest) -> str | None:
        asset: IAsset | None = self.assets.get(digest)
        if not asset:
            return None

        asset_uri: str | None = asset.uri
        if asset_uri is not None:
            return asset.uri

        template_uri: str | None = self.template_asset_uri
        if template_uri is None:
            return None

        asset_id: str | None = asset.identifier
        if asset_id is None:
            return template_uri.replace(_ASSET_URI_PLACEHOLDER, asset.digest.digest_bytes.hex())

        return template_uri.replace(_ASSET_URI_PLACEHOLDER, asset_id)

class AssetItem(StaticGroup, IAsset):
    def __init__(self, parent: IGroup | None, key: ITypedKey[IHexDigest]) -> None:
        super().__init__(parent, key)
        self._digest: IHexDigest = key.get()
        self.field_uri = OptionalTextItem(self, 'uri')
        self.field_id = OptionalTextItem(self, 'id')
        self.field_size = IntegerItem(self, 'size')

    @property
    def digest(self) -> IHexDigest:
        return self._digest

    @property
    def uri(self) -> str | None:
        return self.field_uri.get()

    @property
    def identifier(self) -> str | None:
        return self.field_id.get()

    @property
    def size(self) -> int:
        return self.field_size.get()
