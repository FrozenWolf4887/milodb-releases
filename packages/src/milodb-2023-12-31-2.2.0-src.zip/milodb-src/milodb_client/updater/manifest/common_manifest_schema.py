# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from typing import Any
from milodb_client.updater.manifest.common_manifest import IConfigFile, IHexDigest, ILaunchFile, IVersionNumber
from milodb_client.updater.manifest.hex_digest import HexDigest, HexDigestError
from milodb_client.updater.manifest.i_schema_types import IGroup, IKey, IKeyCreator, ITypedKey, KeyParseError, SchemaLoadError
from milodb_client.updater.manifest.schema_types import Item
from milodb_client.updater.manifest.version_number import VersionNumber, VersionNumberError

class VersionNumberKey(ITypedKey[IVersionNumber]):
    def __init__(self, version_number: IVersionNumber) -> None:
        self._version_number: IVersionNumber = version_number

    def __str__(self) -> str:
        return str(self._version_number)

    @property
    def name(self) -> str:
        return str(self._version_number)

    def get(self) -> IVersionNumber:
        return self._version_number

    class Creator(IKeyCreator[IVersionNumber]):
        def parse(self, key_name: str) -> ITypedKey[IVersionNumber]:
            try:
                version_number: IVersionNumber = VersionNumber.parse(key_name)
            except VersionNumberError as ex:
                raise KeyParseError(ex) from ex
            return VersionNumberKey(version_number)

        def from_base_type(self, value: IVersionNumber) -> ITypedKey[IVersionNumber]:
            return VersionNumberKey(value)

class HexDigestKey(ITypedKey[IHexDigest]):
    def __init__(self, digest: IHexDigest) -> None:
        self._digest: IHexDigest = digest

    def __str__(self) -> str:
        return str(self._digest)

    @property
    def name(self) -> str:
        return str(self._digest)

    def get(self) -> IHexDigest:
        return self._digest

    class Creator(IKeyCreator[IHexDigest]):
        def parse(self, key_name: str) -> ITypedKey[IHexDigest]:
            try:
                digest: IHexDigest = HexDigest.parse(key_name)
            except HexDigestError as ex:
                raise KeyParseError(ex) from ex
            return HexDigestKey(digest)

        def from_base_type(self, value: IHexDigest) -> ITypedKey[IHexDigest]:
            return HexDigestKey(value)

class VersionNumberItem(Item):
    def __init__(self, parent: IGroup | None, key: IKey | str) -> None:
        super().__init__(parent, key)
        self._version_number: IVersionNumber = VersionNumber(0, 0, 0)

    def __str__(self) -> str:
        return str(self._version_number)

    def load(self, value: Any) -> None:
        if not isinstance(value, str):
            raise SchemaLoadError(f"Key '{self.full_path}' value is not text")
        if not value:
            raise SchemaLoadError(f"Key '{self.full_path}' value is blank")

        try:
            self._version_number = VersionNumber.parse(value)
        except VersionNumberError as ex:
            raise SchemaLoadError(f"Key '{self.full_path}' value {ex}") from ex

    def save(self) -> Any:
        return str(self._version_number)

    def get(self) -> IVersionNumber:
        return self._version_number

    def set(self, version_number: VersionNumber) -> None:
        self._version_number = version_number

class HexDigestItem(Item):
    def __init__(self, parent: IGroup | None, key: IKey | str) -> None:
        super().__init__(parent, key)
        self._digest: IHexDigest = HexDigest(bytes())

    def __str__(self) -> str:
        return str(self._digest)

    def load(self, value: Any) -> None:
        if not isinstance(value, str):
            raise SchemaLoadError(f"Key '{self.full_path}' value is not text")

        try:
            self._digest = HexDigest.parse(value)
        except HexDigestError as ex:
            raise SchemaLoadError(f"Key '{self.full_path}' value {ex}") from ex

    def save(self) -> Any:
        return str(self._digest)

    def get(self) -> IHexDigest:
        return self._digest

class ConfigFileItem(Item, IConfigFile):
    def __init__(self, parent: IGroup | None, key: ITypedKey[int]) -> None:
        super().__init__(parent, key)
        self._config_key: int = key.get()
        self._filename: str = ''

    def load(self, value: Any) -> None:
        if not isinstance(value, str):
            raise SchemaLoadError(f"Key '{self.full_path}' value is not text")
        if not value:
            raise SchemaLoadError(f"Key '{self.full_path}' value is blank")
        self._filename = value

    def save(self) -> Any:
        return self._filename

    @property
    def config_key(self) -> int:
        return self._config_key

    @property
    def filename(self) -> str:
        return self._filename

class LaunchFileItem(Item, ILaunchFile):
    def __init__(self, parent: IGroup | None, key: ITypedKey[str]) -> None:
        super().__init__(parent, key)
        self._operating_system: str = key.get()
        self._filename: str = ''

    def load(self, value: Any) -> None:
        if not isinstance(value, str):
            raise SchemaLoadError(f"Key '{self.full_path}' value is not text")
        if not value:
            raise SchemaLoadError(f"Key '{self.full_path}' value is blank")
        self._filename = value

    def save(self) -> Any:
        return self._filename

    @property
    def operating_system(self) -> str:
        return self._operating_system

    @property
    def filename(self) -> str:
        return self._filename
