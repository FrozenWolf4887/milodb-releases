# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from abc import ABC, abstractmethod
from typing import Any, Generic, Optional, TypeVar

_BaseKeyT = TypeVar('_BaseKeyT')
_BaseItemT = TypeVar('_BaseItemT')

class SchemaLoadError(Exception):
    pass

class KeyParseError(Exception):
    pass

class IKey(ABC):
    @property
    @abstractmethod
    def name(self) -> str:
        pass

class ITypedKey(IKey, Generic[_BaseKeyT]):
    @abstractmethod
    def get(self) -> _BaseKeyT:
        pass

class IKeyCreator(ABC, Generic[_BaseKeyT]):
    @abstractmethod
    def parse(self, key_name: str) -> ITypedKey[_BaseKeyT]:
        """
        ### Raises
        - KeyParseError
            - If the key_name cannot be parsed to the base type
        """

    @abstractmethod
    def from_base_type(self, value: _BaseKeyT) -> ITypedKey[_BaseKeyT]:
        pass

class IItem(ABC):
    @property
    @abstractmethod
    def parent(self) -> Optional['IGroup']: # pylint: disable=consider-alternative-union-syntax
        pass

    @property
    @abstractmethod
    def key(self) -> IKey:
        pass

    @property
    @abstractmethod
    def full_path(self) -> str:
        pass

    @abstractmethod
    def load(self, value: Any) -> None:
        """
        ### Raises
        - SchemaLoadError
            - If there are any issues loading the value
        """

    @abstractmethod
    def save(self) -> Any:
        pass

class ITypedItem(IItem, Generic[_BaseItemT]):
    @abstractmethod
    def get(self) -> _BaseItemT:
        pass

class IGroup(IItem):
    @abstractmethod
    def add_child(self, child: IItem) -> None:
        pass
