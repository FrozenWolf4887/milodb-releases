# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
import datetime
from collections.abc import Mapping
from typing import Any, Optional
from milodb_client.updater.manifest.common_manifest import IConfigFile, IHexDigest, ILaunchFile, IVersionNumber
from milodb_client.updater.manifest.common_manifest_schema import ConfigFileItem, HexDigestItem, LaunchFileItem, VersionNumberKey
from milodb_client.updater.manifest.cooked_schema_types import CookedDictionary
from milodb_client.updater.manifest.i_schema_types import IGroup, ITypedKey, SchemaLoadError
from milodb_client.updater.manifest.schema_types import BooleanItem, DateItem, DynamicGroup, IntegerItem, IntegerKey, StaticGroup, TextItem, TextKey, root_key
from milodb_client.updater.manifest.version_manifest import ICoreFile, IVariant, IVersion, IVersionManifest

class VersionManifestSchema(StaticGroup, IVersionManifest):
    def __init__(self) -> None:
        super().__init__(None, root_key())
        self.field_format = IntegerItem(self, 'format')
        self.field_variants = DynamicGroup(self, 'variants', TextKey.Creator(), VariantSchema)

    @property
    def format(self) -> int:
        return self.field_format.get()

    @property
    def variants(self) -> Mapping[str, IVariant]:
        return CookedDictionary(self.field_variants.get())

class VariantSchema(StaticGroup, IVariant):
    def __init__(self, parent: IGroup, key: ITypedKey[str]) -> None:
        super().__init__(parent, key)
        self._name: str = key.get()
        self.field_summary = TextItem(self, TextKey('summary'))
        self.field_versions = DynamicGroup(self, 'versions', VersionNumberKey.Creator(), VersionSchema)

    @property
    def name(self) -> str:
        return self._name

    @property
    def summary(self) -> str:
        return self.field_summary.get()

    @property
    def versions(self) ->  Mapping[IVersionNumber, IVersion]:
        return CookedDictionary(self.field_versions.get())

class VersionSchema(StaticGroup, IVersion):
    def __init__(self, parent: IGroup, key: ITypedKey[IVersionNumber]) -> None:
        super().__init__(parent, key)
        self._number: IVersionNumber = key.get()
        self.field_date = DateItem(self, 'date')
        self.field_log = TextItem(self, 'log')
        self.field_launch_files = DynamicGroup(self, 'launchFiles', TextKey.Creator(), LaunchFileItem)
        self.field_core_files = DynamicGroup(self, 'coreFiles', TextKey.Creator(), CoreFileSchema)
        self.field_config_files = DynamicGroup(self, 'configFiles', IntegerKey.Creator(), ConfigFileItem)

    def load(self, value: Any) -> None:
        super().load(value)
        self._verify_launch_files()

    @property
    def number(self) -> IVersionNumber:
        return self._number

    @property
    def date(self) -> datetime.date:
        return self.field_date.get()

    @property
    def log(self) -> str:
        return self.field_log.get()

    @property
    def launch_files(self) -> Mapping[str, ILaunchFile]:
        return CookedDictionary(self.field_launch_files.get())

    @property
    def core_files(self) -> Mapping[str, ICoreFile]:
        return CookedDictionary(self.field_core_files.get())

    @property
    def config_files(self) -> Mapping[int, IConfigFile]:
        return CookedDictionary(self.field_config_files.get())

    def _verify_launch_files(self) -> None:
        launch_file: LaunchFileItem
        for launch_file in self.field_launch_files.get().values():
            core_file: CoreFileSchema | None = self._find_core_file_by_filename(launch_file.filename)
            if not core_file:
                raise SchemaLoadError(f"Key '{launch_file.full_path}' value '{launch_file.filename}' is not a member of core files")
            if not core_file.exe:
                raise SchemaLoadError(f"Key '{launch_file.full_path}' value '{launch_file.filename}' is not executable")

    def _find_core_file_by_filename(self, filename: str) -> Optional['CoreFileSchema']: # pylint: disable=consider-alternative-union-syntax
        core_file: CoreFileSchema
        for core_file in self.field_core_files.get().values():
            if core_file.filename == filename:
                return core_file
        return None

class CoreFileSchema(StaticGroup, ICoreFile):
    def __init__(self, parent: IGroup, key: ITypedKey[str]) -> None:
        super().__init__(parent, key)
        self._filename: str = key.get()
        self.field_digest = HexDigestItem(self, 'digest')
        self.field_exe = BooleanItem(self, 'exe')

    @property
    def filename(self) -> str:
        return self._filename

    @property
    def digest(self) -> IHexDigest:
        return self.field_digest.get()

    @property
    def exe(self) -> bool:
        return self.field_exe.get()
