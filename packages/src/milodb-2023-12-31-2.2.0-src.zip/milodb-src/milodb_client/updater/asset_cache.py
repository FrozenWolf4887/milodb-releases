# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
import hashlib
import pathlib
from milodb_client.updater.i_asset_cache import AssetCacheError, IAssetCache
from milodb_client.updater.manifest.common_manifest import IHexDigest

class AssetCache(IAssetCache):
    def __init__(self, path_to_cache: pathlib.Path) -> None:
        self._path_to_cache: pathlib.Path = path_to_cache

    def has_asset(self, digest: IHexDigest) -> bool:
        filepath: pathlib.Path = self._path_to_cache.joinpath(digest.digest_bytes.hex())
        return filepath.exists() and filepath.is_file()

    def try_load_asset(self, digest: IHexDigest) -> bytes | None:
        filepath: pathlib.Path = self._path_to_cache.joinpath(digest.digest_bytes.hex())
        try:
            with filepath.open('rb') as file:
                data: bytes = file.read()
        except OSError:
            return None

        hasher = hashlib.sha3_224()
        hasher.update(data)
        digest_bytes: bytes = hasher.digest()

        if digest_bytes != digest.digest_bytes:
            return None

        return data

    def store_asset(self, data: bytes) -> None:
        """
        ### Raises
        - AssetCacheError
            - If the cache directory doesn't exist and couldn't be created
            - If the cache file can't be written
        """
        hasher = hashlib.sha3_224()
        hasher.update(data)
        digest_bytes: bytes = hasher.digest()

        try:
            self._path_to_cache.mkdir(parents=True, exist_ok=True)
        except OSError as ex:
            raise AssetCacheError(f"Unable to create cache directory '{self._path_to_cache}'") from ex

        filepath: pathlib.Path = self._path_to_cache.joinpath(digest_bytes.hex())
        try:
            with filepath.open('wb') as file:
                file.write(data)
        except OSError as ex:
            raise AssetCacheError(f"Unable to write cache file '{filepath}'") from ex
