# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
import json
import os
import pathlib
import sys
from collections.abc import Callable
from datetime import datetime
from typing import Any, Optional, TypeVar
import prompt_toolkit
from milodb_client.config.config_schema import CONFIG_SCHEMA
from milodb_client.config.update_config import UpdateConfig
from milodb_client.updater.i_asset_cache import IAssetCache
from milodb_client.updater.i_file_hasher import IFileHasher
from milodb_client.updater.i_file_tester import IFileTester
from milodb_client.updater.manifest.common_manifest import ILaunchFile
from milodb_client.updater.manifest.i_schema_types import IItem, SchemaLoadError
from milodb_client.updater.manifest.local_manifest import ILocalManifest
from milodb_client.updater.manifest.update_directory import IAsset, IAssetRegister, IUpdateDirectory
from milodb_client.updater.manifest.update_directory_schema import UpdateDirectorySchema
from milodb_client.updater.manifest.version_manifest import ICoreFile, IVersion, IVersionManifest
from milodb_client.updater.manifest.version_manifest_schema import VersionManifestSchema
from milodb_client.updater.perform_update import PerformUpdateError, perform_update
from milodb_client.updater.update_strategy import BackupFileSet, ConfigFileChanges, CoreFileChanges, FileRename, UpdateStrategy, UpdateStrategyError, determine_update_strategy
from milodb_common.command_framework.argument_stream import ArgumentStream
from milodb_common.command_framework.candidate_text import CandidateText
from milodb_common.command_framework.i_command import ICommand, ICommandLoader
from milodb_common.command_framework.i_help_info import IHelpInfo
from milodb_common.command_framework.quit_flag import QuitFlag
from milodb_common.internet.i_uri_scraper_factory import IUriScraperFactory, UriScraperFactoryError
from milodb_common.internet.i_web_scraper import IWebScraper, ScrapeResult
from milodb_common.output.print.i_printer import IPrinter

_SchemaT = TypeVar('_SchemaT', bound=IItem)

class Loader(ICommandLoader):
    def __init__(self, local_manifest: ILocalManifest | None, update_config: UpdateConfig, file_hasher: IFileHasher, file_tester: IFileTester, asset_cache: IAssetCache, uri_scraper_factory: IUriScraperFactory, quit_flag: QuitFlag, normal_printer: IPrinter, warning_printer: IPrinter, error_printer: IPrinter) -> None:
        self._local_manifest: ILocalManifest | None = local_manifest
        self._update_config: UpdateConfig = update_config
        self._file_hasher: IFileHasher = file_hasher
        self._file_tester: IFileTester = file_tester
        self._asset_cache: IAssetCache = asset_cache
        self._uri_scraper_factory: IUriScraperFactory = uri_scraper_factory
        self._quit_flag: QuitFlag = quit_flag
        self._normal_printer: IPrinter = normal_printer
        self._warning_printer: IPrinter = warning_printer
        self._error_printer: IPrinter = error_printer

        self._map_of_subcommand_to_loader: dict[str, Callable[[], ICommandLoader.Result]] = {
            'check': self.load_check
        }

    def load(self, argument_stream: ArgumentStream) -> ICommandLoader.Result:
        handler: Callable[[], ICommandLoader.Result] | None = argument_stream.pop_optional_dict_value(self._map_of_subcommand_to_loader)
        if not handler:
            handler = self.load_default
        return handler()

    def load_check(self) -> ICommandLoader.Result:
        return ICommandLoader.Result(
            ExecutorCheck(self._local_manifest, self._update_config, self._file_hasher, self._file_tester, self._uri_scraper_factory, self._normal_printer, self._warning_printer, self._error_printer),
            [])

    def load_default(self) -> ICommandLoader.Result:
        return ICommandLoader.Result(
            ExecutorDefault(self._local_manifest, self._update_config, self._file_hasher, self._file_tester, self._asset_cache, self._uri_scraper_factory, self._quit_flag, self._normal_printer, self._warning_printer, self._error_printer),
            CandidateText.space_delimited_list(self._map_of_subcommand_to_loader.keys()))

class ExecutorCheck(ICommand):
    def __init__(self, local_manifest: ILocalManifest | None, update_config: UpdateConfig, file_hasher: IFileHasher, file_tester: IFileTester, uri_scraper_factory: IUriScraperFactory, normal_printer: IPrinter, warning_printer: IPrinter, error_printer: IPrinter) -> None:
        self._local_manifest: ILocalManifest | None = local_manifest
        self._update_config: UpdateConfig = update_config
        self._uri_scraper_factory: IUriScraperFactory = uri_scraper_factory
        self._file_hasher: IFileHasher = file_hasher
        self._file_tester: IFileTester = file_tester
        self._normal_printer: IPrinter = normal_printer
        self._warning_printer: IPrinter = warning_printer
        self._error_printer: IPrinter = error_printer

    def execute(self) -> None:
        update_strategy: UpdateStrategy | None = _try_get_update_strategy(
            self._update_config.update_directory_uri,
            self._local_manifest,
            self._file_hasher,
            self._file_tester,
            self._uri_scraper_factory,
            self._normal_printer,
            self._warning_printer,
            self._error_printer)

        if update_strategy:
            self._normal_printer.writeln()
            if _is_target_version_same_as_current_version(update_strategy):
                self._normal_printer.writeln('You have the current version')
            else:
                self._normal_printer.writeln('** Update available **')

class ExecutorDefault(ICommand):
    def __init__(self, local_manifest: ILocalManifest | None, update_config: UpdateConfig, file_hasher: IFileHasher, file_tester: IFileTester, asset_cache: IAssetCache, uri_scraper_factory: IUriScraperFactory, quit_flag: QuitFlag, normal_printer: IPrinter, warning_printer: IPrinter, error_printer: IPrinter) -> None:
        self._local_manifest: ILocalManifest | None = local_manifest
        self._update_config: UpdateConfig = update_config
        self._file_hasher: IFileHasher = file_hasher
        self._file_tester: IFileTester = file_tester
        self._asset_cache: IAssetCache = asset_cache
        self._uri_scraper_factory: IUriScraperFactory = uri_scraper_factory
        self._quit_flag: QuitFlag = quit_flag
        self._normal_printer: IPrinter = normal_printer
        self._warning_printer: IPrinter = warning_printer
        self._error_printer: IPrinter = error_printer

    def execute(self) -> None:
        update_strategy: UpdateStrategy | None = _try_get_update_strategy(
            self._update_config.update_directory_uri,
            self._local_manifest,
            self._file_hasher,
            self._file_tester,
            self._uri_scraper_factory,
            self._normal_printer,
            self._warning_printer,
            self._error_printer)

        if update_strategy:
            self._normal_printer.writeln()
            if _is_target_version_same_as_current_version(update_strategy):
                self._normal_printer.writeln('You have the current version')
            else:
                self._normal_printer.writeln('** Update available **')
                self._normal_printer.writeln()
                answer: str = prompt_toolkit.prompt('Would you like to update? [y/n]: ')
                if answer.strip().lower() in {'y', 'yes'}:
                    _perform_update_and_restart(self._update_config, update_strategy, self._asset_cache, self._uri_scraper_factory, self._quit_flag, self._normal_printer, self._warning_printer, self._error_printer)

def _perform_update_and_restart(update_config: UpdateConfig, update_strategy: UpdateStrategy, asset_cache: IAssetCache, web_scraper_factory: IUriScraperFactory, quit_flag: QuitFlag, normal_printer: IPrinter, warning_printer: IPrinter, error_printer: IPrinter) -> None:
    try:
        perform_update(
            root_directory = '.',
            backup_directory = update_config.backup_dir,
            time_stamp = datetime.now(),
            current_variant_name = update_strategy.local_manifest.variant_name,
            current_version_number = update_strategy.local_manifest.version_number,
            core_file_changes = update_strategy.core_file_changes,
            config_file_changes = update_strategy.config_file_changes,
            backup_file_set = update_strategy.backup_file_set,
            asset_register = update_strategy.asset_register,
            asset_cache = asset_cache,
            web_scraper_factory = web_scraper_factory,
            normal_printer = normal_printer)
    except PerformUpdateError as ex:
        normal_printer.writeln()
        error_printer.writeln(f'Update failed: {ex}')
    else:
        normal_printer.writeln()
        normal_printer.writeln('Update complete')
        normal_printer.writeln()
        if update_strategy.launch_executable:

            normal_printer.writeln(f"Restarting application as '{update_strategy.launch_executable.filename}' for '{update_strategy.launch_executable.operating_system}'...")
            normal_printer.writeln()
            quit_flag.set()
            exe_path: pathlib.Path = pathlib.Path.cwd().joinpath(update_strategy.launch_executable.filename)
            os.execl(str(exe_path), str(exe_path))
        else:
            warning_printer.writeln(f"New application cannot be started because there is no known executable specified for '{sys.platform}'")

def _try_get_update_strategy(update_directory_uri: str, local_manifest: ILocalManifest | None, file_hasher: IFileHasher, file_tester: IFileTester, uri_scraper_factory: IUriScraperFactory, normal_printer: IPrinter, warning_printer: IPrinter, error_printer: IPrinter) -> UpdateStrategy | None:
    if not local_manifest:
        error_printer.writeln('Local manifest version information is not available; update impossible')
        return None

    update_data_set: _UpdateDataSet | None = _UpdateDataSet.fetch(update_directory_uri, uri_scraper_factory, normal_printer, error_printer)
    if not update_data_set:
        return None

    try:
        update_strategy: UpdateStrategy = determine_update_strategy(None, None, local_manifest, update_data_set.version_manifest, update_data_set.update_directory.asset_register, file_hasher, file_tester)
    except UpdateStrategyError as ex:
        error_printer.writeln('Failed to determine update strategy')
        normal_printer.writeln(f'Cause: {ex}')
    else:
        _print_update_strategy(update_strategy, update_data_set.update_directory.asset_register, normal_printer, warning_printer)
        return update_strategy

    return None

class _UpdateDataSet:
    _cached_update_directory: IUpdateDirectory | None = None
    _cached_version_manifest: IVersionManifest | None = None

    def __init__(self, update_directory: IUpdateDirectory, version_manifest: IVersionManifest) -> None:
        self._update_directory: IUpdateDirectory = update_directory
        self._version_manifest: IVersionManifest = version_manifest

    @property
    def update_directory(self) -> IUpdateDirectory:
        return self._update_directory

    @property
    def version_manifest(self) -> IVersionManifest:
        return self._version_manifest

    @staticmethod
    def fetch(update_directory_uri: str, uri_scraper_factory: IUriScraperFactory, normal_printer: IPrinter, error_printer: IPrinter) -> Optional['_UpdateDataSet']: # pylint: disable=consider-alternative-union-syntax
        try:
            if not _UpdateDataSet._cached_update_directory:
                _UpdateDataSet._cached_update_directory = _fetch_schema_file(UpdateDirectorySchema(), 'update directory', update_directory_uri, uri_scraper_factory, normal_printer)
            else:
                normal_printer.writeln('Reusing cached update directory')
            if not _UpdateDataSet._cached_version_manifest:
                _UpdateDataSet._cached_version_manifest = _fetch_schema_file(VersionManifestSchema(), 'version manifest', _UpdateDataSet._cached_update_directory.version_manifest_uri, uri_scraper_factory, normal_printer)
            else:
                normal_printer.writeln('Reusing cached version manifest')
        except _FetchSchemaError as ex:
            error_printer.writeln(str(ex))

        if _UpdateDataSet._cached_update_directory and _UpdateDataSet._cached_version_manifest:
            return _UpdateDataSet(_UpdateDataSet._cached_update_directory, _UpdateDataSet._cached_version_manifest)

        return None

class _FetchSchemaError(Exception):
    pass

def _fetch_schema_file(schema: _SchemaT, name_of_schema: str, uri: str, uri_scraper_factory: IUriScraperFactory, printer: IPrinter) -> _SchemaT:
    printer.writeln(f'Fetching {name_of_schema}')
    scraper: IWebScraper
    filepath: str
    try:
        scraper, filepath = uri_scraper_factory.get_scraper_and_filepath(uri)
    except UriScraperFactoryError as ex:
        raise _FetchSchemaError(f"{_capitalise(name_of_schema)} URI '{uri}' error: {ex}") from ex

    try:
        scrape_result: ScrapeResult = scraper.try_scrape(filepath, printer.writeln)
        if scrape_result.error_message:
            raise _FetchSchemaError(f"Failed to fetch {name_of_schema} from '{uri}': {scrape_result.error_message}")
    finally:
        scraper.close()

    try:
        json_root: Any = json.loads(scrape_result.content)
    except json.JSONDecodeError as ex:
        raise _FetchSchemaError(f"{_capitalise(name_of_schema)} '{uri}' could not be parsed as JSON: {ex}") from ex

    try:
        schema.load(json_root)
    except SchemaLoadError as ex:
        raise _FetchSchemaError(f"{_capitalise(name_of_schema)} '{uri}' error: {ex}") from ex

    return schema

def _capitalise(text: str) -> str:
    return f'{text[0].upper()}{text[1:]}'

def _print_update_strategy(update_strategy: UpdateStrategy, asset_register: IAssetRegister, normal_printer: IPrinter, warning_printer: IPrinter) -> None:
    normal_printer.writeln()
    normal_printer.writeln(f"Current version: {update_strategy.local_manifest.variant_name} / {update_strategy.local_manifest.version_number}")
    normal_printer.writeln(f" Target version: {update_strategy.target_variant.name} / {update_strategy.target_version.number}")
    if update_strategy.list_of_newer_versions:
        _print_change_logs(update_strategy.list_of_newer_versions, normal_printer)
    _print_file_changes(update_strategy.core_file_changes, update_strategy.config_file_changes, asset_register, normal_printer)
    _print_backup_set(update_strategy.backup_file_set, normal_printer)
    _print_launch_executable(update_strategy.launch_executable, normal_printer, warning_printer)

def _print_change_logs(list_of_versions: list[IVersion], printer: IPrinter) -> None:
    printer.writeln()
    printer.writeln('** Change Log **')
    printer.writeln()
    index: int
    version: IVersion
    for index, version in enumerate(sorted(list_of_versions, key=lambda version: version.number)):
        if index > 0:
            printer.writeln()
        printer.writeln(f'{version.number}, {version.date}')
        if version.log:
            printer.writeln()
            printer.writeln(version.log)

def _print_file_changes(core_file_changes: CoreFileChanges, config_file_changes: ConfigFileChanges, asset_register: IAssetRegister, printer: IPrinter) -> None:
    printer.writeln()
    printer.writeln('** File Differences **')
    printer.writeln()
    printer.writeln(f' {"Type":<8}  {"File":<20}  {"Status":<12}  {"Action":<12}  Size')
    printer.writeln('-' * 69)

    core_file: ICoreFile
    for core_file in core_file_changes.list_of_new_files_to_acquire:
        printer.writeln(f' {"Core":<8}  {core_file.filename:<20}  {"New":<12}  {"Acquire":<12}  {_asset_file_size(core_file, asset_register):>7}')
    for core_file in core_file_changes.list_of_changed_files_to_acquire:
        printer.writeln(f' {"Core":<8}  {core_file.filename:<20}  {"Changed":<12}  {"Acquire":<12}  {_asset_file_size(core_file, asset_register):>7}')
    for core_file in core_file_changes.list_of_missing_files_to_acquire:
        printer.writeln(f' {"Core":<8}  {core_file.filename:<20}  {"Missing":<12}  {"Reacquire":<12}  {_asset_file_size(core_file, asset_register):>7}')
    filename: str
    for filename in core_file_changes.list_of_files_that_are_deprecated:
        printer.writeln(f' {"Core":<8}  {filename:<20}  {"Redundant":<12}  Delete')
    for core_file in core_file_changes.list_of_unchanged_files:
        printer.writeln(f' {"Core":<8}  {core_file.filename:<20}  {"Unchanged":<12}  None')

    file_rename: FileRename
    for file_rename in config_file_changes.list_of_files_to_rename:
        printer.writeln(f' {"Config":<8}  {file_rename.original_filename:<20}  {"Renamed":<12}  Rename to {file_rename.new_filename}')
    for filename in config_file_changes.list_of_files_that_are_deprecated:
        printer.writeln(f' {"Config":<8}  {filename:<20}  {"Redundant":<12}  Delete')
    for filename in config_file_changes.list_of_files_to_leave:
        printer.writeln(f' {"Config":<8}  {filename:<20}  {"Relevant":<12}  None')
    for filename in config_file_changes.list_of_new_files:
        printer.writeln(f' {"Config":<8}  {filename:<20}  {"New":<12}  None')

def _print_backup_set(backup_file_set: BackupFileSet, printer: IPrinter) -> None:
    printer.writeln()
    printer.writeln('** Files to Backup **')
    printer.writeln()
    printer.writeln(f' {"Type":<8}  File')
    printer.writeln('-' * 59)

    filename: str
    for filename in backup_file_set.list_of_core_files_to_backup:
        printer.writeln(f' {"Core":<8}  {filename}')
    for filename in backup_file_set.list_of_config_files_to_backup:
        printer.writeln(f' {"Config":<8}  {filename}')
    for filename in backup_file_set.list_of_clobbered_files_to_backup:
        printer.writeln(f' {"Unknown":<8}  {filename}')

def _print_launch_executable(launch_executable: ILaunchFile | None, normal_printer: IPrinter, warning_printer: IPrinter) -> None:
    normal_printer.writeln()
    if launch_executable:
        normal_printer.writeln(f"Target executable: '{launch_executable.filename}' for OS '{launch_executable.operating_system}'")
    else:
        warning_printer.writeln('There is no main executable for the current operating system in the chosen target variant / version.')
        normal_printer.writeln('Following the update, the application will close and there can be no attempt to start the new application.')
        normal_printer.writeln('This problem can occur if you upgrade to a variant or version that supports a different operating system.')

_SIZE_KB: int = 1000
_SIZE_MB: int = _SIZE_KB * _SIZE_KB
_SIZE_GB: int = _SIZE_KB * _SIZE_MB
_SIZE_TB: int = _SIZE_KB * _SIZE_GB
_SIZE_PB: int = _SIZE_KB * _SIZE_TB
_SIZE_EB: int = _SIZE_KB * _SIZE_PB

def _asset_file_size(core_file: ICoreFile, asset_register: IAssetRegister) -> str:
    asset: IAsset | None = asset_register.assets.get(core_file.digest)
    if not asset:
        return 'unknown'
    return _unit_file_size(asset.size)

def _unit_file_size(size_bytes: int) -> str:
    exabytes: int = size_bytes // _SIZE_EB
    petabytes: int = size_bytes // _SIZE_PB
    if exabytes > 0:
        return f'{_kilo_str(petabytes)} EB'
    terabytes: int = size_bytes // _SIZE_TB
    if petabytes > 0:
        return f'{_kilo_str(terabytes)} PB'
    gigabytes: int = size_bytes // _SIZE_GB
    if terabytes > 0:
        return f'{_kilo_str(gigabytes)} TB'
    megabytes: int = size_bytes // _SIZE_MB
    if gigabytes > 0:
        return f'{_kilo_str(megabytes)} GB'
    kilobytes: int = size_bytes // _SIZE_KB
    if megabytes > 0:
        return f'{_kilo_str(kilobytes)} MB'
    return f'{_kilo_str(size_bytes)} KB'

def _kilo_str(value: int) -> str:
    if value >= 100000:
        return f'{(value + 500) // 1000}'
    if value >= 10000:
        value += 50
        return f'{value // 1000}.{(value % 1000) // 100}'
    value += 5
    return f'{value // 1000}.{(value % 1000) // 10:02}'

def _is_target_version_same_as_current_version(update_strategy: UpdateStrategy) -> bool:
    return update_strategy.target_variant.name == update_strategy.local_manifest.variant_name and \
        update_strategy.target_version.number == update_strategy.local_manifest.version_number

class Help(IHelpInfo):
    def get_one_line_summary(self) -> str:
        return "Checks for and applies updates to the software"

    def get_detailed_summary(self) -> str:
        return (
            "Arguments: [check]\n"
            "When used without arguments, it will look for a new version of the software available for"
            " download and installation. It will prompt before actually attempting the update. When"
            " using 'check', it will not prompt to perform an update.\n"
            "The metadata related to updating is downloaded once and kept in memory, hence subsequent"
            " calls to update will not repeatedly download the information. The assets for new and"
            " updated files are stored in a local asset cache, the location of which is specified by"
            f" the configuration file entry '{CONFIG_SCHEMA.update.cache_directory.full_path}'.\n"
            "Before attempting the update, the existing files are backed up into a backup directory that"
            " is specified by the configuration file entry "
            f" '{CONFIG_SCHEMA.update.backup_directory.full_path}'."
            " A new directory is created for the backup that includes the current timestamp, variant"
            " name, and version number of the existing software.\n"
            "The remote server hosting the update metadata and assets is specified by the configuration"
            f" file entry '{CONFIG_SCHEMA.update.update_directory_uri.full_path}'.\n"
            "Example:\r"
            "  \tCheck to see if there are updates available\r"
            "  > \tupdate check\r"
            "Example:\r"
            "  \tCheck and prompt to update if an update is available\r"
            "  > \tupdate\r"
        )
