# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
import unittest
from typing import Any
from milodb_client.updater.manifest.i_schema_types import SchemaLoadError
from milodb_client.updater.manifest.update_directory_schema import UpdateDirectorySchema
from milodb_client_test.test import json_tools
from milodb_client_test.test.mock_hex_digest import MockDigest

FAKE_DIGEST_A: bytes = bytes.fromhex('5de2a9952aa5ca078d0f62dde2ab7786a95ff22e0d47041d0bda7507')
FAKE_DIGEST_B: bytes = bytes.fromhex('0f0b26f887238a0c755cf1577cdf9a9d14d4875f67ed24d856bd7c63')
FAKE_DIGEST_C: bytes = bytes.fromhex('818a64a46f6e7a5e28738f34e79ea530a7d437f56425e6e407a9068c')

SAMPLE_UPDATE_DIRECTORY: str = (
    r'{'
    r'    "format": 1,'
    r'    "versionManifestUri": "https://example.com/version-manifect.json",'
    r'    "assetRegister": {'
    r'        "templateAssetUri": "file:///tmp/test/<>",'
    r'        "assets": {'
    rf'           "{FAKE_DIGEST_A.hex()}":''{'
    r'                "uri": "file:///tmp/test/abcd",'
    r'                "id": "apple",'
    r'                "size": 642354'
    r'            },'
    rf'           "{FAKE_DIGEST_B.hex()}":''{'
    r'                "uri": "file:///tmp/test/defg",'
    r'                "id": "pear",'
    r'                "size": 45208'
    r'            },'
    rf'           "{FAKE_DIGEST_C.hex()}":''{'
    r'                "uri": "file:///tmp/test/hijk",'
    r'                "id": "mango",'
    r'                "size": 2345'
    r'            }'
    r'        }'
    r'    }'
    r'}')

class TestUpdateDirectory(unittest.TestCase):
    def test_throws_when_entries_missing(self) -> None:
        list_of_paths_to_remove: tuple[str, ...] = (
            'format',
            'versionManifestUri',
            'assetRegister',
            'assetRegister/templateAssetUri',
            'assetRegister/assets'
        )
        path_to_remove: str
        for path_to_remove in list_of_paths_to_remove:
            with self.subTest(missing_entry=path_to_remove):
                json_root: dict[Any, Any] = json_tools.load_and_prune_json_key(SAMPLE_UPDATE_DIRECTORY, path_to_remove)
                with self.assertRaises(SchemaLoadError) as capture:
                    UpdateDirectorySchema().load(json_root)
                self.assertEqual(f"Key '{path_to_remove}' is missing", str(capture.exception))

    def test_throws_when_entries_are_of_incorrect_basic_type(self) -> None:
        list_of_paths_to_change: tuple[tuple[str, Any, str], ...] = (
            ('format', 'fruit', 'an integer'),
            ('versionManifestUri', 1234, 'text'),
            ('assetRegister', 1234, 'a group'),
            ('assetRegister/templateAssetUri', 1234, 'text or null'),
            ('assetRegister/assets', [], 'a group'),
            (f'assetRegister/assets/{FAKE_DIGEST_A.hex()}', 'something', 'a group'),
            (f'assetRegister/assets/{FAKE_DIGEST_C.hex()}/uri', 1234, 'text or null'),
            (f'assetRegister/assets/{FAKE_DIGEST_B.hex()}/id', 1234, 'text or null'),
            (f'assetRegister/assets/{FAKE_DIGEST_A.hex()}/size', 'something', 'an integer')
        )
        path_to_change: str
        new_value: Any
        error_message_suffix: str
        for path_to_change, new_value, error_message_suffix in list_of_paths_to_change:
            with self.subTest(changed_entry=path_to_change, new_value=new_value):
                json_root: dict[Any, Any] = json_tools.load_and_change_json_value(SAMPLE_UPDATE_DIRECTORY, path_to_change, new_value)
                with self.assertRaises(SchemaLoadError) as capture:
                    UpdateDirectorySchema().load(json_root)
                self.assertEqual(f"Key '{path_to_change}' value is not {error_message_suffix}", str(capture.exception))

    def test_access_to_properties(self) -> None:
        json_root: dict[Any, Any] = json_tools.load_json(SAMPLE_UPDATE_DIRECTORY)
        update_directory = UpdateDirectorySchema()
        update_directory.load(json_root)

        self.assertEqual(1, update_directory.format)
        self.assertEqual('https://example.com/version-manifect.json', update_directory.version_manifest_uri)
        self.assertEqual('file:///tmp/test/<>', update_directory.asset_register.template_asset_uri)
        self.assertEqual('file:///tmp/test/abcd', update_directory.asset_register.assets[MockDigest(FAKE_DIGEST_A)].uri)
        self.assertEqual('pear', update_directory.asset_register.assets[MockDigest(FAKE_DIGEST_B)].identifier)
        self.assertEqual(2345, update_directory.asset_register.assets[MockDigest(FAKE_DIGEST_C)].size)

    def test_throws_when_no_template_asset_uri_and_asset_uri_is_empty(self) -> None:
        json_root: dict[Any, Any] = json_tools.load_json(SAMPLE_UPDATE_DIRECTORY)
        json_tools.change_json_value(json_root, 'assetRegister/templateAssetUri', None)
        json_tools.change_json_value(json_root, f'assetRegister/assets/{FAKE_DIGEST_B.hex()}/uri', None)
        with self.assertRaises(SchemaLoadError) as capture:
            UpdateDirectorySchema().load(json_root)
        self.assertEqual(f"Asset '{FAKE_DIGEST_B.hex()}' must specify a URI when there is no template URI", str(capture.exception))

    def test_throws_when_template_asset_uri_does_not_include_placeholder(self) -> None:
        json_root: dict[Any, Any] = json_tools.load_json(SAMPLE_UPDATE_DIRECTORY)
        json_tools.change_json_value(json_root, 'assetRegister/templateAssetUri', 'file:///tmp/test/<')
        with self.assertRaises(SchemaLoadError) as capture:
            UpdateDirectorySchema().load(json_root)
        self.assertEqual("'assetRegister/templateAssetUri' value 'file:///tmp/test/<' does not include the '<>' placeholder", str(capture.exception))

    def test_resolve_returns_none_if_digest_not_found(self) -> None:
        json_root: dict[Any, Any] = json_tools.load_json(SAMPLE_UPDATE_DIRECTORY)
        json_tools.prune_json_key(json_root, f'assetRegister/assets/{FAKE_DIGEST_B.hex()}')

        update_directory = UpdateDirectorySchema()
        update_directory.load(json_root)

        uri: str | None = update_directory.asset_register.resolve_asset_uri(MockDigest(FAKE_DIGEST_B))

        self.assertIsNone(uri)

    def test_resolve_returns_asset_uri_if_specified_ignoring_specified_template(self) -> None:
        json_root: dict[Any, Any] = json_tools.load_json(SAMPLE_UPDATE_DIRECTORY)
        json_tools.change_json_value(json_root, 'assetRegister/templateAssetUri', 'file:///tmp/test/<>')
        json_tools.change_json_value(json_root, f'assetRegister/assets/{FAKE_DIGEST_B.hex()}/uri', 'file:///something')

        update_directory = UpdateDirectorySchema()
        update_directory.load(json_root)

        uri: str | None = update_directory.asset_register.resolve_asset_uri(MockDigest(FAKE_DIGEST_B))

        self.assertEqual('file:///something', uri)

    def test_resolve_returns_asset_uri_if_specified_ignoring_no_template(self) -> None:
        json_root: dict[Any, Any] = json_tools.load_json(SAMPLE_UPDATE_DIRECTORY)
        json_tools.change_json_value(json_root, 'assetRegister/templateAssetUri', None)
        json_tools.change_json_value(json_root, f'assetRegister/assets/{FAKE_DIGEST_B.hex()}/uri', 'file:///something')

        update_directory = UpdateDirectorySchema()
        update_directory.load(json_root)

        uri: str | None = update_directory.asset_register.resolve_asset_uri(MockDigest(FAKE_DIGEST_B))

        self.assertEqual('file:///something', uri)

    def test_resolve_returns_identifier_substituted_if_no_asset_uri(self) -> None:
        json_root: dict[Any, Any] = json_tools.load_json(SAMPLE_UPDATE_DIRECTORY)
        json_tools.change_json_value(json_root, 'assetRegister/templateAssetUri', 'file:///tmp/test/<>')
        json_tools.change_json_value(json_root, f'assetRegister/assets/{FAKE_DIGEST_B.hex()}/id', '1234abcd')
        json_tools.change_json_value(json_root, f'assetRegister/assets/{FAKE_DIGEST_B.hex()}/uri', None)

        update_directory = UpdateDirectorySchema()
        update_directory.load(json_root)

        uri: str | None = update_directory.asset_register.resolve_asset_uri(MockDigest(FAKE_DIGEST_B))

        self.assertEqual('file:///tmp/test/1234abcd', uri)

    def test_resolve_returns_digest_substituted_if_no_asset_uri_and_no_identifer(self) -> None:
        json_root: dict[Any, Any] = json_tools.load_json(SAMPLE_UPDATE_DIRECTORY)
        json_tools.change_json_value(json_root, 'assetRegister/templateAssetUri', 'file:///tmp/test/<>')
        json_tools.change_json_value(json_root, f'assetRegister/assets/{FAKE_DIGEST_B.hex()}/id', None)
        json_tools.change_json_value(json_root, f'assetRegister/assets/{FAKE_DIGEST_B.hex()}/uri', None)

        update_directory = UpdateDirectorySchema()
        update_directory.load(json_root)

        uri: str | None = update_directory.asset_register.resolve_asset_uri(MockDigest(FAKE_DIGEST_B))

        self.assertEqual(f'file:///tmp/test/{FAKE_DIGEST_B.hex()}', uri)
