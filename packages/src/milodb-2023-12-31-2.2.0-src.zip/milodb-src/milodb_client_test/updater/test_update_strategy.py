# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
import unittest
from unittest.mock import Mock, PropertyMock, patch
from milodb_client.updater.i_file_hasher import HashError, HashFileNotFoundError, IFileHasher
from milodb_client.updater.i_file_tester import FileStat, IFileTester
from milodb_client.updater.manifest.common_manifest import IConfigFile, IHexDigest, ILaunchFile, IVersionNumber
from milodb_client.updater.manifest.local_manifest import ILocalManifest
from milodb_client.updater.manifest.update_directory import IAsset, IAssetRegister
from milodb_client.updater.manifest.version_manifest import ICoreFile, IVariant, IVersion, IVersionManifest
from milodb_client.updater.manifest.version_number import VersionNumber
from milodb_client.updater.update_strategy import BackupFileSet, ConfigFileChanges, CoreFileChanges, FileRename, UpdateStrategy, UpdateStrategyError, determine_config_file_changes, determine_core_file_changes, determine_files_to_backup, determine_newer_versions, determine_update_strategy, find_target_variant_and_version
from milodb_client_test.test.mock_hex_digest import MockDigest
from milodb_common_test.test.strict_mock import StrictMock

FAKE_DIGEST_A: bytes = bytes.fromhex('5de2a9952aa5ca078d0f62dde2ab7786a95ff22e0d47041d0bda7507')
FAKE_DIGEST_B: bytes = bytes.fromhex('0f0b26f887238a0c755cf1577cdf9a9d14d4875f67ed24d856bd7c63')
FAKE_DIGEST_C: bytes = bytes.fromhex('818a64a46f6e7a5e28738f34e79ea530a7d437f56425e6e407a9068c')
FAKE_DIGEST_D: bytes = bytes.fromhex('9fbccc2ada7f2310ac7a7d6cea53eeddf5dc49a9cc3cfbf3f01b6e66')
FAKE_DIGEST_E: bytes = bytes.fromhex('0b31b236147881106db5aec5b64707ff342a3cb721eeab7a93e35dc3')
FAKE_DIGEST_F: bytes = bytes.fromhex('9fbccc2ada7f2310ac7a7d6cea53eeddf5dc49a9cc3cfbf3f01b6e66')

class TestFindTargetVariantAndVersion(unittest.TestCase):
    def setUp(self) -> None:
        super().setUp()

        self.variant_windows = StrictMock(IVariant)
        self.variant_linux = StrictMock(IVariant)
        self.variant_vms = StrictMock(IVariant)
        self.variant_windows.name = PropertyMock(return_value='windows')
        self.variant_linux.name = PropertyMock(return_value='linux')
        self.variant_vms.name = PropertyMock(return_value='vms')

        self.version_number_1 = VersionNumber.parse('1.0.0')
        self.version_number_2 = VersionNumber.parse('2.0.0')
        self.version_number_3 = VersionNumber.parse('3.0.0')
        self.unknown_version_number = VersionNumber.parse('2.1.3')

        self.version_1 = StrictMock(IVersion)
        self.version_2 = StrictMock(IVersion)
        self.version_3 = StrictMock(IVersion)
        self.version_1.number = PropertyMock(return_value=self.version_number_1)
        self.version_2.number = PropertyMock(return_value=self.version_number_2)
        self.version_3.number = PropertyMock(return_value=self.version_number_3)

        self.variant_windows.versions = PropertyMock(return_value={})
        self.variant_linux.versions = PropertyMock(return_value={
            self.version_3.number: self.version_3,
            self.version_1.number: self.version_1,
            self.version_2.number: self.version_2
        })
        self.variant_vms.versions = PropertyMock(return_value={})

        self.map_of_variants: dict[str, Mock] = {
            self.variant_windows.name: self.variant_windows,
            self.variant_linux.name: self.variant_linux,
            self.variant_vms.name: self.variant_vms
        }

    def test_finds_latest_version_when_version_number_not_specified(self) -> None:
        requested_variant_name: str = 'linux'
        requested_version_number: IVersionNumber | None = None

        target_variant: IVariant
        target_version: IVersion
        target_variant, target_version = find_target_variant_and_version(requested_version_number, requested_variant_name, self.map_of_variants)

        self.assertIs(self.variant_linux, target_variant)
        self.assertIs(self.version_3, target_version)

    def test_finds_specified_version_when_specified(self) -> None:
        requested_variant_name: str = 'linux'
        requested_version_number: IVersionNumber | None = self.version_number_1

        target_variant: IVariant
        target_version: IVersion
        target_variant, target_version = find_target_variant_and_version(requested_version_number, requested_variant_name, self.map_of_variants)

        self.assertIs(self.variant_linux, target_variant)
        self.assertIs(self.version_1, target_version)

    def test_raises_error_when_specified_variant_does_not_exist(self) -> None:
        requested_variant_name: str = 'darwin'
        requested_version_number: IVersionNumber | None = None

        with self.assertRaises(UpdateStrategyError) as ex:
            find_target_variant_and_version(requested_version_number, requested_variant_name, self.map_of_variants)

        self.assertEqual(f"Requested variant '{requested_variant_name}' does not exist in the version manifest", str(ex.exception))

    def test_raises_error_when_specified_version_does_not_exist_within_variant(self) -> None:
        requested_variant_name: str = 'linux'
        requested_version_number: IVersionNumber | None = self.unknown_version_number

        with self.assertRaises(UpdateStrategyError) as ex:
            find_target_variant_and_version(requested_version_number, requested_variant_name, self.map_of_variants)

        self.assertEqual(f"Requested version '{requested_version_number}' in variant '{requested_variant_name}' does not exist in the version manifest", str(ex.exception))

    def test_raises_error_when_specified_variant_has_no_versions(self) -> None:
        requested_variant_name: str = 'windows'
        requested_version_number: IVersionNumber | None = None

        with self.assertRaises(UpdateStrategyError) as ex:
            find_target_variant_and_version(requested_version_number, requested_variant_name, self.map_of_variants)

        self.assertEqual(f"Requested variant '{requested_variant_name}' has no versions in the version manifest", str(ex.exception))

class TestDetermineCoreFileChanges(unittest.TestCase):
    def setUp(self) -> None:
        super().setUp()
        self.file_hasher = StrictMock(IFileHasher)

    def test_no_local_files_and_no_target_files_returns_no_changes(self) -> None:
        list_of_local_files: list[str] = []
        map_of_target_core_files: dict[str, ICoreFile] = {}
        set_of_asset_digests: set[IHexDigest] = set()

        core_file_changes: CoreFileChanges = determine_core_file_changes(list_of_local_files, map_of_target_core_files, set_of_asset_digests, self.file_hasher)

        self.assertFalse(core_file_changes.list_of_new_files_to_acquire)
        self.assertFalse(core_file_changes.list_of_missing_files_to_acquire)
        self.assertFalse(core_file_changes.list_of_changed_files_to_acquire)
        self.assertFalse(core_file_changes.list_of_unchanged_files)
        self.assertFalse(core_file_changes.list_of_files_that_are_deprecated)

    def test_two_local_files_and_no_target_files_returns_files_to_remove(self) -> None:
        list_of_local_files: list[str] = ['foo.txt', 'bar.dat']
        map_of_target_core_files: dict[str, ICoreFile] = {}
        set_of_asset_digests: set[IHexDigest] = set()

        core_file_changes: CoreFileChanges = determine_core_file_changes(list_of_local_files, map_of_target_core_files, set_of_asset_digests, self.file_hasher)

        self.assertFalse(core_file_changes.list_of_new_files_to_acquire)
        self.assertFalse(core_file_changes.list_of_missing_files_to_acquire)
        self.assertFalse(core_file_changes.list_of_changed_files_to_acquire)
        self.assertFalse(core_file_changes.list_of_unchanged_files)
        self.assertListEqual(list_of_local_files, core_file_changes.list_of_files_that_are_deprecated)

    def test_two_local_files_and_one_target_file_with_same_name_and_digest_returns_one_unchanged_file(self) -> None:
        list_of_local_files: list[str] = ['foo.txt', 'bar.dat']
        core_file = StrictMock(ICoreFile)
        core_file.filename = PropertyMock(return_value='bar.dat')
        core_file.digest = PropertyMock(return_value=MockDigest(FAKE_DIGEST_A))
        map_of_target_core_files: dict[str, ICoreFile] = {
            core_file.filename: core_file
        }
        set_of_asset_digests: set[IHexDigest] = { MockDigest(FAKE_DIGEST_A) }
        self.file_hasher.hash_file = Mock(return_value=FAKE_DIGEST_A)

        core_file_changes: CoreFileChanges = determine_core_file_changes(list_of_local_files, map_of_target_core_files, set_of_asset_digests, self.file_hasher)

        self.file_hasher.hash_file.assert_called_once_with('bar.dat')
        self.assertFalse(core_file_changes.list_of_new_files_to_acquire)
        self.assertFalse(core_file_changes.list_of_missing_files_to_acquire)
        self.assertFalse(core_file_changes.list_of_changed_files_to_acquire)
        self.assertListEqual([core_file], core_file_changes.list_of_unchanged_files)
        self.assertListEqual(['foo.txt'], core_file_changes.list_of_files_that_are_deprecated)

    def test_two_local_files_and_one_target_file_with_same_name_and_different_digest_returns_changed_file_to_acquire(self) -> None:
        list_of_local_files: list[str] = ['foo.txt', 'bar.dat']
        core_file = StrictMock(ICoreFile)
        core_file.filename = PropertyMock(return_value='bar.dat')
        core_file.digest = PropertyMock(return_value=MockDigest(FAKE_DIGEST_A))
        map_of_target_core_files: dict[str, ICoreFile] = {
            core_file.filename: core_file
        }
        set_of_asset_digests: set[IHexDigest] = { MockDigest(FAKE_DIGEST_A) }
        self.file_hasher.hash_file = Mock(return_value=FAKE_DIGEST_B)

        core_file_changes: CoreFileChanges = determine_core_file_changes(list_of_local_files, map_of_target_core_files, set_of_asset_digests, self.file_hasher)

        self.file_hasher.hash_file.assert_called_once_with('bar.dat')
        self.assertFalse(core_file_changes.list_of_new_files_to_acquire)
        self.assertFalse(core_file_changes.list_of_missing_files_to_acquire)
        self.assertListEqual([core_file], core_file_changes.list_of_changed_files_to_acquire)
        self.assertFalse(core_file_changes.list_of_unchanged_files)
        self.assertListEqual(['foo.txt'], core_file_changes.list_of_files_that_are_deprecated)

    def test_two_local_files_and_one_target_file_with_different_name_and_different_digest_returns_new_file_to_acquire(self) -> None:
        list_of_local_files: list[str] = ['foo.txt', 'bar.dat']
        core_file = StrictMock(ICoreFile)
        core_file.filename = PropertyMock(return_value='fruit.id')
        core_file.digest = PropertyMock(return_value=MockDigest(FAKE_DIGEST_A))
        map_of_target_core_files: dict[str, ICoreFile] = {
            core_file.filename: core_file
        }
        set_of_asset_digests: set[IHexDigest] = { MockDigest(FAKE_DIGEST_A) }

        core_file_changes: CoreFileChanges = determine_core_file_changes(list_of_local_files, map_of_target_core_files, set_of_asset_digests, self.file_hasher)

        self.assertListEqual([core_file], core_file_changes.list_of_new_files_to_acquire)
        self.assertFalse(core_file_changes.list_of_missing_files_to_acquire)
        self.assertFalse(core_file_changes.list_of_changed_files_to_acquire)
        self.assertFalse(core_file_changes.list_of_unchanged_files)
        self.assertCountEqual(['foo.txt', 'bar.dat'], core_file_changes.list_of_files_that_are_deprecated)

    def test_two_local_files_where_one_is_missing_and_matching_target_files_with_same_digests_returns_missing_file_to_acquire(self) -> None:
        list_of_local_files: list[str] = ['foo.txt', 'bar.dat']
        core_file_1 = StrictMock(ICoreFile)
        core_file_1.filename = PropertyMock(return_value='foo.txt')
        core_file_1.digest = PropertyMock(return_value=MockDigest(FAKE_DIGEST_A))
        core_file_2 = StrictMock(ICoreFile)
        core_file_2.filename = PropertyMock(return_value='bar.dat')
        core_file_2.digest = PropertyMock(return_value=MockDigest(FAKE_DIGEST_B))
        map_of_target_core_files: dict[str, ICoreFile] = {
            core_file_1.filename: core_file_1,
            core_file_2.filename: core_file_2
        }
        set_of_asset_digests: set[IHexDigest] = { MockDigest(FAKE_DIGEST_A), MockDigest(FAKE_DIGEST_B) }
        def on_hash_file(filename: str) -> bytes:
            if filename == 'foo.txt':
                raise HashFileNotFoundError()
            if filename == 'bar.dat':
                return FAKE_DIGEST_B
            self.fail(f"Unexpected call to hash_file('{filename}')")
            return bytes()
        self.file_hasher.hash_file = Mock(side_effect=on_hash_file)

        core_file_changes: CoreFileChanges = determine_core_file_changes(list_of_local_files, map_of_target_core_files, set_of_asset_digests, self.file_hasher)

        self.assertFalse(core_file_changes.list_of_new_files_to_acquire)
        self.assertListEqual([core_file_1], core_file_changes.list_of_missing_files_to_acquire)
        self.assertFalse(core_file_changes.list_of_changed_files_to_acquire)
        self.assertListEqual([core_file_2], core_file_changes.list_of_unchanged_files)
        self.assertFalse(core_file_changes.list_of_files_that_are_deprecated)

    def test_error_raised_when_a_hash_file_error_occurs(self) -> None:
        list_of_local_files: list[str] = ['foo.txt', 'bar.dat']
        core_file = StrictMock(ICoreFile)
        core_file.filename = PropertyMock(return_value='bar.dat')
        core_file.digest = PropertyMock(return_value=MockDigest(FAKE_DIGEST_B))
        map_of_target_core_files: dict[str, ICoreFile] = {
            core_file.filename: core_file
        }
        set_of_asset_digests: set[IHexDigest] = { MockDigest(FAKE_DIGEST_B) }
        self.file_hasher.hash_file = Mock(side_effect=HashError('test message'))

        with self.assertRaises(UpdateStrategyError) as ex:
            determine_core_file_changes(list_of_local_files, map_of_target_core_files, set_of_asset_digests, self.file_hasher)

        self.assertEqual('test message', str(ex.exception))

    def test_error_raised_when_a_digest_is_not_in_the_asset_register(self) -> None:
        list_of_local_files: list[str] = ['foo.txt', 'bar.dat']
        core_file = StrictMock(ICoreFile)
        core_file.filename = PropertyMock(return_value='bar.dat')
        core_file.digest = PropertyMock(return_value=MockDigest(FAKE_DIGEST_B))
        map_of_target_core_files: dict[str, ICoreFile] = {
            core_file.filename: core_file
        }
        set_of_asset_digests: set[IHexDigest] = { MockDigest(FAKE_DIGEST_A) }
        self.file_hasher.hash_file = Mock(side_effect=HashError('test message'))

        with self.assertRaises(UpdateStrategyError) as ex:
            determine_core_file_changes(list_of_local_files, map_of_target_core_files, set_of_asset_digests, self.file_hasher)

        self.assertEqual(f"Core file 'bar.dat' with digest '{FAKE_DIGEST_B.hex()}' does not appear in the asset register", str(ex.exception))

class TestDetermineConfigFileChanges(unittest.TestCase):
    def test_no_local_files_and_no_target_files(self) -> None:
        """
        ### Local
        * (none)
        ### Target
        * (none)
        ### Expected
        * (no changes)
        """
        map_of_local_config_files: dict[int, IConfigFile] = {}
        map_of_target_config_files: dict[int, IConfigFile] = {}

        config_file_changes: ConfigFileChanges = determine_config_file_changes(map_of_local_config_files, map_of_target_config_files)

        self.assertFalse(config_file_changes.list_of_files_that_are_deprecated)
        self.assertFalse(config_file_changes.list_of_files_to_rename)
        self.assertFalse(config_file_changes.list_of_files_to_leave)
        self.assertFalse(config_file_changes.list_of_new_files)

    def test_two_local_files_and_no_target_files(self) -> None:
        """
        ### Local
        * 23: test.dat
        * 8: another.txt
        ### Target
        * (none)
        ### Expected
        * files_to_remove = test.dat, another.txt
        """
        local_file_1 = StrictMock(IConfigFile)
        local_file_1.config_key = PropertyMock(return_value=23)
        local_file_1.filename = PropertyMock(return_value='test.dat')
        local_file_2 = StrictMock(IConfigFile)
        local_file_2.config_key = PropertyMock(return_value=8)
        local_file_2.filename = PropertyMock(return_value='another.txt')
        map_of_local_config_files: dict[int, IConfigFile] = {
            local_file_1.config_key: local_file_1,
            local_file_2.config_key: local_file_2
        }
        map_of_target_config_files: dict[int, IConfigFile] = {}

        config_file_changes: ConfigFileChanges = determine_config_file_changes(map_of_local_config_files, map_of_target_config_files)

        self.assertCountEqual(['test.dat', 'another.txt'], config_file_changes.list_of_files_that_are_deprecated)
        self.assertFalse(config_file_changes.list_of_files_to_rename)
        self.assertFalse(config_file_changes.list_of_files_to_leave)
        self.assertFalse(config_file_changes.list_of_new_files)

    def test_no_local_files_and_two_target_files(self) -> None:
        """
        ### Local
        * (none)
        ### Target
        * 23: test.dat
        * 8: another.txt
        ### Expected
        * new_files = test.dat, another.txt
        """
        map_of_local_config_files: dict[int, IConfigFile] = {}
        target_file_1 = StrictMock(IConfigFile)
        target_file_1.config_key = PropertyMock(return_value=23)
        target_file_1.filename = PropertyMock(return_value='test.dat')
        target_file_2 = StrictMock(IConfigFile)
        target_file_2.config_key = PropertyMock(return_value=8)
        target_file_2.filename = PropertyMock(return_value='another.txt')
        map_of_target_config_files: dict[int, IConfigFile] = {
            target_file_1.config_key: target_file_1,
            target_file_2.config_key: target_file_2
        }

        config_file_changes: ConfigFileChanges = determine_config_file_changes(map_of_local_config_files, map_of_target_config_files)

        self.assertFalse(config_file_changes.list_of_files_that_are_deprecated)
        self.assertFalse(config_file_changes.list_of_files_to_rename)
        self.assertFalse(config_file_changes.list_of_files_to_leave)
        self.assertCountEqual(['test.dat', 'another.txt'], config_file_changes.list_of_new_files)

    def test_two_local_files_and_two_target_files_with_same_names_and_keys(self) -> None:
        """
        ### Local
        * 23: test.dat
        * 8: another.txt
        ### Target
        * 23: test.dat
        * 8: another.txt
        ### Expected
        * files_to_leave = test.dat, another.txt
        """
        local_file_1 = StrictMock(IConfigFile)
        local_file_1.config_key = PropertyMock(return_value=23)
        local_file_1.filename = PropertyMock(return_value='test.dat')
        local_file_2 = StrictMock(IConfigFile)
        local_file_2.config_key = PropertyMock(return_value=8)
        local_file_2.filename = PropertyMock(return_value='another.txt')
        map_of_local_config_files: dict[int, IConfigFile] = {
            local_file_1.config_key: local_file_1,
            local_file_2.config_key: local_file_2
        }
        target_file_1 = StrictMock(IConfigFile)
        target_file_1.config_key = PropertyMock(return_value=23)
        target_file_1.filename = PropertyMock(return_value='test.dat')
        target_file_2 = StrictMock(IConfigFile)
        target_file_2.config_key = PropertyMock(return_value=8)
        target_file_2.filename = PropertyMock(return_value='another.txt')
        map_of_target_config_files: dict[int, IConfigFile] = {
            target_file_1.config_key: target_file_1,
            target_file_2.config_key: target_file_2
        }

        config_file_changes: ConfigFileChanges = determine_config_file_changes(map_of_local_config_files, map_of_target_config_files)

        self.assertFalse(config_file_changes.list_of_files_that_are_deprecated)
        self.assertFalse(config_file_changes.list_of_files_to_rename)
        self.assertCountEqual(['test.dat', 'another.txt'], config_file_changes.list_of_files_to_leave)
        self.assertFalse(config_file_changes.list_of_new_files)

    def test_two_local_files_and_two_target_files_where_one_target_file_has_same_name_but_different_key(self) -> None:
        """
        ### Local
        * 23: test.dat
        * 8: another.txt
        ### Target
        * 23: test.dat
        * 31: another.txt
        ### Expected
        * files_to_leave  = test.dat
        * files_to_remove = another.txt
        * new_files       = another.txt
        """
        local_file_1 = StrictMock(IConfigFile)
        local_file_1.config_key = PropertyMock(return_value=23)
        local_file_1.filename = PropertyMock(return_value='test.dat')
        local_file_2 = StrictMock(IConfigFile)
        local_file_2.config_key = PropertyMock(return_value=8)
        local_file_2.filename = PropertyMock(return_value='another.txt')
        map_of_local_config_files: dict[int, IConfigFile] = {
            local_file_1.config_key: local_file_1,
            local_file_2.config_key: local_file_2
        }
        target_file_1 = StrictMock(IConfigFile)
        target_file_1.config_key = PropertyMock(return_value=23)
        target_file_1.filename = PropertyMock(return_value='test.dat')
        target_file_2 = StrictMock(IConfigFile)
        target_file_2.config_key = PropertyMock(return_value=31)
        target_file_2.filename = PropertyMock(return_value='another.txt')
        map_of_target_config_files: dict[int, IConfigFile] = {
            target_file_1.config_key: target_file_1,
            target_file_2.config_key: target_file_2
        }

        config_file_changes: ConfigFileChanges = determine_config_file_changes(map_of_local_config_files, map_of_target_config_files)

        self.assertCountEqual(['another.txt'], config_file_changes.list_of_files_that_are_deprecated)
        self.assertFalse(config_file_changes.list_of_files_to_rename)
        self.assertCountEqual(['test.dat'], config_file_changes.list_of_files_to_leave)
        self.assertCountEqual(['another.txt'], config_file_changes.list_of_new_files)

    def test_two_local_files_and_two_target_files_where_one_target_file_has_same_key_but_different_name(self) -> None:
        """
        ### Local
        * 23: test.dat
        * 8: another.txt
        ### Target
        * 23: test.dat
        * 8: something.log
        ### Expected
        * files_to_leave  = test.dat
        * files_to_rename = another.txt -> something.log
        """
        local_file_1 = StrictMock(IConfigFile)
        local_file_1.config_key = PropertyMock(return_value=23)
        local_file_1.filename = PropertyMock(return_value='test.dat')
        local_file_2 = StrictMock(IConfigFile)
        local_file_2.config_key = PropertyMock(return_value=8)
        local_file_2.filename = PropertyMock(return_value='another.txt')
        map_of_local_config_files: dict[int, IConfigFile] = {
            local_file_1.config_key: local_file_1,
            local_file_2.config_key: local_file_2
        }
        target_file_1 = StrictMock(IConfigFile)
        target_file_1.config_key = PropertyMock(return_value=23)
        target_file_1.filename = PropertyMock(return_value='test.dat')
        target_file_2 = StrictMock(IConfigFile)
        target_file_2.config_key = PropertyMock(return_value=8)
        target_file_2.filename = PropertyMock(return_value='something.log')
        map_of_target_config_files: dict[int, IConfigFile] = {
            target_file_1.config_key: target_file_1,
            target_file_2.config_key: target_file_2
        }

        config_file_changes: ConfigFileChanges = determine_config_file_changes(map_of_local_config_files, map_of_target_config_files)

        self.assertFalse(config_file_changes.list_of_files_that_are_deprecated)
        self.assertEqual(1, len(config_file_changes.list_of_files_to_rename))
        self.assertEqual('another.txt', config_file_changes.list_of_files_to_rename[0].original_filename)
        self.assertEqual('something.log', config_file_changes.list_of_files_to_rename[0].new_filename)
        self.assertCountEqual(['test.dat'], config_file_changes.list_of_files_to_leave)
        self.assertFalse(config_file_changes.list_of_new_files)

class TestDetermineNewerVersions(unittest.TestCase):
    def setUp(self) -> None:
        super().setUp()

        self.variant_windows = StrictMock(IVariant)
        self.variant_linux = StrictMock(IVariant)
        self.variant_vms = StrictMock(IVariant)
        self.variant_windows.name = PropertyMock(return_value='windows')
        self.variant_linux.name = PropertyMock(return_value='linux')
        self.variant_vms.name = PropertyMock(return_value='vms')

        self.version_number_0 = VersionNumber.parse('1.2.3')
        self.version_number_1 = VersionNumber.parse('2.0.1')
        self.version_number_2 = VersionNumber.parse('3.7.9')
        self.version_number_3 = VersionNumber.parse('4.1.2')
        self.version_number_4 = VersionNumber.parse('5.6.8')

        self.version_1 = StrictMock(IVersion)
        self.version_2 = StrictMock(IVersion)
        self.version_3 = StrictMock(IVersion)
        self.version_1.number = PropertyMock(return_value=self.version_number_1)
        self.version_2.number = PropertyMock(return_value=self.version_number_2)
        self.version_3.number = PropertyMock(return_value=self.version_number_3)

        self.variant_windows.versions = PropertyMock(return_value={})
        self.variant_linux.versions = PropertyMock(return_value={
            self.version_3.number: self.version_3,
            self.version_1.number: self.version_1,
            self.version_2.number: self.version_2
        })
        self.variant_vms.versions = PropertyMock(return_value={})

    def test_when_starting_variant_does_not_match_target_variant_returns_no_versions(self) -> None:
        list_of_versions: list[IVersion] = determine_newer_versions('linux', StrictMock(IVersionNumber), self.variant_windows, StrictMock(IVersionNumber))
        self.assertFalse(list_of_versions)

    def test_when_matching_variant_has_no_versions_returns_no_versions(self) -> None:
        list_of_versions: list[IVersion] = determine_newer_versions('vms', StrictMock(IVersionNumber), self.variant_vms, StrictMock(IVersionNumber))
        self.assertFalse(list_of_versions)

    def test_starting_version_is_first_and_target_version_is_last_returns_all_later_versions(self) -> None:
        list_of_versions: list[IVersion] = determine_newer_versions('linux', self.version_number_1, self.variant_linux, self.version_number_3)
        self.assertListEqual([self.version_2, self.version_3], list_of_versions)

    def test_starting_version_is_second_and_target_version_is_last_returns_all_later_versions(self) -> None:
        list_of_versions: list[IVersion] = determine_newer_versions('linux', self.version_number_2, self.variant_linux, self.version_number_3)
        self.assertListEqual([self.version_3], list_of_versions)

    def test_starting_version_is_last_and_same_as_target_version_returns_no_versions(self) -> None:
        list_of_versions: list[IVersion] = determine_newer_versions('linux', self.version_number_3, self.variant_linux, self.version_number_3)
        self.assertListEqual([], list_of_versions)

    def test_starting_version_is_first_and_target_version_is_second_returns_target_version(self) -> None:
        list_of_versions: list[IVersion] = determine_newer_versions('linux', self.version_number_1, self.variant_linux, self.version_number_2)
        self.assertListEqual([self.version_2], list_of_versions)

    def test_starting_version_is_first_and_same_as_target_version_returns_no_versions(self) -> None:
        list_of_versions: list[IVersion] = determine_newer_versions('linux', self.version_number_1, self.variant_linux, self.version_number_1)
        self.assertListEqual([], list_of_versions)

    def test_starting_version_is_not_list_and_lowest_and_target_version_is_last_returns_all_versions(self) -> None:
        list_of_versions: list[IVersion] = determine_newer_versions('linux', self.version_number_0, self.variant_linux, self.version_number_3)
        self.assertListEqual([self.version_1, self.version_2, self.version_3], list_of_versions)

    def test_starting_version_is_first_and_target_version_is_not_in_list_and_highest_returns_all_later_versions(self) -> None:
        list_of_versions: list[IVersion] = determine_newer_versions('linux', self.version_number_1, self.variant_linux, self.version_number_4)
        self.assertListEqual([self.version_2, self.version_3], list_of_versions)

class TestDetermineFilesToBackup(unittest.TestCase):
    def setUp(self) -> None:
        super().setUp()
        self.core_file_1 = StrictMock(ICoreFile)
        self.core_file_1.filename = PropertyMock(return_value='file1')
        self.core_file_2 = StrictMock(ICoreFile)
        self.core_file_2.filename = PropertyMock(return_value='file2')

        self.config_filename_1 = 'config_file1'
        self.config_filename_2 = 'config_file2'
        self.config_new_filename_1 = 'config_new_file1'
        self.config_new_filename_2 = 'config_new_file2'

    def test_no_core_files_or_config_fields_yields_empty_list(self) -> None:
        core_file_changes: CoreFileChanges = CoreFileChanges(
            list_of_new_files_to_acquire = [],
            list_of_missing_files_to_acquire = [],
            list_of_changed_files_to_acquire = [],
            list_of_unchanged_files = [],
            list_of_files_that_are_deprecated = []
        )
        config_file_changes: ConfigFileChanges = ConfigFileChanges(
            list_of_files_that_are_deprecated = [],
            list_of_files_to_rename = [],
            list_of_files_to_leave = [],
            list_of_new_files = []
        )

        backup_file_set: BackupFileSet = determine_files_to_backup(core_file_changes, config_file_changes, StrictMock(IFileTester))

        self.assertFalse(backup_file_set.list_of_core_files_to_backup)
        self.assertFalse(backup_file_set.list_of_config_files_to_backup)
        self.assertFalse(backup_file_set.list_of_clobbered_files_to_backup)

    def test_new_core_files_yields_empty_list(self) -> None:
        core_file_changes: CoreFileChanges = CoreFileChanges(
            list_of_new_files_to_acquire = [self.core_file_1, self.core_file_2],
            list_of_missing_files_to_acquire = [],
            list_of_changed_files_to_acquire = [],
            list_of_unchanged_files = [],
            list_of_files_that_are_deprecated = []
        )
        config_file_changes: ConfigFileChanges = ConfigFileChanges(
            list_of_files_that_are_deprecated = [],
            list_of_files_to_rename = [],
            list_of_files_to_leave = [],
            list_of_new_files = []
        )
        file_tester = StrictMock(IFileTester)
        file_tester.stat_file = Mock(side_effect=lambda filename: {
            self.core_file_1.filename: FileStat(self.core_file_1.filename, False, False),
            self.core_file_2.filename: FileStat(self.core_file_1.filename, False, False)
        }[filename])

        backup_file_set: BackupFileSet = determine_files_to_backup(core_file_changes, config_file_changes, file_tester)

        self.assertFalse(backup_file_set.list_of_core_files_to_backup)
        self.assertFalse(backup_file_set.list_of_config_files_to_backup)
        self.assertFalse(backup_file_set.list_of_clobbered_files_to_backup)

    def test_new_core_files_with_desitnation_file_clash_yields_clobbered_file_list(self) -> None:
        core_file_changes: CoreFileChanges = CoreFileChanges(
            list_of_new_files_to_acquire = [self.core_file_1, self.core_file_2],
            list_of_missing_files_to_acquire = [],
            list_of_changed_files_to_acquire = [],
            list_of_unchanged_files = [],
            list_of_files_that_are_deprecated = []
        )
        config_file_changes: ConfigFileChanges = ConfigFileChanges(
            list_of_files_that_are_deprecated = [],
            list_of_files_to_rename = [],
            list_of_files_to_leave = [],
            list_of_new_files = []
        )
        file_tester = StrictMock(IFileTester)
        file_tester.stat_file = Mock(side_effect=lambda filename: {
            self.core_file_1.filename: FileStat(self.core_file_1.filename, False, False),
            self.core_file_2.filename: FileStat(self.core_file_1.filename, True, True)
        }[filename])

        backup_file_set: BackupFileSet = determine_files_to_backup(core_file_changes, config_file_changes, file_tester)

        self.assertFalse(backup_file_set.list_of_core_files_to_backup)
        self.assertFalse(backup_file_set.list_of_config_files_to_backup)
        self.assertCountEqual([self.core_file_2.filename], backup_file_set.list_of_clobbered_files_to_backup)

    def test_new_core_files_with_desitnation_directory_clash_raises_error(self) -> None:
        core_file_changes: CoreFileChanges = CoreFileChanges(
            list_of_new_files_to_acquire = [self.core_file_1, self.core_file_2],
            list_of_missing_files_to_acquire = [],
            list_of_changed_files_to_acquire = [],
            list_of_unchanged_files = [],
            list_of_files_that_are_deprecated = []
        )
        config_file_changes: ConfigFileChanges = ConfigFileChanges(
            list_of_files_that_are_deprecated = [],
            list_of_files_to_rename = [],
            list_of_files_to_leave = [],
            list_of_new_files = []
        )
        file_tester = StrictMock(IFileTester)
        file_tester.stat_file = Mock(side_effect=lambda filename: {
            self.core_file_1.filename: FileStat(self.core_file_1.filename, False, False),
            self.core_file_2.filename: FileStat(self.core_file_1.filename, True, False)
        }[filename])

        with self.assertRaises(UpdateStrategyError) as ex:
            determine_files_to_backup(core_file_changes, config_file_changes, file_tester)

        self.assertEqual(f"Destination file '{self.core_file_2.filename}' already exists and is a directory", str(ex.exception))

    def test_missing_core_files_yields_empty_list(self) -> None:
        core_file_changes: CoreFileChanges = CoreFileChanges(
            list_of_new_files_to_acquire = [],
            list_of_missing_files_to_acquire = [self.core_file_1, self.core_file_2],
            list_of_changed_files_to_acquire = [],
            list_of_unchanged_files = [],
            list_of_files_that_are_deprecated = []
        )
        config_file_changes: ConfigFileChanges = ConfigFileChanges(
            list_of_files_that_are_deprecated = [],
            list_of_files_to_rename = [],
            list_of_files_to_leave = [],
            list_of_new_files = []
        )

        backup_file_set: BackupFileSet = determine_files_to_backup(core_file_changes, config_file_changes, StrictMock(IFileTester))

        self.assertFalse(backup_file_set.list_of_core_files_to_backup)
        self.assertFalse(backup_file_set.list_of_config_files_to_backup)
        self.assertFalse(backup_file_set.list_of_clobbered_files_to_backup)

    def test_changed_core_files_yields_list_of_files(self) -> None:
        core_file_changes: CoreFileChanges = CoreFileChanges(
            list_of_new_files_to_acquire = [],
            list_of_missing_files_to_acquire = [],
            list_of_changed_files_to_acquire = [self.core_file_1, self.core_file_2],
            list_of_unchanged_files = [],
            list_of_files_that_are_deprecated = []
        )
        config_file_changes: ConfigFileChanges = ConfigFileChanges(
            list_of_files_that_are_deprecated = [],
            list_of_files_to_rename = [],
            list_of_files_to_leave = [],
            list_of_new_files = []
        )

        backup_file_set: BackupFileSet = determine_files_to_backup(core_file_changes, config_file_changes, StrictMock(IFileTester))

        self.assertCountEqual([self.core_file_1.filename, self.core_file_2.filename], backup_file_set.list_of_core_files_to_backup)
        self.assertFalse(backup_file_set.list_of_config_files_to_backup)
        self.assertFalse(backup_file_set.list_of_clobbered_files_to_backup)

    def test_unchanged_core_files_yields_list_of_files(self) -> None:
        core_file_changes: CoreFileChanges = CoreFileChanges(
            list_of_new_files_to_acquire = [],
            list_of_missing_files_to_acquire = [],
            list_of_changed_files_to_acquire = [],
            list_of_unchanged_files = [self.core_file_1, self.core_file_2],
            list_of_files_that_are_deprecated = []
        )
        config_file_changes: ConfigFileChanges = ConfigFileChanges(
            list_of_files_that_are_deprecated = [],
            list_of_files_to_rename = [],
            list_of_files_to_leave = [],
            list_of_new_files = []
        )

        backup_file_set: BackupFileSet = determine_files_to_backup(core_file_changes, config_file_changes, StrictMock(IFileTester))

        self.assertCountEqual([self.core_file_1.filename, self.core_file_2.filename], backup_file_set.list_of_core_files_to_backup)
        self.assertFalse(backup_file_set.list_of_config_files_to_backup)
        self.assertFalse(backup_file_set.list_of_clobbered_files_to_backup)

    def test_removed_core_files_yields_list_of_files(self) -> None:
        core_file_changes: CoreFileChanges = CoreFileChanges(
            list_of_new_files_to_acquire = [],
            list_of_missing_files_to_acquire = [],
            list_of_changed_files_to_acquire = [],
            list_of_unchanged_files = [],
            list_of_files_that_are_deprecated = [self.core_file_1.filename, self.core_file_2.filename]
        )
        config_file_changes: ConfigFileChanges = ConfigFileChanges(
            list_of_files_that_are_deprecated = [],
            list_of_files_to_rename = [],
            list_of_files_to_leave = [],
            list_of_new_files = []
        )

        backup_file_set: BackupFileSet = determine_files_to_backup(core_file_changes, config_file_changes, StrictMock(IFileTester))

        self.assertCountEqual([self.core_file_1.filename, self.core_file_2.filename], backup_file_set.list_of_core_files_to_backup)
        self.assertFalse(backup_file_set.list_of_config_files_to_backup)
        self.assertFalse(backup_file_set.list_of_clobbered_files_to_backup)

    def test_new_config_files_yields_empty_list(self) -> None:
        core_file_changes: CoreFileChanges = CoreFileChanges(
            list_of_new_files_to_acquire = [],
            list_of_missing_files_to_acquire = [],
            list_of_changed_files_to_acquire = [],
            list_of_unchanged_files = [],
            list_of_files_that_are_deprecated = []
        )
        config_file_changes: ConfigFileChanges = ConfigFileChanges(
            list_of_files_that_are_deprecated = [],
            list_of_files_to_rename = [],
            list_of_files_to_leave = [],
            list_of_new_files = [self.config_filename_1, self.config_filename_2]
        )

        backup_file_set: BackupFileSet = determine_files_to_backup(core_file_changes, config_file_changes, StrictMock(IFileTester))

        self.assertFalse(backup_file_set.list_of_core_files_to_backup)
        self.assertFalse(backup_file_set.list_of_config_files_to_backup)
        self.assertFalse(backup_file_set.list_of_clobbered_files_to_backup)

    def test_leave_config_files_yields_list_of_files(self) -> None:
        core_file_changes: CoreFileChanges = CoreFileChanges(
            list_of_new_files_to_acquire = [],
            list_of_missing_files_to_acquire = [],
            list_of_changed_files_to_acquire = [],
            list_of_unchanged_files = [],
            list_of_files_that_are_deprecated = []
        )
        config_file_changes: ConfigFileChanges = ConfigFileChanges(
            list_of_files_that_are_deprecated = [],
            list_of_files_to_rename = [],
            list_of_files_to_leave = [self.config_filename_1, self.config_filename_2],
            list_of_new_files = []
        )

        backup_file_set: BackupFileSet = determine_files_to_backup(core_file_changes, config_file_changes, StrictMock(IFileTester))

        self.assertFalse(backup_file_set.list_of_core_files_to_backup)
        self.assertCountEqual([self.config_filename_1, self.config_filename_2], backup_file_set.list_of_config_files_to_backup)
        self.assertFalse(backup_file_set.list_of_clobbered_files_to_backup)

    def test_rename_config_files_yields_list_of_files(self) -> None:
        core_file_changes: CoreFileChanges = CoreFileChanges(
            list_of_new_files_to_acquire = [],
            list_of_missing_files_to_acquire = [],
            list_of_changed_files_to_acquire = [],
            list_of_unchanged_files = [],
            list_of_files_that_are_deprecated = []
        )
        config_file_changes: ConfigFileChanges = ConfigFileChanges(
            list_of_files_that_are_deprecated = [],
            list_of_files_to_rename = [FileRename(self.config_filename_1, self.config_new_filename_1), FileRename(self.config_filename_2, self.config_new_filename_2)],
            list_of_files_to_leave = [],
            list_of_new_files = []
        )

        backup_file_set: BackupFileSet = determine_files_to_backup(core_file_changes, config_file_changes, StrictMock(IFileTester))

        self.assertFalse(backup_file_set.list_of_core_files_to_backup)
        self.assertCountEqual([self.config_filename_1, self.config_filename_2], backup_file_set.list_of_config_files_to_backup)
        self.assertFalse(backup_file_set.list_of_clobbered_files_to_backup)

    def test_remove_config_files_yields_list_of_files(self) -> None:
        core_file_changes: CoreFileChanges = CoreFileChanges(
            list_of_new_files_to_acquire = [],
            list_of_missing_files_to_acquire = [],
            list_of_changed_files_to_acquire = [],
            list_of_unchanged_files = [],
            list_of_files_that_are_deprecated = []
        )
        config_file_changes: ConfigFileChanges = ConfigFileChanges(
            list_of_files_that_are_deprecated = [self.config_filename_1, self.config_filename_2],
            list_of_files_to_rename = [],
            list_of_files_to_leave = [],
            list_of_new_files = []
        )

        backup_file_set: BackupFileSet = determine_files_to_backup(core_file_changes, config_file_changes, StrictMock(IFileTester))

        self.assertFalse(backup_file_set.list_of_core_files_to_backup)
        self.assertCountEqual([self.config_filename_1, self.config_filename_2], backup_file_set.list_of_config_files_to_backup)
        self.assertFalse(backup_file_set.list_of_clobbered_files_to_backup)

class TestDetermineUpdateStrategy(unittest.TestCase):
    def setUp(self) -> None: # pylint: disable=too-many-statements
        super().setUp()

        self.version_manifest = StrictMock(IVersionManifest)
        self.local_manifest = StrictMock(ILocalManifest)
        self.asset_register = StrictMock(IAssetRegister)

        self.variant_main = StrictMock(IVariant)
        self.variant_alpha = StrictMock(IVariant)
        self.variant_beta = StrictMock(IVariant)
        self.variant_main.name = PropertyMock(return_value='main')
        self.variant_alpha.name = PropertyMock(return_value='alpha')
        self.variant_beta.name = PropertyMock(return_value='beta')

        self.version_manifest.variants = PropertyMock(return_value={
            self.variant_main.name: self.variant_main,
            self.variant_alpha.name: self.variant_alpha,
            self.variant_beta.name: self.variant_beta
        })

        self.version_number_1 = VersionNumber.parse('1.0.0')
        self.version_number_2 = VersionNumber.parse('2.0.0')
        self.version_number_3 = VersionNumber.parse('3.0.0')

        self.version_1 = StrictMock(IVersion)
        self.version_2 = StrictMock(IVersion)
        self.version_3 = StrictMock(IVersion)
        self.version_1.number = PropertyMock(return_value=self.version_number_1)
        self.version_2.number = PropertyMock(return_value=self.version_number_2)
        self.version_3.number = PropertyMock(return_value=self.version_number_3)

        self.variant_main.versions = PropertyMock(return_value={
            self.version_3.number: self.version_3,
            self.version_1.number: self.version_1,
            self.version_2.number: self.version_2
        })
        self.variant_alpha.versions = PropertyMock(return_value={})
        self.variant_beta.versions = PropertyMock(return_value={})

        self.target_core_file_1 = StrictMock(ICoreFile)
        self.target_core_file_1.filename = PropertyMock(return_value='application.exe')
        self.target_core_file_1.digest = PropertyMock(return_value=MockDigest(FAKE_DIGEST_D))
        self.target_core_file_2 = StrictMock(ICoreFile)
        self.target_core_file_2.filename = PropertyMock(return_value='pear.log')
        self.target_core_file_2.digest = PropertyMock(return_value=MockDigest(FAKE_DIGEST_E))
        self.target_core_file_3 = StrictMock(ICoreFile)
        self.target_core_file_3.filename = PropertyMock(return_value='apple.txt')
        self.target_core_file_3.digest = PropertyMock(return_value=MockDigest(FAKE_DIGEST_A))
        self.target_core_file_4 = StrictMock(ICoreFile)
        self.target_core_file_4.filename = PropertyMock(return_value='app')
        self.target_core_file_4.digest = PropertyMock(return_value=MockDigest(FAKE_DIGEST_F))

        self.version_3.core_files = PropertyMock(return_value={
            self.target_core_file_1.filename: self.target_core_file_1,
            self.target_core_file_2.filename: self.target_core_file_2,
            self.target_core_file_3.filename: self.target_core_file_3,
            self.target_core_file_4.filename: self.target_core_file_4
        })

        self.launch_file_1 = StrictMock(ILaunchFile)
        self.launch_file_1.operating_system = PropertyMock(return_value='windows')
        self.launch_file_1.filename = PropertyMock(return_value='application.exe')
        self.launch_file_2 = StrictMock(ILaunchFile)
        self.launch_file_2.operating_system = PropertyMock(return_value='linux')
        self.launch_file_2.filename = PropertyMock(return_value='app')

        self.version_3.launch_files = PropertyMock(return_value={
            self.launch_file_1.operating_system: self.launch_file_1,
            self.launch_file_2.operating_system: self.launch_file_2
        })

        self.target_config_file_1 = StrictMock(IConfigFile)
        self.target_config_file_1.config_key = PropertyMock(return_value=23)
        self.target_config_file_1.filename = PropertyMock(return_value='config.json')
        self.target_config_file_2 = StrictMock(IConfigFile)
        self.target_config_file_2.config_key = PropertyMock(return_value=12)
        self.target_config_file_2.filename = PropertyMock(return_value='history.txt')

        self.version_3.config_files = PropertyMock(return_value={
            self.target_config_file_1.config_key: self.target_config_file_1,
            self.target_config_file_2.config_key: self.target_config_file_2
        })

        self.local_manifest.variant_name = PropertyMock(return_value='windows')
        self.local_manifest.version_number = PropertyMock(return_value=self.version_number_1)
        self.local_manifest.core_files = PropertyMock(return_value=[
            'apple.txt',
            'banana.dat',
            'pear.log'
        ])
        self.local_config_file_1 = StrictMock(IConfigFile)
        self.local_config_file_1.config_key = PropertyMock(return_value=23)
        self.local_config_file_1.filename = PropertyMock(return_value='config.json')
        self.local_config_file_2 = StrictMock(IConfigFile)
        self.local_config_file_2.config_key = PropertyMock(return_value=8)
        self.local_config_file_2.filename = PropertyMock(return_value='history.log')

        self.local_manifest.config_files = PropertyMock(return_value={
            self.local_config_file_1.config_key: self.local_config_file_1,
            self.local_config_file_2.config_key: self.local_config_file_2
        })

        asset_file_a = StrictMock(IAsset)
        asset_file_a.digest = PropertyMock(return_value=MockDigest(FAKE_DIGEST_A))
        asset_file_d = StrictMock(IAsset)
        asset_file_d.digest = PropertyMock(return_value=MockDigest(FAKE_DIGEST_D))
        asset_file_e = StrictMock(IAsset)
        asset_file_e.digest = PropertyMock(return_value=MockDigest(FAKE_DIGEST_E))
        asset_file_f = StrictMock(IAsset)
        asset_file_f.digest = PropertyMock(return_value=MockDigest(FAKE_DIGEST_F))
        self.asset_register.assets = PropertyMock(return_value={
            asset_file_a.digest: asset_file_a,
            asset_file_d.digest: asset_file_d,
            asset_file_e.digest: asset_file_e,
            asset_file_f.digest: asset_file_f
        })

        self.map_of_file_hashes: dict[str, bytes] = {
            'apple.txt': FAKE_DIGEST_A,
            'banana.dat': FAKE_DIGEST_B,
            'pear.log': FAKE_DIGEST_C
        }
        self.file_hasher = StrictMock(IFileHasher)
        self.file_hasher.hash_file = Mock(side_effect=lambda filename: self.map_of_file_hashes[filename])

        self.map_of_file_stats: dict[str, FileStat] = {
            'application.exe' : FileStat('application.exe', False, False),
            'app': FileStat('app', True, True)
        }
        self.file_tester = StrictMock(IFileTester)
        self.file_tester.stat_file = Mock(side_effect=lambda filename: self.map_of_file_stats[filename])

    @patch('sys.platform', 'windows')
    def test_integration_of_all_functions_on_windows(self) -> None:
        requested_version_number: IVersionNumber | None = None
        requested_variant: str | None = 'main'

        update_strategy: UpdateStrategy = determine_update_strategy(requested_version_number, requested_variant, self.local_manifest, self.version_manifest, self.asset_register, self.file_hasher, self.file_tester)

        self.assertIs(self.local_manifest, update_strategy.local_manifest)
        self.assertIs(self.version_manifest, update_strategy.version_manifest)

        self.assertCountEqual([self.target_core_file_1, self.target_core_file_4], update_strategy.core_file_changes.list_of_new_files_to_acquire)
        self.assertCountEqual([], update_strategy.core_file_changes.list_of_missing_files_to_acquire)
        self.assertCountEqual([self.target_core_file_2], update_strategy.core_file_changes.list_of_changed_files_to_acquire)
        self.assertCountEqual([self.target_core_file_3], update_strategy.core_file_changes.list_of_unchanged_files)
        self.assertCountEqual(['banana.dat'], update_strategy.core_file_changes.list_of_files_that_are_deprecated)

        self.assertCountEqual(['history.log'], update_strategy.config_file_changes.list_of_files_that_are_deprecated)
        self.assertCountEqual([], update_strategy.config_file_changes.list_of_files_to_rename)
        self.assertCountEqual(['config.json'], update_strategy.config_file_changes.list_of_files_to_leave)
        self.assertCountEqual(['history.txt'], update_strategy.config_file_changes.list_of_new_files)

        self.assertCountEqual(['pear.log', 'apple.txt', 'banana.dat'], update_strategy.backup_file_set.list_of_core_files_to_backup)
        self.assertCountEqual(['config.json', 'history.log'], update_strategy.backup_file_set.list_of_config_files_to_backup)
        self.assertCountEqual(['app'], update_strategy.backup_file_set.list_of_clobbered_files_to_backup)

        self.assertIsNotNone(update_strategy.launch_executable)
        if update_strategy.launch_executable:
            self.assertEqual('windows', update_strategy.launch_executable.operating_system)
            self.assertEqual('application.exe', update_strategy.launch_executable.filename)

    @patch('sys.platform', 'linux')
    def test_integration_of_all_functions_on_linux(self) -> None:
        requested_version_number: IVersionNumber | None = None
        requested_variant: str | None = 'main'

        update_strategy: UpdateStrategy = determine_update_strategy(requested_version_number, requested_variant, self.local_manifest, self.version_manifest, self.asset_register, self.file_hasher, self.file_tester)

        self.assertIs(self.local_manifest, update_strategy.local_manifest)
        self.assertIs(self.version_manifest, update_strategy.version_manifest)

        self.assertCountEqual([self.target_core_file_1, self.target_core_file_4], update_strategy.core_file_changes.list_of_new_files_to_acquire)
        self.assertCountEqual([], update_strategy.core_file_changes.list_of_missing_files_to_acquire)
        self.assertCountEqual([self.target_core_file_2], update_strategy.core_file_changes.list_of_changed_files_to_acquire)
        self.assertCountEqual([self.target_core_file_3], update_strategy.core_file_changes.list_of_unchanged_files)
        self.assertCountEqual(['banana.dat'], update_strategy.core_file_changes.list_of_files_that_are_deprecated)

        self.assertCountEqual(['history.log'], update_strategy.config_file_changes.list_of_files_that_are_deprecated)
        self.assertCountEqual([], update_strategy.config_file_changes.list_of_files_to_rename)
        self.assertCountEqual(['config.json'], update_strategy.config_file_changes.list_of_files_to_leave)
        self.assertCountEqual(['history.txt'], update_strategy.config_file_changes.list_of_new_files)

        self.assertCountEqual(['pear.log', 'apple.txt', 'banana.dat'], update_strategy.backup_file_set.list_of_core_files_to_backup)
        self.assertCountEqual(['config.json', 'history.log'], update_strategy.backup_file_set.list_of_config_files_to_backup)
        self.assertCountEqual(['app'], update_strategy.backup_file_set.list_of_clobbered_files_to_backup)

        self.assertIsNotNone(update_strategy.launch_executable)
        if update_strategy.launch_executable:
            self.assertEqual('linux', update_strategy.launch_executable.operating_system)
            self.assertEqual('app', update_strategy.launch_executable.filename)

    @patch('sys.platform', 'osx')
    def test_integration_of_all_functions_on_osx(self) -> None:
        requested_version_number: IVersionNumber | None = None
        requested_variant: str | None = 'main'

        update_strategy: UpdateStrategy = determine_update_strategy(requested_version_number, requested_variant, self.local_manifest, self.version_manifest, self.asset_register, self.file_hasher, self.file_tester)

        self.assertIs(self.local_manifest, update_strategy.local_manifest)
        self.assertIs(self.version_manifest, update_strategy.version_manifest)

        self.assertCountEqual([self.target_core_file_1, self.target_core_file_4], update_strategy.core_file_changes.list_of_new_files_to_acquire)
        self.assertCountEqual([], update_strategy.core_file_changes.list_of_missing_files_to_acquire)
        self.assertCountEqual([self.target_core_file_2], update_strategy.core_file_changes.list_of_changed_files_to_acquire)
        self.assertCountEqual([self.target_core_file_3], update_strategy.core_file_changes.list_of_unchanged_files)
        self.assertCountEqual(['banana.dat'], update_strategy.core_file_changes.list_of_files_that_are_deprecated)

        self.assertCountEqual(['history.log'], update_strategy.config_file_changes.list_of_files_that_are_deprecated)
        self.assertCountEqual([], update_strategy.config_file_changes.list_of_files_to_rename)
        self.assertCountEqual(['config.json'], update_strategy.config_file_changes.list_of_files_to_leave)
        self.assertCountEqual(['history.txt'], update_strategy.config_file_changes.list_of_new_files)

        self.assertCountEqual(['pear.log', 'apple.txt', 'banana.dat'], update_strategy.backup_file_set.list_of_core_files_to_backup)
        self.assertCountEqual(['config.json', 'history.log'], update_strategy.backup_file_set.list_of_config_files_to_backup)
        self.assertCountEqual(['app'], update_strategy.backup_file_set.list_of_clobbered_files_to_backup)

        self.assertIsNone(update_strategy.launch_executable)
