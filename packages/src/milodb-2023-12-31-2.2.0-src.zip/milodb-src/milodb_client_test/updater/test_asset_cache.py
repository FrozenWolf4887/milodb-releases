# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
import hashlib
import unittest
from pathlib import Path
from milodb_client.updater.asset_cache import AssetCache
from milodb_client.updater.i_asset_cache import AssetCacheError
from milodb_client.updater.manifest.common_manifest import IHexDigest
from milodb_client_test.test.fake_file import FakeFile
from milodb_client_test.test.mock_hex_digest import MockDigest
from milodb_client_test.test.temporary_directory import TemporaryDirectory

def sha3_224(data: bytes) -> bytes:
    hasher = hashlib.sha3_224()
    hasher.update(data)
    return hasher.digest()

FAKE_DATA_A: bytes = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit'.encode()
FAKE_DATA_B: bytes = 'sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.'.encode()
FAKE_DATA_C: bytes = 'Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.'.encode()
FAKE_DIGEST_A: IHexDigest = MockDigest(sha3_224(FAKE_DATA_A))
FAKE_DIGEST_B: IHexDigest = MockDigest(sha3_224(FAKE_DATA_B))
FAKE_DIGEST_C: IHexDigest = MockDigest(sha3_224(FAKE_DATA_C))

class TestAssetCache(unittest.TestCase):
    def assert_file_contents(self, path: Path, expected_data: bytes) -> None:
        with path.open('rb') as file:
            data: bytes = file.read()
        self.assertEqual(expected_data, data)

    def test_has_asset_returns_false_when_asset_directory_missing(self) -> None:
        with TemporaryDirectory() as directory:
            asset_cache = AssetCache(directory.joinpath('missing'))
            self.assertFalse(asset_cache.has_asset(FAKE_DIGEST_A))

    def test_has_asset_returns_false_when_asset_missing(self) -> None:
        with TemporaryDirectory() as directory:
            asset_cache = AssetCache(directory)
            self.assertFalse(asset_cache.has_asset(FAKE_DIGEST_A))

    def test_has_asset_returns_true_when_asset_exists(self) -> None:
        with TemporaryDirectory() as directory:
            FakeFile(directory, str(FAKE_DIGEST_A), FAKE_DATA_A)
            asset_cache = AssetCache(directory)
            self.assertTrue(asset_cache.has_asset(FAKE_DIGEST_A))

    def test_try_load_asset_returns_stored_asset(self) -> None:
        with TemporaryDirectory() as directory:
            FakeFile(directory, str(FAKE_DIGEST_A), FAKE_DATA_A)
            asset_cache = AssetCache(directory)
            self.assertEqual(FAKE_DATA_A, asset_cache.try_load_asset(FAKE_DIGEST_A))

    def test_try_load_asset_returns_none_if_asset_missing(self) -> None:
        with TemporaryDirectory() as directory:
            asset_cache = AssetCache(directory)
            self.assertIsNone(asset_cache.try_load_asset(FAKE_DIGEST_A))

    def test_try_load_asset_returns_none_if_stored_asset_is_invalid(self) -> None:
        with TemporaryDirectory() as directory:
            FakeFile(directory, str(FAKE_DIGEST_A), FAKE_DATA_B)
            asset_cache = AssetCache(directory)
            self.assertIsNone(asset_cache.try_load_asset(FAKE_DIGEST_A))

    def test_store_asset_stores_new_asset(self) -> None:
        with TemporaryDirectory() as directory:
            asset_cache = AssetCache(directory)
            asset_cache.store_asset(FAKE_DATA_B)
            self.assert_file_contents(directory.joinpath(str(FAKE_DIGEST_B)), FAKE_DATA_B)

    def test_store_asset_overwrites_existing_asset(self) -> None:
        with TemporaryDirectory() as directory:
            FakeFile(directory, str(FAKE_DIGEST_B), FAKE_DATA_C)
            asset_cache = AssetCache(directory)
            asset_cache.store_asset(FAKE_DATA_B)
            self.assert_file_contents(directory.joinpath(str(FAKE_DIGEST_B)), FAKE_DATA_B)

    def test_store_asset_creates_directory_if_required(self) -> None:
        with TemporaryDirectory() as directory:
            cache_directory: Path = directory.joinpath('hello', 'world')
            asset_cache = AssetCache(cache_directory)
            asset_cache.store_asset(FAKE_DATA_C)
            self.assert_file_contents(cache_directory.joinpath(str(FAKE_DIGEST_C)), FAKE_DATA_C)

    def test_store_raises_error_if_directory_cannot_be_created(self) -> None:
        with TemporaryDirectory() as directory:
            FakeFile(directory, 'hello', 100)
            subdirectory: Path = directory.joinpath('hello', 'world')
            asset_cache = AssetCache(subdirectory)
            with self.assertRaises(AssetCacheError):
                asset_cache.store_asset(FAKE_DATA_C)

    def test_store_raises_error_if_file_cannot_be_created(self) -> None:
        with TemporaryDirectory() as directory:
            directory.joinpath(str(FAKE_DIGEST_A)).mkdir()
            asset_cache = AssetCache(directory)
            with self.assertRaises(AssetCacheError):
                asset_cache.store_asset(FAKE_DATA_A)
