# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
import hashlib
import os
import sys
import unittest
from collections.abc import Sequence
from datetime import datetime
from pathlib import Path
from typing import NoReturn
from unittest.mock import Mock, PropertyMock, call
from mockito import when # type: ignore
from milodb_client.updater.i_asset_cache import AssetCacheError, IAssetCache
from milodb_client.updater.manifest.common_manifest import IHexDigest, IVersionNumber
from milodb_client.updater.manifest.update_directory import IAssetRegister
from milodb_client.updater.manifest.version_manifest import ICoreFile
from milodb_client.updater.manifest.version_number import VersionNumber
from milodb_client.updater.perform_update import PerformUpdateError, backup_files, emplace_files_from_cache, fetch_assets_to_cache, perform_update, remove_files_and_directories, rename_config_files
from milodb_client.updater.update_strategy import BackupFileSet, ConfigFileChanges, CoreFileChanges, FileRename
from milodb_client_test.test.fake_file import FakeFile
from milodb_client_test.test.mock_hex_digest import MockDigest
from milodb_client_test.test.temporary_directory import TemporaryDirectory
from milodb_common.internet.i_uri_scraper_factory import IUriScraperFactory, UriScraperFactoryError
from milodb_common.internet.i_web_scraper import IWebScraper, ScrapeResult
from milodb_common.output.print.i_printer import IPrinter
from milodb_common_test.test.strict_mock import StrictMock

def sha3_224(data: bytes) -> bytes:
    hasher = hashlib.sha3_224()
    hasher.update(data)
    return hasher.digest()

FAKE_DATA_A: bytes = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit'.encode()
FAKE_DATA_B: bytes = 'sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.'.encode()
FAKE_DATA_C: bytes = 'Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.'.encode()
FAKE_DATA_D: bytes = 'Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.'.encode()
FAKE_DATA_E: bytes = 'Excepteur sint occaecat cupidatat non proident'.encode()
FAKE_DATA_F: bytes = 'sunt in culpa qui officia deserunt mollit anim id est laborum.'.encode()
FAKE_DIGEST_A: IHexDigest = MockDigest(sha3_224(FAKE_DATA_A))
FAKE_DIGEST_B: IHexDigest = MockDigest(sha3_224(FAKE_DATA_B))
FAKE_DIGEST_C: IHexDigest = MockDigest(sha3_224(FAKE_DATA_C))
FAKE_DIGEST_D: IHexDigest = MockDigest(sha3_224(FAKE_DATA_E))
FAKE_DIGEST_E: IHexDigest = MockDigest(sha3_224(FAKE_DATA_E))
FAKE_DIGEST_F: IHexDigest = MockDigest(sha3_224(FAKE_DATA_F))
FAKE_URI_A: str = 'Morbi tincidunt augue interdum velit euismod in'
FAKE_URI_B: str = 'Elementum sagittis vitae et leo. Erat pellentesque adipiscing commodo elit at imperdiet dui'
FAKE_URI_C: str = 'Dui vivamus arcu felis bibendum ut tristique'
FAKE_URI_D: str = 'Consectetur a erat nam at lectus urna duis. Lacinia at quis risus sed vulputate odio'
FAKE_URI_E: str = 'Turpis nunc eget lorem dolor sed viverra'
FAKE_URI_F: str = 'Vitae justo eget magna fermentum iaculis'
FAKE_URI_FILEPATH_A: str = 'euismod'
FAKE_URI_FILEPATH_B: str = 'sagittis'
FAKE_URI_FILEPATH_C: str = 'tristique'
FAKE_URI_FILEPATH_D: str = 'lectus'
FAKE_URI_FILEPATH_E: str = 'vulputate'
FAKE_URI_FILEPATH_F: str = 'justo'

_STUB_DATETIME_2020: datetime = datetime(2020, 12, 31, 13, 45, 28)

class TestPerformUpdateFetchAssetsToCache(unittest.TestCase):
    def setUp(self) -> None:
        super().setUp()
        self.asset_register = StrictMock(IAssetRegister)
        self.asset_cache = StrictMock(IAssetCache)
        self.web_scraper_factory = StrictMock(IUriScraperFactory)
        self.web_scraper = StrictMock(IWebScraper)
        self.printer = StrictMock(IPrinter)

        self.core_file_1 = StrictMock(ICoreFile)
        self.core_file_1.digest = PropertyMock(return_value=FAKE_DIGEST_A)
        self.core_file_1.filename = PropertyMock(return_value='mango.txt')
        self.core_file_2 = StrictMock(ICoreFile)
        self.core_file_2.digest = PropertyMock(return_value=FAKE_DIGEST_B)
        self.core_file_2.filename = PropertyMock(return_value='fruit.dat')
        self.core_file_3 = StrictMock(ICoreFile)
        self.core_file_3.digest = PropertyMock(return_value=FAKE_DIGEST_C)
        self.core_file_3.filename = PropertyMock(return_value='apple.exe')
        self.core_file_4 = StrictMock(ICoreFile)
        self.core_file_4.digest = PropertyMock(return_value=FAKE_DIGEST_D)
        self.core_file_4.filename = PropertyMock(return_value='pear.log')

    def test_given_no_file_changes_does_nothing(self) -> None:
        fetch_assets_to_cache([], self.asset_register, self.asset_cache, self.web_scraper_factory, self.printer)

    def test_given_file_not_in_cache_downloads_new_file_to_cache(self) -> None:
        self.printer.writeln = Mock()
        self.asset_cache.has_asset = Mock()
        self.asset_register.resolve_asset_uri = Mock()
        self.web_scraper_factory.get_scraper_and_filepath = Mock()
        self.web_scraper.try_scrape = Mock()
        self.asset_cache.store_asset = Mock()
        when(self.asset_cache).has_asset(self.core_file_1.digest).thenReturn(False)
        when(self.asset_register).resolve_asset_uri(self.core_file_1.digest).thenReturn(FAKE_URI_A)
        when(self.web_scraper_factory).get_scraper_and_filepath(FAKE_URI_A).thenReturn((self.web_scraper, FAKE_URI_FILEPATH_A))
        when(self.web_scraper).try_scrape(FAKE_URI_FILEPATH_A, self.printer.writeln).thenReturn(ScrapeResult(None, FAKE_DATA_A))

        fetch_assets_to_cache([self.core_file_1], self.asset_register, self.asset_cache, self.web_scraper_factory, self.printer)

        self.asset_cache.store_asset.assert_called_once_with(FAKE_DATA_A)

    def test_given_file_in_cache_does_nothing(self) -> None:
        self.printer.writeln = Mock()
        self.asset_cache.has_asset = Mock()
        when(self.asset_cache).has_asset(self.core_file_1.digest).thenReturn(True)

        fetch_assets_to_cache( [
            self.core_file_1
        ], self.asset_register, self.asset_cache, self.web_scraper_factory, self.printer)

    def test_given_some_files_in_cache_and_some_not_then_non_cached_files_are_downloaded_to_cache(self) -> None:
        self.printer.writeln = Mock()
        self.asset_cache.has_asset = Mock()
        self.asset_register.resolve_asset_uri = Mock()
        self.web_scraper_factory.get_scraper_and_filepath = Mock()
        self.web_scraper.try_scrape = Mock()
        self.asset_cache.store_asset = Mock()
        when(self.asset_cache).has_asset(self.core_file_1.digest).thenReturn(False)
        when(self.asset_cache).has_asset(self.core_file_2.digest).thenReturn(True)
        when(self.asset_cache).has_asset(self.core_file_3.digest).thenReturn(False)
        when(self.asset_cache).has_asset(self.core_file_4.digest).thenReturn(True)
        when(self.asset_register).resolve_asset_uri(self.core_file_1.digest).thenReturn(FAKE_URI_A)
        when(self.asset_register).resolve_asset_uri(self.core_file_3.digest).thenReturn(FAKE_URI_C)
        when(self.web_scraper_factory).get_scraper_and_filepath(FAKE_URI_A).thenReturn((self.web_scraper, FAKE_URI_FILEPATH_A))
        when(self.web_scraper_factory).get_scraper_and_filepath(FAKE_URI_C).thenReturn((self.web_scraper, FAKE_URI_FILEPATH_C))
        when(self.web_scraper).try_scrape(FAKE_URI_FILEPATH_A, self.printer.writeln).thenReturn(ScrapeResult(None, FAKE_DATA_A))
        when(self.web_scraper).try_scrape(FAKE_URI_FILEPATH_C, self.printer.writeln).thenReturn(ScrapeResult(None, FAKE_DATA_C))

        fetch_assets_to_cache( [
            self.core_file_1,
            self.core_file_2,
            self.core_file_3,
            self.core_file_4
        ], self.asset_register, self.asset_cache, self.web_scraper_factory, self.printer)

        self.asset_cache.store_asset.assert_has_calls( [
            call(FAKE_DATA_A),
            call(FAKE_DATA_C)
        ])

    def test_raises_error_when_requested_asset_not_in_register(self) -> None:
        self.printer.writeln = Mock()
        self.asset_cache.has_asset = Mock()
        self.asset_register.resolve_asset_uri = Mock()
        when(self.asset_cache).has_asset(self.core_file_1.digest).thenReturn(False)
        when(self.asset_register).resolve_asset_uri(self.core_file_1.digest).thenReturn(None)

        with self.assertRaises(PerformUpdateError) as ex:
            fetch_assets_to_cache([self.core_file_1], self.asset_register, self.asset_cache, self.web_scraper_factory, self.printer)

        self.assertEqual(f"Asset '{self.core_file_1.digest}' for file '{self.core_file_1.filename}' is not in the asset register", str(ex.exception))

    def test_raises_error_when_web_scraper_not_avaiable_from_factory(self) -> None:
        self.printer.writeln = Mock()
        self.asset_cache.has_asset = Mock()
        self.asset_register.resolve_asset_uri = Mock()
        self.web_scraper_factory.get_scraper_and_filepath = Mock()
        when(self.asset_cache).has_asset(self.core_file_1.digest).thenReturn(False)
        when(self.asset_register).resolve_asset_uri(self.core_file_1.digest).thenReturn(FAKE_URI_A)
        when(self.web_scraper_factory).get_scraper_and_filepath(FAKE_URI_A).thenRaise(UriScraperFactoryError('test exception message'))

        with self.assertRaises(PerformUpdateError) as ex:
            fetch_assets_to_cache([self.core_file_1], self.asset_register, self.asset_cache, self.web_scraper_factory, self.printer)

        self.assertEqual(f"Asset '{self.core_file_1.digest}' for file '{self.core_file_1.filename}' with URI '{FAKE_URI_A}' is inaccessible: test exception message", str(ex.exception))

    def test_raises_error_when_web_scraper_cannot_download_file(self) -> None:
        self.printer.writeln = Mock()
        self.asset_cache.has_asset = Mock()
        self.asset_register.resolve_asset_uri = Mock()
        self.web_scraper_factory.get_scraper_and_filepath = Mock()
        self.web_scraper.try_scrape = Mock()
        when(self.asset_cache).has_asset(self.core_file_1.digest).thenReturn(False)
        when(self.asset_register).resolve_asset_uri(self.core_file_1.digest).thenReturn(FAKE_URI_A)
        when(self.web_scraper_factory).get_scraper_and_filepath(FAKE_URI_A).thenReturn((self.web_scraper, FAKE_URI_FILEPATH_A))
        when(self.web_scraper).try_scrape(FAKE_URI_FILEPATH_A, self.printer.writeln).thenReturn(ScrapeResult('error during scrape', bytes()))

        with self.assertRaises(PerformUpdateError) as ex:
            fetch_assets_to_cache([self.core_file_1], self.asset_register, self.asset_cache, self.web_scraper_factory, self.printer)

        self.assertEqual(f"Asset '{self.core_file_1.digest}' for file '{self.core_file_1.filename}' with URI '{FAKE_URI_A}' download error: error during scrape", str(ex.exception))

    def test_raises_error_when_asset_cannot_be_stored_in_cache(self) -> None:
        self.printer.writeln = Mock()
        self.asset_cache.has_asset = Mock()
        self.asset_register.resolve_asset_uri = Mock()
        self.web_scraper_factory.get_scraper_and_filepath = Mock()
        self.web_scraper.try_scrape = Mock()
        self.asset_cache.store_asset = Mock()
        when(self.asset_cache).has_asset(self.core_file_1.digest).thenReturn(False)
        when(self.asset_register).resolve_asset_uri(self.core_file_1.digest).thenReturn(FAKE_URI_A)
        when(self.web_scraper_factory).get_scraper_and_filepath(FAKE_URI_A).thenReturn((self.web_scraper, FAKE_URI_FILEPATH_A))
        when(self.web_scraper).try_scrape(FAKE_URI_FILEPATH_A, self.printer.writeln).thenReturn(ScrapeResult(None, FAKE_DATA_A))
        when(self.asset_cache).store_asset(FAKE_DATA_A).thenRaise(AssetCacheError('issue with asset cache'))

        with self.assertRaises(PerformUpdateError) as ex:
            fetch_assets_to_cache([self.core_file_1], self.asset_register, self.asset_cache, self.web_scraper_factory, self.printer)

        self.assertEqual(f"Asset '{self.core_file_1.digest}' for file '{self.core_file_1.filename}' failed to store in cache: issue with asset cache", str(ex.exception))

class TestPerformUpdateBackupFiles(unittest.TestCase):
    def setUp(self) -> None:
        super().setUp()

        self.timestamp: datetime = _STUB_DATETIME_2020
        self.variant_name: str = 'bar'
        self.version_number = StrictMock(IVersionNumber)
        setattr(self.version_number, '__str__', Mock(return_value='hello-world'))
        self.normal_printer = StrictMock(IPrinter)
        self.normal_printer.writeln = Mock()

    def assert_dir_exists(self, path: Path) -> None:
        self.assertTrue(path.exists(), f"Path '{path}' should be a directory but does not exist")
        self.assertTrue(path.is_dir(), f"Path '{path}' should be a directory")

    def assert_file_exists(self, path: Path, size: int, is_executable: bool=False) -> None:
        """Checks the file exists, is of the correct size, and whether it is executable.
        On Windows, the executable mode is not checked as all files are considered executable.
        """
        self.assertTrue(path.exists(), f"Path '{path}' should be a file but does not exist")
        self.assertTrue(path.is_file(), f"Path '{path}' should be a file")
        self.assertEqual(os.stat(path).st_size, size, f"Path '{path}' file size should be {size} bytes")
        if sys.platform != 'win32':
            self.assertEqual(os.access(path, os.X_OK), is_executable, f"Path '{path}' should {'not ' if not is_executable else ''}be executable")

    def test_creates_backup_directory(self) -> None:
        with TemporaryDirectory() as backup_path:
            expected_path: Path = Path(f'{backup_path}/{_date_text(self.timestamp)}_{self.variant_name}_{self.version_number}')

            backup_files('.', str(backup_path), self.timestamp, self.variant_name, self.version_number, [], self.normal_printer)

            self.assert_dir_exists(expected_path)

        self.normal_printer.writeln.assert_called_once_with(f"Backing up files to '{expected_path}'")

    def test_saves_files(self) -> None:
        with TemporaryDirectory() as root_path:
            file1 = FakeFile(root_path, 'bongo.txt', 821)
            file2 = FakeFile(root_path, 'fruit.exe', 19, is_executable=True)
            file3 = FakeFile(root_path, Path('subdir1', 'something.dat'), 642)
            file4 = FakeFile(root_path, Path('subdir2/subdir3', 'apple.map'), 2031)
            list_of_fake_filenames: list[str] = [file1.filename, file2.filename, file3.filename, file4.filename]

            with TemporaryDirectory() as backup_path:
                expected_path: Path = Path(f'{backup_path}/{_date_text(self.timestamp)}_{self.variant_name}_{self.version_number}')

                backup_files(str(root_path), str(backup_path), self.timestamp, self.variant_name, self.version_number, list_of_fake_filenames, self.normal_printer)

                self.assert_file_exists(Path(expected_path, file1.filename), file1.size)
                self.assert_file_exists(Path(expected_path, file2.filename), file2.size, is_executable=True)
                self.assert_file_exists(Path(expected_path, file3.filename), file3.size)
                self.assert_file_exists(Path(expected_path, file4.filename), file4.size)

    def test_raises_error_when_backup_directory_cannot_be_created(self) -> None:
        with TemporaryDirectory() as root_path:
            file1 = FakeFile(root_path, 'bongo.txt', 821)
            file2 = FakeFile(root_path, 'not-a-directory', 100)
            list_of_fake_filenames: list[str] = [file1.filename]

            with self.assertRaises(PerformUpdateError):
                backup_files(str(root_path), str(file2.filepath), self.timestamp, self.variant_name, self.version_number, list_of_fake_filenames, self.normal_printer)

    def test_skips_files_that_do_not_exist(self) -> None:
        with TemporaryDirectory() as root_path:
            missing_filename = 'bongo.txt'
            list_of_fake_filenames: list[str] = [missing_filename]

            with TemporaryDirectory() as backup_path:
                backup_files(str(root_path), str(backup_path), self.timestamp, self.variant_name, self.version_number, list_of_fake_filenames, self.normal_printer)

                expected_path: Path = Path(f'{backup_path}/{_date_text(self.timestamp)}_{self.variant_name}_{self.version_number}')
                _assert_directory_empty(self, expected_path)

class TestRemoveFilesAndDirectories(unittest.TestCase):
    def setUp(self) -> None:
        super().setUp()
        self.printer = StrictMock(IPrinter)
        self.printer.writeln = Mock()

    def test_removes_single_file_from_directory(self) -> None:
        with TemporaryDirectory() as root_path:
            file_1 = FakeFile(root_path, 'mango.txt', 821)

            remove_files_and_directories(str(root_path), [file_1.filename], self.printer)

            _assert_directory_empty(self, root_path)

    def test_removes_single_file_and_leaves_existing_file_in_directory(self) -> None:
        with TemporaryDirectory() as root_path:
            file_1 = FakeFile(root_path, 'mango.txt', 821)
            file_2 = FakeFile(root_path, 'banana.dat', FAKE_DATA_A)

            remove_files_and_directories(str(root_path), [file_1.filename], self.printer)

            _assert_directory_contains(self, root_path, [file_2.filename], [])
            _assert_file_contents(self, Path(root_path, file_2.filename), FAKE_DATA_A)

    def test_removes_files_from_subdirectories_and_empty_directories(self) -> None:
        with TemporaryDirectory() as root_path:
            file_1 = FakeFile(root_path, 'mango.txt', 821)
            file_2 = FakeFile(root_path, Path('subdir1', 'banana.dat'), 100)
            file_3 = FakeFile(root_path, Path('subdir2', 'subdir3', 'changes.txt'), 100)
            file_4 = FakeFile(root_path, Path('subdir2', 'subdir3', 'details.log'), 100)

            remove_files_and_directories(str(root_path), [file_1.filename, file_2.filename, file_3.filename, file_4.filename], self.printer)

            _assert_directory_contains(self, root_path, [], [])

    def test_removes_files_from_subdirectories_and_leaves_populated_directories(self) -> None:
        with TemporaryDirectory() as root_path:
            file_1 = FakeFile(root_path, 'mango.txt', 821)
            file_2 = FakeFile(root_path, Path('subdir1', 'banana.dat'), 100)
            file_3 = FakeFile(root_path, Path('subdir2', 'subdir3', 'changes.txt'), 100)
            file_4 = FakeFile(root_path, Path('subdir2', 'subdir3', 'details.log'), 100)
            file_5 = FakeFile(root_path, Path('subdir2', 'sticky.pud'), 100)

            remove_files_and_directories(str(root_path), [file_1.filename, file_2.filename, file_3.filename, file_4.filename], self.printer)

            _assert_directory_contains(self, root_path, [file_5.filename], [str(Path(file_5.filename).parent)])

class TestPerformUpdateEmplaceFilesFromCache(unittest.TestCase):
    def setUp(self) -> None:
        self.asset_cache = StrictMock(IAssetCache)
        self.printer = StrictMock(IPrinter)
        self.printer.writeln = Mock()

    def test_empty_list_of_files_does_nothing(self) -> None:
        with TemporaryDirectory() as root_path:
            emplace_files_from_cache(str(root_path), [], self.asset_cache, self.printer)

            _assert_directory_empty(self, root_path)

    def test_files_without_subdirectories_are_emplaced(self) -> None:
        self.asset_cache.try_load_asset = Mock()
        file_1 = StrictMock(ICoreFile)
        file_1.digest = PropertyMock(return_value=FAKE_DIGEST_A)
        file_1.filename = PropertyMock(return_value='mango.txt')
        file_1.exe = PropertyMock(return_value=False)
        file_2 = StrictMock(ICoreFile)
        file_2.digest = PropertyMock(return_value=FAKE_DIGEST_B)
        file_2.filename = PropertyMock(return_value='something.dat')
        file_2.exe = PropertyMock(return_value=False)

        when(self.asset_cache).try_load_asset(file_1.digest).thenReturn(FAKE_DATA_A)
        when(self.asset_cache).try_load_asset(file_2.digest).thenReturn(FAKE_DATA_B)

        with TemporaryDirectory() as root_path:
            emplace_files_from_cache(str(root_path), [
                file_1,
                file_2
            ], self.asset_cache, self.printer)

            _assert_directory_contains(self, root_path, [file_1.filename, file_2.filename], [])
            _assert_file_contents(self, root_path.joinpath(file_1.filename), FAKE_DATA_A)
            _assert_file_contents(self, root_path.joinpath(file_2.filename), FAKE_DATA_B)

    def test_executable_files_are_set_as_executable(self) -> None:
        self.asset_cache.try_load_asset = Mock()
        file_1 = StrictMock(ICoreFile)
        file_1.digest = PropertyMock(return_value=FAKE_DIGEST_A)
        file_1.filename = PropertyMock(return_value='mango.txt')
        file_1.exe = PropertyMock(return_value=False)
        file_2 = StrictMock(ICoreFile)
        file_2.digest = PropertyMock(return_value=FAKE_DIGEST_B)
        file_2.filename = PropertyMock(return_value='something.dat')
        file_2.exe = PropertyMock(return_value=True)

        when(self.asset_cache).try_load_asset(file_1.digest).thenReturn(FAKE_DATA_A)
        when(self.asset_cache).try_load_asset(file_2.digest).thenReturn(FAKE_DATA_B)

        with TemporaryDirectory() as root_path:
            emplace_files_from_cache(str(root_path), [
                file_1,
                file_2
            ], self.asset_cache, self.printer)

            _assert_directory_contains(self, root_path, [file_1.filename, file_2.filename], [])
            _assert_file_contents(self, root_path.joinpath(file_1.filename), FAKE_DATA_A)
            _assert_file_contents(self, root_path.joinpath(file_2.filename), FAKE_DATA_B, True)

    def test_files_with_subdirectories_are_emplaced(self) -> None:
        self.asset_cache.try_load_asset = Mock()
        file_1 = StrictMock(ICoreFile)
        file_1.digest = PropertyMock(return_value=FAKE_DIGEST_A)
        file_1.filename = PropertyMock(return_value='fruit/apple/mango.txt')
        file_1.exe = PropertyMock(return_value=False)
        file_2 = StrictMock(ICoreFile)
        file_2.digest = PropertyMock(return_value=FAKE_DIGEST_B)
        file_2.filename = PropertyMock(return_value='fruit/banana/something.dat')
        file_2.exe = PropertyMock(return_value=False)
        file_3 = StrictMock(ICoreFile)
        file_3.digest = PropertyMock(return_value=FAKE_DIGEST_C)
        file_3.filename = PropertyMock(return_value='pear/changes.txt')
        file_3.exe = PropertyMock(return_value=False)

        when(self.asset_cache).try_load_asset(file_1.digest).thenReturn(FAKE_DATA_A)
        when(self.asset_cache).try_load_asset(file_2.digest).thenReturn(FAKE_DATA_B)
        when(self.asset_cache).try_load_asset(file_3.digest).thenReturn(FAKE_DATA_C)

        with TemporaryDirectory() as root_path:
            emplace_files_from_cache(str(root_path), [
                file_1,
                file_2,
                file_3
            ], self.asset_cache, self.printer)

            _assert_directory_contains(self, root_path, [
                file_1.filename,
                file_2.filename,
                file_3.filename
            ], [
                str(Path(file_1.filename).parent.parent),
                str(Path(file_1.filename).parent),
                str(Path(file_2.filename).parent),
                str(Path(file_3.filename).parent)
            ])
            _assert_file_contents(self, root_path.joinpath(file_1.filename), FAKE_DATA_A)
            _assert_file_contents(self, root_path.joinpath(file_2.filename), FAKE_DATA_B)
            _assert_file_contents(self, root_path.joinpath(file_3.filename), FAKE_DATA_C)

    def test_raises_error_when_asset_cache_has_no_asset(self) -> None:
        self.asset_cache.try_load_asset = Mock()
        file_1 = StrictMock(ICoreFile)
        file_1.digest = PropertyMock(return_value=FAKE_DIGEST_A)
        file_1.filename = PropertyMock(return_value='mango.txt')
        file_1.exe = PropertyMock(return_value=False)

        when(self.asset_cache).try_load_asset(file_1.digest).thenReturn(None)

        with TemporaryDirectory() as root_path:
            with self.assertRaises(PerformUpdateError) as ex:
                emplace_files_from_cache(str(root_path), [file_1], self.asset_cache, self.printer)
            self.assertEqual(f"Asset '{file_1.digest}' for file '{file_1.filename}' is not in the asset cache", str(ex.exception))

    def test_raises_error_when_file_cannot_be_written(self) -> None:
        self.asset_cache.try_load_asset = Mock()
        file_1 = StrictMock(ICoreFile)
        file_1.digest = PropertyMock(return_value=FAKE_DIGEST_A)
        file_1.filename = PropertyMock(return_value='mango.txt')
        file_1.exe = PropertyMock(return_value=False)

        when(self.asset_cache).try_load_asset(file_1.digest).thenReturn(FAKE_DATA_A)

        with TemporaryDirectory() as root_path:
            root_path.joinpath(file_1.filename).mkdir()
            with self.assertRaises(PerformUpdateError) as ex:
                emplace_files_from_cache(str(root_path), [file_1], self.asset_cache, self.printer)
            self.assertTrue(str(ex.exception).startswith(f"Failed to write file '{root_path.joinpath(file_1.filename)}': "))

class TestPerformUpdateRenameConfigFiles(unittest.TestCase):
    def setUp(self) -> None:
        super().setUp()
        self.printer = StrictMock(IPrinter)
        self.printer.writeln = Mock()

    def test_empty_list_of_renames_does_nothing(self) -> None:
        with TemporaryDirectory() as root_path:
            rename_config_files(str(root_path), [], self.printer)

            _assert_directory_empty(self, root_path)

    def test_list_of_files_to_rename(self) -> None:
        with TemporaryDirectory() as root_path:
            file_1 = FakeFile(root_path, 'file1.txt', FAKE_DATA_A)
            file_2 = FakeFile(root_path, 'something.org', FAKE_DATA_B)
            rename_config_files(str(root_path), [
                FileRename(file_1.filename, 'newFilename.dat'),
                FileRename(file_2.filename, 'config.json')
                ], self.printer)

            _assert_directory_contains(self, root_path, ['newFilename.dat', 'config.json'], [])
            _assert_file_contents(self, Path(root_path, 'newFilename.dat'), FAKE_DATA_A)
            _assert_file_contents(self, Path(root_path, 'config.json'), FAKE_DATA_B)

    def test_raises_error_if_file_cannot_be_renamed(self) -> None:
        with TemporaryDirectory() as root_path:
            with self.assertRaises(PerformUpdateError) as ex:
                rename_config_files(str(root_path), [
                    FileRename('missing.log', 'newFilename.dat')
                    ], self.printer)

            self.assertTrue(str(ex.exception).startswith(f"Failed to rename file '{Path(root_path, 'missing.log')}' to '{Path(root_path, 'newFilename.dat')}': "))

class TestPerformUpdateIntegration(unittest.TestCase):
    def test_fully_integrated_update(self) -> None: # pylint: disable=too-many-statements
        core_file_1 = StrictMock(ICoreFile)
        core_file_1.digest = PropertyMock(return_value=FAKE_DIGEST_A)
        core_file_1.filename = PropertyMock(return_value='mango.txt')
        core_file_1.exe = PropertyMock(return_value=False)

        core_file_2 = StrictMock(ICoreFile)
        core_file_2.digest = PropertyMock(return_value=FAKE_DIGEST_B)
        core_file_2.filename = PropertyMock(return_value='logs/changes.txt')
        core_file_2.exe = PropertyMock(return_value=False)

        core_file_3 = StrictMock(ICoreFile)
        core_file_3.digest = PropertyMock(return_value=FAKE_DIGEST_C)
        core_file_3.filename = PropertyMock(return_value='application.exe')
        core_file_3.exe = PropertyMock(return_value=True)

        core_file_4 = StrictMock(ICoreFile)
        core_file_4.digest = PropertyMock(return_value=FAKE_DIGEST_D)
        core_file_4.filename = PropertyMock(return_value='style.css')
        core_file_4.exe = PropertyMock(return_value=False)

        core_file_5 = StrictMock(ICoreFile)
        core_file_5.digest = PropertyMock(return_value=FAKE_DIGEST_E)
        core_file_5.filename = PropertyMock(return_value='deprecated')
        core_file_5.exe = PropertyMock(return_value=False)

        core_file_6 = StrictMock(ICoreFile)
        core_file_6.digest = PropertyMock(return_value=FAKE_DIGEST_F)
        core_file_6.filename = PropertyMock(return_value='database.mdb')
        core_file_6.exe = PropertyMock(return_value=False)

        core_file_changes: CoreFileChanges = CoreFileChanges(
            list_of_new_files_to_acquire = [core_file_1],
            list_of_missing_files_to_acquire = [core_file_2],
            list_of_changed_files_to_acquire = [core_file_3, core_file_6],
            list_of_unchanged_files = [core_file_4],
            list_of_files_that_are_deprecated = [core_file_5.filename]
        )

        time_stamp: datetime = datetime(2000, 1, 1, 12, 0, 0)

        config_file_1: str = 'config.old'
        config_file_2: str = 'settings.dat'
        config_file_2b: str = 'settings.json'
        config_file_3: str = 'variables.json'
        config_file_4: str = 'autoexec.txt'
        config_file_5: str = 'history.txt'

        config_file_changes: ConfigFileChanges = ConfigFileChanges(
            list_of_files_that_are_deprecated = [config_file_1],
            list_of_files_to_rename = [FileRename(config_file_2, config_file_2b)],
            list_of_files_to_leave = [config_file_3, config_file_4],
            list_of_new_files = [config_file_5]
        )
        backup_file_set: BackupFileSet = BackupFileSet(
            list_of_core_files_to_backup = [core_file_3.filename, core_file_6.filename, core_file_4.filename, core_file_5.filename],
            list_of_config_files_to_backup = [config_file_1, config_file_2, config_file_3, config_file_4, config_file_5],
            list_of_clobbered_files_to_backup = [core_file_1.filename]
        )

        current_variant_name: str = 'main-windows-linux'
        current_version_number: IVersionNumber = VersionNumber.parse('1.2.3')

        asset_register = StrictMock(IAssetRegister)
        asset_register.resolve_asset_uri = Mock()
        when(asset_register).resolve_asset_uri(FAKE_DIGEST_B).thenReturn(FAKE_URI_B)
        when(asset_register).resolve_asset_uri(FAKE_DIGEST_C).thenReturn(FAKE_URI_C)

        asset_cache = StrictMock(IAssetCache)
        asset_cache.has_asset = Mock()
        asset_cache.try_load_asset = Mock()
        asset_cache.store_asset = Mock()
        when(asset_cache).has_asset(core_file_1.digest).thenReturn(True)
        when(asset_cache).try_load_asset(core_file_1.digest).thenReturn(FAKE_DATA_A)
        when(asset_cache).has_asset(core_file_2.digest).thenReturn(False)
        when(asset_cache).try_load_asset(core_file_2.digest).thenReturn(FAKE_DATA_B)
        when(asset_cache).store_asset(FAKE_DATA_B)
        when(asset_cache).has_asset(core_file_3.digest).thenReturn(False)
        when(asset_cache).try_load_asset(core_file_3.digest).thenReturn(FAKE_DATA_C)
        when(asset_cache).store_asset(FAKE_DATA_C)
        when(asset_cache).has_asset(core_file_6.digest).thenReturn(True)
        when(asset_cache).try_load_asset(core_file_6.digest).thenReturn(FAKE_DATA_F)

        printer = StrictMock(IPrinter)
        printer.writeln = Mock()

        web_scraper_b = StrictMock(IWebScraper)
        web_scraper_b.try_scrape = Mock()
        when(web_scraper_b).try_scrape(FAKE_URI_FILEPATH_B, printer.writeln).thenReturn(ScrapeResult(None, FAKE_DATA_B))

        web_scraper_c = StrictMock(IWebScraper)
        web_scraper_c.try_scrape = Mock()
        when(web_scraper_c).try_scrape(FAKE_URI_FILEPATH_C, printer.writeln).thenReturn(ScrapeResult(None, FAKE_DATA_C))

        web_scraper_factory = StrictMock(IUriScraperFactory)
        web_scraper_factory.get_scraper_and_filepath = Mock()
        when(web_scraper_factory).get_scraper_and_filepath(FAKE_URI_B).thenReturn((web_scraper_b, FAKE_URI_FILEPATH_B))
        when(web_scraper_factory).get_scraper_and_filepath(FAKE_URI_C).thenReturn((web_scraper_c, FAKE_URI_FILEPATH_C))

        fake_original_core_file_1_data: bytes = FAKE_DATA_A + FAKE_DATA_A
        fake_original_core_file_3_data: bytes = FAKE_DATA_A + FAKE_DATA_B
        fake_original_core_file_4_data: bytes = FAKE_DATA_A + FAKE_DATA_C
        fake_original_core_file_5_data: bytes = FAKE_DATA_A + FAKE_DATA_D
        fake_original_core_file_6_data: bytes = FAKE_DATA_A + FAKE_DATA_E
        fake_original_config_file_1_data: bytes = FAKE_DATA_B + FAKE_DATA_B
        fake_original_config_file_2_data: bytes = FAKE_DATA_B + FAKE_DATA_C
        fake_original_config_file_3_data: bytes = FAKE_DATA_B + FAKE_DATA_D
        fake_original_config_file_4_data: bytes = FAKE_DATA_B + FAKE_DATA_E
        fake_original_config_file_5_data: bytes = FAKE_DATA_B + FAKE_DATA_F

        with TemporaryDirectory() as root_path:
            list_of_expected_files_backed_up: list[FakeFile] = [
                FakeFile(root_path, core_file_1.filename, fake_original_core_file_1_data),
                FakeFile(root_path, core_file_3.filename, fake_original_core_file_3_data),
                FakeFile(root_path, core_file_4.filename, fake_original_core_file_4_data),
                FakeFile(root_path, core_file_5.filename, fake_original_core_file_5_data),
                FakeFile(root_path, core_file_6.filename, fake_original_core_file_6_data),
                FakeFile(root_path, config_file_1, fake_original_config_file_1_data),
                FakeFile(root_path, config_file_2, fake_original_config_file_2_data),
                FakeFile(root_path, config_file_3, fake_original_config_file_3_data),
                FakeFile(root_path, config_file_4, fake_original_config_file_4_data),
                FakeFile(root_path, config_file_5, fake_original_config_file_5_data)
            ]
            unknown_file_1 = FakeFile(root_path, 'unknown-1', 123)
            unknown_file_2 = FakeFile(root_path, 'unknown-2', 234)

            with TemporaryDirectory() as backup_path:
                perform_update(
                    root_directory = str(root_path),
                    backup_directory = str(backup_path),
                    time_stamp = time_stamp,
                    current_variant_name = current_variant_name,
                    current_version_number = current_version_number,
                    core_file_changes = core_file_changes,
                    config_file_changes = config_file_changes,
                    backup_file_set = backup_file_set,
                    asset_register = asset_register,
                    asset_cache = asset_cache,
                    web_scraper_factory = web_scraper_factory,
                    normal_printer = printer)

                backup_subdirectory: Path = backup_path.joinpath(f'{_date_text(time_stamp)}_{current_variant_name}_{current_version_number}')
                _assert_directory_contains(self, backup_subdirectory, list_of_expected_files_backed_up, [])
                for file in list_of_expected_files_backed_up:
                    _assert_file_contents(self, backup_subdirectory.joinpath(file.filename), file.data, file.is_executable)

            _assert_directory_contains(
                self, root_path, [
                    core_file_1, core_file_2, core_file_3, core_file_4, core_file_6,
                    config_file_2b, config_file_3, config_file_4, config_file_5,
                    unknown_file_1, unknown_file_2
                ], ['logs'])
            _assert_file_contents(self, root_path.joinpath(core_file_1.filename), FAKE_DATA_A, core_file_1.exe)
            _assert_file_contents(self, root_path.joinpath(core_file_2.filename), FAKE_DATA_B, core_file_2.exe)
            _assert_file_contents(self, root_path.joinpath(core_file_3.filename), FAKE_DATA_C, core_file_3.exe)
            _assert_file_contents(self, root_path.joinpath(core_file_4.filename), fake_original_core_file_4_data, core_file_4.exe)
            _assert_file_contents(self, root_path.joinpath(core_file_6.filename), FAKE_DATA_F, core_file_6.exe)
            _assert_file_contents(self, root_path.joinpath(config_file_2b), fake_original_config_file_2_data)
            _assert_file_contents(self, root_path.joinpath(config_file_3), fake_original_config_file_3_data)
            _assert_file_contents(self, root_path.joinpath(config_file_4), fake_original_config_file_4_data)
            _assert_file_contents(self, root_path.joinpath(config_file_5), fake_original_config_file_5_data)
            _assert_file_contents(self, root_path.joinpath(unknown_file_1.filename), unknown_file_1.data)
            _assert_file_contents(self, root_path.joinpath(unknown_file_2.filename), unknown_file_2.data)

def _date_text(date: datetime) -> str:
    return f'{date.year:04}-{date.month:02}-{date.day:02}_{date.hour:02}-{date.minute:02}-{date.second:02}'

def _assert_directory_empty(test_case: unittest.TestCase, root_path: str | Path) -> None:
    _assert_directory_contains(test_case, root_path, [], [])

def _assert_directory_contains(test_case: unittest.TestCase, root_path: str | Path, expected_list_of_files: Sequence[str | FakeFile], expected_list_of_dirpaths: list[str]) -> None:
    def fail(ex: OSError) -> NoReturn:
        test_case.fail(f"Error walking directory: {ex}")

    actual_list_of_filepaths: list[str] = []
    actual_list_of_dirpaths: list[str] = []

    dirpath: str
    list_of_dirnames: list[str]
    list_of_filenames: list[str]
    for dirpath, list_of_dirnames, list_of_filenames in os.walk(root_path, onerror=fail):
        actual_list_of_dirpaths.extend( [ str(Path(dirpath, dirname)) for dirname in list_of_dirnames ] )
        actual_list_of_filepaths.extend( [ str(Path(dirpath, filename)) for filename in list_of_filenames ] )

    test_case.assertCountEqual([ str(Path(root_path, file)) if isinstance(file, str) else str(Path(root_path, file.filename)) for file in expected_list_of_files ], actual_list_of_filepaths)
    test_case.assertCountEqual([ str(Path(root_path, dirpath)) for dirpath in expected_list_of_dirpaths ], actual_list_of_dirpaths)

def _assert_file_contents(test_case: unittest.TestCase, path: Path, expected_data: bytes, is_executable: bool=False) -> None:
    """Checks the file contents and executable mode for the file.
    On Windows, the executable mode is not checked as all files are considered executable.
    """
    with path.open('rb') as file:
        data: bytes = file.read()
    test_case.assertEqual(expected_data, data)
    if sys.platform != 'win32':
        test_case.assertEqual(os.access(path, os.X_OK), is_executable, f"Path '{path}' should {'not ' if not is_executable else ''}be executable")
