# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
import os
import pathlib
import stat

class FakeFile:
    def __init__(self, path: pathlib.Path, filename_or_path: str | pathlib.Path, size_or_data: int | bytes, is_executable: bool = False) -> None:
        self._path: pathlib.Path = path.joinpath(filename_or_path)
        self._filename: pathlib.Path = pathlib.Path(filename_or_path)
        self._size: int
        self._data: bytes
        self._is_executable = is_executable

        self._path.parent.mkdir(parents=True, exist_ok=True)

        if isinstance(size_or_data, int):
            self._size = size_or_data
            buffer: bytearray = bytearray(self._size)
            index: int
            for index in range(len(buffer)): # pylint: disable=consider-using-enumerate
                buffer[index] = index % 256
            self._data = bytes(buffer)
            with self._path.open('wb') as file:
                file.write(buffer)
        else:
            self._size = len(size_or_data)
            self._data = size_or_data
            with self._path.open('wb') as file:
                file.write(size_or_data)

        if is_executable:
            stat_result: os.stat_result = os.stat(self._path)
            os.chmod(self._path, stat_result.st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)

    @property
    def filename(self) -> str:
        return str(self._filename)

    @property
    def filepath(self) -> pathlib.Path:
        return self._path

    @property
    def size(self) -> int:
        return self._size

    @property
    def data(self) -> bytes:
        return self._data

    @property
    def is_executable(self) -> bool:
        return self._is_executable
