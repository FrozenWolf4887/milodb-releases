# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
import os
import pathlib
import tempfile
from typing import Any, NoReturn

class TemporaryDirectory:
    def __init__(self) -> None:
        self._path: pathlib.Path | None = None

    def __enter__(self) -> pathlib.Path:
        self._path = pathlib.Path(tempfile.mkdtemp())
        return self._path

    def __exit__(self, exc_type: Any, exc_value: Any, traceback: Any) -> None:
        if not self._path:
            return
        if exc_value is not None:
            print(f"WARNING: Exception detected; showing contents of directory '{self._path}':")
            _display_directory_contents(self._path)
        _delete_directory_recursively(self._path)

def _display_directory_contents(starting_path: pathlib.Path) -> None:
    def warning(ex: OSError) -> None:
        print(f'WARNING: {ex}')

    dirpath: str
    list_of_directories: list[str]
    list_of_filenames: list[str]

    for dirpath, list_of_directories, list_of_filenames in os.walk(starting_path, onerror=warning):
        path: pathlib.Path
        for filename in list_of_filenames:
            path = pathlib.Path(dirpath, filename)
            stats: os.stat_result = path.stat()
            print(f"  {stats.st_size:10,} bytes  {'EXE' if os.access(path, os.X_OK) else '   '} '{path}'")
        for directory_name in list_of_directories:
            path = pathlib.Path(dirpath, directory_name)
            print(f"  {'<DIR>':10}            '{path}'")

def _delete_directory_recursively(starting_path: pathlib.Path) -> None:
    def fail(ex: OSError) -> NoReturn:
        raise ex

    dirpath: str
    list_of_directory_names: list[str]
    list_of_filenames: list[str]

    for dirpath, list_of_directory_names, list_of_filenames in os.walk(starting_path, topdown=False, onerror=fail):
        for filename in list_of_filenames:
            pathlib.Path(dirpath, filename).unlink()
        for directory_name in list_of_directory_names:
            pathlib.Path(dirpath, directory_name).rmdir()
    starting_path.rmdir()
