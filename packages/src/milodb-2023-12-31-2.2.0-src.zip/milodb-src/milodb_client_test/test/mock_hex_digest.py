# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from typing import Any
from milodb_client.updater.manifest.common_manifest import IHexDigest

class MockDigest(IHexDigest):
    def __init__(self, digest_bytes: bytes) -> None:
        self._digest_bytes = digest_bytes

    def __str__(self) -> str:
        return self._digest_bytes.hex()

    def __eq__(self, other: Any) -> bool:
        return isinstance(other, IHexDigest) and self.digest_bytes == other.digest_bytes

    def __ne__(self, other: Any) -> bool:
        return not self.__eq__(other)

    def __hash__(self) -> int:
        return hash(self.digest_bytes)

    @property
    def digest_bytes(self) -> bytes:
        return self._digest_bytes
