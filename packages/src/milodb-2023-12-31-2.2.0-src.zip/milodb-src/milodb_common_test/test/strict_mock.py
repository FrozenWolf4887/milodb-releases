# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from abc import ABC
from typing import Any
from unittest.mock import Mock, NonCallableMock, PropertyMock

class StrictMock(NonCallableMock):
    def __init__(self, interface: type[ABC]) -> None:
        self._mocked_interface: type[ABC] = interface
        super().__init__(spec=interface, name=interface.__name__)

    def __getattr__(self, name: str) -> Any:
        if name in dir():
            return super().__getattr__(name)
        if name in dir(self._mocked_interface):
            raise AssertionError(f"Mock interface '{self._mocked_interface.__name__}' unexpected access to '{name}'")
        raise AttributeError(f"Mock interface '{self._mocked_interface.__name__}' has no attribute '{name}'")

    def __setattr__(self, name: str, value: Any) -> None:
        if name == '_mocked_interface':
            object.__setattr__(self, name, value)
        elif name in dir(self._mocked_interface):
            if isinstance(getattr(self._mocked_interface, name), property):
                assert isinstance(value, PropertyMock), f"Member '{self._mocked_interface.__name__}.{name}' is a property and should be assigned to a PropertyMock"
                setattr(type(self), name, value)
            elif callable(getattr(self._mocked_interface, name)):
                assert (isinstance(value, Mock) or callable(value)) and not isinstance(value, PropertyMock), f"Member '{self._mocked_interface.__name__}.{name}' is a method and should be assigned to a Mock"
                super().__setattr__(name, value)
            else:
                super().__setattr__(name, value)
        else:
            raise AttributeError(f"Mock interface '{self._mocked_interface.__name__}' has no attribute '{name}'")
