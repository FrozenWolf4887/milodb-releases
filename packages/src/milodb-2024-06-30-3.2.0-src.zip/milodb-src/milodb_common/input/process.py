# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from milodb_common.command_framework.argument_stream import ArgumentStream
from milodb_common.command_framework.i_command_constructor import ICommandConstructor
from milodb_common.command_framework.quit_flag import QuitFlag
from milodb_common.parser.expanding_token_stream import ExpandingTokenStream
from milodb_common.variables.i_user_variables import IUserVariables

def process_user_input(user_input: str, command_constructor: ICommandConstructor, user_variables: IUserVariables, quit_flag: QuitFlag) -> None:
    token_stream: ExpandingTokenStream = ExpandingTokenStream(user_input, user_variables)
    argument_stream: ArgumentStream = ArgumentStream(token_stream)
    construct_result: ICommandConstructor.ConstructResult = command_constructor.try_construct(argument_stream)
    if isinstance(construct_result, ICommandConstructor.SuccessfulResult):
        print()
        construct_result.command.execute()
        if not quit_flag:
            print()
    elif isinstance(construct_result, ICommandConstructor.FailedResult):
        print(f'\nError: {construct_result.fault_text}')
        if construct_result.command_name:
            print(f"Command: '{construct_result.command_name}'")
        if construct_result.fault_token:
            print(f"Faulty token: '{construct_result.fault_token.text}' starting at character #{construct_result.fault_token.inner_indices.start}")
        if construct_result.input_text:
            print(f"Input text: {construct_result.input_text}")
        if construct_result.list_of_candidate_text:
            print(f'Expected: {sorted([candidate_text.text for candidate_text in construct_result.list_of_candidate_text])}')
        print()
