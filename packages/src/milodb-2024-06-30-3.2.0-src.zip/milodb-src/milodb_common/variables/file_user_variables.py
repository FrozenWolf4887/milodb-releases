# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
import json
from collections.abc import Mapping, Sequence
from pathlib import Path
from milodb_common.variables.i_user_variables import IPersistentUserVariables, VARIABLE_NAME_PATTERN

class FileUserVariables(IPersistentUserVariables):
    def __init__(self, filepath: Path) -> None:
        self._map_of_name_to_value: dict[str, str] = {}
        self._filepath: Path = filepath
        self._load_was_successful: bool = True

        try:
            with filepath.open(encoding='utf-8') as file:
                json_object: object = json.load(file)
        except FileNotFoundError:
            pass
        except (OSError, json.JSONDecodeError) as ex:
            print(f"Error: Unable to load variables from '{filepath}': {ex}")
            self._load_was_successful = False
        else:
            print(f"Loaded variables from '{filepath}'")
            if isinstance(json_object, Mapping):
                self._map_of_name_to_value = self._validate_config(json_object)
            else:
                print("Error: Root of variables file is not a JSON dictionary")
                self._load_was_successful = False

        if not self._load_was_successful:
            print("CRITICAL: Variables set or changed at runtime will not be saved to prevent corruption")

    def _validate_config(self, some_dictionary: Mapping[object, object]) -> dict[str, str]:
        map_of_name_to_value: dict[str, str] = {}

        index: int
        name: object
        value: object
        for index, (name, value) in enumerate(some_dictionary.items()):
            if isinstance(name, str) and isinstance(value, str):
                map_of_name_to_value[name] = value
            else:
                self._load_was_successful = False
                if not isinstance(name, str):
                    print(f'Error: Variable at index #{index} has a non string name')
                elif not name:
                    print(f'Error: Variable at index #{index} has a blank name')
                elif not VARIABLE_NAME_PATTERN.fullmatch(name):
                    print(f"Error: Variable at index #{index} named '{name}' does not conform to pattern '{VARIABLE_NAME_PATTERN.pattern}'")
                if not isinstance(value, str):
                    print(f"Error: Variable at index #{index} named '{name}' has a value that is not a string")

        return map_of_name_to_value

    def try_retrieve(self, name: str) -> str | None:
        value: object = self._map_of_name_to_value.get(name)
        return value if isinstance(value, str) else None

    def set(self, name: str, value: str) -> None:
        self._map_of_name_to_value[name] = value

    def try_delete(self, name: str) -> bool:
        return self._map_of_name_to_value.pop(name, None) is not None

    def try_save(self) -> IPersistentUserVariables.SaveResult:
        if not self._load_was_successful:
            return IPersistentUserVariables.SaveResult(was_successful=False, warning_message="Variable not saved due to initial loading error", error_message=None)
        try:
            with self._filepath.open("w", encoding='utf-8') as file:
                json.dump(self._map_of_name_to_value, file, indent=4, ensure_ascii=False, sort_keys=True)
        except OSError as ex:
            return IPersistentUserVariables.SaveResult(was_successful=False, warning_message=None, error_message=f"Unable to save variables to '{self._filepath}': {ex}")
        return IPersistentUserVariables.SaveResult(was_successful=True, warning_message=None, error_message=None)

    def get_list_of_names(self) -> Sequence[str]:
        return list(self._map_of_name_to_value)

    def get_list_of_variables(self) -> Sequence[tuple[str, str]]:
        return list(self._map_of_name_to_value.items())
