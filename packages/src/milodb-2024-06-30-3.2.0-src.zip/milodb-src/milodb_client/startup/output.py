# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0

def print_fatal_and_prompt_to_continue(message: str) -> None:
    print(f'FATAL: {message}')
    prompt_to_continue()

def print_warning_and_prompt_to_continue(message: str) -> None:
    print(f'Warning: {message}')
    prompt_to_continue()

def prompt_to_continue() -> None:
    input('Press return to continue...')
