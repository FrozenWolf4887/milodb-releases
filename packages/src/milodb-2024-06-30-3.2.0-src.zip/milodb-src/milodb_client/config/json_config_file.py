# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
import json
from collections.abc import Mapping
from pathlib import Path
from typing import TYPE_CHECKING
from milodb_client.config.framework import IConfig, IConfigGroup
if TYPE_CHECKING:
    from collections.abc import Callable

class JsonConfigFile(IConfig):
    def __init__(self, filepath: Path, schema_root: IConfigGroup) -> None:
        self._filepath: Path = filepath
        self._schema_root: IConfigGroup = schema_root
        self._config_dict: Mapping[object, object] = {}
        next_action: Callable[[], None]

        try:
            with filepath.open(encoding='utf-8') as file:
                self._config_dict = json.load(file)
        except FileNotFoundError:
            next_action = self._generate_config_file
        except (OSError, json.JSONDecodeError) as ex:
            print(f"Error: Unable to load config from '{filepath}': {ex}")
            next_action = self._create_default_config
        else:
            print(f"Loaded config from '{filepath}'")
            next_action = self._validate_config

        next_action()

    @property
    def dictionary(self) -> Mapping[object, object]:
        return self._config_dict

    def _validate_config(self) -> None:
        self._schema_root.validate_existing(self._config_dict)
        self._schema_root.report_redundancy(self._config_dict)
        if self._schema_root.try_add_missing(self._config_dict):
            self._save_config()

    def _save_config(self) -> None:
        was_backup_successful: bool = False
        backup_filepath: Path = self._filepath.with_name(f'{self._filepath.name}.old')
        try:
            with self._filepath.open('rb') as file_in, backup_filepath.open('wb') as file_out:
                file_out.write(file_in.read())
        except FileNotFoundError:
            was_backup_successful = True
        except OSError as ex:
            print(f"Error: Unable to backup config to file '{backup_filepath}': {ex}")
        else:
            was_backup_successful = True

        if was_backup_successful:
            try:
                with self._filepath.open("w", encoding='utf-8') as file:
                    json.dump(self._config_dict, file, indent=4, ensure_ascii=False, sort_keys=True)
            except OSError as ex:
                print(f"Error: Unable to write config to file '{self._filepath}': {ex}")
            else:
                print(f"Saved config file '{self._filepath}'")

    def _generate_config_file(self) -> None:
        self._config_dict = self._schema_root.default_value
        self._save_config()

    def _create_default_config(self) -> None:
        print('Using default config')
        self._config_dict = self._schema_root.default_value
