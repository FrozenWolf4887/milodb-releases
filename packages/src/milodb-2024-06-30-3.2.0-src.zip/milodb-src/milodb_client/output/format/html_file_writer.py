# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
import re
from collections.abc import Sequence
from typing import TYPE_CHECKING
from milodb_client.config.html_config import HtmlConfig
from milodb_client.output.format.i_formatter_factory import IFormatterCreator
from milodb_client.output.format.i_html_file_writer import IHtmlFileWriter
from milodb_client.query.tease_match import TeaseMatch
from milodb_common.output.print.i_printer import IPrinter
if TYPE_CHECKING:
    from milodb_client.output.format.i_formatter import IFormatter

_CSS_KEYWORD_PATTERN: re.Pattern[str] = re.compile(r'\${([a-zA-Z_-]+)}')

class HtmlFileWriter(IHtmlFileWriter):
    def __init__(self, html_config: HtmlConfig, formatter_creator: IFormatterCreator) -> None:
        self._html_config: HtmlConfig = html_config
        self._formatter_creator: IFormatterCreator = formatter_creator

    def try_write_browse_file_of_text_matches(self, list_of_tease_matches: Sequence[TeaseMatch], file_printer: IPrinter, error_printer: IPrinter, icon_data_uri: str) -> bool:
        css: str | None = _try_load_css(self._html_config, error_printer)
        if css:
            _write_file_header(css, icon_data_uri, file_printer)
            formatter: IFormatter = self._formatter_creator.create(file_printer)
            formatter.print_list_of_teases(list_of_tease_matches)
            formatter.print_matching_text_of_list_of_teases(list_of_tease_matches)
            _write_file_footer(file_printer)
            return True
        return False

    def try_write_browse_file_of_all_text(self, list_of_tease_matches: Sequence[TeaseMatch], file_printer: IPrinter, error_printer: IPrinter, icon_data_uri: str) -> bool:
        css: str | None = _try_load_css(self._html_config, error_printer)
        if css:
            _write_file_header(css, icon_data_uri, file_printer)
            formatter: IFormatter = self._formatter_creator.create(file_printer)
            formatter.print_list_of_teases(list_of_tease_matches)
            formatter.print_all_text_of_list_of_teases(list_of_tease_matches)
            _write_file_footer(file_printer)
            return True
        return False

def _try_load_css(html_config: HtmlConfig, error_printer: IPrinter) -> str | None:
    css: str | None = None
    try:
        with html_config.css_file_path.open(encoding='utf-8') as file:
            css = file.read()
    except OSError as ex:
        error_printer.writeln(f"Failed to load CSS file '{html_config.css_file_path}': {ex}")
    if css:
        css = _CSS_KEYWORD_PATTERN.sub(lambda match: _replace_css_keyword(match, html_config, error_printer), css)
    return css

def _replace_css_keyword(match: re.Match[str], html_config: HtmlConfig, error_printer: IPrinter) -> str:
    keyword: str = match.group(1)
    replacement_text: str | None = html_config.try_get_colour_field(keyword)
    if replacement_text is None:
        error_printer.writeln(f"Unknown keyword '{keyword}' in CSS file '{html_config.css_file_path}'")
    return replacement_text or 'black'

def _write_file_header(css: str, icon_data_uri: str, file_printer: IPrinter) -> None:
    file_printer.writeln(
        '<!DOCTYPE html>\n'
        '<html lang="en">\n'
        ' <head>\n'
        '  <meta charset="utf-8">\n'
        '  <title>MiloDB Results</title>\n'
        f'  <link rel="icon" href="{icon_data_uri}">\n'
        '  <style>\n'
        f'{css}'
        '  </style>\n'
        ' </head>\n'
        ' <body>')

def _write_file_footer(file_printer: IPrinter) -> None:
    file_printer.writeln(
        ' </body>\n'
        '</html>')
