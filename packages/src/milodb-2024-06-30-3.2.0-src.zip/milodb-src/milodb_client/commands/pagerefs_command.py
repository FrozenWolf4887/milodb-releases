# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from milodb_common.command_framework.argument_stream import ArgumentStream
from milodb_common.command_framework.candidate_text import CandidateText
from milodb_common.command_framework.i_command import CommandLoaderResult, ICommand
from milodb_common.command_framework.i_help_info import IHelpInfo
from milodb_common.commands import enums
from milodb_common.commands.enums import OnOrOff
from milodb_common.datum.ref_datum import RefDatum
from milodb_common.output.print.i_printer import IPrinter

def load(argument_stream: ArgumentStream, ref_show_pagerefs: RefDatum[bool], normal_printer: IPrinter) -> CommandLoaderResult:
    new_show_pagerefs: OnOrOff | None = argument_stream.pop_optional_enum(OnOrOff)
    if new_show_pagerefs is not None:
        argument_stream.fail_if_not_empty()
        return CommandLoaderResult(Executor(new_show_pagerefs, ref_show_pagerefs, normal_printer), [])
    return CommandLoaderResult(
        ExecutorShowCurrentPagerefs(normal_printer, show_pagerefs=ref_show_pagerefs.get()),
        CandidateText.space_delimited_list(enums.lowercase_names(OnOrOff)))

class ExecutorShowCurrentPagerefs(ICommand):
    def __init__(self, normal_printer: IPrinter, *, show_pagerefs: bool) -> None:
        self._show_pagerefs: bool = show_pagerefs
        self._normal_printer: IPrinter = normal_printer

    def execute(self) -> None:
        self._normal_printer.writeln(f"Current display of pagerefs is '{OnOrOff(self._show_pagerefs).name.lower()}'")
        self._normal_printer.writeln(f"Available options are {enums.lowercase_names(OnOrOff)}")

class Executor(ICommand):
    def __init__(self, new_show_pagerefs: OnOrOff, ref_show_pagerefs: RefDatum[bool], normal_printer: IPrinter) -> None:
        self._new_show_pagerefs: OnOrOff = new_show_pagerefs
        self._ref_show_pagerefs: RefDatum[bool] = ref_show_pagerefs
        self._normal_printer: IPrinter = normal_printer

    def execute(self) -> None:
        self._ref_show_pagerefs.set(self._new_show_pagerefs.value)
        self._normal_printer.writeln(f"Changed display of pagerefs to '{self._new_show_pagerefs.name.lower()}'")

class Help(IHelpInfo):
    def get_one_line_summary(self) -> str:
        return "Sets whether page references are displayed with the text blocks"

    def get_detailed_summary(self) -> str:
        return (
            f"Arguments: [{'|'.join(enums.lowercase_names(OnOrOff))}]\n"
            "Page references can be shown alongside the text blocks if desired. This defaults"
            " to false because the page references can be a distraction.\n"
            "When used without arguments, the current setting is shown.\n"
            "Example:\r"
            "  \tTurn on page references\r"
            "  > \tpagerefs on\r"
            "Example:\r"
            "  \tShow the current setting\r"
            "  > \tpagerefs\n"
            "See also:\r"
            "  \tshow, browse, format, highlight, ellipsis\n"
        )
