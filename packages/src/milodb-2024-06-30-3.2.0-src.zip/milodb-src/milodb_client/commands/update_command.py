# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
import json
import time
import urllib.parse
from collections.abc import Mapping, Sequence
from pathlib import Path
from typing import Optional, TYPE_CHECKING, TypeVar
import prompt_toolkit
from milodb_client.config.config_schema import CONFIG_SCHEMA
from milodb_client.config.update_config import UpdateConfig
from milodb_client.startup.shutdown_action import IShutdownAction, RestartToPerformUpdateAction
from milodb_client.updater.i_file_hasher import IFileHasher
from milodb_client.updater.i_file_tester import IFileTester
from milodb_client.updater.i_temp_directory import ITempDirectory, ITempDirectoryCreator, TempDirectoryError
from milodb_client.updater.manifest.common_manifest import ILaunchFile
from milodb_client.updater.manifest.i_schema_types import IItem, SchemaLoadError
from milodb_client.updater.manifest.local_manifest import ILocalManifest
from milodb_client.updater.manifest.update_directory import IAsset, IAssetRegister, IUpdateDirectory
from milodb_client.updater.manifest.update_directory_schema import UpdateDirectorySchema
from milodb_client.updater.manifest.update_sequence_schema import UpdateSequenceSchema
from milodb_client.updater.manifest.version_manifest import ICoreFile, IVersion, IVersionManifest
from milodb_client.updater.manifest.version_manifest_schema import VersionManifestSchema
from milodb_client.updater.prepare_update import PrepareUpdateError, prepare_update
from milodb_client.updater.update_strategy import BackupFileSet, ConfigFileChanges, CoreFileChanges, FileRename, UpdateStrategy, UpdateStrategyError, determine_update_strategy
from milodb_common.command_framework.argument_stream import ArgumentStream
from milodb_common.command_framework.candidate_text import CandidateText
from milodb_common.command_framework.i_command import CommandLoaderResult, ICommand
from milodb_common.command_framework.i_help_info import IHelpInfo
from milodb_common.command_framework.quit_flag import QuitFlag
from milodb_common.datum.ref_datum import RefDatum
from milodb_common.internet.i_uri_scraper import IUriScraper
from milodb_common.internet.i_uri_scraper_factory import IUriScraperFactory
from milodb_common.output.print.i_printer import IPrinter
from milodb_common.output.unit_file_size import unit_file_size
if TYPE_CHECKING:
    from collections.abc import Callable
    from milodb_common.internet.scrape_result import ScrapeResult

_SchemaT = TypeVar('_SchemaT', bound=IItem)

_CONFIG_HELP_TEXT: str = (
    "Config:\r"
    f"  * \t'{CONFIG_SCHEMA.update.backup_directory.full_path}'\r"
    "    \tDirectory in which to store a backup of the existing application and configuration files"
    f" before performing the update.\r"
    f"  * \t'{CONFIG_SCHEMA.update.update_directory_uri.full_path}'\r"
    f"    \tThe remote server URI hosting the update metadata and assets.\n"
)

def load(argument_stream: ArgumentStream, local_manifest: ILocalManifest | None, update_config: UpdateConfig, file_hasher: IFileHasher, file_tester: IFileTester, temp_directory_creator: ITempDirectoryCreator, uri_scraper_factory: IUriScraperFactory, quit_flag: QuitFlag, ref_shutdown_action: RefDatum[IShutdownAction | None], normal_printer: IPrinter, warning_printer: IPrinter, error_printer: IPrinter) -> CommandLoaderResult:
    def load_default_subcommand() -> CommandLoaderResult:
        return CommandLoaderResult(
            ExecutorDefault(local_manifest, update_config, file_hasher, file_tester, temp_directory_creator, uri_scraper_factory, quit_flag, ref_shutdown_action, normal_printer, warning_printer, error_printer),
            CandidateText.space_delimited_list(map_of_subcommand_to_loader.keys()))

    def load_check_subcommand() -> CommandLoaderResult:
        argument_stream.fail_if_not_empty()
        return CommandLoaderResult(
            ExecutorCheck(local_manifest, update_config, file_hasher, file_tester, temp_directory_creator, uri_scraper_factory, normal_printer, warning_printer, error_printer),
            [])

    map_of_subcommand_to_loader: Mapping[str, Callable[[], CommandLoaderResult]] = {
        'check': load_check_subcommand,
    }

    loader: Callable[[], CommandLoaderResult] | None = argument_stream.pop_optional_dict_value(map_of_subcommand_to_loader)
    if not loader:
        loader = load_default_subcommand
    return loader()

class ExecutorCheck(ICommand):
    def __init__(self, local_manifest: ILocalManifest | None, update_config: UpdateConfig, file_hasher: IFileHasher, file_tester: IFileTester, temp_directory_creator: ITempDirectoryCreator, uri_scraper_factory: IUriScraperFactory, normal_printer: IPrinter, warning_printer: IPrinter, error_printer: IPrinter) -> None:
        self._local_manifest: ILocalManifest | None = local_manifest
        self._update_config: UpdateConfig = update_config
        self._uri_scraper_factory: IUriScraperFactory = uri_scraper_factory
        self._file_hasher: IFileHasher = file_hasher
        self._file_tester: IFileTester = file_tester
        self._temp_directory_creator: ITempDirectoryCreator = temp_directory_creator
        self._normal_printer: IPrinter = normal_printer
        self._warning_printer: IPrinter = warning_printer
        self._error_printer: IPrinter = error_printer

    def execute(self) -> None:
        update_strategy: UpdateStrategy | None = _try_get_update_strategy(
            self._update_config.update_directory_uri,
            self._local_manifest,
            self._file_hasher,
            self._file_tester,
            self._uri_scraper_factory,
            self._normal_printer,
            self._warning_printer,
            self._error_printer)

        if update_strategy:
            self._normal_printer.writeln()
            _is_newer_version_available(update_strategy, self._normal_printer)

class ExecutorDefault(ICommand):
    def __init__(self, local_manifest: ILocalManifest | None, update_config: UpdateConfig, file_hasher: IFileHasher, file_tester: IFileTester, temp_directory_creator: ITempDirectoryCreator, uri_scraper_factory: IUriScraperFactory, quit_flag: QuitFlag, ref_shutdown_action: RefDatum[IShutdownAction | None], normal_printer: IPrinter, warning_printer: IPrinter, error_printer: IPrinter) -> None:
        self._local_manifest: ILocalManifest | None = local_manifest
        self._update_config: UpdateConfig = update_config
        self._file_hasher: IFileHasher = file_hasher
        self._file_tester: IFileTester = file_tester
        self._temp_directory_creator: ITempDirectoryCreator = temp_directory_creator
        self._uri_scraper_factory: IUriScraperFactory = uri_scraper_factory
        self._quit_flag: QuitFlag = quit_flag
        self._ref_shutdown_action: RefDatum[IShutdownAction | None] = ref_shutdown_action
        self._normal_printer: IPrinter = normal_printer
        self._warning_printer: IPrinter = warning_printer
        self._error_printer: IPrinter = error_printer

    def execute(self) -> None:
        update_strategy: UpdateStrategy | None = _try_get_update_strategy(
            self._update_config.update_directory_uri,
            self._local_manifest,
            self._file_hasher,
            self._file_tester,
            self._uri_scraper_factory,
            self._normal_printer,
            self._warning_printer,
            self._error_printer)

        if update_strategy:
            self._normal_printer.writeln()
            if _is_newer_version_available(update_strategy, self._normal_printer):
                self._normal_printer.writeln()
                answer: str = prompt_toolkit.prompt('Would you like to update? [y/n]: ')
                if answer.strip().lower() in {'y', 'yes'}:
                    _prepare_update_and_restart(self._update_config, update_strategy, self._temp_directory_creator, self._uri_scraper_factory, self._quit_flag, self._ref_shutdown_action, self._normal_printer, self._error_printer)

def _prepare_update_and_restart(update_config: UpdateConfig, update_strategy: UpdateStrategy, temp_directory_creator: ITempDirectoryCreator, web_scraper_factory: IUriScraperFactory, quit_flag: QuitFlag, ref_shutdown_action: RefDatum[IShutdownAction | None], normal_printer: IPrinter, error_printer: IPrinter) -> None:
    try:
        temp_directory: ITempDirectory = temp_directory_creator.create()
    except TempDirectoryError as ex:
        normal_printer.writeln()
        error_printer.writeln(f'Failed to prepare update: {ex}')
        return
    normal_printer.writeln(f"Created update temp directory '{temp_directory.path}'")

    try:
        update_sequence: UpdateSequenceSchema = prepare_update(
            update_strategy = update_strategy,
            backup_directory = update_config.backup_directory,
            time_stamp = time.localtime(),
            directory_uri = update_config.update_directory_uri,
            asset_register = update_strategy.asset_register,
            temp_directory = temp_directory,
            uri_scraper_factory = web_scraper_factory,
            normal_printer = normal_printer)
    except PrepareUpdateError as ex:
        normal_printer.writeln()
        error_printer.writeln(f'Failed to determine update sequence: {ex}')
        return

    update_sequence_filepath: Path | None = _try_save_update_sequence(update_sequence, temp_directory, error_printer)
    if update_sequence_filepath:
        normal_printer.writeln(f"Update sequence written to '{update_sequence_filepath}'")
        temp_application_filepath: Path | None = _try_save_copy_of_application(update_strategy, temp_directory, error_printer)
        if temp_application_filepath:
            normal_printer.writeln(f"Temporary application saved to '{temp_application_filepath}'")
            ref_shutdown_action.set(RestartToPerformUpdateAction(temp_application_filepath=temp_application_filepath, update_sequence_filepath=update_sequence_filepath))
            quit_flag.set()

def _try_save_update_sequence(update_sequence: UpdateSequenceSchema, temp_directory: ITempDirectory, error_printer: IPrinter) -> Path | None:
    json_text: str = json.dumps(update_sequence.save(), indent=4, ensure_ascii=False, sort_keys=True)
    filename: Path = Path('update_sequence.json')
    filepath: Path = temp_directory.path_of(filename)
    try:
        temp_directory.store_file(filename, json_text.encode())
    except TempDirectoryError as ex:
        error_printer.writeln(f"Failed to save update sequence to '{filepath}': {ex}")
        return None

    return filepath

def _try_save_copy_of_application(update_strategy: UpdateStrategy, temp_directory: ITempDirectory, error_printer: IPrinter) -> Path | None:
    filename: Path = Path(f'milodb-update-{update_strategy.current_executable_filename.name}')
    filepath: Path = temp_directory.path_of(filename)
    try:
        with Path(update_strategy.current_executable_filename).open('rb') as input_file:
            temp_directory.store_file(filename, input_file.read(), is_executable=True)
    except (TempDirectoryError, OSError) as ex:
        error_printer.writeln(f"Failed to save copy of application '{update_strategy.current_executable_filename}' to '{filepath}': {ex}")
        return None

    return filepath

def _try_get_update_strategy(update_directory_uri: str, local_manifest: ILocalManifest | None, file_hasher: IFileHasher, file_tester: IFileTester, uri_scraper_factory: IUriScraperFactory, normal_printer: IPrinter, warning_printer: IPrinter, error_printer: IPrinter) -> UpdateStrategy | None:
    if not local_manifest:
        error_printer.writeln('Local manifest version information is not available; update impossible')
        return None

    update_data_set: _UpdateDataSet | None = _UpdateDataSet.fetch(update_directory_uri, uri_scraper_factory, normal_printer, error_printer)
    if not update_data_set:
        return None

    try:
        update_strategy: UpdateStrategy = determine_update_strategy(Path(), None, None, local_manifest, update_data_set.version_manifest, update_data_set.update_directory.asset_register, file_hasher, file_tester)
    except UpdateStrategyError as ex:
        error_printer.writeln('Failed to determine update strategy')
        normal_printer.writeln(f'Cause: {ex}')
    else:
        _print_update_strategy(update_strategy, update_data_set.update_directory.asset_register, normal_printer, warning_printer)
        return update_strategy

    return None

class _UpdateDataSet:
    _cached_update_directory: IUpdateDirectory | None = None
    _cached_version_manifest: IVersionManifest | None = None

    def __init__(self, update_directory: IUpdateDirectory, version_manifest: IVersionManifest) -> None:
        self._update_directory: IUpdateDirectory = update_directory
        self._version_manifest: IVersionManifest = version_manifest

    @property
    def update_directory(self) -> IUpdateDirectory:
        return self._update_directory

    @property
    def version_manifest(self) -> IVersionManifest:
        return self._version_manifest

    @staticmethod
    def fetch(update_directory_uri: str, uri_scraper_factory: IUriScraperFactory, normal_printer: IPrinter, error_printer: IPrinter) -> Optional['_UpdateDataSet']: # pylint: disable=consider-alternative-union-syntax
        uri_scraper: IUriScraper
        with uri_scraper_factory.new_pool(normal_printer.writeln) as uri_scraper:
            try:
                if not _UpdateDataSet._cached_update_directory:
                    _UpdateDataSet._cached_update_directory = _fetch_schema_file(UpdateDirectorySchema(), 'update directory', update_directory_uri, uri_scraper, normal_printer)
                else:
                    normal_printer.writeln('Reusing cached update directory')

                if not _UpdateDataSet._cached_version_manifest:
                    version_manifest_uri: str = urllib.parse.urljoin(update_directory_uri, _UpdateDataSet._cached_update_directory.version_manifest_uri)
                    _UpdateDataSet._cached_version_manifest = _fetch_schema_file(VersionManifestSchema(), 'version manifest', version_manifest_uri, uri_scraper, normal_printer)
                else:
                    normal_printer.writeln('Reusing cached version manifest')
            except _FetchSchemaError as ex:
                error_printer.writeln(str(ex))

        if _UpdateDataSet._cached_update_directory and _UpdateDataSet._cached_version_manifest:
            return _UpdateDataSet(_UpdateDataSet._cached_update_directory, _UpdateDataSet._cached_version_manifest)

        return None

class _FetchSchemaError(Exception):
    pass

def _fetch_schema_file(schema: _SchemaT, name_of_schema: str, uri: str, uri_scraper: IUriScraper, printer: IPrinter) -> _SchemaT:
    printer.writeln(f'Fetching {name_of_schema}')

    scrape_result: ScrapeResult = uri_scraper.try_scrape(uri, lambda msg: printer.writeln(f'  {msg}'))
    if scrape_result.error_message:
        msg = f"Failed to fetch {name_of_schema} from '{uri}': {scrape_result.error_message}"
        raise _FetchSchemaError(msg)

    try:
        json_root: object = json.loads(scrape_result.content)
    except json.JSONDecodeError as ex:
        msg = f"{_capitalise(name_of_schema)} '{uri}' could not be parsed as JSON: {ex}"
        raise _FetchSchemaError(msg) from ex

    try:
        schema.load(json_root)
    except SchemaLoadError as ex:
        msg = f"{_capitalise(name_of_schema)} '{uri}' error: {ex}"
        raise _FetchSchemaError(msg) from ex

    return schema

def _capitalise(text: str) -> str:
    return f'{text[0].upper()}{text[1:]}'

def _print_update_strategy(update_strategy: UpdateStrategy, asset_register: IAssetRegister, normal_printer: IPrinter, warning_printer: IPrinter) -> None:
    normal_printer.writeln()
    normal_printer.writeln(f"Current version: {update_strategy.local_manifest.variant_name} / {update_strategy.local_manifest.version_number}")
    normal_printer.writeln(f" Target version: {update_strategy.target_variant.name} / {update_strategy.target_version.number}")
    _print_file_changes(update_strategy.core_file_changes, update_strategy.config_file_changes, asset_register, normal_printer)
    _print_backup_set(update_strategy.backup_file_set, normal_printer)
    _print_launch_executable(update_strategy.launch_executable, normal_printer, warning_printer)
    if update_strategy.list_of_newer_versions:
        _print_change_logs(update_strategy.list_of_newer_versions, normal_printer)

def _print_change_logs(list_of_versions: Sequence[IVersion], printer: IPrinter) -> None:
    printer.writeln()
    printer.writeln('** Change Log **')
    printer.writeln()
    index: int
    version: IVersion
    for index, version in enumerate(sorted(list_of_versions, key=lambda version: version.number)):
        if index > 0:
            printer.writeln()
        printer.writeln(f'{version.number}, {version.date}')
        if version.log:
            printer.writeln()
            printer.writeln(version.log)

def _print_file_changes(core_file_changes: CoreFileChanges, config_file_changes: ConfigFileChanges, asset_register: IAssetRegister, printer: IPrinter) -> None:
    printer.writeln()
    printer.writeln('** File Differences **')
    printer.writeln()
    printer.writeln(f' {"Type":<8}  {"File":<20}  {"Status":<12}  {"Action":<12}  Size')
    printer.writeln('-' * 69)

    core_file: ICoreFile
    for core_file in core_file_changes.list_of_new_files_to_acquire:
        printer.writeln(f' {"Core":<8}  {core_file.filename!s:<20}  {"New":<12}  {"Acquire":<12}  {_asset_file_size(core_file, asset_register):>7}')
    for core_file in core_file_changes.list_of_changed_files_to_acquire:
        printer.writeln(f' {"Core":<8}  {core_file.filename!s:<20}  {"Changed":<12}  {"Acquire":<12}  {_asset_file_size(core_file, asset_register):>7}')
    for core_file in core_file_changes.list_of_missing_files_to_acquire:
        printer.writeln(f' {"Core":<8}  {core_file.filename!s:<20}  {"Missing":<12}  {"Reacquire":<12}  {_asset_file_size(core_file, asset_register):>7}')
    filename: Path
    for filename in core_file_changes.list_of_files_that_are_deprecated:
        printer.writeln(f' {"Core":<8}  {filename!s:<20}  {"Redundant":<12}  Delete')
    for core_file in core_file_changes.list_of_unchanged_files:
        printer.writeln(f' {"Core":<8}  {core_file.filename!s:<20}  {"Unchanged":<12}  None')

    file_rename: FileRename
    for file_rename in config_file_changes.list_of_files_to_rename:
        printer.writeln(f' {"Config":<8}  {file_rename.original_filename!s:<20}  {"Renamed":<12}  Rename to {file_rename.new_filename!s}')
    for filename in config_file_changes.list_of_files_that_are_deprecated:
        printer.writeln(f' {"Config":<8}  {filename!s:<20}  {"Redundant":<12}  Delete')
    for filename in config_file_changes.list_of_files_to_leave:
        printer.writeln(f' {"Config":<8}  {filename!s:<20}  {"Relevant":<12}  None')
    for filename in config_file_changes.list_of_new_files:
        printer.writeln(f' {"Config":<8}  {filename!s:<20}  {"New":<12}  None')

def _print_backup_set(backup_file_set: BackupFileSet, printer: IPrinter) -> None:
    printer.writeln()
    printer.writeln('** Files to Backup **')
    printer.writeln()
    printer.writeln(f' {"Type":<8}  File')
    printer.writeln('-' * 59)

    filename: Path
    for filename in backup_file_set.list_of_core_files_to_backup:
        printer.writeln(f' {"Core":<8}  {filename}')
    for filename in backup_file_set.list_of_config_files_to_backup:
        printer.writeln(f' {"Config":<8}  {filename}')
    for filename in backup_file_set.list_of_clobbered_files_to_backup:
        printer.writeln(f' {"Unknown":<8}  {filename}')

def _print_launch_executable(launch_executable: ILaunchFile | None, normal_printer: IPrinter, warning_printer: IPrinter) -> None:
    normal_printer.writeln()
    if launch_executable:
        normal_printer.writeln(f"Target executable: '{launch_executable.filename}' for OS '{launch_executable.operating_system}'")
    else:
        warning_printer.writeln('There is no main executable for the current operating system in the chosen target variant / version.')
        normal_printer.writeln('Following the update, the application will close and there can be no attempt to start the new application.')
        normal_printer.writeln('This problem can occur if you upgrade to a variant or version that supports a different operating system.')

def _asset_file_size(core_file: ICoreFile, asset_register: IAssetRegister) -> str:
    asset: IAsset | None = asset_register.assets.get(core_file.digest)
    if not asset:
        return 'unknown'
    return unit_file_size(asset.size)

def _is_newer_version_available(update_strategy: UpdateStrategy, normal_printer: IPrinter) -> bool:
    if update_strategy.target_variant.name != update_strategy.local_manifest.variant_name:
        normal_printer.writeln(f"** Switch variant: '{update_strategy.target_variant.name} / {update_strategy.target_version.number}' **")
        return True
    if update_strategy.target_version.number <= update_strategy.local_manifest.version_number:
        normal_printer.writeln(f"You have the current version: {update_strategy.local_manifest.variant_name} / {update_strategy.local_manifest.version_number}")
        return False
    normal_printer.writeln(f"** Upgrade available to: {update_strategy.target_variant.name} / {update_strategy.target_version.number} **")
    return True

class Help(IHelpInfo):
    def get_one_line_summary(self) -> str:
        return "Checks for and applies updates to the software"

    def get_detailed_summary(self) -> str:
        return (
            "Arguments: [check]\n"
            "When used without arguments, it will look for a new version of the software available for"
            " download and installation. It will prompt before actually attempting the update. When"
            " specifying 'check', it will not prompt to perform an update.\n"
            "The metadata related to updating is downloaded once and kept in memory, hence subsequent"
            " calls to update will not repeatedly download the information.\n"
            "Before attempting the update, the existing files are backed up. The assets for new and"
            " updated files are stored in a temporary directory that is automatically removed after a"
            " successful update.\n"
            f"{_CONFIG_HELP_TEXT}"
            "Example:\r"
            "  \tCheck to see if there are updates available\r"
            "  > \tupdate check\r"
            "Example:\r"
            "  \tCheck and prompt to update if an update is available\r"
            "  > \tupdate\r"
        )
