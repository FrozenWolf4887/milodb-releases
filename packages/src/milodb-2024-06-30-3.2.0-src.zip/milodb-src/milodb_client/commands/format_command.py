# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from collections.abc import Sequence
from milodb_client.output.format.i_formatter_factory import IFormatterCreator, IFormatterFactory
from milodb_common.command_framework.argument_stream import ArgumentStream
from milodb_common.command_framework.candidate_text import CandidateText
from milodb_common.command_framework.i_command import CommandLoaderResult, ICommand
from milodb_common.command_framework.i_help_info import IHelpInfo
from milodb_common.datum.ref_datum import RefDatum
from milodb_common.output.print.i_printer import IPrinter

def load(argument_stream: ArgumentStream, ref_formatter_creator: RefDatum[IFormatterCreator], formatter_factory: IFormatterFactory, normal_printer: IPrinter) -> CommandLoaderResult:
    new_formatter_creator: IFormatterCreator | None = argument_stream.pop_optional_dict_value(formatter_factory.map_of_name_to_formatter_creator)
    if new_formatter_creator is not None:
        argument_stream.fail_if_not_empty()
        return CommandLoaderResult(ExecutorChangeFormat(new_formatter_creator, ref_formatter_creator, normal_printer), [])
    return CommandLoaderResult(
        ExecutorPrintCurrentFormat(
            ref_formatter_creator.get().get_name(), formatter_factory.get_list_of_formatter_names(), normal_printer),
            CandidateText.space_delimited_list(formatter_factory.get_list_of_formatter_names()))

class ExecutorPrintCurrentFormat(ICommand):
    def __init__(self, current_formatter_name: str, list_of_formatter_names: Sequence[str], normal_printer: IPrinter) -> None:
        self._current_formatter_name: str = current_formatter_name
        self._list_of_formatter_names: Sequence[str] = list_of_formatter_names
        self._normal_printer: IPrinter = normal_printer

    def execute(self) -> None:
        self._normal_printer.writeln(f"Current format is '{self._current_formatter_name}'")
        self._normal_printer.writeln(f"Available formats are {self._list_of_formatter_names}")

class ExecutorChangeFormat(ICommand):
    def __init__(self, new_formatter_creator: IFormatterCreator, ref_formatter_creator: RefDatum[IFormatterCreator], normal_printer: IPrinter) -> None:
        self._new_formatter_creator: IFormatterCreator = new_formatter_creator
        self._ref_formatter_creator: RefDatum[IFormatterCreator] = ref_formatter_creator
        self._normal_printer: IPrinter = normal_printer

    def execute(self) -> None:
        self._ref_formatter_creator.set(self._new_formatter_creator)
        self._normal_printer.writeln(f"Changed format to '{self._new_formatter_creator.get_name()}'")

class Help(IHelpInfo):
    def __init__(self, list_of_formatter_names: Sequence[str]) -> None:
        self._list_of_formatter_names: Sequence[str] = list_of_formatter_names

    def get_one_line_summary(self) -> str:
        return "Sets the formatting used in the output of commands"

    def get_detailed_summary(self) -> str:
        return (
            f"Arguments: [{'|'.join(self._list_of_formatter_names)}]\n"
            "Changes the output format that is produced by commands such as list, summary,"
            " and show. Some of the formats are more suitable for copy-pasting into another"
            " application that supports that format; 'bbcode' for example is suitable to be"
            " pasted into the Milovana forums.\n"
            "When used without arguments, the current setting is shown.\n"
            "Example:\r"
            "  \tSelect the bbcode output format\r"
            "  > \tformat bbcode\r"
            "Example:\r"
            "  \tShow the current setting\r"
            "  > \tformat\n"
            "See also:\r"
            "  \tlist, summary, show, ellipsis, highlight\n"
        )
