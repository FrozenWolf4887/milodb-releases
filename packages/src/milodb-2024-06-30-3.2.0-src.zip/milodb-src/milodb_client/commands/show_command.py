# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from abc import abstractmethod
from collections.abc import Sequence
from milodb_client.commands.database_support import try_create_list_of_tease_matches_from_ref_ids
from milodb_client.database.tease import Tease
from milodb_client.output.format.i_formatter_factory import IFormatterCreator
from milodb_client.query.tease_match import TeaseMatch
from milodb_common.command_framework.argument_stream import ArgumentStream
from milodb_common.command_framework.i_command import CommandLoaderResult, ICommand
from milodb_common.command_framework.i_help_info import IHelpInfo
from milodb_common.command_framework.ref_id import RefId
from milodb_common.output.print.i_printer import IPrinter

def load(argument_stream: ArgumentStream, list_of_teases: Sequence[Tease], list_of_tease_matches: Sequence[TeaseMatch], formatter_creator: IFormatterCreator, normal_printer: IPrinter, error_printer: IPrinter, *, show_all: bool) -> CommandLoaderResult:
    list_of_ref_ids: Sequence[RefId] = ArgumentStream.pop_list(argument_stream.pop_optional_ref_id)
    if show_all:
        return CommandLoaderResult(
            ShowAllExecutor(list_of_ref_ids, list_of_teases, list_of_tease_matches, formatter_creator, normal_printer, error_printer),
            [])
    return CommandLoaderResult(
        ShowExecutor(list_of_ref_ids, list_of_teases, list_of_tease_matches, formatter_creator, normal_printer, error_printer),
        [])

class _Executor(ICommand):
    def __init__(self, list_of_ref_ids: Sequence[RefId], list_of_teases: Sequence[Tease], list_of_tease_matches: Sequence[TeaseMatch], formatter_creator: IFormatterCreator, normal_printer: IPrinter, error_printer: IPrinter) -> None:
        self._list_of_ref_ids: Sequence[RefId] = list_of_ref_ids
        self._list_of_teases: Sequence[Tease] = list_of_teases
        self._list_of_tease_matches: Sequence[TeaseMatch] = list_of_tease_matches
        self._formatter_creator: IFormatterCreator = formatter_creator
        self._normal_printer: IPrinter = normal_printer
        self._error_printer: IPrinter = error_printer

    def execute(self) -> None:
        list_of_tease_matches: Sequence[TeaseMatch] | None = None
        if self._list_of_ref_ids:
            list_of_tease_matches = try_create_list_of_tease_matches_from_ref_ids(self._list_of_teases, self._list_of_tease_matches, self._list_of_ref_ids, self._error_printer)
        else:
            list_of_tease_matches = self._list_of_tease_matches

        if list_of_tease_matches:
            self._print_from_list(list_of_tease_matches)
        else:
            self._error_printer.writeln("No teases available to show")

    @abstractmethod
    def _print_from_list(self, list_of_tease_matches: Sequence[TeaseMatch]) -> None:
        pass

class ShowExecutor(_Executor):
    def _print_from_list(self, list_of_tease_matches: Sequence[TeaseMatch]) -> None:
        self._formatter_creator.create(self._normal_printer).print_matching_text_of_list_of_teases(list_of_tease_matches)

class ShowAllExecutor(_Executor):
    def _print_from_list(self, list_of_tease_matches: Sequence[TeaseMatch]) -> None:
        self._formatter_creator.create(self._normal_printer).print_all_text_of_list_of_teases(list_of_tease_matches)

class ShowHelp(IHelpInfo):
    def get_one_line_summary(self) -> str:
        return "Prints the summary and text matches for the current results"

    def get_detailed_summary(self) -> str:
        return (
            "Arguments: [list of RefIds]\n"
            "Shows details for each tease including the matching text paragraphs if"
            " appropriate. The formatting used for the details can be controlled with the "
            " format command.\n"
            "When used without arguments, all teases that were found from the last query are"
            " included. When one or more RefIds are specified, only those teases are included.\n"
            "RefIds can be an index into the list of matches such as '3', a teaseId such as"
            " '#38664', or an authorId such as '@43937'.\n"
            "Matching fields and text may be highlighted which can be controlled with the"
            " highlight command.\n"
            "The text paragraphs may be abbreviated with an ellipsis which can be controlled"
            " with the ellipsis command.\n"
            "Example:\r"
            "  \tShow details of the last query results\r"
            "  > \tshow\r"
            "Example:\r"
            "  \tShow details of some matched teases by index\r"
            "  > \tshow 3 7\r"
            "Example:\r"
            "  \tShow details of some specific teaseIds\r"
            "  > \tshow #16830 #1465 #38664\r"
            "Example:\r"
            "  \tShow details of teases from a specific authorId\r"
            "  > \tshow @43937\n"
            "See also:\r"
            "  \tshowall, summary, format, ellipsis, highlight\n"
        )

class ShowAllHelp(IHelpInfo):
    def get_one_line_summary(self) -> str:
        return "Prints the summary and all text paragraphs for the current results"

    def get_detailed_summary(self) -> str:
        return (
            "Arguments: [list of RefIds]\n"
            "Shows details for each tease with all text paragraphs. The formatting used for the"
            " details can be controlled with the format command.\n"
            "When used without arguments, all teases that were found from the last query are"
            " included. When one or more RefIds are specified, only those teases are included.\n"
            "RefIds can be an index into the list of matches such as '3', a teaseId such as"
            " '#38664', or an authorId such as '@43937'.\n"
            "Matching fields and text may be highlighted which can be controlled with the"
            " highlight command.\n"
            "The ellipsis setting is ignored with this command so that all of the text is"
            " shown regardless of whether it matched or not.\n"
            "Example:\r"
            "  \tShow details of the last query results\r"
            "  > \tshowall\r"
            "Example:\r"
            "  \tShow details of some matched teases by index\r"
            "  > \tshowall 3 7\r"
            "Example:\r"
            "  \tShow details of some specific teaseIds\r"
            "  > \tshowall #16830 #1465 #38664\r"
            "Example:\r"
            "  \tShow details of teases from a specific authorId\r"
            "  > \tshowall @43937\n"
            "See also:\r"
            "  \tshow, summary, format, ellipsis, highlight\n"
        )
