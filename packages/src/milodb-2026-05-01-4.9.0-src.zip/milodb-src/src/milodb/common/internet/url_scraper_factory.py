# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from collections.abc import Callable
from typing import override
from milodb.common.internet.i_scraper import IUrlScraperFactory, IUrlScraperPool
from milodb.common.internet.uri_scraper_pool import UrlScraperPool

class UrlScraperFactory(IUrlScraperFactory):
    @override
    def new_pool(self, close_callback: Callable[[str], None] | None = None) -> IUrlScraperPool:
        return UrlScraperPool(close_callback)
