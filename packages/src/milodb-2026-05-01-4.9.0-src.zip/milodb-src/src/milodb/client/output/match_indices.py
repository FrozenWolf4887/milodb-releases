# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from collections.abc import Iterable, Sequence
from typing import Protocol
from milodb.client.database.tease import TeaseProperty
from milodb.client.database.tease_page import TeasePage
from milodb.client.query.field_match import FieldItemMatch, FieldListMatch, FieldPageListMatch, IFieldMatch

class TextCallable(Protocol):
    def __call__(self, text: str, *, is_first_item: bool, is_last_item: bool) -> None:
        ...

def get_list_of_metadata_indices(tease_property: TeaseProperty.Any, list_of_field_matches: Iterable[IFieldMatch]) -> list[IFieldMatch.Indices]:
    list_of_indices: list[IFieldMatch.Indices] = []

    field_match: IFieldMatch
    for field_match in list_of_field_matches:
        if isinstance(field_match, FieldItemMatch) and field_match.tease_property is tease_property:
            list_of_indices.extend(field_match.list_of_indices)

    return list_of_indices

def get_list_of_indexed_metadata_indices(tease_property: TeaseProperty.StrList, index: int, list_of_field_matches: Iterable[IFieldMatch]) -> list[IFieldMatch.Indices]:
    list_of_indices: list[IFieldMatch.Indices] = []

    field_match: IFieldMatch
    for field_match in list_of_field_matches:
        if isinstance(field_match, FieldListMatch) and field_match.tease_property is tease_property and field_match.index_of_block == index:
            list_of_indices.extend(field_match.list_of_indices)

    return list_of_indices

def get_matching_indices_for_page(page: TeasePage, list_of_field_matches: Iterable[IFieldMatch]) -> list[IFieldMatch.Indices]:
    list_of_indices: list[IFieldMatch.Indices] = []

    field_match: IFieldMatch
    for field_match in list_of_field_matches:
        if isinstance(field_match, FieldPageListMatch) and field_match.page is page:
            list_of_indices.extend(field_match.list_of_indices)

    return list_of_indices

def iterate_match_indices(text: str, list_of_indices: Iterable[IFieldMatch.Indices], callback_normal_text: TextCallable, callback_matched_text: TextCallable) -> None:
    if not list_of_indices:
        callback_normal_text(text, is_first_item=True, is_last_item=True)
        return
    if any(match.is_whole_match for match in list_of_indices):
        callback_matched_text(text, is_first_item=True, is_last_item=True)
        return
    list_of_index_match_toggles: Sequence[int] = _create_indices_of_match_toggles(list_of_indices)
    list_of_text_slices: Sequence[str] = _create_text_slices_from_match_toggles(text, list_of_index_match_toggles)
    _callback_with_text_slices(list_of_text_slices, callback_normal_text, callback_matched_text)

def _create_indices_of_match_toggles(list_of_indices: Iterable[IFieldMatch.Indices]) -> list[int]:
    list_of_index_match_toggles: list[int] = []

    current_start_index: int | None = None
    current_end_index: int = 0
    for match in _sort_and_prune_indices(list_of_indices):
        if current_start_index is None:
            list_of_index_match_toggles.append(match.start_index)
            current_start_index = match.start_index
            current_end_index = match.end_index
        elif current_end_index < match.start_index:
            list_of_index_match_toggles.append(current_end_index)
            list_of_index_match_toggles.append(match.start_index)
            current_start_index = match.start_index
            current_end_index = match.end_index
        elif current_end_index < match.end_index:
            current_end_index = match.end_index

    list_of_index_match_toggles.append(current_end_index)

    return list_of_index_match_toggles

def _sort_and_prune_indices(list_of_indices: Iterable[IFieldMatch.Indices]) -> list[IFieldMatch.Indices]:
    list_of_pruned_indices: list[IFieldMatch.Indices] = []

    list_of_sorted_indices: Iterable[IFieldMatch.Indices] = sorted(list_of_indices, key=lambda match: (match.start_index, -match.end_index))

    current_start_index: int | None = None
    match: IFieldMatch.Indices
    for match in list_of_sorted_indices:
        if current_start_index is None or (current_start_index != match.start_index):
            list_of_pruned_indices.append(match)
            current_start_index = match.start_index

    return list_of_pruned_indices

def _create_text_slices_from_match_toggles(text: str, list_of_index_match_toggles: Iterable[int]) -> list[str]:
    list_of_text_slices: list[str] = []

    previous_index_of_toggle: int = 0
    for index_of_toggle in list_of_index_match_toggles:
        list_of_text_slices.append(text[previous_index_of_toggle:index_of_toggle])
        previous_index_of_toggle = index_of_toggle
    if previous_index_of_toggle < len(text):
        list_of_text_slices.append(text[previous_index_of_toggle:])

    return list_of_text_slices

def _callback_with_text_slices(list_of_text_slices: Sequence[str], callback_normal_text: TextCallable, callback_matched_text: TextCallable) -> None:
    is_first_slice: bool = True
    is_currently_in_match: bool = False
    index: int
    text_slice: str
    for index, text_slice in enumerate(list_of_text_slices):
        if text_slice:
            is_last_slice: bool = index == len(list_of_text_slices) - 1
            if is_currently_in_match:
                callback_matched_text(text_slice, is_first_item=is_first_slice, is_last_item=is_last_slice)
            else:
                callback_normal_text(text_slice, is_first_item=is_first_slice, is_last_item=is_last_slice)
            is_first_slice = False
        is_currently_in_match = not is_currently_in_match
