# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import sys
from pathlib import Path
from milodb.common.system import IS_FROZEN_APP

RESOURCE_PATH: Path = (
    Path(str(sys._MEIPASS))/'resources' if IS_FROZEN_APP # type: ignore [attr-defined] # pylint: disable=protected-access # noqa: SLF001 Private member accessed # pyright: ignore[reportAttributeAccessIssue]
    else Path(__file__).parent
)
