# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import tkinter as tk
from typing import TYPE_CHECKING
from milodb.client.view.gui.theme import Style
from milodb.client.view.gui.util import tk_type
from milodb.client.view.gui.widgets.scrollable_canvas import ScrollableCanvas
from milodb.client.view.gui.widgets.styled_frame import StyledFrame
from milodb.common.view.gui.metrics import Size
if TYPE_CHECKING:
    from milodb.client.view.gui.util.widget_id import WidgetId

class ScrollableFrame:
    def __init__(self, master: tk.Misc,
            frame_style: str = Style.Generic.Frame.STYLE_NAME,
            *,
            height: tk_type.ScreenUnits = 0,
            width: tk_type.ScreenUnits = 0,
        ) -> None:
        self._scrollable_canvas: ScrollableCanvas = ScrollableCanvas(master, self._on_canvas_resized)
        self._frame: StyledFrame = StyledFrame(self._scrollable_canvas.canvas, frame_style, height=height, width=width)
        self._window: WidgetId = self._scrollable_canvas.canvas.create_window(0, 0, window=self._frame, anchor=tk.NW)
        self._current_canvas_width: int = 0
        self._current_frame_height: int = 0

        self._frame.bindtags((str(self._frame), str(self._scrollable_canvas.canvas), tk.ALL))
        self._frame.bind('<Configure>', self._on_frame_changed)

    @property
    def top_frame(self) -> StyledFrame:
        return self._scrollable_canvas

    @property
    def content_frame(self) -> StyledFrame:
        return self._frame

    def set_child_bindtags_for_scrolling(self, *, max_depth: int=1) -> None:
        canvas_name: str = str(self._scrollable_canvas.canvas)
        def _set_child_bindtags(widget: tk.Widget, *, depth: int) -> None:
            child_widget: tk.Widget
            for child_widget in widget.children.values():
                child_widget.bindtags((str(child_widget), child_widget.winfo_class(), canvas_name, tk.ALL))
            if depth < max_depth:
                for child_widget in self._frame.children.values():
                    _set_child_bindtags(child_widget, depth=depth+1)
        _set_child_bindtags(self._frame, depth=1)

    def reset_scroll(self) -> None:
        self._scrollable_canvas.reset_scroll()

    def _on_canvas_resized(self, size: Size) -> None:
        if size.width != self._current_canvas_width:
            self._current_canvas_width = size.width
            self._scrollable_canvas.canvas.itemconfigure(self._window, width=size.width)

    def _on_frame_changed(self, _event: object) -> None:
        bbox: tuple[int, int, int, int] | None = self._frame.grid_bbox()
        if bbox is not None:
            height: int = bbox[3]
            if height != self._current_frame_height:
                self._current_frame_height = height
                self._scrollable_canvas.set_content_height(height)
