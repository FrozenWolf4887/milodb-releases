# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import tkinter as tk
import tkinter.font as tkfont
from milodb.client.util.markdown_parser import MarkdownParser, ParagraphType
from milodb.client.view.gui.theme import get_font_of_themed_widget
from milodb.client.view.gui.widgets.styled_text import StyledText

_PLAIN_TAG_NAME: str = 'plain'
_INDENT_TAG_NAME: str = 'indent'
_BULLET_TAG_NAME: str = 'bullet'
_BULLET_TEXT: str = '\u2022 '

class FormatMarkdownIntoText:
    def __init__(self, markdown: str, styled_text: StyledText) -> None:
        self._styled_text: StyledText = styled_text

        self._is_first_paragraph: bool = True
        self._is_first_word: bool = True
        self._paragraph_tag: str = _PLAIN_TAG_NAME

        font: tkfont.Font = get_font_of_themed_widget(styled_text, styled_text)
        bullet_width: int = font.measure(_BULLET_TEXT)
        styled_text.tag_config(_PLAIN_TAG_NAME)
        styled_text.tag_config(_INDENT_TAG_NAME, lmargin1=bullet_width, lmargin2=bullet_width)
        styled_text.tag_config(_BULLET_TAG_NAME, lmargin2=bullet_width)

        MarkdownParser(markdown, self._on_new_paragraph, self._on_word)

    def _on_new_paragraph(self, paragraph_type: ParagraphType) -> None:
        if self._is_first_paragraph:
            self._is_first_paragraph = False
        else:
            self._styled_text.insert(tk.END, '\n')

        self._is_first_word = True

        match paragraph_type:
            case ParagraphType.PLAIN:
                self._paragraph_tag = _PLAIN_TAG_NAME
            case ParagraphType.INDENTED:
                self._paragraph_tag = _INDENT_TAG_NAME
            case ParagraphType.BULLETED:
                self._paragraph_tag = _BULLET_TAG_NAME
                self._styled_text.insert(tk.END, _BULLET_TEXT, self._paragraph_tag)

    def _on_word(self, word: str) -> None:
        if self._is_first_word:
            self._styled_text.insert(tk.END, word, self._paragraph_tag)
            self._is_first_word = False
        else:
            self._styled_text.insert(tk.END, f'{word} ', self._paragraph_tag)
