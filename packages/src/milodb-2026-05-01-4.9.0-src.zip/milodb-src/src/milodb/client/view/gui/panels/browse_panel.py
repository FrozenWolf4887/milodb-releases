# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import tkinter as tk
from collections.abc import Callable, Sequence
from tkinter import ttk
from typing import override
from milodb.client.query.tease_match import TeaseMatch
from milodb.client.view.gui import general_layout
from milodb.client.view.gui.theme import Style
from milodb.client.view.gui.util.datum import IValueDatum
from milodb.client.view.gui.util.datum_tk_binding import DatumBoolTkBinding
from milodb.client.view.gui.widgets.styled_frame import StyledFrame

class BrowsePanel(StyledFrame):
    def __init__(self, master: tk.Misc, list_of_tease_matches: IValueDatum[Sequence[TeaseMatch]], show_only_matching_pages_ref: IValueDatum[bool], abbreviate_text_ref: IValueDatum[bool], show_page_refs_ref: IValueDatum[bool], browse_teases: Callable[[], None]) -> None:
        super().__init__(master, style=Style.Generic.ValueFrame.STYLE_NAME)
        self._list_of_tease_matches: IValueDatum[Sequence[TeaseMatch]] = list_of_tease_matches
        self._show_only_matching_pages_ref: IValueDatum[bool] = show_only_matching_pages_ref
        self._abbreviate_text_ref: IValueDatum[bool] = abbreviate_text_ref
        self._show_page_refs_ref: IValueDatum[bool] = show_page_refs_ref

        ttk.Button(self, text='Generate\nsummary', style=Style.Generic.Button.STYLE_NAME, command=browse_teases).pack(side=tk.LEFT, padx=general_layout.PANEL_PADDING_X)
        options_frame: StyledFrame = StyledFrame(self, style=Style.Generic.ValueFrame.STYLE_NAME)
        show_only_matching_pages: tk.BooleanVar = tk.BooleanVar(master, value=show_only_matching_pages_ref.get())
        abbreviate_text: tk.BooleanVar = tk.BooleanVar(master, value=abbreviate_text_ref.get())
        show_page_refs: tk.BooleanVar = tk.BooleanVar(master, value=show_page_refs_ref.get())
        ttk.Checkbutton(options_frame, text='Only matching pages', variable=show_only_matching_pages, style=Style.OnValueFrame.Checkbox.STYLE_NAME).grid(row=0, column=0, sticky=tk.W, columnspan=2)
        ttk.Checkbutton(options_frame, text='Abbreviate', variable=abbreviate_text, style=Style.OnValueFrame.Checkbox.STYLE_NAME).grid(row=1, column=0, sticky=tk.W)
        ttk.Checkbutton(options_frame, text='Page refs', variable=show_page_refs, style=Style.OnValueFrame.Checkbox.STYLE_NAME).grid(row=1, column=1, sticky=tk.W)
        options_frame.pack(side=tk.LEFT, ipadx=general_layout.PANEL_PADDING_X, padx=(general_layout.PANEL_PADDING_X, 0))

        self._list_of_datum_tk_bindings: tuple[DatumBoolTkBinding, ...] = (
            DatumBoolTkBinding(self._show_only_matching_pages_ref, show_only_matching_pages),
            DatumBoolTkBinding(self._abbreviate_text_ref, abbreviate_text),
            DatumBoolTkBinding(self._show_page_refs_ref, show_page_refs),
        )

    @override
    def destroy(self) -> None:
        binding: DatumBoolTkBinding
        for binding in self._list_of_datum_tk_bindings:
            binding.destroy()
        super().destroy()
