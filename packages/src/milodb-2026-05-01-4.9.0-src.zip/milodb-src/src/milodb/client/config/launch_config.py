# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from typing import override
from milodb.client.config.config_schema import CONFIG_SCHEMA
from milodb.common.config.framework import IConfig
from milodb.common.config.i_launch_config import ILaunchConfig, LaunchOption
from milodb.common.system import PLATFORM, Platform

class SummaryLaunchConfig(ILaunchConfig):
    def __init__(self, config: IConfig) -> None:
        self._config = config

    @property
    @override
    def launch_option(self) -> LaunchOption:
        launch_option: LaunchOption
        match PLATFORM:
            case Platform.WINDOWS:
                launch_option = CONFIG_SCHEMA.launch.summary.windows.launch_option.fetch_enum_value_or_default(self._config)
            case Platform.LINUX | Platform.MACOS:
                launch_option = CONFIG_SCHEMA.launch.summary.linux.launch_option.fetch_enum_value_or_default(self._config)
            case Platform.UNKNOWN:
                launch_option = LaunchOption.DEFAULT
        return launch_option

    @property
    @override
    def custom_launch_command(self) -> str:
        launch_command: str
        match PLATFORM:
            case Platform.WINDOWS:
                launch_command = CONFIG_SCHEMA.launch.summary.windows.custom_command.fetch_value_or_default(self._config)
            case Platform.LINUX | Platform.MACOS:
                launch_command = CONFIG_SCHEMA.launch.summary.linux.custom_command.fetch_value_or_default(self._config)
            case Platform.UNKNOWN:
                launch_command = ''
        return launch_command

    @property
    @override
    def custom_launch_as_shell(self) -> bool:
        return True

class OpenLaunchConfig(ILaunchConfig):
    def __init__(self, config: IConfig) -> None:
        self._config = config

    @property
    @override
    def launch_option(self) -> LaunchOption:
        launch_option: LaunchOption
        match PLATFORM:
            case Platform.WINDOWS:
                launch_option = CONFIG_SCHEMA.launch.open.windows.launch_option.fetch_enum_value_or_default(self._config)
            case Platform.LINUX | Platform.MACOS:
                launch_option = CONFIG_SCHEMA.launch.open.linux.launch_option.fetch_enum_value_or_default(self._config)
            case Platform.UNKNOWN:
                launch_option = LaunchOption.DEFAULT
        return launch_option

    @property
    @override
    def custom_launch_command(self) -> str:
        launch_command: str
        match PLATFORM:
            case Platform.WINDOWS:
                launch_command = CONFIG_SCHEMA.launch.open.windows.custom_command.fetch_value_or_default(self._config)
            case Platform.LINUX | Platform.MACOS:
                launch_command = CONFIG_SCHEMA.launch.open.linux.custom_command.fetch_value_or_default(self._config)
            case Platform.UNKNOWN:
                launch_command = ''
        return launch_command

    @property
    @override
    def custom_launch_as_shell(self) -> bool:
        return True
