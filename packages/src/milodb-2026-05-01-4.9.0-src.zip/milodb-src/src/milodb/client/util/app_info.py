# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from collections.abc import Sequence
from typing import TYPE_CHECKING
from milodb.client.database.database import try_get_newest_tease_date, try_get_oldest_tease_date
from milodb.client.database.tease import Tease
if TYPE_CHECKING:
    import datetime

APPLICATION_NAME: str = 'MiloDB'
AUTHOR_NAME: str = 'FrozenWolf'
AUTHOR_ID: int = 102_759
FORUM_THREAD_URL: str = 'https://milovana.com/forum/viewtopic.php?t=25177'
SOFTWARE_LICENCE_URL: str = 'https://creativecommons.org/publicdomain/zero/1.0/'
SOFTWARE_LICENCE_TEXT: str = (
    'MiloDB by FrozenWolf is marked with CC0 1.0.\n'
    f'To view a copy of this license, visit {SOFTWARE_LICENCE_URL}'
)
TERMS_OF_SERVICE_URL: str = 'https://milovana.com/pages/tos.php'
TEASE_COPYRIGHT_TEXT: str = (
    'The ownership/copyright of each tease remains with the respective author according to'
    f' the Milovana.com terms of service, {TERMS_OF_SERVICE_URL}'
)

def get_database_info_one_line(list_of_teases: Sequence[Tease]) -> str:
    oldest_tease_date: datetime.date | None = try_get_oldest_tease_date(list_of_teases)
    newest_tease_date: datetime.date | None = try_get_newest_tease_date(list_of_teases)
    return f"{len(list_of_teases):,} teases loaded ranging from {oldest_tease_date or 'None'} to {newest_tease_date or 'None'}"
