# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from collections.abc import Callable
from enum import Enum

class ParagraphType(Enum):
    PLAIN = 0
    INDENTED = 1
    BULLETED = 2

class MarkdownParser:
    def __init__(self, text: str, on_new_paragraph: Callable[[ParagraphType], None], on_word: Callable[[str], None]) -> None:
        self._on_new_paragraph: Callable[[ParagraphType], None] = on_new_paragraph
        self._on_word: Callable[[str], None] = on_word

        self._previous_paragraph_type: ParagraphType | None = None
        self._current_paragraph_type: ParagraphType = ParagraphType.PLAIN

        line: str
        for line in text.splitlines():
            self._previous_paragraph_type = None
            self._parse_line(line)

    def _parse_line(self, line: str) -> None:
        list_of_words: list[str] = line.rstrip().split()
        if not list_of_words:
            self._current_paragraph_type = ParagraphType.PLAIN
            return

        discard_word: bool = False
        index: int
        word: str
        for index, word in enumerate(list_of_words):
            if index == 0:
                if word == '*':
                    self._current_paragraph_type = ParagraphType.BULLETED
                    discard_word = True
                else:
                    match self._current_paragraph_type:
                        case ParagraphType.PLAIN:
                            pass
                        case ParagraphType.INDENTED:
                            pass
                        case ParagraphType.BULLETED:
                            self._current_paragraph_type = ParagraphType.INDENTED
            if discard_word:
                discard_word = False
            else:
                self._emit_word(word)

    def _emit_word(self, word: str) -> None:
        if self._current_paragraph_type != self._previous_paragraph_type:
            self._previous_paragraph_type = self._current_paragraph_type
            self._on_new_paragraph(self._current_paragraph_type)
        self._on_word(_strip_escapes(word))

def _strip_escapes(text: str) -> str:
    stripped_text: str = ''
    is_escaping: bool = False

    char: str
    for char in text:
        if is_escaping:
            is_escaping = False
            stripped_text += char
        elif char == '\\':
            is_escaping = True
        else:
            stripped_text += char

    return stripped_text
