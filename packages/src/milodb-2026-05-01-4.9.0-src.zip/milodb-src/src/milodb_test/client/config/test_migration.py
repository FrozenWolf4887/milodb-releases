# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import unittest
from typing import override
from unittest.mock import Mock, call, patch
from milodb.client.config.migration import try_migrate_config
from milodb.common.config.migration_result import ConfigMigrationResult
from milodb.common.output.print.i_printer import IPrinter
from milodb.common.system import PLATFORM, Platform
from milodb_test.common.test.strict_mock import InterfaceMock

class TestMigration(unittest.TestCase):
    @override
    def setUp(self) -> None:
        self._normal_printer = InterfaceMock(IPrinter)
        self._error_printer = InterfaceMock(IPrinter)

    def test_missing_version_reports_error(self) -> None:
        config: dict[object, object] = {}
        self._error_printer.writeln = Mock()
        result: ConfigMigrationResult = try_migrate_config(config, self._normal_printer, self._error_printer)
        self.assertIs(result, ConfigMigrationResult.FAILED)
        self._error_printer.writeln.assert_called_once_with("Unable to identify current config version because key 'configVersion' is missing or not text")

    def test_unknown_version_reports_error(self) -> None:
        config: dict[object, object] = {
            'configVersion': 'foo',
        }
        self._error_printer.writeln = Mock()
        result: ConfigMigrationResult = try_migrate_config(config, self._normal_printer, self._error_printer)
        self.assertIs(result, ConfigMigrationResult.FAILED)
        self._error_printer.writeln.assert_called_once_with("Unknown config file version 'foo' specified by key 'configVersion'")

    @patch('milodb.common.system.PLATFORM', Platform.WINDOWS)
    def test_version_1_migrates_to_version_4_windows(self) -> None:
        self._test_version_1_migrates_to_version_4()

    @patch('milodb.common.system.PLATFORM', Platform.LINUX)
    def test_version_1_migrates_to_version_4_linux(self) -> None:
        self._test_version_1_migrates_to_version_4()

    def _test_version_1_migrates_to_version_4(self) -> None:
        config: dict[object, object] = {
            "configVersion": "1",
            "commands": {
                "browse": {
                    "customLaunchCommand": "banana",
                    "launchOption": "none",
                },
                "open": {
                    "customLaunchCommand": "apple",
                    "launchOption": "custom",
                },
            },
            "format": {
                "html": {
                    "css": {
                        "colour": {
                            "listTableBackground": "#933737",
                            "pageBackground": "#F2CFCF",
                            "summaryTableBackground": "#933737",
                            "textTableBackground": "#933737",
                        },
                        "filePath": "default.css",
                    },
                },
            },
        }
        expected_config: dict[object, object] = {
            "configVersion": "4",
            "launch": {
                "summary": {
                    _platform_name(): {
                        "customCommand": "banana",
                        "launchOption": "none",
                    },
                },
                "open": {
                    _platform_name(): {
                        "customCommand": "apple",
                        "launchOption": "custom",
                    },
                },
            },
            "format": {
                "html": {
                    "cssFilePath": "default-light.css",
                },
            },
        }
        self._normal_printer.writeln = Mock()
        result: ConfigMigrationResult = try_migrate_config(config, self._normal_printer, self._error_printer)
        self.assertIs(result, ConfigMigrationResult.SUCCESSFUL)
        self.assertListEqual(self._normal_printer.writeln.mock_calls, [
            call('* Migrating config from v1 to v2'),
            call(f"- Created 'commands/browse/{_platform_name()}'"),
            call(f"- Shifted 'commands/browse/customLaunchCommand' to 'commands/browse/{_platform_name()}/customLaunchCommand'"),
            call(f"- Shifted 'commands/browse/launchOption' to 'commands/browse/{_platform_name()}/launchOption'"),
            call(f"- Created 'commands/open/{_platform_name()}'"),
            call(f"- Shifted 'commands/open/customLaunchCommand' to 'commands/open/{_platform_name()}/customLaunchCommand'"),
            call(f"- Shifted 'commands/open/launchOption' to 'commands/open/{_platform_name()}/launchOption'"),
            call("- Changed 'configVersion'"),
            call('* Migrating config from v2 to v3'),
            call("- Shifted 'format/html/css/filePath' to 'format/html/cssFilePath'"),
            call("- Updated 'format/html/cssFilePath'"),
            call("- Removed 'format/html/css'"),
            call("- Changed 'configVersion'"),
            call("* Migrating config from v3 to v4"),
            call(f"- Shifted 'commands/browse/{_platform_name()}/customLaunchCommand' to 'commands/browse/{_platform_name()}/customCommand'"),
            call("- Shifted 'commands/browse' to 'commands/summary'"),
            call(f"- Shifted 'commands/open/{_platform_name()}/customLaunchCommand' to 'commands/open/{_platform_name()}/customCommand'"),
            call("- Shifted 'commands' to 'launch'"),
            call("- Changed 'configVersion'"),
        ])
        self.assertDictEqual(expected_config, config)

    @patch('milodb.common.system.PLATFORM', Platform.WINDOWS)
    def test_version_2_migrates_to_version_4_windows(self) -> None:
        self._test_version_2_migrates_to_version_4()

    @patch('milodb.common.system.PLATFORM', Platform.LINUX)
    def test_version_2_migrates_to_version_4_linux(self) -> None:
        self._test_version_2_migrates_to_version_4()

    def _test_version_2_migrates_to_version_4(self) -> None:
        config: dict[object, object] = {
            "configVersion": "2",
            "commands": {
                "browse": {
                    _platform_name(): {
                        "customLaunchCommand": "banana",
                        "launchOption": "none",
                    },
                },
                "open": {
                    _platform_name(): {
                        "customLaunchCommand": "apple",
                        "launchOption": "custom",
                    },
                },
            },
            "format": {
                "html": {
                    "css": {
                        "colour": {
                            "listTableBackground": "#933737",
                            "pageBackground": "#F2CFCF",
                            "summaryTableBackground": "#933737",
                            "textTableBackground": "#933737",
                        },
                        "filePath": "default.css",
                    },
                },
            },
        }
        expected_config: dict[object, object] = {
            "configVersion": "4",
            "launch": {
                "summary": {
                    _platform_name(): {
                        "customCommand": "banana",
                        "launchOption": "none",
                    },
                },
                "open": {
                    _platform_name(): {
                        "customCommand": "apple",
                        "launchOption": "custom",
                    },
                },
            },
            "format": {
                "html": {
                    "cssFilePath": "default-light.css",
                },
            },
        }
        self._normal_printer.writeln = Mock()
        result: ConfigMigrationResult = try_migrate_config(config, self._normal_printer, self._error_printer)
        self.assertIs(result, ConfigMigrationResult.SUCCESSFUL)
        self.assertListEqual(self._normal_printer.writeln.mock_calls, [
            call('* Migrating config from v2 to v3'),
            call("- Shifted 'format/html/css/filePath' to 'format/html/cssFilePath'"),
            call("- Updated 'format/html/cssFilePath'"),
            call("- Removed 'format/html/css'"),
            call("- Changed 'configVersion'"),
            call("* Migrating config from v3 to v4"),
            call(f"- Shifted 'commands/browse/{_platform_name()}/customLaunchCommand' to 'commands/browse/{_platform_name()}/customCommand'"),
            call("- Shifted 'commands/browse' to 'commands/summary'"),
            call(f"- Shifted 'commands/open/{_platform_name()}/customLaunchCommand' to 'commands/open/{_platform_name()}/customCommand'"),
            call("- Shifted 'commands' to 'launch'"),
            call("- Changed 'configVersion'"),
        ])
        self.assertDictEqual(expected_config, config)

    @patch('milodb.common.system.PLATFORM', Platform.WINDOWS)
    def test_version_3_migrates_to_version_4_windows(self) -> None:
        self._test_version_2_migrates_to_version_4()

    @patch('milodb.common.system.PLATFORM', Platform.LINUX)
    def test_version_3_migrates_to_version_4_linux(self) -> None:
        self._test_version_3_migrates_to_version_4()

    def _test_version_3_migrates_to_version_4(self) -> None:
        config: dict[object, object] = {
            "configVersion": "3",
            "commands": {
                "browse": {
                    _platform_name(): {
                        "customLaunchCommand": "banana",
                        "launchOption": "none",
                    },
                },
                "open": {
                    _platform_name(): {
                        "customLaunchCommand": "apple",
                        "launchOption": "custom",
                    },
                },
            },
        }
        expected_config: dict[object, object] = {
            "configVersion": "4",
            "launch": {
                "summary": {
                    _platform_name(): {
                        "customCommand": "banana",
                        "launchOption": "none",
                    },
                },
                "open": {
                    _platform_name(): {
                        "customCommand": "apple",
                        "launchOption": "custom",
                    },
                },
            },
        }
        self._normal_printer.writeln = Mock()
        result: ConfigMigrationResult = try_migrate_config(config, self._normal_printer, self._error_printer)
        self.assertIs(result, ConfigMigrationResult.SUCCESSFUL)
        self.assertListEqual(self._normal_printer.writeln.mock_calls, [
            call("* Migrating config from v3 to v4"),
            call(f"- Shifted 'commands/browse/{_platform_name()}/customLaunchCommand' to 'commands/browse/{_platform_name()}/customCommand'"),
            call("- Shifted 'commands/browse' to 'commands/summary'"),
            call(f"- Shifted 'commands/open/{_platform_name()}/customLaunchCommand' to 'commands/open/{_platform_name()}/customCommand'"),
            call("- Shifted 'commands' to 'launch'"),
            call("- Changed 'configVersion'"),
        ])
        self.assertDictEqual(expected_config, config)

def _platform_name() -> str:
    match PLATFORM:
        case Platform.WINDOWS:
            return 'windows'
        case Platform.LINUX | Platform.MACOS:
            return 'linux'
        case Platform.UNKNOWN:
            return 'unknown'
