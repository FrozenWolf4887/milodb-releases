# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import unittest
from unittest.mock import Mock, call
from milodb.client.util.markdown_parser import MarkdownParser, ParagraphType

class TestMarkdownParser(unittest.TestCase):
    @staticmethod
    def test_empty_document_produces_no_callbacks() -> None:
        on_new_paragraph = Mock()
        on_word = Mock()
        MarkdownParser('', on_new_paragraph, on_word)
        on_new_paragraph.assert_not_called()
        on_word.assert_not_called()

    @staticmethod
    def test_one_plain_line_one_word() -> None:
        host_mock = Mock()
        host_mock.on_new_paragraph = Mock()
        host_mock.on_word = Mock()
        MarkdownParser('right', host_mock.on_new_paragraph, host_mock.on_word)
        host_mock.assert_has_calls([
            call.on_new_paragraph(ParagraphType.PLAIN),
            call.on_word('right'),
        ])

    @staticmethod
    def test_one_plain_line_multiple_words() -> None:
        host_mock = Mock()
        host_mock.on_new_paragraph = Mock()
        host_mock.on_word = Mock()
        MarkdownParser('right left up down', host_mock.on_new_paragraph, host_mock.on_word)
        host_mock.assert_has_calls([
            call.on_new_paragraph(ParagraphType.PLAIN),
            call.on_word('right'),
            call.on_word('left'),
            call.on_word('up'),
            call.on_word('down'),
        ])

    @staticmethod
    def test_two_plain_lines_one_word() -> None:
        host_mock = Mock()
        host_mock.on_new_paragraph = Mock()
        host_mock.on_word = Mock()
        MarkdownParser('right\nleft', host_mock.on_new_paragraph, host_mock.on_word)
        host_mock.assert_has_calls([
            call.on_new_paragraph(ParagraphType.PLAIN),
            call.on_word('right'),
            call.on_new_paragraph(ParagraphType.PLAIN),
            call.on_word('left'),
        ])

    @staticmethod
    def test_two_plain_lines_multiple_words() -> None:
        host_mock = Mock()
        host_mock.on_new_paragraph = Mock()
        host_mock.on_word = Mock()
        MarkdownParser('right left\nup down', host_mock.on_new_paragraph, host_mock.on_word)
        host_mock.assert_has_calls([
            call.on_new_paragraph(ParagraphType.PLAIN),
            call.on_word('right'),
            call.on_word('left'),
            call.on_new_paragraph(ParagraphType.PLAIN),
            call.on_word('up'),
            call.on_word('down'),
        ])

    @staticmethod
    def test_one_bullet_line_one_word() -> None:
        host_mock = Mock()
        host_mock.on_new_paragraph = Mock()
        host_mock.on_word = Mock()
        MarkdownParser('* right', host_mock.on_new_paragraph, host_mock.on_word)
        host_mock.assert_has_calls([
            call.on_new_paragraph(ParagraphType.BULLETED),
            call.on_word('right'),
        ])

    @staticmethod
    def test_one_bullet_line_multiple_words() -> None:
        host_mock = Mock()
        host_mock.on_new_paragraph = Mock()
        host_mock.on_word = Mock()
        MarkdownParser('* right left up down', host_mock.on_new_paragraph, host_mock.on_word)
        host_mock.assert_has_calls([
            call.on_new_paragraph(ParagraphType.BULLETED),
            call.on_word('right'),
            call.on_word('left'),
            call.on_word('up'),
            call.on_word('down'),
        ])

    @staticmethod
    def test_one_plain_and_one_bullet_line_one_word() -> None:
        host_mock = Mock()
        host_mock.on_new_paragraph = Mock()
        host_mock.on_word = Mock()
        MarkdownParser('right\n* left', host_mock.on_new_paragraph, host_mock.on_word)
        host_mock.assert_has_calls([
            call.on_new_paragraph(ParagraphType.PLAIN),
            call.on_word('right'),
            call.on_new_paragraph(ParagraphType.BULLETED),
            call.on_word('left'),
        ])

    @staticmethod
    def test_one_plain_and_one_bullet_line_multiple_words() -> None:
        host_mock = Mock()
        host_mock.on_new_paragraph = Mock()
        host_mock.on_word = Mock()
        MarkdownParser('right left\n* up down', host_mock.on_new_paragraph, host_mock.on_word)
        host_mock.assert_has_calls([
            call.on_new_paragraph(ParagraphType.PLAIN),
            call.on_word('right'),
            call.on_word('left'),
            call.on_new_paragraph(ParagraphType.BULLETED),
            call.on_word('up'),
            call.on_word('down'),
        ])

    @staticmethod
    def test_one_bullet_and_one_plain_line_one_word() -> None:
        host_mock = Mock()
        host_mock.on_new_paragraph = Mock()
        host_mock.on_word = Mock()
        MarkdownParser('* right\nup', host_mock.on_new_paragraph, host_mock.on_word)
        host_mock.assert_has_calls([
            call.on_new_paragraph(ParagraphType.BULLETED),
            call.on_word('right'),
            call.on_new_paragraph(ParagraphType.INDENTED),
            call.on_word('up'),
        ])

    @staticmethod
    def test_one_bullet_and_one_plain_line_mutiple_words() -> None:
        host_mock = Mock()
        host_mock.on_new_paragraph = Mock()
        host_mock.on_word = Mock()
        MarkdownParser('* right left\nup down', host_mock.on_new_paragraph, host_mock.on_word)
        host_mock.assert_has_calls([
            call.on_new_paragraph(ParagraphType.BULLETED),
            call.on_word('right'),
            call.on_word('left'),
            call.on_new_paragraph(ParagraphType.INDENTED),
            call.on_word('up'),
            call.on_word('down'),
        ])

    @staticmethod
    def test_one_bullet_and_one_plain_line_with_blank_line() -> None:
        host_mock = Mock()
        host_mock.on_new_paragraph = Mock()
        host_mock.on_word = Mock()
        MarkdownParser('* right left\n\nup down', host_mock.on_new_paragraph, host_mock.on_word)
        host_mock.assert_has_calls([
            call.on_new_paragraph(ParagraphType.BULLETED),
            call.on_word('right'),
            call.on_word('left'),
            call.on_new_paragraph(ParagraphType.PLAIN),
            call.on_word('up'),
            call.on_word('down'),
        ])

    @staticmethod
    def test_one_bullet_and_one_plain_line_with_multiple_blank_lines() -> None:
        host_mock = Mock()
        host_mock.on_new_paragraph = Mock()
        host_mock.on_word = Mock()
        MarkdownParser('* right left\n\n\n\n\nup down', host_mock.on_new_paragraph, host_mock.on_word)
        host_mock.assert_has_calls([
            call.on_new_paragraph(ParagraphType.BULLETED),
            call.on_word('right'),
            call.on_word('left'),
            call.on_new_paragraph(ParagraphType.PLAIN),
            call.on_word('up'),
            call.on_word('down'),
        ])

    @staticmethod
    def test_multiple_bullet_and_plain_lines() -> None:
        host_mock = Mock()
        host_mock.on_new_paragraph = Mock()
        host_mock.on_word = Mock()
        MarkdownParser('* right left\n* up down\nnorth south', host_mock.on_new_paragraph, host_mock.on_word)
        host_mock.assert_has_calls([
            call.on_new_paragraph(ParagraphType.BULLETED),
            call.on_word('right'),
            call.on_word('left'),
            call.on_new_paragraph(ParagraphType.BULLETED),
            call.on_word('up'),
            call.on_word('down'),
            call.on_new_paragraph(ParagraphType.INDENTED),
            call.on_word('north'),
            call.on_word('south'),
        ])

    @staticmethod
    def test_escapes_are_stripped() -> None:
        host_mock = Mock()
        host_mock.on_new_paragraph = Mock()
        host_mock.on_word = Mock()
        MarkdownParser('\\*right\\*', host_mock.on_new_paragraph, host_mock.on_word)
        host_mock.assert_has_calls([
            call.on_new_paragraph(ParagraphType.PLAIN),
            call.on_word('*right*'),
        ])

    @staticmethod
    def test_escaped_escapes_are_stripped() -> None:
        host_mock = Mock()
        host_mock.on_new_paragraph = Mock()
        host_mock.on_word = Mock()
        MarkdownParser('\\\\right', host_mock.on_new_paragraph, host_mock.on_word)
        host_mock.assert_has_calls([
            call.on_new_paragraph(ParagraphType.PLAIN),
            call.on_word('\\right'),
        ])
