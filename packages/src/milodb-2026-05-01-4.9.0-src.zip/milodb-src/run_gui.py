#!/usr/bin/env python3
# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
if __name__ == "__main__":
    from tools import run_from_root_dir
    run_from_root_dir('entry_gui.pyw')
