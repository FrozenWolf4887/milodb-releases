from typing import Optional

MILODB_VERSION: Optional[str] = '1.7'
MILODB_DATE: Optional[str] = '2022-10-31'
