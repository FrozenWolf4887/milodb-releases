# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import re
from collections.abc import Callable, Sequence
from milodb_systest.logger import Logger

class TestFailError(Exception):
    pass

class ExpectedLine:
    def __init__(self, expected_text: str | re.Pattern[str] | None = None) -> None:
        if expected_text is None:
            expected_text = ''
        self._expected_text: str | re.Pattern[str] = expected_text

    def does_match(self, actual_text: str) -> bool:
        if isinstance(self._expected_text, re.Pattern):
            return bool(self._expected_text.fullmatch(actual_text))
        return actual_text == self._expected_text

    def log_expected(self, logger: Logger) -> None:
        if isinstance(self._expected_text, re.Pattern):
            logger.log_note('expected pattern:')
            logger.log_note(self._expected_text.pattern)
        else:
            logger.log_note('expected text:')
            logger.log_note(self._expected_text)

class TestFramework:
    def __init__(self, logger: Logger, input_sender: Callable[[str], None], output_reader: Callable[[], str], is_quit: Callable[[], bool]) -> None:
        self._logger: Logger = logger
        self._input_sender: Callable[[str], None] = input_sender
        self._output_reader: Callable[[], str] = output_reader
        self._is_quit: Callable[[], bool] = is_quit

    def verify_command(self, command_text: str, list_of_expected_lines: Sequence[ExpectedLine], *, quit_flag: bool = False) -> None:
        self.send_command(command_text)
        self.verify_output([ ExpectedLine(), *list_of_expected_lines, ExpectedLine() ], quit_flag = quit_flag)

    def send_command(self, command_text: str) -> None:
        self._logger.log_injection(command_text)
        self._input_sender(command_text)

    def verify_output(self, list_of_expected_lines: Sequence[ExpectedLine], *, quit_flag: bool = False) -> None:
        output_text: str = self._output_reader()
        list_of_output_lines: list[str] = output_text.splitlines()

        expected_line: ExpectedLine
        actual_line: str
        for expected_line, actual_line in zip(list_of_expected_lines, list_of_output_lines, strict=False):
            if expected_line.does_match(actual_line):
                self._logger.log_pass_output(actual_line)
            else:
                self._logger.log_fail_output(actual_line)
                expected_line.log_expected(self._logger)
                raise TestFailError

        if len(list_of_output_lines) > len(list_of_expected_lines):
            self._logger.log_fail_output(list_of_output_lines[len(list_of_expected_lines)])
            self._logger.log_note('unexpected additional line(s)')
            raise TestFailError
        if len(list_of_output_lines) < len(list_of_expected_lines):
            self._logger.log_fail('missing line(s)')
            list_of_expected_lines[len(list_of_output_lines)].log_expected(self._logger)

        if self._is_quit() != quit_flag:
            self._logger.log_fail(f'Expected quit flag was {quit_flag} but is {self._is_quit()}')
