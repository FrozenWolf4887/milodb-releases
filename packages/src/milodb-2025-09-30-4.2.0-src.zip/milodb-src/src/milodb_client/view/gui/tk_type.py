# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import tkinter as tk

type Relief = tk._Relief # pylint: disable=protected-access, no-member # type: ignore[reportPrivateUsage] # noqa: SLF001 Private member accessed
type ScreenUnits = tk._ScreenUnits # pylint: disable=protected-access, no-member # type: ignore[reportPrivateUsage] # noqa: SLF001 Private member accessed
type TakeFocusValue = tk._TakeFocusValue # pylint: disable=protected-access, no-member # type: ignore[reportPrivateUsage] # noqa: SLF001 Private member accessed
type XYScrollCommand = tk._XYScrollCommand # pylint: disable=protected-access, no-member # type: ignore[reportPrivateUsage] # noqa: SLF001 Private member accessed
