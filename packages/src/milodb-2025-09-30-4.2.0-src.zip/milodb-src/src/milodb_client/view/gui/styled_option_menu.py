# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import tkinter as tk
from collections.abc import Callable, Sequence
from tkinter import ttk
from typing import Literal
from milodb_client.view.gui.theme import apply_optionmenu_style

class StyledOptionMenu(ttk.OptionMenu):
    def __init__(
            self,
            master: tk.Misc,
            variable: tk.StringVar,
            *,
            default_value: str | None = None,
            list_of_values: Sequence[str],
            style: str,
            direction: Literal['above', 'below', 'left', 'right', 'flush'] = "below",
            command: Callable[[tk.StringVar], object] | None = None,
        ) -> None:
        super().__init__(master, variable, default_value, *list_of_values, style=style, direction=direction, command=command)
        self._style_name: str = style
        self._change_theme_event_id: str | None = None

        apply_optionmenu_style(self, self._style_name)
        self.bind('<<ThemeChanged>>', self._on_theme_changed)

    def _on_theme_changed(self, _event: object) -> None:
        if self._change_theme_event_id is None:
            self._change_theme_event_id = self.after_idle(self._on_idle_update_theme)

    def _on_idle_update_theme(self) -> None:
        self._change_theme_event_id = None
        apply_optionmenu_style(self, self._style_name)
