# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import tkinter as tk
import tkinter.font as tkfont
from collections.abc import Sequence
from tkinter import ttk
from typing import TYPE_CHECKING, override
from milodb_client.query.field_match import FieldPageListMatch, IFieldMatch
from milodb_client.query.tease_match import TeaseMatch
from milodb_client.view.gui.banner_text import BANNER_NO_MATCHING_TEASES, BANNER_NO_MATCHING_TEXT, BANNER_NO_SELECTED_TEASE, BANNER_NO_TEXT
from milodb_client.view.gui.canvas_widgets import CanvasPlainText, get_canvas_event_relative_coord
from milodb_client.view.gui.page_text_panel import PageTextPanel
from milodb_client.view.gui.popup_menu_call import PopupPageMenuCallback
from milodb_client.view.gui.scrollable_canvas import ScrollableCanvas
from milodb_client.view.gui.styled_frame import StyledFrame
from milodb_client.view.gui.theme import Colour, Font, Style
from milodb_client.view.gui.util.datum import IValueDatum
from milodb_client.view.gui.util.datum_tk_binding import DatumBoolTkBinding
from milodb_common.view.gui.metrics import Padding, Point, Size
if TYPE_CHECKING:
    from milodb_client.database.tease_page import TeasePage

_PANEL_PADDING: Padding = Padding(4, 4, 4, 4)

class TextMatchesPanel(StyledFrame):
    def __init__(self, master: tk.Misc, list_of_tease_matches: IValueDatum[Sequence[TeaseMatch]], selected_tease_index: IValueDatum[int | None], show_only_matching_pages_ref: IValueDatum[bool], abbreviate_text_ref: IValueDatum[bool], show_page_refs_ref: IValueDatum[bool], call_popup_page_menu: PopupPageMenuCallback) -> None:
        super().__init__(master, style=Style.Generic.PanelFrame.STYLE_NAME)
        self._list_of_tease_matches: IValueDatum[Sequence[TeaseMatch]] = list_of_tease_matches
        self._selected_tease_index: IValueDatum[int | None] = selected_tease_index
        self._show_only_matching_pages_ref: IValueDatum[bool] = show_only_matching_pages_ref
        self._abbreviate_text_ref: IValueDatum[bool] = abbreviate_text_ref
        self._show_page_refs_ref: IValueDatum[bool] = show_page_refs_ref
        self._call_popup_page_menu: PopupPageMenuCallback = call_popup_page_menu

        self._font: tkfont.Font = tkfont.Font(self, Font.Normal.TUPLE)
        self._banner_font: tkfont.Font = tkfont.Font(self, Font.Banner.TUPLE)
        self._list_of_pages: list[PageTextPanel] = []
        self._update_height_event_id: str | None = None
        self._update_height_index: int = 0
        self._tease_match: TeaseMatch | None = None
        self._banner_text: CanvasPlainText | None = None
        self._selected_page: PageTextPanel | None = None
        self._has_matching_pages: bool = False

        options_frame: StyledFrame = StyledFrame(self, style=Style.Generic.ValueFrame.STYLE_NAME)
        show_only_matching_pages: tk.BooleanVar = tk.BooleanVar(master, value=show_only_matching_pages_ref.get())
        abbreviate_text: tk.BooleanVar = tk.BooleanVar(master, value=abbreviate_text_ref.get())
        show_page_refs: tk.BooleanVar = tk.BooleanVar(master, value=show_page_refs_ref.get())
        ttk.Checkbutton(options_frame, text='Only matching pages', variable=show_only_matching_pages, style=Style.OnValueFrame.Checkbox.STYLE_NAME).grid(row=0, column=0, sticky=tk.W, columnspan=2)
        ttk.Checkbutton(options_frame, text='Abbreviate', variable=abbreviate_text, style=Style.OnValueFrame.Checkbox.STYLE_NAME).grid(row=1, column=0, sticky=tk.W)
        ttk.Checkbutton(options_frame, text='Page refs', variable=show_page_refs, style=Style.OnValueFrame.Checkbox.STYLE_NAME).grid(row=1, column=1, sticky=tk.W, columnspan=2)
        options_frame.pack(fill=tk.X)

        self._list_panel: ScrollableCanvas = ScrollableCanvas(self, self._on_canvas_size_changed)
        self._list_panel.pack(fill=tk.BOTH, expand=True)

        self._list_of_datum_tk_bindings: tuple[DatumBoolTkBinding, ...] = (
            DatumBoolTkBinding(self._show_only_matching_pages_ref, show_only_matching_pages, self._on_change_show_only_matching_pages),
            DatumBoolTkBinding(self._abbreviate_text_ref, abbreviate_text, self._on_change_abbreviate_text),
            DatumBoolTkBinding(self._show_page_refs_ref, show_page_refs, self._on_change_show_page_refs),
        )
        self._list_of_tease_matches.add_new_value_listener(self._on_list_of_tease_matches_changed, call_immediately=True)
        self._selected_tease_index.add_new_value_listener(self._on_selected_tease_index_changed, call_immediately=True)

        self._list_panel.canvas.bind('<Button-1>', self._on_mouse_click)
        self._list_panel.canvas.bind('<Button-2>', self._on_mouse_right_click)
        self._list_panel.canvas.bind('<Button-3>', self._on_mouse_right_click)

    @override
    def destroy(self) -> None:
        binding: DatumBoolTkBinding
        for binding in self._list_of_datum_tk_bindings:
            binding.destroy()
        self._list_of_tease_matches.remove_listener(self._on_list_of_tease_matches_changed)
        self._selected_tease_index.remove_listener(self._on_selected_tease_index_changed)
        self._clear_panel()
        super().destroy()

    def _on_list_of_tease_matches_changed(self, new_value: Sequence[TeaseMatch]) -> None:
        self._clear_panel()
        self._tease_match = None

        if not new_value:
            self._add_banner_text(BANNER_NO_MATCHING_TEASES)
        else:
            self._add_banner_text(BANNER_NO_SELECTED_TEASE)

    def _on_selected_tease_index_changed(self, new_value: int | None) -> None:
        self._clear_panel()
        self._tease_match = None

        list_of_tease_matches: Sequence[TeaseMatch] = self._list_of_tease_matches.get()
        if not list_of_tease_matches:
            self._add_banner_text(BANNER_NO_MATCHING_TEASES)
            self._has_matching_pages = False
        elif new_value is None:
            self._add_banner_text(BANNER_NO_SELECTED_TEASE)
            self._has_matching_pages = False
        else:
            self._tease_match = list_of_tease_matches[new_value]
            if self._show_only_matching_pages_ref.get():
                self._show_matching_pages(self._tease_match)
            else:
                self._show_all_pages(self._tease_match)
            self._has_matching_pages = any(isinstance(field_match, FieldPageListMatch) for field_match in self._tease_match.list_of_field_matches)

    def _add_banner_text(self, text: str) -> None:
        self._banner_text = CanvasPlainText(
            self._list_panel.canvas,
            origin_x = self._list_panel.canvas.winfo_width() // 2,
            origin_y = _PANEL_PADDING.top,
            text = text,
            fill = Colour.TextMatchesPanel.BANNER_FORE,
            font = self._banner_font,
            justify = tk.CENTER,
            anchor = tk.N,
        )

    def _clear_panel(self) -> None:
        if self._update_height_event_id is not None:
            self.after_cancel(self._update_height_event_id)
            self._update_height_event_id = None

        if self._banner_text:
            self._banner_text.destroy()
            self._banner_text = None

        page: PageTextPanel
        for page in self._list_of_pages:
            page.destroy()
        self._list_of_pages = []
        self._selected_page = None

        self._list_panel.reset_scroll()

    def _show_matching_pages(self, tease_match: TeaseMatch) -> None:
        panel_width: int = self._list_panel.canvas.winfo_width() - _PANEL_PADDING.width

        index: int = 0
        field_match: IFieldMatch
        for field_match in tease_match.list_of_field_matches:
            if isinstance(field_match, FieldPageListMatch):
                self._list_of_pages.append(
                    PageTextPanel(
                        index = index,
                        tease_page = field_match.page,
                        list_of_field_matches = tease_match.list_of_field_matches,
                        abbreviate_text = self._abbreviate_text_ref.get(),
                        show_page_ref = self._show_page_refs_ref.get(),
                        font = self._font,
                        canvas = self._list_panel.canvas,
                        left = _PANEL_PADDING.left,
                        top = _PANEL_PADDING.top,
                        width = panel_width,
                        height_changed_callback = self._on_page_height_changed,
                    ),
                )
                index += 1

        if not index:
            self._add_banner_text(BANNER_NO_MATCHING_TEXT)

    def _show_all_pages(self, tease_match: TeaseMatch) -> None:
        panel_width: int = self._list_panel.canvas.winfo_width() - _PANEL_PADDING.width

        index: int | None = None
        tease_page: TeasePage
        for index, tease_page in enumerate(tease_match.tease.get_list_of_pages()):
            self._list_of_pages.append(
                PageTextPanel(
                    index = index,
                    tease_page = tease_page,
                    list_of_field_matches = tease_match.list_of_field_matches,
                    abbreviate_text = self._abbreviate_text_ref.get(),
                    show_page_ref = self._show_page_refs_ref.get(),
                    font = self._font,
                    canvas = self._list_panel.canvas,
                    left = _PANEL_PADDING.left,
                    top = _PANEL_PADDING.top,
                    width = panel_width,
                    height_changed_callback = self._on_page_height_changed,
                ),
            )

        if index is None:
            self._add_banner_text(BANNER_NO_TEXT)

    def _on_change_show_only_matching_pages(self, *, new_value: bool) -> None:
        if self._tease_match:
            self._clear_panel()
            if new_value:
                self._show_matching_pages(self._tease_match)
            else:
                self._show_all_pages(self._tease_match)

    def _on_change_abbreviate_text(self, *, new_value: bool) -> None:
        page: PageTextPanel
        for page in self._list_of_pages:
            page.set_abbreviate_text(new_value)

    def _on_change_show_page_refs(self, *, new_value: bool) -> None:
        page: PageTextPanel
        for page in self._list_of_pages:
            page.set_show_page_ref(new_value)

    def _on_canvas_size_changed(self, size: Size) -> None:
        panel_width: int = size.width - _PANEL_PADDING.width

        if self._banner_text:
            self._banner_text.move_to(left = size.width // 2)

        page: PageTextPanel
        for page in self._list_of_pages:
            page.set_width(panel_width)

    def _on_page_height_changed(self, index: int) -> None:
        if self._update_height_event_id is None:
            self._update_height_event_id = self.after(0, self._on_idle_refit_to_page_height)
            self._update_height_index = index
        else:
            self._update_height_index = min(index, self._update_height_index)

    def _on_idle_refit_to_page_height(self) -> None:
        self._update_height_event_id = None

        top: int | None = None
        index: int
        for index in range(self._update_height_index, len(self._list_of_pages)):
            page: PageTextPanel = self._list_of_pages[index]
            if top is None:
                top = page.top
            else:
                page.set_top(top)
            top = page.bottom + _PANEL_PADDING.height

        self._list_panel.set_content_height(top - _PANEL_PADDING.top if top is not None else 0)

        self.update_idletasks()

    def _on_mouse_click(self, event: tk.Event) -> str:
        page: PageTextPanel | None = self._get_page_from_event(event)
        self._select_page(page)
        return 'break'

    def _on_mouse_right_click(self, event: tk.Event) -> str:
        page: PageTextPanel | None = self._get_page_from_event(event)
        self._select_page(page)
        if self._tease_match:
            if self._selected_page:
                self._call_popup_page_menu(self, event.x_root, event.y_root, self._tease_match, self._selected_page.tease_page, has_matching_pages=self._has_matching_pages)
            else:
                self._call_popup_page_menu(self, event.x_root, event.y_root, self._tease_match, None, has_matching_pages=self._has_matching_pages)
        return 'break'

    def _select_page(self, page: PageTextPanel | None) -> None:
        if page is not self._selected_page:
            if page is not None:
                page.select()
            if self._selected_page is not None:
                self._selected_page.deselect()
            self._selected_page = page

    def _get_page_from_event(self, event: tk.Event) -> PageTextPanel | None:
        point: Point = get_canvas_event_relative_coord(self._list_panel.canvas, event)
        return self._get_page_from_y_offset(int(point.y))

    def _get_page_from_y_offset(self, pos_y: int) -> PageTextPanel | None:
        for card in self._list_of_pages:
            if card.top <= pos_y <= card.bottom:
                return card
        return None
