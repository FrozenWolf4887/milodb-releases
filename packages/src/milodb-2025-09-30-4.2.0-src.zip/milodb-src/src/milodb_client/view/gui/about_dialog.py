# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from __future__ import annotations
import platform
import sys
import tkinter as tk
from tkinter import ttk
from typing import TYPE_CHECKING
import psutil
from milodb_client.util import app_info
from milodb_client.view.gui.frame_widgets import WrappingLabel
from milodb_client.view.gui.scrollable_frame import ScrollableFrame
from milodb_client.view.gui.styled_frame import StyledFrame
from milodb_client.view.gui.theme import Style
from milodb_client.view.gui.window_widgets import ModalDialog
from milodb_common.util.get_url import get_url_of_author
from milodb_common.util.unit_size import UnitSizeText, unit_size
if TYPE_CHECKING:
    from collections.abc import Callable
    from milodb_client.updater.manifest.local_manifest import ILocalManifest

_TABLE_GRIDLINE_THICKNESS: int = 1

class AboutDialog(ModalDialog):
    def __init__(self, master: tk.Tk, local_manifest: ILocalManifest | None, *, call_copy_to_clipboard: Callable[[str], None], call_open_url: Callable[[str], None]) -> None: # pylint: disable=too-many-statements # noqa: PLR0915 Too many statements
        super().__init__(master, title=f'About {app_info.APPLICATION_NAME}', width=680, height=400)

        virtual_memory = psutil.virtual_memory()
        process: psutil.Process = psutil.Process()
        process_memory = process.memory_info()
        total_memory_size: UnitSizeText = unit_size(virtual_memory.total)
        used_memory: UnitSizeText = unit_size(process_memory.rss)
        available_memory_size: UnitSizeText = unit_size(virtual_memory.available)
        core_count: int | None = psutil.cpu_count(logical=False)
        thread_count: int | None = psutil.cpu_count()

        table_frame: ScrollableFrame = ScrollableFrame(self.content_frame, frame_style=Style.Generic.TableFrame.STYLE_NAME)
        table_frame.top_frame.pack(fill=tk.BOTH, expand=True)

        row: int = 0
        _create_heading_label(table_frame.content_frame, row, 'Application')
        _create_value_label(table_frame.content_frame, row, f'{app_info.APPLICATION_NAME}, {local_manifest.variant_name if local_manifest else 'unknown variant'}')
        row += 1
        _create_heading_label(table_frame.content_frame, row, 'Version')
        _create_value_label(table_frame.content_frame, row, f'{local_manifest.version_number if local_manifest else 'unknown version'}, {local_manifest.date.isoformat() if local_manifest else 'unknown date'}')
        row += 1
        _create_heading_label(table_frame.content_frame, row, 'Support Topic')
        _create_value_label(table_frame.content_frame, row, app_info.FORUM_THREAD_URL, columnspan=1)
        _create_copy_button(table_frame.content_frame, row, app_info.FORUM_THREAD_URL, call_copy_to_clipboard, column=2)
        _create_open_button(table_frame.content_frame, row, app_info.FORUM_THREAD_URL, call_open_url, column=3)
        row += 1
        _create_heading_label(table_frame.content_frame, row, 'Author')
        _create_value_label(table_frame.content_frame, row, app_info.AUTHOR_NAME)
        row += 1
        _create_heading_label(table_frame.content_frame, row, 'Author Profile')
        _create_value_label(table_frame.content_frame, row, get_url_of_author(app_info.AUTHOR_ID), columnspan=1)
        _create_copy_button(table_frame.content_frame, row, get_url_of_author(app_info.AUTHOR_ID), call_copy_to_clipboard, column=2)
        _create_open_button(table_frame.content_frame, row, get_url_of_author(app_info.AUTHOR_ID), call_open_url, column=3)
        row += 1
        _create_heading_label(table_frame.content_frame, row, 'Machine')
        _create_value_label(table_frame.content_frame, row, f'{platform.machine()}, {sys.platform}, {platform.platform()}')
        row += 1
        _create_heading_label(table_frame.content_frame, row, 'Memory')
        _create_value_label(table_frame.content_frame, row, f'{total_memory_size.size_text} {total_memory_size.unit_text} total, {used_memory.size_text} {used_memory.unit_text} used by {app_info.APPLICATION_NAME}, {available_memory_size.size_text} {available_memory_size.unit_text} free')
        row += 1
        _create_heading_label(table_frame.content_frame, row, 'CPU')
        _create_value_label(table_frame.content_frame, row, f'{platform.processor()}, {core_count if core_count else 'unknown'} cores, {thread_count if thread_count else 'unknown'} threads')
        row += 1
        _create_heading_label(table_frame.content_frame, row, 'Python')
        _create_value_label(table_frame.content_frame, row, sys.version)
        row += 1
        _create_heading_label(table_frame.content_frame, row, 'Software Licence')
        _create_value_label(table_frame.content_frame, row, app_info.SOFTWARE_LICENCE_TEXT, columnspan=1)
        _create_copy_button(table_frame.content_frame, row, app_info.SOFTWARE_LICENCE_URL, call_copy_to_clipboard, column=2)
        _create_open_button(table_frame.content_frame, row, app_info.SOFTWARE_LICENCE_URL, call_open_url, column=3)
        row += 1
        _create_heading_label(table_frame.content_frame, row, 'Tease Copyright')
        _create_value_label(table_frame.content_frame, row, app_info.TEASE_COPYRIGHT_TEXT, columnspan=1)
        _create_copy_button(table_frame.content_frame, row, app_info.TERMS_OF_SERVICE_URL, call_copy_to_clipboard, column=2)
        _create_open_button(table_frame.content_frame, row, app_info.TERMS_OF_SERVICE_URL, call_open_url, column=3)

        table_frame.content_frame.columnconfigure(1, weight=1)
        table_frame.set_child_bindtags_for_scrolling()

        self.add_button('Okay', column=0, command=self.destroy)
        self.focus_button(column=0)

def _create_heading_label(frame: tk.Misc, row: int, text: str) -> None:
    ttk.Label(frame, text=text, anchor=tk.W, justify=tk.LEFT, style=Style.InTable.HeaderLabel.STYLE_NAME).grid(row=row, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)

def _create_value_label(frame: tk.Misc, row: int, text: str, *, column: int=1, columnspan: int=3) -> None:
    WrappingLabel(frame, text=text, anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=column, columnspan=columnspan, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)

def _create_copy_button(frame: tk.Misc, row: int, text_to_copy: str, call_copy_to_clipboard: Callable[[str], None], *, column: int) -> None:
    _create_button(frame, row, 'Copy', lambda: call_copy_to_clipboard(text_to_copy), column=column)

def _create_open_button(frame: tk.Misc, row: int, url: str, call_open_url: Callable[[str], None], *, column: int) -> None:
    _create_button(frame, row, 'Open', lambda: call_open_url(url), column=column)

def _create_button(frame: tk.Misc, row: int, button_text: str, call_handler: Callable[[], None], *, column: int) -> None:
    cell_frame: StyledFrame = StyledFrame(frame, style=Style.InTable.CellFrame.STYLE_NAME)
    cell_frame.grid(row=row, column=column, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
    ttk.Button(cell_frame, text=button_text, style=Style.Generic.Button.STYLE_NAME, command=call_handler).grid()
    cell_frame.rowconfigure(0, weight=1)
    cell_frame.columnconfigure(0, weight=1)
