# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import re
import tkinter as tk
from abc import ABC, abstractmethod
from enum import Enum
from typing import override
from milodb_client.view.gui.util.tk_index import TkIndex

class ValidationResult(Enum):
    EMPTY = 0
    VALID = 1
    INVALID = 2

class IValidator(ABC):
    @abstractmethod
    def validate(self) -> ValidationResult:
        pass

class TrueValidator(IValidator):
    def __init__(self, entry: tk.Text, error_tag: str) -> None:
        self._entry: tk.Text = entry
        self._error_tag: str = error_tag

    @override
    def validate(self) -> ValidationResult:
        self._entry.tag_delete(self._error_tag)
        if self._entry.get('1.0', tk.END)[:-1]:
            return ValidationResult.VALID
        return ValidationResult.EMPTY

class RegexValidator(IValidator):
    def __init__(self, entry: tk.Text, error_tag: str) -> None:
        self._entry: tk.Text = entry
        self._error_tag: str = error_tag

    @override
    def validate(self) -> ValidationResult:
        text: str = self._entry.get('1.0', tk.END)[:-1]
        self._entry.tag_delete(self._error_tag)
        if text:
            try:
                re.compile(text)
            except re.error as ex:
                start_tk_index: TkIndex = TkIndex.from_text(text[:ex.colno - 1])
                end_tk_index: TkIndex = start_tk_index.copy().move_with_text(text[ex.colno])
                self._entry.tag_add(self._error_tag, str(start_tk_index), str(end_tk_index))
                return ValidationResult.INVALID
            return ValidationResult.VALID
        return ValidationResult.EMPTY
