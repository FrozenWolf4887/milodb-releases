# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import sys
import tempfile
from collections.abc import Callable, Iterable, Sequence
from pathlib import Path
from typing import override
from milodb_client.config.config_schema import CONFIG_SCHEMA
from milodb_client.database.tease import Tease
from milodb_client.output.format.i_html_file_writer import IHtmlFileWriter
from milodb_client.query.tease_match import TeaseMatch
from milodb_client.util.launcher import launch
from milodb_client.view.terminal.commands.database_support import try_create_list_of_tease_matches_from_ref_ids
from milodb_common.config.framework import IConfigEnumLeaf, IConfigLeaf
from milodb_common.config.i_launch_config import ILaunchConfig, LaunchOption
from milodb_common.output.print.file_printer import FilePrinter
from milodb_common.output.print.i_printer import IPrinter
from milodb_common.parser import arg
from milodb_common.parser.arg_token_stream import ArgTokenStream
from milodb_common.parser.ref_id import RefId
from milodb_common.util import enums
from milodb_common.view.terminal.command_framework.i_command import CommandLoaderResult
from milodb_common.view.terminal.command_framework.i_help_info import IHelpInfo

# spell-checker: disable
_ICON_DATA_URI: str = r"data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20xml:space='preserve'%20width='122mm'%20height='123mm'%20viewBox='0%200%20122%20123'%3e%3cg%20transform='translate(-47%20-120)'%3e%3cpath%20d='m131%20192%2037%2037a6.35%206.35%2090%200%201%200%208l-5%205a6.35%206.35%200%200%201-8%200l-37-37z'%20style='fill:%23fff;stroke-width:0;stroke-linecap:round;stroke-linejoin:round'/%3e%3ccircle%20cx='97'%20cy='170'%20r='50'%20style='fill:%23fff;fill-opacity:1;stroke:none;stroke-width:0;stroke-linecap:round;stroke-linejoin:round;stroke-dasharray:none;stroke-opacity:1'/%3e%3cpath%20d='m131%20197%208%207-9%209-7-8z'%20style='fill:%23616161;stroke-width:0;stroke-linecap:round;stroke-linejoin:round'/%3e%3ccircle%20cx='97'%20cy='170'%20r='47'%20style='fill:%23616161;fill-opacity:1;stroke:none;stroke-width:0;stroke-linecap:round;stroke-linejoin:round;stroke-dasharray:none;stroke-opacity:1'/%3e%3ccircle%20cx='97'%20cy='170'%20r='40'%20style='fill:%23f1c3c3;fill-opacity:1;stroke:none;stroke-width:0;stroke-linecap:round;stroke-linejoin:round;stroke-dasharray:none;stroke-opacity:1'/%3e%3cpath%20d='M88%20190c-1-3-1-7-10-15-11.9-13-1-32%2013-22%206%203%208%203%2012%201%2020-16%2027%2018%203%2034-11%209-16%2013-18%202z'%20style='fill:%23b85a5a;fill-opacity:1;stroke:none;stroke-width:12.011;stroke-dasharray:none;stroke-opacity:1'/%3e%3cpath%20d='M88%20190c-1-3-2-8-10-15-12.3-12-1-32%2013-22%206%203%208%203%2012%201%2020-16%2027%2018%203%2034-11%209-16%2013-18%202z'%20style='mix-blend-mode:normal;fill:none;fill-opacity:1;stroke:%23b14d4d;stroke-width:12.011;stroke-dasharray:none;stroke-opacity:.459'/%3e%3cpath%20d='m139%20204%2026%2026a3.97%203.97%2090%200%201%200%206l-3%203a3.97%203.97%20180%200%201-6%200l-26-26z'%20style='fill:%2337474f;fill-opacity:1;stroke-width:0;stroke-linecap:round;stroke-linejoin:round'/%3e%3c/g%3e%3c/svg%3e"
# spell-checker: enable

_CONFIG_LAUNCH_OPTION: IConfigEnumLeaf[LaunchOption] = \
    CONFIG_SCHEMA.commands.browse.windows.launch_option if sys.platform == 'win32' else \
    CONFIG_SCHEMA.commands.browse.linux.launch_option
_CONFIG_LAUNCH_COMMAND: IConfigLeaf = \
    CONFIG_SCHEMA.commands.browse.windows.custom_launch_command if sys.platform == 'win32' else \
    CONFIG_SCHEMA.commands.browse.linux.custom_launch_command

_CONFIG_HELP_TEXT: str = (
    "Config:\r"
    f"  \t'{_CONFIG_LAUNCH_OPTION.full_path}'\r"
    "    \tDetermines how the web browser is launched to open the generated file. The options"
    f" are {enums.lowercase_names(_CONFIG_LAUNCH_OPTION.enum_class)}.\r"
    f"  \t'{_CONFIG_LAUNCH_COMMAND.full_path}'\r"
    f"    \tWhen '{_CONFIG_LAUNCH_OPTION.key_name}' is set to"
    f" '{_CONFIG_LAUNCH_OPTION.enum_class.CUSTOM.name.lower()}'"
    " this specifies the custom command to be executed where the following symbols can be"
    " specified:\r"
    "      $p  \tFull path to the generated file\r"
    "      $u  \tURL to the generated file\r"
    f"  \t'{CONFIG_SCHEMA.format.html.css_file_path.full_path}'\r"
    "    \tSpecifies the style sheet file to be embedded into the generated file."
)

def load(arg_token_stream: ArgTokenStream, list_of_teases: Sequence[Tease], list_of_tease_matches: Sequence[TeaseMatch], launch_config: ILaunchConfig, html_file_writer: IHtmlFileWriter, normal_printer: IPrinter, warning_printer: IPrinter, error_printer: IPrinter, debug_printer: IPrinter, *, browse_all: bool) -> CommandLoaderResult:
    list_of_ref_ids: Sequence[RefId] = arg.pop_list(arg_token_stream, arg.REF_ID)
    return CommandLoaderResult(
        lambda: execute(_write_all_text if browse_all else _write_matching_text, list_of_ref_ids, list_of_teases, list_of_tease_matches, launch_config, html_file_writer, normal_printer, warning_printer, error_printer, debug_printer),
        [],
    )

def execute(write_call: Callable[[IHtmlFileWriter, Iterable[TeaseMatch], IPrinter, IPrinter], bool], list_of_ref_ids: Sequence[RefId], list_of_teases: Sequence[Tease], list_of_tease_matches: Sequence[TeaseMatch], launch_config: ILaunchConfig, html_file_writer: IHtmlFileWriter, normal_printer: IPrinter, warning_printer: IPrinter, error_printer: IPrinter, debug_printer: IPrinter) -> None:
    list_of_tease_matches_to_write: Sequence[TeaseMatch] | None = None
    if list_of_ref_ids:
        list_of_tease_matches_to_write = try_create_list_of_tease_matches_from_ref_ids(list_of_teases, list_of_tease_matches, list_of_ref_ids, error_printer)
    else:
        list_of_tease_matches_to_write = list_of_tease_matches

    if list_of_tease_matches_to_write:
        try:
            with tempfile.NamedTemporaryFile(mode='w+t', suffix='.html', encoding='utf-8', delete=False) as file:
                file_printer: FilePrinter = FilePrinter(file)
                was_successful = write_call(html_file_writer, list_of_tease_matches_to_write, file_printer, error_printer)
        except OSError as ex:
            error_printer.writeln(f'Unable to create temporary file: {ex}')
        else:
            if was_successful:
                normal_printer.writeln(f"Created '{file.name}'")
                launch(launch_config, Path(file.name), Path(file.name).as_uri(), normal_printer, warning_printer, error_printer, debug_printer)
    else:
        error_printer.writeln("No teases available to browse")

def _write_matching_text(html_file_writer: IHtmlFileWriter, list_of_tease_matches: Iterable[TeaseMatch], file_printer: IPrinter, error_printer: IPrinter) -> bool:
    return html_file_writer.try_write_browse_file_of_text_matches(list_of_tease_matches, file_printer, error_printer, _ICON_DATA_URI)

def _write_all_text(html_file_writer: IHtmlFileWriter, list_of_tease_matches: Iterable[TeaseMatch], file_printer: IPrinter, error_printer: IPrinter) -> bool:
    return html_file_writer.try_write_browse_file_of_all_text(list_of_tease_matches, file_printer, error_printer, _ICON_DATA_URI)

class BrowseHelp(IHelpInfo):
    @override
    def get_one_line_summary(self) -> str:
        return "Opens a webpage for the results with the matching paragraphs of text"

    @override
    def get_detailed_summary(self) -> str:
        return (
            "Arguments: [list of RefIds]\n"
            "Generates a webpage that contains details for each tease including the matching"
            " text paragraphs if appropriate.\n"
            "When used without arguments, all teases that were found from the last query are"
            " included. When one or more RefIds are specified, only those teases are included.\n"
            "RefIds can be an index into the list of matches such as '3', a teaseId such as"
            " '#38664', or an authorId such as '@43937'.\n"
            "Matching fields and text may be highlighted which can be controlled with the"
            " highlight command.\n"
            "The text paragraphs may be abbreviated with an ellipsis which can be controlled"
            " with the ellipsis command.\n"
            f"{_CONFIG_HELP_TEXT}\n"
            "Example:\r"
            "  \tOpen a webpage with the last query results\r"
            "  > \tbrowse\r"
            "Example:\r"
            "  \tOpen a webpage for matched teases by index\r"
            "  > \tbrowse 3 7\r"
            "Example:\r"
            "  \tOpen a webpage for some specific teaseIds\r"
            "  > \tbrowse #16830 #1465 #38664\r"
            "Example:\r"
            "  \tOpen a webpage for teases from some specific authorId\r"
            "  > \tbrowse @43937\n"
            "See also:\r"
            "  \tbrowseall, debug, ellipsis, highlight\n"
        )

class BrowseAllHelp(IHelpInfo):
    @override
    def get_one_line_summary(self) -> str:
        return "Opens a webpage for the results with all paragraphs of text"

    @override
    def get_detailed_summary(self) -> str:
        return (
            "Arguments: [list of RefIds]\n"
            "Generates a webpage that contains details for each tease including all text"
            " paragraphs.\n"
            "When used without arguments, all teases that were found from the last query are"
            " included. When one or more RefIds are specified, only those teases are included.\n"
            "RefIds can be an index into the list of matches such as '3', a teaseId such as"
            " '#38664', or an authorId such as '@43937'.\n"
            "Matching fields and text may be highlighted which can be controlled with the"
            " highlight command.\n"
            "The ellipsis setting is ignored with this command so that all of the text is"
            " shown regardless of whether it matched or not.\n"
            f"{_CONFIG_HELP_TEXT}\n"
            "Example:\r"
            "  \tOpen a webpage with the last query results\r"
            "  > \tbrowseall\r"
            "Example:\r"
            "  \tOpen a webpage for matched teases by index\r"
            "  > \tbrowseall 3 7\r"
            "Example:\r"
            "  \tOpen a webpage for some specific teaseIds\r"
            "  > \tbrowseall #16830 #1465 #38664\r"
            "Example:\r"
            "  \tOpen a webpage for teases from some specific authorId\r"
            "  > \tbrowseall @43937\n"
            "See also:\r"
            "  \tbrowse, debug, ellipsis, highlight\n"
        )
