# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from collections.abc import Sequence
from typing import override
from milodb_client.database.tease import Tease
from milodb_client.output.format.i_formatter_factory import IFormatterCreator
from milodb_client.query.infix_query_parser import IInfixQueryParser, InfixError, PostfixQuery
from milodb_client.query.postfix_query_executor import IPostfixQueryExecutor, PostfixError, PostfixQueryResult
from milodb_client.query.query import IQuery
from milodb_client.query.syntax import LIST_OF_FIELD_NAMES, LIST_OF_OPERATORS, LIST_OF_VERB_NAMES
from milodb_client.query.tease_match import TeaseMatch
from milodb_client.util.tease_match_sorter import ITeaseMatchSorter
from milodb_client.view.terminal.util.named_sort_keys import OrderedNamedSortKey
from milodb_common.output.print.i_printer import IPrinter
from milodb_common.parser.arg_token_stream import ArgTokenStream
from milodb_common.util.ref import IRef
from milodb_common.view.terminal.command_framework.i_command import CommandLoaderError, CommandLoaderResult
from milodb_common.view.terminal.command_framework.i_help_info import IHelpInfo

def load(arg_token_stream: ArgTokenStream, list_of_teases: Sequence[Tease], infix_parser: IInfixQueryParser, postfix_executor: IPostfixQueryExecutor, list_of_tease_matches: IRef[Sequence[TeaseMatch]], tease_match_sorter: ITeaseMatchSorter, list_of_active_sort_keys: Sequence[OrderedNamedSortKey], formatter_creator: IFormatterCreator, normal_printer: IPrinter, warning_printer: IPrinter, error_printer: IPrinter) -> CommandLoaderResult:
    arg_token_stream.set_keep_delimiters('()')
    try:
        postfix_query: PostfixQuery = infix_parser.convert_to_postfix(arg_token_stream)
    except InfixError as ex:
        raise CommandLoaderError(
            ex.message,
            ex.fault_token,
            ex.list_of_candidate_text) from ex
    return CommandLoaderResult(
        lambda: execute(postfix_query.query_chain, list_of_teases, postfix_executor, list_of_tease_matches, tease_match_sorter, list_of_active_sort_keys, formatter_creator, normal_printer, warning_printer, error_printer),
        postfix_query.list_of_candidate_text,
    )

def execute(postfix_query_chain: Sequence[IQuery], list_of_teases: Sequence[Tease], postfix_executor: IPostfixQueryExecutor, list_of_tease_matches: IRef[Sequence[TeaseMatch]], tease_match_sorter: ITeaseMatchSorter, list_of_active_sort_keys: Sequence[OrderedNamedSortKey], formatter_creator: IFormatterCreator, normal_printer: IPrinter, warning_printer: IPrinter, error_printer: IPrinter) -> None:
    try:
        result: PostfixQueryResult = postfix_executor.execute(list_of_teases, postfix_query_chain, 10_000_000)
    except PostfixError as ex:
        error_printer.writeln(f'Unexpected fault in postfix query chain: {ex.message}')
        return

    list_of_tease_matches.set(tease_match_sorter.sort(result.list_of_tease_matches, list_of_active_sort_keys))
    if list_of_tease_matches:
        formatter_creator.create(normal_printer).print_list_of_teases(list_of_tease_matches.get())
    else:
        normal_printer.writeln("No matches")

    if result.was_max_match_count_reached:
        normal_printer.writeln()
        warning_printer.writeln(f'Limit of {result.max_match_count:,} matching items was reached')
        normal_printer.writeln(f'   Note: Search stopped with {result.total_match_count:,} matching items')
        percentage_searched: float = 0.0
        if result.queried_tease_count != 0:
            percentage_searched = 100.0 * result.queried_tease_count / result.total_tease_count
        normal_printer.writeln(f'   Note: Searched {result.queried_tease_count:,} of {result.total_tease_count:,} teases ({percentage_searched:.1f}%)')

class Help(IHelpInfo):
    @override
    def get_one_line_summary(self) -> str:
        return "Performs a deep search against metadata and text content"

    @override
    def get_detailed_summary(self) -> str:
        return (
            "Arguments: <infix query expression>\n"
            "A simple query is in the form: <field> <verb> <regex>. More complex"
            " queries can be constructed with parentheses and boolean operators.\n"
            "Fields:\r"
            f"  \t{', '.join(LIST_OF_FIELD_NAMES)}\r"
            "Verbs:\r"
            f"  \t{', '.join(LIST_OF_VERB_NAMES)}\r"
            "Operators:\r"
            f"  \t{', '.join(LIST_OF_OPERATORS)}\n"
            "The 'contains' and 'is' verbs are a plain text search where 'contains' will match text"
            " anywhere within the specified field, and 'is' will match against the whole field.\n"
            "The 'match' verb is a regular expression search. For more information on regular"
            " expression syntax, see 'https://pythex.org/'. When the regular expression contains"
            " a space or groups, surround the text with single or double quotes.\n"
            "The '=', '>', '>=', '<', '<=' verbs perform value comparisons against numerical and date"
            " fields.\n"
            "Comparison against dates may be shorthand, for example:\r"
            "  \t'date = 2023' is equivalent to 'date >= 2023-01-01 and date <= 2023-12-31'\r"
            "  \t'date > 2023' is equivalent to 'date >= 2024-01-01\r"
            "  \t'date < 2023-06' is equivalent to 'date < 2023-06-01\r"
            "  \t'date <= 2023-06' is equivalent to 'date <= 2023-06-30\r"
            "  \t'date > 2023-06' is equivalent to 'date >= 2023-07-01\n"
            "The 'not' operator is used before a conditional expression to negate it, such as 'not"
            " type is eos'.\n"
            "The list of results found by the query are sorted according to the current sort"
            " criteria specified with the sort command, and shown with the list command.\n"
            'Teases that have no known authors have an implicit authorId of 0 and authorName of "",'
            " and therefore can be queried with either 'authorId = 0' or 'authorName is \"\"'\n"
            "Example:\r"
            "  \tSearch all text paragraphs for a word\r"
            "  > \tquery text contains banana\r"
            "Example:\r"
            "  \tSearch the title field\r"
            "  \tNote: Quotes are used here because of the space\r"
            '  > \tquery title contains "lexi belle"\r'
            "Example:\r"
            "  \tSearch all text paragraphs for a regular expression\r"
            "  \tNote: Quotes are used here because of the parentheses\r"
            "  > \tquery text matches '(8|eight).?ball'\r"
            "Example:\r"
            "  \tSearch for all teases over a certain rating\r"
            '  > \tquery rating >= 4.5\r'
            "Example:\r"
            "  \tSearch for all teases on or newer than a certain date\r"
            '  > \tquery date >= 2019-03-14\r'
            "Example:\r"
            "  \tPerform a search for multiple fields\r"
            "  > \tquery title matches denial.+part and rating > 4 and text contains denied\r"
            "Example:\r"
            "  \tPerform a search using parentheses\r"
            '  > \tquery (type is nyx or type is eos) and text matches "chastity.?(belt|cage)"\n'
            "See also:\r"
            "  \tlist, sort, show, summary, browse, browseall\n"
        )
