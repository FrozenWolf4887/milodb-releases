# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
_LINEFEED_CHAR: str = '\n'
_SPACE_CHAR: str = ' '
_TAB_CHAR: str = '\t'

def indent_text(text: str, indent: int) -> str:
    prefix: str = _SPACE_CHAR * indent
    list_of_new_lines: list[str] = [
        f'{prefix}{line}' if line != _LINEFEED_CHAR else _LINEFEED_CHAR for line in text.splitlines(keepends=True)
    ]
    return ''.join(list_of_new_lines)

def wrap_text(text: str, max_line_length: int) -> str:
    return _WordWrapper(text, max_line_length).text

class _WordWrapper:
    def __init__(self, text: str, max_line_length: int) -> None:
        self._max_line_length: int = max_line_length
        self._result_text = ""
        self._line_length: int = 0
        self._indent_length: int = 0
        self._current_word: str = ""
        self._is_in_space: bool = False
        self._number_of_spaces: int = 0

        char: str
        for char in text:
            self._process_char(char)

        if self._line_length + self._number_of_spaces + len(self._current_word) > max_line_length:
            self._result_text += _LINEFEED_CHAR
            self._result_text += _SPACE_CHAR * self._indent_length
            self._result_text += self._current_word
        else:
            self._result_text += _SPACE_CHAR * self._number_of_spaces
            self._result_text += self._current_word

    @property
    def text(self) -> str:
        return self._result_text

    def _process_char(self, char: str) -> None:
        if char == _LINEFEED_CHAR:
            self._process_linefeed()
        elif char == _SPACE_CHAR:
            self._process_space()
        elif char == _TAB_CHAR:
            self._process_indent()
        else:
            self._is_in_space = False
            self._current_word += char

    def _process_linefeed(self) -> None:
        if self._line_length + self._number_of_spaces + len(self._current_word) >= self._max_line_length:
            self._result_text += _LINEFEED_CHAR
            self._result_text += _SPACE_CHAR * self._indent_length
            self._result_text += self._current_word
        else:
            self._result_text += _SPACE_CHAR * self._number_of_spaces
            self._result_text += self._current_word
        self._result_text += _LINEFEED_CHAR
        self._line_length = 0
        self._indent_length = 0
        self._current_word = ""
        self._is_in_space = False
        self._number_of_spaces = 0

    def _process_space(self) -> None:
        if self._is_in_space:
            self._number_of_spaces += 1
        else:
            self._is_in_space = True
            if self._line_length + self._number_of_spaces + len(self._current_word) > self._max_line_length:
                self._result_text += _LINEFEED_CHAR
                self._result_text += _SPACE_CHAR * self._indent_length
                self._result_text += self._current_word
                self._line_length = self._indent_length + len(self._current_word)
                self._current_word = ""
                self._number_of_spaces = 0
            else:
                self._result_text += _SPACE_CHAR * self._number_of_spaces
                self._result_text += self._current_word
                self._line_length += self._number_of_spaces + len(self._current_word)
            self._number_of_spaces = 1
            self._current_word = ""

    def _process_indent(self) -> None:
        self._indent_length = self._line_length + self._number_of_spaces
