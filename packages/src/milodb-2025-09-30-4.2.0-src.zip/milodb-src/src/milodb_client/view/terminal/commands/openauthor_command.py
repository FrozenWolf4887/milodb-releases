# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import sys
from collections.abc import Iterable, Sequence
from typing import override
from milodb_client.config.config_schema import CONFIG_SCHEMA
from milodb_client.database.tease import Tease
from milodb_client.query.tease_match import TeaseMatch
from milodb_client.util.launcher import launch
from milodb_client.view.terminal.commands.database_support import try_create_list_of_tease_matches_from_ref_ids
from milodb_common.config.framework import IConfigEnumLeaf, IConfigLeaf
from milodb_common.config.i_launch_config import ILaunchConfig, LaunchOption
from milodb_common.output.print.i_printer import IPrinter
from milodb_common.parser import arg
from milodb_common.parser.arg_token_stream import ArgTokenStream
from milodb_common.parser.ref_id import AuthorId, RefId
from milodb_common.util import enums
from milodb_common.util.get_url import get_url_of_author
from milodb_common.view.terminal.command_framework.i_command import CommandLoaderResult
from milodb_common.view.terminal.command_framework.i_help_info import IHelpInfo

_CONFIG_LAUNCH_OPTION: IConfigEnumLeaf[LaunchOption] = \
    CONFIG_SCHEMA.commands.open.windows.launch_option if sys.platform == 'win32' else \
    CONFIG_SCHEMA.commands.open.linux.launch_option
_CONFIG_LAUNCH_COMMAND: IConfigLeaf = \
    CONFIG_SCHEMA.commands.open.windows.custom_launch_command if sys.platform == 'win32' else \
    CONFIG_SCHEMA.commands.open.linux.custom_launch_command

_CONFIG_HELP_TEXT: str = (
    "Config:\r"
    f"  \t'{_CONFIG_LAUNCH_OPTION.full_path}'\r"
    "    \tDetermines how the web browser is launched to open the links. The options"
    f" are {enums.lowercase_names(_CONFIG_LAUNCH_OPTION.enum_class)}.\r"
    f"  \t'{_CONFIG_LAUNCH_COMMAND.full_path}'\r"
    f"    \tWhen '{_CONFIG_LAUNCH_OPTION.key_name}' is set to"
    f" '{_CONFIG_LAUNCH_OPTION.enum_class.CUSTOM.name.lower()}'"
    " this specifies the custom command to be executed where the following symbol can be"
    " specified:\r"
    "      $u  \tURL to the author's profile"
)

def load(arg_token_stream: ArgTokenStream, list_of_teases: Iterable[Tease], list_of_tease_matches: Iterable[TeaseMatch], launch_config: ILaunchConfig, normal_printer: IPrinter, warning_printer: IPrinter, error_printer: IPrinter, debug_printer: IPrinter) -> CommandLoaderResult:
    list_of_ref_ids: list[RefId] = []
    list_of_author_ids: list[int] = []

    ref_id: RefId
    for ref_id in arg.pop_minimum_list(arg_token_stream, 1, arg.REF_ID):
        if isinstance(ref_id, AuthorId):
            list_of_author_ids.append(ref_id.author_id)
        else:
            list_of_ref_ids.append(ref_id)

    return CommandLoaderResult(
        lambda: execute(list_of_ref_ids, list_of_author_ids, list_of_teases, list_of_tease_matches, launch_config, normal_printer, warning_printer, error_printer, debug_printer),
        [],
    )

def execute(list_of_ref_ids: Iterable[RefId], list_of_author_ids: Iterable[int], list_of_teases: Iterable[Tease], list_of_tease_matches: Iterable[TeaseMatch], launch_config: ILaunchConfig, normal_printer: IPrinter, warning_printer: IPrinter, error_printer: IPrinter, debug_printer: IPrinter) -> None:
    list_of_tease_matches_to_open: Sequence[TeaseMatch] | None = None
    is_ref_id_list_reasonable: bool = True
    if list_of_ref_ids:
        list_of_tease_matches_to_open = try_create_list_of_tease_matches_from_ref_ids(list_of_teases, list_of_tease_matches, list_of_ref_ids, error_printer)

        if list_of_tease_matches_to_open:
            tease_match: TeaseMatch
            for tease_match in list_of_tease_matches_to_open:
                if tease_match.tease.author.has_author:
                    author_url_for_tease: str = get_url_of_author(tease_match.tease.author.author_id)
                    launch(launch_config, None, author_url_for_tease, normal_printer, warning_printer, error_printer, debug_printer)
                else:
                    error_printer.writeln(f"Tease id '{tease_match.tease.get_tease_id()}' has no known author")
        else:
            error_printer.writeln("No teases available from which to open authors")
            is_ref_id_list_reasonable = False

    if is_ref_id_list_reasonable:
        for author_id in list_of_author_ids:
            author_url: str = get_url_of_author(author_id)
            launch(launch_config, None, author_url, normal_printer, warning_printer, error_printer, debug_printer)

class Help(IHelpInfo):
    @override
    def get_one_line_summary(self) -> str:
        return "Opens a specified author profile in a web browser"

    @override
    def get_detailed_summary(self) -> str:
        return (
            "Arguments: <list of RefIds>\n"
            "Opens one or more author profiles in a web browser from the list of RefIds."
            " This effectively opens the link to the author profile on Milovana.\n"
            "RefIds can be an index into the list of matches such as '3', a teaseId such as"
            " '#38664', or an authorId such as '@43937'.\n"
            f"{_CONFIG_HELP_TEXT}\n"
            "Example:\r"
            "  \tOpen an author's profile for a tease by index in the match list\r"
            "  > \topenauthor 3\r"
            "Example:\r"
            "  \tOpen am author's profile for a specific teaseId\r"
            "  > \topenauthor #16830\r"
            "Example:\r"
            "  \tOpen the profile of a specific authorId\r"
            "  > \topenauthor @43937\n"
            "See also:\r"
            "  \topen, debug, url, urlauthor"
        )
