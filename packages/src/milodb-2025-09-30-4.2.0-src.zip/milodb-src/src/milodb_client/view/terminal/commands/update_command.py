# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from __future__ import annotations
import time
from enum import Enum
from pathlib import Path
from typing import TYPE_CHECKING, override
import prompt_toolkit
from milodb_client.config.config_schema import CONFIG_SCHEMA
from milodb_client.updater.cached_remote_update_data import CachedRemoteUpdateData
from milodb_client.updater.i_temp_directory import ITempDirectory, ITempDirectoryCreator, TempDirectoryError
from milodb_client.updater.prepare_update import PrepareUpdateError, prepare_update
from milodb_client.updater.update_potential import UpdatePotential
from milodb_client.updater.update_strategy import BackupFileSet, ConfigFileChanges, CoreFileChanges, FileRename, UpdateStrategy, UpdateStrategyError, determine_update_strategy
from milodb_common.parser import arg
from milodb_common.parser.candidate_text import CandidateText
from milodb_common.util.unit_size import UnitSizeText, unit_size
from milodb_common.view.terminal.command_framework.i_command import CommandLoaderResult
from milodb_common.view.terminal.command_framework.i_help_info import IHelpInfo
if TYPE_CHECKING:
    from collections.abc import Callable, Iterable, Mapping
    from milodb_client.config.update_config import UpdateConfig
    from milodb_client.startup.shutdown_action import IShutdownAction
    from milodb_client.updater.i_file_hasher import IFileHasher
    from milodb_client.updater.i_file_tester import IFileTester
    from milodb_client.updater.manifest.common_manifest import ILaunchFile
    from milodb_client.updater.manifest.local_manifest import ILocalManifest
    from milodb_client.updater.manifest.update_directory import IAsset, IAssetRegister
    from milodb_client.updater.manifest.version_manifest import ICoreFile, IVariant, IVersion
    from milodb_common.internet.i_scraper import IUrlScraperFactory
    from milodb_common.output.print.i_printer import IPrinter
    from milodb_common.parser.arg_token_stream import ArgTokenStream
    from milodb_common.util.ref import IRef
    from milodb_common.view.terminal.command_framework.quit_flag import QuitFlag

_CONFIG_HELP_TEXT: str = (
    "Config:\r"
    f"  \t'{CONFIG_SCHEMA.update.backup_directory.full_path}'\r"
    "    \tDirectory in which to store a backup of the existing application and configuration files"
    f" before performing the update.\r"
    f"  \t'{CONFIG_SCHEMA.update.update_directory_url.full_path}'\r"
    f"    \tThe remote server URL hosting the update metadata and assets.\n"
)

def load(arg_token_stream: ArgTokenStream, local_manifest: ILocalManifest | None, update_config: UpdateConfig, file_hasher: IFileHasher, file_tester: IFileTester, temp_directory_creator: ITempDirectoryCreator, url_scraper_factory: IUrlScraperFactory, quit_flag: QuitFlag, ref_shutdown_action: IRef[IShutdownAction | None], normal_printer: IPrinter, warning_printer: IPrinter, error_printer: IPrinter) -> CommandLoaderResult:
    def load_default_subcommand() -> CommandLoaderResult:
        return CommandLoaderResult(
            lambda: execute_update(
                local_manifest,
                update_config,
                file_hasher,
                file_tester,
                temp_directory_creator,
                url_scraper_factory,
                quit_flag,
                ref_shutdown_action,
                normal_printer,
                warning_printer,
                error_printer,
                variant_name = None,
            ),
            CandidateText.space_delimited_list(map_of_subcommand_to_loader.keys()),
        )

    def load_check_subcommand() -> CommandLoaderResult:
        arg.fail_if_not_empty(arg_token_stream)
        return CommandLoaderResult(
            lambda: execute_check(
                local_manifest,
                update_config,
                file_hasher,
                file_tester,
                url_scraper_factory,
                normal_printer,
                warning_printer,
                error_printer,
            ),
            [],
        )

    def load_list_subcommand() -> CommandLoaderResult:
        list_option: _ListOption = arg.pop(arg_token_stream, arg.DictValue({
            'versions': _ListOption.VERSIONS,
            'variants': _ListOption.VARIANTS,
            'all': _ListOption.ALL,
        }, 'list option'))
        arg.fail_if_not_empty(arg_token_stream)
        return CommandLoaderResult(
            lambda: execute_list(local_manifest, update_config, url_scraper_factory, normal_printer, warning_printer, error_printer, list_option),
            [],
        )

    def load_switch_subcommand() -> CommandLoaderResult:
        variant_name: str = arg.pop(arg_token_stream, arg.Text('variant name'))
        arg.fail_if_not_empty(arg_token_stream)
        return CommandLoaderResult(
            lambda: execute_update(
                local_manifest,
                update_config,
                file_hasher,
                file_tester,
                temp_directory_creator,
                url_scraper_factory,
                quit_flag,
                ref_shutdown_action,
                normal_printer,
                warning_printer,
                error_printer,
                variant_name = variant_name),
            [],
        )

    map_of_subcommand_to_loader: Mapping[str, Callable[[], CommandLoaderResult]] = {
        'check': load_check_subcommand,
        'list': load_list_subcommand,
        'switch': load_switch_subcommand,
    }

    loader: Callable[[], CommandLoaderResult] | None = arg.pop_optional(arg_token_stream, arg.DictValue(map_of_subcommand_to_loader, 'subcommand'))
    if not loader:
        loader = load_default_subcommand
    return loader()

def execute_check(local_manifest: ILocalManifest | None, update_config: UpdateConfig, file_hasher: IFileHasher, file_tester: IFileTester, url_scraper_factory: IUrlScraperFactory, normal_printer: IPrinter, warning_printer: IPrinter, error_printer: IPrinter) -> None:
    update_strategy: UpdateStrategy | None = _try_get_update_strategy(
        update_config.update_directory_url,
        local_manifest,
        file_hasher,
        file_tester,
        url_scraper_factory,
        normal_printer,
        error_printer,
    )

    if update_strategy:
        update_potential: UpdatePotential = UpdatePotential(update_strategy)
        if update_potential.is_update_available:
            _print_update_strategy(update_strategy, normal_printer, warning_printer)
            normal_printer.writeln()
            normal_printer.writeln(f'** {update_potential.message} **')
        else:
            normal_printer.writeln()
            normal_printer.writeln(update_potential.message)

def execute_update(local_manifest: ILocalManifest | None, update_config: UpdateConfig, file_hasher: IFileHasher, file_tester: IFileTester, temp_directory_creator: ITempDirectoryCreator, url_scraper_factory: IUrlScraperFactory, quit_flag: QuitFlag, ref_shutdown_action: IRef[IShutdownAction | None], normal_printer: IPrinter, warning_printer: IPrinter, error_printer: IPrinter, *, variant_name: str | None) -> None:
    update_strategy: UpdateStrategy | None = _try_get_update_strategy(
        update_config.update_directory_url,
        local_manifest,
        file_hasher,
        file_tester,
        url_scraper_factory,
        normal_printer,
        error_printer,
        requested_variant_name = variant_name,
    )

    if update_strategy:
        update_potential: UpdatePotential = UpdatePotential(update_strategy)
        if update_potential.is_update_available:
            _print_update_strategy(update_strategy, normal_printer, warning_printer)
            normal_printer.writeln()
            normal_printer.writeln(f'** {update_potential.message} **')
            normal_printer.writeln()
            answer: str = prompt_toolkit.prompt('Would you like to update? [y/n]: ')
            if answer.strip().lower() in {'y', 'yes'}:
                _prepare_update_and_restart(update_config, update_strategy, temp_directory_creator, url_scraper_factory, quit_flag, ref_shutdown_action, normal_printer, error_printer)
        else:
            normal_printer.writeln()
            normal_printer.writeln(update_potential.message)

class _ListOption(Enum):
    VERSIONS = 0
    VARIANTS = 1
    ALL = 2

def execute_list(local_manifest: ILocalManifest | None, update_config: UpdateConfig, url_scraper_factory: IUrlScraperFactory, normal_printer: IPrinter, warning_printer: IPrinter, error_printer: IPrinter, list_option: _ListOption) -> None:
    remote_update_data: CachedRemoteUpdateData | None = CachedRemoteUpdateData.fetch(update_config.update_directory_url, url_scraper_factory, normal_printer, error_printer)
    if not remote_update_data:
        return

    normal_printer.writeln()

    match list_option:
        case _ListOption.VERSIONS:
            if not local_manifest:
                warning_printer.writeln('Local manifest version information is not available, therefore the current variant is not known')
            else:
                variant: IVariant | None = remote_update_data.version_manifest.variants.get(local_manifest.variant_name)
                if variant is None:
                    error_printer.writeln(f"Variant name '{local_manifest.variant_name}'of current software is not listed in the remote version manifest")
                else:
                    _print_versions_of_variant(variant, normal_printer)

        case _ListOption.VARIANTS:
            _print_list_of_variants(remote_update_data.version_manifest.variants.values(), normal_printer)

        case _ListOption.ALL:
            for index, variant in enumerate(remote_update_data.version_manifest.variants.values()):
                if index:
                    normal_printer.writeln()
                _print_versions_of_variant(variant, normal_printer)

def _prepare_update_and_restart(update_config: UpdateConfig, update_strategy: UpdateStrategy, temp_directory_creator: ITempDirectoryCreator, web_scraper_factory: IUrlScraperFactory, quit_flag: QuitFlag, ref_shutdown_action: IRef[IShutdownAction | None], normal_printer: IPrinter, error_printer: IPrinter) -> None:
    try:
        temp_directory: ITempDirectory = temp_directory_creator.create()
    except TempDirectoryError as ex:
        normal_printer.writeln()
        error_printer.writeln(f'Failed to prepare update: {ex}')
        return
    normal_printer.writeln(f"Created update temp directory '{temp_directory.path}'")

    try:
        shutdown_action: IShutdownAction = prepare_update(
            update_strategy = update_strategy,
            backup_directory = update_config.backup_directory,
            time_stamp = time.localtime(),
            directory_url = update_config.update_directory_url,
            asset_register = update_strategy.asset_register,
            temp_directory = temp_directory,
            url_scraper_factory = web_scraper_factory,
            normal_printer = normal_printer,
        )
    except PrepareUpdateError as ex:
        normal_printer.writeln()
        error_printer.writeln(f'Failed to prepare update: {ex}')
    else:
        ref_shutdown_action.set(shutdown_action)
        quit_flag.set()

def _try_get_update_strategy(update_directory_url: str, local_manifest: ILocalManifest | None, file_hasher: IFileHasher, file_tester: IFileTester, url_scraper_factory: IUrlScraperFactory, normal_printer: IPrinter, error_printer: IPrinter, *, requested_variant_name: str | None=None) -> UpdateStrategy | None:
    if not local_manifest:
        error_printer.writeln('Local manifest version information is not available; update impossible')
        return None

    remote_update_data: CachedRemoteUpdateData | None = CachedRemoteUpdateData.fetch(update_directory_url, url_scraper_factory, normal_printer, error_printer)
    if not remote_update_data:
        return None

    try:
        update_strategy: UpdateStrategy = determine_update_strategy(Path(), None, requested_variant_name, local_manifest, remote_update_data.version_manifest, remote_update_data.update_directory.asset_register, file_hasher, file_tester)
    except UpdateStrategyError as ex:
        error_printer.writeln('Failed to determine update strategy')
        normal_printer.writeln(f'Cause: {ex}')
    else:
        return update_strategy

    return None

def _print_update_strategy(update_strategy: UpdateStrategy, normal_printer: IPrinter, warning_printer: IPrinter) -> None:
    normal_printer.writeln()
    normal_printer.writeln(f"Current version: {update_strategy.local_manifest.variant_name} / {update_strategy.local_manifest.version_number}")
    normal_printer.writeln(f" Target version: {update_strategy.target_variant.name} / {update_strategy.target_version.number}")
    _print_file_changes(update_strategy.core_file_changes, update_strategy.config_file_changes, update_strategy.asset_register, normal_printer)
    _print_backup_set(update_strategy.backup_file_set, normal_printer)
    _print_launch_executable(update_strategy.launch_executable, normal_printer, warning_printer)
    if update_strategy.list_of_newer_versions:
        _print_change_logs(update_strategy.list_of_newer_versions, normal_printer)

def _print_change_logs(list_of_versions: Iterable[IVersion], printer: IPrinter) -> None:
    printer.writeln()
    printer.writeln('** Change Log **')
    printer.writeln()
    index: int
    version: IVersion
    for index, version in enumerate(sorted(list_of_versions, key=lambda version: version.number)):
        if index > 0:
            printer.writeln()
        printer.writeln(f'{version.number}, {version.date}')
        if version.log:
            printer.writeln()
            printer.writeln(version.log)

def _print_file_changes(core_file_changes: CoreFileChanges, config_file_changes: ConfigFileChanges, asset_register: IAssetRegister, printer: IPrinter) -> None:
    printer.writeln()
    printer.writeln('** File Differences **')
    printer.writeln()
    printer.writeln(f' {"Type":<8}  {"File":<20}  {"Status":<12}  {"Action":<12}  Size')
    printer.writeln('-' * 69)

    core_file: ICoreFile
    for core_file in core_file_changes.list_of_new_files_to_acquire:
        printer.writeln(f' {"Core":<8}  {core_file.filename!s:<20}  {"New":<12}  {"Acquire":<12}  {_asset_file_size(core_file, asset_register):>7}')
    for core_file in core_file_changes.list_of_changed_files_to_acquire:
        printer.writeln(f' {"Core":<8}  {core_file.filename!s:<20}  {"Changed":<12}  {"Acquire":<12}  {_asset_file_size(core_file, asset_register):>7}')
    for core_file in core_file_changes.list_of_missing_files_to_acquire:
        printer.writeln(f' {"Core":<8}  {core_file.filename!s:<20}  {"Missing":<12}  {"Reacquire":<12}  {_asset_file_size(core_file, asset_register):>7}')
    filename: Path
    for filename in core_file_changes.list_of_files_that_are_deprecated:
        printer.writeln(f' {"Core":<8}  {filename!s:<20}  {"Redundant":<12}  Delete')
    for core_file in core_file_changes.list_of_unchanged_files:
        printer.writeln(f' {"Core":<8}  {core_file.filename!s:<20}  {"Unchanged":<12}  None')

    file_rename: FileRename
    for file_rename in config_file_changes.list_of_files_to_rename:
        printer.writeln(f' {"Config":<8}  {file_rename.original_filename!s:<20}  {"Renamed":<12}  Rename to {file_rename.new_filename!s}')
    for filename in config_file_changes.list_of_files_that_are_deprecated:
        printer.writeln(f' {"Config":<8}  {filename!s:<20}  {"Redundant":<12}  Delete')
    for filename in config_file_changes.list_of_files_to_leave:
        printer.writeln(f' {"Config":<8}  {filename!s:<20}  {"Relevant":<12}  None')
    for filename in config_file_changes.list_of_new_files:
        printer.writeln(f' {"Config":<8}  {filename!s:<20}  {"New":<12}  None')

def _print_backup_set(backup_file_set: BackupFileSet, printer: IPrinter) -> None:
    printer.writeln()
    printer.writeln('** Files to Backup **')
    printer.writeln()
    printer.writeln(f' {"Type":<8}  File')
    printer.writeln('-' * 59)

    filename: Path
    for filename in backup_file_set.list_of_core_files_to_backup:
        printer.writeln(f' {"Core":<8}  {filename}')
    for filename in backup_file_set.list_of_config_files_to_backup:
        printer.writeln(f' {"Config":<8}  {filename}')
    for filename in backup_file_set.list_of_clobbered_files_to_backup:
        printer.writeln(f' {"Unknown":<8}  {filename}')

def _print_launch_executable(launch_executable: ILaunchFile | None, normal_printer: IPrinter, warning_printer: IPrinter) -> None:
    normal_printer.writeln()
    if launch_executable:
        normal_printer.writeln(f"Target executable: '{launch_executable.filename}' for OS '{launch_executable.operating_system}'")
    else:
        warning_printer.writeln('There is no main executable for the current operating system in the chosen target variant / version.')
        normal_printer.writeln('Following the update, the application will close and there can be no attempt to start the new application.')
        normal_printer.writeln('This problem can occur if you upgrade to a variant or version that supports a different operating system.')

def _asset_file_size(core_file: ICoreFile, asset_register: IAssetRegister) -> str:
    asset: IAsset | None = asset_register.assets.get(core_file.digest)
    if not asset:
        return 'unknown'
    unit_size_text: UnitSizeText = unit_size(asset.size)
    return f'{unit_size_text.size_text} {unit_size_text.unit_text}'

def _print_versions_of_variant(variant: IVariant, normal_printer: IPrinter) -> None:
    normal_printer.writeln('=' * 40)
    normal_printer.writeln(f"Variant: '{variant.name}'")
    normal_printer.writeln(f"Summary: '{variant.summary}'")
    normal_printer.writeln('-' * 40)

    version: IVersion
    for version in variant.versions.values():
        normal_printer.writeln(f'{version.number}, {version.date}')
        log_line: str
        for log_line in version.log.splitlines():
            normal_printer.writeln(f'    {log_line}')

def _print_list_of_variants(list_of_variants: Iterable[IVariant], normal_printer: IPrinter) -> None:
    index: int
    variant: IVariant
    for index, variant in enumerate(list_of_variants):
        if index:
            normal_printer.writeln()
        normal_printer.writeln('=' * 40)
        normal_printer.writeln(f"Variant: '{variant.name}'")
        normal_printer.writeln(f"Summary: '{variant.summary}'")

class Help(IHelpInfo):
    @override
    def get_one_line_summary(self) -> str:
        return "Checks for and applies updates to the software"

    @override
    def get_detailed_summary(self) -> str:
        return (
            "Arguments: [check|list|switch]\r"
            "  check\r"
            "  list    versions|variants|all\r"
            "  switch  <variant name>\n"
            "When used without arguments, it will look for a new version of the software available for"
            " download and installation. It will prompt before actually attempting the update. When"
            " specifying 'check', it will not prompt to perform an update.\n"
            "The 'list' subcommand shows information from the remote version manifest, showing the"
            " versions from the currently active variant when 'versions' is specified.\n"
            "The 'switch' subcommand can switch to an alternative variant of the application if there"
            " is more than one available. The list of available variants can be found with"
             " 'update list variants'.\r"
            "Note that TAB completion won't work for the variant name because the variants are only"
             " know once the version manifest has been retrieved from the server.\n"
            "The metadata related to updating is downloaded once and kept in memory, hence subsequent"
            " calls to update will not repeatedly download the information.\n"
            "Before attempting the update, the existing files are backed up. The assets for new and"
            " updated files are stored in a temporary directory that is automatically removed after a"
            " successful update.\n"
            f"{_CONFIG_HELP_TEXT}"
            "Example:\r"
            "  \tCheck to see if there are updates available\r"
            "  > \tupdate check\r"
            "Example:\r"
            "  \tCheck and prompt to update if an update is available\r"
            "  > \tupdate\r"
            "Example:\r"
            "  \tList the different available variants of the application\r"
            "  > \tupdate list variants\r"
        )
