# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from collections.abc import Iterable, Sequence
from typing import override
from milodb_client.query.tease_match import TeaseMatch
from milodb_client.util.tease_match_sorter import ITeaseMatchSorter
from milodb_client.view.terminal.util.named_sort_keys import NamedSortKey, OrderedNamedSortKey
from milodb_common.output.print.i_printer import IPrinter
from milodb_common.parser import arg
from milodb_common.parser.arg import IArgParser
from milodb_common.parser.arg_token_stream import ArgTokenStream
from milodb_common.parser.arg_type import ArgType
from milodb_common.parser.candidate_text import CandidateText
from milodb_common.parser.token import Token
from milodb_common.util.ref import IRef
from milodb_common.view.terminal.command_framework.i_command import CommandLoaderResult
from milodb_common.view.terminal.command_framework.i_help_info import IHelpInfo

def load(arg_token_stream: ArgTokenStream, ref_list_of_tease_matches: IRef[Sequence[TeaseMatch]], tease_match_sorter: ITeaseMatchSorter, ref_list_of_active_sort_keys: IRef[Sequence[OrderedNamedSortKey]], list_of_available_sort_keys: Sequence[NamedSortKey], normal_printer: IPrinter) -> CommandLoaderResult:
    sort_key_parser: _SortKeyParser = _SortKeyParser(list_of_available_sort_keys)
    new_list_of_active_sort_keys: Sequence[OrderedNamedSortKey] = arg.pop_list(arg_token_stream, sort_key_parser)
    if new_list_of_active_sort_keys:
        return CommandLoaderResult(
            lambda: execute_change(new_list_of_active_sort_keys, ref_list_of_tease_matches, tease_match_sorter, ref_list_of_active_sort_keys, normal_printer),
            sort_key_parser.get_list_of_candidate_text(),
        )
    return CommandLoaderResult(
        lambda: execute_print(ref_list_of_active_sort_keys.get(), list_of_available_sort_keys, normal_printer),
        sort_key_parser.get_list_of_candidate_text(),
    )

def execute_print(list_of_active_sort_keys: Sequence[OrderedNamedSortKey], list_of_available_sort_keys: Sequence[NamedSortKey], normal_printer: IPrinter) -> None:
    normal_printer.writeln(f"Current sorting keys are {[ ('' if sort_key.is_ascending else '-') + sort_key.named_sort_key.name for sort_key in list_of_active_sort_keys ]}")
    normal_printer.writeln(f"Available keys are {sorted([ sort_key.name for sort_key in list_of_available_sort_keys ])}")

def execute_change(new_list_of_active_sort_keys: Sequence[OrderedNamedSortKey], ref_list_of_tease_matches: IRef[Sequence[TeaseMatch]], tease_match_sorter: ITeaseMatchSorter, ref_list_of_active_sort_keys: IRef[Sequence[OrderedNamedSortKey]], normal_printer: IPrinter) -> None:
    ref_list_of_active_sort_keys.set(new_list_of_active_sort_keys)
    normal_printer.writeln(f"Changed sorting keys to {[ ('' if sort_key.is_ascending else '-') + sort_key.named_sort_key.name for sort_key in ref_list_of_active_sort_keys.get() ]}")
    ref_list_of_tease_matches.set(tease_match_sorter.sort(ref_list_of_tease_matches.get(), ref_list_of_active_sort_keys.get()))

class Help(IHelpInfo):
    def __init__(self, list_of_available_sort_keys: Iterable[NamedSortKey]) -> None:
        self._list_of_available_sort_keys = list_of_available_sort_keys

    @override
    def get_one_line_summary(self) -> str:
        return "Sorts the list of teases by specific fields"

    @override
    def get_detailed_summary(self) -> str:
        sort_key: NamedSortKey
        longest_sort_key_name_length: int = max(len(sort_key.name) for sort_key in self._list_of_available_sort_keys) if self._list_of_available_sort_keys else 0
        sort_key_help_text: str = ''
        for sort_key in self._list_of_available_sort_keys:
            if sort_key_help_text:
                sort_key_help_text += '\r'
            sort_key_help_text += f'  {sort_key.name:<{longest_sort_key_name_length}} : \t{sort_key.description}'

        return (
            "Arguments: [list of sort keys]\n"
            "Sets the sorting order for the display of teases. More than one key can be"
            " specified to determine secondary, tertiary, etc. ordering.\n"
            "Keys:\r"
            f'{sort_key_help_text}\n'
            "Keys can be prefixed with '-' to indicate a descending order, otherwise the"
            " order defaults to ascending.\n"
            "When used without arguments, the current sorting keys are shown.\n"
            "Example:\r"
            "  \tSort by teaseId\r"
            "  > \tsort teaseId\r"
            "Example:\r"
            "  \tSort by rating (ascending) and date (descending)\r"
            "  > \tsort rating -date\n"
            "See also:\r"
            "  \tlist\n"
            )

class _SortKeyParser(IArgParser[OrderedNamedSortKey]):
    def __init__(self, list_of_available_sort_keys: Sequence[NamedSortKey]) -> None:
        self._map_of_names_to_sort_keys: dict[str, NamedSortKey] = {}
        sort_key: NamedSortKey
        for sort_key in list_of_available_sort_keys:
            self._map_of_names_to_sort_keys[sort_key.name] = sort_key
            self._map_of_names_to_sort_keys[f'-{sort_key.name}'] = sort_key
        self._arg_dict_value: arg.DictValue[NamedSortKey] = arg.DictValue(self._map_of_names_to_sort_keys, self.get_expecting_type_description())

    @property
    @override
    def arg_type(self) -> ArgType:
        return ArgType.ARG_KEYWORD

    @override
    def get_expecting_type_description(self) -> str:
        return 'sort key'

    @override
    def get_list_of_candidate_text(self) -> Sequence[CandidateText]:
        return CandidateText.space_delimited_list(self._map_of_names_to_sort_keys)

    @override
    def parse(self, token: Token) -> OrderedNamedSortKey:
        sort_key: NamedSortKey = self._arg_dict_value.parse(token)
        del self._map_of_names_to_sort_keys[sort_key.name]
        del self._map_of_names_to_sort_keys[f'-{sort_key.name}']
        is_ascending: bool = token.text[0] != '-'
        return OrderedNamedSortKey(sort_key, is_ascending=is_ascending)
