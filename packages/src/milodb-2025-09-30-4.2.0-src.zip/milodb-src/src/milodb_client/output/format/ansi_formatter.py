# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from collections.abc import Iterable, Mapping
from typing import override
from milodb_client.config.ansi_config import AnsiConfig
from milodb_client.database.tease import Tease, TeaseProperty, TeaseStrListProperty, TotmStatus
from milodb_client.database.tease_page import TeasePage
from milodb_client.output.format.i_formatter import IFormatter
from milodb_client.output.support import EllipsisLocation, ellipsify_text, get_list_of_indexed_metadata_indices, get_list_of_metadata_indices, get_matching_indices_for_page, iterate_through_indices, iterate_through_lines
from milodb_client.query.field_match import IFieldMatch
from milodb_client.query.tease_match import TeaseMatch
from milodb_common.output.print.i_printer import IPrinter
from milodb_common.util.get_url import get_url_of_author, get_url_of_tease

_MAP_OF_TOTM_STATUS_TO_TEXT: Mapping[TotmStatus, str] = {
    TotmStatus.NONE: ' ',
    TotmStatus.NOMINEE: 'n',
    TotmStatus.WINNER: 'w',
}

_TEXT_SEPARATOR_LINE: str = 40 * '-'

class AnsiFormatter(IFormatter):
    def __init__(self, ansi_config: AnsiConfig, printer: IPrinter, *, use_highlighting: bool, ellipsis_max_width: int | None, show_pagerefs: bool) -> None:
        self._ansi_config: AnsiConfig = ansi_config
        self._printer: IPrinter = printer
        self._use_highlighting: bool = use_highlighting
        self._ellipsis_max_width: int | None = ellipsis_max_width
        self._show_pagerefs: bool = show_pagerefs

    @override
    def print_list_of_teases(self, list_of_tease_matches: Iterable[TeaseMatch]) -> None:
        tease_match: TeaseMatch
        for tease_match in list_of_tease_matches:
            self._print_oneline_of_tease(tease_match)

    @override
    def print_summary_of_tease(self, tease_match: TeaseMatch) -> None:
        match_index: str = str(tease_match.index_of_match) if tease_match.index_of_match else 'none'
        tease_id: int = tease_match.tease.get_tease_id()
        author_id: int = tease_match.tease.get_author_id()
        formatted_tease_id: str = self._highlight_metadata(tease_match, Tease.get_tease_id, 6, '#')
        formatted_tease_title: str = self._highlight_metadata(tease_match, Tease.get_title)
        formatted_author_id: str = self._highlight_metadata(tease_match, Tease.get_author_id, 6, '@') if tease_match.tease.author.has_author else 'unknown'
        formatted_author_name: str = f"'{self._highlight_metadata(tease_match, Tease.get_author_name)}'" if tease_match.tease.author.has_author else 'unknown'
        formatted_tease_date: str = self._highlight_metadata(tease_match, Tease.get_date)
        formatted_tease_type: str = self._highlight_metadata(tease_match, Tease.get_type, 7)
        formatted_tease_rating: str = self._highlight_metadata(tease_match, Tease.get_rating_value, 7)
        formatted_tags: str = ', '.join(self._highlight_metadata_string_list(tease_match, Tease.get_list_of_tags, include_matching_only=False))
        formatted_summary: str = self._highlight_metadata(tease_match, Tease.get_summary)
        deleted_text: str = f'[\x1b[{self._ansi_config.deleted_heading_colour}mDELETED\x1b[0m] ' if tease_match.tease.is_deleted() else ''
        author_gone_text: str = f'[\x1b[{self._ansi_config.author_gone_heading_colour}mGONE\x1b[0m] ' if tease_match.tease.author.has_gone else ''
        url_of_tease: str = get_url_of_tease(tease_id)
        url_of_author: str = get_url_of_author(author_id) if tease_match.tease.author.has_author else 'link unavailable (author unknown)'
        self._printer.writeln(f"\x1b[{self._ansi_config.index_heading_colour}mIndex   \x1b[0m{match_index:>7}   \x1b[{self._ansi_config.hits_heading_colour}mHits   \x1b[0m{tease_match.get_match_count()}")
        self._printer.writeln(f"\x1b[{self._ansi_config.tease_heading_colour}mTease   \x1b[0m{formatted_tease_id}   \x1b[{self._ansi_config.tease_heading_colour}mTitle  \x1b[0m{deleted_text}'{formatted_tease_title}'")
        self._printer.writeln(f"\x1b[{self._ansi_config.author_heading_colour}mAuthor  \x1b[0m{formatted_author_id}   \x1b[{self._ansi_config.author_heading_colour}mName   \x1b[0m{author_gone_text}{formatted_author_name}")
        self._printer.writeln(f"\x1b[{self._ansi_config.type_heading_colour}mType    \x1b[0m{formatted_tease_type}   \x1b[{self._ansi_config.date_heading_colour}mDate   \x1b[0m{formatted_tease_date}")
        self._printer.writeln(f"\x1b[{self._ansi_config.rating_heading_colour}mRating  \x1b[0m{formatted_tease_rating}   \x1b[{self._ansi_config.tags_heading_colour}mTags   \x1b[0m{formatted_tags}")
        self._printer.writeln(f"\x1b[{self._ansi_config.tease_heading_colour}mTease   \x1b[0m{url_of_tease}")
        if tease_match.tease.author.has_author:
            self._printer.writeln(f"\x1b[{self._ansi_config.author_heading_colour}mAuthor  \x1b[0m{url_of_author}")
        self._printer.writeln(f"\x1b[{self._ansi_config.summary_heading_colour}mSummary\x1b[0m")
        self._printer.writeln(formatted_summary or 'None')

    @override
    def print_text_of_page(self, tease_match: TeaseMatch, page: TeasePage) -> None:
        if self._show_pagerefs:
            self._printer.writeln(self._page_separator(page))
        formatted_text: str | None = self._try_highlight_page_text(page, tease_match, abbreviate_text=bool(self._ellipsis_max_width))
        if formatted_text is None:
            if self._ellipsis_max_width:
                formatted_text = self._ellipsify_and_escape_text_item(page.text, is_first_item=True, is_last_item=True, ellipsis_max_width=self._ellipsis_max_width)
            else:
                formatted_text = _escape_text(page.text)
        self._printer.writeln(formatted_text)

    @override
    def print_all_text_of_list_of_teases(self, list_of_tease_matches: Iterable[TeaseMatch]) -> None:
        index: int
        tease_match: TeaseMatch
        for index, tease_match in enumerate(list_of_tease_matches):
            if index > 0:
                self._printer.writeln()
            self.print_summary_of_tease(tease_match)
            self.print_all_text_of_tease(tease_match, include_header_and_footer=True)

    @override
    def print_matching_text_of_list_of_teases(self, list_of_tease_matches: Iterable[TeaseMatch]) -> None:
        index: int
        tease_match: TeaseMatch
        for index, tease_match in enumerate(list_of_tease_matches):
            if index > 0:
                self._printer.writeln()
            self.print_summary_of_tease(tease_match)
            self.print_matching_text_of_tease(tease_match, include_header_and_footer=True)

    @override
    def print_all_text_of_tease(self, tease_match: TeaseMatch, *, include_header_and_footer: bool) -> None:
        index: int
        page: TeasePage | None = None
        for index, page in enumerate(tease_match.tease.get_list_of_pages()):
            if not index and include_header_and_footer:
                self._printer.writeln(f'\x1b[{self._ansi_config.matching_text_heading_colour}mText\x1b[0m')
            self._printer.writeln(self._page_separator(page if self._show_pagerefs else None))
            formatted_text: str | None = self._try_highlight_page_text(page, tease_match, abbreviate_text=False)
            if formatted_text is None:
                formatted_text = _escape_text(page.text)
            self._printer.writeln(formatted_text)
        if page and include_header_and_footer:
            self._printer.writeln(self._page_separator(None))

    @override
    def print_matching_text_of_tease(self, tease_match: TeaseMatch, *, include_header_and_footer: bool) -> None:
        is_first_match: bool = True
        page: TeasePage | None = None
        for page in tease_match.tease.get_list_of_pages():
            formatted_text: str | None = self._try_highlight_page_text(page, tease_match, abbreviate_text=True)
            if formatted_text:
                if is_first_match:
                    is_first_match = False
                    if include_header_and_footer:
                        self._printer.writeln(f'\x1b[{self._ansi_config.matching_text_heading_colour}mMatching text\x1b[0m')
                self._printer.writeln(self._page_separator(page if self._show_pagerefs else None))
                self._printer.writeln(formatted_text)
        if page and include_header_and_footer:
            self._printer.writeln(self._page_separator(None))

    def _print_oneline_of_tease(self, tease_match: TeaseMatch) -> None:
        match_index: str = str(tease_match.index_of_match) if tease_match.index_of_match else '-'
        hits: str = '*' + str(tease_match.get_match_count())
        formatted_tease_id: str = self._highlight_metadata(tease_match, Tease.get_tease_id, 5, '#')
        formatted_tease_type: str = self._highlight_metadata(tease_match, Tease.get_type)
        formatted_tease_rating: str = self._highlight_metadata(tease_match, Tease.get_rating_value, 3)
        formatted_tease_date: str = self._highlight_metadata(tease_match, Tease.get_date)
        formatted_tease_title: str = self._highlight_metadata(tease_match, Tease.get_title)
        formatted_author_text: str = 'unknown author'
        if tease_match.tease.author.has_author:
            formatted_author_name: str = self._highlight_metadata(tease_match, Tease.get_author_name)
            formatted_author_id: str = self._highlight_metadata(tease_match, Tease.get_author_id)
            formatted_author_text = f"{formatted_author_name}, @{formatted_author_id}"
        totm_text: str = _MAP_OF_TOTM_STATUS_TO_TEXT.get(tease_match.tease.get_totm_status(), ' ')
        deleted_text: str = f'[\x1b[{self._ansi_config.deleted_heading_colour}mDELETED\x1b[0m] ' if tease_match.tease.is_deleted() else ''
        author_gone_text: str = f'[\x1b[{self._ansi_config.author_gone_heading_colour}mGONE\x1b[0m] ' if tease_match.tease.author.has_gone else ''
        self._printer.writeln(
            f'{match_index:>3}:'
            f' {hits:>4}'
            f'  {formatted_tease_id}'
            f'  {formatted_tease_type}'
            f'  {formatted_tease_rating}'
            f'  {totm_text}'
            f'  {formatted_tease_date}'
            f'  {deleted_text}{formatted_tease_title}'
            f' : {author_gone_text}<{formatted_author_text}>')

    def _page_separator(self, page: TeasePage | None) -> str:
        if page:
            plain_text_length: int = len("-- Page: '' ") + len(page.page_ref)
            formatted_text: str = f"-- \x1b[{self._ansi_config.page_heading_colour}mPage\x1b[0m: '\x1b[{self._ansi_config.page_name_colour}m{page.page_ref}\x1b[0m' "
            cut_off_length: int = len(_TEXT_SEPARATOR_LINE) + (len(formatted_text) - plain_text_length)
            formatted_text += _TEXT_SEPARATOR_LINE
            if cut_off_length > 0:
                formatted_text = formatted_text[:cut_off_length]
            return formatted_text
        return _TEXT_SEPARATOR_LINE

    def _highlight_metadata(self, tease_match: TeaseMatch, tease_property: TeaseProperty, width: int = 0, prefix_text: str = '') -> str:
        field_value: str = tease_match.tease.get_text_of_property(tease_property)
        formatted_value: str = self._highlight_text(field_value, get_list_of_metadata_indices(tease_property, tease_match.list_of_field_matches), abbreviate_text=False)

        if width:
            if prefix_text:
                formatted_value = prefix_text + formatted_value

            pad_char_count = abs(width) - len(field_value)
            if pad_char_count > 0:
                if width < 0:
                    formatted_value = formatted_value + (pad_char_count * ' ')
                else:
                    formatted_value = (pad_char_count * ' ') + formatted_value

        return formatted_value

    def _highlight_metadata_string_list(self, tease_match: TeaseMatch, tease_property: TeaseStrListProperty, *, include_matching_only: bool) -> list[str]:
        list_of_formatted_text: list[str] = []

        index_of_block: int
        text_block: str
        for index_of_block, text_block in enumerate(tease_property(tease_match.tease)):
            list_of_indices: Iterable[IFieldMatch.Indices] = get_list_of_indexed_metadata_indices(tease_property, index_of_block, tease_match.list_of_field_matches)
            formatted_text: str | None = None
            if list_of_indices:
                formatted_text = self._highlight_text(text_block, list_of_indices, abbreviate_text=include_matching_only and bool(self._ellipsis_max_width))
            elif not include_matching_only:
                formatted_text = _escape_text(text_block)

            if formatted_text is not None:
                list_of_formatted_text.append(formatted_text)

        return list_of_formatted_text

    def _try_highlight_page_text(self, page: TeasePage, tease_match: TeaseMatch, *, abbreviate_text: bool) -> str | None:
        list_of_indices: Iterable[IFieldMatch.Indices] = get_matching_indices_for_page(page, tease_match.list_of_field_matches)
        if list_of_indices:
            return self._highlight_text(page.text, list_of_indices, abbreviate_text=abbreviate_text and bool(self._ellipsis_max_width))
        return None

    def _highlight_text(self, text: str, list_of_indices: Iterable[IFieldMatch.Indices], *, abbreviate_text: bool) -> str:
        formatted_text = ''

        def on_normal_text(text: str, *, is_first_item: bool, is_last_item: bool) -> None:
            nonlocal formatted_text
            if abbreviate_text and self._ellipsis_max_width:
                formatted_text += self._ellipsify_and_escape_text_item(text, is_first_item=is_first_item, is_last_item=is_last_item, ellipsis_max_width=self._ellipsis_max_width)
            else:
                formatted_text += _escape_text(text)

        def on_matched_text(text: str, *, is_first_item: bool, is_last_item: bool) -> None: # pylint: disable=W0613:unused-argument # noqa: ARG001 Unused function argument
            nonlocal formatted_text
            if self._use_highlighting:
                iterate_through_lines(text, on_highlight_text, on_end_of_line_text)
            else:
                formatted_text += _escape_text(text)

        def on_highlight_text(text: str) -> None:
            nonlocal formatted_text
            formatted_text += f'\x1b[{self._ansi_config.matching_text_colour}m'
            formatted_text += _escape_text(text)
            formatted_text += '\x1b[0m'

        def on_end_of_line_text(text: str) -> None:
            nonlocal formatted_text
            formatted_text += text

        iterate_through_indices(text, list_of_indices, on_normal_text, on_matched_text)

        return formatted_text

    def _ellipsify_and_escape_text_item(self, text: str, *, is_first_item: bool, is_last_item: bool, ellipsis_max_width: int) -> str:
        formatted_text: str = ''

        def on_text(text: str) -> None:
            nonlocal formatted_text
            formatted_text += _escape_text(text)

        def on_ellipsis() -> None:
            nonlocal formatted_text
            formatted_text += f'\x1b[{self._ansi_config.ellipsis_colour}m\u2026\x1b[0m'

        ellipsify_text(text, ellipsis_max_width, EllipsisLocation.from_position(is_first_item=is_first_item, is_last_item=is_last_item), on_text, on_ellipsis)

        return formatted_text

def _escape_text(text: str) -> str:
    return text.replace('\x1b', '')
