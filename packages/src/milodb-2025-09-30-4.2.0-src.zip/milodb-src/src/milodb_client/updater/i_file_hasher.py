# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from abc import ABC, abstractmethod
from pathlib import Path

class HashError(Exception):
    pass

class HashFileNotFoundError(HashError):
    pass

class IFileHasher(ABC):
    @abstractmethod
    def hash_file(self, filepath: Path) -> bytes:
        """Hash the specified file and returns the digest.

        ### Raises:
        - HashFileNotFoundError
            - If the file was not found
        - HashError
            - If there was any error hashing the file
        """
