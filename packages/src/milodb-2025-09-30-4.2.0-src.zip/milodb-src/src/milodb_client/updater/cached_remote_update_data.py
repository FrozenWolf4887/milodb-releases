# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from __future__ import annotations
import json
import urllib.parse
from typing import TYPE_CHECKING
from milodb_client.updater.manifest.i_schema_types import IItem, SchemaLoadError
from milodb_client.updater.manifest.update_directory_schema import UpdateDirectorySchema
from milodb_client.updater.manifest.version_manifest_schema import VersionManifestSchema
if TYPE_CHECKING:
    from milodb_client.updater.manifest.update_directory import IUpdateDirectory
    from milodb_client.updater.manifest.version_manifest import IVersionManifest
    from milodb_common.internet.i_scraper import IUrlScraper, IUrlScraperFactory, ScrapeResult
    from milodb_common.output.print.i_printer import IPrinter

class CachedRemoteUpdateData:
    _cached_update_directory: IUpdateDirectory | None = None
    _cached_version_manifest: IVersionManifest | None = None

    def __init__(self, update_directory: IUpdateDirectory, version_manifest: IVersionManifest) -> None:
        self._update_directory: IUpdateDirectory = update_directory
        self._version_manifest: IVersionManifest = version_manifest

    @property
    def update_directory(self) -> IUpdateDirectory:
        return self._update_directory

    @property
    def version_manifest(self) -> IVersionManifest:
        return self._version_manifest

    @staticmethod
    def fetch(update_directory_url: str, url_scraper_factory: IUrlScraperFactory, normal_printer: IPrinter, error_printer: IPrinter) -> CachedRemoteUpdateData | None:
        url_scraper: IUrlScraper
        with url_scraper_factory.new_pool(normal_printer.writeln) as url_scraper:
            if not CachedRemoteUpdateData._cached_update_directory:
                try:
                    CachedRemoteUpdateData._cached_update_directory = _fetch_schema_file(UpdateDirectorySchema(), 'update directory', update_directory_url, url_scraper, normal_printer)
                except _FetchSchemaError as ex:
                    error_printer.writeln(str(ex))
            else:
                normal_printer.writeln('Reusing cached update directory')

            if not CachedRemoteUpdateData._cached_version_manifest and CachedRemoteUpdateData._cached_update_directory:
                version_manifest_url: str = urllib.parse.urljoin(update_directory_url, CachedRemoteUpdateData._cached_update_directory.version_manifest_url)
                try:
                    CachedRemoteUpdateData._cached_version_manifest = _fetch_schema_file(VersionManifestSchema(), 'version manifest', version_manifest_url, url_scraper, normal_printer)
                except _FetchSchemaError as ex:
                    error_printer.writeln(str(ex))
            else:
                normal_printer.writeln('Reusing cached version manifest')

        if CachedRemoteUpdateData._cached_update_directory and CachedRemoteUpdateData._cached_version_manifest:
            return CachedRemoteUpdateData(CachedRemoteUpdateData._cached_update_directory, CachedRemoteUpdateData._cached_version_manifest)

        return None

class _FetchSchemaError(Exception):
    pass

def _fetch_schema_file[T: IItem](schema: T, name_of_schema: str, url: str, url_scraper: IUrlScraper, printer: IPrinter) -> T:
    printer.writeln(f'Fetching {name_of_schema}')

    def progress_callback(*, message: str | None, percentage_complete: int | None) -> None:
        _ = percentage_complete
        if message:
            printer.writeln(f'  {message}')
    scrape_result: ScrapeResult = url_scraper.try_scrape_url(url, progress_callback)
    if scrape_result.error_message:
        msg = f"Failed to fetch {name_of_schema} from '{url}': {scrape_result.error_message}"
        raise _FetchSchemaError(msg)

    try:
        json_root: object = json.loads(scrape_result.content)
    except json.JSONDecodeError as ex:
        msg = f"{name_of_schema.capitalize()} '{url}' could not be parsed as JSON: {ex}"
        raise _FetchSchemaError(msg) from ex

    try:
        schema.load(json_root)
    except SchemaLoadError as ex:
        msg = f"{name_of_schema.capitalize()} '{url}' error: {ex}"
        raise _FetchSchemaError(msg) from ex

    return schema
