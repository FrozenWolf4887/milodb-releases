# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from __future__ import annotations
from typing import TYPE_CHECKING, override
from milodb_client.updater.manifest.common_manifest_schema import ConfigFileItem, HexDigestItem, LaunchFileItem, VersionNumberKey, validate_format_field
from milodb_client.updater.manifest.cooked_schema_types import CookedDictionary
from milodb_client.updater.manifest.i_schema_types import IGroup, ITypedKey, SchemaLoadError
from milodb_client.updater.manifest.schema_types import DateItem, DynamicGroup, IntegerItem, IntegerKey, OptionalBooleanItem, PathKey, StaticGroup, TextItem, TextKey, root_key
from milodb_client.updater.manifest.version_manifest import ICoreFile, IVariant, IVersion, IVersionManifest
if TYPE_CHECKING:
    import datetime
    from collections.abc import Mapping
    from pathlib import Path
    from milodb_client.updater.manifest.common_manifest import IConfigFile, IHexDigest, ILaunchFile, IVersionNumber

_EXPECTED_FORMAT_VERSION: int = 2

class VersionManifestSchema(StaticGroup, IVersionManifest):
    def __init__(self) -> None:
        super().__init__(None, root_key())
        self.field_format = IntegerItem(self, 'format')
        self.field_variants = DynamicGroup(self, 'variants', TextKey.Creator(), VariantSchema)

    @override
    def load(self, value: object) -> None:
        validate_format_field(value, _EXPECTED_FORMAT_VERSION, 'version manifest')
        return super().load(value)

    @property
    @override
    def format(self) -> int:
        return self.field_format.get_item_value()

    @property
    @override
    def variants(self) -> Mapping[str, IVariant]:
        return CookedDictionary(self.field_variants.get())

class VariantSchema(StaticGroup, IVariant):
    def __init__(self, parent: IGroup, key: ITypedKey[str]) -> None:
        super().__init__(parent, key)
        self._name: str = key.get_key_value()
        self.field_summary = TextItem(self, TextKey('summary'))
        self.field_versions = DynamicGroup(self, 'versions', VersionNumberKey.Creator(), VersionSchema)

    @property
    @override
    def name(self) -> str:
        return self._name

    @property
    @override
    def summary(self) -> str:
        return self.field_summary.get_item_value()

    @property
    @override
    def versions(self) ->  Mapping[IVersionNumber, IVersion]:
        return CookedDictionary(self.field_versions.get())

class VersionSchema(StaticGroup, IVersion):
    def __init__(self, parent: IGroup, key: ITypedKey[IVersionNumber]) -> None:
        super().__init__(parent, key)
        self._number: IVersionNumber = key.get_key_value()
        self.field_date = DateItem(self, 'date')
        self.field_log = TextItem(self, 'log')
        self.field_launch_files = DynamicGroup(self, 'launchFiles', TextKey.Creator(), LaunchFileItem)
        self.field_core_files = DynamicGroup(self, 'coreFiles', PathKey.Creator(), CoreFileSchema)
        self.field_config_files = DynamicGroup(self, 'configFiles', IntegerKey.Creator(), ConfigFileItem)

    @override
    def load(self, value: object) -> None:
        super().load(value)
        self._verify_launch_files()

    @property
    @override
    def number(self) -> IVersionNumber:
        return self._number

    @property
    @override
    def date(self) -> datetime.date:
        return self.field_date.get_item_value()

    @property
    @override
    def log(self) -> str:
        return self.field_log.get_item_value()

    @property
    @override
    def launch_files(self) -> Mapping[str, ILaunchFile]:
        return CookedDictionary(self.field_launch_files.get())

    @property
    @override
    def core_files(self) -> Mapping[Path, ICoreFile]:
        return CookedDictionary(self.field_core_files.get())

    @property
    @override
    def config_files(self) -> Mapping[int, IConfigFile]:
        return CookedDictionary(self.field_config_files.get())

    def _verify_launch_files(self) -> None:
        launch_file: LaunchFileItem
        for launch_file in self.field_launch_files.get().values():
            core_file: CoreFileSchema | None = self._find_core_file_by_filename(launch_file.filename)
            if not core_file:
                msg = f"Key '{launch_file.full_path}' value '{launch_file.filename}' is not a member of core files"
                raise SchemaLoadError(msg)

    def _find_core_file_by_filename(self, filename: Path) -> CoreFileSchema | None:
        core_file: CoreFileSchema
        for core_file in self.field_core_files.get().values():
            if core_file.filename == filename:
                return core_file
        return None

class CoreFileSchema(StaticGroup, ICoreFile):
    def __init__(self, parent: IGroup, key: ITypedKey[Path]) -> None:
        super().__init__(parent, key)
        self._filename: Path = key.get_key_value()
        self.field_digest = HexDigestItem(self, 'digest')
        self.field_exe = OptionalBooleanItem(self, 'exe')

    @property
    @override
    def filename(self) -> Path:
        return self._filename

    @property
    @override
    def digest(self) -> IHexDigest:
        return self.field_digest.get()

    @property
    @override
    def exe(self) -> bool | None:
        return self.field_exe.get_item_value()
