# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import datetime
from abc import ABC, abstractmethod
from collections.abc import Mapping
from pathlib import Path
from milodb_client.updater.manifest.common_manifest import IConfigFile, IHexDigest, ILaunchFile, IVersionNumber

class IVersionManifest(ABC):
    @property
    @abstractmethod
    def format(self) -> int:
        pass

    @property
    @abstractmethod
    def variants(self) -> Mapping[str, 'IVariant']:
        pass

class IVariant(ABC):
    @property
    @abstractmethod
    def name(self) -> str:
        pass

    @property
    @abstractmethod
    def summary(self) -> str:
        pass

    @property
    @abstractmethod
    def versions(self) ->  Mapping[IVersionNumber, 'IVersion']:
        pass

class IVersion(ABC):
    @property
    @abstractmethod
    def number(self) -> IVersionNumber:
        pass

    @property
    @abstractmethod
    def date(self) -> datetime.date:
        pass

    @property
    @abstractmethod
    def log(self) -> str:
        pass

    @property
    @abstractmethod
    def launch_files(self) -> Mapping[str, ILaunchFile]:
        pass

    @property
    @abstractmethod
    def core_files(self) -> Mapping[Path, 'ICoreFile']:
        pass

    @property
    @abstractmethod
    def config_files(self) -> Mapping[int, IConfigFile]:
        pass

class ICoreFile(ABC):
    @property
    @abstractmethod
    def filename(self) -> Path:
        pass

    @property
    @abstractmethod
    def digest(self) -> IHexDigest:
        pass

    @property
    @abstractmethod
    def exe(self) -> bool | None:
        pass
