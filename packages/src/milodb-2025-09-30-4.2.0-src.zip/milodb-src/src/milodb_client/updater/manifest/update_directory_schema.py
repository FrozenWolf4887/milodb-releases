# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import urllib.parse
from collections.abc import Mapping
from typing import override
from milodb_client.updater.manifest.common_manifest import IHexDigest
from milodb_client.updater.manifest.common_manifest_schema import HexDigestKey, validate_format_field
from milodb_client.updater.manifest.cooked_schema_types import CookedDictionary
from milodb_client.updater.manifest.i_schema_types import IGroup, IKey, ITypedKey, SchemaLoadError
from milodb_client.updater.manifest.schema_types import DynamicGroup, IntegerItem, OptionalTextItem, StaticGroup, TextItem, root_key
from milodb_client.updater.manifest.update_directory import IAsset, IAssetRegister, IUpdateDirectory

_EXPECTED_FORMAT_VERSION: int = 2
_ASSET_URL_PLACEHOLDER: str = '<>'

class UpdateDirectorySchema(StaticGroup, IUpdateDirectory):
    def __init__(self) -> None:
        super().__init__(None, root_key())
        self.field_format = IntegerItem(self, 'format')
        self.field_version_manifest_url = TextItem(self, 'versionManifestUri')
        self.field_asset_register = AssetRegisterItem(self, 'assetRegister')

    @override
    def load(self, value: object) -> None:
        validate_format_field(value, _EXPECTED_FORMAT_VERSION, 'update directory')
        return super().load(value)

    @property
    @override
    def format(self) -> int:
        return self.field_format.get_item_value()

    @property
    @override
    def version_manifest_url(self) -> str:
        return self.field_version_manifest_url.get_item_value()

    @property
    @override
    def asset_register(self) -> IAssetRegister:
        return self.field_asset_register

class AssetRegisterItem(StaticGroup, IAssetRegister):
    def __init__(self, parent: IGroup | None, key: IKey | str) -> None:
        super().__init__(parent, key)
        self.field_template_asset_url = OptionalTextItem(self, 'templateAssetUri')
        self.field_assets = DynamicGroup(self, 'assets', HexDigestKey.Creator(), AssetItem)

    @override
    def load(self, value: object) -> None:
        super().load(value)

        template_url: str | None = self.template_asset_url
        if template_url and _ASSET_URL_PLACEHOLDER not in template_url:
            msg = f"'{self.field_template_asset_url.full_path}' value '{template_url}' does not include the '{_ASSET_URL_PLACEHOLDER}' placeholder"
            raise SchemaLoadError(msg)

        asset: AssetItem
        for asset in self.field_assets.get().values():
            if not template_url and not asset.url:
                msg = f"Asset '{asset.digest}' must specify a URL when there is no template URL"
                raise SchemaLoadError(msg)
            if asset.url and asset.identifier:
                msg = f"Asset '{asset.digest}' cannot specify both '{asset.field_id.key.name}' and '{asset.field_url.key.name}' fields"
                raise SchemaLoadError(msg)

    @property
    @override
    def template_asset_url(self) -> str | None:
        return self.field_template_asset_url.get_item_value()

    @property
    @override
    def assets(self) -> Mapping[IHexDigest, IAsset]:
        return CookedDictionary(self.field_assets.get())

    @override
    def resolve_asset_url(self, host_url: str, digest: IHexDigest) -> str | None:
        asset: IAsset | None = self.assets.get(digest)
        if not asset:
            return None

        asset_url: str | None = asset.url
        if asset_url is not None:
            return urllib.parse.urljoin(host_url, asset.url)

        template_url: str | None = self.template_asset_url
        if template_url is None:
            return None

        asset_id: str | None = asset.identifier
        if asset_id is not None:
            url_with_asset_id: str = template_url.replace(_ASSET_URL_PLACEHOLDER, asset_id)
            return urllib.parse.urljoin(host_url, url_with_asset_id)

        url_with_digest: str = template_url.replace(_ASSET_URL_PLACEHOLDER, asset.digest.digest_bytes.hex())
        return urllib.parse.urljoin(host_url, url_with_digest)

class AssetItem(StaticGroup, IAsset):
    def __init__(self, parent: IGroup | None, key: ITypedKey[IHexDigest]) -> None:
        super().__init__(parent, key)
        self._digest: IHexDigest = key.get_key_value()
        self.field_url = OptionalTextItem(self, 'uri')
        self.field_id = OptionalTextItem(self, 'id')
        self.field_size = IntegerItem(self, 'size')

    @property
    @override
    def digest(self) -> IHexDigest:
        return self._digest

    @property
    @override
    def url(self) -> str | None:
        return self.field_url.get_item_value()

    @property
    @override
    def identifier(self) -> str | None:
        return self.field_id.get_item_value()

    @property
    @override
    def size(self) -> int:
        return self.field_size.get_item_value()
