# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from collections.abc import Iterable, MutableSequence, Sequence
from typing import override
from milodb_client.database.tease import Tease, TeaseProperty, TeaseStrListProperty
from milodb_client.query.field_match import FieldItemMatch, FieldListMatch, FieldPageListMatch, IFieldMatch
from milodb_client.query.match_result import FalseMatchResult, IMatchResult, TrueMatchResult
from milodb_client.query.postfix_query_executor import PostfixError
from milodb_client.query.query import IQuery

class And(IQuery):
    @override
    def perform_query(self, stack_of_match_results: MutableSequence[IMatchResult], tease: Tease) -> None:
        try:
            right: IMatchResult = stack_of_match_results.pop()
            left: IMatchResult = stack_of_match_results.pop()
        except IndexError as ex:
            msg = "Bad expression: AND requires at least two match results on the stack"
            raise PostfixError(msg) from ex

        if isinstance(left, TrueMatchResult) and isinstance(right, TrueMatchResult):
            merged: Sequence[IFieldMatch] = _merge_list_of_field_matches(left.list_of_field_matches, right.list_of_field_matches)
            stack_of_match_results.append(TrueMatchResult(merged))
        else:
            stack_of_match_results.append(FalseMatchResult())

class Not(IQuery):
    @override
    def perform_query(self, stack_of_match_results: MutableSequence[IMatchResult], tease: Tease) -> None:
        try:
            result: IMatchResult = stack_of_match_results.pop()
        except IndexError as ex:
            msg = "Bad expression: NOT requires at least one match result on the stack"
            raise PostfixError(msg) from ex

        if isinstance(result, TrueMatchResult):
            stack_of_match_results.append(FalseMatchResult())
        else:
            stack_of_match_results.append(TrueMatchResult([]))

class Or(IQuery):
    @override
    def perform_query(self, stack_of_match_results: MutableSequence[IMatchResult], tease: Tease) -> None:
        try:
            right: IMatchResult = stack_of_match_results.pop()
            left: IMatchResult = stack_of_match_results.pop()
        except IndexError as ex:
            msg = "Bad expression: OR requires at least two match results on the stack"
            raise PostfixError(msg) from ex

        if isinstance(left, TrueMatchResult):
            if isinstance(right, TrueMatchResult):
                merged: Sequence[IFieldMatch] = _merge_list_of_field_matches(left.list_of_field_matches, right.list_of_field_matches)
                stack_of_match_results.append(TrueMatchResult(merged))
            else:
                stack_of_match_results.append(left)
        elif isinstance(right, TrueMatchResult):
            stack_of_match_results.append(right)
        else:
            stack_of_match_results.append(FalseMatchResult())

def _merge_list_of_field_matches(left: Iterable[IFieldMatch], right: Iterable[IFieldMatch]) -> list[IFieldMatch]:
    new_list_of_field_matches: list[IFieldMatch] = _merge_list_of_field_item_matches(left, right)
    new_list_of_field_matches.extend(_merge_list_of_field_list_matches(left, right))
    new_list_of_field_matches.extend(_merge_list_of_field_page_list_matches(left, right))
    return new_list_of_field_matches

def _merge_list_of_field_item_matches(left: Iterable[IFieldMatch], right: Iterable[IFieldMatch]) -> list[IFieldMatch]:
    merged_list: list[IFieldMatch] = []

    list_of_all_field_item_matches: Iterable[FieldItemMatch] = [
        match for match in left if isinstance(match, FieldItemMatch)
    ] + [
        match for match in right if isinstance(match, FieldItemMatch)
    ]

    list_of_unique_tease_properties: list[TeaseProperty] = []
    field_item_match: FieldItemMatch
    for field_item_match in list_of_all_field_item_matches:
        if field_item_match.tease_property not in list_of_unique_tease_properties:
            list_of_unique_tease_properties.append(field_item_match.tease_property)

    tease_property: TeaseProperty
    for tease_property in list_of_unique_tease_properties:
        list_of_indices: list[IFieldMatch.Indices] = []
        for match in list_of_all_field_item_matches:
            if match.tease_property == tease_property:
                list_of_indices.extend(match.list_of_indices)
        merged_list.append(FieldItemMatch(tease_property, list_of_indices))

    return merged_list

def _merge_list_of_field_list_matches(left: Iterable[IFieldMatch], right: Iterable[IFieldMatch]) -> list[FieldListMatch]:
    merged_list: list[FieldListMatch] = []

    list_of_all_field_list_matches: Iterable[FieldListMatch] = [
        match for match in left if isinstance(match, FieldListMatch)
    ] + [
        match for match in right if isinstance(match, FieldListMatch)
    ]

    list_of_unique_tease_properties: list[TeaseStrListProperty] = []
    field_list_match: FieldListMatch
    for field_list_match in list_of_all_field_list_matches:
        if field_list_match.tease_property not in list_of_unique_tease_properties:
            list_of_unique_tease_properties.append(field_list_match.tease_property)

    tease_property: TeaseStrListProperty
    for tease_property in list_of_unique_tease_properties:
        list_of_field_matches_for_property: Iterable[FieldListMatch] = [
            field_item_match for field_item_match in list_of_all_field_list_matches if field_item_match.tease_property == tease_property
        ]
        merged_list.extend(_merge_list_of_field_list_matches_for_single_property(list_of_field_matches_for_property))

    return merged_list

def _merge_list_of_field_list_matches_for_single_property(list_of_field_matches: Iterable[FieldListMatch]) -> list[FieldListMatch]:
    merged_list: list[FieldListMatch] = []

    list_of_field_matches = sorted(list_of_field_matches, key=lambda match: match.index_of_block)

    current_match: FieldListMatch | None = None
    match: FieldListMatch
    for match in list_of_field_matches:
        if current_match:
            if current_match.index_of_block == match.index_of_block:
                current_match.list_of_indices.extend(match.list_of_indices)
            else:
                merged_list.append(current_match)
                current_match = match
        else:
            current_match = match

    if current_match:
        merged_list.append(current_match)

    return merged_list

def _merge_list_of_field_page_list_matches(left: Iterable[IFieldMatch], right: Iterable[IFieldMatch]) -> list[FieldPageListMatch]:
    list_of_all_field_page_matches: Iterable[FieldPageListMatch] = [
        match for match in left if isinstance(match, FieldPageListMatch)
    ] + [
        match for match in right if isinstance(match, FieldPageListMatch)
    ]

    return _merge_list_of_field_page_list_matches_for_single_property(list_of_all_field_page_matches)

def _merge_list_of_field_page_list_matches_for_single_property(list_of_field_matches: Iterable[FieldPageListMatch]) -> list[FieldPageListMatch]:
    merged_list: list[FieldPageListMatch] = []

    list_of_field_matches = sorted(list_of_field_matches, key=lambda match: match.index_of_page)

    current_match: FieldPageListMatch | None = None
    match: FieldPageListMatch
    for match in list_of_field_matches:
        if current_match:
            if current_match.index_of_page == match.index_of_page:
                current_match.list_of_indices.extend(match.list_of_indices)
            else:
                merged_list.append(current_match)
                current_match = match
        else:
            current_match = match

    if current_match:
        merged_list.append(current_match)

    return merged_list
