# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from abc import ABC, abstractmethod
from collections.abc import Iterable, Sequence
from dataclasses import dataclass
from typing import Protocol, override
from milodb_client.database.tease import Tease
from milodb_client.query.match_result import IMatchResult, TrueMatchResult
from milodb_client.query.query import IQuery
from milodb_client.query.tease_match import TeaseMatch

@dataclass
class PostfixError(Exception):
    message: str

@dataclass
class PostfixQueryResult:
    total_match_count: int
    max_match_count: int
    was_max_match_count_reached: bool
    total_tease_count: int
    queried_tease_count: int
    list_of_tease_matches: Sequence[TeaseMatch]

class _QueryProgressCallback(Protocol):
    def __call__(self, *, percentage_complete: int) -> None:
        pass

class IPostfixQueryExecutor(ABC):
    @abstractmethod
    def execute(self, list_of_teases: Sequence[Tease], chain_of_postfix_queries: Iterable[IQuery], max_match_count: int, progress_callback: _QueryProgressCallback | None = None) -> PostfixQueryResult:
        pass

class PostfixQueryExecutor(IPostfixQueryExecutor):
    @override
    def execute(self, list_of_teases: Sequence[Tease], chain_of_postfix_queries: Iterable[IQuery], max_match_count: int, progress_callback: _QueryProgressCallback | None = None) -> PostfixQueryResult:
        list_of_tease_matches: list[TeaseMatch] = []
        queried_tease_count: int

        percentage_complete: int = -1
        index_of_match: int = 1
        total_match_count: int = 0
        was_max_match_count_reached: bool = False
        index_of_tease: int = 0
        tease: Tease
        for index_of_tease, tease in enumerate(list_of_teases):
            if progress_callback:
                new_percentage_complete: int = 100 * index_of_tease // len(list_of_teases)
                if new_percentage_complete != percentage_complete:
                    percentage_complete = new_percentage_complete
                    progress_callback(percentage_complete=percentage_complete)

            stack_of_match_results: list[IMatchResult] = []

            query_object: IQuery
            for query_object in chain_of_postfix_queries:
                query_object.perform_query(stack_of_match_results, tease)

            if len(stack_of_match_results) == 1:
                match_result: IMatchResult = stack_of_match_results[0]
                if isinstance(match_result, TrueMatchResult):
                    match_count: int = match_result.get_match_count()
                    if total_match_count + match_count <= max_match_count:
                        list_of_tease_matches.append(TeaseMatch(index_of_match, tease, match_result.list_of_field_matches))
                        total_match_count += match_count
                    else:
                        was_max_match_count_reached = True
                        queried_tease_count = index_of_tease
                        break
                    index_of_match += 1
            else:
                msg = "Bad expression: Expected a single result remaining on the stack"
                raise PostfixError(msg)
        else:
            queried_tease_count = len(list_of_teases)

        if progress_callback:
            progress_callback(percentage_complete=100)

        return PostfixQueryResult(total_match_count, max_match_count, was_max_match_count_reached, len(list_of_teases), queried_tease_count, list_of_tease_matches)
