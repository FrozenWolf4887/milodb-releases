# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from abc import ABC, abstractmethod
from collections.abc import Sequence
from typing import override
from milodb_client.query.field_match import IFieldMatch

class IMatchResult(ABC):
    @abstractmethod
    def get_match_count(self) -> int:
        pass

class TrueMatchResult(IMatchResult):
    def __init__(self, list_of_field_matches: Sequence[IFieldMatch]) -> None:
        self._list_of_field_matches: Sequence[IFieldMatch] = list_of_field_matches

    @override
    def get_match_count(self) -> int:
        return sum(len(field_match.list_of_indices) for field_match in self._list_of_field_matches)

    @property
    def list_of_field_matches(self) -> Sequence[IFieldMatch]:
        return self._list_of_field_matches

class FalseMatchResult(IMatchResult):
    @override
    def get_match_count(self) -> int:
        return 0
