# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from __future__ import annotations
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from collections.abc import Callable, Sequence
    from milodb_common.parser.arg_token_stream import ArgTokenStream
    from milodb_common.parser.candidate_text import CandidateText
    from milodb_common.parser.token import Token

class ICommandConstructor(ABC):
    @dataclass
    class EmptyInputResult:
        list_of_command_names: Sequence[str]

    @dataclass
    class SuccessfulResult:
        command: Callable[[], None]
        list_of_candidate_text: Sequence[CandidateText]

    @dataclass
    class FailedResult:
        command_name: str | None
        fault_token: Token | None
        fault_text: str
        input_text: str
        list_of_candidate_text: Sequence[CandidateText]

    type ConstructResult = SuccessfulResult | FailedResult | EmptyInputResult

    @dataclass
    class DelegateError(Exception):
        construct_result: ICommandConstructor.ConstructResult

    @abstractmethod
    def try_construct(self, arg_token_stream: ArgTokenStream) -> ConstructResult:
        pass
