# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from milodb_common.output.print.i_printer import IPrinter
from milodb_common.parser.arg_token_stream import ArgTokenStream
from milodb_common.variables.i_user_variables import IUserVariables
from milodb_common.view.terminal.command_framework.i_command_constructor import ICommandConstructor
from milodb_common.view.terminal.command_framework.quit_flag import QuitFlag

def process_user_input(user_input: str, command_constructor: ICommandConstructor, user_variables: IUserVariables, quit_flag: QuitFlag, normal_printer: IPrinter, error_printer: IPrinter) -> None:
    arg_token_stream: ArgTokenStream = ArgTokenStream(user_input, user_variables)
    construct_result: ICommandConstructor.ConstructResult = command_constructor.try_construct(arg_token_stream)
    if isinstance(construct_result, ICommandConstructor.SuccessfulResult):
        normal_printer.writeln()
        construct_result.command()
        if not quit_flag:
            normal_printer.writeln()
    elif isinstance(construct_result, ICommandConstructor.FailedResult):
        normal_printer.writeln()
        error_printer.writeln(construct_result.fault_text)
        if construct_result.command_name:
            normal_printer.writeln(f"Command: '{construct_result.command_name}'")
        if construct_result.fault_token:
            normal_printer.writeln(f"Faulty token: '{construct_result.fault_token.text}' starting at character #{construct_result.fault_token.inner_indices.start}")
        if construct_result.input_text:
            normal_printer.writeln(f"Input text: {construct_result.input_text}")
        if construct_result.list_of_candidate_text:
            normal_printer.writeln(f'Expected: {sorted([candidate_text.text for candidate_text in construct_result.list_of_candidate_text])}')
        normal_printer.writeln()
