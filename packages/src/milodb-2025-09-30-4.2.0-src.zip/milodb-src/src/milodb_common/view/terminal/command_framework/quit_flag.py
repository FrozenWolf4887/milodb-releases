# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
class QuitFlag:
    def __init__(self) -> None:
        self._is_set: bool = False

    def set(self) -> None:
        self._is_set = True

    def clear(self) -> None:
        self._is_set = False

    def __bool__(self) -> bool:
        return self._is_set
