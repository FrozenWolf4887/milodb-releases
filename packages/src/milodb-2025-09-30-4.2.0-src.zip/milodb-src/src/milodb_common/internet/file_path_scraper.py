# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from collections.abc import Callable
from pathlib import Path
from typing import override
from urllib.request import url2pathname
from milodb_common.internet.i_scraper import IPathScraper, ScrapeProgressCallback, ScrapeResult

class FilePathScraper(IPathScraper):
    @override
    def try_scrape_path(self, filepath: str, progress_callback: ScrapeProgressCallback | None) -> ScrapeResult:
        decoded_filepath: Path = Path(url2pathname(filepath))
        if progress_callback:
            progress_callback(message=f"Reading file '{decoded_filepath}'", percentage_complete=0)

        try:
            content: bytes = decoded_filepath.read_bytes()
        except OSError as ex:
            return ScrapeResult(f"Cannot read from file '{decoded_filepath}': {ex}", None, b'')

        if progress_callback:
            progress_callback(message=f'Read {len(content):,} bytes', percentage_complete=100)

        return ScrapeResult(None, None, content)

    @override
    def close(self, close_callback: Callable[[str], None] | None) -> None:
        """There is no connection to close."""
