# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from collections.abc import MutableMapping
from enum import Enum
from typing import Protocol

from milodb_common.output.print.i_printer import IPrinter

class ConfigMigrationResult(Enum):
    NOT_NEEDED = 0
    FAILED = 1
    SUCCESSFUL = 2

class MigrateCallable(Protocol):
    def __call__(self, config_dict: MutableMapping[object, object], normal_printer: IPrinter, error_printer: IPrinter) -> ConfigMigrationResult:
        ...
