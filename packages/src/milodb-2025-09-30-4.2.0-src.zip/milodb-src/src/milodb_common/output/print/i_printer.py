# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from abc import ABC, abstractmethod

class IPrinter(ABC):
    @abstractmethod
    def write(self, text: str) -> None:
        pass

    @abstractmethod
    def writeln(self, text: str | None = None) -> None:
        pass

    @property
    @abstractmethod
    def is_on_new_line(self) -> bool:
        pass

class IRedirectablePrinter(IPrinter):
    @abstractmethod
    def get_target_printer(self) -> IPrinter:
        pass

    @abstractmethod
    def set_target_printer(self, target_printer: IPrinter) -> None:
        pass
