# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from enum import Enum

def names(enum_class: type[Enum]) -> list[str]:
    return list(enum_class.__members__)

def lowercase_names(enum_class: type[Enum]) -> list[str]:
    return [ enum_name.lower() for enum_name in enum_class.__members__ ]

def uppercase_names(enum_class: type[Enum]) -> list[str]:
    return [ enum_name.upper() for enum_name in enum_class.__members__ ]

def text_of_values(enum_class: type[Enum]) -> list[str]:
    return [ str(enum.value) for enum in enum_class.__members__.values() ]

def lowercase_text_of_values(enum_class: type[Enum]) -> list[str]:
    return [ enum.value.lower() if isinstance(enum.value, str) else str(enum.value) for enum in enum_class.__members__.values() ]

def uppercase_text_of_values(enum_class: type[Enum]) -> list[str]:
    return [ enum.value.upper() if isinstance(enum.value, str) else str(enum.value) for enum in enum_class.__members__.values() ]

def try_lookup_name[E: Enum](enum_class: type[E], name: str, *, case_sensitive: bool) -> E | None:
    if case_sensitive:
        return enum_class.__members__.get(name)

    name = name.lower()
    enum_name: str
    enum: E
    for enum_name, enum in enum_class.__members__.items():
        if enum_name.lower() == name:
            return enum
    return None
