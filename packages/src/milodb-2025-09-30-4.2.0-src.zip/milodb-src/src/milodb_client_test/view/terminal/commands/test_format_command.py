# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from dataclasses import dataclass, field
from typing import override
from unittest.mock import Mock, PropertyMock, call
from milodb_client.output.format.i_formatter_factory import IFormatterCreator, IFormatterFactory
from milodb_client.view.terminal.commands import format_command
from milodb_common.output.print.i_printer import IPrinter
from milodb_common.parser.arg_token_stream import ArgTokenStream
from milodb_common.util.ref import IRef, SimpleRef
from milodb_common.view.terminal.command_framework.i_command import CommandLoaderResult
from milodb_common_test.parser.error_messages import ErrorMessage
from milodb_common_test.test.strict_mock import InterfaceMock
from milodb_common_test.test.test_command_base import CommandTestBase

_MOCK_FORMATTER_CHEESE_CREATOR: InterfaceMock = InterfaceMock(IFormatterCreator)
_MOCK_FORMATTER_CHEESE_CREATOR.get_name = Mock(return_value='Cheese')
_MOCK_FORMATTER_BISCUITS_CREATOR: InterfaceMock = InterfaceMock(IFormatterCreator)
_MOCK_FORMATTER_BISCUITS_CREATOR.get_name = Mock(return_value='Biscuits')
_MOCK_FORMATTER_WHISKEY_CREATOR: InterfaceMock = InterfaceMock(IFormatterCreator)
_MOCK_FORMATTER_WHISKEY_CREATOR.get_name = Mock(return_value='Whiskey')

_MOCK_FORMATTER_FACTORY: InterfaceMock = InterfaceMock(IFormatterFactory)
_MOCK_FORMATTER_FACTORY.get_list_of_formatter_names = Mock(return_value=['Cheese', 'Biscuits', 'Whiskey'])
type(_MOCK_FORMATTER_FACTORY).map_of_name_to_formatter_creator = PropertyMock(return_value={
    'Cheese': _MOCK_FORMATTER_CHEESE_CREATOR,
    'Biscuits': _MOCK_FORMATTER_BISCUITS_CREATOR,
    'Whiskey': _MOCK_FORMATTER_WHISKEY_CREATOR})

@dataclass
class _Args:
    current_formatter: IRef[IFormatterCreator] = field(default_factory=lambda: SimpleRef(_MOCK_FORMATTER_CHEESE_CREATOR))
    formatter_factory: InterfaceMock = _MOCK_FORMATTER_FACTORY
    normal_printer: InterfaceMock = field(default_factory=lambda: InterfaceMock(IPrinter))

class TestFormatCommand(CommandTestBase):
    @override
    def setUp(self) -> None:
        self._args: _Args = _Args()
        return super().setUp()

    @override
    def load_command(self, arg_token_stream: ArgTokenStream) -> CommandLoaderResult:
        return format_command.load(
            arg_token_stream,
            self._args.current_formatter,
            self._args.formatter_factory,
            self._args.normal_printer,
        )

    def test_without_arguments_prints_current_setting_without_change(self) -> None:
        for initial_formatter in (_MOCK_FORMATTER_CHEESE_CREATOR, _MOCK_FORMATTER_BISCUITS_CREATOR, _MOCK_FORMATTER_WHISKEY_CREATOR):
            with self.subTest(initial_formatter=initial_formatter):
                self.setUp()
                self._args.current_formatter = SimpleRef(initial_formatter)
                self._args.normal_printer.writeln = Mock()
                self.command_load_and_execute([])
                self._args.normal_printer.writeln.assert_has_calls([
                    call(f"Current format is '{initial_formatter.get_name()}'"),
                    call("Available formats are ['Cheese', 'Biscuits', 'Whiskey']")])
                self.assertIs(initial_formatter, self._args.current_formatter.get())
                self.assert_next_text(['Cheese', 'Biscuits', 'Whiskey'])

    def test_with_argument_changes_setting_regardless_of_initial_setting(self) -> None:
        for initial_formatter in (_MOCK_FORMATTER_CHEESE_CREATOR, _MOCK_FORMATTER_BISCUITS_CREATOR, _MOCK_FORMATTER_WHISKEY_CREATOR):
            for new_formatter in (_MOCK_FORMATTER_CHEESE_CREATOR, _MOCK_FORMATTER_BISCUITS_CREATOR, _MOCK_FORMATTER_WHISKEY_CREATOR):
                with self.subTest(initial_formatter=initial_formatter):
                    self.setUp()
                    self._args.current_formatter = SimpleRef(initial_formatter)
                    self._args.normal_printer.writeln = Mock()
                    self.command_load_and_execute([new_formatter.get_name()])
                    self._args.normal_printer.writeln.assert_called_once_with(f"Changed format to '{new_formatter.get_name()}'")
                    self.assertIs(new_formatter, self._args.current_formatter.get())
                    self.assert_next_text([])

    def test_with_one_invalid_argument_returns_failure(self) -> None:
        self.command_load(['Wine'])
        self.assert_argument_error(1, ErrorMessage.INVALID_FORMATTER, ['Cheese', 'Biscuits', 'Whiskey'])

    def test_with_redundant_argument_returns_failure(self) -> None:
        self.command_load(['Whiskey', 'Biscuits'])
        self.assert_argument_error(2, ErrorMessage.UNEXPECTED, [])
