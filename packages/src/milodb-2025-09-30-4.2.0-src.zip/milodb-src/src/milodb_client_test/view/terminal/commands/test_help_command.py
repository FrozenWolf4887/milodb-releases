# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import re
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, override
from unittest.mock import Mock, call
from milodb_client.view.terminal.commands import help_command
from milodb_common.output.print.i_printer import IPrinter
from milodb_common.parser.arg_token_stream import ArgTokenStream
from milodb_common.view.terminal.command_framework.i_command import CommandLoaderResult
from milodb_common.view.terminal.command_framework.i_command_factory import ICommandFactory
from milodb_common.view.terminal.command_framework.i_help_info import IHelpInfo
from milodb_common_test.parser.error_messages import ErrorMessage
from milodb_common_test.test.matchers_strings import RegexSubstringMatch
from milodb_common_test.test.strict_mock import InterfaceMock
from milodb_common_test.test.test_command_base import CommandTestBase
if TYPE_CHECKING:
    from collections.abc import Mapping

@dataclass
class _Args:
    command_factory: InterfaceMock = field(default_factory=lambda: InterfaceMock(ICommandFactory))
    normal_printer: InterfaceMock = field(default_factory=lambda: InterfaceMock(IPrinter))

class TestHelpCommand(CommandTestBase):
    @override
    def setUp(self) -> None:
        self._args: _Args = _Args()
        return super().setUp()

    @override
    def load_command(self, arg_token_stream: ArgTokenStream) -> CommandLoaderResult:
        return help_command.load(
            arg_token_stream,
            self._args.command_factory,
            self._args.normal_printer,
        )

    def test_without_arguments_prints_generic_help_for_commands(self) -> None:
        command_one_help: InterfaceMock = InterfaceMock(IHelpInfo)
        command_one_help.get_one_line_summary = Mock(return_value='This is the summary of the first command')
        command_two_help: InterfaceMock = InterfaceMock(IHelpInfo)
        command_two_help.get_one_line_summary = Mock(return_value='The second command summary')
        map_of_command_name_to_help: Mapping[str, InterfaceMock] = {
            'first': command_one_help,
            'second': command_two_help,
        }
        self._args.command_factory.get_list_of_command_names = Mock(return_value=list(map_of_command_name_to_help))
        self._args.command_factory.try_get_command_help_from_name = Mock(side_effect=map_of_command_name_to_help.get)
        self._args.normal_printer.writeln = Mock()
        self.command_load_and_execute([])
        self._args.command_factory.get_list_of_command_names.assert_called()
        self._args.command_factory.try_get_command_help_from_name.assert_has_calls([call(name) for name in map_of_command_name_to_help])
        self._args.normal_printer.writeln.assert_called_once_with(RegexSubstringMatch('first +This is the summary of the first command.+second +The second command summary', re.DOTALL))

    def test_with_known_command_argument_returns_success(self) -> None:
        help_info: InterfaceMock = InterfaceMock(IHelpInfo)
        help_info.get_one_line_summary = Mock(return_value='Summary of the first command')
        help_info.get_detailed_summary = Mock(return_value='Detailed command summary')
        self._args.command_factory.try_get_command_help_from_name = Mock(return_value=help_info)
        self._args.normal_printer.writeln = Mock()
        self.command_load_and_execute(['fake_command'])
        self._args.command_factory.try_get_command_help_from_name.assert_called_once_with('fake_command')
        self._args.normal_printer.writeln.assert_called_once_with(RegexSubstringMatch('Summary of the first command.+Detailed command summary', re.DOTALL))

    def test_with_unknown_command_name_returns_failure(self) -> None:
        map_of_command_name_to_help: Mapping[str, InterfaceMock] = {
            'first': InterfaceMock(IHelpInfo),
            'second': InterfaceMock(IHelpInfo),
        }
        self._args.command_factory.get_list_of_command_names = Mock(return_value=list(map_of_command_name_to_help))
        self._args.command_factory.try_get_command_help_from_name = Mock(side_effect=map_of_command_name_to_help.get)
        self.command_load(['mango'])
        self.assert_load_error(1, ErrorMessage.INVALID_EXPECTING_COMMAND, list(map_of_command_name_to_help))

    def test_with_redundant_argument_returns_failure(self) -> None:
        map_of_command_name_to_help: Mapping[str, InterfaceMock] = {
            'first': InterfaceMock(IHelpInfo),
            'second': InterfaceMock(IHelpInfo),
        }
        self._args.command_factory.get_list_of_command_names = Mock(return_value=list(map_of_command_name_to_help))
        self._args.command_factory.try_get_command_help_from_name = Mock(side_effect=map_of_command_name_to_help.get)
        self.command_load(['first', 'second'])
        self.assert_argument_error(2, ErrorMessage.UNEXPECTED, [])
