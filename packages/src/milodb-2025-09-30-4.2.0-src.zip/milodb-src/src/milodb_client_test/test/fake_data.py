# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import hashlib
from milodb_client.updater.manifest.common_manifest import IHexDigest
from milodb_client_test.test.mock_hex_digest import MockDigest

def _sha3_224(data: bytes) -> bytes:
    hasher = hashlib.sha3_224()
    hasher.update(data)
    return hasher.digest()

# spell-checker: disable
FAKE_DATA_A: bytes = b'Lorem ipsum dolor sit amet, consectetur adipiscing elit'
FAKE_DATA_B: bytes = b'sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.'
FAKE_DATA_C: bytes = b'Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.'
FAKE_DATA_D: bytes = b'Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.'
FAKE_DATA_E: bytes = b'Excepteur sint occaecat cupidatat non proident'
FAKE_DATA_F: bytes = b'sunt in culpa qui officia deserunt mollit anim id est laborum.'
FAKE_DATA_G: bytes = b'Egestas tellus rutrum tellus pellentesque eu tincidunt tortor.'
FAKE_DATA_H: bytes = b'Vivamus at augue eget arcu.'
FAKE_DATA_I: bytes = b'Convallis tellus id interdum velit laoreet id.'
# spell-checker: enable

FAKE_DIGEST_BYTES_A: bytes = _sha3_224(FAKE_DATA_A)
FAKE_DIGEST_BYTES_B: bytes = _sha3_224(FAKE_DATA_B)
FAKE_DIGEST_BYTES_C: bytes = _sha3_224(FAKE_DATA_C)
FAKE_DIGEST_BYTES_D: bytes = _sha3_224(FAKE_DATA_D)
FAKE_DIGEST_BYTES_E: bytes = _sha3_224(FAKE_DATA_E)
FAKE_DIGEST_BYTES_F: bytes = _sha3_224(FAKE_DATA_F)
FAKE_DIGEST_BYTES_G: bytes = _sha3_224(FAKE_DATA_G)
FAKE_DIGEST_BYTES_H: bytes = _sha3_224(FAKE_DATA_H)
FAKE_DIGEST_BYTES_I: bytes = _sha3_224(FAKE_DATA_I)

FAKE_HEXDIGEST_A: IHexDigest = MockDigest(FAKE_DIGEST_BYTES_A)
FAKE_HEXDIGEST_B: IHexDigest = MockDigest(FAKE_DIGEST_BYTES_B)
FAKE_HEXDIGEST_C: IHexDigest = MockDigest(FAKE_DIGEST_BYTES_C)
FAKE_HEXDIGEST_D: IHexDigest = MockDigest(FAKE_DIGEST_BYTES_D)
FAKE_HEXDIGEST_E: IHexDigest = MockDigest(FAKE_DIGEST_BYTES_E)
FAKE_HEXDIGEST_F: IHexDigest = MockDigest(FAKE_DIGEST_BYTES_F)
FAKE_HEXDIGEST_G: IHexDigest = MockDigest(FAKE_DIGEST_BYTES_G)
FAKE_HEXDIGEST_H: IHexDigest = MockDigest(FAKE_DIGEST_BYTES_H)
FAKE_HEXDIGEST_I: IHexDigest = MockDigest(FAKE_DIGEST_BYTES_I)
