# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import datetime
import unittest
from pathlib import Path
from typing import TYPE_CHECKING, override
from milodb_client.updater.manifest.common_manifest import PreReleaseLabel
from milodb_client.updater.manifest.i_schema_types import SchemaLoadError
from milodb_client.updater.manifest.version_manifest_schema import VersionManifestSchema
from milodb_client.updater.manifest.version_number import PreRelease, VersionNumber
from milodb_client_test.test import json_tools
if TYPE_CHECKING:
    from collections.abc import Mapping
    from milodb_client.updater.manifest.version_manifest import ICoreFile, IVariant, IVersion, IVersionManifest

SAMPLE_VERSION_MANIFEST: str = r"""
{
    "format": 2,
    "variants": {
        "main": {
            "summary": "This is the main variant",
            "versions": {
                "1.7.0": {
                    "date": "2023-07-31",
                    "log": "* Initial release",
                    "launchFiles": {
                        "linux": "milodb"
                    },
                    "coreFiles": {
                        "milodb": {
                            "digest": "d5c37703a48d8aab85ab1d027984c4c1ede0720c98ce9157d1d6fea6",
                            "exe": true
                        },
                        "milodb.ver": {
                            "digest": "0b31b236147881106db5aec5b64707ff342a3cb721eeab7a93e35dc3",
                            "exe": false
                        },
                        "database.mdb": {
                            "digest": "7112b8d27fd849dc1540ba96a67ed4dfe30c907a62bcb227bcc27cfd"
                        },
                        "changelog.md": {
                            "digest": "8242b54e4d91cf58f477b65a14a009bd6c520fd2e3d5c679f00fcc07"
                        },
                        "default.css": {
                            "digest": "1a936f2a010312a2b70d2e3cf160bd239a74297d4025e95e02b83c39"
                        }
                    },
                    "configFiles": {
                        "90": "variables.json",
                        "82": "config.json",
                        "40": "history.json"
                    }
                },
                "1.8.0-alpha.4": {
                    "date": "2023-11-17",
                    "log": "* Fixed something\n* Added something",
                    "launchFiles": {
                        "win32": "milodb.exe"
                    },
                    "coreFiles": {
                        "milodb.exe": {
                            "digest": "0a9a1c7840d1c4c20c5dfb9d68fd6563731f8b1cae676acf3284ec6b",
                            "exe": true
                        },
                        "milodb.ver": {
                            "digest": "40d7f9b081560901bf429405babf9d148ca782ccbd6c657b4745b284"
                        },
                        "database.mdb": {
                            "digest": "003ac36b3de4b09cca30d21062242eeb2d14e3ecd98496d2a185bfc9",
                            "exe": false
                        },
                        "changes.txt": {
                            "digest": "ec1a8357b7fc775024a74af543b1988161f5fa389226d87ec4492ba0"
                        },
                        "default.css": {
                            "digest": "1a936f2a010312a2b70d2e3cf160bd239a74297d4025e95e02b83c39",
                            "exe": false
                        }
                    },
                    "configFiles": {
                        "90": "variables.json",
                        "82": "settings.json",
                        "38": "history.txt"
                    }
                }
            }
        }
    }
}"""

class TestVersionManifest(unittest.TestCase):
    def test_throws_when_root_is_invalid(self) -> None:
        with self.assertRaises(SchemaLoadError) as capture:
            VersionManifestSchema().load('hello')
        self.assertEqual("Schema of version manifest has invalid root type of 'str'", str(capture.exception))

    def test_throws_when_format_is_missing(self) -> None:
        json_root: Mapping[object, object] = json_tools.load_and_prune_json_key(SAMPLE_VERSION_MANIFEST, 'format')
        with self.assertRaises(SchemaLoadError) as capture:
            VersionManifestSchema().load(json_root)
        self.assertEqual("Format field of version manifest is missing", str(capture.exception))

    def test_throws_when_format_is_unexpected_value(self) -> None:
        json_root: Mapping[object, object] = json_tools.load_and_change_json_value(SAMPLE_VERSION_MANIFEST, 'format', 24)
        with self.assertRaises(SchemaLoadError) as capture:
            VersionManifestSchema().load(json_root)
        self.assertEqual("Unsupported version manifest format of '24'; expected to be '2'", str(capture.exception))

    def test_throws_when_format_is_unexpected_type(self) -> None:
        json_root: Mapping[object, object] = json_tools.load_and_change_json_value(SAMPLE_VERSION_MANIFEST, 'format', '2')
        with self.assertRaises(SchemaLoadError) as capture:
            VersionManifestSchema().load(json_root)
        self.assertEqual("Format field of version manifest is of type 'str'; expected to be 'int'", str(capture.exception))

    def test_throws_when_entries_missing(self) -> None:
        list_of_paths_to_remove: tuple[str, ...] = (
            'variants',
            'variants/main/summary',
            'variants/main/versions/1.7.0/date',
            'variants/main/versions/1.8.0-alpha.4/log',
            'variants/main/versions/1.8.0-alpha.4/launchFiles',
            'variants/main/versions/1.7.0/coreFiles',
            'variants/main/versions/1.8.0-alpha.4/configFiles',
            'variants/main/versions/1.7.0/coreFiles/database.mdb/digest',
        )
        path_to_remove: str
        for path_to_remove in list_of_paths_to_remove:
            with self.subTest(missing_entry=path_to_remove):
                json_root: Mapping[object, object] = json_tools.load_and_prune_json_key(SAMPLE_VERSION_MANIFEST, path_to_remove)
                with self.assertRaises(SchemaLoadError) as capture:
                    VersionManifestSchema().load(json_root)
                self.assertEqual(f"Key '{path_to_remove}' is missing", str(capture.exception))

    def test_throws_when_entries_are_of_incorrect_basic_type(self) -> None:
        list_of_paths_to_change: tuple[tuple[str, object, str], ...] = (
            ('variants', 'fruit', 'a group'),
            ('variants/main', 1234, 'a group'),
            ('variants/main/summary', 1234, 'text'),
            ('variants/main/versions', 1234, 'a group'),
            ('variants/main/versions/1.7.0', 1234, 'a group'),
            ('variants/main/versions/1.7.0/date', 1234, 'text'),
            ('variants/main/versions/1.8.0-alpha.4/log', 1234, 'text'),
            ('variants/main/versions/1.8.0-alpha.4/launchFiles', 1234, 'a group'),
            ('variants/main/versions/1.7.0/coreFiles', 'fruit', 'a group'),
            ('variants/main/versions/1.8.0-alpha.4/configFiles', 'fruit', 'a group'),
            ('variants/main/versions/1.7.0/coreFiles/database.mdb/digest', 1234, 'text'),
            ('variants/main/versions/1.7.0/coreFiles/milodb/exe', 1234, 'a boolean'),
        )
        path_to_change: str
        new_value: object
        error_message_suffix: str
        for path_to_change, new_value, error_message_suffix in list_of_paths_to_change:
            with self.subTest(changed_entry=path_to_change, new_value=new_value):
                json_root: Mapping[object, object] = json_tools.load_and_change_json_value(SAMPLE_VERSION_MANIFEST, path_to_change, new_value)
                with self.assertRaises(SchemaLoadError) as capture:
                    VersionManifestSchema().load(json_root)
                self.assertEqual(f"Key '{path_to_change}' value is not {error_message_suffix}", str(capture.exception))

    def test_throws_when_digest_is_of_incorrect_type(self) -> None:
        list_of_paths_to_change: tuple[tuple[str, object, str], ...] = (
            ('variants/main/versions/1.7.0/coreFiles/database.mdb/digest', 'frogs', 'a SHA3-224 hexadecimal digest'),
            ('variants/main/versions/1.7.0/coreFiles/database.mdb/digest', '1234567890', 'a SHA3-224 hexadecimal digest'),
        )
        path_to_change: str
        new_value: object
        error_message_suffix: str
        for path_to_change, new_value, error_message_suffix in list_of_paths_to_change:
            with self.subTest(changed_entry=path_to_change, new_value=new_value):
                json_root: Mapping[object, object] = json_tools.load_and_change_json_value(SAMPLE_VERSION_MANIFEST, path_to_change, new_value)
                with self.assertRaises(SchemaLoadError) as capture:
                    VersionManifestSchema().load(json_root)
                self.assertEqual(f"Key '{path_to_change}' value '{new_value}' is not {error_message_suffix}", str(capture.exception))

    def test_throws_when_date_entry_is_wrong_format(self) -> None:
        list_of_paths_to_change: tuple[tuple[str, object], ...] = (
            ('variants/main/versions/1.7.0/date', '2021-06-4'),
            ('variants/main/versions/1.8.0-alpha.4/date', '30-09-23'),
        )
        path_to_change: str
        new_value: object
        for path_to_change, new_value in list_of_paths_to_change:
            with self.subTest(changed_entry=path_to_change, new_value=new_value):
                json_root: Mapping[object, object] = json_tools.load_and_change_json_value(SAMPLE_VERSION_MANIFEST, path_to_change, new_value)
                with self.assertRaises(SchemaLoadError) as capture:
                    VersionManifestSchema().load(json_root)
                self.assertEqual(f"Key '{path_to_change}' value '{new_value}' is not an ISO date", str(capture.exception))

    def test_throws_when_unknown_entry_is_found(self) -> None:
        list_of_paths_to_add: tuple[tuple[str, object], ...] = (
            ('something', 'fruit'),
            ('variants/main/versions/1.8.0-alpha.4/apple', 'green'),
        )
        path_to_add: str
        value: object
        for path_to_add, value in list_of_paths_to_add:
            with self.subTest(new_entry=path_to_add, value=value):
                json_root: Mapping[object, object] = json_tools.load_and_add_json_key(SAMPLE_VERSION_MANIFEST, path_to_add, value)
                with self.assertRaises(SchemaLoadError) as capture:
                    VersionManifestSchema().load(json_root)
                self.assertEqual(f"Key '{path_to_add}' is unknown", str(capture.exception))

    def test_throws_if_launch_file_not_within_core_files(self) -> None:
        json_root: Mapping[object, object] = json_tools.load_and_change_json_value(SAMPLE_VERSION_MANIFEST, 'variants/main/versions/1.7.0/launchFiles/linux', 'missing.exe')
        with self.assertRaises(SchemaLoadError) as capture:
            VersionManifestSchema().load(json_root)
        self.assertEqual("Key 'variants/main/versions/1.7.0/launchFiles/linux' value 'missing.exe' is not a member of core files", str(capture.exception))

    def test_throws_when_values_are_blank(self) -> None:
        list_of_paths_to_change: tuple[str, ...] = (
            'variants/main/versions/1.8.0-alpha.4/log',
        )
        path_to_change: str
        for path_to_change in list_of_paths_to_change:
            with self.subTest(changed_entry=path_to_change):
                json_root: Mapping[object, object] = json_tools.load_and_change_json_value(SAMPLE_VERSION_MANIFEST, path_to_change, '')
                with self.assertRaises(SchemaLoadError) as capture:
                    VersionManifestSchema().load(json_root)
                self.assertEqual(f"Key '{path_to_change}' value is blank", str(capture.exception))

    def test_throws_when_keys_are_blank(self) -> None:
        list_of_path_keys_to_blank: tuple[tuple[str, str], ...] = (
            ('', 'variants'),
            ('variants', 'main'),
            ('variants/main', 'summary'),
            ('variants/main', 'versions'),
            ('variants/main/versions', '1.8.0-alpha.4'),
            ('variants/main/versions/1.8.0-alpha.4', 'log'),
            ('variants/main/versions/1.7.0', 'coreFiles'),
            ('variants/main/versions/1.7.0/coreFiles', 'database.mdb'),
            ('variants/main/versions/1.7.0/coreFiles/database.mdb', 'digest'),
        )
        path_to_blank: str
        key_to_blank: str
        for path_to_blank, key_to_blank in list_of_path_keys_to_blank:
            path_to_blank_key: str = f'{path_to_blank}{"/" if path_to_blank else ""}{key_to_blank}'
            with self.subTest(blanked_key=path_to_blank_key):
                json_root: Mapping[object, object] = json_tools.load_and_change_json_key(SAMPLE_VERSION_MANIFEST, path_to_blank_key, '')
                with self.assertRaises(SchemaLoadError) as capture:
                    VersionManifestSchema().load(json_root)
                self.assertEqual(f"Key '{path_to_blank}/' is blank", str(capture.exception))

    def test_throws_when_version_format_is_incorrect(self) -> None:
        list_of_keys_to_change: tuple[tuple[str, str, str], ...] = (
            ('variants/main/versions', '1.7.0', '1.7'),
            ('variants/main/versions', '1.8.0-alpha.4', '1.8.0a'),
            ('variants/main/versions', '1.8.0-alpha.4', 'a1.b2.c3'),
        )
        parent_path_to_change: str
        key_to_change: str
        new_key_value: str
        for parent_path_to_change, key_to_change, new_key_value in list_of_keys_to_change:
            with self.subTest(changed_key=f'{parent_path_to_change}/{key_to_change}', new_value=new_key_value):
                json_root: Mapping[object, object] = json_tools.load_and_change_json_key(SAMPLE_VERSION_MANIFEST, f'{parent_path_to_change}/{key_to_change}', new_key_value)
                with self.assertRaises(SchemaLoadError) as capture:
                    VersionManifestSchema().load(json_root)
                self.assertEqual(f"Key '{parent_path_to_change}/{new_key_value}': '{new_key_value}' is not a Semantic Version number", str(capture.exception))

    def test_throws_when_config_key_is_not_an_integer(self) -> None:
        list_of_keys_to_change: tuple[tuple[str, str, str], ...] = (
            ('variants/main/versions/1.7.0/configFiles', '90', '90a'),
            ('variants/main/versions/1.8.0-alpha.4/configFiles', '82', 'a82'),
        )
        path_to_change: str
        key_to_change: str
        new_key_value: str
        for path_to_change, key_to_change, new_key_value in list_of_keys_to_change:
            with self.subTest(changed_key=f'{path_to_change}/{key_to_change}', new_value=new_key_value):
                json_root: Mapping[object, object] = json_tools.load_and_change_json_key(SAMPLE_VERSION_MANIFEST, f'{path_to_change}/{key_to_change}', new_key_value)
                with self.assertRaises(SchemaLoadError) as capture:
                    VersionManifestSchema().load(json_root)
                self.assertEqual(f"Key '{path_to_change}/{new_key_value}': '{new_key_value}' is not an integer", str(capture.exception))

FIRST_VERSION_NUMBER = VersionNumber(1, 7, 0)
SECOND_VERSION_NUMBER = VersionNumber(1, 8, 0, PreRelease(PreReleaseLabel.ALPHA, 4))

class TestVersionManifestProperties(unittest.TestCase):
    @override
    def setUp(self) -> None:
        super().setUp()
        self._manifest: IVersionManifest = VersionManifestSchema()
        self._manifest.load(json_tools.load_json(SAMPLE_VERSION_MANIFEST))

    def test_access_root_entries_as_properties(self) -> None:
        self.assertEqual(2, self._manifest.format)

    def test_access_variant_entries_as_properties(self) -> None:
        self.assertEqual(1, len(self._manifest.variants))

        main_variant: IVariant = self._manifest.variants['main']
        self.assertEqual('main', main_variant.name)
        self.assertEqual('This is the main variant', main_variant.summary)

    def test_access_version_entries_as_properties(self) -> None:
        variant: IVariant = self._manifest.variants['main']
        self.assertEqual(2, len(variant.versions))

        version: IVersion = variant.versions[FIRST_VERSION_NUMBER]
        self.assertEqual(FIRST_VERSION_NUMBER, version.number)
        self.assertEqual(datetime.date(2023, 7, 31), version.date)
        self.assertEqual('* Initial release', version.log)

        version = variant.versions[SECOND_VERSION_NUMBER]
        self.assertEqual(SECOND_VERSION_NUMBER, version.number)
        self.assertEqual(datetime.date(2023, 11, 17), version.date)
        self.assertEqual('* Fixed something\n* Added something', version.log)

    def test_access_launch_files_as_properties(self) -> None:
        version: IVersion = self._manifest.variants['main'].versions[FIRST_VERSION_NUMBER]
        self.assertEqual(1, len(version.launch_files))
        self.assertEqual('linux', version.launch_files['linux'].operating_system)
        self.assertEqual(Path('milodb'), version.launch_files['linux'].filename)

        version = self._manifest.variants['main'].versions[SECOND_VERSION_NUMBER]
        self.assertEqual(1, len(version.launch_files))
        self.assertEqual('win32', version.launch_files['win32'].operating_system)
        self.assertEqual(Path('milodb.exe'), version.launch_files['win32'].filename)

    def test_access_core_files_as_properties(self) -> None:
        version: IVersion = self._manifest.variants['main'].versions[FIRST_VERSION_NUMBER]

        self.assertEqual(5, len(version.core_files))

        first_file: ICoreFile = version.core_files[Path('milodb')]
        self.assertEqual(Path('milodb'), first_file.filename)
        self.assertEqual(bytes.fromhex('d5c37703a48d8aab85ab1d027984c4c1ede0720c98ce9157d1d6fea6'), first_file.digest.digest_bytes)
        self.assertTrue(first_file.exe)

        middle_file: ICoreFile = version.core_files[Path('database.mdb')]
        self.assertEqual(Path('database.mdb'), middle_file.filename)
        self.assertEqual(bytes.fromhex('7112b8d27fd849dc1540ba96a67ed4dfe30c907a62bcb227bcc27cfd'), middle_file.digest.digest_bytes)
        self.assertFalse(middle_file.exe)

        last_file: ICoreFile = version.core_files[Path('default.css')]
        self.assertEqual(Path('default.css'), last_file.filename)
        self.assertEqual(bytes.fromhex('1a936f2a010312a2b70d2e3cf160bd239a74297d4025e95e02b83c39'), last_file.digest.digest_bytes)
        self.assertFalse(last_file.exe)

        version = self._manifest.variants['main'].versions[SECOND_VERSION_NUMBER]

        self.assertEqual(5, len(version.core_files))

        first_file = version.core_files[Path('milodb.exe')]
        self.assertEqual(Path('milodb.exe'), first_file.filename)
        self.assertEqual(bytes.fromhex('0a9a1c7840d1c4c20c5dfb9d68fd6563731f8b1cae676acf3284ec6b'), first_file.digest.digest_bytes)
        self.assertTrue(first_file.exe)

        middle_file = version.core_files[Path('database.mdb')]
        self.assertEqual(Path('database.mdb'), middle_file.filename)
        self.assertEqual(bytes.fromhex('003ac36b3de4b09cca30d21062242eeb2d14e3ecd98496d2a185bfc9'), middle_file.digest.digest_bytes)
        self.assertFalse(middle_file.exe)

        last_file = version.core_files[Path('default.css')]
        self.assertEqual(Path('default.css'), last_file.filename)
        self.assertEqual(bytes.fromhex('1a936f2a010312a2b70d2e3cf160bd239a74297d4025e95e02b83c39'), last_file.digest.digest_bytes)
        self.assertFalse(last_file.exe)

    def test_config_files_as_properties(self) -> None:
        version: IVersion = self._manifest.variants['main'].versions[FIRST_VERSION_NUMBER]

        self.assertEqual(3, len(version.config_files))

        self.assertEqual(3, len(version.config_files))
        self.assertEqual(90, version.config_files[90].config_key)
        self.assertEqual(Path('variables.json'), version.config_files[90].filename)
        self.assertEqual(82, version.config_files[82].config_key)
        self.assertEqual(Path('config.json'), version.config_files[82].filename)
        self.assertEqual(40, version.config_files[40].config_key)
        self.assertEqual(Path('history.json'), version.config_files[40].filename)

        version = self._manifest.variants['main'].versions[SECOND_VERSION_NUMBER]

        self.assertEqual(3, len(version.config_files))

        self.assertEqual(3, len(version.config_files))
        self.assertEqual(90, version.config_files[90].config_key)
        self.assertEqual(Path('variables.json'), version.config_files[90].filename)
        self.assertEqual(82, version.config_files[82].config_key)
        self.assertEqual(Path('settings.json'), version.config_files[82].filename)
        self.assertEqual(38, version.config_files[38].config_key)
        self.assertEqual(Path('history.txt'), version.config_files[38].filename)
