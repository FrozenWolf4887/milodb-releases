#!/usr/bin/env python3
# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import sys
if sys.version_info < (3, 12):
    print("Python version 3.12 or greater required")
    print("Actual version is " + sys.version)
    sys.exit(1)

# pylint: disable=wrong-import-position
from collections.abc import Iterable
from pathlib import Path
# pylint: enable=wrong-import-position

DATA_PREFIX: str = 'data:image/svg+xml,'
SUBSTITUTIONS: tuple[tuple[str, str], ...] = (
    ('"', "'"),
    ('%', r'%25'),
    ('<', r'%3c'),
    ('>', r'%3e'),
    ('{', r'%7b'),
    ('}', r'%7d'),
    ('#', r'%23'),
)
SUBSTITUTIONS_WITH_SPACE: tuple[tuple[str, str], ...] = (*SUBSTITUTIONS, (' ', '%20'))

def show_syntax(app_name: str) -> None:
    print(
        f'Syntax: {app_name} input-file\n'
        '    Translates the specified SVG input file to a Data URI that is suitable\n'
        '    for embedding in a webpage. The result is written to stdout.\n'
        'Note:\n'
        '    It is recommended to process the SVG file through the optimiser, svgo,\n'
        '    before using this tool.\n'
        '    svgo is available from: https://github.com/svg/svgo\n'
        'Options:\n'
        '    -h  --help   Show this help\n'
        '    -s  --space  Translate spaces',
        )

def translate_file(filepath: Path, substitutions: tuple[tuple[str, str], ...]) -> int:
    try:
        file_text: str = filepath.read_text(encoding='utf-8')
    except OSError as ex:
        print(f"Error reading from '{filepath}': {ex}", file=sys.stderr)
        return 1

    key: str
    value: str
    for key, value in substitutions:
        file_text = file_text.replace(key, value)

    print(DATA_PREFIX + file_text)

    return 0

def main(app_name: str, list_of_args: Iterable[str]) -> int:
    if not list_of_args or '-h' in list_of_args or '--help' in list_of_args:
        show_syntax(app_name)
        return 0

    filepath: Path | None = None
    translate_space: bool = False

    arg: str
    for arg in list_of_args:
        if arg.startswith('-'):
            if arg in {'-s', '--space'}:
                translate_space = True
            else:
                print(f"Error: Unknown option '{arg}'")
                return 1
        elif filepath:
            print(f"Error: Excessive parameter '{arg}'")
            return 1
        else:
            filepath = Path(arg)

    if not filepath:
        print("Error: Missing input file argument")
        return 1

    if translate_space:
        return translate_file(filepath, SUBSTITUTIONS_WITH_SPACE)
    return translate_file(filepath, SUBSTITUTIONS)

if __name__ == "__main__":
    sys.exit(main(Path(sys.argv[0]).name, sys.argv[1:]))
