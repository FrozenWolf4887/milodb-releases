# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import unittest
from collections.abc import Mapping, MutableMapping
from typing import override
from milodb.client.database.author import Author, AuthorLoadError, load_author

_DICT_KEY_NAME: str = 'anm'
_DICT_KEY_GONE: str = 'agn'

_DEFAULT_AUTHOR_ID: int = 678
_DICT_DEFAULT_VALUE_NAME: str = 'Name of Author'
_DICT_DEFAULT_VALUE_GONE: bool = False

_AUTHOR_DEFAULT_VALUE_NAME: str = 'Name of Author'
_AUTHOR_DEFAULT_VALUE_GONE: bool =False

_AUTHOR_METADATA: Mapping[object, object] = {
    _DICT_KEY_NAME : _DICT_DEFAULT_VALUE_NAME,
    _DICT_KEY_GONE : _DICT_DEFAULT_VALUE_GONE,
}

class _TestAuthorBase(unittest.TestCase):
    @override
    def setUp(self) -> None:
        self.author_id: int = _DEFAULT_AUTHOR_ID
        self.tease_metadata: MutableMapping[object, object] = dict(_AUTHOR_METADATA)
        self.expect_author_id: int = _DEFAULT_AUTHOR_ID
        self.expect_author_name: str = _AUTHOR_DEFAULT_VALUE_NAME
        self.expect_author_gone: bool = _AUTHOR_DEFAULT_VALUE_GONE

    def _remove_key(self, key: str) -> None:
        del self.tease_metadata[key]

    def _change_key(self, key: str, value: object) -> None:
        self.tease_metadata[key] = value

    def _load_and_verify(self) -> None:
        author: Author = load_author(self.author_id, self.tease_metadata)
        self.assertEqual(self.expect_author_id, author.author_id)
        self.assertEqual(self.expect_author_name, author.name)
        self.assertEqual(self.expect_author_gone, author.has_gone)

    def _load_and_verify_exception_not_a_string(self, key: str) -> None:
        with self.assertRaises(AuthorLoadError) as ex:
            load_author(self.author_id, self.tease_metadata)
        self.assertEqual(f"Key '{key}' is not a string", str(ex.exception))

    def _load_and_verify_exception_not_a_boolean(self, key: str, value: str) -> None:
        with self.assertRaises(AuthorLoadError) as ex:
            load_author(self.author_id, self.tease_metadata)
        self.assertEqual(f"Key '{key}' value '{value}' is not a valid boolean", str(ex.exception))

class TestAuthorDefaults(_TestAuthorBase):
    def test_defaults_produces_all_defaults(self) -> None:
        self._load_and_verify()

class TestTeaseAuthorId(_TestAuthorBase):
    def test_specific_value_produces_expected_value(self) -> None:
        self.author_id = 38834
        self.expect_author_id = 38834
        self._load_and_verify()

    def test_zero_value_produces_no_author(self) -> None:
        self.author_id = 0
        self.expect_author_id = 0
        self._load_and_verify()

class TestAuthorName(_TestAuthorBase):
    def test_specific_value_produces_expected_value(self) -> None:
        self._change_key(_DICT_KEY_NAME, 'Vicky')
        self.expect_author_name = 'Vicky'
        self._load_and_verify()

    def test_empty_value_produces_empty_field(self) -> None:
        self._change_key(_DICT_KEY_NAME, '')
        self.expect_author_name = ''
        self._load_and_verify()

    def test_missing_key_produces_blank_field(self) -> None:
        self._remove_key(_DICT_KEY_NAME)
        self.expect_author_name = ''
        self._load_and_verify()

    def test_non_string_value_fails(self) -> None:
        self._change_key(_DICT_KEY_NAME, 77)
        self._load_and_verify_exception_not_a_string(_DICT_KEY_NAME)

class TestAuthorGone(_TestAuthorBase):
    def test_specific_value_produces_expected_value(self) -> None:
        self._change_key(_DICT_KEY_GONE, value=True)
        self.expect_author_gone = True
        self._load_and_verify()

    def test_missing_key_produces_default_value(self) -> None:
        self._remove_key(_DICT_KEY_GONE)
        self.expect_author_gone = False
        self._load_and_verify()

    def test_non_bool_value_fails(self) -> None:
        self._change_key(_DICT_KEY_GONE, 'Zip')
        self._load_and_verify_exception_not_a_boolean(_DICT_KEY_GONE, 'Zip')
