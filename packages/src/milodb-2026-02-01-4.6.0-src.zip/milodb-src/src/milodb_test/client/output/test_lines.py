# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from __future__ import annotations
import unittest
from dataclasses import dataclass
from enum import Enum
from typing import override
from milodb.client.output.lines import iterate_through_lines
from milodb_test.client.test import fake_text

@dataclass
class _NonEndOfLineText:
    text: str

@dataclass
class _EndOfLineText:
    text: str

class _EndOfLineType(Enum):
    NOT_END_OF_LINE_TEXT = _NonEndOfLineText
    END_OF_LINE_TEXT = _EndOfLineText

    def toggle(self) -> _EndOfLineType:
        if self.value is _NonEndOfLineText:
            return _EndOfLineType.END_OF_LINE_TEXT
        return _EndOfLineType.NOT_END_OF_LINE_TEXT

class TestIterateThroughLines(unittest.TestCase):
    @override
    def setUp(self) -> None:
        self.list_of_captured_text: list[_NonEndOfLineText | _EndOfLineText] = []

    def on_text(self, text: str) -> None:
        self.list_of_captured_text.append(_NonEndOfLineText(text))

    def on_end_of_line_text(self, text: str) -> None:
        self.list_of_captured_text.append(_EndOfLineText(text))

    def execute(self, text: str, starts_with_type: _EndOfLineType, *list_of_expected_text: str) -> None:
        iterate_through_lines(text, self.on_text, self.on_end_of_line_text)

        message_on_failure: str = f'\nExpected: {list_of_expected_text}\nReceived: {[capture.text for capture in self.list_of_captured_text]}'

        self.assertEqual(len(list_of_expected_text), len(self.list_of_captured_text),
                         f'Expected {len(list_of_expected_text)} text items, got {len(self.list_of_captured_text)}{message_on_failure}')
        text_type: _EndOfLineType = starts_with_type
        index: int
        captured_text: _NonEndOfLineText | _EndOfLineText
        for index, captured_text in enumerate(self.list_of_captured_text):
            self.assertIsInstance(captured_text, text_type.value,
                                  f'text "{captured_text.text}" should of be of type {text_type.value.__name__} at index {index}{message_on_failure}')
            self.assertEqual(list_of_expected_text[index], captured_text.text,
                             f'text mismatch at index {index}{message_on_failure}')
            text_type = text_type.toggle()

    def test_middle_end_of_lines_are_returned(self) -> None:
        self.execute(
            fake_text.MULTILINE_TEXT,
            _EndOfLineType.NOT_END_OF_LINE_TEXT,
            fake_text.MULTILINE_TEXT[:fake_text.INDEX_OF_FIRST_EOL],
            fake_text.MULTILINE_TEXT[fake_text.INDEX_OF_FIRST_EOL:fake_text.INDEX_OF_FIRST_EOL_END],
            fake_text.MULTILINE_TEXT[fake_text.INDEX_OF_FIRST_EOL_END:fake_text.INDEX_OF_SECOND_EOL],
            fake_text.MULTILINE_TEXT[fake_text.INDEX_OF_SECOND_EOL:fake_text.INDEX_OF_SECOND_EOL_END],
            fake_text.MULTILINE_TEXT[fake_text.INDEX_OF_SECOND_EOL_END:fake_text.INDEX_OF_THIRD_EOL],
            fake_text.MULTILINE_TEXT[fake_text.INDEX_OF_THIRD_EOL:fake_text.INDEX_OF_THIRD_EOL_END],
            fake_text.MULTILINE_TEXT[fake_text.INDEX_OF_THIRD_EOL_END:],
        )

    def test_starting_end_of_line_is_returned(self) -> None:
        self.execute(
            fake_text.MULTILINE_TEXT[fake_text.INDEX_OF_FIRST_EOL:],
            _EndOfLineType.END_OF_LINE_TEXT,
            fake_text.MULTILINE_TEXT[fake_text.INDEX_OF_FIRST_EOL:fake_text.INDEX_OF_FIRST_EOL_END],
            fake_text.MULTILINE_TEXT[fake_text.INDEX_OF_FIRST_EOL_END:fake_text.INDEX_OF_SECOND_EOL],
            fake_text.MULTILINE_TEXT[fake_text.INDEX_OF_SECOND_EOL:fake_text.INDEX_OF_SECOND_EOL_END],
            fake_text.MULTILINE_TEXT[fake_text.INDEX_OF_SECOND_EOL_END:fake_text.INDEX_OF_THIRD_EOL],
            fake_text.MULTILINE_TEXT[fake_text.INDEX_OF_THIRD_EOL:fake_text.INDEX_OF_THIRD_EOL_END],
            fake_text.MULTILINE_TEXT[fake_text.INDEX_OF_THIRD_EOL_END:],
        )

    def test_ending_end_of_line_is_returned(self) -> None:
        self.execute(
            fake_text.MULTILINE_TEXT[:fake_text.INDEX_OF_THIRD_EOL_END],
            _EndOfLineType.NOT_END_OF_LINE_TEXT,
            fake_text.MULTILINE_TEXT[:fake_text.INDEX_OF_FIRST_EOL],
            fake_text.MULTILINE_TEXT[fake_text.INDEX_OF_FIRST_EOL:fake_text.INDEX_OF_FIRST_EOL_END],
            fake_text.MULTILINE_TEXT[fake_text.INDEX_OF_FIRST_EOL_END:fake_text.INDEX_OF_SECOND_EOL],
            fake_text.MULTILINE_TEXT[fake_text.INDEX_OF_SECOND_EOL:fake_text.INDEX_OF_SECOND_EOL_END],
            fake_text.MULTILINE_TEXT[fake_text.INDEX_OF_SECOND_EOL_END:fake_text.INDEX_OF_THIRD_EOL],
            fake_text.MULTILINE_TEXT[fake_text.INDEX_OF_THIRD_EOL:fake_text.INDEX_OF_THIRD_EOL_END],
        )

    def test_no_end_of_lines_returns_plain_text(self) -> None:
        self.execute(
            fake_text.MULTILINE_TEXT[:fake_text.INDEX_OF_FIRST_EOL],
            _EndOfLineType.NOT_END_OF_LINE_TEXT,
            fake_text.MULTILINE_TEXT[:fake_text.INDEX_OF_FIRST_EOL],
        )

    def test_only_end_of_line_returns_end_of_line(self) -> None:
        self.execute(
            fake_text.MULTILINE_TEXT[fake_text.INDEX_OF_FIRST_EOL:fake_text.INDEX_OF_FIRST_EOL_END],
            _EndOfLineType.END_OF_LINE_TEXT,
            fake_text.MULTILINE_TEXT[fake_text.INDEX_OF_FIRST_EOL:fake_text.INDEX_OF_FIRST_EOL_END],
        )

    def test_multiple_end_of_lines_returns_lump_of_end_of_lines(self) -> None:
        self.execute(
            fake_text.MULTI_EOL_TEXT,
            _EndOfLineType.NOT_END_OF_LINE_TEXT,
            fake_text.MULTI_EOL_TEXT[:fake_text.INDEX_OF_MULTI_EOL],
            fake_text.MULTI_EOL_TEXT[fake_text.INDEX_OF_MULTI_EOL:fake_text.INDEX_OF_MULTI_EOL_END],
            fake_text.MULTI_EOL_TEXT[fake_text.INDEX_OF_MULTI_EOL_END:],
        )
