# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from __future__ import annotations
import unittest
from dataclasses import dataclass
from enum import Enum
from typing import TYPE_CHECKING, override
from milodb.client.output.match_indices import iterate_match_indices
from milodb.client.query.field_match import IFieldMatch
from milodb_test.client.test import fake_text
if TYPE_CHECKING:
    from collections.abc import Iterable

@dataclass
class _NormalText:
    text: str
    is_first_item: bool
    is_last_item: bool

@dataclass
class _MatchedText:
    text: str
    is_first_item: bool
    is_last_item: bool

class _TextType(Enum):
    NORMAL_TEXT = _NormalText
    MATCHED_TEXT = _MatchedText

    def toggle(self) -> _TextType:
        if self.value is _NormalText:
            return _TextType.MATCHED_TEXT
        return _TextType.NORMAL_TEXT

class TestIterateMatchIndices(unittest.TestCase):
    @override
    def setUp(self) -> None:
        self.list_of_captured_text: list[_NormalText | _MatchedText] = []

    def on_normal_text(self, text: str, *, is_first_item: bool, is_last_item: bool) -> None:
        self.list_of_captured_text.append(_NormalText(text, is_first_item, is_last_item))

    def on_matched_text(self, text: str, *, is_first_item: bool, is_last_item: bool) -> None:
        self.list_of_captured_text.append(_MatchedText(text, is_first_item, is_last_item))

    def execute(self, text: str, list_of_indices: Iterable[IFieldMatch.Indices], starts_with_type: _TextType, *list_of_expected_text: str) -> None:
        iterate_match_indices(text, list_of_indices, self.on_normal_text, self.on_matched_text)

        message_on_failure: str = f'\nExpected: {list_of_expected_text}\nReceived: {[match.text for match in self.list_of_captured_text]}\nDetails: {self.list_of_captured_text}'

        self.assertEqual(len(list_of_expected_text), len(self.list_of_captured_text),
                         f'Expected {len(list_of_expected_text)} text items, got {len(self.list_of_captured_text)}{message_on_failure}')
        text_type: _TextType = starts_with_type
        index: int
        captured_text: _NormalText | _MatchedText
        for index, captured_text in enumerate(self.list_of_captured_text):
            self.assertEqual(index == 0, captured_text.is_first_item,
                             f'is_first_item should be {index==0} at index {index}{message_on_failure}')
            self.assertEqual(index == len(list_of_expected_text) - 1, captured_text.is_last_item,
                             f'is_last_item should be {index == len(list_of_expected_text) - 1} at index {index}{message_on_failure}')
            self.assertIsInstance(captured_text, text_type.value,
                                  f'text "{captured_text.text}" should of be of type {text_type.value.__name__} at index {index}{message_on_failure}')
            self.assertEqual(list_of_expected_text[index], captured_text.text,
                             f'text mismatch at index {index}{message_on_failure}')
            text_type = text_type.toggle()

    def test_empty_matches(self) -> None:
        self.execute(
            fake_text.TEXT,
            [],
            _TextType.NORMAL_TEXT,
            fake_text.TEXT,
        )

    def test_single_match_at_start(self) -> None:
        self.execute(
            fake_text.TEXT,
            [IFieldMatch.Indices(0, 5)],
            _TextType.MATCHED_TEXT,
            fake_text.TEXT[:5],
            fake_text.TEXT[5:],
        )

    def test_single_match_of_one_character_at_start(self) -> None:
        self.execute(
            fake_text.TEXT,
            [IFieldMatch.Indices(0, 1)],
            _TextType.MATCHED_TEXT,
            fake_text.TEXT[:1],
            fake_text.TEXT[1:],
        )

    def test_single_match_at_end(self) -> None:
        self.execute(
            fake_text.TEXT,
            [IFieldMatch.Indices(fake_text.TEXT_LEN - 5, fake_text.TEXT_LEN)],
            _TextType.NORMAL_TEXT,
            fake_text.TEXT[:-5],
            fake_text.TEXT[-5:],
        )

    def test_single_match_of_one_character_at_end(self) -> None:
        self.execute(
            fake_text.TEXT,
            [IFieldMatch.Indices(fake_text.TEXT_LEN - 1, fake_text.TEXT_LEN)],
            _TextType.NORMAL_TEXT,
            fake_text.TEXT[:-1],
            fake_text.TEXT[-1:],
        )

    def test_single_match_in_middle(self) -> None:
        self.execute(
            fake_text.TEXT,
            [IFieldMatch.Indices(40, 45)],
            _TextType.NORMAL_TEXT,
            fake_text.TEXT[:40],
            fake_text.TEXT[40:45],
            fake_text.TEXT[45:],
        )

    def test_single_match_of_one_character_in_middle(self) -> None:
        self.execute(
            fake_text.TEXT,
            [IFieldMatch.Indices(40, 41)],
            _TextType.NORMAL_TEXT,
            fake_text.TEXT[:40],
            fake_text.TEXT[40:41],
            fake_text.TEXT[41:],
        )

    def test_two_matches_in_order_at_start_and_end(self) -> None:
        self.execute(
            fake_text.TEXT,
            [IFieldMatch.Indices(0, 10), IFieldMatch.Indices(fake_text.TEXT_LEN - 10, fake_text.TEXT_LEN)],
            _TextType.MATCHED_TEXT,
            fake_text.TEXT[:10],
            fake_text.TEXT[10:-10],
            fake_text.TEXT[-10:],
        )

    def test_two_matches_in_order_in_middle(self) -> None:
        self.execute(
            fake_text.TEXT,
            [IFieldMatch.Indices(20, 25), IFieldMatch.Indices(fake_text.TEXT_LEN - 20, fake_text.TEXT_LEN - 15)],
            _TextType.NORMAL_TEXT,
            fake_text.TEXT[:20],
            fake_text.TEXT[20:25],
            fake_text.TEXT[25:-20],
            fake_text.TEXT[-20:-15],
            fake_text.TEXT[-15:],
        )

    def test_two_matches_out_of_order_at_start_and_end(self) -> None:
        self.execute(
            fake_text.TEXT,
            [IFieldMatch.Indices(fake_text.TEXT_LEN - 10, fake_text.TEXT_LEN), IFieldMatch.Indices(0, 10)],
            _TextType.MATCHED_TEXT,
            fake_text.TEXT[:10],
            fake_text.TEXT[10:-10],
            fake_text.TEXT[-10:],
        )

    def test_two_matches_out_of_order_in_middle(self) -> None:
        self.execute(
            fake_text.TEXT,
            [IFieldMatch.Indices(fake_text.TEXT_LEN - 20, fake_text.TEXT_LEN - 15), IFieldMatch.Indices(20, 25)],
            _TextType.NORMAL_TEXT,
            fake_text.TEXT[:20],
            fake_text.TEXT[20:25],
            fake_text.TEXT[25:-20],
            fake_text.TEXT[-20:-15],
            fake_text.TEXT[-15:],
        )

    def test_two_consecutive_matches_in_order(self) -> None:
        self.execute(
            fake_text.TEXT,
            [IFieldMatch.Indices(20, 25), IFieldMatch.Indices(25, 35)],
            _TextType.NORMAL_TEXT,
            fake_text.TEXT[:20],
            fake_text.TEXT[20:35],
            fake_text.TEXT[35:],
        )

    def test_two_consecutive_matches_out_of_order(self) -> None:
        self.execute(
            fake_text.TEXT,
            [IFieldMatch.Indices(25, 35), IFieldMatch.Indices(20, 25)],
            _TextType.NORMAL_TEXT,
            fake_text.TEXT[:20],
            fake_text.TEXT[20:35],
            fake_text.TEXT[35:],
        )

    def test_two_overlapping_matches_in_order(self) -> None:
        self.execute(
            fake_text.TEXT,
            [IFieldMatch.Indices(20, 25), IFieldMatch.Indices(23, 33)],
            _TextType.NORMAL_TEXT,
            fake_text.TEXT[:20],
            fake_text.TEXT[20:33],
            fake_text.TEXT[33:],
        )

    def test_two_overlapping_matches_out_of_order(self) -> None:
        self.execute(
            fake_text.TEXT,
            [IFieldMatch.Indices(23, 33), IFieldMatch.Indices(20, 25)],
            _TextType.NORMAL_TEXT,
            fake_text.TEXT[:20],
            fake_text.TEXT[20:33],
            fake_text.TEXT[33:],
        )

    def test_two_completely_overlapping_matches_in_order(self) -> None:
        self.execute(
            fake_text.TEXT,
            [IFieldMatch.Indices(20, 40), IFieldMatch.Indices(25, 35)],
            _TextType.NORMAL_TEXT,
            fake_text.TEXT[:20],
            fake_text.TEXT[20:40],
            fake_text.TEXT[40:],
        )

    def test_two_completely_overlapping_matches_out_of_order(self) -> None:
        self.execute(
            fake_text.TEXT,
            [IFieldMatch.Indices(25, 35), IFieldMatch.Indices(20, 40)],
            _TextType.NORMAL_TEXT,
            fake_text.TEXT[:20],
            fake_text.TEXT[20:40],
            fake_text.TEXT[40:],
        )

    def test_single_match_extending_after_end(self) -> None:
        self.execute(
            fake_text.TEXT,
            [IFieldMatch.Indices(fake_text.TEXT_LEN - 10, fake_text.TEXT_LEN + 5)],
            _TextType.NORMAL_TEXT,
            fake_text.TEXT[:-10],
            fake_text.TEXT[-10:],
        )

    def test_three_matches_where_one_match_completely_overlaps_the_others(self) -> None:
        self.execute(
            fake_text.TEXT,
            [IFieldMatch.Indices(20, 25), IFieldMatch.Indices(15, 40), IFieldMatch.Indices(30, 35)],
            _TextType.NORMAL_TEXT,
            fake_text.TEXT[:15],
            fake_text.TEXT[15:40],
            fake_text.TEXT[40:],
        )

    def test_single_whole_match_matches_all_text(self) -> None:
        self.execute(
            fake_text.TEXT,
            [IFieldMatch.Indices.whole_match()],
            _TextType.MATCHED_TEXT,
            fake_text.TEXT,
        )

    def test_single_whole_match_embedded_within_matches_matches_all_text(self) -> None:
        self.execute(
            fake_text.TEXT,
            [IFieldMatch.Indices(20, 25), IFieldMatch.Indices.whole_match(), IFieldMatch.Indices(30, 35)],
            _TextType.MATCHED_TEXT,
            fake_text.TEXT,
        )

    def test_single_match_spanning_eol_includes_eol(self) -> None:
        self.execute(
            fake_text.MULTILINE_TEXT,
            [IFieldMatch.Indices(fake_text.INDEX_OF_FIRST_EOL - 5, fake_text.INDEX_OF_FIRST_EOL + 5)],
            _TextType.NORMAL_TEXT,
            fake_text.MULTILINE_TEXT[:fake_text.INDEX_OF_FIRST_EOL - 5],
            fake_text.MULTILINE_TEXT[fake_text.INDEX_OF_FIRST_EOL - 5:fake_text.INDEX_OF_FIRST_EOL + 5],
            fake_text.MULTILINE_TEXT[fake_text.INDEX_OF_FIRST_EOL + 5:],
        )
