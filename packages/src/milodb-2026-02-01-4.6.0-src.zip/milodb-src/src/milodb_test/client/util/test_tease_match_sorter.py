# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import unittest
from collections.abc import Sequence
from unittest.mock import Mock, PropertyMock
from milodb.client.query.field_match import IFieldMatch
from milodb.client.query.tease_match import TeaseMatch
from milodb.client.util.sort_keys import AUTHOR_ID_SORT_KEY, DATE_SORT_KEY, ISortKey, MATCH_COUNT_SORT_KEY, OrderedSortKey, RATING_SORT_KEY, TEASE_ID_SORT_KEY, TITLE_SORT_KEY, TOTM_SORT_KEY, TYPE_SORT_KEY
from milodb.client.util.tease_match_sorter import TeaseMatchSorter
from milodb_test.client.test import fake_teases
from milodb_test.client.test.matchers_teases import is_equal_list_of_tease_matches
from milodb_test.common.test.strict_mock import InterfaceMock

_DEFAULT_LIST_OF_TEASE_MATCHES: Sequence[TeaseMatch] = [
    TeaseMatch(1, fake_teases.TEASE_ID_1234_AUTHOR_ID_6431, []),
    TeaseMatch(2, fake_teases.TEASE_ID_1000_AUTHOR_ID_4567, []),
    TeaseMatch(3, fake_teases.TEASE_ID_5678_AUTHOR_ID_4567, []),
    TeaseMatch(4, fake_teases.TEASE_ID_8721_AUTHOR_ID_7213, []),
    TeaseMatch(5, fake_teases.TEASE_ID_2000_AUTHOR_ID_6431, []),
]

class TestTeaseMatchSorter(unittest.TestCase):
    def test_sort_empty_list_with_no_keys_returns_empty_list(self) -> None:
        sorted_list: Sequence[TeaseMatch] = TeaseMatchSorter([]).sort([], [])
        self.assertSequenceEqual([], sorted_list)

    def test_sort_empty_list_with_some_keys_returns_empty_list(self) -> None:
        sorted_list: Sequence[TeaseMatch] = TeaseMatchSorter([]).sort([], [
            InterfaceMock(ISortKey),
            InterfaceMock(ISortKey),
        ])
        self.assertSequenceEqual([], sorted_list)

    def test_sort_empty_list_with_no_keys_and_some_defaults_returns_empty_list(self) -> None:
        sorted_list: Sequence[TeaseMatch] = TeaseMatchSorter([
            InterfaceMock(ISortKey),
            InterfaceMock(ISortKey),
        ]).sort([], [])
        self.assertSequenceEqual([], sorted_list)

    def test_sort_with_no_keys_returns_same_list(self) -> None:
        sorted_list: Sequence[TeaseMatch] = TeaseMatchSorter([]).sort(_DEFAULT_LIST_OF_TEASE_MATCHES, [])
        self.assertTrue(is_equal_list_of_tease_matches(sorted_list, _DEFAULT_LIST_OF_TEASE_MATCHES))

    def test_sort_by_tease_id_ascending_returns_sorted_list(self) -> None:
        sorted_list: Sequence[TeaseMatch] = TeaseMatchSorter([]).sort(
            _DEFAULT_LIST_OF_TEASE_MATCHES, [
                OrderedSortKey(TEASE_ID_SORT_KEY, is_ascending=True),
        ])
        self.assertTrue(is_equal_list_of_tease_matches(sorted_list, [
            TeaseMatch(1, fake_teases.TEASE_ID_1000_AUTHOR_ID_4567, []),
            TeaseMatch(2, fake_teases.TEASE_ID_1234_AUTHOR_ID_6431, []),
            TeaseMatch(3, fake_teases.TEASE_ID_2000_AUTHOR_ID_6431, []),
            TeaseMatch(4, fake_teases.TEASE_ID_5678_AUTHOR_ID_4567, []),
            TeaseMatch(5, fake_teases.TEASE_ID_8721_AUTHOR_ID_7213, []),
        ]))

    def test_sort_by_tease_id_descending_returns_sorted_list(self) -> None:
        sorted_list: Sequence[TeaseMatch] = TeaseMatchSorter([]).sort(
            _DEFAULT_LIST_OF_TEASE_MATCHES, [
                OrderedSortKey(TEASE_ID_SORT_KEY, is_ascending=False),
        ])
        self.assertTrue(is_equal_list_of_tease_matches(sorted_list, [
            TeaseMatch(1, fake_teases.TEASE_ID_8721_AUTHOR_ID_7213, []),
            TeaseMatch(2, fake_teases.TEASE_ID_5678_AUTHOR_ID_4567, []),
            TeaseMatch(3, fake_teases.TEASE_ID_2000_AUTHOR_ID_6431, []),
            TeaseMatch(4, fake_teases.TEASE_ID_1234_AUTHOR_ID_6431, []),
            TeaseMatch(5, fake_teases.TEASE_ID_1000_AUTHOR_ID_4567, []),
        ]))

    def test_sort_by_author_id_ascending_returns_sorted_list(self) -> None:
        sorted_list: Sequence[TeaseMatch] = TeaseMatchSorter([]).sort(
            _DEFAULT_LIST_OF_TEASE_MATCHES, [
                OrderedSortKey(AUTHOR_ID_SORT_KEY, is_ascending=True),
        ])
        self.assertTrue(is_equal_list_of_tease_matches(sorted_list, [
            TeaseMatch(1, fake_teases.TEASE_ID_1000_AUTHOR_ID_4567, []),
            TeaseMatch(2, fake_teases.TEASE_ID_5678_AUTHOR_ID_4567, []),
            TeaseMatch(3, fake_teases.TEASE_ID_1234_AUTHOR_ID_6431, []),
            TeaseMatch(4, fake_teases.TEASE_ID_2000_AUTHOR_ID_6431, []),
            TeaseMatch(5, fake_teases.TEASE_ID_8721_AUTHOR_ID_7213, []),
        ]))

    def test_sort_by_author_id_descending_returns_sorted_list(self) -> None:
        sorted_list: Sequence[TeaseMatch] = TeaseMatchSorter([]).sort(
            _DEFAULT_LIST_OF_TEASE_MATCHES, [
                OrderedSortKey(AUTHOR_ID_SORT_KEY, is_ascending=False),
        ])
        self.assertTrue(is_equal_list_of_tease_matches(sorted_list, [
            TeaseMatch(1, fake_teases.TEASE_ID_8721_AUTHOR_ID_7213, []),
            TeaseMatch(2, fake_teases.TEASE_ID_1234_AUTHOR_ID_6431, []),
            TeaseMatch(3, fake_teases.TEASE_ID_2000_AUTHOR_ID_6431, []),
            TeaseMatch(4, fake_teases.TEASE_ID_1000_AUTHOR_ID_4567, []),
            TeaseMatch(5, fake_teases.TEASE_ID_5678_AUTHOR_ID_4567, []),
        ]))

    def test_sort_by_date_ascending_returns_sorted_list(self) -> None:
        sorted_list: Sequence[TeaseMatch] = TeaseMatchSorter([]).sort(
            _DEFAULT_LIST_OF_TEASE_MATCHES, [
                OrderedSortKey(DATE_SORT_KEY, is_ascending=True),
        ])
        self.assertTrue(is_equal_list_of_tease_matches(sorted_list, [
            TeaseMatch(1, fake_teases.TEASE_ID_5678_AUTHOR_ID_4567, []),
            TeaseMatch(2, fake_teases.TEASE_ID_1000_AUTHOR_ID_4567, []),
            TeaseMatch(3, fake_teases.TEASE_ID_1234_AUTHOR_ID_6431, []),
            TeaseMatch(4, fake_teases.TEASE_ID_2000_AUTHOR_ID_6431, []),
            TeaseMatch(5, fake_teases.TEASE_ID_8721_AUTHOR_ID_7213, []),
        ]))

    def test_sort_by_date_descending_returns_sorted_list(self) -> None:
        sorted_list: Sequence[TeaseMatch] = TeaseMatchSorter([]).sort(
            _DEFAULT_LIST_OF_TEASE_MATCHES, [
                OrderedSortKey(DATE_SORT_KEY, is_ascending=False),
        ])
        self.assertTrue(is_equal_list_of_tease_matches(sorted_list, [
            TeaseMatch(1, fake_teases.TEASE_ID_8721_AUTHOR_ID_7213, []),
            TeaseMatch(2, fake_teases.TEASE_ID_2000_AUTHOR_ID_6431, []),
            TeaseMatch(3, fake_teases.TEASE_ID_1234_AUTHOR_ID_6431, []),
            TeaseMatch(4, fake_teases.TEASE_ID_1000_AUTHOR_ID_4567, []),
            TeaseMatch(5, fake_teases.TEASE_ID_5678_AUTHOR_ID_4567, []),
        ]))

    def test_sort_by_title_ascending_returns_sorted_list(self) -> None:
        sorted_list: Sequence[TeaseMatch] = TeaseMatchSorter([]).sort(
            _DEFAULT_LIST_OF_TEASE_MATCHES, [
                OrderedSortKey(TITLE_SORT_KEY, is_ascending=True),
        ])
        self.assertTrue(is_equal_list_of_tease_matches(sorted_list, [
            TeaseMatch(1, fake_teases.TEASE_ID_1234_AUTHOR_ID_6431, []),
            TeaseMatch(2, fake_teases.TEASE_ID_1000_AUTHOR_ID_4567, []),
            TeaseMatch(3, fake_teases.TEASE_ID_5678_AUTHOR_ID_4567, []),
            TeaseMatch(4, fake_teases.TEASE_ID_8721_AUTHOR_ID_7213, []),
            TeaseMatch(5, fake_teases.TEASE_ID_2000_AUTHOR_ID_6431, []),
        ]))

    def test_sort_by_title_descending_returns_sorted_list(self) -> None:
        sorted_list: Sequence[TeaseMatch] = TeaseMatchSorter([]).sort(
            _DEFAULT_LIST_OF_TEASE_MATCHES, [
                OrderedSortKey(TITLE_SORT_KEY, is_ascending=False),
        ])
        self.assertTrue(is_equal_list_of_tease_matches(sorted_list, [
            TeaseMatch(1, fake_teases.TEASE_ID_2000_AUTHOR_ID_6431, []),
            TeaseMatch(2, fake_teases.TEASE_ID_8721_AUTHOR_ID_7213, []),
            TeaseMatch(3, fake_teases.TEASE_ID_5678_AUTHOR_ID_4567, []),
            TeaseMatch(4, fake_teases.TEASE_ID_1000_AUTHOR_ID_4567, []),
            TeaseMatch(5, fake_teases.TEASE_ID_1234_AUTHOR_ID_6431, []),
        ]))

    def test_sort_by_rating_ascending_returns_sorted_list(self) -> None:
        sorted_list: Sequence[TeaseMatch] = TeaseMatchSorter([]).sort(
            _DEFAULT_LIST_OF_TEASE_MATCHES, [
                OrderedSortKey(RATING_SORT_KEY, is_ascending=True),
        ])
        self.assertTrue(is_equal_list_of_tease_matches(sorted_list, [
            TeaseMatch(1, fake_teases.TEASE_ID_8721_AUTHOR_ID_7213, []),
            TeaseMatch(2, fake_teases.TEASE_ID_5678_AUTHOR_ID_4567, []),
            TeaseMatch(3, fake_teases.TEASE_ID_1234_AUTHOR_ID_6431, []),
            TeaseMatch(4, fake_teases.TEASE_ID_1000_AUTHOR_ID_4567, []),
            TeaseMatch(5, fake_teases.TEASE_ID_2000_AUTHOR_ID_6431, []),
        ]))

    def test_sort_by_rating_descending_returns_sorted_list(self) -> None:
        sorted_list: Sequence[TeaseMatch] = TeaseMatchSorter([]).sort(
            _DEFAULT_LIST_OF_TEASE_MATCHES, [
                OrderedSortKey(RATING_SORT_KEY, is_ascending=False),
        ])
        self.assertTrue(is_equal_list_of_tease_matches(sorted_list, [
            TeaseMatch(1, fake_teases.TEASE_ID_2000_AUTHOR_ID_6431, []),
            TeaseMatch(2, fake_teases.TEASE_ID_1000_AUTHOR_ID_4567, []),
            TeaseMatch(3, fake_teases.TEASE_ID_1234_AUTHOR_ID_6431, []),
            TeaseMatch(4, fake_teases.TEASE_ID_5678_AUTHOR_ID_4567, []),
            TeaseMatch(5, fake_teases.TEASE_ID_8721_AUTHOR_ID_7213, []),
        ]))

    def test_sort_by_type_ascending_returns_sorted_list(self) -> None:
        sorted_list: Sequence[TeaseMatch] = TeaseMatchSorter([]).sort(
            _DEFAULT_LIST_OF_TEASE_MATCHES, [
                OrderedSortKey(TYPE_SORT_KEY, is_ascending=True),
        ])
        self.assertTrue(is_equal_list_of_tease_matches(sorted_list, [
            TeaseMatch(1, fake_teases.TEASE_ID_2000_AUTHOR_ID_6431, []),
            TeaseMatch(2, fake_teases.TEASE_ID_1234_AUTHOR_ID_6431, []),
            TeaseMatch(3, fake_teases.TEASE_ID_8721_AUTHOR_ID_7213, []),
            TeaseMatch(4, fake_teases.TEASE_ID_1000_AUTHOR_ID_4567, []),
            TeaseMatch(5, fake_teases.TEASE_ID_5678_AUTHOR_ID_4567, []),
        ]))

    def test_sort_by_type_descending_returns_sorted_list(self) -> None:
        sorted_list: Sequence[TeaseMatch] = TeaseMatchSorter([]).sort(
            _DEFAULT_LIST_OF_TEASE_MATCHES, [
                OrderedSortKey(TYPE_SORT_KEY, is_ascending=False),
        ])
        self.assertTrue(is_equal_list_of_tease_matches(sorted_list, [
            TeaseMatch(1, fake_teases.TEASE_ID_5678_AUTHOR_ID_4567, []),
            TeaseMatch(2, fake_teases.TEASE_ID_1000_AUTHOR_ID_4567, []),
            TeaseMatch(3, fake_teases.TEASE_ID_1234_AUTHOR_ID_6431, []),
            TeaseMatch(4, fake_teases.TEASE_ID_8721_AUTHOR_ID_7213, []),
            TeaseMatch(5, fake_teases.TEASE_ID_2000_AUTHOR_ID_6431, []),
        ]))

    def test_sort_by_totm_ascending_returns_sorted_list(self) -> None:
        sorted_list: Sequence[TeaseMatch] = TeaseMatchSorter([]).sort(
            _DEFAULT_LIST_OF_TEASE_MATCHES, [
                OrderedSortKey(TOTM_SORT_KEY, is_ascending=True),
        ])
        self.assertTrue(is_equal_list_of_tease_matches(sorted_list, [
            TeaseMatch(1, fake_teases.TEASE_ID_5678_AUTHOR_ID_4567, []),
            TeaseMatch(2, fake_teases.TEASE_ID_8721_AUTHOR_ID_7213, []),
            TeaseMatch(3, fake_teases.TEASE_ID_1000_AUTHOR_ID_4567, []),
            TeaseMatch(4, fake_teases.TEASE_ID_2000_AUTHOR_ID_6431, []),
            TeaseMatch(5, fake_teases.TEASE_ID_1234_AUTHOR_ID_6431, []),
        ]))

    def test_sort_by_totm_descending_returns_sorted_list(self) -> None:
        sorted_list: Sequence[TeaseMatch] = TeaseMatchSorter([]).sort(
            _DEFAULT_LIST_OF_TEASE_MATCHES, [
                OrderedSortKey(TOTM_SORT_KEY, is_ascending=False),
        ])
        self.assertTrue(is_equal_list_of_tease_matches(sorted_list, [
            TeaseMatch(1, fake_teases.TEASE_ID_1234_AUTHOR_ID_6431, []),
            TeaseMatch(2, fake_teases.TEASE_ID_1000_AUTHOR_ID_4567, []),
            TeaseMatch(3, fake_teases.TEASE_ID_2000_AUTHOR_ID_6431, []),
            TeaseMatch(4, fake_teases.TEASE_ID_5678_AUTHOR_ID_4567, []),
            TeaseMatch(5, fake_teases.TEASE_ID_8721_AUTHOR_ID_7213, []),
        ]))

    def test_sort_by_match_count_ascending_returns_sorted_list(self) -> None:
        mock_indices = Mock(IFieldMatch.Indices)
        list_of_one_field_match_with_four_indices: Sequence[InterfaceMock] = [
            InterfaceMock(IFieldMatch,
                list_of_indices = PropertyMock(return_value=[mock_indices, mock_indices, mock_indices, mock_indices]),
            ),
        ]
        list_of_two_field_matches_with_five_indices: Sequence[InterfaceMock] = [
            InterfaceMock(IFieldMatch,
                list_of_indices = PropertyMock(return_value=[mock_indices, mock_indices]),
            ),
            InterfaceMock(IFieldMatch,
                list_of_indices = PropertyMock(return_value=[mock_indices, mock_indices, mock_indices]),
            ),
        ]
        list_of_three_field_matches_with_three_indices: Sequence[InterfaceMock] = [
            InterfaceMock(IFieldMatch,
                list_of_indices = PropertyMock(return_value=[mock_indices]),
            ),
            InterfaceMock(IFieldMatch,
                list_of_indices = PropertyMock(return_value=[mock_indices]),
            ),
            InterfaceMock(IFieldMatch,
                list_of_indices = PropertyMock(return_value=[mock_indices]),
            ),
        ]
        list_of_tease_matches: Sequence[TeaseMatch] = [
            TeaseMatch(1, fake_teases.TEASE_ID_1234_AUTHOR_ID_6431, []),
            TeaseMatch(2, fake_teases.TEASE_ID_1000_AUTHOR_ID_4567, [*list_of_two_field_matches_with_five_indices]),
            TeaseMatch(3, fake_teases.TEASE_ID_5678_AUTHOR_ID_4567, []),
            TeaseMatch(4, fake_teases.TEASE_ID_8721_AUTHOR_ID_7213, [*list_of_three_field_matches_with_three_indices]),
            TeaseMatch(5, fake_teases.TEASE_ID_2000_AUTHOR_ID_6431, [*list_of_one_field_match_with_four_indices]),
        ]
        sorted_list: Sequence[TeaseMatch] = TeaseMatchSorter([]).sort(list_of_tease_matches, [OrderedSortKey(MATCH_COUNT_SORT_KEY, is_ascending=True)])
        self.assertTrue(is_equal_list_of_tease_matches(sorted_list, [
            TeaseMatch(1, fake_teases.TEASE_ID_1234_AUTHOR_ID_6431, []),
            TeaseMatch(2, fake_teases.TEASE_ID_5678_AUTHOR_ID_4567, []),
            TeaseMatch(3, fake_teases.TEASE_ID_8721_AUTHOR_ID_7213, [*list_of_three_field_matches_with_three_indices]),
            TeaseMatch(4, fake_teases.TEASE_ID_2000_AUTHOR_ID_6431, [*list_of_one_field_match_with_four_indices]),
            TeaseMatch(5, fake_teases.TEASE_ID_1000_AUTHOR_ID_4567, [*list_of_two_field_matches_with_five_indices]),
        ]))

    def test_sort_by_match_count_descending_returns_sorted_list(self) -> None:
        mock_indices = Mock(IFieldMatch.Indices)
        list_of_one_field_match_with_four_indices: Sequence[InterfaceMock] = [
            InterfaceMock(IFieldMatch,
                list_of_indices = PropertyMock(return_value=[mock_indices, mock_indices, mock_indices, mock_indices]),
            ),
        ]
        list_of_two_field_matches_with_five_indices: Sequence[InterfaceMock] = [
            InterfaceMock(IFieldMatch,
                list_of_indices = PropertyMock(return_value=[mock_indices, mock_indices]),
            ),
            InterfaceMock(IFieldMatch,
                list_of_indices = PropertyMock(return_value=[mock_indices, mock_indices, mock_indices]),
            ),
        ]
        list_of_three_field_matches_with_three_indices: Sequence[InterfaceMock] = [
            InterfaceMock(IFieldMatch,
                list_of_indices = PropertyMock(return_value=[mock_indices]),
            ),
            InterfaceMock(IFieldMatch,
                list_of_indices = PropertyMock(return_value=[mock_indices]),
            ),
            InterfaceMock(IFieldMatch,
                list_of_indices = PropertyMock(return_value=[mock_indices]),
            ),
        ]
        list_of_tease_matches: Sequence[TeaseMatch] = [
            TeaseMatch(1, fake_teases.TEASE_ID_1234_AUTHOR_ID_6431, []),
            TeaseMatch(2, fake_teases.TEASE_ID_1000_AUTHOR_ID_4567, [*list_of_two_field_matches_with_five_indices]),
            TeaseMatch(3, fake_teases.TEASE_ID_5678_AUTHOR_ID_4567, []),
            TeaseMatch(4, fake_teases.TEASE_ID_8721_AUTHOR_ID_7213, [*list_of_three_field_matches_with_three_indices]),
            TeaseMatch(5, fake_teases.TEASE_ID_2000_AUTHOR_ID_6431, [*list_of_one_field_match_with_four_indices]),
        ]
        sorted_list: Sequence[TeaseMatch] = TeaseMatchSorter([]).sort(
            list_of_tease_matches, [
                OrderedSortKey(MATCH_COUNT_SORT_KEY, is_ascending=False),
        ])
        self.assertTrue(is_equal_list_of_tease_matches(sorted_list, [
            TeaseMatch(1, fake_teases.TEASE_ID_1000_AUTHOR_ID_4567, [*list_of_two_field_matches_with_five_indices]),
            TeaseMatch(2, fake_teases.TEASE_ID_2000_AUTHOR_ID_6431, [*list_of_one_field_match_with_four_indices]),
            TeaseMatch(3, fake_teases.TEASE_ID_8721_AUTHOR_ID_7213, [*list_of_three_field_matches_with_three_indices]),
            TeaseMatch(4, fake_teases.TEASE_ID_1234_AUTHOR_ID_6431, []),
            TeaseMatch(5, fake_teases.TEASE_ID_5678_AUTHOR_ID_4567, []),
        ]))

    def test_sort_by_author_id_ascending_and_tease_id_descending_returns_sorted_list(self) -> None:
        sorted_list: Sequence[TeaseMatch] = TeaseMatchSorter([]).sort(
            _DEFAULT_LIST_OF_TEASE_MATCHES, [
                OrderedSortKey(AUTHOR_ID_SORT_KEY, is_ascending=True),
                OrderedSortKey(TEASE_ID_SORT_KEY, is_ascending=False),
        ])
        self.assertTrue(is_equal_list_of_tease_matches(sorted_list, [
            TeaseMatch(1, fake_teases.TEASE_ID_5678_AUTHOR_ID_4567, []),
            TeaseMatch(2, fake_teases.TEASE_ID_1000_AUTHOR_ID_4567, []),
            TeaseMatch(3, fake_teases.TEASE_ID_2000_AUTHOR_ID_6431, []),
            TeaseMatch(4, fake_teases.TEASE_ID_1234_AUTHOR_ID_6431, []),
            TeaseMatch(5, fake_teases.TEASE_ID_8721_AUTHOR_ID_7213, []),
        ]))

    def test_sort_by_author_id_ascending_and_tease_id_ascending_returns_sorted_list(self) -> None:
        sorted_list: Sequence[TeaseMatch] = TeaseMatchSorter([]).sort(
            _DEFAULT_LIST_OF_TEASE_MATCHES, [
                OrderedSortKey(AUTHOR_ID_SORT_KEY, is_ascending=True),
                OrderedSortKey(TEASE_ID_SORT_KEY, is_ascending=True),
            ])
        self.assertTrue(is_equal_list_of_tease_matches(sorted_list, [
            TeaseMatch(1, fake_teases.TEASE_ID_1000_AUTHOR_ID_4567, []),
            TeaseMatch(2, fake_teases.TEASE_ID_5678_AUTHOR_ID_4567, []),
            TeaseMatch(3, fake_teases.TEASE_ID_1234_AUTHOR_ID_6431, []),
            TeaseMatch(4, fake_teases.TEASE_ID_2000_AUTHOR_ID_6431, []),
            TeaseMatch(5, fake_teases.TEASE_ID_8721_AUTHOR_ID_7213, []),
        ]))

    def test_default_sort_by_author_id_ascending_and_tease_id_descending_returns_sorted_list(self) -> None:
        sorted_list: Sequence[TeaseMatch] = TeaseMatchSorter([
            OrderedSortKey(AUTHOR_ID_SORT_KEY, is_ascending=True),
            OrderedSortKey(TEASE_ID_SORT_KEY, is_ascending=False),
        ]).sort(
            _DEFAULT_LIST_OF_TEASE_MATCHES,
            [],
        )
        self.assertTrue(is_equal_list_of_tease_matches(sorted_list, [
            TeaseMatch(1, fake_teases.TEASE_ID_5678_AUTHOR_ID_4567, []),
            TeaseMatch(2, fake_teases.TEASE_ID_1000_AUTHOR_ID_4567, []),
            TeaseMatch(3, fake_teases.TEASE_ID_2000_AUTHOR_ID_6431, []),
            TeaseMatch(4, fake_teases.TEASE_ID_1234_AUTHOR_ID_6431, []),
            TeaseMatch(5, fake_teases.TEASE_ID_8721_AUTHOR_ID_7213, []),
        ]))

    def test_default_tease_id_descending_and_specified_sort_by_author_id_ascending_returns_sorted_list(self) -> None:
        sorted_list: Sequence[TeaseMatch] = TeaseMatchSorter([
            OrderedSortKey(TEASE_ID_SORT_KEY, is_ascending=False),
        ]).sort(
            _DEFAULT_LIST_OF_TEASE_MATCHES, [
                OrderedSortKey(AUTHOR_ID_SORT_KEY, is_ascending=True),
        ])
        self.assertTrue(is_equal_list_of_tease_matches(sorted_list, [
            TeaseMatch(1, fake_teases.TEASE_ID_5678_AUTHOR_ID_4567, []),
            TeaseMatch(2, fake_teases.TEASE_ID_1000_AUTHOR_ID_4567, []),
            TeaseMatch(3, fake_teases.TEASE_ID_2000_AUTHOR_ID_6431, []),
            TeaseMatch(4, fake_teases.TEASE_ID_1234_AUTHOR_ID_6431, []),
            TeaseMatch(5, fake_teases.TEASE_ID_8721_AUTHOR_ID_7213, []),
        ]))
