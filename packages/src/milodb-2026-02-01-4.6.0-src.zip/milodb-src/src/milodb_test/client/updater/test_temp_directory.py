# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import unittest
from pathlib import Path
from milodb.client.updater.i_temp_directory import TempDirectoryError
from milodb.client.updater.temp_directory import TempDirectory
from milodb_test.client.test.fake_data import FAKE_DATA_A, FAKE_DATA_B
from milodb_test.client.test.test_directory import FakeFile, TestDirectory

_FILE_PREFIX: str = 'mdbu-'

class TestPerformDeleteAction(unittest.TestCase):
    def test_directory_remains_empty_on_construction(self) -> None:
        with TestDirectory(self) as temp_dir:
            TempDirectory(temp_dir.path)

            temp_dir.assert_empty()

    def test_stored_files_are_prefixed(self) -> None:
        with TestDirectory(self) as temp_dir:
            temp_directory: TempDirectory = TempDirectory(temp_dir.path)

            temp_directory.store_file(Path('test.file'), FAKE_DATA_A)
            temp_directory.store_file(Path('something'), FAKE_DATA_B)

            temp_dir.assert_file_exists(f'{_FILE_PREFIX}test.file', FAKE_DATA_A)
            temp_dir.assert_file_exists(f'{_FILE_PREFIX}something', FAKE_DATA_B)

    def test_store_file_with_directory_raises_error(self) -> None:
        with TestDirectory(self) as temp_dir:
            temp_directory: TempDirectory = TempDirectory(temp_dir.path)

            file: Path = Path('test') / 'file'
            with self.assertRaises(TempDirectoryError) as ex:
                temp_directory.store_file(file, FAKE_DATA_A)

            self.assertEqual(f"Temporary filename '{file}' may not contain directory components", str(ex.exception))

    def test_stored_files_can_be_set_as_executable(self) -> None:
        with TestDirectory(self) as temp_dir:
            temp_directory: TempDirectory = TempDirectory(temp_dir.path)

            temp_directory.store_file(Path('test.file'), FAKE_DATA_A)
            temp_directory.store_file(Path('something'), FAKE_DATA_B, is_executable=True)

            temp_dir.assert_file_exists(f'{_FILE_PREFIX}test.file', FAKE_DATA_A)
            temp_dir.assert_file_exists(f'{_FILE_PREFIX}something', FAKE_DATA_B, is_executable=True)

    def test_destroy_will_remove_empty_directory(self) -> None:
        with TestDirectory(self) as test_dir:
            temp_path: Path = test_dir.path.joinpath('subdir')
            temp_path.mkdir()

            temp_directory: TempDirectory = TempDirectory(temp_path)
            temp_directory.destroy()

            test_dir.assert_empty()

    def test_destroy_will_remove_directory_with_stored_files(self) -> None:
        with TestDirectory(self) as test_dir:
            temp_path: Path = test_dir.path.joinpath('subdir')
            temp_path.mkdir()

            temp_directory: TempDirectory = TempDirectory(temp_path)
            temp_directory.store_file(Path('test.file'), FAKE_DATA_A)
            temp_directory.store_file(Path('something'), FAKE_DATA_B)
            temp_directory.destroy()

            test_dir.assert_empty()

    def test_destroy_will_remove_directory_with_existing_files_with_prefix(self) -> None:
        with TestDirectory(self) as test_dir:
            temp_path: Path = test_dir.path.joinpath('subdir')
            temp_path.mkdir()
            FakeFile(temp_path, f'{_FILE_PREFIX}test.file', FAKE_DATA_A)
            FakeFile(temp_path, f'{_FILE_PREFIX}something', FAKE_DATA_B)

            temp_directory: TempDirectory = TempDirectory(temp_path)
            temp_directory.destroy()

            test_dir.assert_empty()

    def test_destroy_raises_error_when_file_exists_without_prefix(self) -> None:
        with TestDirectory(self) as test_dir:
            temp_path: Path = test_dir.path.joinpath('subdir')
            temp_path.mkdir()
            file = FakeFile(temp_path, 'test.file', FAKE_DATA_A)

            temp_directory: TempDirectory = TempDirectory(temp_path)

            with self.assertRaises(TempDirectoryError) as ex:
                temp_directory.destroy()

            self.assertEqual(f"Refusing to delete temp file '{file.filepath}' because it doesn't start with '{_FILE_PREFIX}'", str(ex.exception))
