# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import unittest
from pathlib import Path
from typing import override
from unittest.mock import Mock, PropertyMock
from mockito import when # type: ignore[import-untyped]
from milodb.client.updater.i_temp_directory import ITempDirectory
from milodb.client.updater.manifest.update_sequence import IDeleteFile, IDeleteFilesAction, IEmplaceFile, IEmplaceFilesAction, IMoveFile, IMoveFilesAction, ISetFileAttribute, ISetFilesAttributeAction, IUpdateSequence
from milodb.client.updater.perform_update import PerformUpdateError, perform_delete_action, perform_emplace_action, perform_move_action, perform_set_attribute_action, perform_update
from milodb.common.output.print.i_printer import IPrinter
from milodb_test.client.test.fake_data import FAKE_DATA_A, FAKE_DATA_B, FAKE_DATA_C, FAKE_DATA_D, FAKE_DATA_E
from milodb_test.client.test.test_directory import FakeFile, FakeTempFile, TestDirectory
from milodb_test.common.test.strict_mock import InterfaceMock

class TestPerformDeleteAction(unittest.TestCase):
    @override
    def setUp(self) -> None:
        super().setUp()
        self.normal_printer = InterfaceMock(IPrinter,
            writeln = Mock(),
        )
        self.warning_printer = InterfaceMock(IPrinter)

    def test_removes_nothing_from_empty_list(self) -> None:
        with TestDirectory(self) as root_dir:
            file_1 = FakeFile(root_dir, 'mango.txt', FAKE_DATA_A)

            delete_action = InterfaceMock(IDeleteFilesAction,
                files = PropertyMock(return_value=[]),
            )

            perform_delete_action(root_dir.path, delete_action, self.normal_printer, self.warning_printer)

            root_dir.assert_contains(
                expected_list_of_files = [
                    file_1,
                ],
                expected_list_of_dirpaths = [
                ])
            root_dir.assert_file_exists(file_1, FAKE_DATA_A)

    def test_removes_single_file_from_directory(self) -> None:
        with TestDirectory(self) as root_dir:
            file_1 = FakeFile(root_dir, 'mango.txt', 821)

            delete_action = InterfaceMock(IDeleteFilesAction,
                files = PropertyMock(return_value=[
                    InterfaceMock(IDeleteFile,
                        must_exist = PropertyMock(return_value=True),
                        filename = PropertyMock(return_value=file_1.filename),
                    ),
                ]),
            )

            perform_delete_action(root_dir.path, delete_action, self.normal_printer, self.warning_printer)

            root_dir.assert_empty()

    def test_removes_readonly_file_from_directory(self) -> None:
        with TestDirectory(self) as root_dir:
            file_1 = FakeFile(root_dir, 'mango.txt', 123, is_readonly=True)

            delete_action = InterfaceMock(IDeleteFilesAction,
                files = PropertyMock(return_value=[
                    InterfaceMock(IDeleteFile,
                        must_exist = PropertyMock(return_value=True),
                        filename = PropertyMock(return_value=file_1.filename),
                    ),
                ]),
            )

            perform_delete_action(root_dir.path, delete_action, self.normal_printer, self.warning_printer)

            root_dir.assert_empty()

    def test_removes_single_file_and_leaves_existing_file_in_directory(self) -> None:
        with TestDirectory(self) as root_dir:
            file_1 = FakeFile(root_dir, 'mango.txt', 821)
            file_2 = FakeFile(root_dir, 'banana.dat', FAKE_DATA_A)

            delete_action = InterfaceMock(IDeleteFilesAction,
                files = PropertyMock(return_value=[
                    InterfaceMock(IDeleteFile,
                        must_exist = PropertyMock(return_value=True),
                        filename = PropertyMock(return_value=file_1.filename),
                    ),
                ]),
            )

            perform_delete_action(root_dir.path, delete_action, self.normal_printer, self.warning_printer)

            root_dir.assert_contains(
                expected_list_of_files = [
                    file_2,
                ],
                expected_list_of_dirpaths = [
                ])
            root_dir.assert_file_exists(file_2, FAKE_DATA_A)

    def test_removes_files_from_subdirectories_and_empty_directories(self) -> None:
        with TestDirectory(self) as root_dir:
            file_1 = FakeFile(root_dir, 'mango.txt', 821)
            file_2 = FakeFile(root_dir, Path('subdir1', 'banana.dat'), 100)
            file_3 = FakeFile(root_dir, Path('subdir2', 'subdir3', 'changes.txt'), 100)
            file_4 = FakeFile(root_dir, Path('subdir2', 'subdir3', 'details.log'), 100)

            delete_action = InterfaceMock(IDeleteFilesAction,
                files = PropertyMock(return_value=[
                    InterfaceMock(IDeleteFile,
                        must_exist = PropertyMock(return_value=True),
                        filename = PropertyMock(return_value=file_1.filename),
                    ),
                    InterfaceMock(IDeleteFile,
                        must_exist = PropertyMock(return_value=True),
                        filename = PropertyMock(return_value=file_2.filename),
                    ),
                    InterfaceMock(IDeleteFile,
                        must_exist = PropertyMock(return_value=True),
                        filename = PropertyMock(return_value=file_3.filename),
                    ),
                    InterfaceMock(IDeleteFile,
                        must_exist = PropertyMock(return_value=True),
                        filename = PropertyMock(return_value=file_4.filename),
                    ),
                ]),
            )

            perform_delete_action(root_dir.path, delete_action, self.normal_printer, self.warning_printer)

            root_dir.assert_empty()

    def test_removes_files_from_subdirectories_and_leaves_populated_directories(self) -> None:
        with TestDirectory(self) as root_dir:
            file_1 = FakeFile(root_dir, 'mango.txt', 821)
            file_2 = FakeFile(root_dir, Path('subdir1', 'banana.dat'), 100)
            file_3 = FakeFile(root_dir, Path('subdir2', 'subdir3', 'changes.txt'), 100)
            file_4 = FakeFile(root_dir, Path('subdir2', 'subdir3', 'details.log'), 100)
            file_5 = FakeFile(root_dir, Path('subdir2', 'sticky.pud'), 100)

            delete_action = InterfaceMock(IDeleteFilesAction,
                files = PropertyMock(return_value=[
                    InterfaceMock(IDeleteFile,
                        must_exist = PropertyMock(return_value=True),
                        filename = PropertyMock(return_value=file_1.filename),
                    ),
                    InterfaceMock(IDeleteFile,
                        must_exist = PropertyMock(return_value=True),
                        filename = PropertyMock(return_value=file_2.filename),
                    ),
                    InterfaceMock(IDeleteFile,
                        must_exist = PropertyMock(return_value=True),
                        filename = PropertyMock(return_value=file_3.filename),
                    ),
                    InterfaceMock(IDeleteFile,
                        must_exist = PropertyMock(return_value=True),
                        filename = PropertyMock(return_value=file_4.filename),
                    ),
                ]),
            )

            perform_delete_action(root_dir.path, delete_action, self.normal_printer, self.warning_printer)

            root_dir.assert_contains(
                expected_list_of_files = [
                    file_5,
                ],
                expected_list_of_dirpaths = [
                    file_5.parent,
                ])

    def test_raises_error_when_deleting_missing_mandatory_file(self) -> None:
        with TestDirectory(self) as root_dir:
            delete_action = InterfaceMock(IDeleteFilesAction,
                files = PropertyMock(return_value=[
                    InterfaceMock(IDeleteFile,
                        must_exist = PropertyMock(return_value=True),
                        filename = PropertyMock(return_value=Path('does-not-exist.dat')),
                    ),
                ]),
            )

            with self.assertRaises(PerformUpdateError) as ex:
                perform_delete_action(root_dir.path, delete_action, self.normal_printer, self.warning_printer)
            self.assertTrue(str(ex.exception).startswith(f"Failed to remove file '{root_dir.path_of('does-not-exist.dat')}': "))

            root_dir.assert_empty()

    def test_ignores_missing_optional_file_when_removing_single_file_from_directory(self) -> None:
        with TestDirectory(self) as root_dir:
            delete_action = InterfaceMock(IDeleteFilesAction,
                files = PropertyMock(return_value=[
                    InterfaceMock(IDeleteFile,
                        must_exist = PropertyMock(return_value=False),
                        filename = PropertyMock(return_value=Path('does-not-exist.dat')),
                    ),
                ]),
            )

            perform_delete_action(root_dir.path, delete_action, self.normal_printer, self.warning_printer)

            root_dir.assert_empty()

    def test_ignores_missing_optional_file_when_removing_multiple_files_from_directory(self) -> None:
        with TestDirectory(self) as root_dir:
            file_1 = FakeFile(root_dir, 'mango.txt', 821)
            file_2 = FakeFile(root_dir, 'banana.dat', FAKE_DATA_A)

            delete_action = InterfaceMock(IDeleteFilesAction,
                files = PropertyMock(return_value=[
                    InterfaceMock(IDeleteFile,
                        must_exist = PropertyMock(return_value=True),
                        filename = PropertyMock(return_value=file_1.filename),
                    ),
                    InterfaceMock(IDeleteFile,
                        must_exist = PropertyMock(return_value=False),
                        filename = PropertyMock(return_value=Path('does-not-exist.dat')),
                    ),
                    InterfaceMock(IDeleteFile,
                        must_exist = PropertyMock(return_value=False),
                        filename = PropertyMock(return_value=file_2.filename),
                    ),
                ]),
            )

            perform_delete_action(root_dir.path, delete_action, self.normal_printer, self.warning_printer)

            root_dir.assert_empty()

    def test_ignores_missing_directories_when_deleting_optional_missing_file(self) -> None:
        with TestDirectory(self) as root_dir:
            delete_action = InterfaceMock(IDeleteFilesAction,
                files = PropertyMock(return_value=[
                    InterfaceMock(IDeleteFile,
                        must_exist = PropertyMock(return_value=False),
                        filename = PropertyMock(return_value=Path('subdir1', 'subdir2', 'does-not-exist.dat')),
                    ),
                ]),
            )

            perform_delete_action(root_dir.path, delete_action, self.normal_printer, self.warning_printer)

            root_dir.assert_empty()

class TestPerformEmplaceAction(unittest.TestCase):
    @override
    def setUp(self) -> None:
        self.printer = InterfaceMock(IPrinter,
            writeln = Mock(),
        )

    def test_empty_list_of_files_does_nothing(self) -> None:
        emplace_action = InterfaceMock(IEmplaceFilesAction,
            files = PropertyMock(return_value=[]),
        )
        temp_directory = InterfaceMock(ITempDirectory)

        with TestDirectory(self, 'root') as root_dir:
            perform_emplace_action(root_dir.path, temp_directory, emplace_action, self.printer)

            root_dir.assert_empty()

    def test_files_without_subdirectories_are_emplaced(self) -> None:
        file_1_target_filename: Path = Path('mango.txt')
        file_1_source_filename: Path = Path('abcd')
        file_2_target_filename: Path = Path('something.dat')
        file_2_source_filename: Path = Path('1234')

        emplace_action = InterfaceMock(IEmplaceFilesAction,
            files = PropertyMock(return_value=[
                InterfaceMock(IEmplaceFile,
                    target_filename = PropertyMock(return_value=file_1_target_filename),
                    source_filename = PropertyMock(return_value=file_1_source_filename),
                ),
                InterfaceMock(IEmplaceFile,
                    target_filename = PropertyMock(return_value=file_2_target_filename),
                    source_filename = PropertyMock(return_value=file_2_source_filename),
                ),
            ]),
        )

        with TestDirectory(self, 'temp') as temp_dir:
            file_1_source = FakeFile(temp_dir, file_1_source_filename, FAKE_DATA_A)
            file_2_source = FakeFile(temp_dir, file_2_source_filename, FAKE_DATA_B)
            temp_directory = InterfaceMock(ITempDirectory,
                path_of = Mock(),
            )
            when(temp_directory).path_of(file_1_source_filename).thenReturn(file_1_source.filepath)
            when(temp_directory).path_of(file_2_source_filename).thenReturn(file_2_source.filepath)

            with TestDirectory(self, 'root') as root_dir:
                perform_emplace_action(root_dir.path, temp_directory, emplace_action, self.printer)

                root_dir.assert_contains(
                    expected_list_of_files = [
                        file_1_target_filename,
                        file_2_target_filename,
                    ],
                    expected_list_of_dirpaths = [
                    ])
                root_dir.assert_file_exists(file_1_target_filename, FAKE_DATA_A)
                root_dir.assert_file_exists(file_2_target_filename, FAKE_DATA_B)

    def test_files_with_subdirectories_are_emplaced(self) -> None:
        file_1_target_filename: Path = Path('fruit/apple/mango.txt')
        file_1_source_filename: Path = Path('source/abxd')
        file_2_target_filename: Path = Path('fruit/banana/something.dat')
        file_2_source_filename: Path = Path('source/1234')
        file_3_target_filename: Path = Path('pear/changes.txt')
        file_3_source_filename: Path = Path('source/abe4')

        emplace_action = InterfaceMock(IEmplaceFilesAction,
            files = PropertyMock(return_value=[
                InterfaceMock(IEmplaceFile,
                    target_filename = PropertyMock(return_value=file_1_target_filename),
                    source_filename = PropertyMock(return_value=file_1_source_filename),
                ),
                InterfaceMock(IEmplaceFile,
                    target_filename = PropertyMock(return_value=file_2_target_filename),
                    source_filename = PropertyMock(return_value=file_2_source_filename),
                ),
                InterfaceMock(IEmplaceFile,
                    target_filename = PropertyMock(return_value=file_3_target_filename),
                    source_filename = PropertyMock(return_value=file_3_source_filename),
                ),
            ]),
        )

        with TestDirectory(self, 'temp') as temp_dir:
            file_1_source = FakeFile(temp_dir, file_1_source_filename, FAKE_DATA_A)
            file_2_source = FakeFile(temp_dir, file_2_source_filename, FAKE_DATA_B)
            file_3_source = FakeFile(temp_dir, file_3_source_filename, FAKE_DATA_C)
            temp_directory = InterfaceMock(ITempDirectory,
                path_of = Mock(),
            )
            when(temp_directory).path_of(file_1_source_filename).thenReturn(file_1_source.filepath)
            when(temp_directory).path_of(file_2_source_filename).thenReturn(file_2_source.filepath)
            when(temp_directory).path_of(file_3_source_filename).thenReturn(file_3_source.filepath)

            with TestDirectory(self, 'root') as root_dir:
                perform_emplace_action(root_dir.path, temp_directory, emplace_action, self.printer)

                root_dir.assert_contains(
                    expected_list_of_files = [
                        file_1_target_filename,
                        file_2_target_filename,
                        file_3_target_filename,
                    ],
                    expected_list_of_dirpaths = [
                        Path(file_1_target_filename).parent.parent,
                        Path(file_1_target_filename).parent,
                        Path(file_2_target_filename).parent,
                        Path(file_3_target_filename).parent,
                    ])
                root_dir.assert_file_exists(file_1_target_filename, FAKE_DATA_A)
                root_dir.assert_file_exists(file_2_target_filename, FAKE_DATA_B)
                root_dir.assert_file_exists(file_3_target_filename, FAKE_DATA_C)

    def test_raises_error_when_source_file_doesnt_exist(self) -> None:
        file_1_target_filename: Path = Path('mango.txt')
        file_1_source_filename: Path = Path('missing')

        emplace_action = InterfaceMock(IEmplaceFilesAction,
            files = PropertyMock(return_value=[
                InterfaceMock(IEmplaceFile,
                    target_filename = PropertyMock(return_value=file_1_target_filename),
                    source_filename = PropertyMock(return_value=file_1_source_filename),
                ),
            ]),
        )

        with TestDirectory(self, 'temp') as temp_dir:
            temp_directory = InterfaceMock(ITempDirectory,
                path_of = Mock(),
            )
            when(temp_directory).path_of(file_1_source_filename).thenReturn(temp_dir.path_of(file_1_source_filename))

            with TestDirectory(self, 'root') as root_dir:
                with self.assertRaises(PerformUpdateError) as ex:
                    perform_emplace_action(root_dir.path, temp_directory, emplace_action, self.printer)

                self.assertTrue(str(ex.exception).startswith(f"Asset '{temp_dir.path_of(file_1_source_filename)}' for file '{root_dir.path_of(file_1_target_filename)}' is unavailable: "))

    def test_raises_error_when_file_cannot_be_written(self) -> None:
        file_1_target_filename: Path = Path('mango.txt')
        file_1_source_filename: Path = Path('work') / 'mango.txt'

        emplace_action = InterfaceMock(IEmplaceFilesAction,
            files = PropertyMock(return_value=[
                InterfaceMock(IEmplaceFile,
                    target_filename = PropertyMock(return_value=file_1_target_filename),
                    source_filename = PropertyMock(return_value=file_1_source_filename),
                ),
            ]),
        )

        with TestDirectory(self, 'temp') as temp_dir:
            file_1_source = FakeFile(temp_dir, file_1_source_filename, FAKE_DATA_A)
            temp_directory = InterfaceMock(ITempDirectory,
                path_of = Mock(),
            )
            when(temp_directory).path_of(file_1_source_filename).thenReturn(file_1_source.filepath)

            with TestDirectory(self, 'root') as root_dir:
                root_dir.path_of(file_1_target_filename).mkdir()

                with self.assertRaises(PerformUpdateError) as ex:
                    perform_emplace_action(root_dir.path, temp_directory, emplace_action, self.printer)
                self.assertTrue(str(ex.exception).startswith(f"Failed to write file '{root_dir.path_of(file_1_target_filename)}': "))

class TestPerformMoveAction(unittest.TestCase):
    @override
    def setUp(self) -> None:
        super().setUp()
        self.printer = InterfaceMock(IPrinter,
            writeln = Mock(),
        )

    def test_empty_list_of_renames_does_nothing(self) -> None:
        move_action = InterfaceMock(IMoveFilesAction,
            files = PropertyMock(return_value=[]),
        )

        with TestDirectory(self) as root_dir:
            perform_move_action(root_dir.path, move_action, self.printer)
            root_dir.assert_empty()

    def test_list_of_files_to_rename(self) -> None:
        with TestDirectory(self) as root_dir:
            file_1 = FakeFile(root_dir, 'file1.txt', FAKE_DATA_A)
            file_2 = FakeFile(root_dir, 'something.org', FAKE_DATA_B)

            move_action = InterfaceMock(IMoveFilesAction,
                files = PropertyMock(return_value=[
                    InterfaceMock(IMoveFile,
                        must_exist = PropertyMock(return_value=True),
                        original_filename = PropertyMock(return_value=file_1.filename),
                        new_filename = PropertyMock(return_value='newFilename.dat'),
                    ),
                    InterfaceMock(IMoveFile,
                        must_exist = PropertyMock(return_value=True),
                        original_filename = PropertyMock(return_value=file_2.filename),
                        new_filename = PropertyMock(return_value='config.json'),
                    ),
                ]),
            )

            perform_move_action(root_dir.path, move_action, self.printer)

            root_dir.assert_contains(
                expected_list_of_files = [
                    'newFilename.dat',
                    'config.json',
                    ],
                expected_list_of_dirpaths = [
                ])
            root_dir.assert_file_exists('newFilename.dat', FAKE_DATA_A)
            root_dir.assert_file_exists('config.json', FAKE_DATA_B)

    def test_raises_error_if_mandatory_file_cannot_be_renamed(self) -> None:
        move_action = InterfaceMock(IMoveFilesAction,
            files = PropertyMock(return_value=[
                InterfaceMock(IMoveFile,
                    must_exist = PropertyMock(return_value=True),
                    original_filename = PropertyMock(return_value='missing.log'),
                    new_filename = PropertyMock(return_value='newFilename.dat'),
                ),
            ]),
        )

        with TestDirectory(self) as root_dir:
            with self.assertRaises(PerformUpdateError) as ex:
                perform_move_action(root_dir.path, move_action, self.printer)
            self.assertTrue(str(ex.exception).startswith(f"Failed to rename file '{root_dir.path_of('missing.log')}' to '{root_dir.path_of('newFilename.dat')}': "))

    def test_ignores_optional_missing_file_cannot_be_renamed(self) -> None:
        move_action = InterfaceMock(IMoveFilesAction,
            files = PropertyMock(return_value=[
                InterfaceMock(IMoveFile,
                    must_exist = PropertyMock(return_value=False),
                    original_filename = PropertyMock(return_value='missing.log'),
                    new_filename = PropertyMock(return_value='newFilename.dat'),
                ),
            ]),
        )

        with TestDirectory(self) as root_dir:
            perform_move_action(root_dir.path, move_action, self.printer)
            root_dir.assert_empty()

class TestPerformSetAttributeAction(unittest.TestCase):
    @override
    def setUp(self) -> None:
        super().setUp()
        self.printer = InterfaceMock(IPrinter,
            writeln = Mock(),
        )

    def test_file_attributes_are_set(self) -> None:
        with TestDirectory(self) as root_dir:
            file_1 = FakeFile(root_dir, 'file1.txt', FAKE_DATA_A)
            file_2 = FakeFile(root_dir, 'mango.log', FAKE_DATA_B)
            file_3 = FakeFile(root_dir, 'config.dat', FAKE_DATA_C)
            file_4 = FakeFile(root_dir, 'apple.cue', FAKE_DATA_D)

            set_attributes_action = InterfaceMock(ISetFilesAttributeAction,
                files = PropertyMock(return_value=[
                    InterfaceMock(ISetFileAttribute,
                        filename = PropertyMock(return_value=file_1.filename),
                        is_readonly = PropertyMock(return_value=False),
                        is_executable = PropertyMock(return_value=False),
                    ),
                    InterfaceMock(ISetFileAttribute,
                        filename = PropertyMock(return_value=file_2.filename),
                        is_readonly = PropertyMock(return_value=True),
                        is_executable = PropertyMock(return_value=False),
                    ),
                    InterfaceMock(ISetFileAttribute,
                        filename = PropertyMock(return_value=file_3.filename),
                        is_readonly = PropertyMock(return_value=False),
                        is_executable = PropertyMock(return_value=True),
                    ),
                    InterfaceMock(ISetFileAttribute,
                        filename = PropertyMock(return_value=file_4.filename),
                        is_readonly = PropertyMock(return_value=True),
                        is_executable = PropertyMock(return_value=True),
                    ),
                ]),
            )

            perform_set_attribute_action(root_dir.path, set_attributes_action, self.printer)

            root_dir.assert_contains(
                expected_list_of_files = [
                    file_1,
                    file_2,
                    file_3,
                    file_4,
                ],
                expected_list_of_dirpaths = [
                ])
            root_dir.assert_file_exists(file_1, FAKE_DATA_A)
            root_dir.assert_file_exists(file_2, FAKE_DATA_B, is_readonly=True)
            root_dir.assert_file_exists(file_3, FAKE_DATA_C, is_executable=True)
            root_dir.assert_file_exists(file_4, FAKE_DATA_D, is_readonly=True, is_executable=True)

    def test_raises_error_if_attribute_cannot_be_set(self) -> None:
        with TestDirectory(self) as root_dir:
            set_attributes_action = InterfaceMock(ISetFilesAttributeAction,
                files = PropertyMock(return_value=[
                    InterfaceMock(ISetFileAttribute,
                        filename = PropertyMock(return_value='missing.txt'),
                        is_readonly = PropertyMock(return_value=False),
                        is_executable = PropertyMock(return_value=True),
                    ),
                ]),
            )

            with self.assertRaises(PerformUpdateError) as ex:
                perform_set_attribute_action(root_dir.path, set_attributes_action, self.printer)
            self.assertTrue(str(ex.exception).startswith(f"Failed to set attributes of file '{root_dir.path_of('missing.txt')}': "))

class TestPerformUpdate(unittest.TestCase):
    def test_performs_actions_in_key_order(self) -> None:
        """Test a sequence of actions are performed according to their key order.

                      1                 2                 3                 4                 5                 6                 7
        --------------------------------------------------------------------------------------------------------------------------------------------
                DEL file1.txt     MOV mango.log     ATR config.dat    MOV config.dat    EMP config.dat    MOV apple.cue     ATR orange.exe
                                    -> file1.txt      -> +exe           -> mango.log      -> (E)            -> orange.exe     -> +exe
        --------------------------------------------------------------------------------------------------------------------------------------------
        file1.txt(A)                        file1.txt(B)      file1.txt(B)      file1.txt(B)      file1.txt(B)      file1.txt(B)      file1.txt(B)
        mango.log(B)      mango.log(B)                                          mango.log(C)x     mango.log(C)x     mango.log(C)x     mango.log(C)x
        config.dat(C)     config.dat(C)     config.dat(C)     config.dat(C)x                      config.dat(E)     config.dat(E)     config.dat(E)
        apple.cue(D)      apple.cue(D)      apple.cue(D)      apple.cue(D)      apple.cue(D)      apple.cue(D)      orange.exe(D)     orange.exe(D)x
        """
        with TestDirectory(self, 'temp') as temp_dir:
            file_new = FakeTempFile(temp_dir, '87f4g0gA', FAKE_DATA_E)

            with TestDirectory(self, 'root') as root_dir:
                file_1 = FakeFile(root_dir, 'file1.txt', FAKE_DATA_A)
                file_2 = FakeFile(root_dir, 'mango.log', FAKE_DATA_B)
                file_3 = FakeFile(root_dir, 'config.dat', FAKE_DATA_C)
                file_4 = FakeFile(root_dir, 'apple.cue', FAKE_DATA_D)

                update_sequence = InterfaceMock(IUpdateSequence,
                    root_directory = PropertyMock(return_value=root_dir.path),
                    temp_directory = PropertyMock(return_value=temp_dir.path),
                    move_files_actions = PropertyMock(return_value={
                        2: InterfaceMock(IMoveFilesAction,
                            files = PropertyMock(return_value=[
                                InterfaceMock(IMoveFile,
                                    original_filename = PropertyMock(return_value=file_2.filename),
                                    new_filename = PropertyMock(return_value=file_1.filename),
                                ),
                            ]),
                        ),
                        4: InterfaceMock(IMoveFilesAction,
                            files = PropertyMock(return_value=[
                                InterfaceMock(IMoveFile,
                                    original_filename = PropertyMock(return_value=file_3.filename),
                                    new_filename = PropertyMock(return_value=file_2.filename),
                                ),
                            ]),
                        ),
                        6: InterfaceMock(IMoveFilesAction,
                            files = PropertyMock(return_value=[
                                InterfaceMock(IMoveFile,
                                    original_filename = PropertyMock(return_value=file_4.filename),
                                    new_filename = PropertyMock(return_value=Path('orange.exe')),
                                ),
                            ]),
                        ),
                    }),
                    emplace_files_actions = PropertyMock(return_value={
                        5: InterfaceMock(IEmplaceFilesAction,
                            files = PropertyMock(return_value=[
                                InterfaceMock(IEmplaceFile,
                                    target_filename = PropertyMock(return_value=file_3.filename),
                                    source_filename = PropertyMock(return_value=file_new.filename),
                                ),
                            ]),
                        ),
                    }),
                    delete_files_actions = PropertyMock(return_value={
                        1: InterfaceMock(IDeleteFilesAction,
                            files = PropertyMock(return_value=[
                                InterfaceMock(IDeleteFile,
                                    filename = PropertyMock(return_value=file_1.filename),
                                ),
                            ]),
                        ),
                    }),
                    set_files_attribute_actions = PropertyMock(return_value={
                        3: InterfaceMock(ISetFilesAttributeAction,
                            files = PropertyMock(return_value=[
                                InterfaceMock(ISetFileAttribute,
                                    filename = PropertyMock(return_value=file_3.filename),
                                    is_readonly = PropertyMock(return_value=False),
                                    is_executable = PropertyMock(return_value=True),
                                ),
                            ]),
                        ),
                        7: InterfaceMock(ISetFilesAttributeAction,
                            files = PropertyMock(return_value=[
                                InterfaceMock(ISetFileAttribute,
                                    filename = PropertyMock(return_value=Path('orange.exe')),
                                    is_readonly = PropertyMock(return_value=False),
                                    is_executable = PropertyMock(return_value=True),
                                ),
                            ]),
                        ),
                    }),
                )

                normal_printer = InterfaceMock(IPrinter,
                    writeln = Mock(),
                )
                warning_printer = InterfaceMock(IPrinter)

                perform_update(update_sequence, normal_printer, warning_printer)

                root_dir.assert_contains(
                    expected_list_of_files = [
                        file_1,
                        file_2,
                        file_3,
                        'orange.exe',
                    ],
                    expected_list_of_dirpaths = [
                    ])
                root_dir.assert_file_exists(file_1, FAKE_DATA_B)
                root_dir.assert_file_exists(file_2, FAKE_DATA_C, is_executable=True)
                root_dir.assert_file_exists(file_3, FAKE_DATA_E)
                root_dir.assert_file_exists('orange.exe', FAKE_DATA_D, is_executable=True)
