# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import operator
import unittest
from collections.abc import Callable
from dataclasses import dataclass
from typing import override
from milodb.client.updater.manifest.common_manifest import IVersionNumber, PreReleaseLabel
from milodb.client.updater.manifest.version_number import PreRelease, VersionNumber, VersionNumberError

class TestVersionNumberParsesCorrectly(unittest.TestCase):
    def test_major_number_parses_correctly(self) -> None:
        version_number = VersionNumber.parse('0.2.3')
        self.assertEqual(0, version_number.major)

        version_number = VersionNumber.parse('1.2.3')
        self.assertEqual(1, version_number.major)

        version_number = VersionNumber.parse('87.2.3')
        self.assertEqual(87, version_number.major)

    def test_minor_number_parses_correctly(self) -> None:
        version_number = VersionNumber.parse('1.0.3')
        self.assertEqual(0, version_number.minor)

        version_number = VersionNumber.parse('1.2.3')
        self.assertEqual(2, version_number.minor)

        version_number = VersionNumber.parse('1.64.3')
        self.assertEqual(64, version_number.minor)

    def test_patch_number_parses_correctly(self) -> None:
        version_number = VersionNumber.parse('1.2.0')
        self.assertEqual(0, version_number.patch)

        version_number = VersionNumber.parse('1.2.3')
        self.assertEqual(3, version_number.patch)

        version_number = VersionNumber.parse('1.2.50')
        self.assertEqual(50, version_number.patch)

    def test_pre_release_label_parses_correctly(self) -> None:
        version_number = VersionNumber.parse('1.2.3-alpha.1')
        if not version_number.pre_release:
            self.fail('version_number.pre_release is None')
        self.assertEqual(PreReleaseLabel.ALPHA, version_number.pre_release.label)
        self.assertEqual(1, version_number.pre_release.number)

        version_number = VersionNumber.parse('1.2.3-beta.508')
        if not version_number.pre_release:
            self.fail('version_number.pre_release is None')
        self.assertEqual(PreReleaseLabel.BETA, version_number.pre_release.label)
        self.assertEqual(508, version_number.pre_release.number)

        version_number = VersionNumber.parse('1.2.3-rc.60')
        if not version_number.pre_release:
            self.fail('version_number.pre_release is None')
        self.assertEqual(PreReleaseLabel.RELEASE_CANDIDATE, version_number.pre_release.label)
        self.assertEqual(60, version_number.pre_release.number)

class TestVersionNumberParseRaisesErrors(unittest.TestCase):
    def _assert_error(self, text: str, error: VersionNumberError) -> None:
        self.assertEqual(f"'{text}' is not a Semantic Version number", str(error))

    def test_invalid_major_number_raises_error(self) -> None:
        text = 'a.2.3'
        with self.assertRaises(VersionNumberError) as ex:
            VersionNumber.parse(text)
        self._assert_error(text, ex.exception)

        text = '01.2.3'
        with self.assertRaises(VersionNumberError) as ex:
            VersionNumber.parse(text)
        self._assert_error(text, ex.exception)

        text = '-1.2.3'
        with self.assertRaises(VersionNumberError) as ex:
            VersionNumber.parse(text)
        self._assert_error(text, ex.exception)

    def test_invalid_minor_number_raises_error(self) -> None:
        text = '1.a.3'
        with self.assertRaises(VersionNumberError) as ex:
            VersionNumber.parse(text)
        self._assert_error(text, ex.exception)

        text = '1.02.3'
        with self.assertRaises(VersionNumberError) as ex:
            VersionNumber.parse(text)
        self._assert_error(text, ex.exception)

        text = '1.-2.3'
        with self.assertRaises(VersionNumberError) as ex:
            VersionNumber.parse(text)
        self._assert_error(text, ex.exception)

    def test_invalid_patch_number_raises_error(self) -> None:
        text = '1.2.a'
        with self.assertRaises(VersionNumberError) as ex:
            VersionNumber.parse(text)
        self._assert_error(text, ex.exception)

        text = '1.2.03'
        with self.assertRaises(VersionNumberError) as ex:
            VersionNumber.parse(text)
        self._assert_error(text, ex.exception)

        text = '1.2.-3'
        with self.assertRaises(VersionNumberError) as ex:
            VersionNumber.parse(text)
        self._assert_error(text, ex.exception)

    def test_invalid_pre_release_label_raises_error(self) -> None:
        text = '1.2.3-4.1'
        with self.assertRaises(VersionNumberError) as ex:
            VersionNumber.parse(text)
        self._assert_error(text, ex.exception)

        text = '1.2.3-mango.1'
        with self.assertRaises(VersionNumberError) as ex:
            VersionNumber.parse(text)
        self._assert_error(text, ex.exception)

        text = '1.2.3-ALPHA.1'
        with self.assertRaises(VersionNumberError) as ex:
            VersionNumber.parse(text)
        self._assert_error(text, ex.exception)

    def test_invalid_pre_release_number_raises_error(self) -> None:
        text = '1.2.3-alpha.0'
        with self.assertRaises(VersionNumberError) as ex:
            VersionNumber.parse(text)
        self._assert_error(text, ex.exception)

        text = '1.2.3-alpha.a'
        with self.assertRaises(VersionNumberError) as ex:
            VersionNumber.parse(text)
        self._assert_error(text, ex.exception)

        text = '1.2.3-alpha.01'
        with self.assertRaises(VersionNumberError) as ex:
            VersionNumber.parse(text)
        self._assert_error(text, ex.exception)

        text = '1.2.3-alpha.-1'
        with self.assertRaises(VersionNumberError) as ex:
            VersionNumber.parse(text)
        self._assert_error(text, ex.exception)

@dataclass
class _Comparison:
    left: IVersionNumber
    the_operator: Callable[[IVersionNumber, IVersionNumber], bool]
    right: IVersionNumber
    expected_result: bool
    converse_operator: Callable[[IVersionNumber, IVersionNumber], bool]

    @override
    def __str__(self) -> str:
        return f'({self.left} {self._operator_text(self.the_operator)} {self.right}) is {self.expected_result} and ({self.left} {self._operator_text(self.converse_operator)} {self.right}) is {not self.expected_result}'

    @staticmethod
    def _operator_text(the_operator: Callable[[IVersionNumber, IVersionNumber], bool]) -> str:
        operator_text: str = '?'
        if the_operator is operator.lt:
            operator_text = '<'
        elif the_operator is operator.le:
            operator_text = '<='
        elif the_operator is operator.eq:
            operator_text = '=='
        elif the_operator is operator.ne:
            operator_text = '!='
        elif the_operator is operator.gt:
            operator_text = '>'
        elif the_operator is operator.ge:
            operator_text = '>='
        return operator_text

class TestVersionNumberCompare(unittest.TestCase):
    def _run_comparisons(self, list_of_comparisons: tuple[_Comparison, ...]) -> None:
        comparison: _Comparison
        for comparison in list_of_comparisons:
            with self.subTest(comparison=str(comparison)):
                if comparison.expected_result:
                    self.assertTrue(comparison.the_operator(comparison.left, comparison.right), str(comparison))
                    self.assertFalse(comparison.converse_operator(comparison.left, comparison.right), str(comparison))
                else:
                    self.assertFalse(comparison.the_operator(comparison.left, comparison.right), str(comparison))
                    self.assertTrue(comparison.converse_operator(comparison.left, comparison.right), str(comparison))

    def test_standard_versions_compare_equality(self) -> None:
        self._run_comparisons((
            _Comparison(VersionNumber(5, 5, 5), operator.eq, VersionNumber(5, 5, 5), expected_result=True, converse_operator=operator.ne),
            _Comparison(VersionNumber(5, 5, 6), operator.eq, VersionNumber(5, 5, 6), expected_result=True, converse_operator=operator.ne),
            _Comparison(VersionNumber(5, 6, 5), operator.eq, VersionNumber(5, 6, 5), expected_result=True, converse_operator=operator.ne),
            _Comparison(VersionNumber(6, 5, 5), operator.eq, VersionNumber(6, 5, 5), expected_result=True, converse_operator=operator.ne),
            _Comparison(VersionNumber(5, 5, 5), operator.eq, VersionNumber(5, 5, 6), expected_result=False, converse_operator=operator.ne),
            _Comparison(VersionNumber(5, 5, 5), operator.eq, VersionNumber(5, 6, 5), expected_result=False, converse_operator=operator.ne),
            _Comparison(VersionNumber(5, 5, 5), operator.eq, VersionNumber(6, 5, 5), expected_result=False, converse_operator=operator.ne),
        ))

    def test_standard_versions_compare_less_than(self) -> None:
        self._run_comparisons((
            _Comparison(VersionNumber(5, 5, 5), operator.lt, VersionNumber(5, 5, 6), expected_result=True, converse_operator=operator.ge),
            _Comparison(VersionNumber(5, 5, 5), operator.lt, VersionNumber(5, 6, 5), expected_result=True, converse_operator=operator.ge),
            _Comparison(VersionNumber(5, 5, 5), operator.lt, VersionNumber(6, 5, 5), expected_result=True, converse_operator=operator.ge),
            _Comparison(VersionNumber(5, 5, 6), operator.lt, VersionNumber(5, 5, 5), expected_result=False, converse_operator=operator.ge),
            _Comparison(VersionNumber(5, 6, 5), operator.lt, VersionNumber(5, 5, 5), expected_result=False, converse_operator=operator.ge),
            _Comparison(VersionNumber(6, 5, 5), operator.lt, VersionNumber(5, 5, 5), expected_result=False, converse_operator=operator.ge),
       ))

    def test_standard_versions_compare_greater_than(self) -> None:
        self._run_comparisons((
            _Comparison(VersionNumber(5, 5, 5), operator.gt, VersionNumber(5, 5, 6), expected_result=False, converse_operator=operator.le),
            _Comparison(VersionNumber(5, 5, 5), operator.gt, VersionNumber(5, 6, 5), expected_result=False, converse_operator=operator.le),
            _Comparison(VersionNumber(5, 5, 5), operator.gt, VersionNumber(6, 5, 5), expected_result=False, converse_operator=operator.le),
            _Comparison(VersionNumber(5, 5, 6), operator.gt, VersionNumber(5, 5, 5), expected_result=True, converse_operator=operator.le),
            _Comparison(VersionNumber(5, 6, 5), operator.gt, VersionNumber(5, 5, 5), expected_result=True, converse_operator=operator.le),
            _Comparison(VersionNumber(6, 5, 5), operator.gt, VersionNumber(5, 5, 5), expected_result=True, converse_operator=operator.le),
        ))

    def test_pre_release_versions_compare_for_equality_with_standard_versions(self) -> None:
        self._run_comparisons((
            _Comparison(VersionNumber(5, 5, 5), operator.eq, VersionNumber(5, 5, 5, PreRelease(PreReleaseLabel.ALPHA, 3)), expected_result=False, converse_operator=operator.ne),
            _Comparison(VersionNumber(5, 5, 6), operator.eq, VersionNumber(5, 5, 6, PreRelease(PreReleaseLabel.BETA, 4)), expected_result=False, converse_operator=operator.ne),
            _Comparison(VersionNumber(5, 6, 5), operator.eq, VersionNumber(5, 6, 5, PreRelease(PreReleaseLabel.RELEASE_CANDIDATE, 5)), expected_result=False, converse_operator=operator.ne),
            _Comparison(VersionNumber(5, 5, 5, PreRelease(PreReleaseLabel.ALPHA, 4)), operator.eq, VersionNumber(5, 5, 5), expected_result=False, converse_operator=operator.ne),
            _Comparison(VersionNumber(5, 5, 6, PreRelease(PreReleaseLabel.BETA, 3)), operator.eq, VersionNumber(5, 5, 6), expected_result=False, converse_operator=operator.ne),
            _Comparison(VersionNumber(5, 6, 5, PreRelease(PreReleaseLabel.RELEASE_CANDIDATE, 2)), operator.eq, VersionNumber(5, 6, 5), expected_result=False, converse_operator=operator.ne),
        ))

    def test_pre_release_versions_compare_less_than_standard_versions(self) -> None:
        self._run_comparisons((
            _Comparison(VersionNumber(5, 5, 5), operator.lt, VersionNumber(5, 5, 5, PreRelease(PreReleaseLabel.ALPHA, 3)), expected_result=False, converse_operator=operator.ge),
            _Comparison(VersionNumber(5, 5, 6), operator.lt, VersionNumber(5, 5, 6, PreRelease(PreReleaseLabel.BETA, 4)), expected_result=False, converse_operator=operator.ge),
            _Comparison(VersionNumber(5, 6, 5), operator.lt, VersionNumber(5, 6, 5, PreRelease(PreReleaseLabel.RELEASE_CANDIDATE, 5)), expected_result=False, converse_operator=operator.ge),
            _Comparison(VersionNumber(5, 5, 5, PreRelease(PreReleaseLabel.ALPHA, 4)), operator.lt, VersionNumber(5, 5, 5), expected_result=True, converse_operator=operator.ge),
            _Comparison(VersionNumber(5, 5, 6, PreRelease(PreReleaseLabel.BETA, 3)), operator.lt, VersionNumber(5, 5, 6), expected_result=True, converse_operator=operator.ge),
            _Comparison(VersionNumber(5, 6, 5, PreRelease(PreReleaseLabel.RELEASE_CANDIDATE, 2)), operator.lt, VersionNumber(5, 6, 5), expected_result=True, converse_operator=operator.ge),
        ))

    def test_pre_release_versions_compare_greater_than_standard_versions(self) -> None:
        self._run_comparisons((
            _Comparison(VersionNumber(5, 5, 5), operator.gt, VersionNumber(5, 5, 5, PreRelease(PreReleaseLabel.ALPHA, 3)), expected_result=True, converse_operator=operator.le),
            _Comparison(VersionNumber(5, 5, 6), operator.gt, VersionNumber(5, 5, 6, PreRelease(PreReleaseLabel.BETA, 4)), expected_result=True, converse_operator=operator.le),
            _Comparison(VersionNumber(5, 6, 5), operator.gt, VersionNumber(5, 6, 5, PreRelease(PreReleaseLabel.RELEASE_CANDIDATE, 5)), expected_result=True, converse_operator=operator.le),
            _Comparison(VersionNumber(5, 5, 5, PreRelease(PreReleaseLabel.ALPHA, 4)), operator.gt, VersionNumber(5, 5, 5), expected_result=False, converse_operator=operator.le),
            _Comparison(VersionNumber(5, 5, 6, PreRelease(PreReleaseLabel.BETA, 3)), operator.gt, VersionNumber(5, 5, 6), expected_result=False, converse_operator=operator.le),
            _Comparison(VersionNumber(5, 6, 5, PreRelease(PreReleaseLabel.RELEASE_CANDIDATE, 2)), operator.gt, VersionNumber(5, 6, 5), expected_result=False, converse_operator=operator.le),
        ))

    def test_pre_release_versions_compare_for_equality(self) -> None:
        self._run_comparisons((
            _Comparison(VersionNumber(5, 5, 5, PreRelease(PreReleaseLabel.ALPHA, 3)), operator.eq, VersionNumber(5, 5, 5, PreRelease(PreReleaseLabel.ALPHA, 3)), expected_result=True, converse_operator=operator.ne),
            _Comparison(VersionNumber(5, 5, 5, PreRelease(PreReleaseLabel.BETA, 4)), operator.eq, VersionNumber(5, 5, 5, PreRelease(PreReleaseLabel.BETA, 4)), expected_result=True, converse_operator=operator.ne),
            _Comparison(VersionNumber(5, 5, 5, PreRelease(PreReleaseLabel.RELEASE_CANDIDATE, 7)), operator.eq, VersionNumber(5, 5, 5, PreRelease(PreReleaseLabel.RELEASE_CANDIDATE, 7)), expected_result=True, converse_operator=operator.ne),
            _Comparison(VersionNumber(5, 5, 5, PreRelease(PreReleaseLabel.ALPHA, 3)), operator.eq, VersionNumber(5, 5, 5, PreRelease(PreReleaseLabel.ALPHA, 2)), expected_result=False, converse_operator=operator.ne),
            _Comparison(VersionNumber(5, 5, 5, PreRelease(PreReleaseLabel.BETA, 4)), operator.eq, VersionNumber(5, 5, 5, PreRelease(PreReleaseLabel.BETA, 5)), expected_result=False, converse_operator=operator.ne),
            _Comparison(VersionNumber(5, 5, 5, PreRelease(PreReleaseLabel.RELEASE_CANDIDATE, 7)), operator.eq, VersionNumber(5, 5, 5, PreRelease(PreReleaseLabel.RELEASE_CANDIDATE, 12)), expected_result=False, converse_operator=operator.ne),
        ))

    def test_pre_release_versions_compare_less_than(self) -> None:
        self._run_comparisons((
            _Comparison(VersionNumber(5, 5, 5, PreRelease(PreReleaseLabel.ALPHA, 3)), operator.lt, VersionNumber(5, 5, 5, PreRelease(PreReleaseLabel.BETA, 3)), expected_result=True, converse_operator=operator.ge),
            _Comparison(VersionNumber(5, 5, 5, PreRelease(PreReleaseLabel.BETA, 4)), operator.lt, VersionNumber(5, 5, 5, PreRelease(PreReleaseLabel.RELEASE_CANDIDATE, 4)), expected_result=True, converse_operator=operator.ge),
            _Comparison(VersionNumber(5, 5, 5, PreRelease(PreReleaseLabel.ALPHA, 7)), operator.lt, VersionNumber(5, 5, 5, PreRelease(PreReleaseLabel.RELEASE_CANDIDATE, 7)), expected_result=True, converse_operator=operator.ge),
            _Comparison(VersionNumber(5, 5, 5, PreRelease(PreReleaseLabel.ALPHA, 3)), operator.lt, VersionNumber(5, 5, 5, PreRelease(PreReleaseLabel.ALPHA, 2)), expected_result=False, converse_operator=operator.ge),
            _Comparison(VersionNumber(5, 5, 5, PreRelease(PreReleaseLabel.BETA, 4)), operator.lt, VersionNumber(5, 5, 5, PreRelease(PreReleaseLabel.BETA, 5)), expected_result=True, converse_operator=operator.ge),
            _Comparison(VersionNumber(5, 5, 5, PreRelease(PreReleaseLabel.RELEASE_CANDIDATE, 7)), operator.lt, VersionNumber(5, 5, 5, PreRelease(PreReleaseLabel.RELEASE_CANDIDATE, 12)), expected_result=True, converse_operator=operator.ge),
        ))

    def test_pre_release_versions_compare_greater_than(self) -> None:
        self._run_comparisons((
            _Comparison(VersionNumber(5, 5, 5, PreRelease(PreReleaseLabel.ALPHA, 3)), operator.gt, VersionNumber(5, 5, 5, PreRelease(PreReleaseLabel.BETA, 3)), expected_result=False, converse_operator=operator.le),
            _Comparison(VersionNumber(5, 5, 5, PreRelease(PreReleaseLabel.BETA, 4)), operator.gt, VersionNumber(5, 5, 5, PreRelease(PreReleaseLabel.RELEASE_CANDIDATE, 4)), expected_result=False, converse_operator=operator.le),
            _Comparison(VersionNumber(5, 5, 5, PreRelease(PreReleaseLabel.ALPHA, 7)), operator.gt, VersionNumber(5, 5, 5, PreRelease(PreReleaseLabel.RELEASE_CANDIDATE, 7)), expected_result=False, converse_operator=operator.le),
            _Comparison(VersionNumber(5, 5, 5, PreRelease(PreReleaseLabel.ALPHA, 3)), operator.gt, VersionNumber(5, 5, 5, PreRelease(PreReleaseLabel.ALPHA, 2)), expected_result=True, converse_operator=operator.le),
            _Comparison(VersionNumber(5, 5, 5, PreRelease(PreReleaseLabel.BETA, 4)), operator.gt, VersionNumber(5, 5, 5, PreRelease(PreReleaseLabel.BETA, 5)), expected_result=False, converse_operator=operator.le),
            _Comparison(VersionNumber(5, 5, 5, PreRelease(PreReleaseLabel.RELEASE_CANDIDATE, 7)), operator.gt, VersionNumber(5, 5, 5, PreRelease(PreReleaseLabel.RELEASE_CANDIDATE, 12)), expected_result=False, converse_operator=operator.le),
        ))
