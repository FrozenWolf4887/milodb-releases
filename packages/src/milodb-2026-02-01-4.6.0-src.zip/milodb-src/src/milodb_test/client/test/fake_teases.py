# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from milodb.client.database.author import Author, load_author
from milodb.client.database.tease import Tease, load_tease

FAKE_THUMBNAIL: str = "https://media.milovana.com/timg/tb_s/73d0969cdbccbf0aa37a5dd2ac1c8962e53ff7a4.jpg"

AUTHOR_ID_4567: Author = load_author(
    4567, {
        "anm": "Placebo",
    })

AUTHOR_ID_6431: Author = load_author(
    6431, {
        "anm": "Forest",
    })

AUTHOR_ID_7213: Author = load_author(
    7213, {
        "anm": "Curtains",
    })

TEASE_ID_1000_AUTHOR_ID_4567: Tease = load_tease(
    1000, {
        "aid": 4567,
        "dat": "2019-04-27",
        "rvl": 4.2,
        "sum": "Cutting paper and cardboard with scissors",
        "tgs": ":totm-nominee:paper:card:scissors:fabric:",
        "thm": FAKE_THUMBNAIL,
        "ttl": "Cutting paper",
        "txt": [ {
            "ref": "page1",
            "txt": "Take an A4 sheet\n"
                   "Draw a line down the middle\n"
                   "Cut it in half",
            },
        ],
        "typ": 1,
    }, {
        4567: AUTHOR_ID_4567,
    })

TEASE_ID_1234_AUTHOR_ID_6431: Tease = load_tease(
    1234, {
        "aid": 6431,
        "dat": "2020-01-18",
        "rvl": 4.0,
        "sum": "Bake a nice cookie",
        "tgs": ":food:cooking:totm:",
        "thm": FAKE_THUMBNAIL,
        "ttl": "Baking cookies",
        "txt": [ {
            "ref": "page1",
            "txt": "Get some flour, eggs, and chocolate\n"
                   "Mix it all together in a dough\n"
                   "Put it in a baking tray\n"
                   "Bake for 30 minutes",
            },
        ],
        "typ": 2,
    }, {
        6431: AUTHOR_ID_6431,
    })

TEASE_ID_5678_AUTHOR_ID_4567: Tease = load_tease(
    5678, {
        "aid": 4567,
        "dat": "2018-09-02",
        "rvl": 3.8,
        "sum": "Learn to drive a car",
        "tgs": ":driving:car:",
        "thm": FAKE_THUMBNAIL,
        "ttl": "Driving lessons",
        "txt": [ {
            "ref": "page1",
            "txt": "Seatbelt on\n"
                   "Put into neutral\n"
                   "Ensure handbrake is on\n"
                   "Start engine\n"
                   "Pass test",
            },
        ],
        "typ": 0,
    }, {
        4567: AUTHOR_ID_4567,
    })

TEASE_ID_2000_AUTHOR_ID_6431: Tease = load_tease(
    2000, {
        "aid": 6431,
        "dat": "2021-11-15",
        "rvl": 4.4,
        "sum": "Clean those dishes",
        "tgs": ":washing:totm-nominee:cleaning:chores:",
        "thm": FAKE_THUMBNAIL,
        "ttl": "Washing up",
        "typ": 3,
    }, {
        6431: AUTHOR_ID_6431,
    })

TEASE_ID_8721_AUTHOR_ID_7213: Tease = load_tease(
    8721, {
        "aid": 7213,
        "dat": "2022-12-31",
        "rvl": 3.0,
        "sum": "Vacuum the living room and bedroom",
        "tgs": ":vacuuming:chores:clean:",
        "thm": FAKE_THUMBNAIL,
        "ttl": "Vacuuming",
        "txt": [ {
            "ref": "page1",
            "txt": "Turn on the vacuum cleaner\n"
                   "Move the vacuum cleaner around the living room\n"
                   "Now the bedroom\n"
                   "Sit down and relax",
            },
        ],
        "typ": 2,
    }, {
        7213: AUTHOR_ID_7213,
    })
