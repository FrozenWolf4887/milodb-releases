# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from typing import override
from milodb.client.updater.manifest.common_manifest import IHexDigest

class MockDigest(IHexDigest):
    def __init__(self, digest_bytes: bytes) -> None:
        self._digest_bytes = digest_bytes

    @override
    def __str__(self) -> str:
        return self._digest_bytes.hex()

    @override
    def __eq__(self, other: object) -> bool:
        return isinstance(other, IHexDigest) and self.digest_bytes == other.digest_bytes

    @override
    def __ne__(self, other: object) -> bool:
        return not self.__eq__(other)

    @override
    def __hash__(self) -> int:
        return hash(self.digest_bytes)

    @property
    @override
    def digest_bytes(self) -> bytes:
        return self._digest_bytes
