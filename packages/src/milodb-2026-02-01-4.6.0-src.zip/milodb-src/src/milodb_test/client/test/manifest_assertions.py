# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import unittest
from collections.abc import Mapping, Sequence, Set as AbstractSet
from milodb.client.updater.manifest.i_schema_types import ITypedItem, ITypedKey

def assert_typed_mapping_equal[K, V](test_case: unittest.TestCase, left: Mapping[K, V], right: Mapping[ITypedKey[K], ITypedItem[V]]) -> None:
    set_of_left_keys: AbstractSet[K] = set(left)
    set_of_right_keys: AbstractSet[K] = { key.get_key_value() for key in right }

    set_of_unique_left_keys: AbstractSet[K] = set_of_left_keys - set_of_right_keys
    set_of_unique_right_keys: AbstractSet[K] = set_of_right_keys - set_of_left_keys

    if set_of_unique_left_keys:
        test_case.fail(f"Keys of left {set_of_unique_left_keys} missing from right")
    if set_of_unique_right_keys:
        test_case.fail(f"Keys of right {set_of_unique_right_keys} missing from left")

    right_typed_key: ITypedKey[K]
    right_typed_value: ITypedItem[V]
    for right_typed_key, right_typed_value in right.items():
        left_value: V = left[right_typed_key.get_key_value()]
        test_case.assertEqual(left_value, right_typed_value.get_item_value())

def assert_typed_sequence_equal[V](test_case: unittest.TestCase, left: Sequence[V], right: Sequence[ITypedItem[V]]) -> None:
    if len(left) != len(right):
        test_case.fail(f"Left sequence has {len(left)} items and right sequence as {len(right)} items")

    index: int
    left_value: V
    for index, left_value in enumerate(left):
        right_typed_value: ITypedItem[V] = right[index]
        test_case.assertEqual(left_value, right_typed_value.get_item_value(), f'Mismatch at index {index}')
