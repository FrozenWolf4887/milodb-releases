# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import dataclasses
from abc import ABC
from types import UnionType
from typing import get_origin, override
from unittest.mock import Mock, NonCallableMock, PropertyMock

class InterfaceMock(NonCallableMock):
    def __init__(self, interface: type[ABC], **kwargs: Mock) -> None: # pyright: ignore [reportInconsistentConstructor]
        self._mocked_interface: type[ABC] = interface
        super().__init__(spec=interface, name=interface.__name__)
        arg_name: str
        arg_value: Mock
        for arg_name, arg_value in kwargs.items():
            self.__setattr__(arg_name, arg_value)

    @override
    def __getattr__(self, name: str) -> Mock:
        if name in dir():
            attr: object = super().__getattr__(name)
            if isinstance(attr, Mock):
                return attr
            msg = f"Mock interface '{self._mocked_interface.__name__}' has a non-mocked attribute '{name}'"
            raise AssertionError(msg)
        if name in dir(self._mocked_interface):
            msg = f"Mock interface '{self._mocked_interface.__name__}' unexpected access to '{name}'"
            raise AssertionError(msg)
        msg = f"Mock interface '{self._mocked_interface.__name__}' has no attribute '{name}'"
        raise AttributeError(msg)

    @override
    def __setattr__(self, name: str, value: object) -> None:
        if name == '_mocked_interface':
            object.__setattr__(self, name, value)
        elif name in dir(self._mocked_interface):
            if isinstance(getattr(self._mocked_interface, name), property):
                if not isinstance(value, PropertyMock):
                    msg = f"Member '{self._mocked_interface.__name__}.{name}' is a property and should be assigned to a PropertyMock"
                    raise TypeError(msg)
                setattr(type(self), name, value)
            elif callable(getattr(self._mocked_interface, name)):
                if not (isinstance(value, Mock) or callable(value)) and not isinstance(value, PropertyMock):
                    msg = f"Member '{self._mocked_interface.__name__}.{name}' is a method and should be assigned to a Mock"
                    raise TypeError(msg)
                super().__setattr__(name, value)
            else:
                super().__setattr__(name, value)
        else:
            msg = f"Mock interface '{self._mocked_interface.__name__}' has no attribute '{name}'"
            raise AttributeError(msg)

class DataclassMock(NonCallableMock):
    def __init__(self, cls: type[object], **kwargs: object) -> None: # pyright: ignore [reportInconsistentConstructor]
        if not dataclasses.is_dataclass(cls):
            msg = f"Class '{cls.__name__}' is not a dataclass"
            raise TypeError(msg)
        self._mocked_class: type[object] = cls
        super().__init__(spec=cls, name=cls.__name__)
        arg_name: str
        arg_value: object
        for arg_name, arg_value in kwargs.items():
            self.__setattr__(arg_name, arg_value)

    @override
    def __getattr__(self, name: str) -> object:
        if name in dir():
            return super().__getattr__(name)
        if name in self._mocked_class.__annotations__:
            msg = f"Mock dataclass '{self._mocked_class.__name__}' unexpected access to '{name}'"
            raise AssertionError(msg)
        msg = f"Mock dataclass '{self._mocked_class.__name__}' has no attribute '{name}'"
        raise AttributeError(msg)

    @override
    def __setattr__(self, name: str, value: object) -> None:
        if name == '_mocked_class':
            object.__setattr__(self, name, value)
        else:
            member_type: type[object] | None = self._mocked_class.__annotations__.get(name)
            if not member_type:
                msg = f"Mock interface '{self._mocked_class.__name__}' has no attribute '{name}'"
                raise AttributeError(msg)
            base_type: type[object] | None = get_origin(member_type)
            if base_type is UnionType: # pyright: ignore[reportUnnecessaryComparison] False-positive
                base_type = None
            if not isinstance(value, base_type or member_type):
                msg = f"Mock interface '{self._mocked_class.__name__}' attribute '{name}' is being assigned the wrong type"
                raise AttributeError(msg)
            super().__setattr__(name, value)
