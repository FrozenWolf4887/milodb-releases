# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import datetime
import unittest
from milodb.common.types.partial_date import PartialDate

class TestPartialDateYear(unittest.TestCase):
    def test_eq_is_true_in_same_year(self) -> None:
        date = PartialDate(datetime.date(2000, 5, 18), PartialDate.Granularity.HAS_YEAR)
        self.assertTrue(PartialDate.is_eq(datetime.date(2000, 1, 1), date))
        self.assertTrue(PartialDate.is_eq(datetime.date(2000, 5, 18), date))
        self.assertTrue(PartialDate.is_eq(datetime.date(2000, 12, 31), date))

    def test_eq_is_false_in_previous_years(self) -> None:
        date = PartialDate(datetime.date(2000, 5, 18), PartialDate.Granularity.HAS_YEAR)
        self.assertFalse(PartialDate.is_eq(datetime.date(1999, 12, 31), date))
        self.assertFalse(PartialDate.is_eq(datetime.date(1999, 5, 18), date))
        self.assertFalse(PartialDate.is_eq(datetime.date(1985, 6, 1), date))

    def test_eq_is_false_in_following_years(self) -> None:
        date = PartialDate(datetime.date(2000, 5, 18), PartialDate.Granularity.HAS_YEAR)
        self.assertFalse(PartialDate.is_eq(datetime.date(2001, 1, 1), date))
        self.assertFalse(PartialDate.is_eq(datetime.date(2001, 5, 18), date))
        self.assertFalse(PartialDate.is_eq(datetime.date(2024, 7, 11), date))

    def test_gt_is_false_in_same_year(self) -> None:
        date = PartialDate(datetime.date(2000, 5, 18), PartialDate.Granularity.HAS_YEAR)
        self.assertFalse(PartialDate.is_gt(datetime.date(2000, 1, 1), date))
        self.assertFalse(PartialDate.is_gt(datetime.date(2000, 5, 18), date))
        self.assertFalse(PartialDate.is_gt(datetime.date(2000, 12, 31), date))

    def test_gt_is_false_in_previous_years(self) -> None:
        date = PartialDate(datetime.date(2000, 5, 18), PartialDate.Granularity.HAS_YEAR)
        self.assertFalse(PartialDate.is_gt(datetime.date(1999, 12, 31), date))
        self.assertFalse(PartialDate.is_gt(datetime.date(1999, 7, 21), date))
        self.assertFalse(PartialDate.is_gt(datetime.date(1985, 6, 1), date))

    def test_gt_is_true_in_following_years(self) -> None:
        date = PartialDate(datetime.date(2000, 5, 18), PartialDate.Granularity.HAS_YEAR)
        self.assertTrue(PartialDate.is_gt(datetime.date(2001, 1, 1), date))
        self.assertTrue(PartialDate.is_gt(datetime.date(2001, 7, 21), date))
        self.assertTrue(PartialDate.is_gt(datetime.date(2024, 5, 6), date))

    def test_lt_is_false_in_same_year(self) -> None:
        date = PartialDate(datetime.date(2000, 5, 18), PartialDate.Granularity.HAS_YEAR)
        self.assertFalse(PartialDate.is_lt(datetime.date(2000, 1, 1), date))
        self.assertFalse(PartialDate.is_lt(datetime.date(2000, 5, 18), date))
        self.assertFalse(PartialDate.is_lt(datetime.date(2000, 12, 31), date))

    def test_lt_is_true_in_previous_years(self) -> None:
        date = PartialDate(datetime.date(2000, 5, 18), PartialDate.Granularity.HAS_YEAR)
        self.assertTrue(PartialDate.is_lt(datetime.date(1999, 12, 31), date))
        self.assertTrue(PartialDate.is_lt(datetime.date(1999, 7, 21), date))
        self.assertTrue(PartialDate.is_lt(datetime.date(1985, 6, 1), date))

    def test_lt_is_false_in_following_years(self) -> None:
        date = PartialDate(datetime.date(2000, 5, 18), PartialDate.Granularity.HAS_YEAR)
        self.assertFalse(PartialDate.is_lt(datetime.date(2001, 1, 1), date))
        self.assertFalse(PartialDate.is_lt(datetime.date(2001, 7, 21), date))
        self.assertFalse(PartialDate.is_lt(datetime.date(2024, 5, 6), date))

    def test_ge_is_true_in_same_year(self) -> None:
        date = PartialDate(datetime.date(2000, 5, 18), PartialDate.Granularity.HAS_YEAR)
        self.assertTrue(PartialDate.is_ge(datetime.date(2000, 1, 1), date))
        self.assertTrue(PartialDate.is_ge(datetime.date(2000, 5, 18), date))
        self.assertTrue(PartialDate.is_ge(datetime.date(2000, 12, 31), date))

    def test_ge_is_false_in_previous_years(self) -> None:
        date = PartialDate(datetime.date(2000, 5, 18), PartialDate.Granularity.HAS_YEAR)
        self.assertFalse(PartialDate.is_ge(datetime.date(1999, 12, 31), date))
        self.assertFalse(PartialDate.is_ge(datetime.date(1999, 7, 21), date))
        self.assertFalse(PartialDate.is_ge(datetime.date(1985, 6, 1), date))

    def test_ge_is_true_in_following_years(self) -> None:
        date = PartialDate(datetime.date(2000, 5, 18), PartialDate.Granularity.HAS_YEAR)
        self.assertTrue(PartialDate.is_ge(datetime.date(2001, 1, 1), date))
        self.assertTrue(PartialDate.is_ge(datetime.date(2001, 7, 21), date))
        self.assertTrue(PartialDate.is_ge(datetime.date(2024, 5, 6), date))

    def test_le_is_true_in_same_year(self) -> None:
        date = PartialDate(datetime.date(2000, 5, 18), PartialDate.Granularity.HAS_YEAR)
        self.assertTrue(PartialDate.is_le(datetime.date(2000, 1, 1), date))
        self.assertTrue(PartialDate.is_le(datetime.date(2000, 5, 18), date))
        self.assertTrue(PartialDate.is_le(datetime.date(2000, 12, 31), date))

    def test_le_is_true_in_previous_years(self) -> None:
        date = PartialDate(datetime.date(2000, 5, 18), PartialDate.Granularity.HAS_YEAR)
        self.assertTrue(PartialDate.is_le(datetime.date(1999, 12, 31), date))
        self.assertTrue(PartialDate.is_le(datetime.date(1999, 7, 21), date))
        self.assertTrue(PartialDate.is_le(datetime.date(1985, 6, 1), date))

    def test_le_is_false_in_following_years(self) -> None:
        date = PartialDate(datetime.date(2000, 5, 18), PartialDate.Granularity.HAS_YEAR)
        self.assertFalse(PartialDate.is_le(datetime.date(2001, 1, 1), date))
        self.assertFalse(PartialDate.is_le(datetime.date(2001, 7, 21), date))
        self.assertFalse(PartialDate.is_le(datetime.date(2024, 5, 6), date))

class TestPartialDateMonth(unittest.TestCase):
    def test_eq_is_true_in_same_year_and_month(self) -> None:
        date = PartialDate(datetime.date(2000, 5, 18), PartialDate.Granularity.HAS_MONTH)
        self.assertTrue(PartialDate.is_eq(datetime.date(2000, 5, 1), date))
        self.assertTrue(PartialDate.is_eq(datetime.date(2000, 5, 18), date))
        self.assertTrue(PartialDate.is_eq(datetime.date(2000, 5, 30), date))

    def test_eq_is_false_in_same_year_different_months(self) -> None:
        date = PartialDate(datetime.date(2000, 5, 18), PartialDate.Granularity.HAS_MONTH)
        self.assertFalse(PartialDate.is_eq(datetime.date(2000, 4, 1), date))
        self.assertFalse(PartialDate.is_eq(datetime.date(2000, 6, 18), date))
        self.assertFalse(PartialDate.is_eq(datetime.date(2000, 12, 30), date))

    def test_eq_is_false_in_previous_years(self) -> None:
        date = PartialDate(datetime.date(2000, 5, 18), PartialDate.Granularity.HAS_MONTH)
        self.assertFalse(PartialDate.is_eq(datetime.date(1999, 12, 31), date))
        self.assertFalse(PartialDate.is_eq(datetime.date(1999, 7, 21), date))
        self.assertFalse(PartialDate.is_eq(datetime.date(1985, 6, 1), date))

    def test_eq_is_false_in_same_year_previous_months(self) -> None:
        date = PartialDate(datetime.date(2000, 5, 18), PartialDate.Granularity.HAS_MONTH)
        self.assertFalse(PartialDate.is_eq(datetime.date(2000, 4, 1), date))
        self.assertFalse(PartialDate.is_eq(datetime.date(2000, 2, 18), date))
        self.assertFalse(PartialDate.is_eq(datetime.date(2000, 1, 30), date))

    def test_eq_is_false_in_following_years(self) -> None:
        date = PartialDate(datetime.date(2000, 5, 18), PartialDate.Granularity.HAS_MONTH)
        self.assertFalse(PartialDate.is_eq(datetime.date(2001, 1, 1), date))
        self.assertFalse(PartialDate.is_eq(datetime.date(2001, 7, 21), date))
        self.assertFalse(PartialDate.is_eq(datetime.date(2024, 5, 6), date))

    def test_gt_is_false_in_previous_years(self) -> None:
        date = PartialDate(datetime.date(2000, 5, 18), PartialDate.Granularity.HAS_MONTH)
        self.assertFalse(PartialDate.is_gt(datetime.date(1999, 12, 31), date))
        self.assertFalse(PartialDate.is_gt(datetime.date(1999, 7, 21), date))
        self.assertFalse(PartialDate.is_gt(datetime.date(1985, 6, 1), date))

    def test_gt_is_true_in_following_years(self) -> None:
        date = PartialDate(datetime.date(2000, 5, 18), PartialDate.Granularity.HAS_MONTH)
        self.assertTrue(PartialDate.is_gt(datetime.date(2001, 1, 1), date))
        self.assertTrue(PartialDate.is_gt(datetime.date(2001, 7, 21), date))
        self.assertTrue(PartialDate.is_gt(datetime.date(2024, 5, 6), date))

    def test_gt_is_false_in_same_year_same_month(self) -> None:
        date = PartialDate(datetime.date(2000, 5, 18), PartialDate.Granularity.HAS_MONTH)
        self.assertFalse(PartialDate.is_gt(datetime.date(2000, 5, 1), date))
        self.assertFalse(PartialDate.is_gt(datetime.date(2000, 5, 18), date))
        self.assertFalse(PartialDate.is_gt(datetime.date(2000, 5, 31), date))

    def test_gt_is_false_in_same_year_previous_months(self) -> None:
        date = PartialDate(datetime.date(2000, 5, 18), PartialDate.Granularity.HAS_MONTH)
        self.assertFalse(PartialDate.is_gt(datetime.date(2000, 1, 18), date))
        self.assertFalse(PartialDate.is_gt(datetime.date(2000, 3, 1), date))
        self.assertFalse(PartialDate.is_gt(datetime.date(2000, 4, 30), date))

    def test_gt_is_true_in_same_year_following_months(self) -> None:
        date = PartialDate(datetime.date(2000, 5, 18), PartialDate.Granularity.HAS_MONTH)
        self.assertTrue(PartialDate.is_gt(datetime.date(2000, 6, 1), date))
        self.assertTrue(PartialDate.is_gt(datetime.date(2000, 9, 22), date))
        self.assertTrue(PartialDate.is_gt(datetime.date(2000, 12, 4), date))

    def test_lt_is_true_in_previous_years(self) -> None:
        date = PartialDate(datetime.date(2000, 5, 18), PartialDate.Granularity.HAS_MONTH)
        self.assertTrue(PartialDate.is_lt(datetime.date(1999, 12, 31), date))
        self.assertTrue(PartialDate.is_lt(datetime.date(1999, 7, 21), date))
        self.assertTrue(PartialDate.is_lt(datetime.date(1985, 6, 1), date))

    def test_lt_is_false_in_following_years(self) -> None:
        date = PartialDate(datetime.date(2000, 5, 18), PartialDate.Granularity.HAS_MONTH)
        self.assertFalse(PartialDate.is_lt(datetime.date(2001, 1, 1), date))
        self.assertFalse(PartialDate.is_lt(datetime.date(2001, 7, 21), date))
        self.assertFalse(PartialDate.is_lt(datetime.date(2024, 5, 6), date))

    def test_lt_is_false_in_same_year_same_month(self) -> None:
        date = PartialDate(datetime.date(2000, 5, 18), PartialDate.Granularity.HAS_MONTH)
        self.assertFalse(PartialDate.is_lt(datetime.date(2000, 5, 1), date))
        self.assertFalse(PartialDate.is_lt(datetime.date(2000, 5, 18), date))
        self.assertFalse(PartialDate.is_lt(datetime.date(2000, 5, 31), date))

    def test_lt_is_true_in_same_year_previous_months(self) -> None:
        date = PartialDate(datetime.date(2000, 5, 18), PartialDate.Granularity.HAS_MONTH)
        self.assertTrue(PartialDate.is_lt(datetime.date(2000, 1, 18), date))
        self.assertTrue(PartialDate.is_lt(datetime.date(2000, 3, 1), date))
        self.assertTrue(PartialDate.is_lt(datetime.date(2000, 4, 30), date))

    def test_lt_is_false_in_same_year_following_months(self) -> None:
        date = PartialDate(datetime.date(2000, 5, 18), PartialDate.Granularity.HAS_MONTH)
        self.assertFalse(PartialDate.is_lt(datetime.date(2000, 6, 1), date))
        self.assertFalse(PartialDate.is_lt(datetime.date(2000, 9, 22), date))
        self.assertFalse(PartialDate.is_lt(datetime.date(2000, 12, 4), date))

    def test_ge_is_false_in_previous_years(self) -> None:
        date = PartialDate(datetime.date(2000, 5, 18), PartialDate.Granularity.HAS_MONTH)
        self.assertFalse(PartialDate.is_ge(datetime.date(1999, 12, 31), date))
        self.assertFalse(PartialDate.is_ge(datetime.date(1999, 7, 21), date))
        self.assertFalse(PartialDate.is_ge(datetime.date(1985, 6, 1), date))

    def test_ge_is_true_in_following_years(self) -> None:
        date = PartialDate(datetime.date(2000, 5, 18), PartialDate.Granularity.HAS_MONTH)
        self.assertTrue(PartialDate.is_ge(datetime.date(2001, 1, 1), date))
        self.assertTrue(PartialDate.is_ge(datetime.date(2001, 7, 21), date))
        self.assertTrue(PartialDate.is_ge(datetime.date(2024, 5, 6), date))

    def test_ge_is_true_in_same_year_same_month(self) -> None:
        date = PartialDate(datetime.date(2000, 5, 18), PartialDate.Granularity.HAS_MONTH)
        self.assertTrue(PartialDate.is_ge(datetime.date(2000, 5, 1), date))
        self.assertTrue(PartialDate.is_ge(datetime.date(2000, 5, 18), date))
        self.assertTrue(PartialDate.is_ge(datetime.date(2000, 5, 31), date))

    def test_ge_is_false_in_same_year_previous_months(self) -> None:
        date = PartialDate(datetime.date(2000, 5, 18), PartialDate.Granularity.HAS_MONTH)
        self.assertFalse(PartialDate.is_ge(datetime.date(2000, 1, 18), date))
        self.assertFalse(PartialDate.is_ge(datetime.date(2000, 3, 1), date))
        self.assertFalse(PartialDate.is_ge(datetime.date(2000, 4, 30), date))

    def test_ge_is_true_in_same_year_following_months(self) -> None:
        date = PartialDate(datetime.date(2000, 5, 18), PartialDate.Granularity.HAS_MONTH)
        self.assertTrue(PartialDate.is_ge(datetime.date(2000, 6, 1), date))
        self.assertTrue(PartialDate.is_ge(datetime.date(2000, 9, 22), date))
        self.assertTrue(PartialDate.is_ge(datetime.date(2000, 12, 4), date))

    def test_le_is_true_in_previous_years(self) -> None:
        date = PartialDate(datetime.date(2000, 5, 18), PartialDate.Granularity.HAS_MONTH)
        self.assertTrue(PartialDate.is_le(datetime.date(1999, 12, 31), date))
        self.assertTrue(PartialDate.is_le(datetime.date(1999, 7, 21), date))
        self.assertTrue(PartialDate.is_le(datetime.date(1985, 6, 1), date))

    def test_le_is_false_in_following_years(self) -> None:
        date = PartialDate(datetime.date(2000, 5, 18), PartialDate.Granularity.HAS_MONTH)
        self.assertFalse(PartialDate.is_le(datetime.date(2001, 1, 1), date))
        self.assertFalse(PartialDate.is_le(datetime.date(2001, 7, 21), date))
        self.assertFalse(PartialDate.is_le(datetime.date(2024, 5, 6), date))

    def test_le_is_true_in_same_year_same_month(self) -> None:
        date = PartialDate(datetime.date(2000, 5, 18), PartialDate.Granularity.HAS_MONTH)
        self.assertTrue(PartialDate.is_le(datetime.date(2000, 5, 1), date))
        self.assertTrue(PartialDate.is_le(datetime.date(2000, 5, 18), date))
        self.assertTrue(PartialDate.is_le(datetime.date(2000, 5, 31), date))

    def test_le_is_true_in_same_year_previous_months(self) -> None:
        date = PartialDate(datetime.date(2000, 5, 18), PartialDate.Granularity.HAS_MONTH)
        self.assertTrue(PartialDate.is_le(datetime.date(2000, 1, 18), date))
        self.assertTrue(PartialDate.is_le(datetime.date(2000, 3, 1), date))
        self.assertTrue(PartialDate.is_le(datetime.date(2000, 4, 30), date))

    def test_le_is_false_in_same_year_following_months(self) -> None:
        date = PartialDate(datetime.date(2000, 5, 18), PartialDate.Granularity.HAS_MONTH)
        self.assertFalse(PartialDate.is_le(datetime.date(2000, 6, 1), date))
        self.assertFalse(PartialDate.is_le(datetime.date(2000, 9, 22), date))
        self.assertFalse(PartialDate.is_le(datetime.date(2000, 12, 4), date))

class TestPartialDateDay(unittest.TestCase):
    def test_eq_is_true_only_when_exactly_the_same(self) -> None:
        date = PartialDate(datetime.date(2000, 5, 18), PartialDate.Granularity.HAS_DAY)
        self.assertTrue(PartialDate.is_eq(datetime.date(2000, 5, 18), date))
        self.assertFalse(PartialDate.is_eq(datetime.date(2000, 5, 17), date))
        self.assertFalse(PartialDate.is_eq(datetime.date(2000, 5, 19), date))
        self.assertFalse(PartialDate.is_eq(datetime.date(2000, 4, 18), date))
        self.assertFalse(PartialDate.is_eq(datetime.date(2000, 6, 18), date))
        self.assertFalse(PartialDate.is_eq(datetime.date(1999, 5, 18), date))
        self.assertFalse(PartialDate.is_eq(datetime.date(2001, 5, 18), date))

    def test_lt_is_true_only_when_less(self) -> None:
        date = PartialDate(datetime.date(2000, 5, 18), PartialDate.Granularity.HAS_DAY)
        self.assertFalse(PartialDate.is_lt(datetime.date(2000, 5, 18), date))
        self.assertTrue(PartialDate.is_lt(datetime.date(2000, 5, 17), date))
        self.assertFalse(PartialDate.is_lt(datetime.date(2000, 5, 19), date))
        self.assertTrue(PartialDate.is_lt(datetime.date(2000, 4, 18), date))
        self.assertFalse(PartialDate.is_lt(datetime.date(2000, 6, 18), date))
        self.assertTrue(PartialDate.is_lt(datetime.date(1999, 5, 18), date))
        self.assertFalse(PartialDate.is_lt(datetime.date(2001, 5, 18), date))

    def test_gt_is_true_only_when_greater(self) -> None:
        date = PartialDate(datetime.date(2000, 5, 18), PartialDate.Granularity.HAS_DAY)
        self.assertFalse(PartialDate.is_gt(datetime.date(2000, 5, 18), date))
        self.assertFalse(PartialDate.is_gt(datetime.date(2000, 5, 17), date))
        self.assertTrue(PartialDate.is_gt(datetime.date(2000, 5, 19), date))
        self.assertFalse(PartialDate.is_gt(datetime.date(2000, 4, 18), date))
        self.assertTrue(PartialDate.is_gt(datetime.date(2000, 6, 18), date))
        self.assertFalse(PartialDate.is_gt(datetime.date(1999, 5, 18), date))
        self.assertTrue(PartialDate.is_gt(datetime.date(2001, 5, 18), date))

    def test_le_is_true_only_when_less_or_equal(self) -> None:
        date = PartialDate(datetime.date(2000, 5, 18), PartialDate.Granularity.HAS_DAY)
        self.assertTrue(PartialDate.is_le(datetime.date(2000, 5, 18), date))
        self.assertTrue(PartialDate.is_le(datetime.date(2000, 5, 17), date))
        self.assertFalse(PartialDate.is_le(datetime.date(2000, 5, 19), date))
        self.assertTrue(PartialDate.is_le(datetime.date(2000, 4, 18), date))
        self.assertFalse(PartialDate.is_le(datetime.date(2000, 6, 18), date))
        self.assertTrue(PartialDate.is_le(datetime.date(1999, 5, 18), date))
        self.assertFalse(PartialDate.is_le(datetime.date(2001, 5, 18), date))

    def test_ge_is_true_only_when_greater_or_equal(self) -> None:
        date = PartialDate(datetime.date(2000, 5, 18), PartialDate.Granularity.HAS_DAY)
        self.assertTrue(PartialDate.is_ge(datetime.date(2000, 5, 18), date))
        self.assertFalse(PartialDate.is_ge(datetime.date(2000, 5, 17), date))
        self.assertTrue(PartialDate.is_ge(datetime.date(2000, 5, 19), date))
        self.assertFalse(PartialDate.is_ge(datetime.date(2000, 4, 18), date))
        self.assertTrue(PartialDate.is_ge(datetime.date(2000, 6, 18), date))
        self.assertFalse(PartialDate.is_ge(datetime.date(1999, 5, 18), date))
        self.assertTrue(PartialDate.is_ge(datetime.date(2001, 5, 18), date))

class TestPartialDateParse(unittest.TestCase):
    def test_parse_accepts_year(self) -> None:
        date = PartialDate.parse('1984')
        self.assertEqual(1984, date.year)
        self.assertEqual(1, date.month)
        self.assertEqual(1, date.day)
        self.assertEqual(PartialDate.Granularity.HAS_YEAR, date.granularity)

    def test_parse_accepts_year_and_one_digit_month(self) -> None:
        date = PartialDate.parse('1984-4')
        self.assertEqual(1984, date.year)
        self.assertEqual(4, date.month)
        self.assertEqual(1, date.day)
        self.assertEqual(PartialDate.Granularity.HAS_MONTH, date.granularity)

    def test_parse_accepts_year_and_two_digit_month(self) -> None:
        date = PartialDate.parse('1984-10')
        self.assertEqual(1984, date.year)
        self.assertEqual(10, date.month)
        self.assertEqual(1, date.day)
        self.assertEqual(PartialDate.Granularity.HAS_MONTH, date.granularity)

    def test_parse_accepts_year_and_one_digit_month_and_one_digit_day(self) -> None:
        date = PartialDate.parse('1984-3-9')
        self.assertEqual(1984, date.year)
        self.assertEqual(3, date.month)
        self.assertEqual(9, date.day)
        self.assertEqual(PartialDate.Granularity.HAS_DAY, date.granularity)

    def test_parse_accepts_year_and_two_digit_month_and_one_digit_day(self) -> None:
        date = PartialDate.parse('1984-12-7')
        self.assertEqual(1984, date.year)
        self.assertEqual(12, date.month)
        self.assertEqual(7, date.day)
        self.assertEqual(PartialDate.Granularity.HAS_DAY, date.granularity)

    def test_parse_accepts_year_and_two_digit_month_and_two_digit_day(self) -> None:
        date = PartialDate.parse('1984-02-26')
        self.assertEqual(1984, date.year)
        self.assertEqual(2, date.month)
        self.assertEqual(26, date.day)
        self.assertEqual(PartialDate.Granularity.HAS_DAY, date.granularity)

    def test_parse_fails_when_year_has_invalid_characters(self) -> None:
        with self.assertRaises(ValueError):
            PartialDate.parse('200a')
        with self.assertRaises(ValueError):
            PartialDate.parse('-200')
        with self.assertRaises(ValueError):
            PartialDate.parse('18w3')

    def test_parse_fails_when_year_is_too_short(self) -> None:
        with self.assertRaises(ValueError):
            PartialDate.parse('200')
        with self.assertRaises(ValueError):
            PartialDate.parse('20')
        with self.assertRaises(ValueError):
            PartialDate.parse('2')

    def test_parse_fails_when_year_is_too_long(self) -> None:
        with self.assertRaises(ValueError):
            PartialDate.parse('20000')

    def test_parse_fails_when_month_has_invalid_characters(self) -> None:
        with self.assertRaises(ValueError):
            PartialDate.parse('2000-K')
        with self.assertRaises(ValueError):
            PartialDate.parse('2000-1g')

    def test_parse_fails_when_month_is_too_long(self) -> None:
        with self.assertRaises(ValueError):
            PartialDate.parse('2000-001')
        with self.assertRaises(ValueError):
            PartialDate.parse('2000-123')

    def test_parse_fails_when_month_is_out_of_range(self) -> None:
        with self.assertRaises(ValueError):
            PartialDate.parse('2000-0')
        with self.assertRaises(ValueError):
            PartialDate.parse('2000-00')
        with self.assertRaises(ValueError):
            PartialDate.parse('2000-13')

    def test_parse_fails_when_day_has_invalid_characters(self) -> None:
        with self.assertRaises(ValueError):
            PartialDate.parse('2000-01-K')
        with self.assertRaises(ValueError):
            PartialDate.parse('2000-01-1g')

    def test_parse_fails_when_day_is_too_long(self) -> None:
        with self.assertRaises(ValueError):
            PartialDate.parse('2000-01-001')
        with self.assertRaises(ValueError):
            PartialDate.parse('2000-01-123')

    def test_parse_fails_when_day_is_out_of_range(self) -> None:
        with self.assertRaises(ValueError):
            PartialDate.parse('2000-01-0')
        with self.assertRaises(ValueError):
            PartialDate.parse('2000-01-00')
        with self.assertRaises(ValueError):
            PartialDate.parse('2000-02-30')
        with self.assertRaises(ValueError):
            PartialDate.parse('2000-01-32')
