# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import copy
import json
from collections.abc import MutableMapping
from enum import Enum
from pathlib import Path
from typing import override
from milodb.common.config.framework import IConfigGroup, IPersistentConfig
from milodb.common.config.migration_result import ConfigMigrationResult, MigrateCallable
from milodb.common.output.print.i_printer import IPrinter

class _ShouldSave(Enum):
    NO = 0
    YES = 1

    def __bool__(self) -> bool:
        return self is _ShouldSave.YES

class JsonConfigFile(IPersistentConfig):
    def __init__(self, filepath: Path, config_schema: IConfigGroup, call_migrate: MigrateCallable | None) -> None:
        self._filepath: Path = filepath
        self._config_schema: IConfigGroup = config_schema
        self._call_migrate: MigrateCallable | None = call_migrate
        self._config_dict: MutableMapping[object, object] = _copy_of_default_config(config_schema)
        self._load_was_successful: bool = True

    @override
    def load(self, normal_printer: IPrinter, warning_printer: IPrinter, error_printer: IPrinter) -> None:
        try:
            self._config_dict = json.loads(self._filepath.read_text(encoding='utf-8'))
        except FileNotFoundError:
            self._config_dict = _copy_of_default_config(self._config_schema)
            self.save(normal_printer, warning_printer, error_printer)
        except (OSError, json.JSONDecodeError) as ex:
            self._load_was_successful = False
            error_printer.writeln(f"Unable to load config from '{self._filepath}': {ex}")
            warning_printer.writeln("Config entries changed at runtime will not be saved to prevent corruption")
            normal_printer.writeln('Using default config')
            self._config_dict = _copy_of_default_config(self._config_schema)
        else:
            normal_printer.writeln(f"Loaded config from '{self._filepath}'")
            should_save_from_migration: _ShouldSave = self._migrate_config_versions(normal_printer, error_printer)
            should_save_from_validation: _ShouldSave = self._validate_config(normal_printer, warning_printer, error_printer)
            if should_save_from_migration or should_save_from_validation:
                self.save(normal_printer, warning_printer, error_printer)

    @override
    def save(self, normal_printer: IPrinter, warning_printer: IPrinter, error_printer: IPrinter) -> None:
        if self._load_was_successful:
            was_backup_successful: bool = False
            backup_filepath: Path = self._filepath.with_name(f'{self._filepath.name}.old')
            try:
                backup_filepath.write_bytes(self._filepath.read_bytes())
            except FileNotFoundError:
                was_backup_successful = True
            except OSError as ex:
                error_printer.writeln(f"Unable to backup config to file '{backup_filepath}': {ex}")
                warning_printer.writeln('Config not saved due to backup error')
            else:
                was_backup_successful = True

            if was_backup_successful:
                try:
                    self._filepath.write_text(json.dumps(self._config_dict, indent=4, ensure_ascii=False, sort_keys=True), encoding='utf-8')
                except (OSError, UnicodeEncodeError) as ex:
                    error_printer.writeln(f"Unable to write config to file '{self._filepath}': {ex}")
                else:
                    normal_printer.writeln(f"Saved config file '{self._filepath}'")
        else:
            warning_printer.writeln('Config not saved due to initial loading error')

    @override
    def try_purge(self, normal_printer: IPrinter) -> bool:
        return self._config_schema.try_remove_redundancy(self._config_dict, normal_printer)

    @property
    @override
    def dictionary(self) -> MutableMapping[object, object]:
        return self._config_dict

    def _migrate_config_versions(self, normal_printer: IPrinter, error_printer: IPrinter) -> _ShouldSave:
        if self._call_migrate is None:
            return _ShouldSave.NO
        migration_result: ConfigMigrationResult = self._call_migrate(self._config_dict, normal_printer, error_printer)
        match migration_result:
            case ConfigMigrationResult.SUCCESSFUL:
                return _ShouldSave.YES
            case ConfigMigrationResult.FAILED:
                self._load_was_successful = False
                return _ShouldSave.NO
            case ConfigMigrationResult.NOT_NEEDED:
                return _ShouldSave.NO

    def _validate_config(self, normal_printer: IPrinter, warning_printer: IPrinter, error_printer: IPrinter) -> _ShouldSave:
        self._config_schema.validate_existing(self._config_dict, error_printer)
        self._config_schema.report_redundancy(self._config_dict, warning_printer)
        if self._config_schema.try_add_missing(self._config_dict, normal_printer):
            return _ShouldSave.YES
        return _ShouldSave.NO

def _copy_of_default_config(schema_root: IConfigGroup) -> dict[object, object]:
    return dict(copy.deepcopy(schema_root.default_value))
