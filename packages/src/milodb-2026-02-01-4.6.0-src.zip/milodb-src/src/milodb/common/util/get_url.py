# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
def get_url_of_tease(tease_id: int) -> str:
    return f"https://milovana.com/webteases/showtease.php?id={tease_id}"

def get_url_of_author(author_id: int) -> str:
    return f"https://milovana.com/forum/memberlist.php?mode=viewprofile&u={author_id}"

def get_url_of_author_teases(author_id: int) -> str:
    return f"https://milovana.com/webteases/?author={author_id}"
