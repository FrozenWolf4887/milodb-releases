# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from abc import ABC, abstractmethod
from typing import override

class IRef[T](ABC):
    @abstractmethod
    def set(self, ref: T) -> None:
        pass

    @abstractmethod
    def get(self) -> T:
        pass

    @abstractmethod
    def __bool__(self) -> bool:
        pass

class SimpleRef[T](IRef[T]):
    def __init__(self, default: T) -> None:
        self._ref: T = default

    @override
    def set(self, ref: T) -> None:
        self._ref = ref

    @override
    def get(self) -> T:
        return self._ref

    @override
    def __bool__(self) -> bool:
        return bool(self._ref)
