# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from __future__ import annotations
import datetime
import re
from enum import Enum

_PARTIAL_DATE_FORMAT: str = "'yyyy' or 'yyyy-mm' or 'yyyy-mm-dd'"
_DATE_PATTERN: re.Pattern[str] = re.compile(r'(?P<year>\d{4})(-(?P<month>\d{1,2}))?(-(?P<day>\d{1,2}))?')

class PartialDate:
    class Granularity(Enum):
        HAS_YEAR = 1
        HAS_MONTH = 2
        HAS_DAY = 3

    def __init__(self, date: datetime.date, granularity: Granularity) -> None:
        self._base_date: datetime.date = date
        self._granularity: PartialDate.Granularity = granularity

    @property
    def granularity(self) -> Granularity:
        return self._granularity

    @property
    def base_date(self) -> datetime.date:
        return self._base_date

    @property
    def year(self) -> int:
        return self._base_date.year

    @property
    def month(self) -> int:
        return self._base_date.month

    @property
    def day(self) -> int:
        return self._base_date.day

    @staticmethod
    def parse(text: str) -> PartialDate:
        """Parse date from text or throw.

        ### Raises:
        - ValueError if the format is incorrect
        """
        match: re.Match[str] | None = _DATE_PATTERN.fullmatch(text)
        if not match:
            msg = f'expected format {_PARTIAL_DATE_FORMAT}'
            raise ValueError(msg)

        year_text: str = match.group('year')
        granularity: PartialDate.Granularity = PartialDate.Granularity.HAS_YEAR
        try:
            year: int = int(year_text)
        except ValueError as ex:
            msg = 'invalid year value'
            raise ValueError(msg) from ex

        month: int = 1
        day: int = 1

        month_text: str | None = match.group('month')
        if month_text:
            granularity = PartialDate.Granularity.HAS_MONTH
            try:
                month = int(month_text)
            except ValueError as ex:
                msg = 'invalid month value'
                raise ValueError(msg) from ex

            day_text: str | None = match.group('day')
            if day_text:
                granularity = PartialDate.Granularity.HAS_DAY
                try:
                    day = int(day_text)
                except ValueError as ex:
                    msg = 'invalid day value'
                    raise ValueError(msg) from ex

        date = datetime.date(year, month, day)

        return PartialDate(date, granularity)

    @staticmethod
    def is_eq(date: datetime.date, partial_date: PartialDate) -> bool:
        """Compare a date against a partial date.

        If datetime.date == PartialDate
        - date == 2000         (is-equivalent-to)   date >= 2000-01-01 and date < 2001-01-01
        - date == 2000-06      (is-equivalent-to)   date >= 2000-06-01 and date < 2000-07-01
        - date == 2000-12      (is-equivalent-to)   date >= 2000-12-01 and date < 2001-01-01
        - date == 2000-12-31   (is-equivalent-to)   date == 2000-12-31
        """
        match partial_date.granularity:
            case PartialDate.Granularity.HAS_YEAR:
                return date.year == partial_date.year
            case PartialDate.Granularity.HAS_MONTH:
                return date.year == partial_date.year and date.month == partial_date.month
            case PartialDate.Granularity.HAS_DAY:
                return date == partial_date.base_date

    @staticmethod
    def is_gt(date: datetime.date, partial_date: PartialDate) -> bool:
        """Compare a date against a partial date.

        If datetime.date > PartialDate
        - date > 2000         (is-equivalent-to)   date >= 2001-01-01
        - date > 2000-06      (is-equivalent-to)   date >= 2000-07-01
        - date > 2000-12      (is-equivalent-to)   date >= 2001-01-01
        - date > 2000-12-31   (is-equivalent-to)   date >  2000-12-31
        """
        match partial_date.granularity:
            case PartialDate.Granularity.HAS_YEAR:
                return date.year > partial_date.year
            case PartialDate.Granularity.HAS_MONTH:
                return date.year > partial_date.year or (date.year == partial_date.year and date.month > partial_date.month)
            case PartialDate.Granularity.HAS_DAY:
                return date > partial_date.base_date

    @staticmethod
    def is_lt(date: datetime.date, partial_date: PartialDate) -> bool:
        """Compare a date against a partial date.

        If datetime.date < PartialDate
        - date < 2000         (is-equivalent-to)   date <  2000-01-01
        - date < 2000-06      (is-equivalent-to)   date <  2000-06-01
        - date < 2000-12-31   (is-equivalent-to)   date <  2000-12-31
        """
        match partial_date.granularity:
            case PartialDate.Granularity.HAS_YEAR:
                return date.year < partial_date.year
            case PartialDate.Granularity.HAS_MONTH:
                return date.year < partial_date.year or (date.year == partial_date.year and date.month < partial_date.month)
            case PartialDate.Granularity.HAS_DAY:
                return date < partial_date.base_date

    @staticmethod
    def is_ge(date: datetime.date, partial_date: PartialDate) -> bool:
        """Compare a date against a partial date.

        If datetime.date >= PartialDate
        - date >= 2000         (is-equivalent-to)   date >= 2000-01-01
        - date >= 2000-12      (is-equivalent-to)   date >= 2000-12-01
        - date >= 2000-12-31   (is-equivalent-to)   date >= 2000-12-31
        """
        match partial_date.granularity:
            case PartialDate.Granularity.HAS_YEAR:
                return date.year >= partial_date.year
            case PartialDate.Granularity.HAS_MONTH:
                return date.year > partial_date.year or (date.year == partial_date.year and date.month >= partial_date.month)
            case PartialDate.Granularity.HAS_DAY:
                return date >= partial_date.base_date

    @staticmethod
    def is_le(date: datetime.date, partial_date: PartialDate) -> bool:
        """Compare a date against a partial date.

        If datetime.date >= PartialDate
        - date < 2000         (is-equivalent-to)   date < 2000-01-01
        - date < 2000-06      (is-equivalent-to)   date < 2000-06-01
        - date < 2000-12      (is-equivalent-to)   date < 2000-12-01
        - date < 2000-12-31   (is-equivalent-to)   date < 2000-12-31
        """
        match partial_date.granularity:
            case PartialDate.Granularity.HAS_YEAR:
                return date.year <= partial_date.year
            case PartialDate.Granularity.HAS_MONTH:
                return date.year < partial_date.year or (date.year == partial_date.year and date.month <= partial_date.month)
            case PartialDate.Granularity.HAS_DAY:
                return date <= partial_date.base_date
