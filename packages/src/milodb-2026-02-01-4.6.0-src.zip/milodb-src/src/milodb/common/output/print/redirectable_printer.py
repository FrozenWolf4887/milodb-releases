# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from typing import override
from milodb.common.output.print.i_printer import IPrinter, IRedirectablePrinter

class RedirectablePrinter(IRedirectablePrinter):
    def __init__(self, target_printer: IPrinter) -> None:
        self._target_printer: IPrinter = target_printer

    @override
    def get_target_printer(self) -> IPrinter:
        return self._target_printer

    @override
    def set_target_printer(self, target_printer: IPrinter) -> None:
        self._target_printer = target_printer
