# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from PIL import Image
from milodb.common.view.gui.metrics import Size

def resize_image_to_fit(thumbnail_image: Image.Image, fit_size: Size) -> Image.Image:
    image_width: int = thumbnail_image.width
    image_height: int = thumbnail_image.height

    if image_width <= 0 or image_height <= 0:
        return thumbnail_image

    need_to_resize: bool = (image_width != fit_size.width and image_height != fit_size.height) or \
                           (image_width == fit_size.width and image_height > fit_size.height) or \
                           (image_height == fit_size.height and image_width > fit_size.width)
    if not need_to_resize:
        return thumbnail_image

    landscape_size: Size = Size(fit_size.width, fit_size.width * image_height // image_width)
    portrait_size: Size = Size(fit_size.height * image_width // image_height, fit_size.height)

    new_size: Size = landscape_size if landscape_size.height <= fit_size.height else portrait_size
    return thumbnail_image.resize(new_size.to_tuple())
