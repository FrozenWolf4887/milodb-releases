# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from __future__ import annotations
from dataclasses import dataclass
from typing import NamedTuple, override

class Point(NamedTuple):
    x: float
    y: float

class RelPoint(NamedTuple):
    x: float | None = None
    y: float | None = None
    up: float | None = None
    down: float | None = None
    left: float | None = None
    right: float | None = None

    def relative_to(self, point: Point) -> Point:
        return Point(
            x = (point.x if self.x is None else self.x) + (self.right if self.right else 0) - (self.left if self.left else 0),
            y = (point.y if self.y is None else self.y) + (self.down if self.down else 0) - (self.up if self.up else 0),
        )

@dataclass
class Size:
    width: int
    height: int

    def to_tuple(self) -> tuple[int, int]:
        return (self.width, self.height)

    @override
    def __eq__(self, value: object) -> bool:
        if isinstance(value, Size):
            return value.width == self.width and value.height == self.height
        return False

    @override
    def __hash__(self) -> int:
        return hash((self.width, self.height))

    @override
    def __str__(self) -> str:
        return f'width: {self.width}, height: {self.height}'

@dataclass
class Padding:
    left: int
    top: int
    right: int
    bottom: int

    @property
    def width(self) -> int:
        return self.left + self.right

    @property
    def height(self) -> int:
        return  self.top + self.bottom

    @override
    def __str__(self) -> str:
        return f'left: {self.left}, top: {self.top}, right: {self.right}, bottom: {self.bottom}  ({self.width} x {self.height})'

Margin = Padding

@dataclass
class Spacing:
    horizontal: int
    vertical: int

class Bounds:
    def __init__(self, left: int, top: int, right: int, bottom: int) -> None:
        self._left: int = left
        self._top: int = top
        self._right: int = right
        self._bottom: int = bottom

    @property
    def left(self) -> int:
        return self._left

    @property
    def top(self) -> int:
        return self._top

    @property
    def right(self) -> int:
        return self._right

    @property
    def bottom(self) -> int:
        return self._bottom

    @property
    def width(self) -> int:
        return self.right - self.left

    @property
    def height(self) -> int:
        return  self.bottom - self.top

    @property
    def middle_x(self) -> int:
        return (self.left + self.right) // 2

    @property
    def middle_y(self) -> int:
        return (self.top + self.bottom) // 2

    @staticmethod
    def empty() -> MutableBounds:
        return MutableBounds(0, 0, 0, 0)

    def to_tuple(self) -> tuple[int, int, int, int]:
        return (self.left, self.top, self.right, self.bottom)

    @staticmethod
    def from_tuple(bounds: tuple[int, int, int, int] | None) -> MutableBounds:
        if bounds is not None:
            return MutableBounds(bounds[0], bounds[1], bounds[2], bounds[3])
        return MutableBounds.empty()

    @staticmethod
    def union(first: Bounds, second: Bounds) -> MutableBounds:
        return MutableBounds(
            left = min(first.left, second.left),
            top = min(first.top, second.top),
            right = max(first.right, second.right),
            bottom = max(first.bottom, second.bottom),
        )

    @override
    def __str__(self) -> str:
        return f'left: {self.left}, top: {self.top}, right: {self.right}, bottom: {self.bottom}  ({self.width} x {self.height})'

class MutableBounds(Bounds):
    def set_left(self, value: int) -> None:
        self._left = value

    def set_top(self, value: int) -> None:
        self._top = value

    def set_right(self, value: int) -> None:
        self._right = value

    def set_bottom(self, value: int) -> None:
        self._bottom = value

    def set_width(self, value: int) -> None:
        self._right = self._left + value

    def set_height(self, value: int) -> None:
        self._bottom = self._top + value

    def move_to(self, left: int, top: int) -> None:
        self._right += left - self.left
        self._bottom += top - self.top
        self._left = left
        self._top = top

    def resize(self, width: int, height: int) -> None:
        self._right = self._left + width
        self._bottom = self._top + height

    def translate(self, *, horizontal: int, vertical: int) -> None:
        self._left += horizontal
        self._right += horizontal
        self._top += vertical
        self._bottom += vertical
