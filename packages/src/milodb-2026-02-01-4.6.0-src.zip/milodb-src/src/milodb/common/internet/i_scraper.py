# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from abc import ABC, abstractmethod
from collections.abc import Callable
from dataclasses import dataclass
from types import TracebackType
from typing import Protocol

@dataclass
class ScrapeResult:
    error_message: str | None
    redirection_url: str | None
    content: bytes

class ScrapeProgressCallback(Protocol):
    def __call__(self, *, message: str | None, percentage_complete: int | None) -> None:
        pass

class IUrlScraper(ABC):
    @abstractmethod
    def try_scrape_url(self, url: str, progress_callback: ScrapeProgressCallback | None) -> ScrapeResult:
        pass

    @abstractmethod
    def close(self, close_callback: Callable[[str], None] | None) -> None:
        pass

class IPathScraper(ABC):
    @abstractmethod
    def try_scrape_path(self, filepath: str, progress_callback: ScrapeProgressCallback | None) -> ScrapeResult:
        pass

    @abstractmethod
    def close(self, close_callback: Callable[[str], None] | None) -> None:
        pass

class IUrlScraperPool:
    @abstractmethod
    def __enter__(self) -> IUrlScraper:
        pass

    @abstractmethod
    def __exit__(self, exc_type: type[BaseException] | None, exc_value: BaseException | None, traceback: TracebackType | None) -> None:
        pass

class IUrlScraperFactory(ABC):
    @abstractmethod
    def new_pool(self, close_callback: Callable[[str], None] | None = None) -> IUrlScraperPool:
        pass
