# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from collections.abc import Sequence
from dataclasses import dataclass, field
from milodb.common.parser.candidate_text import CandidateText
from milodb.common.parser.token import StartEnd, Token

@dataclass
class TokenStreamError(Exception):
    cause_of_fault_text: str
    fault_token: Token
    list_of_candidate_text: Sequence[CandidateText] = field(default_factory=list)

class TokenStream:
    DEFAULT_DISCARD_DELIMITERS: str = ' '
    DEFAULT_KEEP_DELIMITERS: str = ''

    def __init__(self, text: str, discard_delimiters: str | None = None, keep_delimiters: str | None = None, stop_before_character_index: int | None = None) -> None:
        self._text: str = text
        self._stop_before_character_index: int | None = stop_before_character_index

        self._index: int = 0
        self._discard_delimiters: str = discard_delimiters if discard_delimiters is not None else TokenStream.DEFAULT_DISCARD_DELIMITERS
        self._keep_delimiters: str = keep_delimiters if keep_delimiters is not None else TokenStream.DEFAULT_KEEP_DELIMITERS
        self._queued_tokens: list[Token] = []
        self._token_number: int = 0
        self._token_text: str = ""
        self._current_outer_start_index: int = 0
        self._current_inner_start_index: int = 0
        self._is_escaping: bool = False
        self._is_in_token: bool = False
        self._is_in_quoted_string: bool = False
        self._string_quote: str = ''
        self._expecting_delimiter: bool = False
        self._stopped_on_token: Token | None = None
        self._current_token: Token | None = None
        self._previous_token: Token | None = None

    def get_all_text(self) -> str:
        return self._text

    def next(self) -> Token | None:
        token: Token | None = None

        if not self._stopped_on_token:
            if self._queued_tokens:
                token = self._queued_tokens.pop(0)
            else:
                self._load_next_token()
                token = self._queued_tokens.pop(0) if self._queued_tokens else None

            if token and self._should_stop_on_token(token):
                self._stopped_on_token = token
                token = None

            self._current_token = token
            if self._current_token and not self._stopped_on_token:
                self._previous_token = self._current_token

        return token

    def get_remaining_raw_text(self) -> str:
        if self._previous_token:
            return self._text[self._previous_token.outer_indices.end:]
        return self._text

    def get_stopped_on_token(self) -> Token | None:
        return self._stopped_on_token

    def set_discard_delimiters(self, delimiters: str) -> None:
        self._discard_delimiters = delimiters

    def set_keep_delimiters(self, delimiters: str) -> None:
        self._keep_delimiters = delimiters

    def _load_next_token(self) -> None:
        while not self._queued_tokens and self._index < len(self._text):
            self._process_character(self._text[self._index])
            self._index += 1

        if not self._queued_tokens:
            if self._is_escaping:
                msg = 'Trailing escape character at end of text'
                raise TokenStreamError(msg, _make_empty_token(len(self._text)))

            if self._is_in_quoted_string:
                msg = 'String not terminated at end of text'
                raise TokenStreamError(msg, _make_empty_token(self._current_outer_start_index))

            if self._token_text:
                self._queue_token(self._token_text, StartEnd(self._current_outer_start_index, len(self._text)), StartEnd(self._current_outer_start_index, len(self._text)), is_delimiter=False)
                self._token_text = ""

    def _should_stop_on_token(self, token: Token) -> bool:
        return self._stop_before_character_index is not None and \
            ((not token.is_delimiter and token.outer_indices.end >= self._stop_before_character_index) or (token.is_delimiter and token.outer_indices.end > self._stop_before_character_index))

    def _process_character(self, char: str) -> None:
        if self._expecting_delimiter:
            if char not in self._discard_delimiters and char not in self._keep_delimiters:
                msg = 'Expecting delimiter'
                raise TokenStreamError(msg, _make_empty_token(self._index))
            self._expecting_delimiter = False

        if self._is_escaping:
            self._process_escaped_character(char)
        else:
            self._process_non_escaped_character(char)

    def _process_escaped_character(self, char: str) -> None:
        if char in {'"', "'"}:
            self._token_text += char
        else:
            self._token_text += '\\' + char

        if not self._is_in_token:
            self._is_in_token = True
            self._current_outer_start_index = self._index - 1

        self._is_escaping = False

    def _process_non_escaped_character(self, char: str) -> None:
        if char == '\\':
            self._is_escaping = True
        elif self._is_in_quoted_string:
            self._process_character_in_string(char)
        else:
            self._process_character_out_of_string(char)

    def _process_character_in_string(self, char: str) -> None:
        if char == self._string_quote:
            self._is_in_quoted_string = False
            self._queue_token(self._token_text, StartEnd(self._current_outer_start_index, self._index + 1), StartEnd(self._current_outer_start_index + 1, self._index), is_delimiter=False)
            self._expecting_delimiter = True
        else:
            self._token_text += char

    def _process_character_out_of_string(self, char: str) -> None:
        if char in {'"', "'"}:
            self._is_in_quoted_string = True
            self._string_quote = char
            self._is_in_token = True
            self._current_outer_start_index = self._index
        elif char in self._discard_delimiters or char in self._keep_delimiters:
            if self._token_text:
                self._queue_token(self._token_text, StartEnd(self._current_outer_start_index, self._index), StartEnd(self._current_outer_start_index, self._index), is_delimiter=False)
            if char in self._keep_delimiters:
                self._queue_token(char, StartEnd(self._index, self._index + 1), StartEnd(self._index, self._index + 1), is_delimiter=True)
        else:
            if not self._is_in_token:
                self._is_in_token = True
                self._current_outer_start_index = self._index
            self._token_text += char

    def _queue_token(self, text: str, outer_indices: StartEnd, inner_indices: StartEnd, *, is_delimiter: bool) -> None:
        token = Token(text, self._token_number, outer_indices, inner_indices, is_delimiter=is_delimiter)
        self._queued_tokens.append(token)
        self._token_number += 1
        self._token_text = ""
        self._is_in_token = False

def _make_empty_token(char_offset: int) -> Token:
    indices: StartEnd = StartEnd(char_offset, char_offset)
    return Token(
        text = '',
        token_number = -1,
        outer_indices = indices,
        inner_indices = indices,
        is_delimiter = False,
    )
