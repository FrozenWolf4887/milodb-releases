# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import tkinter as tk
from abc import ABC, abstractmethod
from collections import Counter
from tkinter import ttk
from typing import override
from milodb.client.view.gui import general_layout
from milodb.client.view.gui.dialogs.log_dialog import LogDialog
from milodb.client.view.gui.dialogs.modal_dialog import ModalDialog
from milodb.client.view.gui.theme import Style
from milodb.client.view.gui.util.datum import Datum, IValueDatum
from milodb.client.view.gui.util.datum_tk_binding import DatumBoolTkBinding
from milodb.client.view.gui.widgets.scrollable_frame import ScrollableFrame
from milodb.client.view.gui.widgets.styled_frame import StyledFrame
from milodb.client.view.gui.widgets.styled_option_menu import StyledOptionMenu
from milodb.client.view.gui.widgets.text_ex import TextEx
from milodb.client.view.gui.widgets.wrapped_text import WrappedText
from milodb.client.view.gui.widgets.wrapping_label import WrappingLabel
from milodb.common.config.framework import IConfig, IConfigGroup, IConfigLeaf, IConfigSetLeaf, IPersistentConfig
from milodb.common.output.print.i_printer import IPrinter
from milodb.common.variables.i_user_variables import IPersistentUserVariables, VARIABLE_NAME_PATTERN

_LAYOUT_PADDING_X: int = general_layout.PANEL_PADDING_X
_LAYOUT_PADDING_Y: int = general_layout.PANEL_PADDING_Y
_TABLE_GRIDLINE_THICKNESS: int = 1
_DEPTH_INDENT_AMOUNT: int = 6

_CANCEL_BUTTON_COLUMN: int = 0
_SAVE_BUTTON_COLUMN: int = 1

class ConfigDialog(ModalDialog):
    def __init__(self, master: tk.Toplevel | tk.Tk, config: IPersistentConfig, config_schema: IConfigGroup, variables: IPersistentUserVariables, variables_changed_event: Datum, debug_enabled_ref: IValueDatum[bool]) -> None:
        super().__init__(master, width=800, title='Configuration')
        self._config: IPersistentConfig = config
        self._config_schema: IConfigGroup = config_schema
        self._variables: IPersistentUserVariables = variables
        self._variables_changed_event: Datum = variables_changed_event
        self._debug_enabled_ref: IValueDatum[bool] = debug_enabled_ref

        self._list_of_datum_tk_bindings: list[DatumBoolTkBinding] = []

        notebook: ttk.Notebook = ttk.Notebook(self.content_frame)
        notebook.pack(fill=tk.BOTH, expand=True)
        persistent_frame: tk.Widget = self._create_general_frame(notebook)
        variables_frame: tk.Widget = self._create_variables_frame(notebook)
        transient_frame: tk.Widget = self._create_diagnostic_frame(notebook)
        notebook.add(persistent_frame, text='General')
        notebook.add(variables_frame, text='Variables')
        notebook.add(transient_frame, text='Diagnostic')

        self.add_button('Cancel', column=_CANCEL_BUTTON_COLUMN, command=self.destroy)
        self.add_button('Save', column=_SAVE_BUTTON_COLUMN, command=self._on_save)

    @override
    def destroy(self) -> None:
        binding: DatumBoolTkBinding
        for binding in self._list_of_datum_tk_bindings:
            binding.destroy()
        super().destroy()

    def _create_general_frame(self, master: tk.Misc) -> tk.Widget:
        frame: ScrollableFrame = ScrollableFrame(master, frame_style=Style.Generic.TableFrame.STYLE_NAME)

        ttk.Label(frame.content_frame, text='Config Item', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.HeaderLabel.STYLE_NAME).grid(row=0, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
        ttk.Label(frame.content_frame, text='Value', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.HeaderLabel.STYLE_NAME).grid(row=0, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
        ttk.Label(frame.content_frame, text='Status', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.HeaderLabel.STYLE_NAME).grid(row=0, column=2, columnspan=2, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)

        frame.content_frame.columnconfigure(1, weight=1)

        self._list_of_leaf_viewers: list[_LeafViewer] = []
        self._populate_rows(frame.content_frame, 1, 0, self._config_schema)
        frame.set_child_bindtags_for_scrolling()

        return frame.top_frame

    def _create_diagnostic_frame(self, master: tk.Misc) -> tk.Widget:
        outer_frame: StyledFrame = StyledFrame(master)

        WrappingLabel(outer_frame, text="These settings do not persist when the application is closed.").pack(fill=tk.X)

        scroll_frame: ScrollableFrame = ScrollableFrame(outer_frame, frame_style=Style.Generic.TableFrame.STYLE_NAME)
        scroll_frame.top_frame.pack(fill=tk.BOTH, expand=True)
        scroll_frame.content_frame.columnconfigure(1, weight=1)

        frame: StyledFrame = scroll_frame.content_frame

        ttk.Label(frame, text='Setting', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.HeaderLabel.STYLE_NAME).grid(row=0, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
        ttk.Label(frame, text='Description', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.HeaderLabel.STYLE_NAME).grid(row=0, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)

        debug_launch: tk.BooleanVar = tk.BooleanVar(frame, value=self._debug_enabled_ref.get())
        ttk.Checkbutton(frame, text='Debug launch', variable=debug_launch, style=Style.InTable.Checkbox.STYLE_NAME).grid(row=1, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
        WrappingLabel(frame, text=(
                'When opening a tease, author profile, or author tease list,'
                ' a dialog will typically popup and disappear if the launch was successful.'
                ' Setting this flag will display additional information about the launch attempt'
                ' and leave the dialog open.'
            ), anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=1, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
        self._list_of_datum_tk_bindings.append(DatumBoolTkBinding(self._debug_enabled_ref, debug_launch, on_change_callback=None))

        scroll_frame.set_child_bindtags_for_scrolling()

        return outer_frame

    def _create_variables_frame(self, master: tk.Misc) -> tk.Widget:
        outer_frame: StyledFrame = StyledFrame(master)

        WrappingLabel(outer_frame, text="Variables can be used in query expressions as a shortcut. They are prefixed with a '$' and expand in-place.").pack(fill=tk.X)

        self._variables_scroll_frame: ScrollableFrame = ScrollableFrame(outer_frame, frame_style=Style.Generic.TableFrame.STYLE_NAME)
        self._variables_scroll_frame.top_frame.pack(fill=tk.BOTH, expand=True)
        self._variables_scroll_frame.content_frame.columnconfigure(2, weight=1)

        self._variables_frame: StyledFrame = self._variables_scroll_frame.content_frame

        ttk.Label(self._variables_frame, text='Status', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.HeaderLabel.STYLE_NAME).grid(row=0, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
        ttk.Label(self._variables_frame, text='Name', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.HeaderLabel.STYLE_NAME).grid(row=0, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
        ttk.Label(self._variables_frame, text='Value', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.HeaderLabel.STYLE_NAME).grid(row=0, column=2, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
        ttk.Label(self._variables_frame, text='Status', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.HeaderLabel.STYLE_NAME).grid(row=0, column=3, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)

        self._list_of_variable_editors: list[_VariableEditor] = [
            _VariableEditor(variable_name, self._variables, self._variables_frame, row=index+1)
                for index, variable_name in enumerate(self._variables.get_list_of_names())
        ]

        button_frame: StyledFrame = StyledFrame(outer_frame, style=Style.Generic.PanelFrame.STYLE_NAME)
        button_frame.pack(side=tk.LEFT)
        ttk.Button(button_frame, text='Delete', takefocus=False, command=self._on_variable_delete).grid(column=0, row=0, padx=_LAYOUT_PADDING_X, pady=_LAYOUT_PADDING_Y)
        ttk.Button(button_frame, text='New', takefocus=False, command=self._on_variable_new).grid(column=1, row=0, padx=_LAYOUT_PADDING_X, pady=_LAYOUT_PADDING_Y)

        self._variables_scroll_frame.set_child_bindtags_for_scrolling()

        return outer_frame

    def _populate_rows(self, master: tk.Misc, row: int, depth: int, config_group: IConfigGroup) -> int:
        indent: str = ' ' * (depth * _DEPTH_INDENT_AMOUNT)
        config_leaf: IConfigLeaf
        for config_leaf in config_group.list_of_child_leaves:
            ttk.Label(master, text=f'{indent}{config_leaf.key_name}', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME).grid(row=row, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            self._add_row_leaf(master, config_leaf, row=row)
            row += 1
        config_subgroup: IConfigGroup
        for config_subgroup in config_group.list_of_child_groups:
            ttk.Label(master, text=f'{indent}{config_subgroup.key_name}', anchor=tk.W, justify=tk.LEFT, style=Style.InTable.SubHeaderLabel.STYLE_NAME).grid(row=row, column=0, columnspan=4, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            row = self._populate_rows(master, row + 1, depth + 1, config_subgroup)
        return row

    def _add_row_leaf(self, master: tk.Misc, config_leaf: IConfigLeaf, *, row: int) -> None:
        viewer: _LeafViewer
        if config_leaf.is_protected:
            viewer = _ProtectedLeafViewer(config_leaf, self._config, master, row=row)
        elif isinstance(config_leaf, IConfigSetLeaf):
            viewer = _SetLeafEditor(config_leaf, self._config, master, row=row)
        else:
            viewer = _TextLeafEditor(config_leaf, self._config, master, row=row)
        self._list_of_leaf_viewers.append(viewer)

    def _on_variable_delete(self) -> None:
        deleted_index: int

        index: int
        editor: _VariableEditor
        for index, editor in enumerate(self._list_of_variable_editors):
            if editor.has_focus:
                deleted_index = index
                break
        else:
            return

        self._list_of_variable_editors.pop(deleted_index).destroy()

        for index in range(deleted_index, len(self._list_of_variable_editors)):
            editor = self._list_of_variable_editors[index]
            editor.change_row(index + 1)

    def _on_variable_new(self) -> None:
        index: int
        editor: _VariableEditor
        for index, editor in enumerate(self._list_of_variable_editors):
            editor.change_row(index + 2)

        set_of_existing_names: set[str] = { editor.new_name for editor in self._list_of_variable_editors }
        next_name: str
        next_name_index: int = 1
        while (next_name := f'new{next_name_index}') in set_of_existing_names:
            next_name_index += 1

        editor = _VariableEditor(next_name, self._variables, self._variables_frame, row=1)
        self._list_of_variable_editors.insert(0, editor)
        editor.focus_value()
        self._variables_scroll_frame.reset_scroll()

    def _on_save(self) -> None:
        log_dialog: LogDialog = LogDialog(self, title='Save Configuration')

        if self._validate_variables(log_dialog.log_text.normal_printer, log_dialog.log_text.error_printer):
            log_dialog.log_text.normal_printer.writeln('Saving config file')

            viewer: _LeafViewer
            for viewer in self._list_of_leaf_viewers:
                if isinstance(viewer, _LeafEditor):
                    viewer.save_value()
            self._config.save(log_dialog.log_text.normal_printer, log_dialog.log_text.warning_printer, log_dialog.log_text.error_printer)

            log_dialog.log_text.normal_printer.writeln('Saving variables file')

            self._variables.delete_all()
            editor: _VariableEditor
            for editor in self._list_of_variable_editors:
                name: str = editor.new_name
                if name:
                    self._variables.set(name, editor.new_value)
            self._variables.save(log_dialog.log_text.normal_printer, log_dialog.log_text.warning_printer, log_dialog.log_text.error_printer)

            self._variables_changed_event.notify()

        if log_dialog.log_text.any_warnings_or_errors:
            log_dialog.show_okay_button()
        else:
            log_dialog.destroy()
            self.destroy()

    def _validate_variables(self, normal_printer: IPrinter, error_printer: IPrinter) -> bool:
        all_valid: bool = True

        normal_printer.writeln('Checking variables')

        editor: _VariableEditor
        for editor in self._list_of_variable_editors:
            name: str = editor.new_name
            if name and not VARIABLE_NAME_PATTERN.fullmatch(name):
                all_valid = False
                error_printer.writeln(f"Variable name '{name}' does not match pattern {VARIABLE_NAME_PATTERN.pattern}")

        occurrences: int
        for name, occurrences in Counter(editor.new_name for editor in self._list_of_variable_editors).items():
            if occurrences > 1:
                all_valid = False
                error_printer.writeln(f"Variable name '{name}' occurs {occurrences} times")

        if any(editor.new_name == '' and editor.new_value != '' for editor in self._list_of_variable_editors):
            all_valid = False
            error_printer.writeln('At least one variable has a blank name')

        return all_valid

class _LeafViewer(ABC):
    @abstractmethod
    def get_value(self) -> str:
        pass

class _ProtectedLeafViewer(_LeafViewer):
    def __init__(self, config_leaf: IConfigLeaf, config: IConfig, parent: tk.Misc, *, row: int) -> None:
        self._text: str = config_leaf.fetch_value_or_default(config)
        self._label: WrappingLabel = WrappingLabel(parent, text=self._text, anchor=tk.W, justify=tk.LEFT, style=Style.InTable.ValueLabel.STYLE_NAME)
        self._label.grid(row=row, column=1, columnspan=3, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)

    @override
    def get_value(self) -> str:
        return self._text

class _LeafEditor(_LeafViewer):
    def __init__(self, config_leaf: IConfigLeaf, config: IPersistentConfig, parent: tk.Misc, *, row: int) -> None:
        self._config_leaf: IConfigLeaf = config_leaf
        self._config: IPersistentConfig = config

        cell_frame: StyledFrame = StyledFrame(parent, style=Style.InTable.CellFrame.STYLE_NAME)
        cell_frame.grid(row=row, column=2, columnspan=2, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)

        self._revert_button: ttk.Button = ttk.Button(parent, text='Revert', command=self._on_revert)
        self._revert_button.grid(row=row, column=2, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS)
        self._reset_button: ttk.Button = ttk.Button(parent, text='Reset', command=self._on_reset)
        self._reset_button.grid(row=row, column=3, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS)

    def save_value(self) -> None:
        text: str = self.get_value()
        self._config_leaf.try_set_value(self._config, text)

    @abstractmethod
    def _replace_value_and_focus(self, text: str) -> None:
        pass

    def _on_revert(self) -> None:
        text: str = self._config_leaf.fetch_value_or_default(self._config)
        self._replace_value_and_focus(text)
        self._revert_button.grid_remove()
        self._update_reset_button(text)

    def _on_reset(self) -> None:
        text: str = self._config_leaf.default_value
        self._replace_value_and_focus(text)
        self._reset_button.grid_remove()
        self._update_revert_button(text)

    def _update_revert_button(self, text: str) -> None:
        if text == self._config_leaf.fetch_value_or_default(self._config):
            self._revert_button.grid_remove()
        else:
            self._revert_button.grid()

    def _update_reset_button(self, text: str) -> None:
        if text == self._config_leaf.default_value:
            self._reset_button.grid_remove()
        else:
            self._reset_button.grid()

class _TextLeafEditor(_LeafEditor):
    def __init__(self, config_leaf: IConfigLeaf, config: IPersistentConfig, parent: tk.Misc, *, row: int) -> None:
        super().__init__(config_leaf, config, parent, row=row)

        value: str = self._config_leaf.fetch_value_or_default(self._config)

        self._text_widget: WrappedText = WrappedText(parent, style=Style.InTable.EditableText.STYLE_NAME)
        self._text_widget.grid(row=row, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
        self._text_widget.insert('1.0', value)
        self._text_widget.bind(WrappedText.TEXT_CHANGED_BINDING, lambda _event: self._on_value_changed())

        self._update_revert_button(value)
        self._update_reset_button(value)

    @override
    def get_value(self) -> str:
        return self._text_widget.get('1.0', tk.END)[:-1]

    @override
    def _replace_value_and_focus(self, text: str) -> None:
        self._text_widget.delete('1.0', tk.END)
        self._text_widget.insert('1.0', text)
        self._text_widget.focus()

    def _on_value_changed(self) -> None:
        text: str = self._text_widget.get('1.0', tk.END)[:-1]
        self._update_revert_button(text)
        self._update_reset_button(text)

class _SetLeafEditor(_LeafEditor):
    def __init__(self, config_leaf: IConfigSetLeaf, config: IPersistentConfig, parent: tk.Misc, *, row: int) -> None:
        super().__init__(config_leaf, config, parent, row=row)

        value: str = config_leaf.fetch_value_or_default(self._config)

        self._text_variable: tk.StringVar = tk.StringVar(parent)
        self._choice_widget: StyledOptionMenu = StyledOptionMenu(parent, self._text_variable, default_value=value, list_of_values=config_leaf.list_of_values, style=Style.InTable.OptionMenu.STYLE_NAME, command=lambda _variable: self._on_value_changed())
        self._choice_widget.grid(row=row, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)

        self._update_revert_button(value)
        self._update_reset_button(value)

    @override
    def get_value(self) -> str:
        return self._text_variable.get()

    @override
    def _replace_value_and_focus(self, text: str) -> None:
        self._text_variable.set(text)
        self._choice_widget.focus()

    def _on_value_changed(self) -> None:
        text: str = self._text_variable.get()
        self._update_revert_button(text)
        self._update_reset_button(text)

class _VariableEditor:
    def __init__(self, variable_name: str, variables: IPersistentUserVariables, parent: tk.Misc, *, row: int) -> None:
        self._variable_name: str = variable_name
        self._variables: IPersistentUserVariables = variables

        StyledFrame(parent, style=Style.InTable.CellFrame.STYLE_NAME).grid(row=row, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
        self._name_revert_button: ttk.Button = ttk.Button(parent, text='Revert', command=self._on_revert_name)
        self._name_revert_button.grid(row=row, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.EW)
        self._name_revert_button.grid_remove()

        self._name_widget: TextEx = TextEx(parent, style=Style.InTable.EditableText.STYLE_NAME, width=20)
        self._name_widget.grid(row=row, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
        self._name_widget.insert('1.0', self._variable_name)
        self._name_widget.bind(TextEx.TEXT_CHANGED_BINDING, lambda _event: self._on_name_changed())

        self._value_widget: WrappedText = WrappedText(parent, style=Style.InTable.EditableText.STYLE_NAME)
        self._value_widget.grid(row=row, column=2, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
        self._value_widget.insert('1.0', self.old_value)
        self._value_widget.bind(WrappedText.TEXT_CHANGED_BINDING, lambda _event: self._on_value_changed())

        StyledFrame(parent, style=Style.InTable.CellFrame.STYLE_NAME).grid(row=row, column=3, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
        self._value_revert_button: ttk.Button = ttk.Button(parent, text='Revert', command=self._on_revert_value)
        self._value_revert_button.grid(row=row, column=3, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.EW)
        self._value_revert_button.grid_remove()

    @property
    def old_name(self) -> str:
        return self._variable_name

    @property
    def new_name(self) -> str:
        return self._name_widget.get_text()

    @property
    def old_value(self) -> str:
        return self._variables.try_retrieve(self._variable_name) or ''

    @property
    def new_value(self) -> str:
        return self._value_widget.get('1.0', tk.END)[:-1]

    @property
    def has_focus(self) -> bool:
        return self._name_widget.focus_get() in (self._name_widget, self._value_widget)

    def focus_value(self) -> None:
        self._value_widget.focus()

    def change_row(self, row: int) -> None:
        is_name_revert_button_visible: bool = self._name_revert_button.winfo_ismapped()
        is_value_revert_button_visible: bool = self._value_revert_button.winfo_ismapped()

        self._name_revert_button.grid(row=row)
        if not is_name_revert_button_visible:
            self._name_revert_button.grid_remove()
        self._name_widget.grid(row=row)
        self._value_widget.grid(row=row)
        self._value_revert_button.grid(row=row)
        if not is_value_revert_button_visible:
            self._value_revert_button.grid_remove()

    def destroy(self) -> None:
        self._name_revert_button.destroy()
        self._name_widget.destroy()
        self._value_widget.destroy()
        self._value_revert_button.destroy()

    def _on_revert_name(self) -> None:
        self._name_widget.delete('1.0', tk.END)
        self._name_widget.insert('1.0', self._variable_name)
        self._name_widget.focus()
        self._name_revert_button.grid_remove()

    def _on_revert_value(self) -> None:
        text: str = self._variables.try_retrieve(self._variable_name) or ''
        self._value_widget.delete('1.0', tk.END)
        self._value_widget.insert('1.0', text)
        self._value_widget.focus()
        self._value_revert_button.grid_remove()

    def _on_name_changed(self) -> None:
        if self.new_name == self.old_name:
            self._name_revert_button.grid_remove()
        else:
            self._name_revert_button.grid()

    def _on_value_changed(self) -> None:
        if self.new_value == self.old_value:
            self._value_revert_button.grid_remove()
        else:
            self._value_revert_button.grid()
