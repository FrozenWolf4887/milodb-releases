# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import tkinter as tk
from milodb.client.view.gui.field_validator import FieldStatus, IFieldValidator

class CommandGenerator:
    def __init__(self, command_text: tk.Text, list_of_field_validators: list[IFieldValidator]) -> None:
        self._command_text: tk.Text = command_text
        self._list_of_field_validators: list[IFieldValidator] = list_of_field_validators

        field_validator: IFieldValidator
        for field_validator in list_of_field_validators:
            field_validator.add_callback(self._on_field_modified)

    def _on_field_modified(self, _origin_field_validator: IFieldValidator) -> None:
        new_command: str = ''

        field_validator: IFieldValidator
        for field_validator in self._list_of_field_validators:
            if field_validator.status != FieldStatus.INACTIVE:
                if new_command:
                    new_command += ' and '
                new_command += f'{field_validator.field_name} {field_validator.verb_value} '
                text: str = field_validator.entry_widget.get_text()
                new_command += self._quote_if_required(text)

        if new_command:
            new_command = 'query ' + new_command

        self._command_text.config(state='normal')
        self._command_text.delete('1.0', tk.END)
        self._command_text.insert('1.0', new_command)
        self._command_text.config(state='disabled')

    @staticmethod
    def _quote_if_required(text: str) -> str:
        if ' ' in text or '(' in text or ')' in text or "'" in text or '"' in text:
            if '"' not in text:
                text = f'"{text}"'
            elif "'" not in text:
                text = f"'{text}'"
            else:
                text = text.replace("'", "\\'")
                text = f"'{text}'"
        return text
