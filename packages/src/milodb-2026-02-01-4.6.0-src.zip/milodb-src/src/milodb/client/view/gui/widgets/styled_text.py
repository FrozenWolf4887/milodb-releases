# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import tkinter as tk
from typing import Literal
from milodb.client.view.gui.theme import Style, apply_text_style
from milodb.client.view.gui.util import tk_type

class StyledText(tk.Text):
    DISPLAY_LINE_COUNT_CHANGED_BINDING: str = '<<DisplayLineCountChanged>>'
    CONTENT_LINE_COUNT_CHANGED_BINDING: str = '<<ContentLineCountChanged>>'

    def __init__(
            self, master: tk.Misc,
            style: str = Style.Generic.Text.STYLE_NAME,
            *,
            line_count: int | Literal['dynamic'],
            max_line_count: int | None = None,
            disable_for_scrolling: bool = False,
            autoseparators: bool = True,
            endline: int | Literal[''] = '',
            exportselection: bool = True,
            maxundo: int = 0,
            name: str = '',
            setgrid: bool = False,
            startline: int | Literal[''] = '',
            state: Literal['normal', 'disabled'] = tk.NORMAL,
            tabs: tk_type.ScreenUnits | tuple[tk_type.ScreenUnits, ...] = '',
            tabstyle: Literal['tabular', 'wordprocessor'] = 'tabular',
            takefocus: tk_type.TakeFocusValue = '',
            undo: bool = False,
            width: int = 80,
            wrap: Literal['none', 'char', 'word'] = tk.CHAR,
            xscrollcommand: tk_type.XYScrollCommand = '',
            yscrollcommand: tk_type.XYScrollCommand = '',
        ) -> None:
        if line_count == 'dynamic':
            auto_adjust_height: bool = True
            self._current_display_line_count: int = 0
            self._current_content_line_count: int = 0
        else:
            auto_adjust_height = False
            self._current_display_line_count = line_count
            self._current_content_line_count = 0
        self._max_line_count: int | None = max_line_count

        super().__init__(
            master,
            autoseparators = autoseparators,
            endline = endline,
            exportselection = exportselection,
            height = self._current_display_line_count,
            maxundo = maxundo,
            name = name,
            setgrid = setgrid,
            startline = startline,
            state = state,
            tabs = tabs,
            tabstyle = tabstyle,
            takefocus = takefocus,
            undo = undo,
            width = width,
            wrap = wrap,
            xscrollcommand = xscrollcommand,
            yscrollcommand = yscrollcommand,
        )

        if disable_for_scrolling:
            self.bindtags((str(self), str(master), tk.ALL))
            self.config(state=tk.DISABLED, cursor='')

        self._style_name: str = style
        self._change_theme_event_id: str | None = None
        self._suppress_on_size_changed: bool = False

        apply_text_style(self, self._style_name)
        self.bind('<<ThemeChanged>>', self._on_theme_changed)

        self.event_add(self.DISPLAY_LINE_COUNT_CHANGED_BINDING, 'None')
        self.event_add(self.CONTENT_LINE_COUNT_CHANGED_BINDING, 'None')

        if auto_adjust_height:
            self.bind('<Configure>', self._on_size_changed)

    @property
    def display_line_count(self) -> int:
        return self._current_display_line_count

    @property
    def content_line_count(self) -> int:
        return self._current_content_line_count

    @property
    def max_line_count(self) -> int | None:
        return self._max_line_count

    def update_height_to_fit_text(self) -> None:
        self._on_size_changed(None)

    def _on_theme_changed(self, _event: object) -> None:
        if self._change_theme_event_id is None:
            self._change_theme_event_id = self.after_idle(self._on_idle_update_theme)

    def _on_idle_update_theme(self) -> None:
        self._change_theme_event_id = None
        apply_text_style(self, self._style_name)

    def _on_size_changed(self, _: object) -> None:
        if self._suppress_on_size_changed:
            return
        content_line_count: int | None = self.count('1.0', tk.END, 'displaylines', 'update')
        if content_line_count is None:
            return

        if self._current_content_line_count != content_line_count:
            self._current_content_line_count = content_line_count
            self.event_generate(self.CONTENT_LINE_COUNT_CHANGED_BINDING)

        display_line_count: int = min(content_line_count, self._max_line_count) if self._max_line_count else content_line_count
        if self._current_display_line_count != display_line_count:
            self._current_display_line_count = display_line_count
            self._suppress_on_size_changed = True
            self.config(height=display_line_count)
            self._suppress_on_size_changed = False
            self.event_generate(self.DISPLAY_LINE_COUNT_CHANGED_BINDING)
