# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from __future__ import annotations
from abc import abstractmethod
from collections.abc import Callable
from dataclasses import dataclass
from typing import Protocol, override
from milodb.common.util.ref import IRef

class NewValueCall[T](Protocol):
    def __call__(self, new_value: T) -> None:
        pass

class ChangedValueCall[T](Protocol):
    def __call__(self, *, old_value: T, new_value: T) -> None:
        pass

class IDatum:
    @abstractmethod
    def add_listener(self, listener: Callable[[], None], *, call_immediately: bool=False) -> None:
        pass

    @abstractmethod
    def remove_listener(self, listener: Callable[[], None]) -> None:
        pass

class IValueDatum[T](IDatum, IRef[T]):
    @abstractmethod
    def add_new_value_listener(self, listener: NewValueCall[T], *, call_immediately: bool=False) -> None:
        pass

    @abstractmethod
    def add_changed_value_listener(self, listener: ChangedValueCall[T], *, call_immediately: bool=False) -> None:
        pass

    @abstractmethod
    @override
    def remove_listener(self, listener: _Callback[T]) -> None:
        pass

class Datum(IDatum):
    def __init__(self) -> None:
        self._list_of_listeners: list[Callable[[], None]] = []

    @override
    def add_listener(self, listener: Callable[[], None], *, call_immediately: bool=False) -> None:
        self._list_of_listeners.append(listener)
        if call_immediately:
            listener()

    @override
    def remove_listener(self, listener: Callable[[], None]) -> None:
        self._list_of_listeners.remove(listener)

    def notify(self) -> None:
        listener: Callable[[], None]
        for listener in self._list_of_listeners:
            listener()

class ValueDatum[T](IValueDatum[T]):
    def __init__(self, default: T) -> None:
        self._ref: T = default
        self._list_of_listeners: list[_CallbackWrapper[T]] = []

    @override
    def set(self, ref: T) -> None:
        if self._ref != ref:
            previous_ref: T = self._ref
            self._ref = ref
            listener: _CallbackWrapper[T]
            for listener in self._list_of_listeners:
                match listener:
                    case _BasicCallbackWrapper():
                        listener.callback()
                    case _NewValueCallbackWrapper():
                        listener.callback(self._ref)
                    case _ChangedValueCallbackWrapper():
                        listener.callback(old_value=previous_ref, new_value=self._ref)

    @override
    def get(self) -> T:
        return self._ref

    @override
    def __bool__(self) -> bool:
        return bool(self._ref)

    @override
    def add_listener(self, listener: Callable[[], None], *, call_immediately: bool=False) -> None:
        self._list_of_listeners.append(_BasicCallbackWrapper(listener))
        if call_immediately:
            listener()

    @override
    def add_new_value_listener(self, listener: NewValueCall[T], *, call_immediately: bool=False) -> None:
        self._list_of_listeners.append(_NewValueCallbackWrapper(listener))
        if call_immediately:
            listener(self._ref)

    @override
    def add_changed_value_listener(self, listener: ChangedValueCall[T], *, call_immediately: bool=False) -> None:
        self._list_of_listeners.append(_ChangedValueCallbackWrapper(listener))
        if call_immediately:
            listener(old_value=self._ref, new_value=self._ref)

    @override
    def remove_listener(self, listener: _Callback[T]) -> None:
        self._list_of_listeners = [
            callback_wrapper for callback_wrapper in self._list_of_listeners if callback_wrapper.callback is not listener
        ]

class SuppressingDatum[T](IValueDatum[T]):
    def __init__(self, proxy_datum: IValueDatum[T]) -> None:
        self._proxy_datum: IValueDatum[T] = proxy_datum
        self._is_observing_proxy: bool = False
        self._list_of_listeners: list[_CallbackWrapper[T]] = []
        self._suppress_callbacks: bool = False

    @override
    def set(self, ref: T) -> None:
        self._suppress_callbacks = True
        self._proxy_datum.set(ref)
        self._suppress_callbacks = False

    @override
    def get(self) -> T:
        return self._proxy_datum.get()

    @override
    def __bool__(self) -> bool:
        return bool(self._proxy_datum)

    @override
    def add_listener(self, listener: Callable[[], None], *, call_immediately: bool=False) -> None:
        self._list_of_listeners.append(_BasicCallbackWrapper(listener))
        if not self._is_observing_proxy:
            self._proxy_datum.add_changed_value_listener(self._on_proxy_value_changed)
            self._is_observing_proxy = True
        if call_immediately:
            listener()

    @override
    def add_new_value_listener(self, listener: NewValueCall[T], *, call_immediately: bool=False) -> None:
        self._list_of_listeners.append(_NewValueCallbackWrapper(listener))
        if not self._is_observing_proxy:
            self._proxy_datum.add_changed_value_listener(self._on_proxy_value_changed)
            self._is_observing_proxy = True
        if call_immediately:
            listener(self._proxy_datum.get())

    @override
    def add_changed_value_listener(self, listener: ChangedValueCall[T], *, call_immediately: bool=False) -> None:
        self._list_of_listeners.append(_ChangedValueCallbackWrapper(listener))
        if not self._is_observing_proxy:
            self._proxy_datum.add_changed_value_listener(self._on_proxy_value_changed)
            self._is_observing_proxy = True
        if call_immediately:
            value: T = self._proxy_datum.get()
            listener(old_value=value, new_value=value)

    @override
    def remove_listener(self, listener: _Callback[T]) -> None:
        self._list_of_listeners = [
            existing_listener for existing_listener in self._list_of_listeners if existing_listener.callback is not listener
        ]
        if not self._list_of_listeners and self._is_observing_proxy:
            self._proxy_datum.remove_listener(self._on_proxy_value_changed)
            self._is_observing_proxy = False

    def _on_proxy_value_changed(self, old_value: T, new_value: T) -> None:
        if not self._suppress_callbacks:
            listener: _CallbackWrapper[T]
            for listener in self._list_of_listeners:
                match listener:
                    case _BasicCallbackWrapper():
                        listener.callback()
                    case _NewValueCallbackWrapper():
                        listener.callback(new_value)
                    case _ChangedValueCallbackWrapper():
                        listener.callback(old_value=old_value, new_value=new_value)

@dataclass
class _BasicCallbackWrapper:
    callback: Callable[[], None]

@dataclass
class _NewValueCallbackWrapper[T]:
    callback: NewValueCall[T]

@dataclass
class _ChangedValueCallbackWrapper[T]:
    callback: ChangedValueCall[T]

type _Callback[T] = Callable[[], None] | NewValueCall[T] | ChangedValueCall[T]
type _CallbackWrapper[T] = _BasicCallbackWrapper | _ChangedValueCallbackWrapper[T] | _NewValueCallbackWrapper[T]
