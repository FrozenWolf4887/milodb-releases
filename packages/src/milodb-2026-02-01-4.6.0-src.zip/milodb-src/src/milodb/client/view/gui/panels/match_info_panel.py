# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import tkinter as tk
from collections.abc import Callable, Sequence
from tkinter import ttk
from typing import override
from milodb.client.database.tease import Tease
from milodb.client.query.tease_match import TeaseMatch
from milodb.client.view.gui import general_layout
from milodb.client.view.gui.theme import Style
from milodb.client.view.gui.util.datum import IValueDatum
from milodb.client.view.gui.widgets.styled_frame import StyledFrame

class MatchInfoPanel(StyledFrame):
    def __init__(self, master: tk.Misc, list_of_teases: Sequence[Tease], list_of_tease_matches: IValueDatum[Sequence[TeaseMatch]], selected_tease_index: IValueDatum[int | None], reset_tease_matches: Callable[[], None]) -> None:
        super().__init__(master, style=Style.Generic.ValueFrame.STYLE_NAME)
        self._list_of_teases: Sequence[Tease] = list_of_teases
        self._list_of_tease_matches: IValueDatum[Sequence[TeaseMatch]] = list_of_tease_matches
        self._selected_tease_index: IValueDatum[int | None] = selected_tease_index
        self._reset_tease_matches: Callable[[], None] = reset_tease_matches

        ttk.Button(self, text='Reset\nresults', command=self._on_reset_button_pressed).pack(side=tk.LEFT, padx=general_layout.PANEL_PADDING_X)
        details_frame: StyledFrame = StyledFrame(self, style=Style.Generic.ValueFrame.STYLE_NAME)
        self._tease_match_count_text: ttk.Label = ttk.Label(details_frame, style=Style.Generic.ValueLabel.STYLE_NAME)
        self._tease_match_count_text.grid(row=0, column=0, sticky=tk.W)
        self._selected_tease_text: ttk.Label = ttk.Label(details_frame, style=Style.Generic.ValueLabel.STYLE_NAME)
        self._selected_tease_text.grid(row=1, column=0, sticky=tk.W)
        details_frame.pack(side=tk.LEFT, ipadx=general_layout.PANEL_PADDING_X, padx=(general_layout.PANEL_PADDING_X, 0))

        self._list_of_tease_matches.add_new_value_listener(self._on_list_of_tease_matches_changed, call_immediately=True)
        self._selected_tease_index.add_new_value_listener(self._on_selected_tease_index_changed, call_immediately=True)

    @override
    def destroy(self) -> None:
        self._list_of_tease_matches.remove_listener(self._on_list_of_tease_matches_changed)
        self._selected_tease_index.remove_listener(self._on_selected_tease_index_changed)
        super().destroy()

    def _on_list_of_tease_matches_changed(self, new_value: Sequence[TeaseMatch]) -> None:
        match_count: int = len(new_value)
        tease_count: int = len(self._list_of_teases)
        match_percentage: int = max(1 if match_count else 0, match_count * 100 // tease_count) if tease_count > 0 else 0
        self._tease_match_count_text.config(text=f'Showing {match_count:,} of {tease_count:,} teases ({match_percentage}%)')

    def _on_selected_tease_index_changed(self, new_value: int | None) -> None:
        if new_value is None:
            self._selected_tease_text.config(text='Nothing selected')
        else:
            tease_match: TeaseMatch = self._list_of_tease_matches.get()[new_value]
            self._selected_tease_text.config(text=f'Selected tease #{tease_match.tease.tease_id}')

    def _on_reset_button_pressed(self) -> None:
        self._reset_tease_matches()
