# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import tkinter as tk
from pathlib import Path
from tkinter import ttk
from types import TracebackType
from typing import Self, override
from PIL import Image, ImageTk
from milodb.client.resources import resource_path
from milodb.client.util import app_info
from milodb.client.view.gui import general_layout
from milodb.client.view.gui.theme import Colour, Style
from milodb.client.view.gui.widgets.log_text import LogText
from milodb.client.view.gui.widgets.styled_frame import StyledFrame
from milodb.client.view.progress_display import IProgressDisplay
from milodb.common.output.print.i_printer import IPrinter

_LAYOUT_PANEL_BORDER_WIDTH: int = general_layout.PANEL_BORDER_WIDTH

_COLLAPSED_DETAIL_TEXT: str = '⯈ Detail'
_EXPANDED_DETAIL_TEXT: str = '▼ Detail'

class SplashDialog(tk.Toplevel, IProgressDisplay):
    def __init__(self) -> None:
        super().__init__()
        self.config(background=Colour.TopLevel.LOG_DIALOG_BACK, borderwidth=_LAYOUT_PANEL_BORDER_WIDTH)
        self.title('MiloDB')

        self._subtitle_text: tk.StringVar = tk.StringVar(self)
        self._action_text: tk.StringVar = tk.StringVar(self)
        self._progress_value: tk.IntVar = tk.IntVar(self)
        self._activity_category: tk.StringVar = tk.StringVar(self)
        self._activity_text: tk.StringVar = tk.StringVar(self)
        self._detail_text: tk.StringVar = tk.StringVar(self, _COLLAPSED_DETAIL_TEXT)
        self._is_log_expanded: bool = False
        self._should_prompt_to_continue: bool = False
        self._should_prompt_with_log: bool = False

        with Image.open(resource_path(Path('app-icon.png'))) as app_icon:
            self._app_image: ImageTk.PhotoImage = ImageTk.PhotoImage(app_icon.resize((48, 48), resample=Image.Resampling.BICUBIC))

        self.columnconfigure(0, weight=1)
        self.rowconfigure(3, weight=1)

        header_frame: StyledFrame = StyledFrame(self)
        header_frame.grid(row=0, column=0, sticky=tk.EW, padx=4, pady=(4, 2))
        header_frame.columnconfigure(3, weight=1)
        ttk.Label(header_frame, image=self._app_image).grid(row=0, column=0, rowspan=2)
        ttk.Label(header_frame, style=Style.Generic.TitleLabel.STYLE_NAME, text=app_info.APPLICATION_NAME).grid(row=0, column=1, padx=6)
        ttk.Label(header_frame, style=Style.Generic.SubtitleLabel.STYLE_NAME, textvariable=self._subtitle_text).grid(row=0, column=2, columnspan=2, sticky=tk.W, padx=6)
        ttk.Progressbar(header_frame, variable=self._progress_value).grid(row=1, column=1, columnspan=4, sticky=tk.EW, padx=6, pady=6)

        progress_frame: StyledFrame = StyledFrame(self)
        progress_frame.grid(row=1, column=0, sticky=tk.EW, padx=4, pady=4)
        progress_frame.grid_columnconfigure(3, weight=1)
        ttk.Label(progress_frame, style=Style.Generic.SubtitleLabel.STYLE_NAME, textvariable=self._action_text).grid(row=0, column=0, columnspan=3, padx=4, sticky=tk.EW)
        ttk.Label(progress_frame, style=Style.Generic.SubtitleLabel.STYLE_NAME, textvariable=self._progress_value).grid(row=0, column=3, sticky=tk.SE)
        ttk.Label(progress_frame, text='%').grid(row=0, column=4, padx=(0, 4), sticky=tk.SW)

        activity_frame: StyledFrame = StyledFrame(self)
        activity_frame.grid(row=2, column=0, sticky=tk.EW, padx=4, pady=4)
        ttk.Label(activity_frame, textvariable=self._activity_category).grid(row=1, column=1, sticky=tk.SE)
        ttk.Label(activity_frame, textvariable=self._activity_text).grid(row=1, column=2, sticky=tk.SW)

        self._log_frame: StyledFrame = StyledFrame(self)
        self._log_frame.grid(row=3, column=0, sticky=tk.NSEW, padx=4, pady=4)
        self._log_frame.columnconfigure(0, weight=1)
        self._log_frame.rowconfigure(1, weight=1)
        detail_button: ttk.Label = ttk.Label(self._log_frame, width=40, textvariable=self._detail_text, takefocus=True)
        detail_button.grid(row=0, column=0, sticky=tk.W)
        detail_button.bind('<Button-1>', lambda _event: self._toggle_log_view())
        detail_button.bind('<space>', lambda _event: self._toggle_log_view())
        detail_button.focus()
        self._log_text: LogText = LogText(self._log_frame)
        self._log_text.grid(row=1, column=0, sticky=tk.NSEW)
        self._log_text.grid_remove()
        self._log_text.textbox.configure(width=60, height=20)

        self.resizable(width=False, height=False)
        self.protocol("WM_DELETE_WINDOW", self.update)

    @override
    def set_subtitle_text(self, text: str) -> None:
        self._subtitle_text.set(text)

    @override
    def set_action_text(self, text: str) -> None:
        self._action_text.set(text)
        self._activity_category.set('')
        self._activity_text.set('')

    @override
    def set_activity_category(self, text: str) -> None:
        self._activity_category.set(f'{text}:')
        self._activity_text.set('')

    @override
    def set_activity_text(self, text: str) -> None:
        self._activity_text.set(text)

    @override
    def set_progress_percentage(self, percentage: int) -> None:
        self._progress_value.set(percentage)

    @property
    @override
    def normal_printer(self) -> IPrinter:
        return self._log_text.normal_printer

    @property
    @override
    def warning_printer(self) -> IPrinter:
        return self._log_text.warning_printer

    @property
    @override
    def error_printer(self) -> IPrinter:
        return self._log_text.error_printer

    @override
    def prompt_on_exit(self, *, show_log: bool=True) -> None:
        self._should_prompt_to_continue = True
        self._should_prompt_with_log = show_log

    @override
    def print_warning_and_prompt_on_exit(self, message: str) -> None:
        self._log_text.warning_printer.writeln(message)
        self._should_prompt_to_continue = True
        self._should_prompt_with_log = True

    @override
    def print_fatal_and_prompt_on_exit(self, message: str) -> None:
        self._log_text.fatal_printer.writeln(message)
        self._should_prompt_to_continue = True
        self._should_prompt_with_log = True

    def _prompt_to_continue(self) -> None:
        if self._should_prompt_with_log and not self._is_log_expanded:
            self._toggle_log_view()
        button: ttk.Button = ttk.Button(self, text='OK', command=self.destroy)
        button.grid(row=4, column=0)
        button.focus()
        self.protocol("WM_DELETE_WINDOW", self.destroy)
        self.wait_window()

    @override
    def __enter__(self) -> Self:
        self.wait_visibility()
        return self

    @override
    def __exit__(self, exc_type: type[BaseException] | None, exc_value: BaseException | None, traceback: TracebackType | None) -> None:
        if self._should_prompt_to_continue:
            self._prompt_to_continue()
        self.destroy()

    def _toggle_log_view(self) -> None:
        if self._is_log_expanded:
            self._detail_text.set(_COLLAPSED_DETAIL_TEXT)
            self._log_text.grid_remove()
            self.geometry('')
            self.resizable(width=False, height=False)
        else:
            self._detail_text.set(_EXPANDED_DETAIL_TEXT)
            self._log_text.grid()
            self.resizable(width=True, height=True)

        self._is_log_expanded = not self._is_log_expanded
