# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import tkinter as tk
from collections.abc import Callable
from tkinter import ttk
from milodb.client.view.gui import general_layout
from milodb.client.view.gui.theme import Style
from milodb.client.view.gui.widgets.styled_frame import StyledFrame

_LAYOUT_PADDING_X: int = general_layout.PANEL_PADDING_X
_LAYOUT_PADDING_Y: int = general_layout.PANEL_PADDING_Y

class ToolbarPanel(StyledFrame):
    def __init__(self, master: tk.Misc, *, open_about_dialog: Callable[[], None], open_update_dialog: Callable[[], None], open_stats_dialog: Callable[[], None], open_config_dialog: Callable[[], None]) -> None:
        super().__init__(master, style=Style.Generic.PanelFrame.STYLE_NAME)

        ttk.Button(self, text='About', command=open_about_dialog).pack(fill=tk.X, padx=_LAYOUT_PADDING_X, pady=(0,_LAYOUT_PADDING_Y))
        ttk.Button(self, text='Update', command=open_update_dialog).pack(fill=tk.X, padx=_LAYOUT_PADDING_X, pady=_LAYOUT_PADDING_Y)
        ttk.Button(self, text='Stats', command=open_stats_dialog).pack(fill=tk.X, padx=_LAYOUT_PADDING_X, pady=_LAYOUT_PADDING_Y)
        ttk.Button(self, text='Config', command=open_config_dialog).pack(fill=tk.X, padx=_LAYOUT_PADDING_X, pady=(_LAYOUT_PADDING_Y,0))
