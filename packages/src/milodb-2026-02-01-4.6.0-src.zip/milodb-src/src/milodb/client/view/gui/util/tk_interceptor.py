# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import tkinter as tk
from functools import partial
from typing import Any, Protocol

class TkInterceptor:
    class Handler(Protocol):
        def __call__(self, *args: Any) -> object: # noqa: ANN401 Dynamically typed expressions (typing.Any) are disallowed:
            ...

    def __init__(self, widget: tk.Widget) -> None:
        self._widget: tk.Widget = widget
        self._map_of_operation_to_handler: dict[str, TkInterceptor.Handler] = {}
        dispatch_operation: str = widget._w # type: ignore[attr-defined] # noqa: SLF001 Private member accessed
        self._original_dispatch_operation = f'{dispatch_operation}_original'
        self._widget.tk.call('rename', dispatch_operation, self._original_dispatch_operation)
        self._widget.tk.createcommand(dispatch_operation, self._hooked_dispatch)

    def intercept(self, operation: str, dispatch_handler: Handler, method_handler: Handler | None=None) -> Handler:
        self._map_of_operation_to_handler[operation] = dispatch_handler
        setattr(self._widget, operation, method_handler if method_handler else dispatch_handler)
        return partial(self._call_original_dispatch, operation)

    def _hooked_dispatch(self, operation: str, *args: Any) -> Any: # noqa: ANN401 Dynamically typed expressions (typing.Any) are disallowed:
        handler: TkInterceptor.Handler | None = self._map_of_operation_to_handler.get(operation)
        return handler(*args) if handler else self._call_original_dispatch(operation, *args)

    def _call_original_dispatch(self, operation: str, *args: Any) -> Any: # noqa: ANN401 Dynamically typed expressions (typing.Any) are disallowed:
        try:
            return self._widget.tk.call(self._original_dispatch_operation, operation, *args)
        except tk.TclError:
            return ''
