# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import tkinter as tk
from milodb.client.view.gui.util import tk_type

PANEL_RELIEF: tk_type.Relief = tk.GROOVE
PANEL_BORDER_WIDTH: int = 4
PANEL_PADDING_X: int = 2
PANEL_PADDING_Y: int = 2
PANEL_MARGIN_X: int = 5
PANEL_MARGIN_Y: int = 5
BUTTON_PADDING_X: int = -8
BUTTON_PADDING_Y: int = 1
BUTTON_WIDE_PADDING_X: int = 10
BUTTON_WIDE_PADDING_Y: int = 1
LABEL_PADDING_X: int = 4
LABEL_PADDING_Y: int = 0
TABLE_CELL_PADDING_X: int = 6
TABLE_CELL_PADDING_Y: int = 2
SCROLLBAR_WIDTH: int = 17
BUTTON_BORDER_RELIEF: tk_type.Relief = tk.SOLID
