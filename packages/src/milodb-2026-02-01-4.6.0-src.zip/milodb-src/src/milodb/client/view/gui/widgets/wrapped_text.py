# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import tkinter as tk
from milodb.client.view.gui.theme import Style
from milodb.client.view.gui.util import tk_type
from milodb.client.view.gui.util.tk_interceptor import TkInterceptor
from milodb.client.view.gui.widgets.styled_text import StyledText

_TK_INSERT_ARG_COUNT: int = 2
_TK_INSERT_TEXT_ARG_INDEX: int = 1

class WrappedText(StyledText):
    TEXT_CHANGED_BINDING: str = '<<TextChanged>>'

    def __init__(self, master: tk.Misc, *, is_multiline: bool=False, is_readonly: bool=False, max_line_count: int | None=None, style: str=Style.Generic.Text.STYLE_NAME, xscrollcommand: tk_type.XYScrollCommand = '', yscrollcommand: tk_type.XYScrollCommand = '') -> None:
        self._is_multiline: bool = is_multiline
        self._is_readonly: bool = is_readonly

        super().__init__(master, line_count='dynamic', wrap=tk.WORD, style=style, max_line_count=max_line_count, xscrollcommand=xscrollcommand, yscrollcommand=yscrollcommand)

        if not self._is_multiline:
            self.bind('<Return>', lambda _event: 'break')
        self.bind('<<Paste>>', self._on_paste)
        self.bind('<<PasteSelection>>', self._on_paste)

        self.event_add(self.TEXT_CHANGED_BINDING, 'None')

        interceptor: TkInterceptor = TkInterceptor(self)
        self._original_tk_insert: TkInterceptor.Handler = interceptor.intercept("insert", self._on_tk_insert, self._on_tk_insert_call)
        self._original_tk_delete: TkInterceptor.Handler = interceptor.intercept("delete", self._on_tk_delete, self._on_tk_delete_call)

    def replace_text(self, text: str) -> None:
        self._original_tk_delete('1.0', tk.END)
        self._original_tk_insert('1.0', text)
        self.update_height_to_fit_text()

    def _on_tk_insert(self, *args: object) -> object:
        result: object
        if self._is_readonly:
            result = 'break'
        else:
            result = self._original_tk_insert(*args)
            self.update_height_to_fit_text()
            if len(args) == _TK_INSERT_ARG_COUNT and args[_TK_INSERT_TEXT_ARG_INDEX]:
                self.event_generate(self.TEXT_CHANGED_BINDING)
        return result

    def _on_tk_insert_call(self, *args: object) -> object:
        result: object = self._original_tk_insert(*args)
        self.update_height_to_fit_text()
        return result

    def _on_tk_delete(self, *args: object) -> object:
        result: object
        if self._is_readonly:
            result = 'break'
        else:
            result = self._original_tk_delete(*args)
            self.update_height_to_fit_text()
            self.event_generate(self.TEXT_CHANGED_BINDING)
        return result

    def _on_tk_delete_call(self, *args: object) -> object:
        result: object = self._original_tk_delete(*args)
        self.update_height_to_fit_text()
        return result

    def _on_paste(self, _: object) -> str | None:
        if not self._is_readonly:
            text: str | None = self._get_clipboard()
            if text:
                if not self._is_multiline:
                    text = _cut_text_at_line_break(text)
                self._delete_selection()
                self.insert(self.index(tk.INSERT), text)
                self.see(self.index(tk.INSERT))
                self.event_generate(self.TEXT_CHANGED_BINDING)
        return 'break'

    def _delete_selection(self) -> None:
        index_of_selection_begin: str | None = None
        index_of_selection_end: str | None = None
        try:
            index_of_selection_begin = self.index(tk.SEL_FIRST)
            index_of_selection_end = self.index(tk.SEL_LAST)
        except tk.TclError:
            pass

        if index_of_selection_begin and index_of_selection_end:
            self.delete(index_of_selection_begin, index_of_selection_end)

    def _get_clipboard(self) -> str | None:
        text: object = None
        try:
            root: tk.Tk | tk.Toplevel = self.winfo_toplevel()
            text = root.clipboard_get()
        except tk.TclError:
            pass
        if isinstance(text, str):
            return text
        return None

def _cut_text_at_line_break(text: str) -> str:
    lf_pos: int = text.find('\n')
    cr_pos: int = text.find('\r')
    break_pos: int = -1
    if lf_pos != -1:
        break_pos = lf_pos
    if cr_pos != -1 and cr_pos < break_pos:
        break_pos = cr_pos
    if break_pos != -1:
        text = text[:break_pos]
    return text
