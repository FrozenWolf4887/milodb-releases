# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from collections.abc import Callable

class RaiiSingleton[T]:
    def __init__(self, constructor: Callable[[], T]) -> None:
        self._constructor: Callable[[], T] = constructor
        self._instance: T | None = None

    @property
    def instance(self) -> T:
        if self._instance is None:
            self._instance = self._constructor()
        return self._instance
