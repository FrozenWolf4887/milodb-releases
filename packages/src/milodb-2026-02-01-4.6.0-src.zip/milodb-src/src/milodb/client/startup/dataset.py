# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import json
from collections.abc import Sequence
from dataclasses import dataclass
from pathlib import Path
from milodb.client.config.config_schema import CONFIG_SCHEMA
from milodb.client.config.migration import try_migrate_config
from milodb.client.database.database import load_teases_from_database_file
from milodb.client.database.tease import Tease
from milodb.client.database.thumbnail_database import ThumbnailDatabase, load_thumbnail_database
from milodb.client.updater.manifest.i_schema_types import SchemaLoadError
from milodb.client.updater.manifest.local_manifest import ILocalManifest
from milodb.client.updater.manifest.local_manifest_schema import LocalManifestSchema
from milodb.client.util import app_info
from milodb.client.view.progress_display import IProgressDisplay, PercentageSlice
from milodb.common.config.framework import IConfigGroup, IPersistentConfig
from milodb.common.config.json_config_file import JsonConfigFile
from milodb.common.output.print.i_printer import IPrinter
from milodb.common.variables.file_user_variables import FileUserVariables
from milodb.common.variables.i_user_variables import IPersistentUserVariables

_LOCAL_MANIFEST_FILENAME: Path = Path('milodb-manifest.ver')
_TEASES_DATABASE_FILENAME: Path = Path('milodb-teases.dat')
_THUMBS_DATABASE_FILENAME: Path = Path('milodb-thumbs.dat')
_CONFIG_FILENAME: Path = Path('user-config.json')
_VARIABLES_FILENAME: Path = Path('user-variables.json')

@dataclass
class DataSet:
    local_manifest: ILocalManifest | None
    config: IPersistentConfig
    config_schema: IConfigGroup
    user_variables: IPersistentUserVariables
    list_of_teases: Sequence[Tease]
    thumbnail_database: ThumbnailDatabase

def load_dataset(progress_display: IProgressDisplay, *, no_load: bool) -> DataSet:
    config_percentage_slice: PercentageSlice = PercentageSlice(0, 5, progress_display.set_progress_percentage)
    database_percentage_slice: PercentageSlice = PercentageSlice(5, 80, progress_display.set_progress_percentage)
    thumbnail_percentage_slice: PercentageSlice = PercentageSlice(80, 100, progress_display.set_progress_percentage)

    progress_display.set_action_text('Loading')

    progress_display.set_activity_category('Initialise')

    progress_display.set_activity_text('Load manifest')
    local_manifest: LocalManifestSchema | None = _load_local_manifest(_LOCAL_MANIFEST_FILENAME, progress_display.warning_printer, progress_display.error_printer)
    version_text: str = '(unknown version)' if not local_manifest else f'{local_manifest.version_number}, {local_manifest.date}'
    progress_display.set_subtitle_text(version_text)
    progress_display.normal_printer.writeln(version_text)
    config_percentage_slice.set_progress_percentage(33)

    progress_display.set_activity_text('Load configuration')
    config: JsonConfigFile = JsonConfigFile(_CONFIG_FILENAME, CONFIG_SCHEMA, try_migrate_config)
    config.load(progress_display.normal_printer, progress_display.warning_printer, progress_display.error_printer)
    config_percentage_slice.set_progress_percentage(66)

    progress_display.set_activity_text('Load variables')
    user_variables: IPersistentUserVariables = FileUserVariables(_VARIABLES_FILENAME)
    user_variables.load(progress_display.normal_printer, progress_display.warning_printer, progress_display.error_printer)
    config_percentage_slice.set_progress_percentage(100)

    list_of_teases: Sequence[Tease]
    thumbnail_database: ThumbnailDatabase
    if no_load:
        list_of_teases = []
        thumbnail_database = ThumbnailDatabase({}, b'')
    else:
        progress_display.normal_printer.writeln()
        list_of_teases = load_teases_from_database_file(_TEASES_DATABASE_FILENAME, progress_display, database_percentage_slice)
        progress_display.normal_printer.writeln()
        thumbnail_database = load_thumbnail_database(_THUMBS_DATABASE_FILENAME, progress_display, thumbnail_percentage_slice)

    progress_display.normal_printer.writeln()
    progress_display.normal_printer.writeln(app_info.get_database_info_one_line(list_of_teases))
    progress_display.normal_printer.writeln(f'{thumbnail_database.number_of_thumbnails:,} thumbnails loaded')

    progress_display.set_progress_percentage(percentage=100)
    progress_display.set_activity_text('Done')

    return DataSet(
        local_manifest,
        config,
        CONFIG_SCHEMA,
        user_variables,
        list_of_teases,
        thumbnail_database,
    )

def _load_local_manifest(filename: Path, warning_printer: IPrinter, error_printer: IPrinter) -> LocalManifestSchema | None:
    try:
        json_root: object = json.loads(filename.read_bytes())
    except FileNotFoundError:
        warning_printer.writeln(f"Local manifest '{filename}' unavailable")
    except (OSError, json.JSONDecodeError, UnicodeDecodeError) as ex:
        error_printer.writeln(f"Unable to read from local manifest '{filename}': {ex}")
    else:
        manifest: LocalManifestSchema = LocalManifestSchema()
        try:
            manifest.load(json_root)
        except SchemaLoadError as ex:
            error_printer.writeln(f"Invalid local manifest '{filename}': {ex}")
        else:
            return manifest
    return None
