# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import json
import sys
import time
from collections.abc import Iterable
from dataclasses import dataclass
from pathlib import Path
import psutil
from milodb.client.startup.command_line import CommandLine, CommandLineError, parse_command_line
from milodb.client.startup.shutdown_action import IShutdownAction, RestartToCompleteUpdateAction
from milodb.client.updater.i_temp_directory import TempDirectoryError
from milodb.client.updater.manifest.i_schema_types import SchemaLoadError
from milodb.client.updater.manifest.update_sequence_schema import UpdateSequenceSchema
from milodb.client.updater.perform_update import PerformUpdateError, perform_update
from milodb.client.updater.temp_directory import TempDirectory
from milodb.client.view.progress_display import IProgressDisplay

_PID_WAIT_TIMEOUT_SECONDS: int = 10

@dataclass(kw_only=True)
class StartupResult:
    exit_code: int
    run_main_application: bool
    shutdown_action: IShutdownAction | None

def startup(list_of_args: Iterable[str], progress_display: IProgressDisplay) -> tuple[StartupResult, CommandLine | None]:
    progress_display.set_action_text('Startup')
    progress_display.set_activity_category('Command line')
    progress_display.set_activity_text('Parse')
    try:
        command_line: CommandLine = parse_command_line(list_of_args)
    except CommandLineError as ex:
        progress_display.print_fatal_and_prompt_on_exit(f'Command line error: {ex}')
        return StartupResult(exit_code=1, run_main_application=False, shutdown_action=None), None

    if (_wait_for_list_of_pids_to_end(command_line.list_of_pids_to_wait_on, _PID_WAIT_TIMEOUT_SECONDS, progress_display) and
        _purge_list_of_temp_directories(command_line.list_of_temp_directories_to_purge, progress_display)
    ):
        if command_line.update_from_sequence_filepath:
            return _process_perform_update(command_line.update_from_sequence_filepath, progress_display), command_line

        return StartupResult(exit_code=0, run_main_application=True, shutdown_action=None), command_line

    return StartupResult(exit_code=1, run_main_application=False, shutdown_action=None), command_line

def _wait_for_list_of_pids_to_end(list_of_pids: Iterable[int], timeout_seconds: int, progress_display: IProgressDisplay) -> bool:
    progress_display.set_activity_category('Starting')
    return all(_wait_for_pid_to_end(pid, timeout_seconds, progress_display) for pid in list_of_pids)

def _wait_for_pid_to_end(pid: int, timeout_seconds: int, progress_display: IProgressDisplay) -> bool:
    progress_display.set_activity_text(f'Waiting for PID {pid}')
    progress_display.normal_printer.writeln(f'Waiting for PID {pid} to finish...')
    start_time_ns: int = time.monotonic_ns()
    while psutil.pid_exists(pid):
        time.sleep(0.5)
        elapsed_time_seconds: int = (time.monotonic_ns() - start_time_ns) // 1_000_000_000
        if elapsed_time_seconds >= timeout_seconds:
            progress_display.print_fatal_and_prompt_on_exit(f"PID {pid} didn't end within {timeout_seconds} seconds")
            return False
    progress_display.normal_printer.writeln(f'PID {pid} finished')
    return True

def _purge_list_of_temp_directories(list_of_directories: Iterable[Path], progress_display: IProgressDisplay) -> bool:
    if list_of_directories:
        progress_display.set_activity_category('Update')

    directory: Path
    for directory in list_of_directories:
        progress_display.set_activity_text('Cleaning up')
        progress_display.normal_printer.writeln(f"Purge temporary directory '{directory}'")
        try:
            TempDirectory(directory).destroy()
        except TempDirectoryError as ex:
            progress_display.print_warning_and_prompt_on_exit(f"Couldn't purge directory '{directory}': {ex}")
            return False
    return True

def _process_perform_update(update_sequence_filepath: Path, progress_display: IProgressDisplay) -> StartupResult:
    progress_display.set_action_text('Updating')
    progress_display.set_activity_category('Upgrade')
    progress_display.set_activity_text('Load schema')
    try:
        update_strategy_json: object = json.loads(update_sequence_filepath.read_bytes())
    except (OSError, json.JSONDecodeError, UnicodeDecodeError) as ex:
        progress_display.print_fatal_and_prompt_on_exit(f"Loading '{update_sequence_filepath}' failed: {ex}")
        return StartupResult(exit_code=1, run_main_application=False, shutdown_action=None)

    update_sequence: UpdateSequenceSchema = UpdateSequenceSchema()
    try:
        update_sequence.load(update_strategy_json)
    except SchemaLoadError as ex:
        progress_display.print_fatal_and_prompt_on_exit(f"Parsing '{update_sequence_filepath}' failed: {ex}")
        return StartupResult(exit_code=1, run_main_application=False, shutdown_action=None)

    progress_display.set_activity_text('Replace files')
    progress_display.set_progress_percentage(50)

    try:
        perform_update(update_sequence, progress_display.normal_printer, progress_display.error_printer)
    except PerformUpdateError as ex:
        progress_display.print_fatal_and_prompt_on_exit(f"Failed to perform update: {ex}")
        return StartupResult(exit_code=1, run_main_application=False, shutdown_action=None)

    progress_display.set_activity_text('Done')
    progress_display.set_progress_percentage(100)

    shutdown_action: IShutdownAction | None = None
    if update_sequence.launch_filename:
        shutdown_action = RestartToCompleteUpdateAction(
            new_application_filepath = update_sequence.launch_filename,
            temp_application_filepath = Path(sys.executable),
            update_sequence_filepath = update_sequence_filepath,
            temp_directory = update_sequence.temp_directory,
        )
    else:
        progress_display.print_warning_and_prompt_on_exit("There is no known new application that can be started")

    return StartupResult(exit_code=0, run_main_application=False, shutdown_action=shutdown_action)
