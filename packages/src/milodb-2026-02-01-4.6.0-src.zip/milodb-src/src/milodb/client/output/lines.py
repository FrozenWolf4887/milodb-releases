# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from collections.abc import Callable

_LINEFEED_CHAR: str = '\n'

def iterate_through_lines(text: str, callback_text: Callable[[str], None], callback_line_ending: Callable[[str], None]) -> None: # NOSONAR Refactor this function to reduce its Cognitive Complexity (python:S3997)
    previous_index: int = 0
    is_in_line_ending: bool = False

    index: int
    char: str
    for index, char in enumerate(text):
        if char == _LINEFEED_CHAR:
            if not is_in_line_ending:
                if previous_index < index:
                    callback_text(text[previous_index:index])
                is_in_line_ending = True
                previous_index = index
        elif is_in_line_ending:
            if previous_index < index:
                callback_line_ending(text[previous_index:index])
            is_in_line_ending = False
            previous_index = index

    if is_in_line_ending:
        callback_line_ending(text[previous_index:])
    else:
        callback_text(text[previous_index:])
