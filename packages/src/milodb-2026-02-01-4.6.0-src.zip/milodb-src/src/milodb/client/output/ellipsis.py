# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from __future__ import annotations
from enum import Enum
from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from collections.abc import Callable

class EllipsisLocation(Enum):
    LEFT = 0
    MIDDLE = 1
    RIGHT = 2

    @staticmethod
    def from_position(*, is_first_item: bool, is_last_item: bool) -> EllipsisLocation:
        if is_first_item:
            if is_last_item:
                return EllipsisLocation.MIDDLE
            return EllipsisLocation.LEFT
        if is_last_item:
            return EllipsisLocation.RIGHT
        return EllipsisLocation.MIDDLE

def ellipsify_text(text: str, max_length: int, ellipsis_location: EllipsisLocation, callback_normal_text: Callable[[str], None], callback_ellipsis: Callable[[], None]) -> None:
    if ellipsis_location is EllipsisLocation.MIDDLE:
        max_length *= 2
    if len(text) > max_length:
        if ellipsis_location is EllipsisLocation.LEFT:
            callback_ellipsis()
            callback_normal_text(text[len(text) - max_length + 1:])
        elif ellipsis_location is EllipsisLocation.MIDDLE:
            callback_normal_text(text[:max_length // 2])
            callback_ellipsis()
            callback_normal_text(text[len(text) - (max_length - 1) // 2:])
        else:
            callback_normal_text(text[:max_length - 1])
            callback_ellipsis()
    else:
        callback_normal_text(text)
