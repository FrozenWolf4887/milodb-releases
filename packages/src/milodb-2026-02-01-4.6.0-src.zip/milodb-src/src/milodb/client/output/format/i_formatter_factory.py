# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from abc import ABC, abstractmethod
from collections.abc import Mapping, Sequence
from milodb.client.output.format.i_formatter import IFormatter
from milodb.common.output.print.i_printer import IPrinter

class IFormatterCreator(ABC):
    @abstractmethod
    def get_name(self) -> str:
        pass

    @abstractmethod
    def create(self, printer: IPrinter) -> IFormatter:
        pass

class IFormatterFactory(ABC):
    @abstractmethod
    def get_list_of_formatter_names(self) -> Sequence[str]:
        pass

    @property
    @abstractmethod
    def map_of_name_to_formatter_creator(self) -> Mapping[str, IFormatterCreator]:
        pass
