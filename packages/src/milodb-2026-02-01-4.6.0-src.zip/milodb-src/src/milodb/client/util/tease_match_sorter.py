# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from __future__ import annotations
import functools
from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, override
from milodb.client.query.tease_match import TeaseMatch
from milodb.client.util.sort_keys import SortCompareResult
if TYPE_CHECKING:
    from collections.abc import Iterable
    from milodb.client.util.sort_keys import ISortKey

class ITeaseMatchSorter(ABC):
    @abstractmethod
    def sort(self, list_of_tease_matches: Iterable[TeaseMatch], list_of_sort_keys: Iterable[ISortKey]) -> list[TeaseMatch]:
        pass

class TeaseMatchSorter(ITeaseMatchSorter):
    def __init__(self, list_of_default_sort_keys: Iterable[ISortKey]) -> None:
        self._list_of_default_sort_keys: Iterable[ISortKey] = list_of_default_sort_keys

    @override
    def sort(self, list_of_tease_matches: Iterable[TeaseMatch], list_of_sort_keys: Iterable[ISortKey]) -> list[TeaseMatch]:
        new_list_of_tease_matches: list[TeaseMatch] = []

        list_of_actual_sort_keys: Iterable[ISortKey] = [ *list_of_sort_keys, *self._list_of_default_sort_keys ]

        def custom_comparer(left: TeaseMatch, right: TeaseMatch) -> int:
            for sort_key in list_of_actual_sort_keys:
                compare_result: SortCompareResult = sort_key.compare(left, right)
                if compare_result is not SortCompareResult.BOTH_ARE_SAME:
                    return compare_result.value
            return SortCompareResult.BOTH_ARE_SAME.value

        sorted_list_of_tease_matches: Iterable[TeaseMatch] = sorted(list_of_tease_matches, key=functools.cmp_to_key(custom_comparer))

        index: int
        tease_match: TeaseMatch
        for index, tease_match in enumerate(sorted_list_of_tease_matches):
            new_list_of_tease_matches.append(TeaseMatch(index + 1, tease_match.tease, tease_match.list_of_field_matches))

        return new_list_of_tease_matches
