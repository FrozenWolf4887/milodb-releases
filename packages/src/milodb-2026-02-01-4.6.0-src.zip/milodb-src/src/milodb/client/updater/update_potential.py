# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from milodb.client.updater.update_strategy import UpdateStrategy

class UpdatePotential:
    def __init__(self, update_strategy: UpdateStrategy) -> None:
        self._is_update_available: bool
        self._message: str

        if update_strategy.target_variant.name != update_strategy.local_manifest.variant_name:
            self._is_update_available = True
            self._message = f"Switch variant: {update_strategy.target_variant.name} / {update_strategy.target_version.number}"
        elif update_strategy.local_manifest.version_number == update_strategy.target_version.number:
            self._is_update_available = False
            self._message=f"You have the current version: {update_strategy.local_manifest.variant_name} / {update_strategy.local_manifest.version_number}"
        elif update_strategy.local_manifest.version_number > update_strategy.target_version.number:
            self._is_update_available = False
            self._message=f"You have a newer version: {update_strategy.local_manifest.variant_name} / {update_strategy.local_manifest.version_number} than the latest available: {update_strategy.target_variant.name} / {update_strategy.target_version.number}"
        else:
            self._is_update_available = True
            self._message=f"Upgrade available to: {update_strategy.target_variant.name} / {update_strategy.target_version.number}"

    @property
    def is_update_available(self) -> bool:
        return self._is_update_available

    @property
    def message(self) -> str:
        return self._message
