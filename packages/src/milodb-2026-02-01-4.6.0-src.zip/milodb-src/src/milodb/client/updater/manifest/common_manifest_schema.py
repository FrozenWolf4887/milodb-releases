# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from pathlib import Path
from typing import override
from milodb.client.updater.manifest.common_manifest import IConfigFile, IHexDigest, ILaunchFile, IVersionNumber
from milodb.client.updater.manifest.hex_digest import HexDigest, HexDigestError
from milodb.client.updater.manifest.i_schema_types import IGroup, IKey, IKeyCreator, ITypedKey, KeyParseError, SchemaLoadError
from milodb.client.updater.manifest.schema_types import Item
from milodb.client.updater.manifest.version_number import VersionNumber, VersionNumberError

def validate_format_field(root: object, expected_format_version: object, name_of_schema: str) -> None:
    if not isinstance(root, dict):
        msg = f"Schema of {name_of_schema} has invalid root type of '{type(root).__name__}'"
        raise SchemaLoadError(msg)
    format_value: object = root.get('format')
    if format_value is None:
        msg = f"Format field of {name_of_schema} is missing"
        raise SchemaLoadError(msg)
    if not isinstance(format_value, type(expected_format_version)):
        msg = f"Format field of {name_of_schema} is of type '{type(format_value).__name__}'; expected to be '{type(expected_format_version).__name__}'"
        raise SchemaLoadError(msg)
    if format_value != expected_format_version:
        msg = f"Unsupported {name_of_schema} format of '{format_value}'; expected to be '{expected_format_version}'"
        raise SchemaLoadError(msg)

class VersionNumberKey(ITypedKey[IVersionNumber]):
    def __init__(self, version_number: IVersionNumber) -> None:
        self._version_number: IVersionNumber = version_number

    @override
    def __str__(self) -> str:
        return str(self._version_number)

    @property
    @override
    def name(self) -> str:
        return str(self._version_number)

    @override
    def get_key_value(self) -> IVersionNumber:
        return self._version_number

    class Creator(IKeyCreator[IVersionNumber]):
        @override
        def parse(self, key_name: str) -> ITypedKey[IVersionNumber]:
            try:
                version_number: IVersionNumber = VersionNumber.parse(key_name)
            except VersionNumberError as ex:
                raise KeyParseError(ex) from ex
            return VersionNumberKey(version_number)

        @override
        def from_base_type(self, value: IVersionNumber) -> ITypedKey[IVersionNumber]:
            return VersionNumberKey(value)

class HexDigestKey(ITypedKey[IHexDigest]):
    def __init__(self, digest: IHexDigest) -> None:
        self._digest: IHexDigest = digest

    @override
    def __str__(self) -> str:
        return str(self._digest)

    @property
    @override
    def name(self) -> str:
        return str(self._digest)

    @override
    def get_key_value(self) -> IHexDigest:
        return self._digest

    class Creator(IKeyCreator[IHexDigest]):
        @override
        def parse(self, key_name: str) -> ITypedKey[IHexDigest]:
            try:
                digest: IHexDigest = HexDigest.parse(key_name)
            except HexDigestError as ex:
                raise KeyParseError(ex) from ex
            return HexDigestKey(digest)

        @override
        def from_base_type(self, value: IHexDigest) -> ITypedKey[IHexDigest]:
            return HexDigestKey(value)

class VersionNumberItem(Item):
    def __init__(self, parent: IGroup | None, key: IKey | str) -> None:
        super().__init__(parent, key)
        self._version_number: IVersionNumber = VersionNumber(0, 0, 0)

    @property
    @override
    def is_mandatory(self) -> bool:
        return True

    @override
    def __str__(self) -> str:
        return str(self._version_number)

    @override
    def load(self, value: object) -> None:
        if not isinstance(value, str):
            msg = f"Key '{self.full_path}' value is not text"
            raise SchemaLoadError(msg)
        if not value:
            msg = f"Key '{self.full_path}' value is blank"
            raise SchemaLoadError(msg)

        try:
            self._version_number = VersionNumber.parse(value)
        except VersionNumberError as ex:
            msg = f"Key '{self.full_path}' value {ex}"
            raise SchemaLoadError(msg) from ex

    @override
    def save(self) -> str:
        return str(self._version_number)

    def get(self) -> IVersionNumber:
        return self._version_number

    def set(self, version_number: IVersionNumber) -> None:
        self._version_number = version_number

class HexDigestItem(Item):
    def __init__(self, parent: IGroup | None, key: IKey | str) -> None:
        super().__init__(parent, key)
        self._digest: IHexDigest = HexDigest(b'')

    @property
    @override
    def is_mandatory(self) -> bool:
        return True

    @override
    def __str__(self) -> str:
        return str(self._digest)

    @override
    def load(self, value: object) -> None:
        if not isinstance(value, str):
            msg = f"Key '{self.full_path}' value is not text"
            raise SchemaLoadError(msg)

        try:
            self._digest = HexDigest.parse(value)
        except HexDigestError as ex:
            msg = f"Key '{self.full_path}' value {ex}"
            raise SchemaLoadError(msg) from ex

    @override
    def save(self) -> str:
        return str(self._digest)

    def get(self) -> IHexDigest:
        return self._digest

    def set(self, digest: IHexDigest) -> None:
        self._digest = digest

class ConfigFileItem(Item, IConfigFile):
    def __init__(self, parent: IGroup | None, key: ITypedKey[int]) -> None:
        super().__init__(parent, key)
        self._config_key: int = key.get_key_value()
        self._filename: Path = Path()

    @property
    @override
    def is_mandatory(self) -> bool:
        return True

    @override
    def load(self, value: object) -> None:
        if not isinstance(value, str):
            msg = f"Key '{self.full_path}' value is not text"
            raise SchemaLoadError(msg)
        if not value:
            msg = f"Key '{self.full_path}' value is blank"
            raise SchemaLoadError(msg)
        self._filename = Path(value)

    @override
    def save(self) -> str:
        return str(self._filename)

    @property
    @override
    def config_key(self) -> int:
        return self._config_key

    @property
    @override
    def filename(self) -> Path:
        return self._filename

    def set_filename(self, value: Path) -> None:
        self._filename = value

class LaunchFileItem(Item, ILaunchFile):
    def __init__(self, parent: IGroup | None, key: ITypedKey[str]) -> None:
        super().__init__(parent, key)
        self._operating_system: str = key.get_key_value()
        self._filename: Path = Path()

    @property
    @override
    def is_mandatory(self) -> bool:
        return True

    @override
    def load(self, value: object) -> None:
        if not isinstance(value, str):
            msg = f"Key '{self.full_path}' value is not text"
            raise SchemaLoadError(msg)
        if not value:
            msg = f"Key '{self.full_path}' value is blank"
            raise SchemaLoadError(msg)
        self._filename = Path(value)

    @override
    def save(self) -> str:
        return str(self._filename)

    @property
    @override
    def operating_system(self) -> str:
        return self._operating_system

    @property
    @override
    def filename(self) -> Path:
        return self._filename

    def set_filename(self, value: Path) -> None:
        self._filename = value
