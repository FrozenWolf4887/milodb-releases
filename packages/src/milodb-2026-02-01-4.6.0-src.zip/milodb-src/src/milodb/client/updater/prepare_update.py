# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import hashlib
import json
import time
from collections.abc import Iterable, Sequence
from pathlib import Path
from typing import TYPE_CHECKING
from zipfile import ZIP_DEFLATED, ZipFile
from milodb.client.startup.shutdown_action import IShutdownAction, RestartToPerformUpdateAction
from milodb.client.updater.i_temp_directory import ITempDirectory, TempDirectoryError
from milodb.client.updater.manifest.update_directory import IAsset, IAssetRegister
from milodb.client.updater.manifest.update_sequence_schema import DeleteFile, DeleteFilesAction, EmplaceFile, EmplaceFilesAction, MoveFile, MoveFilesAction, SetFileAttribute, SetFilesAttributeAction, UpdateSequenceSchema
from milodb.client.updater.manifest.version_manifest import ICoreFile
from milodb.client.updater.update_strategy import FileRename, UpdateStrategy
from milodb.common.internet.i_scraper import IUrlScraper, IUrlScraperFactory
from milodb.common.output.print.i_printer import IPrinter
if TYPE_CHECKING:
    from milodb.common.internet.i_scraper import ScrapeResult

class PrepareUpdateError(Exception):
    pass

def prepare_update(
        update_strategy: UpdateStrategy,
        backup_directory: Path,
        time_stamp: time.struct_time,
        directory_url: str,
        asset_register: IAssetRegister,
        temp_directory: ITempDirectory,
        url_scraper_factory: IUrlScraperFactory,
        normal_printer: IPrinter) -> IShutdownAction:
    """Prepare the update.

    This fetches the new assets, backs up the existing files, saves the update sequence and application, and returns the
    shutdown action to apply the update.

    ### Raises
    - PrepareUpdateError
    """
    url_scraper: IUrlScraper
    with url_scraper_factory.new_pool(normal_printer.writeln) as url_scraper:
        list_of_files_to_emplace: Sequence[ICoreFile] = fetch_assets_to_temp_directory(update_strategy, directory_url, asset_register, temp_directory, url_scraper, normal_printer)
    backup_files(update_strategy, backup_directory, time_stamp, normal_printer)
    update_sequence: UpdateSequenceSchema = determine_update_sequence(update_strategy, temp_directory, list_of_files_to_emplace)
    update_sequence_filepath: Path = _save_update_sequence(update_sequence, temp_directory)
    normal_printer.writeln(f"Update sequence written to '{update_sequence_filepath}'")
    temp_application_filepath: Path = _save_copy_of_application(update_strategy, temp_directory)
    normal_printer.writeln(f"Temporary application saved to '{temp_application_filepath}'")
    return RestartToPerformUpdateAction(
        temp_application_filepath = temp_application_filepath,
        update_sequence_filepath = update_sequence_filepath,
    )

def fetch_assets_to_temp_directory(update_strategy: UpdateStrategy, directory_url: str, asset_register: IAssetRegister, temp_directory: ITempDirectory, url_scraper: IUrlScraper, normal_printer: IPrinter) -> Sequence[ICoreFile]:
    """Fetch the new assets to the temporary directory.

    ### Raises
    - PrepareUpdateError
    """
    list_of_files_to_acquire: Sequence[ICoreFile] = [
        *update_strategy.core_file_changes.list_of_new_files_to_acquire,
        *update_strategy.core_file_changes.list_of_missing_files_to_acquire,
        *update_strategy.core_file_changes.list_of_changed_files_to_acquire,
    ]

    normal_printer.writeln(f"Downloading {len(list_of_files_to_acquire)} assets")

    core_file: ICoreFile
    for core_file in list_of_files_to_acquire:
        normal_printer.writeln(f"  Fetching asset '{core_file.digest}' for file '{core_file.filename}'")

        asset: IAsset | None = asset_register.assets.get(core_file.digest)
        asset_url: str | None = asset_register.resolve_asset_url(directory_url, core_file.digest)
        if not asset or not asset_url:
            msg = f"Asset '{core_file.digest}' for file '{core_file.filename}' is not in the asset register"
            raise PrepareUpdateError(msg)

        def progress_callback(*, message: str | None, percentage_complete: int | None) -> None:
            _ = percentage_complete
            if message:
                normal_printer.writeln(f"    {message}")
        scrape_result: ScrapeResult = url_scraper.try_scrape_url(asset_url, progress_callback)
        if scrape_result.error_message:
            msg = f"Asset '{core_file.digest}' for file '{core_file.filename}' with URL '{asset_url}' download error: {scrape_result.error_message}"
            raise PrepareUpdateError(msg)

        if len(scrape_result.content) != asset.size:
            msg = f"Asset '{core_file.digest}' for file '{core_file.filename}' size mismatch: Expected {asset.size:,} bytes, got {len(scrape_result.content):,} bytes"
            raise PrepareUpdateError(msg)

        actual_digest: bytes = hashlib.sha3_224(scrape_result.content).digest()
        if core_file.digest.digest_bytes != actual_digest:
            msg = f"Asset '{core_file.digest}' for file '{core_file.filename}' integrity failure: Actual '{actual_digest.hex()}'"
            raise PrepareUpdateError(msg)

        try:
            temp_directory.store_file(Path(str(core_file.digest)), scrape_result.content)
        except TempDirectoryError as ex:
            msg = f"Asset '{core_file.digest}' for file '{core_file.filename}' failed to store in temp directory: {ex}"
            raise PrepareUpdateError(msg) from ex

    return list_of_files_to_acquire

def backup_files(update_strategy: UpdateStrategy, backup_directory: Path, time_stamp: time.struct_time, normal_printer: IPrinter) -> None:
    """Backup the files.

    ### Raises
    - PrepareUpdateError
    """
    list_of_files_to_backup: Iterable[Path] = [
        *update_strategy.backup_file_set.list_of_core_files_to_backup,
        *update_strategy.backup_file_set.list_of_config_files_to_backup,
        *update_strategy.backup_file_set.list_of_clobbered_files_to_backup,
    ]

    zip_filename: Path = Path(
        f'{time.strftime("%Y-%m-%d_%H-%M-%S", time_stamp)}'
        f'_{update_strategy.local_manifest.variant_name}_{update_strategy.local_manifest.version_number}.zip',
    )
    zip_filepath: Path = update_strategy.root_directory / backup_directory / zip_filename
    normal_printer.writeln(f"Backing up files to '{zip_filepath}'")

    try:
        zip_filepath.parent.mkdir(parents=True, exist_ok=True)
    except OSError as ex:
        raise PrepareUpdateError(ex) from ex

    try:
        with zip_filepath.open('wb') as raw_zip_file, ZipFile(raw_zip_file, mode='w', compression=ZIP_DEFLATED, compresslevel=9) as zip_file:
            source_filename: Path
            for source_filename in list_of_files_to_backup:
                source_path: Path = update_strategy.root_directory / source_filename
                if source_path.exists():
                    normal_printer.writeln(f"  Saving '{source_path}'")
                    zip_file.write(source_path, source_filename)
                else:
                    normal_printer.writeln(f"  Skipping '{source_path}'")
    except OSError as ex:
        raise PrepareUpdateError(ex) from ex

def determine_update_sequence(update_strategy: UpdateStrategy, temp_directory: ITempDirectory, list_of_files_to_emplace: Iterable[ICoreFile]) -> UpdateSequenceSchema:
    list_of_files_to_remove: Iterable[Path] = [
        file.filename for file in update_strategy.core_file_changes.list_of_changed_files_to_acquire
    ] + [
        *update_strategy.core_file_changes.list_of_files_that_are_deprecated,
        *update_strategy.config_file_changes.list_of_files_that_are_deprecated,
    ]

    update_sequence: UpdateSequenceSchema = UpdateSequenceSchema()

    update_sequence.field_root_directory.set(update_strategy.root_directory)
    update_sequence.field_temp_directory.set(temp_directory.path)

    delete_action: DeleteFilesAction = update_sequence.field_delete_files_actions.add_key(1)
    filename: Path
    for filename in list_of_files_to_remove:
        delete_item: DeleteFile = delete_action.add_item()
        delete_item.field_must_exist.set(False)
        delete_item.field_filename.set(filename)

    move_action: MoveFilesAction = update_sequence.field_move_files_actions.add_key(2)
    file_rename: FileRename
    for file_rename in update_strategy.config_file_changes.list_of_files_to_rename:
        move_item: MoveFile = move_action.add_item()
        move_item.field_must_exist.set(False)
        move_item.field_original_filename.set(file_rename.original_filename)
        move_item.field_new_filename.set(file_rename.new_filename)

    emplace_action: EmplaceFilesAction = update_sequence.field_emplace_files_actions.add_key(3)
    set_attributes_action: SetFilesAttributeAction = update_sequence.field_set_files_attribute_actions.add_key(4)
    core_file: ICoreFile
    for core_file in list_of_files_to_emplace:
        emplace_item: EmplaceFile = emplace_action.add_item()
        emplace_item.field_source_filename.set(Path(str(core_file.digest)))
        emplace_item.field_target_filename.set(core_file.filename)
        if core_file.exe:
            set_item: SetFileAttribute = set_attributes_action.field_files.add_item()
            set_item.field_filename.set(core_file.filename)
            set_item.field_is_executable.set(True)

    if update_strategy.launch_executable:
        update_sequence.field_launch_filename.set(update_strategy.launch_executable.filename)

    return update_sequence

def _save_update_sequence(update_sequence: UpdateSequenceSchema, temp_directory: ITempDirectory) -> Path:
    json_text: str = json.dumps(update_sequence.save(), indent=4, ensure_ascii=False, sort_keys=True)
    filename: Path = Path('update_sequence.json')
    filepath: Path = temp_directory.path_of(filename)
    try:
        temp_directory.store_file(filename, json_text.encode())
    except TempDirectoryError as ex:
        msg = f"Failed to save update sequence to '{filepath}': {ex}"
        raise PrepareUpdateError(msg) from ex

    return filepath

def _save_copy_of_application(update_strategy: UpdateStrategy, temp_directory: ITempDirectory) -> Path:
    filename: Path = Path(f'milodb-update-{update_strategy.current_executable_filename.name}')
    filepath: Path = temp_directory.path_of(filename)
    try:
        temp_directory.store_file(filename, update_strategy.current_executable_filename.read_bytes(), is_executable=True)
    except (TempDirectoryError, OSError) as ex:
        msg = f"Failed to save copy of application '{update_strategy.current_executable_filename}' to '{filepath}': {ex}"
        raise PrepareUpdateError(msg) from ex

    return filepath
