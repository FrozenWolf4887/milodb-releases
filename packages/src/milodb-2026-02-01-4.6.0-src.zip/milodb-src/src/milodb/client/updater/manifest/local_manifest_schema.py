# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import datetime
from collections.abc import Mapping, Sequence
from pathlib import Path
from typing import override
from milodb.client.updater.manifest.common_manifest import IConfigFile, IVersionNumber
from milodb.client.updater.manifest.common_manifest_schema import ConfigFileItem, VersionNumberItem, validate_format_field
from milodb.client.updater.manifest.cooked_schema_types import CookedDatumList, CookedDictionary
from milodb.client.updater.manifest.local_manifest import ILocalManifest
from milodb.client.updater.manifest.schema_types import DateItem, DynamicGroup, IntegerItem, IntegerKey, ListGroup, PathItem, StaticGroup, TextItem, root_key

_EXPECTED_FORMAT_VERSION: int = 1

class LocalManifestSchema(StaticGroup, ILocalManifest):
    def __init__(self) -> None:
        super().__init__(None, root_key())
        self.field_format = IntegerItem(self, 'format')
        self.field_format.set(_EXPECTED_FORMAT_VERSION)
        self.field_variant_name = TextItem(self, 'variant')
        self.field_version_number = VersionNumberItem(self, 'version')
        self.field_date = DateItem(self, 'date')
        self.field_core_files = ListGroup(self, 'coreFiles', PathItem)
        self.field_config_files = DynamicGroup(self, 'configFiles', IntegerKey.Creator(), ConfigFileItem)

    @override
    def load(self, value: object) -> None:
        validate_format_field(value, _EXPECTED_FORMAT_VERSION, 'local manifest')
        return super().load(value)

    @property
    @override
    def format(self) -> int:
        return self.field_format.get_item_value()

    @property
    @override
    def variant_name(self) -> str:
        return self.field_variant_name.get_item_value()

    @property
    @override
    def version_number(self) -> IVersionNumber:
        return self.field_version_number.get()

    @property
    @override
    def date(self) -> datetime.date:
        return self.field_date.get_item_value()

    @property
    @override
    def core_files(self) -> Sequence[Path]:
        return CookedDatumList(self.field_core_files.get())

    @property
    @override
    def config_files(self) -> Mapping[int, IConfigFile]:
        return CookedDictionary(self.field_config_files.get())
