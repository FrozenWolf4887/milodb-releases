# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from collections.abc import Iterator, Mapping, Sequence
from typing import overload, override
from milodb.client.updater.manifest.i_schema_types import IItem, ITypedItem, ITypedKey
from milodb.common.util.ref import IRef

class CookedDictionary[K, V: IItem](Mapping[K, V]):
    def __init__(self, mapping: Mapping[ITypedKey[K], V]) -> None:
        self._mapping: Mapping[ITypedKey[K], V] = mapping

    @override
    def __str__(self) -> str:
        return ', '.join(f'{{{key}: {value}}}' for key, value in self.items())

    @override
    def __len__(self) -> int:
        return len(self._mapping)

    @override
    def __getitem__(self, key: K, /) -> V:
        item: ITypedKey[K]
        value: V
        for item, value in self._mapping.items():
            if item.get_key_value() == key:
                return value
        raise KeyError

    @override
    def __iter__(self) -> Iterator[K]:
        key: ITypedKey[K]
        for key in self._mapping:
            yield key.get_key_value()

class CookedList[T](Sequence[T]):
    def __init__(self, sequence: Sequence[ITypedItem[T]]) -> None:
        self._sequence: Sequence[ITypedItem[T]] = sequence

    @overload
    def __getitem__(self, index: int) -> T:
        ...
    @overload
    def __getitem__(self, index: slice) -> Sequence[T]:
        ...
    @override
    def __getitem__(self, index: int | slice) -> T | Sequence[T]:
        if isinstance(index, slice):
            return [ item.get_item_value() for item in self._sequence.__getitem__(index) ]
        return self._sequence[index].get_item_value()

    @override
    def __len__(self) -> int:
        return len(self._sequence)

class CookedDatumList[T](Sequence[T]):
    def __init__(self, sequence: Sequence[ITypedItem[IRef[T]]]) -> None:
        self._sequence: Sequence[ITypedItem[IRef[T]]] = sequence

    @overload
    def __getitem__(self, index: int) -> T:
        ...
    @overload
    def __getitem__(self, index: slice) -> Sequence[T]:
        ...
    @override
    def __getitem__(self, index: int | slice) -> T | Sequence[T]:
        if isinstance(index, slice):
            return [ item.get_item_value().get() for item in self._sequence.__getitem__(index) ]
        return self._sequence[index].get_item_value().get()

    @override
    def __len__(self) -> int:
        return len(self._sequence)
