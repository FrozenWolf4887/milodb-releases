# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import stat
from collections.abc import Mapping, MutableMapping
from pathlib import Path
from typing import TYPE_CHECKING
from milodb.client.updater.i_temp_directory import ITempDirectory
from milodb.client.updater.manifest.update_sequence import IDeleteFile, IDeleteFilesAction, IEmplaceFile, IEmplaceFilesAction, IMoveFile, IMoveFilesAction, ISetFileAttribute, ISetFilesAttributeAction, IUpdateSequence
from milodb.client.updater.set_file_attributes import set_file_attributes
from milodb.client.updater.temp_directory import TempDirectory
from milodb.common.output.print.i_printer import IPrinter
if TYPE_CHECKING:
    from collections.abc import Sequence, Set as AbstractSet

class PerformUpdateError(Exception):
    pass

def perform_update(
        update_sequence: IUpdateSequence,
        normal_printer: IPrinter,
        warning_printer: IPrinter) -> None:
    """Perform the update according to the specified update_sequence.

    ### Raises
    - PerformUpdateError
    """
    temp_directory: ITempDirectory = TempDirectory(update_sequence.temp_directory)

    set_of_all_action_priorities: AbstractSet[int] = set(
        update_sequence.delete_files_actions.keys()).union(
        update_sequence.move_files_actions.keys()).union(
        update_sequence.emplace_files_actions.keys()).union(
        update_sequence.set_files_attribute_actions.keys())

    priority: int
    for priority in set_of_all_action_priorities:
        delete_action: IDeleteFilesAction | None = update_sequence.delete_files_actions.get(priority)
        if delete_action:
            perform_delete_action(update_sequence.root_directory, delete_action, normal_printer, warning_printer)
        move_action: IMoveFilesAction | None = update_sequence.move_files_actions.get(priority)
        if move_action:
            perform_move_action(update_sequence.root_directory, move_action, normal_printer)
        emplace_action: IEmplaceFilesAction | None = update_sequence.emplace_files_actions.get(priority)
        if emplace_action:
            perform_emplace_action(update_sequence.root_directory, temp_directory, emplace_action, normal_printer)
        set_attribute_action: ISetFilesAttributeAction | None = update_sequence.set_files_attribute_actions.get(priority)
        if set_attribute_action:
            perform_set_attribute_action(update_sequence.root_directory, set_attribute_action, normal_printer)

_MutableRecursiveDirectoryMap = MutableMapping[Path, '_MutableRecursiveDirectoryMap']
_RecursiveDirectoryMap = Mapping[Path, '_RecursiveDirectoryMap']

def perform_delete_action(root_directory: Path, delete_action: IDeleteFilesAction, normal_printer: IPrinter, warning_printer: IPrinter) -> None:
    """Remove the specified list of files and their directories if empty.

    ### Raises
    - PerformUpdateError
    """
    normal_printer.writeln('Removing files')

    file: IDeleteFile
    for file in delete_action.files:
        filepath: Path = root_directory / file.filename
        normal_printer.writeln(f"  Removing '{filepath}'")
        try:
            filepath.chmod(stat.S_IWUSR | stat.S_IWGRP | stat.S_IWOTH)
            filepath.unlink()
        except OSError as ex:
            if not isinstance(ex, FileNotFoundError) or file.must_exist:
                msg = f"Failed to remove file '{filepath}': {ex}"
                raise PerformUpdateError(msg) from ex

    normal_printer.writeln('Removing directories')

    map_of_directories: _MutableRecursiveDirectoryMap = {}
    for file in delete_action.files:
        sub_map: _MutableRecursiveDirectoryMap = map_of_directories
        for part in file.filename.parent.parts:
            sub_map = sub_map.setdefault(Path(part), {})

    _prune_directory_map(Path(root_directory), map_of_directories, normal_printer, warning_printer)

def _prune_directory_map(parent_path: Path, map_of_directories: _RecursiveDirectoryMap, normal_printer: IPrinter, warning_printer: IPrinter) -> None:
    dirname: Path
    sub_map: _RecursiveDirectoryMap
    for dirname, sub_map in map_of_directories.items():
        path: Path = parent_path / dirname
        if sub_map:
            _prune_directory_map(path, sub_map, normal_printer, warning_printer)

        dir_exists: bool
        has_contents: bool
        try:
            _ = next(path.iterdir())
        except StopIteration:
            dir_exists = True
            has_contents = False
        except FileNotFoundError:
            dir_exists = False
            has_contents = False
        except OSError as ex:
            warning_printer.writeln(f"Unable to check contents of directory '{path}': {ex}")
            dir_exists = True
            has_contents = True
        else:
            dir_exists = True
            has_contents = True

        if dir_exists and not has_contents:
            normal_printer.writeln(f"  Removing '{path}'")
            try:
                path.rmdir()
            except OSError as ex:
                warning_printer.writeln(f"  Failed to remove directory '{path}': {ex}")
        else:
            normal_printer.writeln(f"  Leaving populated directory '{path}'")

def perform_move_action(root_directory: Path, move_action: IMoveFilesAction, printer: IPrinter) -> None:
    """Perform the specified file move action.

    ### Raises
    - PerformUpdateError
    """
    printer.writeln('Moving files')
    file: IMoveFile
    for file in move_action.files:
        printer.writeln(f"  Move '{file.original_filename}' to '{file.new_filename}'")
        original_path: Path = root_directory / file.original_filename
        new_path: Path = root_directory / file.new_filename
        try:
            original_path.rename(new_path)
        except OSError as ex:
            if not isinstance(ex, FileNotFoundError) or file.must_exist:
                msg = f"Failed to rename file '{original_path}' to '{new_path}': {ex}"
                raise PerformUpdateError(msg) from ex

def perform_emplace_action(root_directory: Path, temp_directory: ITempDirectory, emplace_action: IEmplaceFilesAction, printer: IPrinter) -> None:
    """Perform the specified emplace file action.

    ### Raises
    - PerformUpdateError
    """
    printer.writeln('Emplacing files')

    file: IEmplaceFile
    for file in emplace_action.files:
        source_path: Path = temp_directory.path_of(file.source_filename)
        target_path: Path = root_directory / file.target_filename

        try:
            file_data: bytes = source_path.read_bytes()
        except OSError as ex:
            msg = f"Asset '{source_path}' for file '{target_path}' is unavailable: {ex}"
            raise PerformUpdateError(msg) from ex

        printer.writeln(f"  Emplacing '{file.target_filename}'")

        try:
            target_path.parent.mkdir(parents=True, exist_ok=True)
            target_path.write_bytes(file_data)
        except OSError as ex:
            msg = f"Failed to write file '{target_path}': {ex}"
            raise PerformUpdateError(msg) from ex

def perform_set_attribute_action(root_directory: Path, set_attribute_action: ISetFilesAttributeAction, printer: IPrinter) -> None:
    """Perform the specified set file attribute action.

    ### Raises
    - PerformUpdateError
    """
    printer.writeln('Setting file attributes')

    file: ISetFileAttribute
    for file in set_attribute_action.files:
        path: Path = root_directory / file.filename
        try:
            list_of_mode_changes: Sequence[str] = set_file_attributes(path, is_executable=file.is_executable, is_readonly=file.is_readonly)
        except OSError as ex:
            msg = f"Failed to set attributes of file '{path}': {ex}"
            raise PerformUpdateError(msg) from ex
        if list_of_mode_changes:
            printer.writeln(f"  Changed '{file.filename}' to {','.join(list_of_mode_changes)}")
