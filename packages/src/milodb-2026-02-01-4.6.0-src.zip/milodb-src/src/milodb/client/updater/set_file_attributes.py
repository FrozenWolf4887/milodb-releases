# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import stat
from collections.abc import Sequence
from pathlib import Path

def set_file_attributes(path: Path, *, is_executable: bool, is_readonly: bool) -> Sequence[str]:
    """Set the file attributes of the specified file.

    ### Returns
    List of textual names of the modes that were actually changed on the file.
    If the list is empty, the mode is already set as required on the file.

    ### Raises
    - OSError
        - If the file attributes cannot be retrieved or changed
    """
    original_mode: int = path.stat().st_mode

    new_mode: int = original_mode
    list_of_mode_changes: list[str] = []

    if is_executable:
        new_mode = new_mode | stat.S_IXUSR
        list_of_mode_changes.append('executable')
    if is_readonly:
        new_mode = new_mode & ~stat.S_IWUSR
        list_of_mode_changes.append('read-only')

    if new_mode != original_mode:
        path.chmod(new_mode)

    return list_of_mode_changes
