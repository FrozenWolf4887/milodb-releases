# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
import copy
import json
from collections.abc import MutableMapping
from pathlib import Path
from milodb_client.config.framework import IConfigGroup, IPersistentConfig
from milodb_common.output.print.i_printer import IPrinter

class JsonConfigFile(IPersistentConfig):
    def __init__(self, schema_root: IConfigGroup, filepath: Path) -> None:
        self._filepath: Path = filepath
        self._schema_root: IConfigGroup = schema_root
        self._config_dict: MutableMapping[object, object] = _copy_of_default_config(self._schema_root)
        self._load_was_successful: bool = True

    def load(self, normal_printer: IPrinter, warning_printer: IPrinter, error_printer: IPrinter) -> None:
        try:
            with self._filepath.open(encoding='utf-8') as file:
                self._config_dict = json.load(file)
        except FileNotFoundError:
            self._config_dict = _copy_of_default_config(self._schema_root)
            self.save(normal_printer, warning_printer, error_printer)
        except (OSError, json.JSONDecodeError) as ex:
            self._load_was_successful = False
            error_printer.writeln(f"Unable to load config from '{self._filepath}': {ex}")
            warning_printer.writeln("Config entries changed at runtime will not be saved to prevent corruption")
            normal_printer.writeln('Using default config')
            self._config_dict = _copy_of_default_config(self._schema_root)
        else:
            normal_printer.writeln(f"Loaded config from '{self._filepath}'")
            self._validate_config(normal_printer, warning_printer, error_printer)

    def save(self, normal_printer: IPrinter, warning_printer: IPrinter, error_printer: IPrinter) -> None:
        if self._load_was_successful:
            was_backup_successful: bool = False
            backup_filepath: Path = self._filepath.with_name(f'{self._filepath.name}.old')
            try:
                with self._filepath.open('rb') as file_in, backup_filepath.open('wb') as file_out:
                    file_out.write(file_in.read())
            except FileNotFoundError:
                was_backup_successful = True
            except OSError as ex:
                error_printer.writeln(f"Unable to backup config to file '{backup_filepath}': {ex}")
                warning_printer.writeln('Config not saved due to backup error')
            else:
                was_backup_successful = True

            if was_backup_successful:
                try:
                    with self._filepath.open("w", encoding='utf-8') as file:
                        json.dump(self._config_dict, file, indent=4, ensure_ascii=False, sort_keys=True)
                except OSError as ex:
                    error_printer.writeln(f"Unable to write config to file '{self._filepath}': {ex}")
                else:
                    normal_printer.writeln(f"Saved config file '{self._filepath}'")
        else:
            warning_printer.writeln('Config not saved due to initial loading error')

    def try_purge(self, normal_printer: IPrinter) -> bool:
        return self._schema_root.try_remove_redundancy(self._config_dict, normal_printer)

    @property
    def dictionary(self) -> MutableMapping[object, object]:
        return self._config_dict

    def _validate_config(self, normal_printer: IPrinter, warning_printer: IPrinter, error_printer: IPrinter) -> None:
        self._schema_root.validate_existing(self._config_dict, error_printer)
        self._schema_root.report_redundancy(self._config_dict, warning_printer)
        if self._schema_root.try_add_missing(self._config_dict, normal_printer):
            self.save(normal_printer, warning_printer, error_printer)

def _copy_of_default_config(schema_root: IConfigGroup) -> dict[object, object]:
    return dict(copy.deepcopy(schema_root.default_value))
