#!/usr/bin/env python3

import sys

ver_major, ver_minor, ver_micro, ver_releaselevel, ver_serial = sys.version_info
if ver_major != 3 or ver_minor < 7:
    print("Python version 3.7 or greater required")
    print("Actual version is " + sys.version)
    quit(1)

if __name__ == "__main__":
    from unittest import TestCase, TestLoader, TestResult, TestSuite
    from typing import Tuple
    test_suite: TestSuite = TestLoader().discover('.', 'test_*.py')
    test_result: TestResult = TestResult()
    test_suite.run(test_result)
    if test_result.wasSuccessful():
        print(f'\x1b[32mPASS\x1b[0m: {test_result.testsRun} tests ran successfully\n')
    else:
        failed_test: Tuple[TestCase, str]
        for failed_test in test_result.errors + test_result.failures:
            test_case: TestCase = failed_test[0]
            test_failure_text: str = failed_test[1]
            print(80 * '=')
            print(f'\x1b[35;1m{test_case}\x1b[0m')
            print(80 * '-')
            print(test_failure_text, end='')
        print(80 * '-')
        print(f'\x1b[31;1mFAIL\x1b[0m: {test_result.testsRun} tests run of which {len(test_result.errors)} errored and {len(test_result.failures)} failed\n')
