from typing import List, Optional, Union
from milodb.commands.argument_stream import ArgumentStream
from milodb.commands.command import CommandContext
from milodb.commands.parse_results import EmptyCommandParseResult, FailedCommandParseResult, SuccessfulCommandParseResult
from milodb.commands.parser import parse as parse_command
from milodb.tokeniser import ExpandingTokenStream

class InputSuggester:
    def __init__(self, context: CommandContext) -> None:
        self._context = context

    def try_get_possible_next_text(self, previous_text: str, text: str) -> Optional[List[str]]:
        list_of_expected_next_text: List[str] = []

        token_stream: ExpandingTokenStream = ExpandingTokenStream(previous_text, self._context.user_variables)
        argument_stream: ArgumentStream = ArgumentStream(token_stream)
        parse_result: Union[SuccessfulCommandParseResult, FailedCommandParseResult, EmptyCommandParseResult] = parse_command(argument_stream, self._context)
        if isinstance(parse_result, EmptyCommandParseResult):
            list_of_expected_next_text = parse_result.list_of_expected_text or []
        elif isinstance(parse_result, SuccessfulCommandParseResult):
            list_of_expected_next_text = parse_result.list_of_possible_next_text or []
        elif isinstance(parse_result, FailedCommandParseResult):
            if parse_result.fault_token:
                if parse_result.fault_token.outer_indices.end > len(previous_text):
                    list_of_expected_next_text = parse_result.list_of_expected_text or []
            else:
                list_of_expected_next_text = parse_result.list_of_expected_text or []

        if text.startswith('$'):
            list_of_expected_next_text.extend([ f'${name}' for name in self._context.user_variables.get_list_of_names() ])

        return [ x for x in list_of_expected_next_text if x.startswith(text) ]
