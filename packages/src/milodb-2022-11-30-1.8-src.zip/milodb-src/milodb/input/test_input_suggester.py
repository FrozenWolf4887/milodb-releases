from milodb.commands.argument_stream import ArgumentStream
from milodb.commands.command import Command, CommandContext, CommandFactory
from milodb.commands.parse_results import LoadError
from milodb.input.input_suggester import InputSuggester
from milodb.tokeniser import StartEnd, Token
from milodb.user_variables import UserVariables
import unittest
from typing import Dict, List, Optional, Type
from unittest.mock import Mock

class MockColourCommand(Command):
    def __init__(self, context: CommandContext) -> None:
        pass

    def load(self, argument_stream: ArgumentStream) -> Optional[List[str]]:
        return ['red', 'black', 'green', 'blue']

    def execute(self) -> None:
        pass

    @classmethod
    def get_one_line_summary(cls) -> str:
        return ''

    @classmethod
    def get_detailed_summary(cls, context: CommandContext) -> str:
        return ''

class MockFoodCommand(Command):
    def __init__(self, context: CommandContext) -> None:
        pass

    def load(self, argument_stream: ArgumentStream) -> Optional[List[str]]:
        return ['peach', 'apple', 'orange', 'pear']

    def execute(self) -> None:
        pass

    @classmethod
    def get_one_line_summary(cls) -> str:
        return ''

    @classmethod
    def get_detailed_summary(cls, context: CommandContext) -> str:
        return ''

class MockForceCommand(Command):
    def __init__(self, context: CommandContext) -> None:
        pass

    def load(self, argument_stream: ArgumentStream) -> Optional[List[str]]:
        return ['high', 'low']

    def execute(self) -> None:
        pass

    @classmethod
    def get_one_line_summary(cls) -> str:
        return ''

    @classmethod
    def get_detailed_summary(cls, context: CommandContext) -> str:
        return ''

class MockFailingCommand(Command):
    _exception: Optional[Exception] = None
    _pop_token_count: int = 0

    @classmethod
    def reset(cls) -> None:
        MockFailingCommand._exception = None
        MockFailingCommand._pop_token_count = 0

    @classmethod
    def set_exception(cls, exception: Exception) -> None:
        MockFailingCommand._exception = exception

    @classmethod
    def pop_token_count(cls, pop_token_count: int) -> None:
        MockFailingCommand._pop_token_count = pop_token_count

    def __init__(self, context: CommandContext) -> None:
        pass

    def load(self, argument_stream: ArgumentStream) -> Optional[List[str]]:
        for _ in range(MockFailingCommand._pop_token_count):
            argument_stream.pop_optional_token()
        if MockFailingCommand._exception:
            raise MockFailingCommand._exception
        return None

    def execute(self) -> None:
        pass

    @classmethod
    def get_one_line_summary(cls) -> str:
        return ''

    @classmethod
    def get_detailed_summary(cls, context: CommandContext) -> str:
        return ''

class TestInputSuggester(unittest.TestCase):
    def setUp(self) -> None:
        MockFailingCommand.reset()

        self.dictionary_of_variables: Dict[str, str] = {}
        self.dictionary_of_command_classes: Dict[str, Type[Command]] = {}

        mock_user_variables = Mock(UserVariables)
        mock_user_variables.try_retrieve = lambda name: self.dictionary_of_variables.get(name)
        mock_user_variables.get_list_of_names = lambda: list(self.dictionary_of_variables.keys())

        mock_command_factory = Mock(CommandFactory)
        mock_command_factory.try_get_command_class_from_name = lambda name: self.dictionary_of_command_classes.get(name)
        mock_command_factory.get_list_of_command_names = lambda: list(self.dictionary_of_command_classes.keys())

        command_context = Mock(CommandContext)
        command_context.user_variables = mock_user_variables
        command_context.command_factory = mock_command_factory

        self._input_suggester: InputSuggester = InputSuggester(command_context)

    def assert_next_text(self, previous_text: str, text: str, expected_list_of_text: List[str]) -> None:
        list_of_text: List[str] = self._input_suggester.try_get_possible_next_text(previous_text, text) or []
        self.assertListEqual(expected_list_of_text, list_of_text)

    def test_blank_previous_text_suggests_command_names(self):
        self.dictionary_of_command_classes = {
            'colour': MockColourCommand,
            'food': MockFoodCommand,
            'force': MockForceCommand
        }
        self.assert_next_text('', '', ['colour', 'food', 'force'])
        self.assert_next_text('', 'c', ['colour'])
        self.assert_next_text('', 'colo', ['colour'])
        self.assert_next_text('', 'colour', ['colour'])
        self.assert_next_text('', 'colu', [])
        self.assert_next_text('', 'colours', [])
        self.assert_next_text('', 'f', ['food', 'force'])
        self.assert_next_text('', 'fo', ['food', 'force'])
        self.assert_next_text('', 'for', ['force'])
        self.assert_next_text('', 'foo', ['food'])
        self.assert_next_text('', 'force', ['force'])
        self.assert_next_text('', 'forcey', [])
        self.assert_next_text('', 'food', ['food'])
        self.assert_next_text('', 'foody', [])

    def test_colour_command_suggests_colours(self):
        self.dictionary_of_command_classes = {
            'colour': MockColourCommand,
            'food': MockFoodCommand,
            'force': MockForceCommand
        }
        self.assert_next_text('colour', '', ['red', 'black', 'green', 'blue'])
        self.assert_next_text('colour', 'r', ['red'])
        self.assert_next_text('colour', 'red', ['red'])
        self.assert_next_text('colour', 'reds', [])
        self.assert_next_text('colour', 'g', ['green'])
        self.assert_next_text('colour', 'green', ['green'])
        self.assert_next_text('colour', 'greens', [])
        self.assert_next_text('colour', 'b', ['black', 'blue'])
        self.assert_next_text('colour', 'bl', ['black', 'blue'])
        self.assert_next_text('colour', 'blu', ['blue'])
        self.assert_next_text('colour', 'blue', ['blue'])
        self.assert_next_text('colour', 'bluez', [])
        self.assert_next_text('colour', 'bla', ['black'])
        self.assert_next_text('colour', 'black', ['black'])
        self.assert_next_text('colour', 'blackq', [])

    def test_force_command_suggests_levels(self):
        self.dictionary_of_command_classes = {
            'colour': MockColourCommand,
            'food': MockFoodCommand,
            'force': MockForceCommand
        }
        self.assert_next_text('force', '', ['high', 'low'])
        self.assert_next_text('force', 'h', ['high'])
        self.assert_next_text('force', 'high', ['high'])
        self.assert_next_text('force', 'highr', [])
        self.assert_next_text('force', 'l', ['low'])
        self.assert_next_text('force', 'low', ['low'])
        self.assert_next_text('force', 'lowd', [])

    def test_colour_command_suggests_colours_for_subsequent_token(self):
        self.dictionary_of_command_classes = {
            'colour': MockColourCommand
        }
        self.assert_next_text('colour red', '', ['red', 'black', 'green', 'blue'])
        self.assert_next_text('colour red', 'bl', ['black', 'blue'])
        self.assert_next_text('colour red', 'blue', ['blue'])
        self.assert_next_text('colour red green blue indigo violet', '', ['red', 'black', 'green', 'blue'])

    def test_load_error_provides_suggestions_without_error_token(self):
        self.dictionary_of_command_classes = {
            'bad': MockFailingCommand
        }
        MockFailingCommand.set_exception(LoadError('failed', None, None))
        self.assert_next_text('bad', '', [])
        self.assert_next_text('bad', 'ness', [])
        MockFailingCommand.set_exception(LoadError('failed', None, ['cat', 'dog']))
        self.assert_next_text('bad', '', ['cat', 'dog'])
        self.assert_next_text('bad', 'd', ['dog'])

    def test_load_error_provides_no_suggestions_when_error_token_is_part_of_previous_text(self):
        self.dictionary_of_command_classes = {
            'bad': MockFailingCommand
        }
        MockFailingCommand.pop_token_count(1)
        MockFailingCommand.set_exception(LoadError('failed', Token('speeling', 1, StartEnd(4, 12), StartEnd(4, 12)), ['spelling', 'bee']))
        self.assert_next_text('bad speeling', '', [])
        self.assert_next_text('bad speeling', 'bee', [])

    def test_load_error_provides_suggestions_when_error_token_is_after_previous_text(self):
        self.dictionary_of_command_classes = {
            'bad': MockFailingCommand
        }
        MockFailingCommand.pop_token_count(1)
        MockFailingCommand.set_exception(LoadError('failed', Token('s', 2, StartEnd(8, 9), StartEnd(8, 9)), ['spelling', 'bee', 'squidgy']))
        self.assert_next_text('bad bee', 's', ['spelling', 'squidgy'])
        MockFailingCommand.pop_token_count(1)
        MockFailingCommand.set_exception(LoadError('failed', Token('spe', 2, StartEnd(8, 11), StartEnd(8, 11)), ['spelling', 'bee', 'squidgy']))
        self.assert_next_text('bad bee', 'spe', ['spelling'])
