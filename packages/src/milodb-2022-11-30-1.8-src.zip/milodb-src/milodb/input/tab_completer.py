from milodb.input.input_suggester import InputSuggester
import readline
from typing import List, Optional

class TabCompleter:
    def __init__(self, input_suggester: InputSuggester) -> None:
        self._input_suggester: InputSuggester = input_suggester
        self._possible_next_text: Optional[List[str]] = None

        readline.parse_and_bind("tab: complete")
        readline.set_completer(self._input_completer)
        readline.set_completer_delims(' ()')

    def shutdown(self) -> None:
        readline.set_completer(None)

    def _input_completer(self, text: str, state: int) -> Optional[str]:
        if state == 0:
            previous_text: str = readline.get_line_buffer()[:readline.get_begidx()]
            self._possible_next_text = self._input_suggester.try_get_possible_next_text(previous_text, text)
            if self._possible_next_text:
                self._possible_next_text = [ x + ' ' for x in self._possible_next_text ]

        return self._possible_next_text[state] if self._possible_next_text and state < len(self._possible_next_text) else None
