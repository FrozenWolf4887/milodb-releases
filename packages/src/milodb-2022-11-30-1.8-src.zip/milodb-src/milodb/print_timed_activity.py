import time

class PrintTimedActivity:
    def __init__(self, prefix_text: str, suffix_text: str = ': ', seconds_width: int = 1) -> None:
        self._prefix_text: str = prefix_text
        self._suffix_text: str = suffix_text
        self._seconds_width: int = seconds_width
        self._start_millis: int = 0

    def __enter__(self) -> None:
        print(f"{self._prefix_text}", end='', flush=True)
        self._start_millis = self.now_millis()

    def __exit__(self, exc_type, exc_value, traceback) -> None:
        duration_millis: int = self.now_millis() - self._start_millis
        if not exc_type and not exc_value and not traceback:
            print(f"{self._suffix_text}{duration_millis // 1000:>{self._seconds_width}}.{duration_millis % 1000:>03}s")

    @staticmethod
    def now_millis() -> int:
        return int(round(time.time() * 1000))
