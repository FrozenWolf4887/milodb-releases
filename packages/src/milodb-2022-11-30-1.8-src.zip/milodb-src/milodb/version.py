from typing import Optional

MILODB_VERSION: Optional[str] = '1.8'
MILODB_DATE: Optional[str] = '2022-11-30'
