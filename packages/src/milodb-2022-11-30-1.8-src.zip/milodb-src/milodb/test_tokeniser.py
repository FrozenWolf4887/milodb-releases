from milodb.tokeniser import ExpandingTokenStream, StartEnd, Token, TokenStream, TokenStreamError
from milodb.user_variables import UserVariables
import unittest
from dataclasses import dataclass
from typing import Dict, List, Optional, Union
from unittest.mock import Mock

@dataclass
class SimpleToken:
    _text: str
    _start_index: int

    @property
    def text(self) -> str:
        return self._text

    @property
    def inner_indices(self) -> StartEnd:
        return StartEnd(self._start_index, self._start_index + len(self._text))

    @property
    def outer_indices(self) -> StartEnd:
        return self.inner_indices

@dataclass
class QuotedToken:
    _text: str
    _start_index: int
    _end_index: Optional[int] = None

    @property
    def text(self) -> str:
        return self._text

    @property
    def inner_indices(self) -> StartEnd:
        if self._end_index is not None:
            return StartEnd(self._start_index + 1, self._end_index - 1)
        else:
            return StartEnd(self._start_index + 1, self._start_index + 1 + len(self._text))

    @property
    def outer_indices(self) -> StartEnd:
        if self._end_index is not None:
            return StartEnd(self._start_index, self._end_index)
        else:
            return StartEnd(self._start_index, self._start_index + len(self._text) + 2)

class TestTokeniserBase(unittest.TestCase):
    _list_of_tokens: List[Token] = []
    _exception: Optional[TokenStreamError] = None

    def assert_successful(self) -> None:
        self.assertIsNone(self._exception,
            "Tokenisation should have been successful but wasn't")

    def assert_unsuccessful(self, error_msg: str, character_index: int, list_of_expected_text: Optional[List[str]]=None) -> None:
        if self._exception is not None:
            self.assertEqual(error_msg, self._exception.cause_of_fault_text,
                f"Expected error message of '{error_msg}' but got '{self._exception.cause_of_fault_text}'")
            self.assertEqual(character_index, self._exception.cause_of_fault_character_index,
                f'Expected character index of failed tokenisation at {character_index} but was {self._exception.cause_of_fault_character_index}')
            if list_of_expected_text is not None:
                self.assertIsNotNone(self._exception.list_of_expected_text, 'Expected list of expected text but was None')
                if self._exception.list_of_expected_text is not None:
                    self.assertSequenceEqual(list_of_expected_text, self._exception.list_of_expected_text)
            else:
                self.assertIsNone(self._exception.list_of_expected_text, f'Expected no list of expected text but got {self._exception.list_of_expected_text}')
        else:
            self.fail("Tokenisation should have failed but was successful")

    def assert_token_count(self, expected_count: int) -> None:
        actual_count: int = len(self._list_of_tokens)
        self.assertEqual(expected_count, actual_count,
            f'Expected {expected_count} tokens but there are {actual_count} tokens')

    def assert_tokens(self, list_of_expected_tokens: List[Union[SimpleToken, QuotedToken]]) -> None:
        self.assert_token_count(len(list_of_expected_tokens))
        token_number: int
        token: Token
        for token_number, token in enumerate(self._list_of_tokens):
            expected_text: str = list_of_expected_tokens[token_number].text
            expected_outer_indices: StartEnd = list_of_expected_tokens[token_number].outer_indices
            expected_inner_indices: StartEnd = list_of_expected_tokens[token_number].inner_indices

            self.assertEqual(token_number, token.token_number,
                f'Token #{token_number}: Expected token number of {token_number} but was {token.token_number}')
            self.assertEqual(expected_text, token.text,
                f"Token #{token_number}: Expected token text of '{expected_text}' but was '{token.text}'")
            self.assertEqual(expected_outer_indices, token.outer_indices,
                f'Token #{token_number}: Expected outer character indices of {expected_outer_indices} but was {token.outer_indices}')
            self.assertEqual(expected_inner_indices, token.inner_indices,
                f'Token #{token_number}: Expected inner character indices of {expected_inner_indices} but was {token.inner_indices}')

class TestTokenStream(TestTokeniserBase):
    def setUp(self) -> None:
        self._list_of_tokens = []
        self._exception = None
        self._token_stream: Optional[TokenStream] = None

    def read_tokens(self, text: str, stop_after: Optional[int]=None) -> None:
        if not self._token_stream:
            self._token_stream = TokenStream(text)

        if stop_after is None or stop_after > 0:
            try:
                token: Optional[Token] = self._token_stream.next()
                while token:
                    if stop_after is not None:
                        stop_after -= 1
                        if stop_after == 0:
                            break
                    self._list_of_tokens.append(token)
                    token = self._token_stream.next()
            except TokenStreamError as ex:
                self._exception = ex

    def assert_remaining_text(self, expected_text: str) -> None:
        self.assertIsNotNone(self._token_stream, "TokenStream has not been initialised")
        if self._token_stream:
            text: str = self._token_stream.get_remaining_raw_text()
            self.assertEqual(expected_text, text,
                f"Expected remaining text of '{expected_text}' but was '{text}'")

    def test_empty_input_returns_successful_with_empty_token_list(self):
        self.read_tokens('')
        self.assert_successful()
        self.assert_tokens([])

    def test_one_word_returns_one_token(self):
        self.read_tokens("hello_world")
        self.assert_successful()
        self.assert_tokens([
            SimpleToken("hello_world", 0)
        ])

    def test_one_word_with_pre_padding_returns_one_token(self):
        self.read_tokens(" hello_world")
        self.assert_successful()
        self.assert_tokens([
            SimpleToken("hello_world", 1)
        ])

    def test_one_word_with_post_padding_returns_one_token(self):
        self.read_tokens("hello_world ")
        self.assert_successful()
        self.assert_tokens([
            SimpleToken("hello_world", 0)
        ])

    def test_one_word_with_pre_and_post_padding_returns_one_token(self):
        self.read_tokens("  hello_world  ")
        self.assert_successful()
        self.assert_tokens([
            SimpleToken("hello_world", 2)
        ])

    def test_one_double_quoted_string_returns_one_token(self):
        self.read_tokens('"hello world"')
        self.assert_successful()
        self.assert_tokens([
            QuotedToken("hello world", 0)
        ])

    def test_one_double_quoted_string_with_pre_padding_returns_one_token(self):
        self.read_tokens(' "hello world"')
        self.assert_successful()
        self.assert_tokens([
            QuotedToken("hello world", 1)
        ])

    def test_one_double_quoted_string_with_post_padding_returns_one_token(self):
        self.read_tokens('"hello world" ')
        self.assert_successful()
        self.assert_tokens([
            QuotedToken("hello world", 0)
        ])

    def test_one_double_quoted_string_with_pre_and_post_padding_returns_one_token(self):
        self.read_tokens('  "hello world"  ')
        self.assert_successful()
        self.assert_tokens([
            QuotedToken("hello world", 2)
        ])

    def test_one_double_quoted_string_with_single_quote_returns_one_token(self):
        self.read_tokens('"isn\'t this nice"')
        self.assert_successful()
        self.assert_tokens([
            QuotedToken("isn't this nice", 0)
        ])

    def test_one_single_quoted_string_returns_one_token(self):
        self.read_tokens("'hello world'")
        self.assert_successful()
        self.assert_tokens([
            QuotedToken("hello world", 0)
        ])

    def test_one_single_quoted_string_with_pre_padding_returns_one_token(self):
        self.read_tokens(" 'hello world'")
        self.assert_successful()
        self.assert_tokens([
            QuotedToken("hello world", 1)
        ])

    def test_one_single_quoted_string_with_post_padding_returns_one_token(self):
        self.read_tokens("'hello world' ")
        self.assert_successful()
        self.assert_tokens([
            QuotedToken("hello world", 0)
        ])

    def test_one_single_quoted_string_with_pre_and_post_padding_returns_one_token(self):
        self.read_tokens("  'hello world'  ")
        self.assert_successful()
        self.assert_tokens([
            QuotedToken("hello world", 2)
        ])

    def test_one_single_quoted_string_with_double_quote_returns_one_token(self):
        self.read_tokens("'isn\"t this nice'")
        self.assert_successful()
        self.assert_tokens([
            QuotedToken('isn"t this nice', 0)
        ])

    def test_one_single_quoted_string_with_escaped_quote_returns_one_token(self):
        self.read_tokens("'isn\\'t this nice'")
        self.assert_successful()
        self.assert_tokens([
            QuotedToken("isn't this nice", 0, 18)
        ])

    def test_one_double_quoted_string_with_escaped_quote_returns_one_token(self):
        self.read_tokens('"isn\\"t this nice"')
        self.assert_successful()
        self.assert_tokens([
            QuotedToken('isn"t this nice', 0, 18)
        ])

    def test_two_words_returns_two_tokens(self):
        self.read_tokens("hello world")
        self.assert_successful()
        self.assert_tokens([
            SimpleToken('hello', 0),
            SimpleToken('world', 6)
        ])

    def test_two_words_with_padding_returns_two_tokens(self):
        self.read_tokens("   hello  world ")
        self.assert_successful()
        self.assert_tokens([
            SimpleToken('hello', 3),
            SimpleToken('world', 10)
        ])

    def test_one_open_bracket_returns_one_token(self):
        self.read_tokens("(")
        self.assert_successful()
        self.assert_tokens([
            SimpleToken('(', 0)
        ])

    def test_one_open_bracket_with_pre_padding_returns_one_token(self):
        self.read_tokens(" (")
        self.assert_successful()
        self.assert_tokens([
            SimpleToken('(', 1)
        ])

    def test_one_open_bracket_with_post_padding_returns_one_token(self):
        self.read_tokens("( ")
        self.assert_successful()
        self.assert_tokens([
            SimpleToken('(', 0)
        ])

    def test_one_open_bracket_with_pre_and_post_padding_returns_one_token(self):
        self.read_tokens("  (  ")
        self.assert_successful()
        self.assert_tokens([
            SimpleToken('(', 2)
        ])

    def test_two_open_brackets_returns_two_tokens(self):
        self.read_tokens("((")
        self.assert_successful()
        self.assert_tokens([
            SimpleToken('(', 0),
            SimpleToken('(', 1)
        ])

    def test_one_close_bracket_returns_one_token(self):
        self.read_tokens(")")
        self.assert_successful()
        self.assert_tokens([
            SimpleToken(')', 0)
        ])

    def test_one_close_bracket_with_pre_padding_returns_one_token(self):
        self.read_tokens(" )")
        self.assert_successful()
        self.assert_tokens([
            SimpleToken(')', 1)
        ])

    def test_one_close_bracket_with_post_padding_returns_one_token(self):
        self.read_tokens(") ")
        self.assert_successful()
        self.assert_tokens([
            SimpleToken(')', 0)
        ])

    def test_one_close_bracket_with_pre_and_post_padding_returns_one_token(self):
        self.read_tokens("  )  ")
        self.assert_successful()
        self.assert_tokens([
            SimpleToken(')', 2)
        ])

    def test_two_close_brackets_returns_two_tokens(self):
        self.read_tokens("))")
        self.assert_successful()
        self.assert_tokens([
            SimpleToken(')', 0),
            SimpleToken(')', 1)
        ])

    def test_word_followed_by_open_bracket_returns_two_tokens(self):
        self.read_tokens("hello(")
        self.assert_successful()
        self.assert_tokens([
            SimpleToken('hello', 0),
            SimpleToken('(', 5)
        ])

    def test_word_followed_by_open_bracket_and_word_returns_three_tokens(self):
        self.read_tokens("hello(world")
        self.assert_successful()
        self.assert_tokens([
            SimpleToken('hello', 0),
            SimpleToken('(', 5),
            SimpleToken('world', 6)
        ])

    def test_word_followed_by_open_bracket_and_word_with_padding_returns_three_tokens(self):
        self.read_tokens("    hello   (  world ")
        self.assert_successful()
        self.assert_tokens([
            SimpleToken('hello', 4),
            SimpleToken('(', 12),
            SimpleToken('world', 15)
        ])

    def test_word_followed_by_close_bracket_returns_two_tokens(self):
        self.read_tokens("hello)")
        self.assert_successful()
        self.assert_tokens([
            SimpleToken('hello', 0),
            SimpleToken(')', 5)
        ])

    def test_word_followed_by_close_bracket_and_word_returns_three_tokens(self):
        self.read_tokens("hello)world")
        self.assert_successful()
        self.assert_tokens([
            SimpleToken('hello', 0),
            SimpleToken(')', 5),
            SimpleToken('world', 6)
        ])

    def test_word_followed_by_close_bracket_and_word_with_padding_returns_three_tokens(self):
        self.read_tokens("    hello   )  world ")
        self.assert_successful()
        self.assert_tokens([
            SimpleToken('hello', 4),
            SimpleToken(')', 12),
            SimpleToken('world', 15)
        ])

    def test_unterminated_double_quoted_string_returns_error(self):
        self.read_tokens('"unterminated')
        self.assert_unsuccessful("String not terminated at end of text", 13)
        self.assert_tokens([])

    def test_unterminated_double_quoted_string_containing_single_quote_returns_error(self):
        self.read_tokens('"isn\'t')
        self.assert_unsuccessful("String not terminated at end of text", 6)
        self.assert_tokens([])

    def test_unterminated_double_quoted_string_with_previous_tokens_returns_error(self):
        self.read_tokens('hello world "unterminated')
        self.assert_unsuccessful("String not terminated at end of text", 25)
        self.assert_tokens([
            SimpleToken('hello', 0),
            SimpleToken('world', 6)
        ])

    def test_unterminated_single_quoted_string_returns_error(self):
        self.read_tokens("'unterminated")
        self.assert_unsuccessful("String not terminated at end of text", 13)
        self.assert_tokens([])

    def test_unterminated_single_quoted_string_containing_double_quote_returns_error(self):
        self.read_tokens("'isn\"t")
        self.assert_unsuccessful("String not terminated at end of text", 6)
        self.assert_tokens([])

    def test_unterminated_single_quoted_string_with_previous_tokens_returns_error(self):
        self.read_tokens("hello world 'unterminated")
        self.assert_unsuccessful("String not terminated at end of text", 25)
        self.assert_tokens([
            SimpleToken('hello', 0),
            SimpleToken('world', 6),
        ])

    def test_word_following_double_quoted_text_returns_error(self):
        self.read_tokens('"hello"world')
        self.assert_unsuccessful("Expecting delimiter", 7)
        self.assert_token_count(1)
        self.assert_tokens([
            QuotedToken('hello', 0)
        ])

    def test_trailing_escape_character_returns_error(self):
        self.read_tokens('hello\\')
        self.assert_unsuccessful("Trailing escape character at end of text", 6)
        self.assert_tokens([])

    def test_get_remaining_after_no_tokens_on_empty_input(self):
        self.read_tokens('', stop_after=0)
        self.assert_remaining_text('')

    def test_get_remaining_after_one_token_on_empty_input(self):
        self.read_tokens('', stop_after=1)
        self.assert_remaining_text('')

    def test_get_remaining_after_no_tokens_on_one_token_input(self):
        self.read_tokens('hello', stop_after=0)
        self.assert_remaining_text('hello')

    def test_get_remaining_after_one_token_on_one_token_input(self):
        self.read_tokens('hello', stop_after=1)
        self.assert_remaining_text('')

    def test_get_remaining_after_no_tokens_on_two_token_input(self):
        self.read_tokens('hello world', stop_after=0)
        self.assert_remaining_text('hello world')

    def test_get_remaining_after_one_token_on_two_token_input(self):
        self.read_tokens('hello world', stop_after=1)
        self.assert_remaining_text(' world')

    def test_get_remaining_after_two_tokens_on_two_token_input(self):
        self.read_tokens('hello world', stop_after=2)
        self.assert_remaining_text('')

    def test_get_remaining_after_one_token_on_two_spaced_token_input(self):
        self.read_tokens('hello   world ', stop_after=1)
        self.assert_remaining_text('   world ')

    def test_get_remaining_after_no_tokens_on_multi_token_input(self):
        self.read_tokens('mary  had   a    little     lamb', stop_after=0)
        self.assert_remaining_text('mary  had   a    little     lamb')

    def test_get_remaining_after_one_token_on_multi_token_input(self):
        self.read_tokens('mary  had   a    little     lamb', stop_after=1)
        self.assert_remaining_text('  had   a    little     lamb')

    def test_get_remaining_after_no_tokens_on_bracketed_token_input(self):
        self.read_tokens('mary(had   a    little     lamb', stop_after=0)
        self.assert_remaining_text('mary(had   a    little     lamb')

    def test_get_remaining_after_one_token_on_bracketed_token_input(self):
        self.read_tokens('mary(had   a    little     lamb', stop_after=1)
        self.assert_remaining_text('(had   a    little     lamb')

    def test_get_remaining_after_one_token_on_partly_quoted_token_input(self):
        self.read_tokens('mary had  "a    little     lamb', stop_after=1)
        self.assert_remaining_text(' had  "a    little     lamb')

class TestExpandingTokenStream(TestTokeniserBase):
    def setUp(self) -> None:
        self._list_of_tokens = []
        self._exception = None
        self._token_stream: Optional[ExpandingTokenStream] = None
        self._mock_variables = Mock(UserVariables)
        self._dictionary_of_variables: Dict[str, str] = {}
        self._mock_variables.try_retrieve = lambda name: self._dictionary_of_variables.get(name)
        self._mock_variables.get_list_of_names = lambda: list(self._dictionary_of_variables.keys())

    def add_variable(self, name: str, value: str) -> None:
        self._dictionary_of_variables[name] = value

    def init(self, text: str):
        self.assertIsNone(self._token_stream)
        self._token_stream = ExpandingTokenStream(text, self._mock_variables)

    def init_and_read_tokens(self, text: str, stop_after: Optional[int]=None) -> None:
        self.init(text)
        self.read_tokens(stop_after)

    def read_tokens(self, stop_after: Optional[int]=None) -> None:
        self.assertIsNotNone(self._token_stream)
        if self._token_stream and (stop_after is None or stop_after > 0):
            try:
                token: Optional[Token] = self._token_stream.next()
                while token:
                    self._list_of_tokens.append(token)
                    if stop_after is not None:
                        stop_after -= 1
                        if stop_after == 0:
                            break
                    token = self._token_stream.next()
            except TokenStreamError as ex:
                self._exception = ex

    def disable_expansion(self) -> None:
        self.assertIsNotNone(self._token_stream)
        if self._token_stream:
            self._token_stream.disable_expansion()

    def assert_remaining_text(self, expected_text: str) -> None:
        self.assertIsNotNone(self._token_stream, "TokenStream has not been initialised")
        if self._token_stream:
            text: str = self._token_stream.get_remaining_raw_text()
            self.assertEqual(expected_text, text,
                f"Expected remaining text of '{expected_text}' but was '{text}'")

    def test_single_variable_alone(self):
        self.add_variable('cheese', 'mango')
        self.init_and_read_tokens('$cheese')
        self.assert_successful()
        self.assert_tokens([
            SimpleToken('mango', 0)
        ])

    def test_single_variable_with_space(self):
        self.add_variable('apple', 'banana')
        self.init_and_read_tokens('   $apple   ')
        self.assert_successful()
        self.assert_tokens([
            SimpleToken('banana', 3)
        ])

    def test_single_variable_at_the_start_of_text(self):
        self.add_variable('pear', 'tomato')
        self.init_and_read_tokens('$pear soup')
        self.assert_successful()
        self.assert_tokens([
            SimpleToken('tomato', 0),
            SimpleToken('soup', 7)
        ])

    def test_single_variable_at_the_end_of_text(self):
        self.add_variable('d', 'fondant')
        self.init_and_read_tokens('chocolate $d')
        self.assert_successful()
        self.assert_tokens([
            SimpleToken('chocolate', 0),
            SimpleToken('fondant', 10)
        ])

    def test_single_variable_in_the_middle_of_text(self):
        self.add_variable('myvar', 'caffeine')
        self.init_and_read_tokens('I need $myvar please')
        self.assert_successful()
        self.assert_tokens([
            SimpleToken('I', 0),
            SimpleToken('need', 2),
            SimpleToken('caffeine', 7),
            SimpleToken('please', 16)
        ])

    def test_double_quoted_variable_is_expanded(self):
        self.add_variable('myvar', 'coffee')
        self.init_and_read_tokens('I need "$myvar" please')
        self.assert_successful()
        self.assert_tokens([
            SimpleToken('I', 0),
            SimpleToken('need', 2),
            SimpleToken('coffee', 7),
            SimpleToken('please', 14)
        ])

    def test_single_quoted_variable_is_expanded(self):
        self.add_variable('myvar', 'coffee')
        self.init_and_read_tokens("I need '$myvar' please")
        self.assert_successful()
        self.assert_tokens([
            SimpleToken('I', 0),
            SimpleToken('need', 2),
            SimpleToken('coffee', 7),
            SimpleToken('please', 14)
        ])

    def test_escaped_variable_is_not_expanded(self):
        self.add_variable('myvar', 'coffee')
        self.init_and_read_tokens("I need $$myvar please")
        self.assert_successful()
        self.assert_tokens([
            SimpleToken('I', 0),
            SimpleToken('need', 2),
            SimpleToken('$$myvar', 7),
            SimpleToken('please', 15)
        ])

    def test_variable_at_start_with_spaces_is_expanded(self):
        self.add_variable('listOfFruit', 'apple, orange and pear')
        self.init_and_read_tokens('$listOfFruit fruits')
        self.assert_successful()
        self.assert_tokens([
            SimpleToken('apple,', 0),
            SimpleToken('orange', 7),
            SimpleToken('and', 14),
            SimpleToken('pear', 18),
            SimpleToken('fruits', 23)
        ])

    def test_variable_at_end_with_spaces_is_expanded(self):
        self.add_variable('listOfFruit', 'apple, orange and pear')
        self.init_and_read_tokens('fruits: $listOfFruit')
        self.assert_successful()
        self.assert_tokens([
            SimpleToken('fruits:', 0),
            SimpleToken('apple,', 8),
            SimpleToken('orange', 15),
            SimpleToken('and', 22),
            SimpleToken('pear', 26)
        ])

    def test_variable_in_middle_with_spaces_is_expanded(self):
        self.add_variable('listOfFruit', 'apple, orange and pear')
        self.init_and_read_tokens('fruits: $listOfFruit with cheese')
        self.assert_successful()
        self.assert_tokens([
            SimpleToken('fruits:', 0),
            SimpleToken('apple,', 8),
            SimpleToken('orange', 15),
            SimpleToken('and', 22),
            SimpleToken('pear', 26),
            SimpleToken('with', 31),
            SimpleToken('cheese', 36)
        ])

    def test_variable_before_open_bracket_is_expanded(self):
        self.add_variable('oldFruit', 'mango')
        self.init_and_read_tokens('$oldFruit(rotting')
        self.assert_successful()
        self.assert_tokens([
            SimpleToken('mango', 0),
            SimpleToken('(', 5),
            SimpleToken('rotting', 6)
        ])

    def test_variable_before_close_bracket_is_expanded(self):
        self.add_variable('oldFruit', 'mango')
        self.init_and_read_tokens('$oldFruit)rotting')
        self.assert_successful()
        self.assert_tokens([
            SimpleToken('mango', 0),
            SimpleToken(')', 5),
            SimpleToken('rotting', 6)
        ])

    def test_variable_expansion_handles_surrounding_spaces(self):
        self.add_variable('car', '  four  wheeler  ')
        self.init_and_read_tokens('I need a   $car  now')
        self.assert_successful()
        self.assert_tokens([
            SimpleToken('I', 0),
            SimpleToken('need', 2),
            SimpleToken('a', 7),
            SimpleToken('four', 13),
            SimpleToken('wheeler', 19),
            SimpleToken('now', 28)
        ])

    def test_variable_with_invalid_name_errors(self):
        self.add_variable('car', 'formula 1 car')
        self.init_and_read_tokens('I need a $c=ar  ')
        self.assert_unsuccessful(r"Invalid variable reference '$c=ar' does not match pattern '\$[\w\-\+]+'", 9, [ '$car' ])

    def test_multiple_identical_variables_are_expanded(self):
        self.add_variable('animal', 'dog')
        self.init_and_read_tokens('the $animal sat on the other $animal')
        self.assert_successful()
        self.assert_tokens([
            SimpleToken('the', 0),
            SimpleToken('dog', 4),
            SimpleToken('sat', 8),
            SimpleToken('on', 12),
            SimpleToken('the', 15),
            SimpleToken('other', 19),
            SimpleToken('dog', 25)
        ])

    def test_multiple_different_variables_are_expanded(self):
        self.add_variable('colour', 'ginger')
        self.add_variable('animal', 'cat')
        self.add_variable('action', 'sat')
        self.init_and_read_tokens('the $colour $animal $action on the mat')
        self.assert_successful()
        self.assert_tokens([
            SimpleToken('the', 0),
            SimpleToken('ginger', 4),
            SimpleToken('cat', 11),
            SimpleToken('sat', 15),
            SimpleToken('on', 19),
            SimpleToken('the', 22),
            SimpleToken('mat', 26)
        ])

    def test_expansion_is_recursive_once(self):
        self.add_variable('colouredAnimal', 'ginger $animal')
        self.add_variable('animal', 'cat')
        self.init_and_read_tokens('$colouredAnimal')
        self.assert_successful()
        self.assert_tokens([
            SimpleToken('ginger', 0),
            SimpleToken('cat', 7)
        ])

    def test_expansion_is_recursive_twice(self):
        self.add_variable('shape', 'rotund')
        self.add_variable('colour', 'grey')
        self.add_variable('animal', '$shape cat')
        self.add_variable('colouredAnimal', '$colour $animal')
        self.init_and_read_tokens('$colouredAnimal')
        self.assert_successful()
        self.assert_tokens([
            SimpleToken('grey', 0),
            SimpleToken('rotund', 5),
            SimpleToken('cat', 12)
        ])

    def test_unknown_variable_causes_an_error(self):
        self.init_and_read_tokens('my $mind hurts')
        self.assert_unsuccessful("Unknown variable reference '$mind'", 3, [] )

    def test_unknown_variable_lists_all_variables(self):
        self.add_variable('chair', 'upright')
        self.add_variable('book', 'gone with the wind')
        self.add_variable('music', 'jazz')
        self.init_and_read_tokens('the $tree')
        self.assert_unsuccessful("Unknown variable reference '$tree'", 4, [ '$chair', '$book', '$music' ])

    def test_flat_reentrant_expansion_causes_an_error(self):
        self.add_variable('shape', '$shape')
        self.init_and_read_tokens('$shape')
        self.assert_unsuccessful("Recursive variable reference detected: '$shape' -> '$shape'", 0)

    def test_deep_reentrant_expansion_causes_an_error(self):
        self.add_variable('onion', 'a $edible')
        self.add_variable('veg', '$onion')
        self.add_variable('edible', '$veg')
        self.init_and_read_tokens('$edible')
        self.assert_unsuccessful("Recursive variable reference detected: '$edible' -> '$veg' -> '$onion' -> '$edible'", 2)

    def test_disable_expansion_prevents_expansion_at_start(self):
        self.add_variable('tomato', 'potato')
        self.init('I like $tomato soup')
        self.disable_expansion()
        self.read_tokens()
        self.assert_successful()
        self.assert_tokens([
            SimpleToken('I', 0),
            SimpleToken('like', 2),
            SimpleToken('$tomato', 7),
            SimpleToken('soup', 15)
        ])

    def test_disable_expansion_prevents_expansion_before_variable(self):
        self.add_variable('tomato', 'potato')
        self.init('I eat $tomato pieces')
        self.read_tokens(2)
        self.disable_expansion()
        self.read_tokens()
        self.assert_successful()
        self.assert_tokens([
            SimpleToken('I', 0),
            SimpleToken('eat', 2),
            SimpleToken('$tomato', 6),
            SimpleToken('pieces', 14)
        ])

    def test_disable_expansion_allows_expansion_after_variable(self):
        self.add_variable('tomato', 'potato')
        self.add_variable('action', 'chew')
        self.init('I $action $tomato slices')
        self.read_tokens(2)
        self.disable_expansion()
        self.read_tokens()
        self.assert_successful()
        self.assert_tokens([
            SimpleToken('I', 0),
            SimpleToken('chew', 2),
            SimpleToken('$tomato', 7),
            SimpleToken('slices', 15)
        ])

    def test_get_remaining_after_no_tokens_and_before_variable_expansion_on_first_token(self):
        self.init('$people $action pizza')
        self.assert_remaining_text('$people $action pizza')

    def test_get_remaining_after_no_tokens_and_before_variable_expansion_on_second_token(self):
        self.init('We $action pizza')
        self.assert_remaining_text('We $action pizza')

    def test_get_remaining_after_one_token_and_before_variable_expansion_on_first_token(self):
        self.add_variable('people', 'They')
        self.init_and_read_tokens('$people $action pizza', 1)
        self.assert_remaining_text(' $action pizza')

    def test_get_remaining_after_one_token_and_before_variable_expansion_on_second_token(self):
        self.init_and_read_tokens('We $action pizza', 1)
        self.assert_remaining_text(' $action pizza')

    def test_get_remaining_after_one_token_and_one_token_variable(self):
        self.add_variable('action', 'chew')
        self.init_and_read_tokens('I $action $tomato slices', 2)
        self.assert_remaining_text(' $tomato slices')

    def test_get_remaining_after_two_tokens_within_multi_token_variable(self):
        self.add_variable('tomato', 'potato')
        self.add_variable('action', 'bite and chew')
        self.init_and_read_tokens('I $action $tomato slices', 2)
        self.assert_remaining_text(' and chew $tomato slices')

    def test_get_remaining_with_recursive_variables(self):
        self.add_variable('animal', '$colour $size cat')
        self.add_variable('colour', 'grey')
        self.init_and_read_tokens('The $animal slept', 2)
        self.assert_remaining_text(' $size cat slept')

    def test_get_remaining_preserves_spaces(self):
        self.add_variable('animal', '     $colour   $size  cat')
        self.add_variable('colour', ' grey  ')
        self.init_and_read_tokens('  The    $animal     slept        ', 2)
        self.assert_remaining_text('     $size  cat     slept        ')
