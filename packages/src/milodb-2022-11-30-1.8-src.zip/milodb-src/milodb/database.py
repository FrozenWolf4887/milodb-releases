import milodb.query as query
from milodb.print_timed_activity import PrintTimedActivity
from milodb.tease import Tease
import datetime
import json
import lzma
from dataclasses import dataclass
from typing import Any, Optional, List

@dataclass
class PostfixQueryResult:
    total_match_count: int
    max_match_count: int
    was_max_match_count_reached: bool
    total_tease_count: int
    queried_tease_count: int
    list_of_matching_teases: List[query.TeaseMatch]

class Database:
    def __init__(self) -> None:
        self._list_of_teases: List[Tease] = []

    def load_from_file(self, database_filepath: str) -> None:
        self._list_of_teases = []

        try:
            with PrintTimedActivity('Load database\n', 'Load completed: '):
                with PrintTimedActivity('  Read', '     : '):
                    with open(database_filepath, 'rb') as file:
                        raw_file_contents: bytes = file.read()
                with PrintTimedActivity('  Unpack', '   : '):
                    file_contents: bytes = lzma.decompress(raw_file_contents)
                with PrintTimedActivity('  Parse', '    : '):
                    json_root: Any = json.loads(file_contents)
                with PrintTimedActivity('  Assemble', ' : '):
                    if isinstance(json_root, list):
                        for tease_obj in json_root:
                            if isinstance(tease_obj, dict):
                                self._list_of_teases.append(Tease(tease_obj))
                            else:
                                raise self._LoadError('Tease entry is not a dictionary')
                    else:
                        raise self._LoadError('Database root is not a list')

        except IOError as ex:
            print(f"\nFile access error: {ex}")
        except lzma.LZMAError as ex:
            print(f"\nUnpack error: {ex}")
        except json.JSONDecodeError as ex:
            print(f"\nJSON decode error: {ex}")
        except self._LoadError as ex:
            print(f"\nAssembly error: {ex}")
        except Tease.LoadError as ex:
            print(f"\nTease error: {ex}")

    @property
    def list_of_teases(self) -> List[Tease]:
        return self._list_of_teases

    def try_get_oldest_tease_date(self) -> Optional[datetime.date]:
        oldest_tease_date: Optional[datetime.date] = None
        tease: Tease
        for tease in self._list_of_teases:
            if oldest_tease_date is not None:
                if tease.date < oldest_tease_date:
                    oldest_tease_date = tease.date
            else:
                oldest_tease_date = tease.date
        return oldest_tease_date

    def try_get_newest_tease_date(self) -> Optional[datetime.date]:
        newest_tease_date: Optional[datetime.date] = None
        tease: Tease
        for tease in self._list_of_teases:
            if newest_tease_date is not None:
                if tease.date > newest_tease_date:
                    newest_tease_date = tease.date
            else:
                newest_tease_date = tease.date
        return newest_tease_date

    def run_postfix_query_chain(self, chain_of_postfix_queries: List[query.QueryBase], max_match_count: int) -> PostfixQueryResult:
        list_of_matching_teases: List[query.TeaseMatch] = []

        index_of_match: int = 1
        total_match_count: int = 0
        was_max_match_count_reached: bool = False
        index_of_tease: int = 0
        tease: Tease
        for index_of_tease, tease in enumerate(self._list_of_teases):
            stack_of_match_results: List[query.MatchResult] = []

            query_object: query.QueryBase
            for query_object in chain_of_postfix_queries:
                query_object.perform_query(stack_of_match_results, tease)

            if len(stack_of_match_results) == 1:
                match_result: query.MatchResult = stack_of_match_results[0]
                if isinstance(match_result, query.TrueMatchResult):
                    match_count: int = match_result.get_match_count()
                    if total_match_count + match_count <= max_match_count:
                        list_of_matching_teases.append(query.TeaseMatch(index_of_match, tease, match_result.list_of_query_matches))
                        total_match_count += match_count
                    else:
                        was_max_match_count_reached = True
                        break
                    index_of_match += 1
            else:
                raise query.QueryException("Bad expression: Expected a single result remaining on the stack", None)

        return PostfixQueryResult(total_match_count, max_match_count, was_max_match_count_reached, len(self._list_of_teases), index_of_tease, list_of_matching_teases)

    def try_get_tease(self, tease_id: int) -> Optional[Tease]:
        tease: Tease
        for tease in self._list_of_teases:
            if tease_id == tease.tease_id:
                return tease

        return None

    def get_teases_by_author_id(self, author_id: int) -> List[Tease]:
        list_of_teases: List[Tease] = []

        tease: Tease
        for tease in self._list_of_teases:
            if author_id == tease.author_id:
                list_of_teases.append(tease)

        return list_of_teases

    class _LoadError(Exception):
        pass
