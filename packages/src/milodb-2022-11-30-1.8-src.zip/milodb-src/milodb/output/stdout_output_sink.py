from milodb.output.output_sink import OutputSink
from typing import Optional

class StdoutOutputSink(OutputSink):
    def write(self, text: str) -> None:
        print(text, end='')

    def writeln(self, text: Optional[str] = None) -> None:
        if text:
            print(text)
        else:
            print()
