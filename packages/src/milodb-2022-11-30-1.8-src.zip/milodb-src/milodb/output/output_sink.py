from abc import ABC, abstractmethod
from typing import Optional

class OutputSink(ABC):
    @abstractmethod
    def write(self, text: str) -> None:
        pass

    @abstractmethod
    def writeln(self, text: Optional[str] = None) -> None:
        pass

    def writeln_warning(self, text: str) -> None:
        self.writeln(f'Warning: {text}')

    def writeln_error(self, text: str) -> None:
        self.writeln(f'Error: {text}')
