from milodb.output.output_sink import OutputSink
from typing import IO, Optional

class FileOutputSink(OutputSink):
    def __init__(self, file: IO[str]) -> None:
        self._file: IO[str] = file

    def write(self, text: str) -> None:
        self._file.write(text)

    def writeln(self, text: Optional[str] = None) -> None:
        if text:
            self._file.write(text)
        self._file.write('\n')
