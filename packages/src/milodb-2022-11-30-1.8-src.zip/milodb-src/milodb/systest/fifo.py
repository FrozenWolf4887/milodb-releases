import os
import time
from datetime import datetime, timedelta
from typing import Optional, TextIO

class InputFifo:
    def __init__(self, filepath: str) -> None:
        self._filepath: str = filepath
        self._file: Optional[TextIO] = None
        self._is_logging_available: bool = False

    def __enter__(self) -> 'InputFifo':
        self._file = open(self._filepath, 'wt')
        return self

    def __exit__(self, exc_type, exc_value, traceback) -> None:
        if self._file:
            self._file.close()

    def send(self, message: str) -> None:
        if self._file:
            self._file.write(f'{message}\n')
            self._file.flush()

class OutputFifo:
    def __init__(self, filepath: str) -> None:
        self._filepath: str = filepath
        self._file: Optional[int] = None
        self._is_logging_available: bool = False

    def __enter__(self) -> 'OutputFifo':
        self._file = os.open(self._filepath, os.O_RDONLY | os.O_NONBLOCK)
        return self

    def __exit__(self, exc_type, exc_value, traceback) -> None:
        if self._file:
            os.close(self._file)

    def read_line(self, timeout: timedelta = timedelta(seconds=5)) -> Optional[str]:
        if not self._file:
            return None

        start_time: datetime = datetime.now()
        all_data: bytearray = bytearray()
        end_of_line: bool = False
        should_yield: bool = False
        while not end_of_line:
            elapsed_time: timedelta = datetime.now() - start_time
            if elapsed_time > timeout:
                return None

            try:
                should_yield = False
                data: bytes = os.read(self._file, 1)
                if data:
                    if data[0] == 10:
                        end_of_line = True
                    else:
                        all_data.append(data[0])
                else:
                    should_yield = True
            except OSError as ex:
                if ex.errno == 11:
                    should_yield = True
                else:
                    raise ex

            if should_yield:
                time.sleep(0.1)

        return all_data.decode(encoding='UTF-8')

    def read_some(self, number_of_bytes: int, timeout: timedelta = timedelta(seconds=5)) -> Optional[bytes]:
        if not self._file:
            return None

        start_time: datetime = datetime.now()
        all_bytes: bytearray = bytearray()
        should_yield: bool = False
        while number_of_bytes > 0:
            elapsed_time: timedelta = datetime.now() - start_time
            if elapsed_time > timeout:
                return None

            try:
                should_yield = False
                chars: bytes = os.read(self._file, 1)
                if chars:
                    all_bytes.append(chars[0])
                    number_of_bytes -= 1
                else:
                    should_yield = True
            except OSError as ex:
                if ex.errno == 11:
                    should_yield = True
                else:
                    raise ex

            if should_yield:
                time.sleep(0.1)

        return all_bytes
