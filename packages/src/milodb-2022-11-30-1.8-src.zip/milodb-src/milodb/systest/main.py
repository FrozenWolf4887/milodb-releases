from milodb.systest.fifo import InputFifo, OutputFifo
from milodb.systest.logger import Logger
from milodb.systest.options import Options
from milodb.systest.test_framework import TestFail
from milodb.systest.test_suite import TestSuite

class Main:
    def __init__(self, options: Options) -> None:
        self._was_successful: bool = False
        try:
            logger: Logger
            input_fifo: InputFifo
            output_fifo: OutputFifo
            with Logger(options.log_filepath) as logger:
                try:
                    with InputFifo(options.input_fifo_filepath) as input_fifo:
                        with OutputFifo(options.output_fifo_filepath) as output_fifo:
                            TestSuite(logger, input_fifo, output_fifo, options)
                            self._was_successful = True
                except TestFail:
                    logger.log_info('Test failed, aborting')
                    self._was_successful = False
        except IOError as ex:
            print(f'IOERROR: {ex}')

    @property
    def was_successful(self) -> bool:
        return self._was_successful
