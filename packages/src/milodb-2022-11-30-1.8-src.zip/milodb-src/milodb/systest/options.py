class Options:
    is_development_version: bool = False
    has_existing_config: bool = False
    has_existing_variables: bool = False
    log_filepath: str = ''
    input_fifo_filepath: str = ''
    output_fifo_filepath: str = ''
