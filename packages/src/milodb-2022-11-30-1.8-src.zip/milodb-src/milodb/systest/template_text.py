import re
from typing import Any

_KEYWORD_PATTERN: re.Pattern = re.compile(r'\~([A-Z]{3}):([^\~]+)\~')

class TemplateText:
    def __init__(self, keyed_text: str):
        self._keyed_text: str = keyed_text

    def expand(self, **kwargs) -> str:
        def on_replace(match: re.Match) -> str:
            var_name: str = match.group(1)
            var_value: str = match.group(2)
            if var_name in kwargs:
                action: Any = kwargs[var_name]
                if callable(action):
                    var_value = action(var_value)
                else:
                    var_value = str(action)
            return var_value

        return _KEYWORD_PATTERN.sub(on_replace, self._keyed_text)
