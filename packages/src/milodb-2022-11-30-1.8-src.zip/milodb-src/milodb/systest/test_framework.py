from milodb.systest.logger import Logger
from milodb.systest.fifo import InputFifo, OutputFifo
import re
from datetime import timedelta
from typing import List, Optional

class TestFail(RuntimeError):
    pass

class TestFramework:
    def __init__(self, logger: Logger, input_fifo: InputFifo, output_fifo: OutputFifo) -> None:
        self._logger: Logger = logger
        self._input_fifo: InputFifo = input_fifo
        self._output_fifo: OutputFifo = output_fifo

    def _verify_command(self, command_text: str, list_of_expected_lines: List[str]) -> None:
        self._inject_line(command_text)
        self._verify_line('')
        expected_line: str
        for expected_line in list_of_expected_lines:
            self._verify_line(expected_line)
        self._verify_line('')
        self._verify_prompt()

    def _inject_line(self, command: str) -> None:
        self._logger.log_injection(command)
        self._input_fifo.send(command)

    def _verify_line(self, expected_line: str, regex: bool=False) -> None:
        actual_line: Optional[str] = self._output_fifo.read_line()
        if actual_line is None:
            self._logger.log_fail(f'Timeout waiting for output "{expected_line}"')
            raise TestFail()
        if regex:
            if re.fullmatch(expected_line, actual_line):
                self._logger.log_pass_output(actual_line)
            else:
                self._logger.log_fail_output(actual_line)
                self._logger.log_note('expected pattern:')
                self._logger.log_note(expected_line)
                raise TestFail()
        else:
            if expected_line == actual_line:
                self._logger.log_pass_output(actual_line)
            else:
                self._logger.log_fail_output(actual_line)
                self._logger.log_note('expected text:')
                self._logger.log_note(expected_line)
                raise TestFail()

    def _verify_some(self, expected_line: str) -> None:
        expected_data: bytes = expected_line.encode('UTF-8')
        actual_data: Optional[bytes] = self._output_fifo.read_some(len(expected_data))
        if actual_data is None:
            self._logger.log_fail(f'Timeout waiting for output "{expected_line}"')
            raise TestFail()
        if expected_data == actual_data:
            self._logger.log_pass_output(expected_line)
        else:
            self._logger.log_fail(actual_data.decode('UTF-8'))
            self._logger.log_note('expected text:')
            self._logger.log_note(expected_line)
            raise TestFail()

    def _verify_none(self) -> None:
        actual_data: Optional[bytes] = self._output_fifo.read_some(1, timeout=timedelta(milliseconds=100))
        if actual_data is None:
            self._logger.log_pass_no_output()
        else:
            self._logger.log_fail(f'Received something when expecting nothing')
            self._logger.log_note('received:')
            self._logger.log_note(actual_data.hex())
            raise TestFail()

    def _verify_prompt(self) -> None:
        self._verify_some('> ')
        self._verify_none()
