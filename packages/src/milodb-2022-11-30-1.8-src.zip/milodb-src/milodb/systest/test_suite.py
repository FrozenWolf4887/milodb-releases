from milodb.systest.fifo import InputFifo, OutputFifo
from milodb.systest.formatting import Ansi, BBCode, Html, Url
from milodb.systest.logger import Logger
from milodb.systest.options import Options
from milodb.systest.template_text import TemplateText
from milodb.systest.test_framework import TestFramework

from typing import List

_HTML_LIST_HEAD: List[str] = [
    '<div class="listTable">',
    '<div class="th hits">Hits</div><div class="th teaseId">Id</div><div class="th type">Type</div><div class="th rating">Rating</div><div class="th date">Date</div><div class="th title">Title</div><div class="th author">Author</div>' ]
def _html_list_tail(number_of_matches: int) -> List[str]:
    plural_text: str = 'es' if number_of_matches != 1 else ''
    return [
        '</div>',
        f'<div class="totalMatches">{number_of_matches} match{plural_text}</div>' ]

class TestSuite(TestFramework):
    def __init__(self, logger: Logger, input_fifo: InputFifo, output_fifo: OutputFifo, options: Options) -> None:
        super().__init__(logger, input_fifo, output_fifo)
        self._options: Options = options
        self._run_tests()

    def _run_tests(self) -> None:
        self._logger.log_info('Starting tests')
        self._test_startup()
        TestSuite.TestDefaults(self)
        TestSuite.TestNoMatches(self)
        TestSuite.TestAnsiList(self)
        TestSuite.TestPlainList(self)
        TestSuite.TestBBCodeList(self)
        TestSuite.TestHtmlList(self)
        self._test_exit()
        self._logger.log_info('Finished running tests')

    def _test_startup(self) -> None:
        if self._options.is_development_version:
            self._verify_line('Milovana Database (Development), (Undated)')
        else:
            self._verify_line(r'Milovana Database [1-9](\.[0-9]+)+, 202[2-9]-[0-1][0-9]-[0-3][0-9]', regex=True)
        if self._options.has_existing_config:
            self._verify_line("Loaded config from 'config.json'")
        else:
            self._verify_line("Saved config file 'config.json'")
        if self._options.has_existing_variables:
            self._verify_line("Loaded variables from 'variables.json'")
        self._verify_line('Load database')
        self._verify_line(r'  Read     : [0-1].[0-9]{3}s', regex=True)
        self._verify_line(r'  Unpack   : [0-1].[0-9]{3}s', regex=True)
        self._verify_line(r'  Parse    : [0-1].[0-9]{3}s', regex=True)
        self._verify_line(r'  Assemble : [0-1].[0-9]{3}s', regex=True)
        self._verify_line(r'Load completed: [0-2].[0-9]{3}s', regex=True)
        self._verify_line(r'[0-9],[0-9]{3} teases loaded ranging from 2006-08-15 to 202[2-9]-[0-1][0-9]-[0-3][0-9]', regex=True)
        self._verify_line('')
        self._verify_line('Enter command (or "help"):')
        self._verify_prompt()

    def _test_exit(self) -> None:
        self._inject_line('exit')
        self._verify_line('')
        self._verify_line('')
        self._verify_none()

    class TestDefaults:
        def __init__(self, test_framework: TestFramework) -> None:
            self._test_framework: TestFramework = test_framework
            self._test_format_default()
            self._test_ellipsis_default()
            self._test_highlight_default()

        def _test_format_default(self) -> None:
            self._test_framework._verify_command('format', [
                "Current format is 'ansi'",
                "Available formats are ['plain', 'ansi', 'bbcode', 'html']" ])

        def _test_ellipsis_default(self) -> None:
            self._test_framework._verify_command('ellipsis', [
                "Current ellipsis mode is 'on'",
                "Available options are ['on', 'off']" ])

        def _test_highlight_default(self) -> None:
            self._test_framework._verify_command('highlight', [
                "Current highlighting is 'on'",
                "Available options are ['on', 'off']" ])

    class TestNoMatches:
        def __init__(self, test_framework: TestFramework) -> None:
            self._test_framework: TestFramework = test_framework
            self._test_query_no_matches()

        def _test_query_no_matches(self) -> None:
            self._test_framework._verify_command('query teaseId = 1234', [
                "No matches" ])

    class TestAnsiList:
        def __init__(self, test_framework: TestFramework) -> None:
            self._test_framework: TestFramework = test_framework
            self._template_output: TemplateText = TemplateText("  ~IDX:1~:   *~HTS:1~  #~TID:40134~  ~TYP:eos~  ~RAT:4.7~  w  ~DAT:2019-06-11~  Be~TTL:fore~ Eternity : [S~AUT:hatter~ed, @~AID:29180~]")
            self._test_format()
            self._test_teaseid_highlighting()
            self._test_type_highlighting()
            self._test_rating_highlighting()
            self._test_date_highlighting()
            self._test_title_highlighting()
            self._test_author_highlighting()
            self._test_authorid_highlighting()

        def _test_format(self) -> None:
            self._test_framework._verify_command('format ansi', [
                "Changed format to 'ansi'" ])

        def _test_teaseid_highlighting(self) -> None:
            self._test_framework._verify_command('query teaseId = 40134', [
                self._template_output.expand(TID=Ansi.highlighted) ])

        def _test_type_highlighting(self) -> None:
            self._test_framework._verify_command('query type is eos and summary contains "another soul guides you"', [
                self._template_output.expand(HTS=2, TYP=Ansi.highlighted) ])

        def _test_rating_highlighting(self) -> None:
            self._test_framework._verify_command('query rating > 4 and summary contains "another soul guides you"', [
                self._template_output.expand(HTS=2, RAT=Ansi.highlighted) ])

        def _test_date_highlighting(self) -> None:
            self._test_framework._verify_command('query date < 2020-01-01 and summary contains "another soul guides you"', [
                self._template_output.expand(HTS=2, DAT=Ansi.highlighted) ])

        def _test_title_highlighting(self) -> None:
            self._test_framework._verify_command('query title contains fore and summary contains "another soul guides you"', [
                self._template_output.expand(HTS=2, TTL=Ansi.highlighted) ])

        def _test_author_highlighting(self) -> None:
            self._test_framework._verify_command('query author contains hatter and summary contains "another soul guides you"', [
                self._template_output.expand(HTS=2, AUT=Ansi.highlighted) ])

        def _test_authorid_highlighting(self) -> None:
            self._test_framework._verify_command('query authorId > 29000 and summary contains "another soul guides you"', [
                self._template_output.expand(HTS=2, AID=Ansi.highlighted) ])

    class TestPlainList:
        def __init__(self, test_framework: TestFramework) -> None:
            self._test_framework: TestFramework = test_framework
            self._template_output: TemplateText = TemplateText("  ~IDX:1~:   *~HTS:1~  #~TID:40134~  ~TYP:eos~  ~RAT:4.7~  w  ~DAT:2019-06-11~  Be~TTL:fore~ Eternity : [S~AUT:hatter~ed, @~AID:29180~]")
            self._test_format()
            self._test_teaseid_highlighting()
            self._test_type_highlighting()
            self._test_rating_highlighting()
            self._test_date_highlighting()
            self._test_title_highlighting()
            self._test_author_highlighting()
            self._test_authorid_highlighting()

        def _test_format(self) -> None:
            self._test_framework._verify_command('format plain', [
                "Changed format to 'plain'" ])

        def _test_teaseid_highlighting(self) -> None:
            self._test_framework._verify_command('query teaseId = 40134', [
                self._template_output.expand() ])

        def _test_type_highlighting(self) -> None:
            self._test_framework._verify_command('query type is eos and summary contains "another soul guides you"', [
                self._template_output.expand(HTS=2) ])

        def _test_rating_highlighting(self) -> None:
            self._test_framework._verify_command('query rating > 4 and summary contains "another soul guides you"', [
                self._template_output.expand(HTS=2) ])

        def _test_date_highlighting(self) -> None:
            self._test_framework._verify_command('query date < 2020-01-01 and summary contains "another soul guides you"', [
                self._template_output.expand(HTS=2) ])

        def _test_title_highlighting(self) -> None:
            self._test_framework._verify_command('query title contains fore and summary contains "another soul guides you"', [
                self._template_output.expand(HTS=2) ])

        def _test_author_highlighting(self) -> None:
            self._test_framework._verify_command('query author contains hatter and summary contains "another soul guides you"', [
                self._template_output.expand(HTS=2) ])

        def _test_authorid_highlighting(self) -> None:
            self._test_framework._verify_command('query authorId > 29000 and summary contains "another soul guides you"', [
                self._template_output.expand(HTS=2) ])

    class TestBBCodeList:
        def __init__(self, test_framework: TestFramework) -> None:
            self._test_framework: TestFramework = test_framework
            self._template_output: TemplateText = TemplateText(f"[pre]  ~IDX:1~:   *~HTS:1~  [url={Url.tease(40134)}]#~TID:40134~[/url]  ~TYP:eos~  ~RAT:4.7~  w  ~DAT:2019-06-11~  [/pre]Be~TTL:fore~ Eternity : [[i][/i]S~AUT:hatter~ed, [url={Url.author(29180)}]@~AID:29180~[/url]]")
            self._test_format()
            self._test_teaseid_highlighting()
            self._test_type_highlighting()
            self._test_rating_highlighting()
            self._test_date_highlighting()
            self._test_title_highlighting()
            self._test_author_highlighting()
            self._test_authorid_highlighting()

        def _test_format(self) -> None:
            self._test_framework._verify_command('format bbcode', [
                "Changed format to 'bbcode'" ])

        def _test_teaseid_highlighting(self) -> None:
            self._test_framework._verify_command('query teaseId = 40134', [
                self._template_output.expand(TID=BBCode.highlighted) ])

        def _test_type_highlighting(self) -> None:
            self._test_framework._verify_command('query type is eos and summary contains "another soul guides you"', [
                self._template_output.expand(HTS=2, TYP=BBCode.highlighted) ])

        def _test_rating_highlighting(self) -> None:
            self._test_framework._verify_command('query rating > 4 and summary contains "another soul guides you"', [
                self._template_output.expand(HTS=2, RAT=BBCode.highlighted) ])

        def _test_date_highlighting(self) -> None:
            self._test_framework._verify_command('query date < 2020-01-01 and summary contains "another soul guides you"', [
                self._template_output.expand(HTS=2, DAT=BBCode.highlighted) ])

        def _test_title_highlighting(self) -> None:
            self._test_framework._verify_command('query title contains fore and summary contains "another soul guides you"', [
                self._template_output.expand(HTS=2, TTL=BBCode.highlighted) ])

        def _test_author_highlighting(self) -> None:
            self._test_framework._verify_command('query author contains hatter and summary contains "another soul guides you"', [
                self._template_output.expand(HTS=2, AUT=BBCode.highlighted) ])

        def _test_authorid_highlighting(self) -> None:
            self._test_framework._verify_command('query authorId > 29000 and summary contains "another soul guides you"', [
                self._template_output.expand(HTS=2, AID=BBCode.highlighted) ])

    class TestHtmlList:
        def __init__(self, test_framework: TestFramework) -> None:
            self._test_framework: TestFramework = test_framework
            self._template_output: TemplateText = TemplateText(f'<div class="td hits">~HTS:1~</div><div class="td teaseId"><a href="{Url.tease(40134)}"><div>~TID:40134~</div></a></div><div class="td type"><div>~TYP:eos~</div></div><div class="td rating"><div>~RAT:4.7~</div></div><div class="td date"><div>~DAT:2019-06-11~</div></div><div class="td title"><img src="milodb-totm-winner.png" alt="TOTM - Winner!"><div>Be~TTL:fore~ Eternity</div></div><div class="td author"><a href="{Url.author(29180)}"><div>S~AUT:hatter~ed</div></a></div>')
            self._test_format()
            self._test_teaseid_highlighting()
            self._test_type_highlighting()
            self._test_rating_highlighting()
            self._test_date_highlighting()
            self._test_title_highlighting()
            self._test_author_highlighting()

        def _test_format(self) -> None:
            self._test_framework._verify_command('format html', [
                "Changed format to 'html'" ])

        def _test_teaseid_highlighting(self) -> None:
            self._test_framework._verify_command('query teaseId = 40134', [
                *_HTML_LIST_HEAD,
                self._template_output.expand(TID=Html.highlighted),
                *_html_list_tail(1) ])

        def _test_type_highlighting(self) -> None:
            self._test_framework._verify_command('query type is eos and summary contains "another soul guides you"', [
                *_HTML_LIST_HEAD,
                self._template_output.expand(HTS=2, TYP=Html.highlighted),
                *_html_list_tail(1) ])

        def _test_rating_highlighting(self) -> None:
            self._test_framework._verify_command('query rating > 4 and summary contains "another soul guides you"', [
                *_HTML_LIST_HEAD,
                self._template_output.expand(HTS=2, RAT=Html.highlighted),
                *_html_list_tail(1) ])

        def _test_date_highlighting(self) -> None:
            self._test_framework._verify_command('query date < 2020-01-01 and summary contains "another soul guides you"', [
                *_HTML_LIST_HEAD,
                self._template_output.expand(HTS=2, DAT=Html.highlighted),
                *_html_list_tail(1) ])

        def _test_title_highlighting(self) -> None:
            self._test_framework._verify_command('query title contains fore and summary contains "another soul guides you"', [
                *_HTML_LIST_HEAD,
                self._template_output.expand(HTS=2, TTL=Html.highlighted),
                *_html_list_tail(1) ])

        def _test_author_highlighting(self) -> None:
            self._test_framework._verify_command('query author contains hatter and summary contains "another soul guides you"', [
                *_HTML_LIST_HEAD,
                self._template_output.expand(HTS=2, AUT=Html.highlighted),
                *_html_list_tail(1) ])
