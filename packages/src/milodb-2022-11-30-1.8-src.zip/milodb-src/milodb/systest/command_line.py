from milodb.systest.options import Options

from typing import Callable, Dict, List, Optional

class CommandLine:
    def __init__(self) -> None:
        self._is_help_requested: bool = False
        self._is_development_version: bool = False
        self._has_existing_config: bool = True
        self._has_existing_variables: bool = True
        self._log_filepath: Optional[str] = None
        self._input_fifo_filepath: Optional[str] = None
        self._output_fifo_filepath: Optional[str] = None
        self._error_message: Optional[str] = ''

    @staticmethod
    def parse_from_args(args: List[str]) -> 'CommandLine':
        options: CommandLine = CommandLine()
        options._load_from_command_line(args.copy())
        return options

    def is_valid(self) -> bool:
        return self._error_message is None

    def is_help_requested(self) -> bool:
        return self._is_help_requested

    def get_error_message(self) -> str:
        return self._error_message or ''

    def get_options(self) -> Options:
        options: Options = Options()
        options.is_development_version = self._is_development_version
        options.has_existing_config = self._has_existing_config
        options.has_existing_variables = self._has_existing_variables
        options.log_filepath = self._log_filepath or ''
        options.input_fifo_filepath = self._input_fifo_filepath or ''
        options.output_fifo_filepath = self._output_fifo_filepath or ''
        return options

    @staticmethod
    def get_syntax_text() -> str:
        return (
            'Syntax: systest.py --log logFilePath --inputfifo inputFIFO --outputfifo outputFIFO [options]\n'
            'Options:\n'
            '  -h   --help        Display this help.\n'
            '  -l   --log         File to write log data to. File must not exist.\n'
            '  -i   --inputfifo   Input FIFO to inject commands into MiloDB. FIFO must exist.\n'
            '  -o   --outputfifo  Output FIFO to capture output from MiloDB. FIFO must exist.\n'
            '  -d   --dev         MiloDB is development version.\n'
            '  -nc  --noconfig    Config file does not yet exist.\n'
            '  -nv  --novars      Variables file does not exist yet.'
        )

    def _load_from_command_line(self, args: List[str]) -> None:
        self._error_message = None

        if '-h' in args or '--help' in args:
            self._is_help_requested = True
            return

        map_of_switch_parsers: Dict[str, Callable[[str, List[str]], None]] = {
            '-l': self._parse_log_switch, '--log': self._parse_log_switch,
            '-i': self._parse_input_fifo_switch, '--inputfifo': self._parse_input_fifo_switch,
            '-o': self._parse_output_fifo_switch, '--outputfifo': self._parse_output_fifo_switch,
            '-d': self._parse_development_switch, '--dev': self._parse_development_switch,
            '-nc': self._parse_no_config_switch, '--noconfig': self._parse_no_config_switch,
            '-nv': self._parse_no_vars_switch, '--novars': self._parse_no_vars_switch }

        while args and not self._error_message:
            switch: str = args.pop(0)
            switch_handler: Optional[Callable[[str, List[str]], None]] = map_of_switch_parsers.get(switch)
            if switch_handler:
                switch_handler(switch, args)
            else:
                self._error_message = f"Unknown switch '{switch}'"

        if not self._error_message:
            if not self._log_filepath:
                self._error_message = 'Log filepath not specified'
            elif not self._input_fifo_filepath:
                self._error_message = 'Input FIFO not specified'
            elif not self._output_fifo_filepath:
                self._error_message = 'Output FIFO not specified'

    def _parse_log_switch(self, switch: str, remaining_args: List[str]) -> None:
        try:
            self._log_filepath = remaining_args.pop(0)
        except IndexError:
            self._error_message = f"Expecting logFilePath following {switch}"

    def _parse_input_fifo_switch(self, switch: str, remaining_args: List[str]) -> None:
        try:
            self._input_fifo_filepath = remaining_args.pop(0)
        except IndexError:
            self._error_message = f"Expecting inputFIFO following {switch}"

    def _parse_output_fifo_switch(self, switch: str, remaining_args: List[str]) -> None:
        try:
            self._output_fifo_filepath = remaining_args.pop(0)
        except IndexError:
            self._error_message = f"Expecting outputFIFO following {switch}"

    def _parse_development_switch(self, switch: str, remaining_args: List[str]) -> None:
        self._is_development_version = True

    def _parse_no_config_switch(self, switch: str, remaining_args: List[str]) -> None:
        self._has_existing_config = False

    def _parse_no_vars_switch(self, switch: str, remaining_args: List[str]) -> None:
        self._has_existing_variables = False
