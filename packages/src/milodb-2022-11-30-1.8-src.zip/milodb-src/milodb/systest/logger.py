from datetime import datetime
from typing import Optional, TextIO

class Logger:
    def __init__(self, filepath: str) -> None:
        self._filepath: str = filepath
        self._file: Optional[TextIO] = None
        self._is_logging_available: bool = False

    def __enter__(self) -> 'Logger':
        self._file = open(self._filepath, 'at')
        return self

    def __exit__(self, exc_type, exc_value, traceback) -> None:
        if self._file:
            self._file.close()

    def log_info(self, message: str) -> None:
        self._log(f'INFO: {message}')

    def log_injection(self, message: str) -> None:
        self._log(f'INFO: <inject> {message}')

    def log_pass_output(self, message: str) -> None:
        self._log(f'PASS: <output> {message}')

    def log_pass_no_output(self) -> None:
        self._log(f'PASS: <no output>')

    def log_fail(self, message: str) -> None:
        self._log(f'FAIL: {message}')

    def log_fail_output(self, message: str) -> None:
        self._log(f'FAIL: <output> {message}')

    def log_fail_no_output(self) -> None:
        self._log(f'FAIL: <no output>')

    def log_note(self, message: str) -> None:
        self._log(f'NOTE: {message}')

    def _log(self, message: str) -> None:
        if self._file:
            timestamp: str = datetime.now().isoformat(sep=' ', timespec='milliseconds')
            self._file.write(f'{timestamp}  {message}\n')
            self._file.flush()
