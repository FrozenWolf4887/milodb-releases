import milodb.query as query
from milodb.tease import Tease, TeaseDateProperty, TeaseFloatProperty, TeaseIntProperty, TeaseStrProperty, TeaseStrListProperty, TeaseTypeProperty
from milodb.tokeniser import Token
import datetime
import operator
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Callable, Optional, Dict, List, Type, Union

class FieldVerb(ABC):
    @abstractmethod
    def create_query(self, queue_of_tokens: List[Token]):
        pass

class FieldFloatVerb(FieldVerb):
    def __init__(self, tease_property: TeaseFloatProperty, field_predicate: Type[query.FieldFloatPredicate], compare_func: Callable[[float, float], bool]):
        self._tease_property: TeaseFloatProperty = tease_property
        self._field_predicate: Type[query.FieldFloatPredicate] = field_predicate
        self._compare_func: Callable[[float, float], bool] = compare_func

    def create_query(self, queue_of_tokens: List[Token]):
        return self._field_predicate(self._tease_property, queue_of_tokens, self._compare_func)

class FieldIntVerb(FieldVerb):
    def __init__(self, tease_property: TeaseIntProperty, field_predicate: Type[query.FieldIntPredicate], compare_func: Callable[[int, int], bool]) -> None:
        self._tease_property: TeaseIntProperty = tease_property
        self._field_predicate = field_predicate
        self._compare_func: Callable[[int, int], bool] = compare_func

    def create_query(self, queue_of_tokens: List[Token]):
        return self._field_predicate(self._tease_property, queue_of_tokens, self._compare_func)

class FieldStrVerb(FieldVerb):
    def __init__(self, tease_property: TeaseStrProperty, field_predicate: Type[query.FieldStrPredicate]) -> None:
        self._tease_property: TeaseStrProperty = tease_property
        self._field_predicate: Type[query.FieldStrPredicate] = field_predicate

    def create_query(self, queue_of_tokens: List[Token]):
        return self._field_predicate(self._tease_property, queue_of_tokens)

class FieldStrListVerb(FieldVerb):
    def __init__(self, tease_property: TeaseStrListProperty, field_predicate: Type[query.FieldStrListPredicate]) -> None:
        self._tease_property: TeaseStrListProperty = tease_property
        self._field_predicate: Type[query.FieldStrListPredicate] = field_predicate

    def create_query(self, queue_of_tokens: List[Token]):
        return self._field_predicate(self._tease_property, queue_of_tokens)

class FieldTypeVerb(FieldVerb):
    def __init__(self, tease_property: TeaseTypeProperty, field_predicate: Type[query.FieldTypePredicate]) -> None:
        self._tease_property: TeaseTypeProperty = tease_property
        self._field_predicate: Type[query.FieldTypePredicate] = field_predicate

    def create_query(self, queue_of_tokens: List[Token]):
        return self._field_predicate(self._tease_property, queue_of_tokens)

class FieldDateVerb(FieldVerb):
    def __init__(self, tease_property: TeaseDateProperty, field_predicate: Type[query.FieldDatePredicate], compare_func: Callable[[datetime.date, datetime.date], bool]) -> None:
        self._tease_property: TeaseDateProperty = tease_property
        self._field_predicate: Type[query.FieldDatePredicate] = field_predicate
        self._compare_func: Callable[[datetime.date, datetime.date], bool] = compare_func

    def create_query(self, queue_of_tokens: List[Token]):
        return self._field_predicate(self._tease_property, queue_of_tokens, self._compare_func)

_MAP_OF_TEASE_FIELDNAMES_TO_PROPERTIES: Dict[str, Dict[str, FieldVerb]] = {
    'teaseId': {
        '=': FieldIntVerb(Tease.tease_id, query.FieldIntCompare, operator.eq),
        '>': FieldIntVerb(Tease.tease_id, query.FieldIntCompare, operator.gt),
        '<': FieldIntVerb(Tease.tease_id, query.FieldIntCompare, operator.lt),
        '>=': FieldIntVerb(Tease.tease_id, query.FieldIntCompare, operator.ge),
        '<=': FieldIntVerb(Tease.tease_id, query.FieldIntCompare, operator.le)
    },
    'authorId': {
        '=': FieldIntVerb(Tease.author_id, query.FieldIntCompare, operator.eq),
        '>': FieldIntVerb(Tease.author_id, query.FieldIntCompare, operator.gt),
        '<': FieldIntVerb(Tease.author_id, query.FieldIntCompare, operator.lt),
        '>=': FieldIntVerb(Tease.author_id, query.FieldIntCompare, operator.ge),
        '<=': FieldIntVerb(Tease.author_id, query.FieldIntCompare, operator.le)
    },
    'type': {
        'is': FieldTypeVerb(Tease.type, query.FieldTypeIs),
    },
    'title': {
        'is': FieldStrVerb(Tease.title, query.FieldStrIs),
        'contains': FieldStrVerb(Tease.title, query.FieldStrContains),
        'matches': FieldStrVerb(Tease.title, query.FieldStrMatches)
    },
    'summary': {
        'is': FieldStrVerb(Tease.summary, query.FieldStrIs),
        'contains': FieldStrVerb(Tease.summary, query.FieldStrContains),
        'matches': FieldStrVerb(Tease.summary, query.FieldStrMatches)
    },
    'author': {
        'is': FieldStrVerb(Tease.author_name, query.FieldStrIs),
        'contains': FieldStrVerb(Tease.author_name, query.FieldStrContains),
        'matches': FieldStrVerb(Tease.author_name, query.FieldStrMatches)
    },
    'tag': {
        'is': FieldStrListVerb(Tease.list_of_tags, query.FieldStrListIs),
        'contains': FieldStrListVerb(Tease.list_of_tags, query.FieldStrListContains),
        'matches': FieldStrListVerb(Tease.list_of_tags, query.FieldStrListMatches)
    },
    'date': {
        '=': FieldDateVerb(Tease.date, query.FieldDateCompare, operator.eq),
        '>': FieldDateVerb(Tease.date, query.FieldDateCompare, operator.gt),
        '<': FieldDateVerb(Tease.date, query.FieldDateCompare, operator.lt),
        '>=': FieldDateVerb(Tease.date, query.FieldDateCompare, operator.ge),
        '<=': FieldDateVerb(Tease.date, query.FieldDateCompare, operator.le)
    },
    'rating': {
        '=': FieldFloatVerb(Tease.rating_value, query.FieldFloatCompare, operator.eq),
        '>': FieldFloatVerb(Tease.rating_value, query.FieldFloatCompare, operator.gt),
        '<': FieldFloatVerb(Tease.rating_value, query.FieldFloatCompare, operator.lt),
        '>=': FieldFloatVerb(Tease.rating_value, query.FieldFloatCompare, operator.ge),
        '<=': FieldFloatVerb(Tease.rating_value, query.FieldFloatCompare, operator.le)
    },
    'text': {
        'contains': FieldStrListVerb(Tease.list_of_text_blocks, query.FieldStrListContains),
        'matches': FieldStrListVerb(Tease.list_of_text_blocks, query.FieldStrListMatches)
    }
}

_MAP_OF_BINARY_OPERATORS_TO_QUERY_CLASS: Dict[str, Type[query.QueryBase]] = {
    'and': query.And,
    'or': query.Or
}

_MAP_OF_UNARY_OPERATORS_TO_QUERY_CLASS: Dict[str, Type[query.QueryBase]] = {
    'not': query.Not
}

def get_list_of_field_names() -> List[str]:
    return list(_MAP_OF_TEASE_FIELDNAMES_TO_PROPERTIES.keys())

def get_list_of_verb_names() -> List[str]:
    list_of_verb_names: List[str] = []
    verb_dictionary: Dict[str, FieldVerb]
    for verb_dictionary in _MAP_OF_TEASE_FIELDNAMES_TO_PROPERTIES.values():
        list_of_verb_names.extend(verb_dictionary.keys())
    return list(set(list_of_verb_names))

def get_list_of_operators() -> List[str]:
    return list(_MAP_OF_BINARY_OPERATORS_TO_QUERY_CLASS.keys()) + list(_MAP_OF_UNARY_OPERATORS_TO_QUERY_CLASS.keys()) + ['(', ')']

@dataclass
class SuccessfulPostfixConversionResult:
    postfix_query_chain: List[query.QueryBase]
    list_of_expected_next_text: List[str]

@dataclass
class FailedPostfixConversionResult:
    cause_of_fault_text: str
    cause_of_fault_token: Optional[Token]
    list_of_expected_next_text: List[str]

def convert(list_of_tokens: Optional[List[Token]]) -> Union[SuccessfulPostfixConversionResult, FailedPostfixConversionResult]:
    converter = _InfixToPostfixQueryConverter(list_of_tokens)
    return converter.get_result()

class _InfixToPostfixQueryConverter:
    def __init__(self, list_of_tokens: Optional[List[Token]]) -> None:
        self._queue_of_tokens: List[Token] = list_of_tokens.copy() if list_of_tokens else []
        self._queue_of_tokens.reverse()
        self._stack_of_operators: List[Optional[query.QueryBase]] = []
        self._expecting_query: bool = True
        self._expecting_verb_list: Optional[List[str]] = None
        self._expecting_binary_operator: bool = False
        self._expecting_unary_operator: bool = True
        self._expecting_open: bool = True
        self._expecting_close: bool = False
        self._postfix_query_chain: List[query.QueryBase] = []
        self._conversion_result: Union[SuccessfulPostfixConversionResult, FailedPostfixConversionResult]

        try:
            self._process_queue_of_tokens()
            self._conversion_result = SuccessfulPostfixConversionResult(
                self._postfix_query_chain, self._get_list_of_expected_next_text())

        except _PostfixException as ex:
            if ex.list_of_possible_text is not None:
                self._conversion_result = FailedPostfixConversionResult(str(ex), ex.token, ex.list_of_possible_text)
            else:
                self._conversion_result = FailedPostfixConversionResult(str(ex), ex.token, self._get_list_of_expected_next_text())

    def get_result(self) -> Union[SuccessfulPostfixConversionResult, FailedPostfixConversionResult]:
        return self._conversion_result

    def _get_list_of_expected_next_text(self) -> List[str]:
        list_of_expected_next_text: List[str] = []
        if self._expecting_query:
            list_of_expected_next_text.extend(_MAP_OF_TEASE_FIELDNAMES_TO_PROPERTIES.keys())
        if self._expecting_binary_operator:
            list_of_expected_next_text.extend(_MAP_OF_BINARY_OPERATORS_TO_QUERY_CLASS.keys())
        if self._expecting_unary_operator:
            list_of_expected_next_text.extend(_MAP_OF_UNARY_OPERATORS_TO_QUERY_CLASS.keys())
        if self._expecting_verb_list:
            list_of_expected_next_text.extend(self._expecting_verb_list)
        if self._expecting_open:
            list_of_expected_next_text.append('(')
        if self._expecting_close:
            list_of_expected_next_text.append(')')
        return list_of_expected_next_text

    def _process_queue_of_tokens(self) -> None:
        while self._queue_of_tokens:
            token: Token = self._queue_of_tokens.pop()
            self._process_token(token)

        if self._expecting_query:
            raise _PostfixException('Unexpected end of input when expecting a query', None)

        while self._stack_of_operators:
            operator: Optional[query.QueryBase] = self._stack_of_operators.pop()
            if operator:
                self._postfix_query_chain.append(operator)
            else:
                raise _PostfixException('No matching closing parenthesis for opening parenthesis', None)

    def _process_token(self, token: Token) -> None:
        if not (self._try_process_query_field(token) or
                self._try_process_binary_operator(token) or
                self._try_process_unary_operator(token) or
                self._try_process_parenthesis(token)):
            raise _PostfixException('Unknown field name or operator', token)

    def _try_process_query_field(self, token: Token) -> bool:
        verb_dictionary: Optional[Dict[str, FieldVerb]] = _MAP_OF_TEASE_FIELDNAMES_TO_PROPERTIES.get(token.text)
        if verb_dictionary:
            if not self._expecting_query:
                raise _PostfixException('Not expecting field query', token)
            self._process_query_field(token, verb_dictionary)
            return True
        else:
            return False

    def _try_process_binary_operator(self, token: Token) -> bool:
        query_class: Optional[Type[query.QueryBase]] = _MAP_OF_BINARY_OPERATORS_TO_QUERY_CLASS.get(token.text)
        if query_class:
            if not self._expecting_binary_operator:
                raise _PostfixException('Not expecting binary operator', token)
            self._process_binary_operator(token, query_class)
            return True
        else:
            return False

    def _try_process_unary_operator(self, token: Token) -> bool:
        query_class: Optional[Type[query.QueryBase]] = _MAP_OF_UNARY_OPERATORS_TO_QUERY_CLASS.get(token.text)
        if query_class:
            if not self._expecting_unary_operator:
                raise _PostfixException('Not expecting unary operator', token)
            self._process_unary_operator(token, query_class)
            return True
        else:
            return False

    def _try_process_parenthesis(self, token: Token) -> bool:
        token_text = token.text
        if token_text == '(':
            if not self._expecting_open:
                raise _PostfixException('Not expecting opening parenthesis', token)
            self._process_open_parenthesis(token)
            return True
        elif token_text == ')':
            if not self._expecting_close:
                raise _PostfixException('Not expecting closing parenthesis', token)
            self._process_close_parenthesis(token)
            return True
        else:
            return False

    def _process_query_field(self, _: Token, verb_dictionary: Dict[str, FieldVerb]) -> None:
        self._expecting_query = False
        self._expecting_verb_list = list(verb_dictionary.keys())
        self._expecting_binary_operator = False
        self._expecting_unary_operator = False
        self._expecting_open = False
        self._expecting_close = False

        try:
            query_type_token: Token = self._queue_of_tokens.pop()
            field_verb: FieldVerb = verb_dictionary[query_type_token.text]
        except IndexError:
            raise _PostfixException('Expecting a verb for comparison to field', None)
        except KeyError:
            raise _PostfixException('Unknown verb for comparison to field', query_type_token)

        self._expecting_query = False
        self._expecting_verb_list = None
        self._expecting_binary_operator = False
        self._expecting_unary_operator = False
        self._expecting_open = False
        self._expecting_close = False

        try:
            query_object = field_verb.create_query(self._queue_of_tokens)
        except query.QueryException as ex:
            raise _PostfixException(str(ex), ex.token, ex.list_of_possible_text)

        self._postfix_query_chain.append(query_object)
        self._pop_unary_operators_to_postfix_query_chain()

        self._expecting_query = False
        self._expecting_verb_list = None
        self._expecting_binary_operator = True
        self._expecting_unary_operator = False
        self._expecting_open = False
        self._expecting_close = self._has_any_stacked_open_parenthesis()

    def _process_binary_operator(self, _: Token, query_class: Type[query.QueryBase]) -> None:
        self._stack_of_operators.append(query_class())

        self._expecting_query = True
        self._expecting_verb_list = None
        self._expecting_binary_operator = False
        self._expecting_unary_operator = True
        self._expecting_open = True
        self._expecting_close = False

    def _process_unary_operator(self, _: Token, query_class: Type[query.QueryBase]) -> None:
        self._stack_of_operators.append(query_class())

        self._expecting_query = True
        self._expecting_verb_list = None
        self._expecting_binary_operator = False
        self._expecting_unary_operator = False
        self._expecting_open = True
        self._expecting_close = False

    def _process_open_parenthesis(self, _: Token) -> None:
        self._stack_of_operators.append(None)

        self._expecting_query = True
        self._expecting_verb_list = None
        self._expecting_binary_operator = False
        self._expecting_unary_operator = True
        self._expecting_open = True
        self._expecting_close = False

    def _process_close_parenthesis(self, token: Token) -> None:
        try:
            found_opening_bracket: bool = False
            while not found_opening_bracket:
                operator: Optional[query.QueryBase] = self._stack_of_operators.pop()
                if operator:
                    self._postfix_query_chain.append(operator)
                else:
                    found_opening_bracket = True
        except IndexError:
            raise _PostfixException('No matching opening parenthesis for closing parenthesis', token)

        self._expecting_query = False
        self._expecting_verb_list = None
        self._expecting_binary_operator = True
        self._expecting_unary_operator = False
        self._expecting_open = False
        self._expecting_close = self._has_any_stacked_open_parenthesis()

    def _pop_unary_operators_to_postfix_query_chain(self) -> None:
        while self._stack_of_operators:
            operator: Optional[query.QueryBase] = self._stack_of_operators[len(self._stack_of_operators) - 1]
            if isinstance(operator, query.Not):
                self._stack_of_operators.pop()
                self._postfix_query_chain.append(operator)
            else:
                break

    def _has_any_stacked_open_parenthesis(self) -> bool:
        for operator in self._stack_of_operators:
            if operator is None:
                return True
        return False

class _PostfixException(Exception):
    def __init__(self, message: str, token: Optional[Token], list_of_possible_text: Optional[List[str]] = None) -> None:
        super().__init__(message)
        self.token: Optional[Token] = token
        self.list_of_possible_text: Optional[List[str]] = list_of_possible_text
