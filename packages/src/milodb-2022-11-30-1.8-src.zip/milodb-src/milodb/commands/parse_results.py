from milodb.tokeniser import Token
from dataclasses import dataclass
from typing import List, Optional, Type, TYPE_CHECKING, Union
if TYPE_CHECKING:
    from milodb.commands.command import Command

@dataclass
class SuccessfulCommandParseResult:
    command: 'Command'
    list_of_possible_next_text: Optional[List[str]]

@dataclass
class FailedCommandParseResult:
    command_class: Optional[Type['Command']]
    fault_token: Optional[Token]
    fault_text: str
    list_of_expected_text: Optional[List[str]]

@dataclass
class EmptyCommandParseResult:
    list_of_expected_text: Optional[List[str]]

@dataclass
class LoadError(Exception):
    message: str
    fault_token: Optional[Token]
    list_of_expected_text: Optional[List[str]]

@dataclass
class LoadDelegateError(Exception):
    failed_command_parse_result: Union[FailedCommandParseResult, EmptyCommandParseResult]

@dataclass
class UnknownCommandError(Exception):
    command_token: Token
