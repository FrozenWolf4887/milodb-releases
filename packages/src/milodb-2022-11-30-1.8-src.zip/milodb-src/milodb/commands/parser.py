from milodb.commands.argument_stream import ArgumentStream
from milodb.commands.command import Command, CommandContext
from milodb.commands.parse_results import EmptyCommandParseResult, FailedCommandParseResult, LoadDelegateError, LoadError, SuccessfulCommandParseResult
from milodb.tokeniser import Token, TokenStreamError
from typing import List, Optional, Type, Union

def parse(argument_stream: ArgumentStream, context: CommandContext) -> Union[SuccessfulCommandParseResult, FailedCommandParseResult, EmptyCommandParseResult]:
    result: Union[SuccessfulCommandParseResult, FailedCommandParseResult, EmptyCommandParseResult]

    try:
        command_token: Optional[Token] = argument_stream.pop_optional_token()
        if command_token:
            command_class: Optional[Type[Command]] = context.command_factory.try_get_command_class_from_name(command_token.text)
            if command_class:
                command: Command = command_class(context)

                try:
                    list_of_possible_next_text: Optional[List[str]] = command.load(argument_stream)
                    result = SuccessfulCommandParseResult(command, list_of_possible_next_text)
                except TokenStreamError as ex:
                    result = FailedCommandParseResult(command_class, ex.cause_of_fault_token, f"Syntax error at character #{ex.cause_of_fault_character_index} '{ex.cause_of_fault_text}'", ex.list_of_expected_text)
                except LoadError as ex:
                    result = FailedCommandParseResult(command_class, ex.fault_token, ex.message, ex.list_of_expected_text)
                except LoadDelegateError as ex:
                    result = ex.failed_command_parse_result
            else:
                result = FailedCommandParseResult(None, command_token, 'Unknown command', list(context.command_factory.get_list_of_command_names()))
        else:
            result = EmptyCommandParseResult(list(context.command_factory.get_list_of_command_names()))
    except TokenStreamError as ex:
        result = FailedCommandParseResult(None, None, f"Syntax error: {ex.cause_of_fault_text} at offset {ex.cause_of_fault_character_index}", ex.list_of_expected_text)

    return result
