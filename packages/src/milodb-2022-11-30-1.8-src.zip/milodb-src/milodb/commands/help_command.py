from milodb.commands.argument_stream import ArgumentStream
from milodb.commands.command import Command, CommandContext
from milodb.commands.command_support import WordWrapper
from milodb.commands.parser import LoadError
from milodb.tokeniser import Token
from typing import List, Optional, Type

class HelpCommand(Command):
    def __init__(self, context: CommandContext) -> None:
        self._context = context
        self._command_class_for_help: Optional[Type[Command]] = None

    def load(self, argument_stream: ArgumentStream) -> Optional[List[str]]:
        command_name_token: Optional[Token] = argument_stream.pop_optional_token()
        if command_name_token:
            self._command_class_for_help = self._context.command_factory.try_get_command_class_from_name(command_name_token.text)
            if self._command_class_for_help:
                argument_stream.fail_if_not_empty()
                return None
            else:
                raise LoadError('Unrecognised command name', command_name_token, self._context.command_factory.get_list_of_command_names())
        else:
            return self._context.command_factory.get_list_of_command_names()

    def execute(self) -> None:
        if self._command_class_for_help:
            self._print_command_help(self._command_class_for_help)
        else:
            self._print_summary_help()

    @classmethod
    def get_one_line_summary(cls) -> str:
        return "Prints the list of commands or detailed help for a specific command"

    @classmethod
    def get_detailed_summary(cls, context: CommandContext) -> str:
        return (
            "Arguments: [command name]\n"
            "Provides details of the specified command including examples where appropriate.\n"
            "When used without arguments, summary help information is shown with the list of"
            " commands available.\n"
            "Example:\r"
            "  Show the help summary\r"
            "  > help\r"
            "Example:\r"
            "  Show detailed help for the query command\r"
            "  > help query\n"
        )

    def _print_command_help(self, command_class: Type[Command]) -> None:
        self._print_help((
            f"{command_class.get_one_line_summary()}.\n"
            f"{command_class.get_detailed_summary(self._context)}"
        ))

    def _print_summary_help(self) -> None:
        text: str = (
            'Run queries on the database to retrieve matches and provide results in a variety of'
            ' formats.\n'
            'For example, perform a query against teases that contain the text "cookies" in'
            ' any of the pages, and show the matching text results for each tease:\r'
            '  > \tquery text contains cookies\r'
            '  > \tshow\n'
            'List of commands:'
        )

        list_of_command_names: List[str] = sorted(self._context.command_factory.get_list_of_command_names())
        length_of_longest_command_name = max(len(name) for name in list_of_command_names)

        command_name: str
        for command_name in list_of_command_names:
            command_class: Optional[Type[Command]] = self._context.command_factory.try_get_command_class_from_name(command_name)
            if command_class:
                summary_text: str = command_class.get_one_line_summary()
                text += f'\r{command_name:>{length_of_longest_command_name}}  \t{summary_text}'

        text += (
            "\nUse 'help <command name>' for detailed information on a specific command.\r"
            'Press <TAB> once to complete command names and arguments where possible.\r'
            'Press <TAB> twice to get a list of suggestions for command names and arguments.\r'
            'Press <UP>/<DOWN> to see previously entered commands.\n'
        )

        self._print_help(text)

    def _print_help(self, text: str) -> None:
        text = text.strip().replace('\n', '\n\n').replace('\r', '\n')
        text = WordWrapper(text, 80).text
        self._context.session_config.stream_writer.writeln(text)
