from milodb.commands.query_command import QueryCommand
from milodb.commands.test_command_base import CommandTestBase

class TestQueryCommand(CommandTestBase):
    def test_without_arguments_returns_failure(self):
        self.parse_test(['query'])
        self.assert_unsuccessful(QueryCommand, None, 'Grammar error: Unexpected end of input when expecting a query',
            ['title', 'summary', 'teaseId', 'author', 'authorId', 'text', 'date', 'type', 'tag', 'rating', '(', 'not'])

    def test_with_one_field_name_returns_failure(self):
        self.parse_test(['query', 'title'])
        self.assert_unsuccessful(QueryCommand, None, 'Grammar error: Expecting a verb for comparison to field',
            ['is', 'contains', 'matches'])

    def test_with_valid_query_returns_success(self):
        self.parse_test(['query', 'title', 'contains', 'mango'])
        self.assert_successful(QueryCommand)
