from milodb.commands.test_command_base import CommandTestBase

class TestFactory(CommandTestBase):
    def test_empty_input_returns_failure(self):
        self.parse_test([])
        self.assert_empty(self.list_of_command_names)

    def test_unknown_command_returns_failure(self):
        self.parse_test(['mango'])
        self.assert_unsuccessful(None, 0, 'Unknown command', self.list_of_command_names)
