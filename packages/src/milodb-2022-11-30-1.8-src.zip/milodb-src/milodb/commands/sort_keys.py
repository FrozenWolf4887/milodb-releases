import milodb.query as query
from milodb.tease import Tease, TeaseDateProperty, TeaseFloatProperty, TeaseIntProperty, TeaseStrProperty, TeaseTypeProperty
import datetime
from abc import ABC, abstractmethod
from enum import Enum
from typing import List, TypeVar

class CompareResult(Enum):
    LEFT_IS_LESS: int = -1
    BOTH_ARE_SAME: int = 0
    LEFT_IS_MORE: int = 1

    def invert(self) -> 'CompareResult':
        return CompareResult(self.value * -1)

class SortKey(ABC):
    @abstractmethod
    def get_name(self) -> str: pass

    @abstractmethod
    def get_description(self) -> str: pass

    @abstractmethod
    def compare(self, left: query.TeaseMatch, right: query.TeaseMatch) -> CompareResult: pass

class IntegerFieldSortKey(SortKey):
    def __init__(self, name: str, tease_property: TeaseIntProperty, description: str) -> None:
        self._name: str = name
        self._tease_property: TeaseIntProperty = tease_property
        self._description = description

    def get_name(self) -> str:
        return self._name

    def get_description(self) -> str:
        return self._description

    def compare(self, left: query.TeaseMatch, right: query.TeaseMatch) -> CompareResult:
        left_value: int = left.tease.get_int_property(self._tease_property)
        right_value: int = right.tease.get_int_property(self._tease_property)
        return _diff(left_value, right_value)

class FloatFieldSortKey(SortKey):
    def __init__(self, name: str, tease_property: TeaseFloatProperty, description: str) -> None:
        self._name: str = name
        self._tease_property: TeaseFloatProperty = tease_property
        self._description = description

    def get_name(self) -> str:
        return self._name

    def get_description(self) -> str:
        return self._description

    def compare(self, left: query.TeaseMatch, right: query.TeaseMatch) -> CompareResult:
        left_value: float = left.tease.get_float_property(self._tease_property)
        right_value: float = right.tease.get_float_property(self._tease_property)
        return _diff(left_value, right_value)

class StringFieldSortKey(SortKey):
    def __init__(self, name: str, tease_property: TeaseStrProperty, description: str) -> None:
        self._name: str = name
        self._tease_property: TeaseStrProperty = tease_property
        self._description = description

    def get_name(self) -> str:
        return self._name

    def get_description(self) -> str:
        return self._description

    def compare(self, left: query.TeaseMatch, right: query.TeaseMatch) -> CompareResult:
        left_value: str = left.tease.get_str_property(self._tease_property)
        right_value: str = right.tease.get_str_property(self._tease_property)
        return _diff(left_value, right_value)

class TeaseTypeSortKey(SortKey):
    def __init__(self, name: str, tease_property: TeaseTypeProperty, description: str) -> None:
        self._name: str = name
        self._tease_property: TeaseTypeProperty = tease_property
        self._description = description

    def get_name(self) -> str:
        return self._name

    def get_description(self) -> str:
        return self._description

    def compare(self, left: query.TeaseMatch, right: query.TeaseMatch) -> CompareResult:
        left_value: str = left.tease.get_type_property(self._tease_property).value
        right_value: str = right.tease.get_type_property(self._tease_property).value
        return _diff(left_value, right_value)

class DateFieldSortKey(SortKey):
    def __init__(self, name: str, tease_property: TeaseDateProperty, description: str) -> None:
        self._name: str = name
        self._tease_property: TeaseDateProperty = tease_property
        self._description = description

    def get_name(self) -> str:
        return self._name

    def get_description(self) -> str:
        return self._description

    def compare(self, left: query.TeaseMatch, right: query.TeaseMatch) -> CompareResult:
        left_value: datetime.date = left.tease.get_date_property(self._tease_property)
        right_value: datetime.date = right.tease.get_date_property(self._tease_property)
        return _diff(left_value, right_value)

class TotmTagSortKey(SortKey):
    def __init__(self, name: str, description: str) -> None:
        self._name: str = name
        self._description = description

    def get_name(self) -> str:
        return self._name

    def get_description(self) -> str:
        return self._description

    def compare(self, left: query.TeaseMatch, right: query.TeaseMatch) -> CompareResult:
        left_value: int = left.tease.totm_status.value
        right_value: int = right.tease.totm_status.value
        return _diff(left_value, right_value)

class MatchCountSortKey(SortKey):
    def __init__(self, name: str, description: str) -> None:
        self._name: str = name
        self._description = description

    def get_name(self) -> str:
        return self._name

    def get_description(self) -> str:
        return self._description

    def compare(self, left: query.TeaseMatch, right: query.TeaseMatch) -> CompareResult:
        left_value: int = left.get_match_count()
        right_value: int = right.get_match_count()
        return _diff(left_value, right_value)

class OrderedSortKey(SortKey):
    def __init__(self, data_sort_key: SortKey, is_ascending: bool) -> None:
        self._data_sort_key: SortKey = data_sort_key
        self._is_ascending: bool = is_ascending

    def get_name(self) -> str:
        return self._data_sort_key.get_name()

    def get_description(self) -> str:
        return self._data_sort_key.get_description()

    def is_ascending(self) -> bool:
        return self._is_ascending

    def compare(self, left: query.TeaseMatch, right: query.TeaseMatch) -> CompareResult:
        compare_result: CompareResult = self._data_sort_key.compare(left, right)
        if self._is_ascending:
            return compare_result
        else:
            return compare_result.invert()

T = TypeVar("T", int, float, str, datetime.date)
def _diff(left: T, right: T) -> CompareResult:
    if left < right:
        return CompareResult.LEFT_IS_LESS
    elif left > right:
        return CompareResult.LEFT_IS_MORE
    else:
        return CompareResult.BOTH_ARE_SAME

list_of_available_sort_keys: List[SortKey] = [
    IntegerFieldSortKey('teaseId', Tease.tease_id, 'Numerical id of the tease'),
    IntegerFieldSortKey('authorId', Tease.author_id, 'Numerical id of the author'),
    DateFieldSortKey('date', Tease.date, 'Published date of the tease'),
    StringFieldSortKey('title', Tease.title, 'Title of the tease'),
    FloatFieldSortKey('rating', Tease.rating_value, 'Value rating of the tease'),
    TeaseTypeSortKey('type', Tease.type, 'EOS, regular, audio, etc. tease type'),
    TotmTagSortKey('totm', 'Tease-Of-The-Month nominees and winners'),
    MatchCountSortKey('hits', 'Number of tease field matches from the last query')
]

default_sort_key: OrderedSortKey = OrderedSortKey(list_of_available_sort_keys[0], True)

default_list_of_active_sort_keys: List[OrderedSortKey] = [
    default_sort_key
]
