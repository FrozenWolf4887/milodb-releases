import milodb.query as query
from milodb.commands.command import CommandContext
from milodb.commands.sort_keys import default_sort_key, CompareResult, OrderedSortKey
import functools
from typing import List

def sort_tease_matches(context: CommandContext) -> None:
    list_of_sort_keys: List[OrderedSortKey] = context.list_of_active_sort_keys + [default_sort_key]

    if context.list_of_tease_matches and context.list_of_active_sort_keys:
        def custom_comparer(left: query.TeaseMatch, right: query.TeaseMatch) -> int:
            for sort_key in list_of_sort_keys:
                compare_result: CompareResult = sort_key.compare(left, right)
                if compare_result != CompareResult.BOTH_ARE_SAME:
                    return compare_result.value
            return CompareResult.BOTH_ARE_SAME.value

        context.list_of_tease_matches = sorted(context.list_of_tease_matches, key=functools.cmp_to_key(custom_comparer))
        index: int
        tease_match: query.TeaseMatch
        for index, tease_match in enumerate(context.list_of_tease_matches):
            tease_match.index_of_match = index + 1

def count_words(text: str) -> int:
    return len(text.split())

class WordWrapper:
    def __init__(self, text: str, max_line_length: int) -> None:
        self._max_line_length: int = max_line_length
        self._result_text = ""
        self._line_length: int = 0
        self._indent_length: int = 0
        self._current_word: str = ""
        self._is_in_space: bool = False
        self._number_of_spaces: int = 0

        char: str
        for char in text:
            self._process_char(char)

        if self._line_length + self._number_of_spaces + len(self._current_word) > max_line_length:
            self._result_text += '\n'
            self._result_text += ' ' * self._indent_length
            self._result_text += self._current_word
        else:
            self._result_text += ' ' * self._number_of_spaces
            self._result_text += self._current_word

    @property
    def text(self) -> str:
        return self._result_text

    def _process_char(self, char: str) -> None:
        if char == '\n':
            self._process_linefeed()
        elif char == ' ':
            self._process_space()
        elif char == '\t':
            self._process_indent()
        else:
            self._is_in_space = False
            self._current_word += char

    def _process_linefeed(self) -> None:
        if self._line_length + self._number_of_spaces + len(self._current_word) >= self._max_line_length:
            self._result_text += '\n'
            self._result_text += ' ' * self._indent_length
            self._result_text += self._current_word
        else:
            self._result_text += ' ' * self._number_of_spaces
            self._result_text += self._current_word
        self._result_text += '\n'
        self._line_length = 0
        self._indent_length = 0
        self._current_word = ""
        self._is_in_space = False
        self._number_of_spaces = 0

    def _process_space(self) -> None:
        if self._is_in_space:
            self._number_of_spaces += 1
        else:
            self._is_in_space = True
            if self._line_length + self._number_of_spaces + len(self._current_word) > self._max_line_length:
                self._result_text += '\n'
                self._result_text += ' ' * self._indent_length
                self._result_text += self._current_word
                self._line_length = self._indent_length + len(self._current_word)
                self._current_word = ""
                self._number_of_spaces = 0
            else:
                self._result_text += ' ' * self._number_of_spaces
                self._result_text += self._current_word
                self._line_length += self._number_of_spaces + len(self._current_word)
            self._number_of_spaces = 1
            self._current_word = ""

    def _process_indent(self) -> None:
        self._indent_length = self._line_length + self._number_of_spaces
