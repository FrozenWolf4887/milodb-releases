from milodb.commands.highlight_command import HighlightCommand
from milodb.commands.test_command_base import CommandTestBase

class TestHilightCommand(CommandTestBase):
    def test_without_arguments_returns_success(self):
        self.parse_test(['highlight'])
        self.assert_successful(HighlightCommand)

    def test_with_off_argument_returns_success(self):
        self.parse_test(['highlight', 'off'])
        self.assert_successful(HighlightCommand)

    def test_with_on_argument_returns_success(self):
        self.parse_test(['highlight', 'on'])
        self.assert_successful(HighlightCommand)

    def test_with_invalid_argument_returns_failure(self):
        self.parse_test(['highlight', 'mango'])
        self.assert_unsuccessful(HighlightCommand, 1, 'Unknown enumeration value', ['on', 'off'])

    def test_with_redundant_argument_returns_failure(self):
        self.parse_test(['highlight', 'on', 'off'])
        self.assert_unsuccessful(HighlightCommand, 2, 'Unexpected additional parameter', None)
