import milodb.query as query
from milodb.commands.argument_stream import ArgumentStream
from milodb.commands.sort_keys import OrderedSortKey, SortKey
from milodb.config import SessionConfig, SystemConfig
from milodb.database import Database
from milodb.output.outputter import Outputter
from milodb.user_variables import UserVariables
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import List, Optional, Type

@dataclass
class CommandContext:
    quit_flag: bool
    database: Database
    command_factory: 'CommandFactory'
    session_config: SessionConfig
    system_config: SystemConfig
    user_variables: UserVariables
    list_of_tease_matches: Optional[List[query.TeaseMatch]]
    list_of_available_sort_keys: List[SortKey]
    list_of_active_sort_keys: List[OrderedSortKey]
    list_of_outputters: List[Outputter]
    current_outputter: Outputter

class Command(ABC):
    @abstractmethod
    def __init__(self, context: CommandContext) -> None:
        pass

    @abstractmethod
    def load(self, argument_stream: ArgumentStream) -> Optional[List[str]]:
        pass

    @abstractmethod
    def execute(self) -> None:
        pass

    @classmethod
    @abstractmethod
    def get_one_line_summary(cls) -> str:
        pass

    @classmethod
    @abstractmethod
    def get_detailed_summary(cls, context: CommandContext) -> str:
        pass

class CommandFactory(ABC):
    @abstractmethod
    def try_get_command_class_from_name(self, name: str) -> Optional[Type[Command]]:
        pass

    @abstractmethod
    def get_list_of_command_names(self) -> List[str]:
        pass
