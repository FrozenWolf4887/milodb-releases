from milodb.user_variables import VARIABLE_FULL_NAME_PATTERN, UserVariables
from dataclasses import dataclass
from typing import List, Optional

@dataclass
class StartEnd:
    start: int
    end: int

@dataclass
class Token:
    text: str
    token_number: int
    outer_indices: StartEnd
    inner_indices: StartEnd

@dataclass
class TokenStreamError(Exception):
    cause_of_fault_text: str
    cause_of_fault_character_index: int
    cause_of_fault_token: Optional[Token] = None
    list_of_expected_text: Optional[List[str]] = None

class TokenStream:
    def __init__(self, text: str) -> None:
        self._text: str = text
        self._index: int = 0
        self._queued_tokens: List[Token] = []
        self._token_number: int = 0
        self._token_text: str = ""
        self._current_outer_start_index: int = 0
        self._current_inner_start_index: int = 0
        self._is_escaping: bool = False
        self._is_in_token: bool = False
        self._is_in_quoted_string: bool = False
        self._string_quote: str = ''
        self._expecting_delimiter: bool = False

    def get_all_text(self) -> str:
        return self._text

    def next(self) -> Optional[Token]:
        if self._queued_tokens:
            return self._queued_tokens.pop(0)

        while not self._queued_tokens and self._index < len(self._text):
            self._process_character(self._text[self._index])
            self._index += 1

        if not self._queued_tokens:
            if self._is_escaping:
                raise(TokenStreamError('Trailing escape character at end of text', len(self._text)))

            if self._is_in_quoted_string:
                raise(TokenStreamError('String not terminated at end of text', len(self._text)))

            if self._token_text:
                self._queue_token(self._token_text, StartEnd(self._current_outer_start_index, len(self._text)), StartEnd(self._current_outer_start_index, len(self._text)))
                self._token_text = ""

        return self._queued_tokens.pop(0) if self._queued_tokens else None

    def get_remaining_raw_text(self) -> str:
        if self._queued_tokens:
            return self._text[self._queued_tokens[0].outer_indices.start:]
        else:
            if self._index:
                if self._index < len(self._text):
                    return self._text[self._index-1:]
                else:
                    return ''
            else:
                return self._text

    def _process_character(self, c: str) -> None:
        if self._expecting_delimiter:
            if c not in [' ', '(', ')']:
                raise TokenStreamError('Expecting delimiter', self._index)
            self._expecting_delimiter = False

        if self._is_escaping:
            self._process_escaped_character(c)
        else:
            self._process_non_escaped_character(c)

    def _process_escaped_character(self, c: str) -> None:
        if c in ['"', "'"]:
            self._token_text += c
        else:
            self._token_text += '\\' + c
        self._is_escaping = False

    def _process_non_escaped_character(self, c: str) -> None:
        if c == '\\':
            self._is_escaping = True
        else:
            if self._is_in_quoted_string:
                self._process_character_in_string(c)
            else:
                self._process_character_out_of_string(c)

    def _process_character_in_string(self, c: str) -> None:
        if c == self._string_quote:
            self._is_in_quoted_string = False
            self._queue_token(self._token_text, StartEnd(self._current_outer_start_index, self._index + 1), StartEnd(self._current_outer_start_index + 1, self._index))
            self._expecting_delimiter = True
        else:
            self._token_text += c

    def _process_character_out_of_string(self, c: str) -> None:
        if c in ['"', "'"]:
            self._is_in_quoted_string = True
            self._string_quote = c
            self._is_in_token = True
            self._current_outer_start_index = self._index
        else:
            if c in [' ', '(', ')']:
                if self._token_text:
                    self._queue_token(self._token_text, StartEnd(self._current_outer_start_index, self._index), StartEnd(self._current_outer_start_index, self._index))
                if c in ['(', ')']:
                    self._queue_token(c, StartEnd(self._index, self._index + 1), StartEnd(self._index, self._index + 1))
            else:
                if not self._is_in_token:
                    self._is_in_token = True
                    self._current_outer_start_index = self._index
                self._token_text += c

    def _queue_token(self, text: str, outer_indices: StartEnd, inner_indices: StartEnd) -> None:
        token = Token(text, self._token_number, outer_indices, inner_indices)
        self._queued_tokens.append(token)
        self._token_number += 1
        self._token_text = ""
        self._is_in_token = False

@dataclass
class _ActiveStream:
    variable_token: Optional[Token]
    token_stream: TokenStream
    last_token: Optional[Token] = None
    expanded_text: str = ''
    begin_expansion_char_index: int = 0

class ExpandingTokenStream:
    def __init__(self, text: str, variables: UserVariables) -> None:
        self._stack_of_active_streams: List[_ActiveStream] = [ _ActiveStream(None, TokenStream(text)) ]
        self._variables: UserVariables = variables
        self._is_expansion_enabled = True
        self._token_number: int = 0
        self._offset_character_index: int = 0
        self._retrieved_tokens: List[Token] = []

    def next(self) -> Optional[Token]:
        token: Optional[Token] = None

        while self._stack_of_active_streams and token is None:
            active_stream: _ActiveStream = self._stack_of_active_streams[-1]
            token = active_stream.token_stream.next()
            if token:
                active_stream.last_token = token
                if self._try_expand_token(token):
                    token = None
            else:
                self._pop_active_stream()

        if token:
            token = self._adjust_token_indices_for_expansion(token)
            self._retrieved_tokens.append(token)

        return token

    def get_remaining_raw_text(self) -> str:
        text = ''
        active_stream: _ActiveStream
        for active_stream in reversed(self._stack_of_active_streams):
            text += active_stream.token_stream.get_remaining_raw_text()
        return text

    def disable_expansion(self) -> None:
        self._is_expansion_enabled = False

    def _try_expand_token(self, token: Token) -> bool:
        did_expand: bool = False

        if self._is_expansion_enabled and token.text.startswith('$') and not token.text.startswith('$$'):
            if VARIABLE_FULL_NAME_PATTERN.fullmatch(token.text):
                self._check_for_recursive_variable_reference(token)
                self._handle_variable_expansion(token)
                did_expand = True
            else:
                list_of_variables: List[str] = [ f'${variable_name}' for variable_name in self._variables.get_list_of_names() ]
                raise TokenStreamError(
                    f"Invalid variable reference '{token.text}' does not match pattern '{VARIABLE_FULL_NAME_PATTERN.pattern}'",
                    token.inner_indices.start, token, list_of_variables)

        return did_expand

    def _check_for_recursive_variable_reference(self, token: Token) -> None:
        active_stream: _ActiveStream
        for active_stream in self._stack_of_active_streams:
            if active_stream.variable_token and token.text == active_stream.variable_token.text:
                variable_chain: List[str] = [ f"'{entry.variable_token.text}'" for entry in self._stack_of_active_streams if entry.variable_token ] + [ f"'{token.text}'" ]
                raise TokenStreamError(f"Recursive variable reference detected: {' -> '.join(variable_chain)}", token.inner_indices.start)

    def _handle_variable_expansion(self, token: Token) -> None:
        variable_name: str = token.text[1:]
        variable_value: Optional[str] = self._variables.try_retrieve(variable_name)
        if variable_value is not None:
            active_stream: _ActiveStream = self._stack_of_active_streams[-1]
            active_stream.expanded_text += active_stream.token_stream.get_all_text()[active_stream.begin_expansion_char_index:token.inner_indices.start]
            self._stack_of_active_streams.append(_ActiveStream(token, TokenStream(variable_value)))
            self._offset_character_index += token.outer_indices.start
        else:
            list_of_variables: List[str] = [ f'${variable_name}' for variable_name in self._variables.get_list_of_names() ]
            raise TokenStreamError(f"Unknown variable reference '${variable_name}'", token.inner_indices.start, token, list_of_variables)

    def _pop_active_stream(self) -> None:
        active_stream: _ActiveStream = self._stack_of_active_streams[-1]

        last_token: Optional[Token] = active_stream.last_token
        if last_token:
            self._offset_character_index += last_token.outer_indices.end

        variable_token: Optional[Token] = active_stream.variable_token
        if variable_token:
            self._offset_character_index -= variable_token.outer_indices.end

        self._stack_of_active_streams.pop()

    def _adjust_token_indices_for_expansion(self, token: Token) -> Token:
        new_token: Token = Token(
            token.text, self._token_number,
            StartEnd(token.outer_indices.start + self._offset_character_index, token.outer_indices.end + self._offset_character_index),
            StartEnd(token.inner_indices.start + self._offset_character_index, token.inner_indices.end + self._offset_character_index))
        self._token_number += 1
        return new_token
