#!/bin/bash
set -e
echo "** Prepare virtual environment"
python -m venv /tmp/mvdb/venv --clear
source /tmp/mvdb/venv/bin/activate
pip install -r requirements-linux.txt
echo "** Build executable"
pyinstaller --distpath bin --workpath /tmp/mvdb/build --clean ../milodb.spec
echo "** Save requirements"
pip freeze | tee requirements-linux.txt
