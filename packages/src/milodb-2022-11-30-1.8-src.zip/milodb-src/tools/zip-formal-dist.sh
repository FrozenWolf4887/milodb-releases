#!/bin/bash
set -e
cd ..

assemblyDirpath="/tmp/milodb-assembly"

listOfIncludeBinFiles=(
    "tools/bin/milodb.exe"
    "tools/bin/milodb"
    "database.mdb"
    "default.css"
    "changelog.md"
)
listOfIncludeSrcFiles=(
    "default.css"
    "changelog.md"
    "run.py"
    "test.py"
)
listOfIncludeSrcDirs=(
    "tools/"
    "milodb/"
)
listOfExcludeSrcPaths=(
    "__pycache__/"
    "tools/bin/"
    "tools/dist/"
)

function fail()
{
    messages=("$@")

    isFirstLine=1
    for line in "${messages[@]}"
    do
        if [ $isFirstLine -eq 1 ]
        then
            echo "Error: $line" 1>&2
            isFirstLine=0
        else
            echo "  $line" 1>&2
        fi
    done
    echo "Aborting" 1>&2
    exit 1
}

function assertToolExists()
{
    toolName="$1"
    if ! which "$toolName" > /dev/null
    then
        fail "Tool '$toolName' not installed or not avaialable"
    fi
}

function assertFileExists()
{
    filePath="$1"
    if [ ! -f "$filePath" ]
    then
        fail "'$filePath' missing"
    fi
}

function assertDirExists()
{
    dirPath="$1"
    if [ ! -d "$dirPath" ]
    then
        fail "'$dirPath' missing"
    fi
}

function assertDirDoesntExist()
{
    dirPath="$1"
    if [ -d "$dirPath" ]
    then
        fail "'$dirPath' already exists" "Please remove this output directory first"
    fi
}

function assertFileIsNewerThanFile()
{
    filepath1="$1"
    filepath2="$2"
    timestamp1=$(stat "$filepath1" --format=%Y)
    timestamp2=$(stat "$filepath2" --format=%Y)
    if [ "$timestamp1" -lt "$timestamp2" ]
    then
        fail "File '$filepath1' must be newer than '$filepath2'"
    fi
}

startingDirpath="$(pwd)"

assertToolExists zip
for binFile in "${listOfIncludeBinFiles[@]}"
do
    assertFileExists "$binFile"
done
for srcFile in "${listOfIncludeSrcFiles[@]}"
do
    assertFileExists "$srcFile"
done
for srcDir in "${listOfIncludeSrcDirs[@]}"
do
    assertDirExists "$srcDir"
done
assertFileIsNewerThanFile "tools/bin/milodb" "milodb/version.py"
assertFileIsNewerThanFile "tools/bin/milodb.exe" "milodb/version.py"
assertDirDoesntExist "tools/dist"
assertDirDoesntExist "$assemblyDirpath"

versionNumberLine=$(grep -o "MILODB_VERSION:.*=.*" "milodb/version.py")
if [[ "$versionNumberLine" =~ =\ *[\'\"]([0-9]+(\.[0-9]+)+)[\'\"]$ ]]
then
    versionNumber="${BASH_REMATCH[1]}"
else
    fail "Version number has not been set." \
         "Was not found in 'version.py' that contained line:" \
         "    $versionNumberLine"
fi

versionDateLine=$(grep -o "MILODB_DATE:.*=.*" "milodb/version.py")
if [[ "$versionDateLine" =~ =\ *[\'\"](20[0-9][0-9]-[0-9][0-9]-[0-9][0-9])[\'\"]$ ]]
then
    versionDate="${BASH_REMATCH[1]}"
else
    fail "Version date has not been set." \
         "Was not found in 'version.py' that contained line:" \
         "    $versionDateLine"
fi

expectedChangeLogEntry="$versionNumber, $versionDate"
if ! grep "$expectedChangeLogEntry" "changelog.md" > /dev/null
then
    fail "Change log doesn't include current version" "Expected: '$expectedChangeLogEntry'"
fi

assemblyBinDirpath="$assemblyDirpath/milodb"
echo "Assembling binaries to '$assemblyBinDirpath'"
mkdir -p "$assemblyBinDirpath"
for binFile in "${listOfIncludeBinFiles[@]}"
do
    cp "$binFile" "$assemblyBinDirpath/"
done

assemblySrcDirpath="$assemblyDirpath/milodb-src"
echo "Assembling source to '$assemblySrcDirpath'"
mkdir -p "$assemblySrcDirpath"
excludeArgs=()
for excludeSrcPath in "${listOfExcludeSrcPaths[@]}"
do
    excludeArgs+=("--exclude" "$excludeSrcPath")
done
rsync --recursive --relative --prune-empty-dirs "${excludeArgs[@]}" "${listOfIncludeSrcFiles[@]}" "${listOfIncludeSrcDirs[@]}" "$assemblySrcDirpath"

zipBinFilename="milodb-$versionDate-$versionNumber.zip"
echo "Packing binaries to '$zipBinFilename'"
echo
cd "$assemblyDirpath"
zip -r9 "$zipBinFilename" milodb
cd "$startingDirpath"

zipSrcFilename="milodb-$versionDate-$versionNumber-src.zip"
echo
echo "Packing source to '$zipSrcFilename'"
echo
cd "$assemblyDirpath"
zip -r9 "$zipSrcFilename" milodb-src
cd "$startingDirpath"

mkdir "tools/dist"
cp "$assemblyDirpath/$zipBinFilename" "tools/dist/"
cp "$assemblyDirpath/$zipSrcFilename" "tools/dist/"

echo
echo Done
echo
ls -lh "tools/dist/"
