@echo off
echo ** Prepare virtual environment
python -m venv "%TEMP%\mvdb\venv" --clear
call "%TEMP%\mvdb\venv\Scripts\activate.bat"
rem python -m pip install --upgrade pip
rem pip install wheel
pip install -r requirements-windows.txt
echo ** Build executable
pyinstaller --distpath bin --workpath "%TEMP%\mvdb\build" --clean ..\milodb.spec
echo "** Save requirements"
pip freeze > "requirements-windows.txt"
type "requirements-windows.txt"
call "%TEMP%\mvdb\venv\Scripts\deactivate.bat"
