#!/usr/bin/env python3

import sys

ver_major, ver_minor, ver_micro, ver_releaselevel, ver_serial = sys.version_info
if ver_major != 3 or ver_minor < 7:
    print("Python version 3.7 or greater required")
    print("Actual version is " + sys.version)
    quit(1)

if __name__ == "__main__":
    from milodb.main import Main
    Main()
