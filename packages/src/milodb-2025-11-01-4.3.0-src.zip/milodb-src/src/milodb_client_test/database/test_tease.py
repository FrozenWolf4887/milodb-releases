# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import datetime
import unittest
from collections.abc import Mapping, MutableMapping, Sequence
from typing import override
from milodb_client.database.author import Author
from milodb_client.database.tease import Tease, TeaseLoadError, TeaseType, TotmStatus, load_tease
from milodb_client.database.tease_page import TeasePage

_DICT_KEY_AUTHOR_ID: str = 'aid'
_DICT_KEY_DATE: str = 'dat'
_DICT_KEY_IMAGE_COUNT: str = 'imr'
_DICT_KEY_RATING: str = 'rvl'
_DICT_KEY_TAGS: str = 'tgs'
_DICT_KEY_PAGES: str = 'pgs'
_DICT_KEY_PAGE_REF: str = 'ref'
_DICT_KEY_PAGE_TEXT: str = 'txt'
_DICT_KEY_THUMBNAIL: str = 'thm'
_DICT_KEY_TITLE: str = 'ttl'
_DICT_KEY_TYPE: str = 'typ'
_DICT_KEY_UNIQUE_IMAGE_COUNT: str = 'imu'

_DEFAULT_AUTHOR_ID: int = 123
_DEFAULT_TEASE_ID: int = 246
_DICT_DEFAULT_VALUE_AUTHOR_ID: int = _DEFAULT_AUTHOR_ID
_DICT_DEFAULT_VALUE_DATE: str = '2018-07-30'
_DICT_DEFAULT_VALUE_IMAGE_COUNT: int = 456
_DICT_DEFAULT_VALUE_RATING: float = 2.5
_DICT_DEFAULT_VALUE_TAGS: str = ':first:second:third:'
_DICT_DEFAULT_VALUE_PAGE_1: str = 'page1'
_DICT_DEFAULT_VALUE_PAGE_2: str = 'page2'
_DICT_DEFAULT_VALUE_PAGE_3: str = 'page3'
_DICT_DEFAULT_VALUE_TEXT_1: str = 'First'
_DICT_DEFAULT_VALUE_TEXT_2: str = 'Second'
_DICT_DEFAULT_VALUE_TEXT_3: str = 'Third'
_DICT_DEFAULT_VALUE_THUMBNAIL: str = 'https://some.thumbnail/image.jpg'
_DICT_DEFAULT_VALUE_TITLE: str = 'This is a Title'
_DICT_DEFAULT_VALUE_TYPE: int = 0
_DICT_DEFAULT_VALUE_UNIQUE_IMAGE_COUNT: int = 789

_TEASE_DEFAULT_VALUE_DATE: datetime.date = datetime.date(2018, 7, 30)
_TEASE_DEFAULT_VALUE_IMAGE_COUNT: int = 456
_TEASE_DEFAULT_VALUE_RATING: float = 2.5
_TEASE_DEFAULT_VALUE_TAGS: Sequence[str] = ['first', 'second', 'third']
_TEASE_DEFAULT_VALUE_TEASE_ID: int = 246
_TEASE_DEFAULT_VALUE_PAGES: Sequence[TeasePage] = [
    TeasePage('page1', 'First'),
    TeasePage('page2', 'Second'),
    TeasePage('page3', 'Third')]
_TEASE_DEFAULT_VALUE_THUMBNAIL: str = 'https://some.thumbnail/image.jpg'
_TEASE_DEFAULT_VALUE_TITLE: str = 'This is a Title'
_TEASE_DEFAULT_VALUE_TOTM: TotmStatus = TotmStatus.NONE
_TEASE_DEFAULT_VALUE_TYPE: TeaseType = TeaseType.REGULAR
_TEASE_DEFAULT_VALUE_UNIQUE_IMAGE_COUNT: int = 789

_TEASE_METADATA: Mapping[object, object] = {
    _DICT_KEY_AUTHOR_ID          : _DICT_DEFAULT_VALUE_AUTHOR_ID,
    _DICT_KEY_DATE               : _DICT_DEFAULT_VALUE_DATE,
    _DICT_KEY_IMAGE_COUNT        : _DICT_DEFAULT_VALUE_IMAGE_COUNT,
    _DICT_KEY_RATING             : _DICT_DEFAULT_VALUE_RATING,
    _DICT_KEY_TAGS               : _DICT_DEFAULT_VALUE_TAGS,
    _DICT_KEY_PAGES : [ {
        _DICT_KEY_PAGE_REF: _DICT_DEFAULT_VALUE_PAGE_1,
        _DICT_KEY_PAGE_TEXT: _DICT_DEFAULT_VALUE_TEXT_1,
        }, {
        _DICT_KEY_PAGE_REF: _DICT_DEFAULT_VALUE_PAGE_2,
        _DICT_KEY_PAGE_TEXT: _DICT_DEFAULT_VALUE_TEXT_2,
        }, {
        _DICT_KEY_PAGE_REF: _DICT_DEFAULT_VALUE_PAGE_3,
        _DICT_KEY_PAGE_TEXT: _DICT_DEFAULT_VALUE_TEXT_3,
        },
    ],
    _DICT_KEY_THUMBNAIL          : _DICT_DEFAULT_VALUE_THUMBNAIL,
    _DICT_KEY_TITLE              : _DICT_DEFAULT_VALUE_TITLE,
    _DICT_KEY_TYPE               : _DICT_DEFAULT_VALUE_TYPE,
    _DICT_KEY_UNIQUE_IMAGE_COUNT : _DICT_DEFAULT_VALUE_UNIQUE_IMAGE_COUNT,
}

_AUTHOR_METADATA: Mapping[object, object] = {
    'anm': 'Some name',
    'agn': False,
}

class _TestTeaseBase(unittest.TestCase):
    @override
    def setUp(self) -> None:
        self.author_id: int = _DEFAULT_AUTHOR_ID
        self.tease_id: int = _DEFAULT_TEASE_ID
        self.tease_metadata: MutableMapping[object, object] = dict(_TEASE_METADATA)
        self.expect_author: Author | None = None
        self.expect_date: datetime.date = _TEASE_DEFAULT_VALUE_DATE
        self.expect_image_count: int = _TEASE_DEFAULT_VALUE_IMAGE_COUNT
        self.expect_rating: float = _TEASE_DEFAULT_VALUE_RATING
        self.expect_tags: Sequence[str] = _TEASE_DEFAULT_VALUE_TAGS
        self.expect_tease_id: int = _TEASE_DEFAULT_VALUE_TEASE_ID
        self.expect_pages: Sequence[TeasePage] = _TEASE_DEFAULT_VALUE_PAGES
        self.expect_thumbnail: str = _TEASE_DEFAULT_VALUE_THUMBNAIL
        self.expect_title: str = _TEASE_DEFAULT_VALUE_TITLE
        self.expect_totm: TotmStatus = _TEASE_DEFAULT_VALUE_TOTM
        self.expect_type: TeaseType = _TEASE_DEFAULT_VALUE_TYPE
        self.expect_unique_image_count: int = _TEASE_DEFAULT_VALUE_UNIQUE_IMAGE_COUNT

    def _remove_key(self, key: str) -> None:
        del self.tease_metadata[key]

    def _change_key(self, key: str, value: object) -> None:
        self.tease_metadata[key] = value

    def _load_and_verify(self) -> None:
        author: Author = Author(self.author_id, _AUTHOR_METADATA)
        tease: Tease = load_tease(self.tease_id, self.tease_metadata, {self.author_id: author})
        self.assertEqual(self.expect_author or author, tease.author)
        self.assertEqual(self.expect_date, tease.date)
        self.assertEqual(self.expect_image_count, tease.count_of_images)
        self.assertEqual(self.expect_rating, tease.rating_value)
        self.assertSequenceEqual(self.expect_tags, tease.list_of_tags)
        self.assertEqual(self.expect_tease_id, tease.tease_id)
        self.assertSequenceEqual(self.expect_pages, tease.list_of_pages)
        self.assertEqual(self.expect_thumbnail, tease.thumbnail)
        self.assertEqual(self.expect_title, tease.title)
        self.assertEqual(self.expect_type, tease.tease_type)
        self.assertEqual(self.expect_unique_image_count, tease.count_of_unique_images)

    def _load_and_verify_exception_missing_key(self, key: str) -> None:
        with self.assertRaises(TeaseLoadError) as ex:
            load_tease(self.tease_id, self.tease_metadata, {self.author_id: Author(self.author_id, _AUTHOR_METADATA)})
        self.assertEqual(f"Key '{key}' is missing", str(ex.exception))

    def _load_and_verify_exception_not_an_integer(self, key: str) -> None:
        with self.assertRaises(TeaseLoadError) as ex:
            load_tease(self.tease_id, self.tease_metadata, {self.author_id: Author(self.author_id, _AUTHOR_METADATA)})
        self.assertEqual(f"Key '{key}' is not an integer", str(ex.exception))

    def _load_and_verify_exception_not_a_decimal_number(self, key: str) -> None:
        with self.assertRaises(TeaseLoadError) as ex:
            load_tease(self.tease_id, self.tease_metadata, {self.author_id: Author(self.author_id, _AUTHOR_METADATA)})
        self.assertEqual(f"Key '{key}' is not a decimal", str(ex.exception))

    def _load_and_verify_exception_unknown_dictionary_entry(self, key: str, dict_key: int) -> None:
        with self.assertRaises(TeaseLoadError) as ex:
            load_tease(self.tease_id, self.tease_metadata, {self.author_id: Author(self.author_id, _AUTHOR_METADATA)})
        self.assertEqual(f"Key '{key}' value '{dict_key}' is not recognised", str(ex.exception))

    def _load_and_verify_exception_not_a_string(self, key: str) -> None:
        with self.assertRaises(TeaseLoadError) as ex:
            load_tease(self.tease_id, self.tease_metadata, {self.author_id: Author(self.author_id, _AUTHOR_METADATA)})
        self.assertEqual(f"Key '{key}' is not a string", str(ex.exception))

    def _load_and_verify_exception_number_below_minimum(self, key: str, value: float, min_value: float) -> None:
        with self.assertRaises(TeaseLoadError) as ex:
            load_tease(self.tease_id, self.tease_metadata, {self.author_id: Author(self.author_id, _AUTHOR_METADATA)})
        self.assertEqual(f"Key '{key}' value '{value}' should be '{min_value}' or greater", str(ex.exception))

    def _load_and_verify_exception_number_above_maximum(self, key: str, value: float, max_value: float) -> None:
        with self.assertRaises(TeaseLoadError) as ex:
            load_tease(self.tease_id, self.tease_metadata, {self.author_id: Author(self.author_id, _AUTHOR_METADATA)})
        self.assertEqual(f"Key '{key}' value '{value}' should be '{max_value}' or less", str(ex.exception))

    def _load_and_verify_exception_number_within_range(self, key: str, value: float, min_value: float, max_value: float) -> None:
        with self.assertRaises(TeaseLoadError) as ex:
            load_tease(self.tease_id, self.tease_metadata, {self.author_id: Author(self.author_id, _AUTHOR_METADATA)})
        self.assertEqual(f"Key '{key}' value '{value}' is out of range '{min_value}' to '{max_value}'", str(ex.exception))

    def _load_and_verify_exception_not_a_date(self, key: str, value: str) -> None:
        with self.assertRaises(TeaseLoadError) as ex:
            load_tease(self.tease_id, self.tease_metadata, {self.author_id: Author(self.author_id, _AUTHOR_METADATA)})
        self.assertEqual(f"Key '{key}' value '{value}' is not a valid ISO date", str(ex.exception))

    def _load_and_verify_exception_not_a_list(self, key: str) -> None:
        with self.assertRaises(TeaseLoadError) as ex:
            load_tease(self.tease_id, self.tease_metadata, {self.author_id: Author(self.author_id, _AUTHOR_METADATA)})
        self.assertEqual(f"Key '{key}' is not a list", str(ex.exception))

    def _load_and_verify_exception_not_a_dictionary_in_list(self, key: str, index: int) -> None:
        with self.assertRaises(TeaseLoadError) as ex:
            load_tease(self.tease_id, self.tease_metadata, {self.author_id: Author(self.author_id, _AUTHOR_METADATA)})
        self.assertEqual(f"Key '{key}' list entry #{index} is not a dictionary", str(ex.exception))

    def _load_and_verify_exception_unknown_author(self, author_id: int) -> None:
        with self.assertRaises(TeaseLoadError) as ex:
            load_tease(self.tease_id, self.tease_metadata, {self.author_id: Author(self.author_id, _AUTHOR_METADATA)})
        self.assertEqual(f"Unknown authorId @{author_id}", str(ex.exception))

class TestTeaseDefaults(_TestTeaseBase):
    def test_defaults_produces_all_defaults(self) -> None:
        self._load_and_verify()

class TestTeaseType(_TestTeaseBase):
    def test_valid_values_produces_expected_field(self) -> None:
        self._change_key(_DICT_KEY_TYPE, 0)
        self.expect_type = TeaseType.REGULAR
        self._load_and_verify()

        self._change_key(_DICT_KEY_TYPE, 1)
        self.expect_type = TeaseType.NYX
        self._load_and_verify()

        self._change_key(_DICT_KEY_TYPE, 2)
        self.expect_type = TeaseType.EOS
        self._load_and_verify()

        self._change_key(_DICT_KEY_TYPE, 3)
        self.expect_type = TeaseType.AUDIO
        self._load_and_verify()

    def test_missing_key_fails(self) -> None:
        self._remove_key(_DICT_KEY_TYPE)
        self._load_and_verify_exception_missing_key(_DICT_KEY_TYPE)

    def test_out_of_range_value_fails(self) -> None:
        self._change_key(_DICT_KEY_TYPE, -1)
        self._load_and_verify_exception_unknown_dictionary_entry(_DICT_KEY_TYPE, -1)

        self._change_key(_DICT_KEY_TYPE, 4)
        self._load_and_verify_exception_unknown_dictionary_entry(_DICT_KEY_TYPE, 4)

    def test_non_integer_value_fails(self) -> None:
        self._change_key(_DICT_KEY_TYPE, 'hello')
        self._load_and_verify_exception_not_an_integer(_DICT_KEY_TYPE)

class TestTeaseTitle(_TestTeaseBase):
    def test_specific_value_produces_expected_value(self) -> None:
        self._change_key(_DICT_KEY_TITLE, 'another title')
        self.expect_title = 'another title'
        self._load_and_verify()

    def test_empty_value_produces_empty_field(self) -> None:
        self._change_key(_DICT_KEY_TITLE, '')
        self.expect_title = ''
        self._load_and_verify()

    def test_missing_key_produces_blank_field(self) -> None:
        self._remove_key(_DICT_KEY_TITLE)
        self.expect_title = ''
        self._load_and_verify()

    def test_non_string_value_fails(self) -> None:
        self._change_key(_DICT_KEY_TITLE, 77)
        self._load_and_verify_exception_not_a_string(_DICT_KEY_TITLE)

class TestTeaseAuthorId(_TestTeaseBase):
    def test_specific_value_produces_expected_author(self) -> None:
        self.author_id = 38834
        self._change_key(_DICT_KEY_AUTHOR_ID, 38834)
        self._load_and_verify()

    def test_missing_key_produces_expected_author(self) -> None:
        self.author_id = 0
        self._remove_key(_DICT_KEY_AUTHOR_ID)
        self._load_and_verify()

    def test_unknown_author_fails(self) -> None:
        self.author_id = 1001
        self._change_key(_DICT_KEY_AUTHOR_ID, 8231)
        self._load_and_verify_exception_unknown_author(8231)

class TestTeaseDate(_TestTeaseBase):
    def test_specific_value_produces_expected_value(self) -> None:
        self._change_key(_DICT_KEY_DATE, '2035-09-16')
        self.expect_date = datetime.date(2035, 9, 16)
        self._load_and_verify()

    def test_invalid_value_fails(self) -> None:
        self._change_key(_DICT_KEY_DATE, '235-09-16')
        self._load_and_verify_exception_not_a_date(_DICT_KEY_DATE, '235-09-16')

    def test_missing_key_fails(self) -> None:
        self._remove_key(_DICT_KEY_DATE)
        self._load_and_verify_exception_missing_key(_DICT_KEY_DATE)

    def test_non_string_value_fails(self) -> None:
        self._change_key(_DICT_KEY_DATE, 1)
        self._load_and_verify_exception_not_a_string(_DICT_KEY_DATE)

class TestTeaseImageCount(_TestTeaseBase):
    def test_specific_value_produces_expected_value(self) -> None:
        self._change_key(_DICT_KEY_IMAGE_COUNT, 19451)
        self.expect_image_count = 19451
        self._load_and_verify()

    def test_out_of_range_value_fails(self) -> None:
        self._change_key(_DICT_KEY_IMAGE_COUNT, -1)
        self._load_and_verify_exception_number_below_minimum(_DICT_KEY_IMAGE_COUNT, -1, 0)

    def test_missing_key_uses_default(self) -> None:
        self._remove_key(_DICT_KEY_IMAGE_COUNT)
        self.expect_image_count = 0
        self._load_and_verify()

    def test_non_integer_value_fails(self) -> None:
        self._change_key(_DICT_KEY_IMAGE_COUNT, 'grub')
        self._load_and_verify_exception_not_an_integer(_DICT_KEY_IMAGE_COUNT)

class TestTeaseRating(_TestTeaseBase):
    def test_specific_value_produces_expected_value(self) -> None:
        self._change_key(_DICT_KEY_RATING, 0)
        self.expect_rating = 0.0
        self._load_and_verify()

        self._change_key(_DICT_KEY_RATING, 2)
        self.expect_rating = 2.0
        self._load_and_verify()

        self._change_key(_DICT_KEY_RATING, 4.3)
        self.expect_rating = 4.3
        self._load_and_verify()

        self._change_key(_DICT_KEY_RATING, 5)
        self.expect_rating = 5.0
        self._load_and_verify()

    def test_out_of_range_value_fails(self) -> None:
        self._change_key(_DICT_KEY_RATING, -0.1)
        self._load_and_verify_exception_number_within_range(_DICT_KEY_RATING, -0.1, 0.0, 5.0)

        self._change_key(_DICT_KEY_RATING, 5.1)
        self._load_and_verify_exception_number_within_range(_DICT_KEY_RATING, 5.1, 0.0, 5.0)

    def test_missing_key_uses_default(self) -> None:
        self._remove_key(_DICT_KEY_RATING)
        self.expect_rating = 0.0
        self._load_and_verify()

    def test_non_decimal_value_fails(self) -> None:
        self._change_key(_DICT_KEY_RATING, 'grub')
        self._load_and_verify_exception_not_a_decimal_number(_DICT_KEY_RATING)

class TestTeaseTeaseId(_TestTeaseBase):
    def test_integer_value_produces_expected_value(self) -> None:
        self.tease_id = 235911
        self.expect_tease_id = 235911
        self._load_and_verify()

class TestTeaseTags(_TestTeaseBase):
    def test_specific_value_produces_expected_value(self) -> None:
        self._change_key(_DICT_KEY_TAGS, ':ancient:frozen:wolf:')
        self.expect_tags = ['ancient', 'frozen', 'wolf']
        self._load_and_verify()

    def test_empty_value_produces_empty_list(self) -> None:
        self._change_key(_DICT_KEY_TAGS, '')
        self.expect_tags = []
        self._load_and_verify()

    def test_empty_value_with_only_delimiters_produces_empty_list(self) -> None:
        self._change_key(_DICT_KEY_TAGS, '::')
        self.expect_tags = []
        self._load_and_verify()

    def test_value_without_outer_delimiters_produces_list(self) -> None:
        self._change_key(_DICT_KEY_TAGS, 'chomp:paper:niche')
        self.expect_tags = ['chomp', 'paper', 'niche']
        self._load_and_verify()

    def test_value_with_black_tags_are_not_in_list(self) -> None:
        self._change_key(_DICT_KEY_TAGS, ':chomp::niche::')
        self.expect_tags = ['chomp', 'niche']
        self._load_and_verify()

    def test_missing_key_produces_empty_list(self) -> None:
        self._remove_key(_DICT_KEY_TAGS)
        self.expect_tags = []
        self._load_and_verify()

    def test_non_string_value_fails(self) -> None:
        self._change_key(_DICT_KEY_TAGS, 9211)
        self._load_and_verify_exception_not_a_string(_DICT_KEY_TAGS)

    def test_totm_nominee_tag_sets_totm_status(self) -> None:
        self._change_key(_DICT_KEY_TAGS, ':captain:totm-nominee:private:')
        self.expect_tags = ['captain', 'totm-nominee', 'private']
        self.expect_totm = TotmStatus.NOMINEE
        self._load_and_verify()

    def test_totm_tag_sets_totm_status(self) -> None:
        self._change_key(_DICT_KEY_TAGS, ':mad:crazy:totm:')
        self.expect_tags = ['mad', 'crazy', 'totm']
        self.expect_totm = TotmStatus.WINNER
        self._load_and_verify()

    def test_multiple_totm_tags_sets_totm_status(self) -> None:
        self._change_key(_DICT_KEY_TAGS, ':totm:mad:crazy:totm-nominee:')
        self.expect_tags = ['totm', 'mad', 'crazy', 'totm-nominee']
        self.expect_totm = TotmStatus.WINNER
        self._load_and_verify()

        self._change_key(_DICT_KEY_TAGS, ':mad:totm-nominee:crazy:totm')
        self.expect_tags = ['mad', 'totm-nominee', 'crazy', 'totm']
        self.expect_totm = TotmStatus.WINNER
        self._load_and_verify()

class TestTeaseText(_TestTeaseBase):
    def test_empty_list_produces_empty_list(self) -> None:
        self._change_key(_DICT_KEY_PAGES, [])
        self.expect_pages = []
        self._load_and_verify()

    def test_list_of_one_page_produces_list(self) -> None:
        self._change_key(_DICT_KEY_PAGES, [ {
            _DICT_KEY_PAGE_REF: 'testPage',
            _DICT_KEY_PAGE_TEXT: 'mangos',
            },
        ])
        self.expect_pages = [TeasePage('testPage', 'mangos')]
        self._load_and_verify()

    def test_list_of_three_pages_produces_list(self) -> None:
        self._change_key(_DICT_KEY_PAGES, [ {
            _DICT_KEY_PAGE_REF: 'testPage',
            _DICT_KEY_PAGE_TEXT: 'bananas',
            }, {
            _DICT_KEY_PAGE_REF: 'page2',
            _DICT_KEY_PAGE_TEXT: 'and',
            }, {
            _DICT_KEY_PAGE_REF: 'another-page',
            _DICT_KEY_PAGE_TEXT: 'cream',
            },
        ])
        self.expect_pages = [TeasePage('testPage', 'bananas'), TeasePage('page2', 'and'), TeasePage('another-page', 'cream')]
        self._load_and_verify()

    def test_missing_key_produces_empty_list(self) -> None:
        self._remove_key(_DICT_KEY_PAGES)
        self.expect_pages = []
        self._load_and_verify()

    def test_non_list_fails(self) -> None:
        self._change_key(_DICT_KEY_PAGES, 'bongos')
        self._load_and_verify_exception_not_a_list(_DICT_KEY_PAGES)

    def test_list_with_non_string_page_ref_fails(self) -> None:
        self._change_key(_DICT_KEY_PAGES, [ {
            _DICT_KEY_PAGE_REF: 'testPage',
            _DICT_KEY_PAGE_TEXT: 'bananas',
            }, {
            _DICT_KEY_PAGE_REF: 1234,
            _DICT_KEY_PAGE_TEXT: 'and\ncheap\nbees',
            }, {
            _DICT_KEY_PAGE_REF: 'another-page',
            _DICT_KEY_PAGE_TEXT: 'cream',
            },
        ])
        self._load_and_verify_exception_not_a_string(_DICT_KEY_PAGE_REF)

    def test_list_with_non_string_text_entry_fails(self) -> None:
        self._change_key(_DICT_KEY_PAGES, [ {
            _DICT_KEY_PAGE_REF: 'testPage',
            _DICT_KEY_PAGE_TEXT: 'bananas',
            }, {
            _DICT_KEY_PAGE_REF: 'something',
            _DICT_KEY_PAGE_TEXT: 25.0,
            }, {
            _DICT_KEY_PAGE_REF: 'another-page',
            _DICT_KEY_PAGE_TEXT: 'cream',
            },
        ])
        self._load_and_verify_exception_not_a_string(_DICT_KEY_PAGE_TEXT)

class TestTeaseThumbnail(_TestTeaseBase):
    def test_specific_value_produces_expected_value(self) -> None:
        self._change_key(_DICT_KEY_THUMBNAIL, 'another thumbnail')
        self.expect_thumbnail = 'another thumbnail'
        self._load_and_verify()

    def test_empty_value_produces_empty_field(self) -> None:
        self._change_key(_DICT_KEY_THUMBNAIL, '')
        self.expect_thumbnail = ''
        self._load_and_verify()

    def test_missing_key_produces_blank_field(self) -> None:
        self._remove_key(_DICT_KEY_THUMBNAIL)
        self.expect_thumbnail = ''
        self._load_and_verify()

    def test_non_string_value_fails(self) -> None:
        self._change_key(_DICT_KEY_THUMBNAIL, 77)
        self._load_and_verify_exception_not_a_string(_DICT_KEY_THUMBNAIL)

class TestTeaseUniqueImageCount(_TestTeaseBase):
    def test_specific_value_produces_expected_value(self) -> None:
        self._change_key(_DICT_KEY_UNIQUE_IMAGE_COUNT, 19451)
        self.expect_unique_image_count = 19451
        self._load_and_verify()

    def test_out_of_range_value_fails(self) -> None:
        self._change_key(_DICT_KEY_UNIQUE_IMAGE_COUNT, -1)
        self._load_and_verify_exception_number_below_minimum(_DICT_KEY_UNIQUE_IMAGE_COUNT, -1, 0)

    def test_missing_key_uses_default(self) -> None:
        self._remove_key(_DICT_KEY_UNIQUE_IMAGE_COUNT)
        self.expect_unique_image_count = 0
        self._load_and_verify()

    def test_non_integer_value_fails(self) -> None:
        self._change_key(_DICT_KEY_UNIQUE_IMAGE_COUNT, 'bonza')
        self._load_and_verify_exception_not_an_integer(_DICT_KEY_UNIQUE_IMAGE_COUNT)
