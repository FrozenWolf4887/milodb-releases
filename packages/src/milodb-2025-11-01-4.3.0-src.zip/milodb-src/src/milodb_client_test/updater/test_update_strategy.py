# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import unittest
from pathlib import Path
from typing import TYPE_CHECKING, override
from unittest.mock import Mock, PropertyMock, patch
from milodb_client.updater.i_file_hasher import HashError, HashFileNotFoundError, IFileHasher
from milodb_client.updater.i_file_tester import FileStat, IFileTester
from milodb_client.updater.manifest.common_manifest import IConfigFile, IHexDigest, ILaunchFile, IVersionNumber
from milodb_client.updater.manifest.local_manifest import ILocalManifest
from milodb_client.updater.manifest.update_directory import IAsset, IAssetRegister
from milodb_client.updater.manifest.version_manifest import ICoreFile, IVariant, IVersion, IVersionManifest
from milodb_client.updater.manifest.version_number import VersionNumber
from milodb_client.updater.update_strategy import BackupFileSet, ConfigFileChanges, CoreFileChanges, FileRename, UpdateStrategy, UpdateStrategyError, determine_config_file_changes, determine_core_file_changes, determine_files_to_backup, determine_newer_versions, determine_update_strategy, find_target_variant_and_version
from milodb_client_test.test.fake_data import FAKE_HEXDIGEST_A, FAKE_HEXDIGEST_B, FAKE_HEXDIGEST_C, FAKE_HEXDIGEST_D, FAKE_HEXDIGEST_E, FAKE_HEXDIGEST_F, FAKE_HEXDIGEST_G, FAKE_HEXDIGEST_H, FAKE_HEXDIGEST_I
from milodb_common_test.test import mock_path
from milodb_common_test.test.strict_mock import InterfaceMock
from milodb_common_test.test.test_case_ex import TestCaseEx
if TYPE_CHECKING:
    from collections.abc import Mapping, Sequence, Set as AbstractSet

class TestFindTargetVariantAndVersion(unittest.TestCase):
    @override
    def setUp(self) -> None:
        super().setUp()

        self.variant_windows = InterfaceMock(IVariant)
        self.variant_linux = InterfaceMock(IVariant)
        self.variant_vms = InterfaceMock(IVariant)
        self.variant_windows.name = PropertyMock(return_value='windows')
        self.variant_linux.name = PropertyMock(return_value='linux')
        self.variant_vms.name = PropertyMock(return_value='vms')

        self.version_number_1 = VersionNumber.parse('1.0.0')
        self.version_number_2 = VersionNumber.parse('2.0.0')
        self.version_number_3 = VersionNumber.parse('3.0.0')
        self.unknown_version_number = VersionNumber.parse('2.1.3')

        self.version_1 = InterfaceMock(IVersion)
        self.version_2 = InterfaceMock(IVersion)
        self.version_3 = InterfaceMock(IVersion)
        self.version_1.number = PropertyMock(return_value=self.version_number_1)
        self.version_2.number = PropertyMock(return_value=self.version_number_2)
        self.version_3.number = PropertyMock(return_value=self.version_number_3)

        self.variant_windows.versions = PropertyMock(return_value={})
        self.variant_linux.versions = PropertyMock(return_value={
            self.version_3.number: self.version_3,
            self.version_1.number: self.version_1,
            self.version_2.number: self.version_2,
        })
        self.variant_vms.versions = PropertyMock(return_value={})

        self.map_of_variants: Mapping[str, Mock] = {
            self.variant_windows.name: self.variant_windows,
            self.variant_linux.name: self.variant_linux,
            self.variant_vms.name: self.variant_vms,
        }

    def test_finds_latest_version_when_version_number_not_specified(self) -> None:
        requested_variant_name: str = 'linux'
        requested_version_number: IVersionNumber | None = None

        target_variant: IVariant
        target_version: IVersion
        target_variant, target_version = find_target_variant_and_version(requested_version_number, requested_variant_name, self.map_of_variants)

        self.assertIs(self.variant_linux, target_variant)
        self.assertIs(self.version_3, target_version)

    def test_finds_specified_version_when_specified(self) -> None:
        requested_variant_name: str = 'linux'
        requested_version_number: IVersionNumber | None = self.version_number_1

        target_variant: IVariant
        target_version: IVersion
        target_variant, target_version = find_target_variant_and_version(requested_version_number, requested_variant_name, self.map_of_variants)

        self.assertIs(self.variant_linux, target_variant)
        self.assertIs(self.version_1, target_version)

    def test_raises_error_when_specified_variant_does_not_exist(self) -> None:
        requested_variant_name: str = 'darwin'
        requested_version_number: IVersionNumber | None = None

        with self.assertRaises(UpdateStrategyError) as ex:
            find_target_variant_and_version(requested_version_number, requested_variant_name, self.map_of_variants)

        self.assertEqual(f"Requested variant '{requested_variant_name}' does not exist in the version manifest", str(ex.exception))

    def test_raises_error_when_specified_version_does_not_exist_within_variant(self) -> None:
        requested_variant_name: str = 'linux'
        requested_version_number: IVersionNumber | None = self.unknown_version_number

        with self.assertRaises(UpdateStrategyError) as ex:
            find_target_variant_and_version(requested_version_number, requested_variant_name, self.map_of_variants)

        self.assertEqual(f"Requested version '{requested_version_number}' in variant '{requested_variant_name}' does not exist in the version manifest", str(ex.exception))

    def test_raises_error_when_specified_variant_has_no_versions(self) -> None:
        requested_variant_name: str = 'windows'
        requested_version_number: IVersionNumber | None = None

        with self.assertRaises(UpdateStrategyError) as ex:
            find_target_variant_and_version(requested_version_number, requested_variant_name, self.map_of_variants)

        self.assertEqual(f"Requested variant '{requested_variant_name}' has no versions in the version manifest", str(ex.exception))

class TestDetermineCoreFileChanges(unittest.TestCase):
    @override
    def setUp(self) -> None:
        super().setUp()
        self.file_hasher = InterfaceMock(IFileHasher)

    def test_no_local_files_and_no_target_files_returns_no_changes(self) -> None:
        list_of_local_files: Sequence[Path] = []
        map_of_target_core_files: Mapping[Path, ICoreFile] = {}
        set_of_asset_digests: AbstractSet[IHexDigest] = set()

        core_file_changes: CoreFileChanges = determine_core_file_changes(list_of_local_files, map_of_target_core_files, set_of_asset_digests, self.file_hasher)

        self.assertFalse(core_file_changes.list_of_new_files_to_acquire)
        self.assertFalse(core_file_changes.list_of_missing_files_to_acquire)
        self.assertFalse(core_file_changes.list_of_changed_files_to_acquire)
        self.assertFalse(core_file_changes.list_of_unchanged_files)
        self.assertFalse(core_file_changes.list_of_files_that_are_deprecated)

    def test_two_local_files_and_no_target_files_returns_files_to_remove(self) -> None:
        list_of_local_files: Sequence[Path] = [Path('foo.txt'), Path('bar.dat')]
        map_of_target_core_files: Mapping[Path, ICoreFile] = {}
        set_of_asset_digests: AbstractSet[IHexDigest] = set()

        core_file_changes: CoreFileChanges = determine_core_file_changes(list_of_local_files, map_of_target_core_files, set_of_asset_digests, self.file_hasher)

        self.assertFalse(core_file_changes.list_of_new_files_to_acquire)
        self.assertFalse(core_file_changes.list_of_missing_files_to_acquire)
        self.assertFalse(core_file_changes.list_of_changed_files_to_acquire)
        self.assertFalse(core_file_changes.list_of_unchanged_files)
        self.assertSequenceEqual(list_of_local_files, core_file_changes.list_of_files_that_are_deprecated)

    def test_two_local_files_and_one_target_file_with_same_name_and_digest_returns_one_unchanged_file(self) -> None:
        list_of_local_files: Sequence[Path] = [Path('foo.txt'), Path('bar.dat')]
        core_file = InterfaceMock(ICoreFile,
            filename = PropertyMock(return_value=Path('bar.dat')),
            digest = PropertyMock(return_value=FAKE_HEXDIGEST_A),
        )
        map_of_target_core_files: Mapping[Path, ICoreFile] = {
            core_file.filename: core_file,
        }
        set_of_asset_digests: AbstractSet[IHexDigest] = { FAKE_HEXDIGEST_A }
        self.file_hasher.hash_file = Mock(return_value=FAKE_HEXDIGEST_A.digest_bytes)

        core_file_changes: CoreFileChanges = determine_core_file_changes(list_of_local_files, map_of_target_core_files, set_of_asset_digests, self.file_hasher)

        self.file_hasher.hash_file.assert_called_once_with(Path('bar.dat'))
        self.assertFalse(core_file_changes.list_of_new_files_to_acquire)
        self.assertFalse(core_file_changes.list_of_missing_files_to_acquire)
        self.assertFalse(core_file_changes.list_of_changed_files_to_acquire)
        self.assertSequenceEqual([core_file], core_file_changes.list_of_unchanged_files)
        self.assertSequenceEqual([Path('foo.txt')], core_file_changes.list_of_files_that_are_deprecated)

    def test_two_local_files_and_one_target_file_with_same_name_and_different_digest_returns_changed_file_to_acquire(self) -> None:
        list_of_local_files: Sequence[Path] = [Path('foo.txt'), Path('bar.dat')]
        core_file = InterfaceMock(ICoreFile,
            filename = PropertyMock(return_value=Path('bar.dat')),
            digest = PropertyMock(return_value=FAKE_HEXDIGEST_A),
        )
        map_of_target_core_files: Mapping[Path, ICoreFile] = {
            core_file.filename: core_file,
        }
        set_of_asset_digests: AbstractSet[IHexDigest] = { FAKE_HEXDIGEST_A }
        self.file_hasher.hash_file = Mock(return_value=FAKE_HEXDIGEST_B.digest_bytes)

        core_file_changes: CoreFileChanges = determine_core_file_changes(list_of_local_files, map_of_target_core_files, set_of_asset_digests, self.file_hasher)

        self.file_hasher.hash_file.assert_called_once_with(Path('bar.dat'))
        self.assertFalse(core_file_changes.list_of_new_files_to_acquire)
        self.assertFalse(core_file_changes.list_of_missing_files_to_acquire)
        self.assertSequenceEqual([core_file], core_file_changes.list_of_changed_files_to_acquire)
        self.assertFalse(core_file_changes.list_of_unchanged_files)
        self.assertSequenceEqual([Path('foo.txt')], core_file_changes.list_of_files_that_are_deprecated)

    def test_two_local_files_and_one_target_file_with_different_name_and_different_digest_returns_new_file_to_acquire(self) -> None:
        list_of_local_files: Sequence[Path] = [Path('foo.txt'), Path('bar.dat')]
        core_file = InterfaceMock(ICoreFile,
            filename = PropertyMock(return_value=Path('fruit.id')),
            digest = PropertyMock(return_value=FAKE_HEXDIGEST_A),
        )
        map_of_target_core_files: Mapping[Path, ICoreFile] = {
            core_file.filename: core_file,
        }
        set_of_asset_digests: AbstractSet[IHexDigest] = { FAKE_HEXDIGEST_A }

        core_file_changes: CoreFileChanges = determine_core_file_changes(list_of_local_files, map_of_target_core_files, set_of_asset_digests, self.file_hasher)

        self.assertSequenceEqual([core_file], core_file_changes.list_of_new_files_to_acquire)
        self.assertFalse(core_file_changes.list_of_missing_files_to_acquire)
        self.assertFalse(core_file_changes.list_of_changed_files_to_acquire)
        self.assertFalse(core_file_changes.list_of_unchanged_files)
        self.assertCountEqual([Path('foo.txt'), Path('bar.dat')], core_file_changes.list_of_files_that_are_deprecated)

    def test_two_local_files_where_one_is_missing_and_matching_target_files_with_same_digests_returns_missing_file_to_acquire(self) -> None:
        list_of_local_files: Sequence[Path] = [Path('foo.txt'), Path('bar.dat')]
        core_file_1 = InterfaceMock(ICoreFile,
            filename = PropertyMock(return_value=Path('foo.txt')),
            digest = PropertyMock(return_value=FAKE_HEXDIGEST_A),
        )
        core_file_2 = InterfaceMock(ICoreFile,
            filename = PropertyMock(return_value=Path('bar.dat')),
            digest = PropertyMock(return_value=FAKE_HEXDIGEST_B),
        )
        map_of_target_core_files: Mapping[Path, ICoreFile] = {
            core_file_1.filename: core_file_1,
            core_file_2.filename: core_file_2,
        }
        set_of_asset_digests: AbstractSet[IHexDigest] = { FAKE_HEXDIGEST_A, FAKE_HEXDIGEST_B }
        def on_hash_file(filename: Path) -> bytes:
            if str(filename) == 'foo.txt':
                raise HashFileNotFoundError
            if str(filename) == 'bar.dat':
                return FAKE_HEXDIGEST_B.digest_bytes
            self.fail(f"Unexpected call to hash_file('{filename}')")
            return b''
        self.file_hasher.hash_file = Mock(side_effect=on_hash_file)

        core_file_changes: CoreFileChanges = determine_core_file_changes(list_of_local_files, map_of_target_core_files, set_of_asset_digests, self.file_hasher)

        self.assertFalse(core_file_changes.list_of_new_files_to_acquire)
        self.assertSequenceEqual([core_file_1], core_file_changes.list_of_missing_files_to_acquire)
        self.assertFalse(core_file_changes.list_of_changed_files_to_acquire)
        self.assertSequenceEqual([core_file_2], core_file_changes.list_of_unchanged_files)
        self.assertFalse(core_file_changes.list_of_files_that_are_deprecated)

    def test_error_raised_when_a_hash_file_error_occurs(self) -> None:
        list_of_local_files: Sequence[Path] = [Path('foo.txt'), Path('bar.dat')]
        core_file = InterfaceMock(ICoreFile)
        core_file.filename = PropertyMock(return_value=Path('bar.dat'))
        core_file.digest = PropertyMock(return_value=FAKE_HEXDIGEST_B)
        map_of_target_core_files: Mapping[Path, ICoreFile] = {
            core_file.filename: core_file,
        }
        set_of_asset_digests: AbstractSet[IHexDigest] = { FAKE_HEXDIGEST_B }
        self.file_hasher.hash_file = Mock(side_effect=HashError('test message'))

        with self.assertRaises(UpdateStrategyError) as ex:
            determine_core_file_changes(list_of_local_files, map_of_target_core_files, set_of_asset_digests, self.file_hasher)

        self.assertEqual('test message', str(ex.exception))

    def test_error_raised_when_a_digest_is_not_in_the_asset_register(self) -> None:
        list_of_local_files: Sequence[Path] = [Path('foo.txt'), Path('bar.dat')]
        core_file = InterfaceMock(ICoreFile)
        core_file.filename = PropertyMock(return_value=Path('bar.dat'))
        core_file.digest = PropertyMock(return_value=FAKE_HEXDIGEST_B)
        map_of_target_core_files: Mapping[Path, ICoreFile] = {
            core_file.filename: core_file,
        }
        set_of_asset_digests: AbstractSet[IHexDigest] = { FAKE_HEXDIGEST_A }
        self.file_hasher.hash_file = Mock(side_effect=HashError('test message'))

        with self.assertRaises(UpdateStrategyError) as ex:
            determine_core_file_changes(list_of_local_files, map_of_target_core_files, set_of_asset_digests, self.file_hasher)

        self.assertEqual(f"Core file 'bar.dat' with digest '{FAKE_HEXDIGEST_B}' does not appear in the asset register", str(ex.exception))

class TestDetermineConfigFileChanges(unittest.TestCase):
    def test_no_local_files_and_no_target_files(self) -> None:
        """Test with a set of local, target, and expected files.

        ### Local
        * (none)
        ### Target
        * (none)
        ### Expected
        * (no changes)
        """
        map_of_local_config_files: Mapping[int, IConfigFile] = {}
        map_of_target_config_files: Mapping[int, IConfigFile] = {}

        config_file_changes: ConfigFileChanges = determine_config_file_changes(map_of_local_config_files, map_of_target_config_files)

        self.assertFalse(config_file_changes.list_of_files_that_are_deprecated)
        self.assertFalse(config_file_changes.list_of_files_to_rename)
        self.assertFalse(config_file_changes.list_of_files_to_leave)
        self.assertFalse(config_file_changes.list_of_new_files)

    def test_two_local_files_and_no_target_files(self) -> None:
        """Test with a set of local, target, and expected files.

        ### Local
        * 23: test.dat
        * 8: another.txt
        ### Target
        * (none)
        ### Expected
        * files_to_remove = test.dat, another.txt
        """
        local_file_1 = InterfaceMock(IConfigFile)
        local_file_1.config_key = PropertyMock(return_value=23)
        local_file_1.filename = PropertyMock(return_value=Path('test.dat'))
        local_file_2 = InterfaceMock(IConfigFile)
        local_file_2.config_key = PropertyMock(return_value=8)
        local_file_2.filename = PropertyMock(return_value=Path('another.txt'))
        map_of_local_config_files: Mapping[int, IConfigFile] = {
            local_file_1.config_key: local_file_1,
            local_file_2.config_key: local_file_2,
        }
        map_of_target_config_files: Mapping[int, IConfigFile] = {}

        config_file_changes: ConfigFileChanges = determine_config_file_changes(map_of_local_config_files, map_of_target_config_files)

        self.assertCountEqual([Path('test.dat'), Path('another.txt')], config_file_changes.list_of_files_that_are_deprecated)
        self.assertFalse(config_file_changes.list_of_files_to_rename)
        self.assertFalse(config_file_changes.list_of_files_to_leave)
        self.assertFalse(config_file_changes.list_of_new_files)

    def test_no_local_files_and_two_target_files(self) -> None:
        """Test with a set of local, target, and expected files.

        ### Local
        * (none)
        ### Target
        * 23: test.dat
        * 8: another.txt
        ### Expected
        * new_files = test.dat, another.txt
        """
        map_of_local_config_files: Mapping[int, IConfigFile] = {}
        target_file_1 = InterfaceMock(IConfigFile)
        target_file_1.config_key = PropertyMock(return_value=23)
        target_file_1.filename = PropertyMock(return_value=Path('test.dat'))
        target_file_2 = InterfaceMock(IConfigFile)
        target_file_2.config_key = PropertyMock(return_value=8)
        target_file_2.filename = PropertyMock(return_value=Path('another.txt'))
        map_of_target_config_files: Mapping[int, IConfigFile] = {
            target_file_1.config_key: target_file_1,
            target_file_2.config_key: target_file_2,
        }

        config_file_changes: ConfigFileChanges = determine_config_file_changes(map_of_local_config_files, map_of_target_config_files)

        self.assertFalse(config_file_changes.list_of_files_that_are_deprecated)
        self.assertFalse(config_file_changes.list_of_files_to_rename)
        self.assertFalse(config_file_changes.list_of_files_to_leave)
        self.assertCountEqual([Path('test.dat'), Path('another.txt')], config_file_changes.list_of_new_files)

    def test_two_local_files_and_two_target_files_with_same_names_and_keys(self) -> None:
        """Test with a set of local, target, and expected files.

        ### Local
        * 23: test.dat
        * 8: another.txt
        ### Target
        * 23: test.dat
        * 8: another.txt
        ### Expected
        * files_to_leave = test.dat, another.txt
        """
        local_file_1 = InterfaceMock(IConfigFile)
        local_file_1.config_key = PropertyMock(return_value=23)
        local_file_1.filename = PropertyMock(return_value=Path('test.dat'))
        local_file_2 = InterfaceMock(IConfigFile)
        local_file_2.config_key = PropertyMock(return_value=8)
        local_file_2.filename = PropertyMock(return_value=Path('another.txt'))
        map_of_local_config_files: Mapping[int, IConfigFile] = {
            local_file_1.config_key: local_file_1,
            local_file_2.config_key: local_file_2,
        }
        target_file_1 = InterfaceMock(IConfigFile)
        target_file_1.config_key = PropertyMock(return_value=23)
        target_file_1.filename = PropertyMock(return_value=Path('test.dat'))
        target_file_2 = InterfaceMock(IConfigFile)
        target_file_2.config_key = PropertyMock(return_value=8)
        target_file_2.filename = PropertyMock(return_value=Path('another.txt'))
        map_of_target_config_files: Mapping[int, IConfigFile] = {
            target_file_1.config_key: target_file_1,
            target_file_2.config_key: target_file_2,
        }

        config_file_changes: ConfigFileChanges = determine_config_file_changes(map_of_local_config_files, map_of_target_config_files)

        self.assertFalse(config_file_changes.list_of_files_that_are_deprecated)
        self.assertFalse(config_file_changes.list_of_files_to_rename)
        self.assertCountEqual([Path('test.dat'), Path('another.txt')], config_file_changes.list_of_files_to_leave)
        self.assertFalse(config_file_changes.list_of_new_files)

    def test_two_local_files_and_two_target_files_where_one_target_file_has_same_name_but_different_key(self) -> None:
        """Test with a set of local, target, and expected files.

        ### Local
        * 23: test.dat
        * 8: another.txt
        ### Target
        * 23: test.dat
        * 31: another.txt
        ### Expected
        * files_to_leave  = test.dat
        * files_to_remove = another.txt
        * new_files       = another.txt
        """
        local_file_1 = InterfaceMock(IConfigFile)
        local_file_1.config_key = PropertyMock(return_value=23)
        local_file_1.filename = PropertyMock(return_value=Path('test.dat'))
        local_file_2 = InterfaceMock(IConfigFile)
        local_file_2.config_key = PropertyMock(return_value=8)
        local_file_2.filename = PropertyMock(return_value=Path('another.txt'))
        map_of_local_config_files: Mapping[int, IConfigFile] = {
            local_file_1.config_key: local_file_1,
            local_file_2.config_key: local_file_2,
        }
        target_file_1 = InterfaceMock(IConfigFile)
        target_file_1.config_key = PropertyMock(return_value=23)
        target_file_1.filename = PropertyMock(return_value=Path('test.dat'))
        target_file_2 = InterfaceMock(IConfigFile)
        target_file_2.config_key = PropertyMock(return_value=31)
        target_file_2.filename = PropertyMock(return_value=Path('another.txt'))
        map_of_target_config_files: Mapping[int, IConfigFile] = {
            target_file_1.config_key: target_file_1,
            target_file_2.config_key: target_file_2,
        }

        config_file_changes: ConfigFileChanges = determine_config_file_changes(map_of_local_config_files, map_of_target_config_files)

        self.assertCountEqual([Path('another.txt')], config_file_changes.list_of_files_that_are_deprecated)
        self.assertFalse(config_file_changes.list_of_files_to_rename)
        self.assertCountEqual([Path('test.dat')], config_file_changes.list_of_files_to_leave)
        self.assertCountEqual([Path('another.txt')], config_file_changes.list_of_new_files)

    def test_two_local_files_and_two_target_files_where_one_target_file_has_same_key_but_different_name(self) -> None:
        """Test with a set of local, target, and expected files.

        ### Local
        * 23: test.dat
        * 8: another.txt
        ### Target
        * 23: test.dat
        * 8: something.log
        ### Expected
        * files_to_leave  = test.dat
        * files_to_rename = another.txt -> something.log
        """
        local_file_1 = InterfaceMock(IConfigFile)
        local_file_1.config_key = PropertyMock(return_value=23)
        local_file_1.filename = PropertyMock(return_value=Path('test.dat'))
        local_file_2 = InterfaceMock(IConfigFile)
        local_file_2.config_key = PropertyMock(return_value=8)
        local_file_2.filename = PropertyMock(return_value=Path('another.txt'))
        map_of_local_config_files: Mapping[int, IConfigFile] = {
            local_file_1.config_key: local_file_1,
            local_file_2.config_key: local_file_2,
        }
        target_file_1 = InterfaceMock(IConfigFile)
        target_file_1.config_key = PropertyMock(return_value=23)
        target_file_1.filename = PropertyMock(return_value=Path('test.dat'))
        target_file_2 = InterfaceMock(IConfigFile)
        target_file_2.config_key = PropertyMock(return_value=8)
        target_file_2.filename = PropertyMock(return_value=Path('something.log'))
        map_of_target_config_files: Mapping[int, IConfigFile] = {
            target_file_1.config_key: target_file_1,
            target_file_2.config_key: target_file_2,
        }

        config_file_changes: ConfigFileChanges = determine_config_file_changes(map_of_local_config_files, map_of_target_config_files)

        self.assertFalse(config_file_changes.list_of_files_that_are_deprecated)
        self.assertEqual(1, len(config_file_changes.list_of_files_to_rename))
        self.assertEqual(Path('another.txt'), config_file_changes.list_of_files_to_rename[0].original_filename)
        self.assertEqual(Path('something.log'), config_file_changes.list_of_files_to_rename[0].new_filename)
        self.assertCountEqual([Path('test.dat')], config_file_changes.list_of_files_to_leave)
        self.assertFalse(config_file_changes.list_of_new_files)

class TestDetermineNewerVersions(unittest.TestCase):
    @override
    def setUp(self) -> None:
        super().setUp()

        self.variant_windows = InterfaceMock(IVariant)
        self.variant_linux = InterfaceMock(IVariant)
        self.variant_vms = InterfaceMock(IVariant)
        self.variant_windows.name = PropertyMock(return_value='windows')
        self.variant_linux.name = PropertyMock(return_value='linux')
        self.variant_vms.name = PropertyMock(return_value='vms')

        self.version_number_0 = VersionNumber.parse('1.2.3')
        self.version_number_1 = VersionNumber.parse('2.0.1')
        self.version_number_2 = VersionNumber.parse('3.7.9')
        self.version_number_3 = VersionNumber.parse('4.1.2')
        self.version_number_4 = VersionNumber.parse('5.6.8')

        self.version_1 = InterfaceMock(IVersion)
        self.version_2 = InterfaceMock(IVersion)
        self.version_3 = InterfaceMock(IVersion)
        self.version_1.number = PropertyMock(return_value=self.version_number_1)
        self.version_2.number = PropertyMock(return_value=self.version_number_2)
        self.version_3.number = PropertyMock(return_value=self.version_number_3)

        self.variant_windows.versions = PropertyMock(return_value={})
        self.variant_linux.versions = PropertyMock(return_value={
            self.version_3.number: self.version_3,
            self.version_1.number: self.version_1,
            self.version_2.number: self.version_2,
        })
        self.variant_vms.versions = PropertyMock(return_value={})

    def test_when_starting_variant_does_not_match_target_variant_returns_no_versions(self) -> None:
        list_of_versions: Sequence[IVersion] = determine_newer_versions('linux', InterfaceMock(IVersionNumber), self.variant_windows, InterfaceMock(IVersionNumber))
        self.assertFalse(list_of_versions)

    def test_when_matching_variant_has_no_versions_returns_no_versions(self) -> None:
        list_of_versions: Sequence[IVersion] = determine_newer_versions('vms', InterfaceMock(IVersionNumber), self.variant_vms, InterfaceMock(IVersionNumber))
        self.assertFalse(list_of_versions)

    def test_starting_version_is_first_and_target_version_is_last_returns_all_later_versions(self) -> None:
        list_of_versions: Sequence[IVersion] = determine_newer_versions('linux', self.version_number_1, self.variant_linux, self.version_number_3)
        self.assertSequenceEqual([self.version_2, self.version_3], list_of_versions)

    def test_starting_version_is_second_and_target_version_is_last_returns_all_later_versions(self) -> None:
        list_of_versions: Sequence[IVersion] = determine_newer_versions('linux', self.version_number_2, self.variant_linux, self.version_number_3)
        self.assertSequenceEqual([self.version_3], list_of_versions)

    def test_starting_version_is_last_and_same_as_target_version_returns_no_versions(self) -> None:
        list_of_versions: Sequence[IVersion] = determine_newer_versions('linux', self.version_number_3, self.variant_linux, self.version_number_3)
        self.assertSequenceEqual([], list_of_versions)

    def test_starting_version_is_first_and_target_version_is_second_returns_target_version(self) -> None:
        list_of_versions: Sequence[IVersion] = determine_newer_versions('linux', self.version_number_1, self.variant_linux, self.version_number_2)
        self.assertSequenceEqual([self.version_2], list_of_versions)

    def test_starting_version_is_first_and_same_as_target_version_returns_no_versions(self) -> None:
        list_of_versions: Sequence[IVersion] = determine_newer_versions('linux', self.version_number_1, self.variant_linux, self.version_number_1)
        self.assertSequenceEqual([], list_of_versions)

    def test_starting_version_is_not_list_and_lowest_and_target_version_is_last_returns_all_versions(self) -> None:
        list_of_versions: Sequence[IVersion] = determine_newer_versions('linux', self.version_number_0, self.variant_linux, self.version_number_3)
        self.assertSequenceEqual([self.version_1, self.version_2, self.version_3], list_of_versions)

    def test_starting_version_is_first_and_target_version_is_not_in_list_and_highest_returns_all_later_versions(self) -> None:
        list_of_versions: Sequence[IVersion] = determine_newer_versions('linux', self.version_number_1, self.variant_linux, self.version_number_4)
        self.assertSequenceEqual([self.version_2, self.version_3], list_of_versions)

class TestDetermineFilesToBackup(unittest.TestCase):
    @override
    def setUp(self) -> None:
        super().setUp()
        self.core_file_1 = InterfaceMock(ICoreFile)
        self.core_file_1.filename = PropertyMock(return_value=Path('file1'))
        self.core_file_2 = InterfaceMock(ICoreFile)
        self.core_file_2.filename = PropertyMock(return_value=Path('file2'))

        self.config_filename_1 = Path('config_file1')
        self.config_filename_2 = Path('config_file2')
        self.config_new_filename_1 = Path('config_new_file1')
        self.config_new_filename_2 = Path('config_new_file2')

    def test_no_core_files_or_config_fields_yields_empty_list(self) -> None:
        core_file_changes: CoreFileChanges = CoreFileChanges(
            list_of_new_files_to_acquire = [],
            list_of_missing_files_to_acquire = [],
            list_of_changed_files_to_acquire = [],
            list_of_unchanged_files = [],
            list_of_files_that_are_deprecated = [],
        )
        config_file_changes: ConfigFileChanges = ConfigFileChanges(
            list_of_files_that_are_deprecated = [],
            list_of_files_to_rename = [],
            list_of_files_to_leave = [],
            list_of_new_files = [],
        )

        backup_file_set: BackupFileSet = determine_files_to_backup(core_file_changes, config_file_changes, InterfaceMock(IFileTester))

        self.assertFalse(backup_file_set.list_of_core_files_to_backup)
        self.assertFalse(backup_file_set.list_of_config_files_to_backup)
        self.assertFalse(backup_file_set.list_of_clobbered_files_to_backup)

    def test_new_core_files_yields_empty_list(self) -> None:
        core_file_changes: CoreFileChanges = CoreFileChanges(
            list_of_new_files_to_acquire = [self.core_file_1, self.core_file_2],
            list_of_missing_files_to_acquire = [],
            list_of_changed_files_to_acquire = [],
            list_of_unchanged_files = [],
            list_of_files_that_are_deprecated = [],
        )
        config_file_changes: ConfigFileChanges = ConfigFileChanges(
            list_of_files_that_are_deprecated = [],
            list_of_files_to_rename = [],
            list_of_files_to_leave = [],
            list_of_new_files = [],
        )
        file_tester = InterfaceMock(IFileTester)
        file_tester.stat_file = Mock(side_effect=lambda filename: {
            self.core_file_1.filename: FileStat(self.core_file_1.filename, does_exist=False, is_file=False),
            self.core_file_2.filename: FileStat(self.core_file_1.filename, does_exist=False, is_file=False),
        }[filename])

        backup_file_set: BackupFileSet = determine_files_to_backup(core_file_changes, config_file_changes, file_tester)

        self.assertFalse(backup_file_set.list_of_core_files_to_backup)
        self.assertFalse(backup_file_set.list_of_config_files_to_backup)
        self.assertFalse(backup_file_set.list_of_clobbered_files_to_backup)

    def test_new_core_files_with_destination_file_clash_yields_clobbered_file_list(self) -> None:
        core_file_changes: CoreFileChanges = CoreFileChanges(
            list_of_new_files_to_acquire = [self.core_file_1, self.core_file_2],
            list_of_missing_files_to_acquire = [],
            list_of_changed_files_to_acquire = [],
            list_of_unchanged_files = [],
            list_of_files_that_are_deprecated = [],
        )
        config_file_changes: ConfigFileChanges = ConfigFileChanges(
            list_of_files_that_are_deprecated = [],
            list_of_files_to_rename = [],
            list_of_files_to_leave = [],
            list_of_new_files = [],
        )
        file_tester = InterfaceMock(IFileTester)
        file_tester.stat_file = Mock(side_effect=lambda filename: {
            self.core_file_1.filename: FileStat(self.core_file_1.filename, does_exist=False, is_file=False),
            self.core_file_2.filename: FileStat(self.core_file_2.filename, does_exist=True, is_file=True),
        }[filename])

        backup_file_set: BackupFileSet = determine_files_to_backup(core_file_changes, config_file_changes, file_tester)

        self.assertFalse(backup_file_set.list_of_core_files_to_backup)
        self.assertFalse(backup_file_set.list_of_config_files_to_backup)
        self.assertCountEqual([self.core_file_2.filename], backup_file_set.list_of_clobbered_files_to_backup)

    def test_new_core_files_with_desitnation_directory_clash_raises_error(self) -> None:
        core_file_changes: CoreFileChanges = CoreFileChanges(
            list_of_new_files_to_acquire = [self.core_file_1, self.core_file_2],
            list_of_missing_files_to_acquire = [],
            list_of_changed_files_to_acquire = [],
            list_of_unchanged_files = [],
            list_of_files_that_are_deprecated = [],
        )
        config_file_changes: ConfigFileChanges = ConfigFileChanges(
            list_of_files_that_are_deprecated = [],
            list_of_files_to_rename = [],
            list_of_files_to_leave = [],
            list_of_new_files = [],
        )
        file_tester = InterfaceMock(IFileTester)
        file_tester.stat_file = Mock(side_effect=lambda filename: {
            self.core_file_1.filename: FileStat(self.core_file_1.filename, does_exist=False, is_file=False),
            self.core_file_2.filename: FileStat(self.core_file_1.filename, does_exist=True, is_file=False),
        }[filename])

        with self.assertRaises(UpdateStrategyError) as ex:
            determine_files_to_backup(core_file_changes, config_file_changes, file_tester)

        self.assertEqual(f"Destination file '{self.core_file_2.filename}' already exists and is a directory", str(ex.exception))

    def test_missing_core_files_yields_empty_list(self) -> None:
        core_file_changes: CoreFileChanges = CoreFileChanges(
            list_of_new_files_to_acquire = [],
            list_of_missing_files_to_acquire = [self.core_file_1, self.core_file_2],
            list_of_changed_files_to_acquire = [],
            list_of_unchanged_files = [],
            list_of_files_that_are_deprecated = [],
        )
        config_file_changes: ConfigFileChanges = ConfigFileChanges(
            list_of_files_that_are_deprecated = [],
            list_of_files_to_rename = [],
            list_of_files_to_leave = [],
            list_of_new_files = [],
        )

        backup_file_set: BackupFileSet = determine_files_to_backup(core_file_changes, config_file_changes, InterfaceMock(IFileTester))

        self.assertFalse(backup_file_set.list_of_core_files_to_backup)
        self.assertFalse(backup_file_set.list_of_config_files_to_backup)
        self.assertFalse(backup_file_set.list_of_clobbered_files_to_backup)

    def test_changed_core_files_yields_list_of_files(self) -> None:
        core_file_changes: CoreFileChanges = CoreFileChanges(
            list_of_new_files_to_acquire = [],
            list_of_missing_files_to_acquire = [],
            list_of_changed_files_to_acquire = [self.core_file_1, self.core_file_2],
            list_of_unchanged_files = [],
            list_of_files_that_are_deprecated = [],
        )
        config_file_changes: ConfigFileChanges = ConfigFileChanges(
            list_of_files_that_are_deprecated = [],
            list_of_files_to_rename = [],
            list_of_files_to_leave = [],
            list_of_new_files = [],
        )

        backup_file_set: BackupFileSet = determine_files_to_backup(core_file_changes, config_file_changes, InterfaceMock(IFileTester))

        self.assertCountEqual([self.core_file_1.filename, self.core_file_2.filename], backup_file_set.list_of_core_files_to_backup)
        self.assertFalse(backup_file_set.list_of_config_files_to_backup)
        self.assertFalse(backup_file_set.list_of_clobbered_files_to_backup)

    def test_unchanged_core_files_yields_list_of_files(self) -> None:
        core_file_changes: CoreFileChanges = CoreFileChanges(
            list_of_new_files_to_acquire = [],
            list_of_missing_files_to_acquire = [],
            list_of_changed_files_to_acquire = [],
            list_of_unchanged_files = [self.core_file_1, self.core_file_2],
            list_of_files_that_are_deprecated = [],
        )
        config_file_changes: ConfigFileChanges = ConfigFileChanges(
            list_of_files_that_are_deprecated = [],
            list_of_files_to_rename = [],
            list_of_files_to_leave = [],
            list_of_new_files = [],
        )

        backup_file_set: BackupFileSet = determine_files_to_backup(core_file_changes, config_file_changes, InterfaceMock(IFileTester))

        self.assertCountEqual([self.core_file_1.filename, self.core_file_2.filename], backup_file_set.list_of_core_files_to_backup)
        self.assertFalse(backup_file_set.list_of_config_files_to_backup)
        self.assertFalse(backup_file_set.list_of_clobbered_files_to_backup)

    def test_removed_core_files_yields_list_of_files(self) -> None:
        core_file_changes: CoreFileChanges = CoreFileChanges(
            list_of_new_files_to_acquire = [],
            list_of_missing_files_to_acquire = [],
            list_of_changed_files_to_acquire = [],
            list_of_unchanged_files = [],
            list_of_files_that_are_deprecated = [self.core_file_1.filename, self.core_file_2.filename],
        )
        config_file_changes: ConfigFileChanges = ConfigFileChanges(
            list_of_files_that_are_deprecated = [],
            list_of_files_to_rename = [],
            list_of_files_to_leave = [],
            list_of_new_files = [],
        )

        backup_file_set: BackupFileSet = determine_files_to_backup(core_file_changes, config_file_changes, InterfaceMock(IFileTester))

        self.assertCountEqual([self.core_file_1.filename, self.core_file_2.filename], backup_file_set.list_of_core_files_to_backup)
        self.assertFalse(backup_file_set.list_of_config_files_to_backup)
        self.assertFalse(backup_file_set.list_of_clobbered_files_to_backup)

    def test_new_config_files_yields_empty_list(self) -> None:
        core_file_changes: CoreFileChanges = CoreFileChanges(
            list_of_new_files_to_acquire = [],
            list_of_missing_files_to_acquire = [],
            list_of_changed_files_to_acquire = [],
            list_of_unchanged_files = [],
            list_of_files_that_are_deprecated = [],
        )
        config_file_changes: ConfigFileChanges = ConfigFileChanges(
            list_of_files_that_are_deprecated = [],
            list_of_files_to_rename = [],
            list_of_files_to_leave = [],
            list_of_new_files = [self.config_filename_1, self.config_filename_2],
        )

        backup_file_set: BackupFileSet = determine_files_to_backup(core_file_changes, config_file_changes, InterfaceMock(IFileTester))

        self.assertFalse(backup_file_set.list_of_core_files_to_backup)
        self.assertFalse(backup_file_set.list_of_config_files_to_backup)
        self.assertFalse(backup_file_set.list_of_clobbered_files_to_backup)

    def test_leave_config_files_yields_list_of_files(self) -> None:
        core_file_changes: CoreFileChanges = CoreFileChanges(
            list_of_new_files_to_acquire = [],
            list_of_missing_files_to_acquire = [],
            list_of_changed_files_to_acquire = [],
            list_of_unchanged_files = [],
            list_of_files_that_are_deprecated = [],
        )
        config_file_changes: ConfigFileChanges = ConfigFileChanges(
            list_of_files_that_are_deprecated = [],
            list_of_files_to_rename = [],
            list_of_files_to_leave = [self.config_filename_1, self.config_filename_2],
            list_of_new_files = [],
        )

        backup_file_set: BackupFileSet = determine_files_to_backup(core_file_changes, config_file_changes, InterfaceMock(IFileTester))

        self.assertFalse(backup_file_set.list_of_core_files_to_backup)
        self.assertCountEqual([self.config_filename_1, self.config_filename_2], backup_file_set.list_of_config_files_to_backup)
        self.assertFalse(backup_file_set.list_of_clobbered_files_to_backup)

    def test_rename_config_files_yields_list_of_files(self) -> None:
        core_file_changes: CoreFileChanges = CoreFileChanges(
            list_of_new_files_to_acquire = [],
            list_of_missing_files_to_acquire = [],
            list_of_changed_files_to_acquire = [],
            list_of_unchanged_files = [],
            list_of_files_that_are_deprecated = [],
        )
        config_file_changes: ConfigFileChanges = ConfigFileChanges(
            list_of_files_that_are_deprecated = [],
            list_of_files_to_rename = [FileRename(self.config_filename_1, self.config_new_filename_1), FileRename(self.config_filename_2, self.config_new_filename_2)],
            list_of_files_to_leave = [],
            list_of_new_files = [],
        )

        backup_file_set: BackupFileSet = determine_files_to_backup(core_file_changes, config_file_changes, InterfaceMock(IFileTester))

        self.assertFalse(backup_file_set.list_of_core_files_to_backup)
        self.assertCountEqual([self.config_filename_1, self.config_filename_2], backup_file_set.list_of_config_files_to_backup)
        self.assertFalse(backup_file_set.list_of_clobbered_files_to_backup)

    def test_remove_config_files_yields_list_of_files(self) -> None:
        core_file_changes: CoreFileChanges = CoreFileChanges(
            list_of_new_files_to_acquire = [],
            list_of_missing_files_to_acquire = [],
            list_of_changed_files_to_acquire = [],
            list_of_unchanged_files = [],
            list_of_files_that_are_deprecated = [],
        )
        config_file_changes: ConfigFileChanges = ConfigFileChanges(
            list_of_files_that_are_deprecated = [self.config_filename_1, self.config_filename_2],
            list_of_files_to_rename = [],
            list_of_files_to_leave = [],
            list_of_new_files = [],
        )

        backup_file_set: BackupFileSet = determine_files_to_backup(core_file_changes, config_file_changes, InterfaceMock(IFileTester))

        self.assertFalse(backup_file_set.list_of_core_files_to_backup)
        self.assertCountEqual([self.config_filename_1, self.config_filename_2], backup_file_set.list_of_config_files_to_backup)
        self.assertFalse(backup_file_set.list_of_clobbered_files_to_backup)

class TestDetermineUpdateStrategy(TestCaseEx):
    """The following configuration is used to test the integrated update strategy.

    Local Manifest

        Version: windows / 1.0.0

    Target

    Core files

        Local Manifest  |  Current Files / Digest  |  Target Files / Digest  |  State      / Action
        ----------------|--------------------------|-------------------------|------------------------------
        apple.txt       |  apple.txt     / A       |  apple.txt    / A       |  Unchanged  / Backup
        banana.dat      |  banana.dat    / B       |  banana.dat   / F       |  Changed    / Backup, Acquire
        pear.log        |  pear.log      / C       |                         |  Deprecated / Backup, Delete
                        |                          |  cheese.net   / G       |  New        / Acquire
        mainApp         |                          |  mainApp      / D       |  Missing    / Acquire
        mainApp.exe     |  mainApp.exe   / E       |  mainApp.exe  / H       |  Changed    / Backup, Acquire
                        |  database.id   / I       |  database.id  / J       |  Clobbered  / Backup, Acquire

    Config files

        Local Manifest / Key  |  Current Files  |  Target Files / Key  |  State      / Action
        ----------------------|-----------------|----------------------|-----------------------------
        config.json    / 3    |  config.json    |  config.json  / 3    |  Unchanged  / Backup
        history.txt    / 5    |  history.txt    |  history.log  / 5    |  Renamed    / Backup, Rename
        auto.txt       / 4    |  auto.txt       |                      |  Deprecated / Backup, Delete
                              |                 |  logging.txt  / 6    |  New        / -
        variables.txt  / 7    |                 |  vars.txt     / 7    |  Renamed    / -

    Launch files

        Operating System  |  Target File
        ------------------|-------------
        win32             |  mainApp.exe
        linux             |  mainApp
    """

    @override
    def setUp(self) -> None: # pylint: disable=too-many-statements
        super().setUp()

        self.local_version_number = VersionNumber.parse('1.0.0')
        self.target_version_number = VersionNumber.parse('2.0.0')

        self.local_manifest = InterfaceMock(ILocalManifest,
            variant_name = PropertyMock(return_value='windows'),
            version_number = PropertyMock(return_value=self.local_version_number),
            core_files = PropertyMock(return_value=[
                Path('apple.txt'),
                Path('banana.dat'),
                Path('pear.log'),
                Path('mainApp'),
                Path('mainApp.exe'),
            ]),
            config_files = PropertyMock(return_value={
                3: InterfaceMock(IConfigFile,
                    config_key = PropertyMock(return_value=3),
                    filename = PropertyMock(return_value=Path('config.json')),
                ),
                5: InterfaceMock(IConfigFile,
                    config_key = PropertyMock(return_value=5),
                    filename = PropertyMock(return_value=Path('history.txt')),
                ),
                4: InterfaceMock(IConfigFile,
                    config_key = PropertyMock(return_value=4),
                    filename = PropertyMock(return_value=Path('auto.txt')),
                ),
                7: InterfaceMock(IConfigFile,
                    config_key = PropertyMock(return_value=7),
                    filename = PropertyMock(return_value=Path('variables.txt')),
                ),
            }),
        )

        self.version_1 = InterfaceMock(IVersion,
            number = PropertyMock(return_value=self.local_version_number),
        )

        self.target_core_file_1 = InterfaceMock(ICoreFile,
            filename = PropertyMock(return_value=Path('apple.txt')),
            digest = PropertyMock(return_value=FAKE_HEXDIGEST_A),
        )
        self.target_core_file_2 = InterfaceMock(ICoreFile,
            filename = PropertyMock(return_value=Path('banana.dat')),
            digest = PropertyMock(return_value=FAKE_HEXDIGEST_F),
        )
        self.target_core_file_3 = InterfaceMock(ICoreFile,
            filename = PropertyMock(return_value=Path('cheese.net')),
            digest = PropertyMock(return_value=FAKE_HEXDIGEST_G),
        )
        self.target_core_file_4 = InterfaceMock(ICoreFile,
            filename = PropertyMock(return_value=Path('mainApp')),
            digest = PropertyMock(return_value=FAKE_HEXDIGEST_D),
        )
        self.target_core_file_5 = InterfaceMock(ICoreFile,
            filename = PropertyMock(return_value=Path('mainApp.exe')),
            digest = PropertyMock(return_value=FAKE_HEXDIGEST_H),
        )
        self.target_core_file_6 = InterfaceMock(ICoreFile,
            filename = PropertyMock(return_value=Path('database.id')),
            digest = PropertyMock(return_value=FAKE_HEXDIGEST_I),
        )

        self.target_config_file_1 = InterfaceMock(IConfigFile,
            config_key = PropertyMock(return_value=3),
            filename = PropertyMock(return_value=Path('config.json')),
        )
        self.target_config_file_2 = InterfaceMock(IConfigFile,
            config_key = PropertyMock(return_value=5),
            filename = PropertyMock(return_value=Path('history.log')),
        )
        self.target_config_file_3 = InterfaceMock(IConfigFile,
            config_key = PropertyMock(return_value=6),
            filename = PropertyMock(return_value=Path('logging.txt')),
        )
        self.target_config_file_4 = InterfaceMock(IConfigFile,
            config_key = PropertyMock(return_value=7),
            filename = PropertyMock(return_value=Path('vars.txt')),
        )

        self.launch_file_1 = InterfaceMock(ILaunchFile,
            operating_system = PropertyMock(return_value='win32'),
            filename = PropertyMock(return_value=Path('mainApp.exe')),
        )
        self.launch_file_2 = InterfaceMock(ILaunchFile,
            operating_system = PropertyMock(return_value='linux'),
            filename = PropertyMock(return_value=Path('mainApp')),
        )

        self.version_2 = InterfaceMock(IVersion,
            number = PropertyMock(return_value=self.target_version_number),
            core_files = PropertyMock(return_value={
                self.target_core_file_1.filename: self.target_core_file_1,
                self.target_core_file_2.filename: self.target_core_file_2,
                self.target_core_file_3.filename: self.target_core_file_3,
                self.target_core_file_4.filename: self.target_core_file_4,
                self.target_core_file_5.filename: self.target_core_file_5,
                self.target_core_file_6.filename: self.target_core_file_6,
            }),
            config_files = PropertyMock(return_value={
                self.target_config_file_1.config_key: self.target_config_file_1,
                self.target_config_file_2.config_key: self.target_config_file_2,
                self.target_config_file_3.config_key: self.target_config_file_3,
                self.target_config_file_4.config_key: self.target_config_file_4,
            }),
            launch_files = PropertyMock(return_value={
                self.launch_file_1.operating_system: self.launch_file_1,
                self.launch_file_2.operating_system: self.launch_file_2,
            }),
        )

        self.variant_main = InterfaceMock(IVariant,
            name = PropertyMock(return_value='main'),
            versions = PropertyMock(return_value={
                self.version_1.number: self.version_1,
                self.version_2.number: self.version_2,
            }),
        )

        self.version_manifest = InterfaceMock(IVersionManifest,
            variants = PropertyMock(return_value={
                self.variant_main.name: self.variant_main,
            }),
        )

        asset_file_a = InterfaceMock(IAsset,
            digest = PropertyMock(return_value=FAKE_HEXDIGEST_A),
        )
        asset_file_d = InterfaceMock(IAsset,
            digest = PropertyMock(return_value=FAKE_HEXDIGEST_D),
        )
        asset_file_f = InterfaceMock(IAsset,
            digest = PropertyMock(return_value=FAKE_HEXDIGEST_F),
        )
        asset_file_g = InterfaceMock(IAsset,
            digest = PropertyMock(return_value=FAKE_HEXDIGEST_G),
        )
        asset_file_h = InterfaceMock(IAsset,
            digest = PropertyMock(return_value=FAKE_HEXDIGEST_H),
        )
        asset_file_i = InterfaceMock(IAsset,
            digest = PropertyMock(return_value=FAKE_HEXDIGEST_I),
        )
        self.asset_register = InterfaceMock(IAssetRegister,
            assets = PropertyMock(return_value={
                asset_file_a.digest: asset_file_a,
                asset_file_d.digest: asset_file_d,
                asset_file_f.digest: asset_file_f,
                asset_file_g.digest: asset_file_g,
                asset_file_h.digest: asset_file_h,
                asset_file_i.digest: asset_file_i,
            }),
        )

        def mock_hash_file(filename: Path) -> bytes:
            digest: bytes | None = {
                Path('apple.txt'): FAKE_HEXDIGEST_A.digest_bytes,
                Path('banana.dat'): FAKE_HEXDIGEST_B.digest_bytes,
                Path('pear.log'): FAKE_HEXDIGEST_C.digest_bytes,
                Path('mainApp.exe'): FAKE_HEXDIGEST_E.digest_bytes,
            }.get(filename)
            if not digest:
                raise HashFileNotFoundError
            return digest

        self.file_hasher = InterfaceMock(IFileHasher,
            hash_file = Mock(side_effect=mock_hash_file),
        )

        def mock_stat_file(filename: Path) -> FileStat:
            file_stat: FileStat | None = {
                Path('apple.txt'): FileStat(Path('apple.txt'), does_exist=True, is_file=True),
                Path('banana.dat'): FileStat(Path('banana.dat'), does_exist=True, is_file=True),
                Path('pear.log'): FileStat(Path('pear.log'), does_exist=True, is_file=True),
                Path('mainApp.exe'): FileStat(Path('mainApp.exe'), does_exist=True, is_file=True),
                Path('database.id'): FileStat(Path('database.id'), does_exist=True, is_file=True),
                Path('config.json'): FileStat(Path('config.json'), does_exist=True, is_file=True),
                Path('history.txt'): FileStat(Path('history.txt'), does_exist=True, is_file=True),
                Path('auto.txt'): FileStat(Path('auto.txt'), does_exist=True, is_file=True),
            }.get(filename)
            if not file_stat:
                return FileStat(filename, does_exist=False, is_file=False)
            return file_stat

        self.file_tester = InterfaceMock(IFileTester,
            stat_file = Mock(side_effect=mock_stat_file),
        )

    @patch('sys.platform', 'win32')
    @patch('sys.executable', str(Path('C:') / 'Temp' / 'milodb' / 'mainApp.exe'))
    def test_integration_of_all_functions_on_windows(self) -> None:
        mock_path.map_of_absolute_resolution = {
            Path('C:') / 'Temp' / 'milodb': Path('C:') / 'Temp' / 'milodb',
            Path('C:') / 'Temp' / 'milodb' / 'mainApp.exe': Path('C:') / 'Temp' / 'milodb' / 'mainApp.exe',
        }
        mock_path.map_of_relative_to_resolution = {
            (Path('C:') / 'Temp' / 'milodb' / 'mainApp.exe', Path('C:') / 'Temp' / 'milodb'): Path('mainApp.exe'),
        }

        with patch.object(Path, 'absolute', mock_path.absolute), patch.object(Path, 'relative_to', mock_path.relative_to):
            self._test_integration_of_all_functions(Path('C:') / 'Temp' / 'milodb', 'win32', Path('mainApp.exe'))

    @patch('sys.platform', 'linux')
    @patch('sys.executable', r'/directory/milodb/mainApp')
    def test_integration_of_all_functions_on_linux(self) -> None:
        mock_path.map_of_absolute_resolution = {
            Path('/directory') / 'milodb': Path('/directory') / 'milodb',
            Path('/directory') / 'milodb' / 'mainApp': Path('/directory') / 'milodb' / 'mainApp',
        }
        mock_path.map_of_relative_to_resolution = {
            (Path(r'/directory/milodb/mainApp'), Path(r'/directory/milodb')): Path('mainApp'),
        }

        with patch.object(Path, 'absolute', mock_path.absolute), patch.object(Path, 'relative_to', mock_path.relative_to):
            self._test_integration_of_all_functions(Path('/directory') / 'milodb', 'linux', Path('mainApp'))

    @patch('sys.platform', 'osx')
    @patch('sys.executable', r'/directory/milodb/mainApp')
    def test_integration_of_all_functions_on_osx(self) -> None:
        mock_path.map_of_absolute_resolution = {
            Path('/directory') / 'milodb': Path('/directory') / 'milodb',
            Path('/directory') / 'milodb' / 'mainApp': Path('/directory') / 'milodb' / 'mainApp',
        }
        mock_path.map_of_relative_to_resolution = {
            (Path('/directory') / 'milodb' / 'mainApp', Path('/directory') / 'milodb'): Path('mainApp'),
        }

        with patch.object(Path, 'absolute', mock_path.absolute), patch.object(Path, 'relative_to', mock_path.relative_to):
            self._test_integration_of_all_functions(Path('/directory') / 'milodb', 'osx', None)

    def _test_integration_of_all_functions(self, root_directory: Path, os_name: str, app_name: Path | None) -> None:
        requested_version_number: IVersionNumber | None = None
        requested_variant: str | None = 'main'

        update_strategy: UpdateStrategy = determine_update_strategy(
            root_directory, requested_version_number, requested_variant,
            self.local_manifest, self.version_manifest, self.asset_register, self.file_hasher, self.file_tester)

        self.assertEqual(root_directory, update_strategy.root_directory)
        self.assertIs(self.local_manifest, update_strategy.local_manifest)
        self.assertIs(self.version_manifest, update_strategy.version_manifest)

        self.assertCountEqual([self.target_core_file_3, self.target_core_file_6], update_strategy.core_file_changes.list_of_new_files_to_acquire)
        self.assertCountEqual([self.target_core_file_4], update_strategy.core_file_changes.list_of_missing_files_to_acquire)
        self.assertCountEqual([self.target_core_file_2, self.target_core_file_5], update_strategy.core_file_changes.list_of_changed_files_to_acquire)
        self.assertCountEqual([self.target_core_file_1], update_strategy.core_file_changes.list_of_unchanged_files)
        self.assertCountEqual([Path('pear.log')], update_strategy.core_file_changes.list_of_files_that_are_deprecated)

        self.assertCountEqual([Path('auto.txt')], update_strategy.config_file_changes.list_of_files_that_are_deprecated)
        self.assertCountEqual([
                FileRename(Path('history.txt'), Path('history.log')),
                FileRename(Path('variables.txt'), Path('vars.txt')),
            ], update_strategy.config_file_changes.list_of_files_to_rename)
        self.assertCountEqual([Path('config.json')], update_strategy.config_file_changes.list_of_files_to_leave)
        self.assertCountEqual([Path('logging.txt')], update_strategy.config_file_changes.list_of_new_files)

        self.assertCountEqual([Path('apple.txt'), Path('banana.dat'), Path('pear.log'), Path('mainApp.exe')], update_strategy.backup_file_set.list_of_core_files_to_backup)
        self.assertCountEqual([Path('config.json'), Path('history.txt'), Path('auto.txt'), Path('variables.txt')], update_strategy.backup_file_set.list_of_config_files_to_backup)
        self.assertCountEqual([Path('database.id')], update_strategy.backup_file_set.list_of_clobbered_files_to_backup)

        self.assertEqual(os_name, update_strategy.current_operating_system)
        if os_name and app_name:
            if self.assert_is_not_none(update_strategy.launch_executable):
                self.assertEqual(os_name, update_strategy.launch_executable.operating_system)
                self.assertEqual(app_name, update_strategy.launch_executable.filename)
        else:
            self.assertIsNone(update_strategy.launch_executable)
