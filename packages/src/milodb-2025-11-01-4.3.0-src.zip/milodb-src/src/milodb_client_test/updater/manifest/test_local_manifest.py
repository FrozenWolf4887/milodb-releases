# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import datetime
import unittest
from pathlib import Path
from typing import TYPE_CHECKING
from milodb_client.updater.manifest.i_schema_types import SchemaLoadError
from milodb_client.updater.manifest.local_manifest_schema import LocalManifestSchema
from milodb_client.updater.manifest.version_number import VersionNumber
from milodb_client_test.test import json_tools
if TYPE_CHECKING:
    from collections.abc import Mapping

SAMPLE_LOCAL_MANIFEST: str = r"""
{
    "format": 1,
    "variant": "main",
    "version": "1.7.0",
    "date": "2023-07-31",
    "coreFiles": [
        "milodb.exe",
        "milodb.ver",
        "database.mdb",
        "changelog.md",
        "default.css"
    ],
    "configFiles": {
        "90": "variables.json",
        "82": "settings.json",
        "38": "history.txt"
    }
}
"""

class TestLocalManifest(unittest.TestCase):
    def test_throws_when_root_is_invalid(self) -> None:
        with self.assertRaises(SchemaLoadError) as capture:
            LocalManifestSchema().load('hello')
        self.assertEqual("Schema of local manifest has invalid root type of 'str'", str(capture.exception))

    def test_throws_when_format_is_missing(self) -> None:
        json_root: Mapping[object, object] = json_tools.load_and_prune_json_key(SAMPLE_LOCAL_MANIFEST, 'format')
        with self.assertRaises(SchemaLoadError) as capture:
            LocalManifestSchema().load(json_root)
        self.assertEqual("Format field of local manifest is missing", str(capture.exception))

    def test_throws_when_format_is_unexpected_value(self) -> None:
        json_root: Mapping[object, object] = json_tools.load_and_change_json_value(SAMPLE_LOCAL_MANIFEST, 'format', 24)
        with self.assertRaises(SchemaLoadError) as capture:
            LocalManifestSchema().load(json_root)
        self.assertEqual("Unsupported local manifest format of '24'; expected to be '1'", str(capture.exception))

    def test_throws_when_format_is_unexpected_type(self) -> None:
        json_root: Mapping[object, object] = json_tools.load_and_change_json_value(SAMPLE_LOCAL_MANIFEST, 'format', '1')
        with self.assertRaises(SchemaLoadError) as capture:
            LocalManifestSchema().load(json_root)
        self.assertEqual("Format field of local manifest is of type 'str'; expected to be 'int'", str(capture.exception))

    def test_throws_when_entries_missing(self) -> None:
        list_of_paths_to_remove: tuple[str, ...] = (
            'variant',
            'version',
            'date',
            'coreFiles',
            'configFiles',
        )
        path_to_remove: str
        for path_to_remove in list_of_paths_to_remove:
            with self.subTest(missing_entry=path_to_remove):
                json_root: Mapping[object, object] = json_tools.load_and_prune_json_key(SAMPLE_LOCAL_MANIFEST, path_to_remove)
                with self.assertRaises(SchemaLoadError) as capture:
                    LocalManifestSchema().load(json_root)
                self.assertEqual(f"Key '{path_to_remove}' is missing", str(capture.exception))

    def test_throws_when_entries_are_of_incorrect_basic_type(self) -> None:
        list_of_paths_to_change: tuple[tuple[str, object, str], ...] = (
            ('variant', 1234, 'text'),
            ('date', 1234, 'text'),
            ('version', 1234, 'text'),
            ('coreFiles', 'fruit', 'a list'),
            ('configFiles', 'fruit', 'a group'),
        )
        path_to_change: str
        new_value: object
        error_message_suffix: str
        for path_to_change, new_value, error_message_suffix in list_of_paths_to_change:
            with self.subTest(changed_entry=path_to_change, new_value=new_value):
                json_root: Mapping[object, object] = json_tools.load_and_change_json_value(SAMPLE_LOCAL_MANIFEST, path_to_change, new_value)
                with self.assertRaises(SchemaLoadError) as capture:
                    LocalManifestSchema().load(json_root)
                self.assertEqual(f"Key '{path_to_change}' value is not {error_message_suffix}", str(capture.exception))

    def test_throws_when_version_format_is_incorrect(self) -> None:
        list_of_keys_to_change: tuple[str, ...] = (
            '1.7',
            '1.8.0a',
            'a1.b2.c3',
        )
        new_value: str
        for new_value in list_of_keys_to_change:
            with self.subTest(version_value=new_value):
                json_root: Mapping[object, object] = json_tools.load_and_change_json_value(SAMPLE_LOCAL_MANIFEST, 'version', new_value)
                with self.assertRaises(SchemaLoadError) as capture:
                    LocalManifestSchema().load(json_root)
                self.assertEqual(f"Key 'version' value '{new_value}' is not a Semantic Version number", str(capture.exception))

    def test_throws_when_date_entry_is_wrong_format(self) -> None:
        list_of_paths_to_change: tuple[tuple[str, object], ...] = (
            ('date', '2021-06-4'),
            ('date', '30-09-23'),
        )
        path_to_change: str
        new_value: object
        for path_to_change, new_value in list_of_paths_to_change:
            with self.subTest(changed_entry=path_to_change, new_value=new_value):
                json_root: Mapping[object, object] = json_tools.load_and_change_json_value(SAMPLE_LOCAL_MANIFEST, path_to_change, new_value)
                with self.assertRaises(SchemaLoadError) as capture:
                    LocalManifestSchema().load(json_root)
                self.assertEqual(f"Key '{path_to_change}' value '{new_value}' is not an ISO date", str(capture.exception))

    def test_throws_when_values_are_blank(self) -> None:
        list_of_paths_to_change: tuple[str, ...] = (
            'variant',
            'version',
            'configFiles/90',
        )
        path_to_change: str
        for path_to_change in list_of_paths_to_change:
            with self.subTest(changed_entry=path_to_change):
                json_root: Mapping[object, object] = json_tools.load_and_change_json_value(SAMPLE_LOCAL_MANIFEST, path_to_change, '')
                with self.assertRaises(SchemaLoadError) as capture:
                    LocalManifestSchema().load(json_root)
                self.assertEqual(f"Key '{path_to_change}' value is blank", str(capture.exception))

    def test_throws_when_config_key_is_not_an_integer(self) -> None:
        list_of_keys_to_change: tuple[tuple[str, str, str], ...] = (
            ('configFiles', '90', '90a'),
            ('configFiles', '82', 'a82'),
        )
        path_to_change: str
        key_to_change: str
        new_key_value: str
        for path_to_change, key_to_change, new_key_value in list_of_keys_to_change:
            with self.subTest(changed_key=f'{path_to_change}/{key_to_change}', new_value=new_key_value):
                json_root: Mapping[object, object] = json_tools.load_and_change_json_key(SAMPLE_LOCAL_MANIFEST, f'{path_to_change}/{key_to_change}', new_key_value)
                with self.assertRaises(SchemaLoadError) as capture:
                    LocalManifestSchema().load(json_root)
                self.assertEqual(f"Key '{path_to_change}/{new_key_value}': '{new_key_value}' is not an integer", str(capture.exception))

class TestLocalManifestProperties(unittest.TestCase):
    def test_access_entries_as_properties(self) -> None:
        manifest: LocalManifestSchema = LocalManifestSchema()
        manifest.load(json_tools.load_json(SAMPLE_LOCAL_MANIFEST))
        self.assertEqual(1, manifest.format)
        self.assertEqual('main', manifest.variant_name)
        self.assertEqual(VersionNumber(1, 7 ,0), manifest.version_number)
        self.assertEqual(datetime.date(2023, 7, 31), manifest.date)
        self.assertSequenceEqual([
            Path("milodb.exe"),
            Path("milodb.ver"),
            Path("database.mdb"),
            Path("changelog.md"),
            Path("default.css"),
        ], manifest.core_files)
        self.assertEqual(3, len(manifest.config_files))
        self.assertEqual(90, manifest.config_files[90].config_key)
        self.assertEqual(Path('variables.json'), manifest.config_files[90].filename)
        self.assertEqual(82, manifest.config_files[82].config_key)
        self.assertEqual(Path('settings.json'), manifest.config_files[82].filename)
        self.assertEqual(38, manifest.config_files[38].config_key)
        self.assertEqual(Path('history.txt'), manifest.config_files[38].filename)
