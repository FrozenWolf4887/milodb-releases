# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import re
from collections.abc import Sequence
from typing import override

class RegexStringMatch:
    def __init__(self, expected_pattern: re.Pattern[str] | str, flags: int = 0) -> None:
        if isinstance(expected_pattern, str):
            expected_pattern = re.compile(expected_pattern, flags=flags)
        self._expected_pattern: re.Pattern[str] = expected_pattern

    @override
    def __eq__(self, other: object) -> bool:
        return isinstance(other, str) and self._expected_pattern.fullmatch(other) is not None

    @override
    def __hash__(self) -> int:
        return hash(self._expected_pattern)

    @override
    def __repr__(self) -> str:
        return f"<String Pattern> '{self._expected_pattern.pattern}'"

class RegexSubstringMatch:
    def __init__(self, expected_pattern: re.Pattern[str] | str, flags: int = 0) -> None:
        if isinstance(expected_pattern, str):
            expected_pattern = re.compile(expected_pattern, flags=flags)
        self._expected_pattern: re.Pattern[str] = expected_pattern

    @override
    def __eq__(self, other: object) -> bool:
        return isinstance(other, str) and self._expected_pattern.search(other) is not None

    @override
    def __hash__(self) -> int:
        return hash(self._expected_pattern)

    @override
    def __repr__(self) -> str:
        return f"<Substring Pattern> '{self._expected_pattern.pattern}'"

class MultiSubstringMatch:
    def __init__(self, list_of_expected_text: Sequence[str]) -> None:
        self._list_of_expected_text: Sequence[str] = list_of_expected_text

    @override
    def __eq__(self, other: object) -> bool:
        return isinstance(other, str) and all(text in other for text in self._list_of_expected_text)

    @override
    def __hash__(self) -> int:
        return hash(self._list_of_expected_text)

    @override
    def __repr__(self) -> str:
        return f"<Substring List> '{self._list_of_expected_text}'"
