# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
_MAX_SMALL_CHUNKS: int = 100

class StringBuilder:
    def __init__(self) -> None:
        self._list_of_big_chunks: list[str] = []
        self._list_of_small_chunks: list[str] = []

    def put(self, text: str) -> None:
        if len(self._list_of_small_chunks) >= _MAX_SMALL_CHUNKS:
            big_chunk: str = ''.join(self._list_of_small_chunks)
            self._list_of_big_chunks.append(big_chunk)
            self._list_of_small_chunks = [text]
        else:
            self._list_of_small_chunks.append(text)

    def clear(self) -> None:
        self._list_of_big_chunks = []
        self._list_of_small_chunks = []

    def get_text(self) -> str:
        return ''.join(self._list_of_big_chunks) + ''.join(self._list_of_small_chunks)
