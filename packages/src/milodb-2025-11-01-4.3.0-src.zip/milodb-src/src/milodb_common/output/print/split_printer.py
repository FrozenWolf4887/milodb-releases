# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from collections.abc import Iterable
from typing import override
from milodb_common.output.print.i_printer import IPrinter

class SplitPrinter(IPrinter):
    def __init__(self, list_of_printers: Iterable[IPrinter]) -> None:
        self._list_of_printers: Iterable[IPrinter] = list_of_printers

    @override
    def write(self, text: str) -> None:
        printer: IPrinter
        for printer in self._list_of_printers:
            printer.write(text)

    @override
    def writeln(self, text: str | None = None) -> None:
        printer: IPrinter
        for printer in self._list_of_printers:
            printer.writeln(text)

    @property
    @override
    def is_on_new_line(self) -> bool:
        if self._list_of_printers:
            return next(iter(self._list_of_printers)).is_on_new_line
        return True
