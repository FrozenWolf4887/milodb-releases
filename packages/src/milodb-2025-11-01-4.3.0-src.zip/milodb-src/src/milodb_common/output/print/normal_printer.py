# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from typing import override
from milodb_common.output.print.redirectable_printer import RedirectablePrinter

class NormalPrinter(RedirectablePrinter):
    @override
    def write(self, text: str) -> None:
        self._target_printer.write(text)

    @override
    def writeln(self, text: str | None = None) -> None:
        self._target_printer.writeln(text)

    @property
    @override
    def is_on_new_line(self) -> bool:
        return self._target_printer.is_on_new_line
