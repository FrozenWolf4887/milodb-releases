# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from typing import IO, override
from milodb_common.output.print.i_printer import IPrinter

class FilePrinter(IPrinter):
    def __init__(self, file: IO[str]) -> None:
        self._file: IO[str] = file
        self._is_on_new_line: bool = False

    @override
    def write(self, text: str) -> None:
        if text:
            self._file.write(text)
            self._is_on_new_line = text[-1] == '\n'

    @override
    def writeln(self, text: str | None = None) -> None:
        if text:
            self._file.write(text)
        self._file.write('\n')
        self._is_on_new_line = True

    @property
    @override
    def is_on_new_line(self) -> bool:
        return self._is_on_new_line
