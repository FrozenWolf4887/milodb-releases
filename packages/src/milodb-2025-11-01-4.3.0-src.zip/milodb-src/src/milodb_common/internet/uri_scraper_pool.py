# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import urllib.parse
from collections.abc import Callable
from types import TracebackType
from typing import override
from milodb_common.internet.file_path_scraper import FilePathScraper
from milodb_common.internet.https_path_scraper import HttpsPathScraper
from milodb_common.internet.i_scraper import IPathScraper, IUrlScraper, IUrlScraperPool, ScrapeProgressCallback, ScrapeResult

_MAXIMUM_REDIRECTIONS: int = 2

class UrlScraperPool(IUrlScraperPool, IUrlScraper):
    def __init__(self, close_callback: Callable[[str], None] | None = None) -> None:
        self._close_callback: Callable[[str], None] | None = close_callback
        self._map_of_netloc_to_path_scraper: dict[tuple[str, str], IPathScraper] = {}

    @override
    def __enter__(self) -> IUrlScraper:
        return self

    @override
    def __exit__(self, exc_type: type[BaseException] | None, exc_value: BaseException | None, traceback: TracebackType | None) -> None:
        self.close(self._close_callback)

    @override
    def try_scrape_url(self, url: str, progress_callback: ScrapeProgressCallback | None) -> ScrapeResult:
        redirection_count: int = 0

        while redirection_count < _MAXIMUM_REDIRECTIONS:
            scrape_result: ScrapeResult = self._get_scraper_and_try_scrape(url, progress_callback)
            if not scrape_result.error_message:
                return scrape_result

            if scrape_result.redirection_url:
                if progress_callback:
                    progress_callback(message=scrape_result.error_message, percentage_complete=None)
                url = scrape_result.redirection_url
                redirection_count += 1
            else:
                return scrape_result

        return ScrapeResult(f'Maximum redirections of {_MAXIMUM_REDIRECTIONS} reached', None, b'')

    @override
    def close(self, close_callback: Callable[[str], None] | None) -> None:
        path_scraper: IPathScraper
        for path_scraper in self._map_of_netloc_to_path_scraper.values():
            path_scraper.close(close_callback)
        self._map_of_netloc_to_path_scraper = {}

    def _get_scraper_and_try_scrape(self, url: str, progress_callback: ScrapeProgressCallback | None) -> ScrapeResult:
        parse_result: urllib.parse.ParseResult = urllib.parse.urlparse(url)
        scraper_key: tuple[str, str] = (parse_result.scheme, parse_result.netloc)
        path_scraper: IPathScraper | None = self._map_of_netloc_to_path_scraper.get(scraper_key)
        if not path_scraper:
            try:
                path_scraper = _create_scraper_for_scheme(parse_result)
            except _PathScraperError as ex:
                return ScrapeResult(str(ex), None, b'')
            self._map_of_netloc_to_path_scraper[scraper_key] = path_scraper
        filepath: str = parse_result._replace(scheme='', netloc='').geturl()
        return path_scraper.try_scrape_path(filepath, progress_callback)

class _PathScraperError(Exception):
    pass

def _create_scraper_for_scheme(parse_result: urllib.parse.ParseResult) -> IPathScraper:
    match parse_result.scheme:
        case 'https':
            return _create_https_path_scraper(parse_result)
        case 'file':
            return _create_file_path_scraper(parse_result)
        case _:
            msg = f"Unsupported URL scheme '{parse_result.scheme}'"
            raise _PathScraperError(msg)

def _create_https_path_scraper(parse_result: urllib.parse.ParseResult) -> IPathScraper:
    if not parse_result.hostname:
        msg = 'URL has no hostname'
        raise _PathScraperError(msg)

    try:
        port: int | None = parse_result.port
    except ValueError as ex:
        msg = f'URL has invalid port number: {ex}'
        raise _PathScraperError(msg) from ex

    if port is not None:
        return HttpsPathScraper(parse_result.hostname, port)
    return HttpsPathScraper(parse_result.hostname)

def _create_file_path_scraper(parse_result: urllib.parse.ParseResult) -> IPathScraper:
    if parse_result.hostname is not None:
        msg = 'URL has a redundant hostname'
        raise _PathScraperError(msg)

    try:
        port: int | None = parse_result.port
    except ValueError as ex:
        msg = 'URL has an invalid and redundant port'
        raise _PathScraperError(msg) from ex

    if port is not None:
        msg = 'URL has a redundant port'
        raise _PathScraperError(msg)

    if not parse_result.path:
        msg = 'URL has no path'
        raise _PathScraperError(msg)

    return FilePathScraper()
