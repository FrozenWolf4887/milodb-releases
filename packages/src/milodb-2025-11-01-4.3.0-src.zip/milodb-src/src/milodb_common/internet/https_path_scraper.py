# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import gzip
import sys
from collections.abc import Callable, Mapping
from http import HTTPStatus
from http.client import HTTPException, HTTPResponse, HTTPSConnection, IncompleteRead
from io import BufferedIOBase
from typing import override
from milodb_common.internet.i_scraper import IPathScraper, ScrapeProgressCallback, ScrapeResult
from milodb_common.internet.throttle import Throttle

_DEFAULT_TIMEOUT_SECONDS: int = 60
_GET_REQUEST: str = 'GET'
_GZIP_ENCODING: str = 'gzip'
_REQUEST_HEADERS: Mapping[str, str] = {
    'Accept': '*/*',
    'Accept-Encoding': _GZIP_ENCODING,
    'Connection': 'keep-alive',
    'User-Agent': f'MiloDB ({sys.platform})',
}
_READ_CHUNK_SIZE: int = 1024*1024
_MIN_SECONDS_BETWEEN_REQUESTS: float = 1.5

class HttpsPathScraper(IPathScraper):
    def __init__(self, host_name: str, host_port: int | None = None) -> None:
        self._connection: HTTPSConnection = HTTPSConnection(host_name, host_port or HTTPSConnection.default_port, timeout=_DEFAULT_TIMEOUT_SECONDS)
        self._throttle: Throttle = Throttle(min_seconds_between_yields=_MIN_SECONDS_BETWEEN_REQUESTS)
        self._error_message: str | None = None

    @override
    def try_scrape_path(self, filepath: str, progress_callback: ScrapeProgressCallback | None) -> ScrapeResult:
        self._error_message = None
        if self._connect_to_host(progress_callback) and self._send_request(filepath, progress_callback):
            response: HTTPResponse | None = self._receive_response()
            if response:
                if response.status in {HTTPStatus.MOVED_PERMANENTLY, HTTPStatus.FOUND}:
                    self._error_message = f'Redirection response: {response.status} {response.reason}'
                    redirection_url: str | None = response.getheader('Location')
                    if redirection_url:
                        self._error_message += f": to '{redirection_url}'"
                        return ScrapeResult(self._error_message, redirection_url, b'')
                    self._error_message += ': without location URL'
                    return ScrapeResult(self._error_message, None, b'')

                content: bytes | None = self._read_data(response, progress_callback)
                if content is not None:
                    return ScrapeResult(None, None, content)

        return ScrapeResult(self._error_message, None, b'')

    @override
    def close(self, close_callback: Callable[[str], None] | None) -> None:
        if self._is_connected:
            if close_callback:
                close_callback(f"Disconnecting from '{self._connection.host}:{self._connection.port}'")
            self._connection.close()

    @property
    def _is_connected(self) -> bool:
        return self._connection.sock is not None

    def _connect_to_host(self, progress_callback: ScrapeProgressCallback | None) -> bool:
        if not self._is_connected:
            self._throttle.apply_throttle_delay()
            if progress_callback:
                progress_callback(message=f"Connecting to '{self._connection.host}:{self._connection.port}'", percentage_complete=None)
            try:
                self._connection.connect()
            except OSError as ex:
                self._error_message = str(ex)
                return False
        return True

    def _send_request(self, filepath: str, progress_callback: ScrapeProgressCallback | None) -> bool:
        self._throttle.apply_throttle_delay()
        if progress_callback:
            progress_callback(message=f"Sending {_GET_REQUEST} request '{filepath}'", percentage_complete=None)
        try:
            self._connection.request(_GET_REQUEST, filepath, headers=_REQUEST_HEADERS)
        except (OSError, HTTPException) as ex:
            self._error_message = str(ex)
            return False
        return True

    def _receive_response(self) -> HTTPResponse | None:
        try:
            response: HTTPResponse = self._connection.getresponse()
        except (OSError, HTTPException) as ex:
            self._error_message = str(ex)
            return None

        if response.status in {HTTPStatus.MOVED_PERMANENTLY, HTTPStatus.FOUND, HTTPStatus.OK}:
            return response

        self._error_message = f'Request failed with response: {response.status} {response.reason}'
        try:
            response.read()
        except (OSError, HTTPException) as ex:
            self._error_message += f' and {ex}'

        return None

    def _read_data(self, response: HTTPResponse, progress_callback: ScrapeProgressCallback | None) -> bytes | None:
        content: bytes | None
        if response.length and progress_callback:
            content = self._read_data_in_chunks(response, response.length, progress_callback)
        else:
            content = self._read_data_all_at_once(response, progress_callback)

        if content is None:
            return None

        content_type: str = response.getheader('Content-Type') or 'unspecified'
        content_encoding: str = response.getheader('Content-Encoding') or 'unspecified'
        if progress_callback:
            progress_callback(message=f"Received {len(content):,} bytes of type '{content_type}' encoded as '{content_encoding}'", percentage_complete=None)

        if response.getheader('Connection') == 'close':
            if progress_callback:
                progress_callback(message=f"Disconnecting from '{self._connection.host}:{self._connection.port}' at request of server", percentage_complete=None)
            self._connection.close()

        if _GZIP_ENCODING in content_encoding:
            decompressed_data: bytes | None = self._decompress_data(content, progress_callback)
            if decompressed_data is None:
                return None
            content = decompressed_data

        return content

    def _read_data_all_at_once(self, stream: BufferedIOBase, progress_callback: ScrapeProgressCallback | None) -> bytes | None:
        content: bytearray = bytearray()

        while True:
            try:
                content.extend(stream.read())
            except IncompleteRead as ex:
                if progress_callback:
                    progress_callback(message=f'Received partial {len(ex.partial):,} bytes', percentage_complete=None)
                content.extend(ex.partial)
            except (OSError, HTTPException) as ex:
                self._error_message = str(ex)
                return None
            else:
                return bytes(content)

    def _read_data_in_chunks(self, stream: BufferedIOBase, length: int, progress_callback: ScrapeProgressCallback) -> bytes | None:
        progress_callback(message=f'Size is {length:,} bytes', percentage_complete=None)
        content: bytearray = bytearray()

        percentage_complete: int = -1
        finished_reading: bool = False
        try:
            while not finished_reading:
                new_percentage_complete: int = len(content) * 100 // length
                if new_percentage_complete != percentage_complete:
                    new_percentage_complete = percentage_complete
                    progress_callback(message=None, percentage_complete=percentage_complete)
                try:
                    chunk: bytes = stream.read(_READ_CHUNK_SIZE)
                except IncompleteRead as ex:
                    progress_callback(message=f'Received partial {len(ex.partial):,} bytes', percentage_complete=None)
                    content.extend(ex.partial)
                else:
                    if not chunk:
                        finished_reading = True
                    else:
                        content.extend(chunk)
        except (OSError, HTTPException) as ex:
            self._error_message = str(ex)
            return None

        progress_callback(message=None, percentage_complete=100)

        return bytes(content)

    def _decompress_data(self, content: bytes, progress_callback: ScrapeProgressCallback | None) -> bytes | None:
        try:
            content = gzip.decompress(content)
        except gzip.BadGzipFile as ex:
            self._error_message = str(ex)
            return None

        if progress_callback:
            progress_callback(message=f"Decompressed data is {len(content):,} bytes", percentage_complete=None)

        return content
