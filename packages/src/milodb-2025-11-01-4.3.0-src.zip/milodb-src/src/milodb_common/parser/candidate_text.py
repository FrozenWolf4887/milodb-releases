# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from __future__ import annotations
from dataclasses import dataclass
from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from collections.abc import Iterable

@dataclass
class CandidateText:
    text: str
    following_delimiter: str

    @staticmethod
    def space_delimited_list(iterable: Iterable[str]) -> list[CandidateText]:
        return [CandidateText(text, ' ') for text in iterable]

    @staticmethod
    def delimited_list(delimiter: str, iterable: Iterable[str]) -> list[CandidateText]:
        return [CandidateText(text, delimiter) for text in iterable]
