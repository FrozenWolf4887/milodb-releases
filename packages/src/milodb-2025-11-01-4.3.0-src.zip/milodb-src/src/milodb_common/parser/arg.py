# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import datetime
import re
from abc import abstractmethod
from collections.abc import Callable, Generator, Iterable, Mapping, MutableMapping, Sequence
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import override
from milodb_common.parser.arg_token_stream import ArgTokenStream
from milodb_common.parser.arg_type import ArgType
from milodb_common.parser.candidate_text import CandidateText
from milodb_common.parser.ref_id import AuthorId, MatchIndex, RefId as RefIdType, TeaseId as TeaseIdType
from milodb_common.parser.token import Token
from milodb_common.types.partial_date import PartialDate
from milodb_common.util import enums
from milodb_common.variables.i_user_variables import VARIABLE_NAME_PATTERN

_DATE_FORMAT: str = 'yyyy-mm-dd'
_MSG_INSUFFICIENT_PARAMETERS: str = 'Insufficient parameters'

@dataclass
class ArgumentError(Exception):
    message: str
    fault_token: Token | None
    list_of_candidate_text: Sequence[CandidateText]

class IArgParser[T]:
    @property
    @abstractmethod
    def arg_type(self) -> ArgType:
        pass

    @abstractmethod
    def get_expecting_type_description(self) -> str:
        pass

    @abstractmethod
    def get_list_of_candidate_text(self) -> Sequence[CandidateText]:
        pass

    @abstractmethod
    def parse(self, token: Token) -> T:
        pass

def pop[T](arg_token_stream: ArgTokenStream, arg_parser: IArgParser[T], override_arg_type: ArgType | None = None) -> T:
    token: Token | None = arg_token_stream.next_arg(override_arg_type or arg_parser.arg_type)
    if token:
        return arg_parser.parse(token)
    raise ArgumentError(
        message = f'{_MSG_INSUFFICIENT_PARAMETERS}, expecting {arg_parser.get_expecting_type_description()}',
        fault_token = None,
        list_of_candidate_text = arg_parser.get_list_of_candidate_text(),
    )

def pop_optional[T](arg_token_stream: ArgTokenStream, arg_parser: IArgParser[T], override_arg_type: ArgType | None = None) -> T | None:
    token: Token | None = arg_token_stream.next_arg(override_arg_type or arg_parser.arg_type)
    if token:
        return arg_parser.parse(token)
    return None

def pop_list[T](arg_token_stream: ArgTokenStream, arg_parser: IArgParser[T], override_arg_type: ArgType | None = None) -> list[T]:
    list_of_values: list[T] = []
    token: Token | None
    while token := arg_token_stream.next_arg(override_arg_type or arg_parser.arg_type):
        list_of_values.append(arg_parser.parse(token))
    return list_of_values

def pop_minimum_list[T](arg_token_stream: ArgTokenStream, min_length: int, arg_parser: IArgParser[T], override_arg_type: ArgType | None = None) -> list[T]:
    list_of_values: list[T] = pop_list(arg_token_stream, arg_parser, override_arg_type)
    if len(list_of_values) >= min_length:
        return list_of_values
    raise ArgumentError(
        message = f'{_MSG_INSUFFICIENT_PARAMETERS}, expecting at least {min_length} {arg_parser.get_expecting_type_description()}',
        fault_token = None,
        list_of_candidate_text = arg_parser.get_list_of_candidate_text(),
    )

def for_each[T](arg_token_stream: ArgTokenStream, arg_parser: IArgParser[T], handler: Callable[[T], bool], override_arg_type: ArgType | None = None) -> None:
    token: Token | None
    while token := arg_token_stream.next_arg(override_arg_type or arg_parser.arg_type):
        if not handler(arg_parser.parse(token)):
            break

def iterate[T](arg_token_stream: ArgTokenStream, arg_parser: IArgParser[T], override_arg_type: ArgType | None = None) -> Generator[T]:
    token: Token | None
    while token := arg_token_stream.next_arg(override_arg_type or arg_parser.arg_type):
        yield arg_parser.parse(token)

def fail_if_not_empty(arg_token_stream: ArgTokenStream) -> None:
    token: Token | None = arg_token_stream.next()
    if token is not None:
        raise ArgumentError(
            message = 'Unexpected additional parameter',
            fault_token = token,
            list_of_candidate_text = [],
        )

class _Token(IArgParser[Token]):
    @property
    @override
    def arg_type(self) -> ArgType:
        return ArgType.ARG_UNKNOWN

    @override
    def parse(self, token: Token) -> Token:
        return token

    @override
    def get_expecting_type_description(self) -> str:
        return 'token'

    @override
    def get_list_of_candidate_text(self) -> Sequence[CandidateText]:
        return []

class EnumFromName[E: Enum](IArgParser[E]):
    def __init__(self, enum_class: type[E]) -> None:
        self._enum_class: type[E] = enum_class

    @override
    def parse(self, token: Token) -> E:
        try:
            return self._enum_class[token.text.upper()]
        except KeyError as ex:
            raise ArgumentError(
                message = 'Unknown keyword or value',
                fault_token = token,
                list_of_candidate_text = self.get_list_of_candidate_text(),
            ) from ex

    @property
    @override
    def arg_type(self) -> ArgType:
        return ArgType.ARG_ENUM

    @override
    def get_expecting_type_description(self) -> str:
        return self._enum_class.__name__

    @override
    def get_list_of_candidate_text(self) -> Sequence[CandidateText]:
        return CandidateText.space_delimited_list(enums.lowercase_names(self._enum_class))

class EnumFromValue[E: Enum](IArgParser[E]):
    def __init__(self, enum_class: type[E]) -> None:
        self._enum_class: type[E] = enum_class

    @override
    def parse(self, token: Token) -> E:
        try:
            return self._enum_class(token.text)
        except ValueError as ex:
            raise ArgumentError(
                message = 'Unknown keyword or value',
                fault_token = token,
                list_of_candidate_text = self.get_list_of_candidate_text(),
            ) from ex

    @property
    @override
    def arg_type(self) -> ArgType:
        return ArgType.ARG_ENUM

    @override
    def get_expecting_type_description(self) -> str:
        return self._enum_class.__name__

    @override
    def get_list_of_candidate_text(self) -> Sequence[CandidateText]:
        return CandidateText.space_delimited_list(enums.text_of_values(self._enum_class))

class Regex(IArgParser[re.Pattern[str]]):
    def __init__(self, flags: int) -> None:
        self._flags: int = flags

    @override
    def parse(self, token: Token) -> re.Pattern[str]:
        try:
            return re.compile(token.text, self._flags)
        except re.error as ex:
            raise ArgumentError(
                message = f"Invalid regular expression, {ex}",
                fault_token = token,
                list_of_candidate_text = [],
            ) from ex

    @property
    @override
    def arg_type(self) -> ArgType:
        return ArgType.ARG_REGEX

    @override
    def get_expecting_type_description(self) -> str:
        return 'regular expression'

    @override
    def get_list_of_candidate_text(self) -> Sequence[CandidateText]:
        return []

class VariableName(IArgParser[str]):
    def __init__(self, list_of_variable_names: Iterable[str]) -> None:
        self._list_of_variable_names: Iterable[str] = list_of_variable_names

    @override
    def parse(self, token: Token) -> str:
        if VARIABLE_NAME_PATTERN.fullmatch(token.text):
            return token.text
        raise ArgumentError(
            message = f"Invalid variable name, expecting pattern '{VARIABLE_NAME_PATTERN.pattern}'",
            fault_token = token,
            list_of_candidate_text = self.get_list_of_candidate_text(),
        )

    @property
    @override
    def arg_type(self) -> ArgType:
        return ArgType.ARG_VARIABLE

    @override
    def get_expecting_type_description(self) -> str:
        return 'variable name'

    @override
    def get_list_of_candidate_text(self) -> Sequence[CandidateText]:
        return CandidateText.space_delimited_list(self._list_of_variable_names)

class _Int(IArgParser[int]):
    @override
    def parse(self, token: Token) -> int:
        return _parse_int(token, token.text, 'integer value')

    @property
    @override
    def arg_type(self) -> ArgType:
        return ArgType.ARG_INT

    @override
    def get_expecting_type_description(self) -> str:
        return 'integer value'

    @override
    def get_list_of_candidate_text(self) -> Sequence[CandidateText]:
        return []

class _UInt(IArgParser[int]):
    @override
    def parse(self, token: Token) -> int:
        return _parse_uint(token, token.text, 'unsigned integer value')

    @property
    @override
    def arg_type(self) -> ArgType:
        return ArgType.ARG_INT

    @override
    def get_expecting_type_description(self) -> str:
        return 'unsigned integer value'

    @override
    def get_list_of_candidate_text(self) -> Sequence[CandidateText]:
        return []

class _Float(IArgParser[float]):
    @override
    def parse(self, token: Token) -> float:
        return _parse_float(token, token.text, 'integer or decimal value')

    @property
    @override
    def arg_type(self) -> ArgType:
        return ArgType.ARG_FLOAT

    @override
    def get_expecting_type_description(self) -> str:
        return 'integer or decimal value'

    @override
    def get_list_of_candidate_text(self) -> Sequence[CandidateText]:
        return []

class _UFloat(IArgParser[float]):
    @override
    def parse(self, token: Token) -> float:
        return _parse_ufloat(token, token.text, 'unsigned integer or decimal value')

    @property
    @override
    def arg_type(self) -> ArgType:
        return ArgType.ARG_FLOAT

    @override
    def get_expecting_type_description(self) -> str:
        return 'unsigned integer or decimal value'

    @override
    def get_list_of_candidate_text(self) -> Sequence[CandidateText]:
        return []

class _RefId(IArgParser[RefIdType]):
    @override
    def parse(self, token: Token) -> RefIdType:
        if token.text.startswith('#'):
            value = _parse_uint(token, token.text[1:], 'TeaseId as a positive integer')
            return TeaseIdType(value)
        if token.text.startswith('@'):
            value = _parse_uint(token, token.text[1:], 'AuthorId as a positive integer')
            return AuthorId(value)
        if token.text[0:1].isdigit():
            value = _parse_uint(token, token.text, 'match index as a positive integer')
            return MatchIndex(value)

        raise ArgumentError(
            message = "Invalid RefId, expecting 'value', '#value', or '@value'",
            fault_token = token,
            list_of_candidate_text = [],
        )

    @property
    @override
    def arg_type(self) -> ArgType:
        return ArgType.ARG_REFID

    @override
    def get_expecting_type_description(self) -> str:
        return 'RefId'

    @override
    def get_list_of_candidate_text(self) -> Sequence[CandidateText]:
        return []

class _TeaseId(IArgParser[int]):
    @override
    def parse(self, token: Token) -> int:
        if token.text.startswith('#'):
            return _parse_uint(token, token.text[1:], 'TeaseId as a positive integer')

        raise ArgumentError(
            message = "Invalid TeaseId, expecting #value",
            fault_token = token,
            list_of_candidate_text = [],
        )

    @property
    @override
    def arg_type(self) -> ArgType:
        return ArgType.ARG_REFID

    @override
    def get_expecting_type_description(self) -> str:
        return 'TeaseId'

    @override
    def get_list_of_candidate_text(self) -> Sequence[CandidateText]:
        return []

class DictValue[V](IArgParser[V]):
    def __init__(self, dictionary: Mapping[str, V], type_description: str) -> None:
        self._dictionary: Mapping[str, V] = dictionary
        self._type_description: str = type_description

    @override
    def parse(self, token: Token) -> V:
        try:
            return self._dictionary[token.text]
        except KeyError as ex:
            raise ArgumentError(
                message = f'Invalid {self._type_description}',
                fault_token = token,
                list_of_candidate_text = self.get_list_of_candidate_text(),
            ) from ex

    @property
    @override
    def arg_type(self) -> ArgType:
        return ArgType.ARG_ENUM

    @override
    def get_expecting_type_description(self) -> str:
        return self._type_description

    @override
    def get_list_of_candidate_text(self) -> Sequence[CandidateText]:
        return CandidateText.space_delimited_list(self._dictionary)

class DictValueAndRemoveEntry[V](IArgParser[V]):
    def __init__(self, dictionary: MutableMapping[str, V], type_description: str) -> None:
        self._dictionary: MutableMapping[str, V] = dictionary
        self._type_description: str = type_description

    @property
    @override
    def arg_type(self) -> ArgType:
        return ArgType.ARG_ENUM

    @override
    def parse(self, token: Token) -> V:
        try:
            return self._dictionary.pop(token.text)
        except KeyError as ex:
            raise ArgumentError(
                message = f'Invalid {self._type_description}',
                fault_token = token,
                list_of_candidate_text = self.get_list_of_candidate_text(),
            ) from ex

    @override
    def get_expecting_type_description(self) -> str:
        return self._type_description

    @override
    def get_list_of_candidate_text(self) -> Sequence[CandidateText]:
        return CandidateText.space_delimited_list(self._dictionary)

class _Date(IArgParser[datetime.date]):
    @override
    def parse(self, token: Token) -> datetime.date:
        try:
            return datetime.date.fromisoformat(token.text)
        except ValueError as ex:
            raise ArgumentError(
                message = f"Invalid date, expected format '{_DATE_FORMAT}'",
                fault_token = token,
                list_of_candidate_text = [],
            ) from ex

    @property
    @override
    def arg_type(self) -> ArgType:
        return ArgType.ARG_DATE

    @override
    def get_expecting_type_description(self) -> str:
        return 'date'

    @override
    def get_list_of_candidate_text(self) -> Sequence[CandidateText]:
        return []

class _PartialDate(IArgParser[PartialDate]):
    @override
    def parse(self, token: Token) -> PartialDate:
        try:
            return PartialDate.parse(token.text)
        except ValueError as ex:
            raise ArgumentError(
                message = f"Invalid date or partial date, {ex}",
                fault_token = token,
                list_of_candidate_text = [],
            ) from ex

    @property
    @override
    def arg_type(self) -> ArgType:
        return ArgType.ARG_DATE

    @override
    def get_expecting_type_description(self) -> str:
        return 'date or partial date'

    @override
    def get_list_of_candidate_text(self) -> Sequence[CandidateText]:
        return []

class Text(IArgParser[str]):
    def __init__(self, type_description: str) -> None:
        self._type_description: str = type_description

    @override
    def parse(self, token: Token) -> str:
        return token.text

    @property
    @override
    def arg_type(self) -> ArgType:
        return ArgType.ARG_TEXT

    @override
    def get_expecting_type_description(self) -> str:
        return self._type_description

    @override
    def get_list_of_candidate_text(self) -> Sequence[CandidateText]:
        return []

class FixedText(IArgParser[bool]):
    def __init__(self, _expected_text: str) -> None:
        self._expected_text = _expected_text

    @override
    def parse(self, token: Token) -> bool:
        if token.text == self._expected_text:
            return True
        raise ArgumentError(
            message = f"Invalid value, expecting fixed text '{self._expected_text}'",
            fault_token = token,
            list_of_candidate_text = self.get_list_of_candidate_text(),
        )

    @property
    @override
    def arg_type(self) -> ArgType:
        return ArgType.ARG_KEYWORD

    @override
    def get_expecting_type_description(self) -> str:
        return f"fixed text '{self._expected_text}'"

    @override
    def get_list_of_candidate_text(self) -> Sequence[CandidateText]:
        return CandidateText.space_delimited_list([self._expected_text])

class AnyFixedText(IArgParser[str]):
    def __init__(self, list_of_text: Iterable[str], type_description: str) -> None:
        self._list_of_text: Iterable[str] = list_of_text
        self._type_description: str = type_description

    @property
    @override
    def arg_type(self) -> ArgType:
        return ArgType.ARG_KEYWORD

    @override
    def parse(self, token: Token) -> str:
        if token.text in self._list_of_text:
            return token.text
        raise ArgumentError(
            message = f"Invalid value, expecting {self._type_description}",
            fault_token = token,
            list_of_candidate_text = self.get_list_of_candidate_text(),
        )

    @override
    def get_expecting_type_description(self) -> str:
        return self._type_description

    @override
    def get_list_of_candidate_text(self) -> Sequence[CandidateText]:
        return CandidateText.space_delimited_list(self._list_of_text)

class _Path(IArgParser[Path]):
    @override
    def parse(self, token: Token) -> Path:
        return Path(token.text)

    @property
    @override
    def arg_type(self) -> ArgType:
        return ArgType.ARG_PATH

    @override
    def get_expecting_type_description(self) -> str:
        return 'filepath'

    @override
    def get_list_of_candidate_text(self) -> Sequence[CandidateText]:
        return []

def _parse_int(token: Token, text: str, type_description: str) -> int:
    try:
        return int(text)
    except ValueError as ex:
        raise ArgumentError(
            message = f'Invalid value, expecting {type_description}',
            fault_token = token,
            list_of_candidate_text = [],
        ) from ex

def _parse_uint(token: Token, text: str, type_description: str) -> int:
    value: int = _parse_int(token, text, type_description)
    if value < 0:
        raise ArgumentError(
            message = f'Invalid value, expecting {type_description}',
            fault_token = token,
            list_of_candidate_text = [],
        )
    return value

def _parse_float(token: Token, text: str, type_description: str) -> float:
    try:
        return float(text)
    except ValueError as ex:
        raise ArgumentError(
            message = f'Invalid value, expecting {type_description}',
            fault_token = token,
            list_of_candidate_text = [],
        ) from ex

def _parse_ufloat(token: Token, text: str, type_description: str) -> float:
    value: float = _parse_float(token, text, type_description)
    if value < 0:
        raise ArgumentError(
            message = f'Invalid value, expecting {type_description}',
            fault_token = token,
            list_of_candidate_text = [],
        )
    return value

TOKEN = _Token()
INT = _Int()
UINT = _UInt()
FLOAT = _Float()
UFLOAT = _UFloat()
REF_ID = _RefId()
TEASE_ID = _TeaseId()
DATE = _Date()
PARTIAL_DATE = _PartialDate()
PATH = _Path()
