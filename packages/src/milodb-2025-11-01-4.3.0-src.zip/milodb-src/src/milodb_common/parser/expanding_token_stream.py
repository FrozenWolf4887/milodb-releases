# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from dataclasses import dataclass
from typing import TYPE_CHECKING
from milodb_common.parser.candidate_text import CandidateText
from milodb_common.parser.token import StartEnd, Token
from milodb_common.parser.token_stream import TokenStream, TokenStreamError
from milodb_common.variables.i_user_variables import IUserVariables, VARIABLE_FULL_NAME_PATTERN
if TYPE_CHECKING:
    from collections.abc import Sequence

@dataclass
class _ActiveStream:
    variable_token: Token | None
    token_stream: TokenStream
    begin_expansion_char_index: int = 0
    last_expanded_end_char_index: int = 0

@dataclass
class ExpandedToken(Token):
    topmost_token: Token
    variable_depth: int

class ExpandingTokenStream:
    def __init__(self, text: str, variables: IUserVariables, discard_delimiters: str | None = None, keep_delimiters: str | None = None, stop_before_character_index: int | None = None) -> None:
        self._variables: IUserVariables = variables
        self._stop_before_character_index: int | None = stop_before_character_index

        self._discard_delimiters: str = discard_delimiters if discard_delimiters is not None else TokenStream.DEFAULT_DISCARD_DELIMITERS
        self._keep_delimiters: str = keep_delimiters if keep_delimiters is not None else TokenStream.DEFAULT_KEEP_DELIMITERS
        self._stack_of_active_streams: list[_ActiveStream] = [_ActiveStream(None, TokenStream(text, discard_delimiters, keep_delimiters))]
        self._is_expansion_enabled = True
        self._token_number: int = 0
        self._offset_character_index: int = 0
        self._expanded_text: str = ''
        self._stopped_on_token: ExpandedToken | None = None

    def next(self) -> ExpandedToken | None:
        token: Token | None = None
        while token is None and not self._stopped_on_token and self._stack_of_active_streams:
            token = self._load_next_token()

        expanded_token: ExpandedToken | None = None
        if token:
            expanded_token = self._convert_to_expanded_token(token)
            self._token_number += 1

        return expanded_token

    def get_remaining_raw_text(self) -> str:
        text: str = ''
        active_stream: _ActiveStream

        if self._stopped_on_token:
            active_stream = self._stack_of_active_streams[-1]
            text = active_stream.token_stream.get_all_text()[active_stream.last_expanded_end_char_index:self._stopped_on_token.topmost_token.outer_indices.end]

        for active_stream in reversed(self._stack_of_active_streams):
            text += active_stream.token_stream.get_remaining_raw_text()

        return text

    def get_expanded_raw_text(self) -> str:
        return self._expanded_text

    def disable_expansion(self) -> None:
        self._is_expansion_enabled = False

    def is_expansion_enabled(self) -> bool:
        return self._is_expansion_enabled

    def get_stopped_on_token(self) -> ExpandedToken | None:
        return self._stopped_on_token

    def set_discard_delimiters(self, delimiters: str) -> None:
        active_stream: _ActiveStream
        for active_stream in self._stack_of_active_streams:
            active_stream.token_stream.set_discard_delimiters(delimiters)
        self._discard_delimiters = delimiters

    def set_keep_delimiters(self, delimiters: str) -> None:
        active_stream: _ActiveStream
        for active_stream in self._stack_of_active_streams:
            active_stream.token_stream.set_keep_delimiters(delimiters)
        self._keep_delimiters = delimiters

    def _load_next_token(self) -> Token | None:
        token: Token | None = None

        active_stream: _ActiveStream = self._stack_of_active_streams[-1]

        try:
            token = active_stream.token_stream.next()
        except TokenStreamError as ex:
            ex.fault_token = self._convert_to_expanded_token(ex.fault_token)
            raise

        if token:
            if self._should_stop_on_token(token):
                self._stopped_on_token = self._convert_to_expanded_token(token)
                token = None
            elif self._try_expand_token(token):
                self._expanded_text += active_stream.token_stream.get_all_text()[active_stream.last_expanded_end_char_index:token.outer_indices.start]
                active_stream.last_expanded_end_char_index = token.outer_indices.end
                token = None
            else:
                self._expanded_text += active_stream.token_stream.get_all_text()[active_stream.last_expanded_end_char_index:token.outer_indices.end]
                active_stream.last_expanded_end_char_index = token.outer_indices.end
        else:
            self._expanded_text += active_stream.token_stream.get_all_text()[active_stream.last_expanded_end_char_index:]
            self._pop_active_stream()

        return token

    def _should_stop_on_token(self, token: Token) -> bool:
        return self._stop_before_character_index is not None and \
            ((not token.is_delimiter and token.outer_indices.end + self._offset_character_index >= self._stop_before_character_index) or (token.is_delimiter and token.outer_indices.end + self._offset_character_index > self._stop_before_character_index))

    def _try_expand_token(self, token: Token) -> bool:
        did_expand: bool = False

        if self._is_expansion_enabled and token.text.startswith('$') and not token.text.startswith('$$'):
            if VARIABLE_FULL_NAME_PATTERN.fullmatch(token.text):
                self._check_for_recursive_variable_reference(token)
                self._handle_variable_expansion(token)
                did_expand = True
            else:
                list_of_variables: Sequence[str] = [f'${variable_name}' for variable_name in self._variables.get_list_of_names()]
                active_stream: _ActiveStream = self._stack_of_active_streams[-1]
                self._expanded_text += active_stream.token_stream.get_all_text()[active_stream.last_expanded_end_char_index:token.outer_indices.end]
                msg = f"Invalid variable reference '{token.text}' does not match pattern '{VARIABLE_FULL_NAME_PATTERN.pattern}'"
                raise TokenStreamError(
                    msg,
                    self._convert_to_expanded_token(token),
                    CandidateText.space_delimited_list(list_of_variables),
                )

        return did_expand

    def _check_for_recursive_variable_reference(self, token: Token) -> None:
        active_stream: _ActiveStream
        for active_stream in self._stack_of_active_streams:
            if active_stream.variable_token and token.text == active_stream.variable_token.text:
                variable_chain: Sequence[str] = [f"'{entry.variable_token.text}'" for entry in self._stack_of_active_streams if entry.variable_token] + [f"'{token.text}'"]
                self._expanded_text += active_stream.token_stream.get_all_text()[active_stream.last_expanded_end_char_index:token.outer_indices.end]
                msg = f"Recursive variable reference detected: {' -> '.join(variable_chain)}"
                raise TokenStreamError(
                    msg,
                    self._stack_of_active_streams[1].variable_token or token,
                )

    def _handle_variable_expansion(self, token: Token) -> None:
        variable_name: str = token.text[1:]
        variable_value: str | None = self._variables.try_retrieve(variable_name)
        if variable_value is not None:
            self._stack_of_active_streams.append(_ActiveStream(token, TokenStream(variable_value, self._discard_delimiters, self._keep_delimiters)))
            self._offset_character_index += token.outer_indices.start
            if self._stop_before_character_index is not None and self._stop_before_character_index >= token.outer_indices.start:
                self._stop_before_character_index -= (token.outer_indices.end - token.outer_indices.start)
                self._stop_before_character_index += len(variable_value)
        else:
            list_of_variables: Sequence[str] = [f'${variable_name}' for variable_name in self._variables.get_list_of_names()]
            active_stream: _ActiveStream = self._stack_of_active_streams[-1]
            self._expanded_text += active_stream.token_stream.get_all_text()[active_stream.last_expanded_end_char_index:token.outer_indices.end]
            msg = f"Unknown variable reference '${variable_name}'"
            raise TokenStreamError(
                msg,
                self._convert_to_expanded_token(token),
                CandidateText.space_delimited_list(list_of_variables),
            )

    def _pop_active_stream(self) -> None:
        active_stream: _ActiveStream = self._stack_of_active_streams[-1]

        self._offset_character_index += len(active_stream.token_stream.get_all_text())
        variable_token: Token | None = active_stream.variable_token
        if variable_token:
            self._offset_character_index -= variable_token.outer_indices.end

        self._stack_of_active_streams.pop()

    def _convert_to_expanded_token(self, token: Token) -> ExpandedToken:
        token.token_number = self._token_number
        topmost_token: Token | None = token if len(self._stack_of_active_streams) <= 1 else self._stack_of_active_streams[1].variable_token

        return ExpandedToken(
            token.text,
            self._token_number,
            StartEnd(token.outer_indices.start + self._offset_character_index, token.outer_indices.end + self._offset_character_index),
            StartEnd(token.inner_indices.start + self._offset_character_index, token.inner_indices.end + self._offset_character_index),
            token.is_delimiter,
            topmost_token or token,
            len(self._stack_of_active_streams) - 1,
        )
