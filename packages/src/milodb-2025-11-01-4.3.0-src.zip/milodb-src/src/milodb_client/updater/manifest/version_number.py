# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import re
from collections.abc import Mapping, Sequence
from typing import override
from milodb_client.updater.manifest.common_manifest import IPreRelease, IVersionNumber, PreReleaseLabel

class VersionNumberError(Exception):
    pass

class PreRelease(IPreRelease):
    def __init__(self, label: PreReleaseLabel, number: int) -> None:
        self._label: PreReleaseLabel = label
        self._number: int = number

    @property
    @override
    def label(self) -> PreReleaseLabel:
        return self._label

    @property
    @override
    def number(self) -> int:
        return self._number

    @staticmethod
    def compare(left: IPreRelease, right: IPreRelease) -> int: # pylint: disable=too-many-return-statements
        if left is right:
            return 0
        if left.label.value < right.label.value:
            return -1
        if left.label.value > right.label.value:
            return 1
        if left.number < right.number:
            return -1
        if left.number > right.number:
            return 1
        return 0

    @override
    def __str__(self) -> str:
        return f'{self.label.value}.{self.number}'

    @override
    def __hash__(self) -> int:
        return hash((self.label.value, self.number))

    @override
    def __eq__(self, other: object) -> bool:
        if isinstance(other, IPreRelease):
            return PreRelease.compare(self, other) == 0
        return False

    @override
    def __ne__(self, other: object) -> bool:
        if isinstance(other, IPreRelease):
            return PreRelease.compare(self, other) != 0
        return False

    @override
    def __lt__(self, other: IPreRelease) -> bool:
        return PreRelease.compare(self, other) < 0

    @override
    def __le__(self, other: IPreRelease) -> bool:
        return PreRelease.compare(self, other) <= 0

    @override
    def __gt__(self, other: IPreRelease) -> bool:
        return PreRelease.compare(self, other) > 0

    @override
    def __ge__(self, other: IPreRelease) -> bool:
        return PreRelease.compare(self, other) >= 0

class VersionNumber(IVersionNumber):
    def __init__(self, major: int, minor: int, patch: int, pre_release: PreRelease | None = None) -> None:
        self._major: int = major
        self._minor: int = minor
        self._patch: int = patch
        self._pre_release: PreRelease | None = pre_release

    @property
    @override
    def major(self) -> int:
        return self._major
    @property
    @override
    def minor(self) -> int:
        return self._minor
    @property
    @override
    def patch(self) -> int:
        return self._patch
    @property
    @override
    def pre_release(self) -> PreRelease | None:
        return self._pre_release

    @staticmethod
    def parse(text: str) -> IVersionNumber:
        """Parse a version number from the specified text.

        Version number format: <major>.<minor>.<patch>[-{alpha|beta|rc}.<number>]
        ### Examples:
        - "2.17.8"
        - "2.17.8-beta.4"

        ### Raises:
        - VersionNumberError
        """
        match: re.Match[str] | None = _VERSION_NUMBER_PATTERN.fullmatch(text)
        if not match:
            msg = f"'{text}' is not a Semantic Version number"
            raise VersionNumberError(msg)

        major: int = int(match.group('major'))
        minor: int = int(match.group('minor'))
        patch: int = int(match.group('patch'))
        pre_release: PreRelease | None = None
        label_text: str | None = match.group('label')
        if label_text:
            pre_release = PreRelease(_MAP_OF_PRE_RELEASE_LABELS[label_text], int(match.group('number')))

        return VersionNumber(major, minor, patch, pre_release)

    @staticmethod
    def compare(left: IVersionNumber, right: IVersionNumber) -> int: # pylint: disable=too-many-return-statements, too-complex # noqa: C901,PLR0911 ... is too complex, Too many return statements
        """Compare two version numbers.

        ### Returns:
        - (left == right) -> 0
        - (left < right) -> -1
        - (left > right) -> 1
        """
        if left is right:
            return 0
        if left.major < right.major:
            return -1
        if left.major > right.major:
            return 1
        if left.minor < right.minor:
            return -1
        if left.minor > right.minor:
            return 1
        if left.patch < right.patch:
            return -1
        if left.patch > right.patch:
            return 1
        if left.pre_release and not right.pre_release:
            return -1
        if not left.pre_release and right.pre_release:
            return 1
        if left.pre_release and right.pre_release:
            return PreRelease.compare(left.pre_release, right.pre_release)
        return 0

    @override
    def __str__(self) -> str:
        if self.pre_release:
            return f'{self.major}.{self.minor}.{self.patch}-{self.pre_release}'
        return f'{self.major}.{self.minor}.{self.patch}'

    @override
    def __hash__(self) -> int:
        return hash((self.major, self.minor, self.patch, hash(self.pre_release)))

    @override
    def __eq__(self, other: object) -> bool:
        if isinstance(other, IVersionNumber):
            return VersionNumber.compare(self, other) == 0
        return False

    @override
    def __ne__(self, other: object) -> bool:
        if isinstance(other, IVersionNumber):
            return VersionNumber.compare(self, other) != 0
        return False

    @override
    def __lt__(self, other: IVersionNumber) -> bool:
        return VersionNumber.compare(self, other) < 0

    @override
    def __le__(self, other: IVersionNumber) -> bool:
        return VersionNumber.compare(self, other) <= 0

    @override
    def __gt__(self, other: IVersionNumber) -> bool:
        return VersionNumber.compare(self, other) > 0

    @override
    def __ge__(self, other: IVersionNumber) -> bool:
        return VersionNumber.compare(self, other) >= 0

_PRE_RELEASE_LABELS: Sequence[str] = [label.value for label in PreReleaseLabel]
_MAP_OF_PRE_RELEASE_LABELS: Mapping[str, PreReleaseLabel] = {label.value: label for label in PreReleaseLabel}
_VERSION_NUMBER_PATTERN: re.Pattern[str] = re.compile(rf'(?P<major>0|[1-9]\d*)\.(?P<minor>0|[1-9]\d*)\.(?P<patch>0|[1-9]\d*)(?:-(?P<label>(?:{"|".join(_PRE_RELEASE_LABELS)}))\.(?P<number>[1-9]\d*))?')
