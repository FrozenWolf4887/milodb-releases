# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import sys
from pathlib import Path, PurePath
from typing import Any

_root_path: Path = Path(__file__).parent
if getattr(sys, 'frozen', False) and hasattr(sys, '_MEIPASS'):
    some_path: Any = sys._MEIPASS # pylint: disable=protected-access # noqa: SLF001 Private member accessed # pyright: ignore[reportAttributeAccessIssue]
    if isinstance(some_path, str):
        _root_path = Path(some_path)

def resource_path(relative_path: PurePath) -> Path:
    return _root_path/'resources'/relative_path
