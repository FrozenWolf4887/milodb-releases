# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from abc import ABC, abstractmethod
from collections.abc import Iterable
from milodb_client.query.tease_match import TeaseMatch
from milodb_common.output.print.i_printer import IPrinter

class IHtmlFileWriter(ABC):
    @abstractmethod
    def try_write_browse_file_of_text_matches(self, list_of_tease_matches: Iterable[TeaseMatch], file_printer: IPrinter, error_printer: IPrinter, icon_data_url: str) -> bool:
        pass

    @abstractmethod
    def try_write_browse_file_of_all_text(self, list_of_tease_matches: Iterable[TeaseMatch], file_printer: IPrinter, error_printer: IPrinter, icon_data_url: str) -> bool:
        pass
