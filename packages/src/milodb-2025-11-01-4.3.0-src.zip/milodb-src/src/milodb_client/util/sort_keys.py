# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from __future__ import annotations
import datetime
from abc import ABC, abstractmethod
from enum import IntEnum
from typing import TYPE_CHECKING, override
from milodb_client.database.tease import TeaseProperty
if TYPE_CHECKING:
    from milodb_client.query.tease_match import TeaseMatch

class SortCompareResult(IntEnum):
    LEFT_IS_LESS = -1
    BOTH_ARE_SAME = 0
    LEFT_IS_MORE = 1

    def invert(self) -> SortCompareResult:
        return SortCompareResult(self.value * -1)

class ISortKey(ABC):
    @abstractmethod
    def compare(self, left: TeaseMatch, right: TeaseMatch) -> SortCompareResult:
        pass

class _IntegerFieldSortKey(ISortKey):
    def __init__(self, tease_property: TeaseProperty.Int) -> None:
        self._tease_property: TeaseProperty.Int = tease_property

    @override
    def compare(self, left: TeaseMatch, right: TeaseMatch) -> SortCompareResult:
        left_value: int = self._tease_property(left.tease)
        right_value: int = self._tease_property(right.tease)
        return _diff(left_value, right_value)

class _FloatFieldSortKey(ISortKey):
    def __init__(self, tease_property: TeaseProperty.Float) -> None:
        self._tease_property: TeaseProperty.Float = tease_property

    @override
    def compare(self, left: TeaseMatch, right: TeaseMatch) -> SortCompareResult:
        left_value: float = self._tease_property(left.tease)
        right_value: float = self._tease_property(right.tease)
        return _diff(left_value, right_value)

class _StringFieldSortKey(ISortKey):
    def __init__(self, tease_property: TeaseProperty.Str) -> None:
        self._tease_property: TeaseProperty.Str = tease_property

    @override
    def compare(self, left: TeaseMatch, right: TeaseMatch) -> SortCompareResult:
        left_value: str = self._tease_property(left.tease)
        right_value: str = self._tease_property(right.tease)
        return _diff(left_value, right_value)

class _TeaseTypeSortKey(ISortKey):
    def __init__(self, tease_property: TeaseProperty.TeaseTyp) -> None:
        self._tease_property: TeaseProperty.TeaseTyp = tease_property

    @override
    def compare(self, left: TeaseMatch, right: TeaseMatch) -> SortCompareResult:
        left_value: str = self._tease_property(left.tease).value
        right_value: str = self._tease_property(right.tease).value
        return _diff(left_value, right_value)

class _DateFieldSortKey(ISortKey):
    def __init__(self, tease_property: TeaseProperty.Date) -> None:
        self._tease_property: TeaseProperty.Date = tease_property

    @override
    def compare(self, left: TeaseMatch, right: TeaseMatch) -> SortCompareResult:
        left_value: datetime.date = self._tease_property(left.tease)
        right_value: datetime.date = self._tease_property(right.tease)
        return _diff(left_value, right_value)

class _BooleanSortKey(ISortKey):
    def __init__(self, tease_property: TeaseProperty.Bool) -> None:
        self._tease_property: TeaseProperty.Bool = tease_property

    @override
    def compare(self, left: TeaseMatch, right: TeaseMatch) -> SortCompareResult:
        left_value: bool = self._tease_property(left.tease)
        right_value: bool = self._tease_property(right.tease)
        return _diff(left_value, right_value)

class _TotmTagSortKey(ISortKey):
    @override
    def compare(self, left: TeaseMatch, right: TeaseMatch) -> SortCompareResult:
        left_value: int = left.tease.totm_status.value
        right_value: int = right.tease.totm_status.value
        return _diff(left_value, right_value)

class _MatchCountSortKey(ISortKey):
    @override
    def compare(self, left: TeaseMatch, right: TeaseMatch) -> SortCompareResult:
        left_value: int = left.get_match_count()
        right_value: int = right.get_match_count()
        return _diff(left_value, right_value)

class _AuthorStatusSortKey(ISortKey):
    @override
    def compare(self, left: TeaseMatch, right: TeaseMatch) -> SortCompareResult:
        left_value: int = left.tease.author.status.value
        right_value: int = right.tease.author.status.value
        return _diff(left_value, right_value)

TEASE_ID_SORT_KEY: ISortKey = _IntegerFieldSortKey(TeaseProperty.tease_id)
TEASE_STATUS_SORT_KEY: ISortKey = _BooleanSortKey(TeaseProperty.is_deleted)
AUTHOR_ID_SORT_KEY: ISortKey = _IntegerFieldSortKey(TeaseProperty.author_id)
AUTHOR_NAME_SORT_KEY: ISortKey = _StringFieldSortKey(TeaseProperty.author_name)
AUTHOR_STATUS_SORT_KEY: ISortKey = _AuthorStatusSortKey()
DATE_SORT_KEY: ISortKey = _DateFieldSortKey(TeaseProperty.date)
TITLE_SORT_KEY: ISortKey = _StringFieldSortKey(TeaseProperty.title)
RATING_SORT_KEY: ISortKey = _FloatFieldSortKey(TeaseProperty.rating_value)
TYPE_SORT_KEY: ISortKey = _TeaseTypeSortKey(TeaseProperty.tease_type)
TOTM_SORT_KEY: ISortKey = _TotmTagSortKey()
MATCH_COUNT_SORT_KEY: ISortKey = _MatchCountSortKey()
WORDS_SORT_KEY: ISortKey = _IntegerFieldSortKey(TeaseProperty.word_count)
IMAGES_SORT_KEY: ISortKey = _IntegerFieldSortKey(TeaseProperty.count_of_images)
UNIQUE_IMAGES_SORT_KEY: ISortKey = _IntegerFieldSortKey(TeaseProperty.count_of_unique_images)
AUDIO_SORT_KEY: ISortKey = _IntegerFieldSortKey(TeaseProperty.count_of_audio)
UNIQUE_AUDIO_SORT_KEY: ISortKey = _IntegerFieldSortKey(TeaseProperty.count_of_unique_audio)

class OrderedSortKey(ISortKey):
    def __init__(self, sort_key: ISortKey, *, is_ascending: bool) -> None:
        self._sort_key: ISortKey = sort_key
        self._is_ascending: bool = is_ascending

    @property
    def original_sort_key(self) -> ISortKey:
        return self._sort_key

    @property
    def is_ascending(self) -> bool:
        return self._is_ascending

    @override
    def compare(self, left: TeaseMatch, right: TeaseMatch) -> SortCompareResult:
        compare_result: SortCompareResult = self._sort_key.compare(left, right)
        if self._is_ascending:
            return compare_result
        return compare_result.invert()

def _diff[T: int | float | str | datetime.date](left: T, right: T) -> SortCompareResult:
    if left < right: # type: ignore [operator] # False-Positive mypy 1.14.0: https://github.com/python/mypy/issues/18203
        return SortCompareResult.LEFT_IS_LESS
    if left > right: # type: ignore [operator] # False-Positive mypy 1.14.0: https://github.com/python/mypy/issues/18203
        return SortCompareResult.LEFT_IS_MORE
    return SortCompareResult.BOTH_ARE_SAME
