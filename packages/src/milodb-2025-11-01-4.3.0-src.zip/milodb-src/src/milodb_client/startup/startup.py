# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import json
import sys
import time
from collections.abc import Iterable
from dataclasses import dataclass
from pathlib import Path
import psutil
from milodb_client.startup.command_line import CommandLine, CommandLineError, parse_command_line
from milodb_client.startup.shutdown_action import IShutdownAction, RestartToCompleteUpdateAction
from milodb_client.updater.i_temp_directory import TempDirectoryError
from milodb_client.updater.manifest.i_schema_types import SchemaLoadError
from milodb_client.updater.manifest.update_sequence_schema import UpdateSequenceSchema
from milodb_client.updater.perform_update import PerformUpdateError, perform_update
from milodb_client.updater.temp_directory import TempDirectory
from milodb_client.view.i_log_display import ILogDisplay

_PID_WAIT_TIMEOUT_SECONDS: int = 10

@dataclass(kw_only=True)
class StartupResult:
    exit_code: int
    run_main_application: bool
    shutdown_action: IShutdownAction | None

def startup(list_of_args: Iterable[str], log_display: ILogDisplay) -> tuple[StartupResult, CommandLine | None]:
    try:
        command_line: CommandLine = parse_command_line(list_of_args)
    except CommandLineError as ex:
        log_display.print_fatal_and_prompt_to_continue(f'Command line error: {ex}')
        return StartupResult(exit_code=1, run_main_application=False, shutdown_action=None), None

    if (_wait_for_list_of_pids_to_end(command_line.list_of_pids_to_wait_on, _PID_WAIT_TIMEOUT_SECONDS, log_display) and
        _purge_list_of_temp_directories(command_line.list_of_temp_directories_to_purge, log_display)
    ):
        if command_line.update_from_sequence_filepath:
            return _process_perform_update(command_line.update_from_sequence_filepath, log_display), command_line

        return StartupResult(exit_code=0, run_main_application=True, shutdown_action=None), command_line

    return StartupResult(exit_code=1, run_main_application=True, shutdown_action=None), command_line

def _wait_for_list_of_pids_to_end(list_of_pids: Iterable[int], timeout_seconds: int, log_display: ILogDisplay) -> bool:
    return all(_wait_for_pid_to_end(pid, timeout_seconds, log_display) for pid in list_of_pids)

def _wait_for_pid_to_end(pid: int, timeout_seconds: int, log_display: ILogDisplay) -> bool:
    log_display.normal_printer.writeln(f'Waiting for PID {pid} to finish...')
    start_time_ns: int = time.monotonic_ns()
    while psutil.pid_exists(pid):
        time.sleep(0.5)
        elapsed_time_seconds: int = (time.monotonic_ns() - start_time_ns) // 1_000_000_000
        if elapsed_time_seconds >= timeout_seconds:
            log_display.print_fatal_and_prompt_to_continue(f"PID {pid} didn't end within {timeout_seconds} seconds")
            return False
    log_display.normal_printer.writeln(f'PID {pid} finished')
    return True

def _purge_list_of_temp_directories(list_of_directories: Iterable[Path], log_display: ILogDisplay) -> bool:
    directory: Path
    for directory in list_of_directories:
        log_display.normal_printer.writeln(f"Purge temporary directory '{directory}'")
        try:
            TempDirectory(directory).destroy()
        except TempDirectoryError as ex:
            log_display.print_warning_and_prompt_to_continue(f"Couldn't purge directory '{directory}': {ex}")
            return False
    return True

def _process_perform_update(update_sequence_filepath: Path, log_display: ILogDisplay) -> StartupResult:
    try:
        update_strategy_json: object = json.loads(update_sequence_filepath.read_bytes())
    except (OSError, json.JSONDecodeError, UnicodeDecodeError) as ex:
        log_display.print_fatal_and_prompt_to_continue(f"Loading '{update_sequence_filepath}' failed: {ex}")
        return StartupResult(exit_code=1, run_main_application=False, shutdown_action=None)

    update_sequence: UpdateSequenceSchema = UpdateSequenceSchema()
    try:
        update_sequence.load(update_strategy_json)
    except SchemaLoadError as ex:
        log_display.print_fatal_and_prompt_to_continue(f"Parsing '{update_sequence_filepath}' failed: {ex}")
        return StartupResult(exit_code=1, run_main_application=False, shutdown_action=None)

    try:
        perform_update(update_sequence, log_display.normal_printer, log_display.error_printer)
    except PerformUpdateError as ex:
        log_display.print_fatal_and_prompt_to_continue(f"Failed to perform update: {ex}")
        return StartupResult(exit_code=1, run_main_application=False, shutdown_action=None)

    shutdown_action: IShutdownAction | None = None
    if update_sequence.launch_filename:
        shutdown_action = RestartToCompleteUpdateAction(
            new_application_filepath = update_sequence.launch_filename,
            temp_application_filepath = Path(sys.executable),
            update_sequence_filepath = update_sequence_filepath,
            temp_directory = update_sequence.temp_directory,
        )
    else:
        log_display.print_warning_and_prompt_to_continue("There is no known new application that can be started")

    return StartupResult(exit_code=0, run_main_application=False, shutdown_action=shutdown_action)
