# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import tkinter as tk
import tkinter.font as tkfont
from io import BytesIO
from math import floor
from PIL import Image, ImageTk
from milodb_client.database.author import AuthorStatus
from milodb_client.database.tease import TeaseProperty, TeaseType, TotmStatus
from milodb_client.database.thumbnail_database import ThumbnailDatabase
from milodb_client.output.support import get_list_of_indexed_metadata_indices, get_list_of_metadata_indices
from milodb_client.query.tease_match import TeaseMatch
from milodb_client.view.gui.canvas_widgets import CanvasImage, CanvasPlainText, CanvasRectangle, CanvasSequenceText, CanvasStyledText, TextAlign
from milodb_client.view.gui.styled_canvas import StyledCanvas
from milodb_client.view.gui.styled_text import StyledText
from milodb_client.view.gui.text_tools import add_highlighted_text
from milodb_client.view.gui.theme import Colour, Style
from milodb_common.view.gui.image_tools import resize_image_to_fit
from milodb_common.view.gui.metrics import Padding, Size

_DEFAULT_VALUE_PADDING: Padding = Padding(4, 1, 4, 0)
_DEFAULT_BACKGROUND_HEIGHT: int = 20

_IMAGE_PADDING: Padding = Padding(6, 6, 4, 6)
_IMAGE_SIZE: Size = Size(128, 128)
_INDEX_BACKGROUND_PADDING: Padding = Padding(1, 6, 1, 1)
_INDEX_BACKGROUND_SIZE: Size = Size(50, _DEFAULT_BACKGROUND_HEIGHT)
_INDEX_VALUE_PADDING: Padding = _DEFAULT_VALUE_PADDING
_TITLE_BACKGROUND_PADDING: Padding = Padding(1, 6, 6, 1)
_TITLE_BACKGROUND_HEIGHT: int = _DEFAULT_BACKGROUND_HEIGHT
_TITLE_ICON_PADDING: Padding = Padding(_DEFAULT_VALUE_PADDING.left, 2, 2, 0)
_TITLE_VALUE_PADDING: Padding = _DEFAULT_VALUE_PADDING
_HITS_BACKGROUND_PADDING: Padding = Padding(1, 1, 1, 1)
_HITS_BACKGROUND_SIZE: Size = _INDEX_BACKGROUND_SIZE
_HITS_VALUE_PADDING: Padding = _DEFAULT_VALUE_PADDING
_DATE_BACKGROUND_PADDING: Padding = Padding(1, 1, 1, 1)
_DATE_BACKGROUND_SIZE: Size = Size(83, _DEFAULT_BACKGROUND_HEIGHT)
_DATE_VALUE_PADDING: Padding = _DEFAULT_VALUE_PADDING
_RATING_BACKGROUND_PADDING: Padding = Padding(1, 1, 1, 1)
_RATING_BACKGROUND_SIZE: Size = Size(98, _DEFAULT_BACKGROUND_HEIGHT)
_RATING_VALUE_PADDING: Padding = _DEFAULT_VALUE_PADDING
_RATING_IMAGE_PADDING: Padding = Padding(2, 2, 5, 0)
_AUTHOR_BACKGROUND_HEIGHT: int = _DEFAULT_BACKGROUND_HEIGHT
_AUTHOR_BACKGROUND_PADDING: Padding = Padding(1, 1, 6, 1)
_AUTHOR_ICON_PADDING: Padding = Padding(_DEFAULT_VALUE_PADDING.left, 2, 2, 0)
_AUTHOR_VALUE_PADDING: Padding = _DEFAULT_VALUE_PADDING
_SUMMARY_BACKGROUND_PADDING: Padding = Padding(1, 1, 6, 1)
_SUMMARY_LINE_COUNT: int = 3
_SUMMARY_BACKGROUND_HEIGHT: int = _SUMMARY_LINE_COUNT * _DEFAULT_BACKGROUND_HEIGHT
_SUMMARY_VALUE_PADDING: Padding = Padding(4, 2, 4, 0)
_SUMMARY_VALUE_LINE_COUNT: int = 3
_TAGS_BACKGROUND_PADDING: Padding = Padding(1, 1, 6, 1)
_TAGS_BACKGROUND_HEIGHT: int = _DEFAULT_BACKGROUND_HEIGHT
_TAGS_VALUE_PADDING: Padding = _DEFAULT_VALUE_PADDING
_TOTM_BACKGROUND_PADDING: Padding = Padding(1, 1, 1, 1)
_TOTM_BACKGROUND_SIZE: Size = Size(_HITS_BACKGROUND_SIZE.width, _SUMMARY_BACKGROUND_HEIGHT // 2 - _TOTM_BACKGROUND_PADDING.bottom)
_TYPE_BACKGROUND_PADDING: Padding = Padding(1, 1, 1, 1)

_HIGHLIGHT_PADDING: Padding = Padding(1, 1, 1, 2)
_TAG_HIGHLIGHT: str = 'highlight'

class TeaseCardPanel:
    HEIGHT: int = _IMAGE_PADDING.height + _IMAGE_SIZE.height

    def __init__(self, thumbnail_database: ThumbnailDatabase, tease_index: int, tease_match: TeaseMatch, left: int, top: int, width: int, canvas: StyledCanvas, font: tkfont.Font, italic_font: tkfont.Font, *, rating_filled_image: Image.Image, rating_hollow_image: Image.Image, deleted_tease_image: Image.Image, gone_author_image: Image.Image, unknown_author_image: Image.Image, totm_nominee_image: Image.Image, totm_winner_image: Image.Image, eos_image: Image.Image, flash_image: Image.Image, audio_image: Image.Image, classic_image: Image.Image, is_selected: bool) -> None:
        self._thumbnail_database: ThumbnailDatabase = thumbnail_database
        self._tease_index: int = tease_index
        self._tease_match: TeaseMatch = tease_match
        self._canvas: StyledCanvas = canvas
        self._font: tkfont.Font = font
        self._italic_font: tkfont.Font = italic_font
        self._rating_filled_image: Image.Image = rating_filled_image
        self._rating_hollow_image: Image.Image = rating_hollow_image
        self._deleted_tease_image: Image.Image = deleted_tease_image
        self._gone_author_image: Image.Image = gone_author_image
        self._unknown_author_image: Image.Image = unknown_author_image
        self._totm_winner_image: Image.Image = totm_winner_image
        self._totm_nominee_image: Image.Image = totm_nominee_image
        self._eos_image: Image.Image = eos_image
        self._flash_image: Image.Image = flash_image
        self._audio_image: Image.Image = audio_image
        self._classic_image: Image.Image = classic_image
        self._card_tag: str = f'card{tease_index}'

        self._card_background: CanvasRectangle = CanvasRectangle(
            canvas,
            left = left,
            top = top,
            width = width,
            height = TeaseCardPanel.HEIGHT,
            fill = Colour.CardPanel.SELECTED_BACK if is_selected else Colour.CardPanel.NORMAL_BACK,
            tags = self._card_tag,
        )

        self._init_thumbnail()
        self._init_index()
        self._init_title()
        self._init_hits()
        self._init_date()
        self._init_rating()
        self._init_author()
        self._init_summary()
        self._init_tags()
        self._init_totm()
        self._init_type()

    def _init_thumbnail(self) -> None:
        self._thumbnail_background: CanvasRectangle = CanvasRectangle(
            self._canvas,
            left = self._card_background.bounds.left + _IMAGE_PADDING.left,
            top = self._card_background.bounds.top + _IMAGE_PADDING.top,
            width = _IMAGE_SIZE.width,
            height = _IMAGE_SIZE.height,
            fill = Colour.CardPanel.THUMBNAIL_BACK,
            tags = self._card_tag,
        )

        self._thumbnail: CanvasImage | None = None
        self._thumbnail_placeholder: CanvasPlainText | None = None
        error_text: str | None = None

        thumbnail_data: bytes | None = self._thumbnail_database.try_get_thumbnail_data(self._tease_match.tease.thumbnail)
        if thumbnail_data:
            try:
                thumbnail_image: Image.Image
                with Image.open(BytesIO(thumbnail_data)) as thumbnail_image:
                    thumbnail_image.load()
            except OSError:
                error_text = 'Invalid'
            else:
                thumbnail_tk_image: ImageTk.PhotoImage = ImageTk.PhotoImage(resize_image_to_fit(thumbnail_image, _IMAGE_SIZE))
                self._thumbnail = CanvasImage(
                    self._canvas,
                    image = thumbnail_tk_image,
                    x = self._thumbnail_background.bounds.middle_x,
                    y = self._thumbnail_background.bounds.middle_y,
                    anchor = tk.CENTER,
                    tags = self._card_tag,
                )
        else:
            error_text = 'None'

        if error_text:
            self._thumbnail_placeholder = CanvasPlainText(
                self._canvas,
                origin_x = self._thumbnail_background.bounds.middle_x,
                origin_y = self._thumbnail_background.bounds.middle_y,
                text = f'[ {error_text} ]',
                font = self._italic_font,
                fill = Colour.CardPanel.THUMBNAIL_TEXT_PLACEHOLDER_FORE,
                anchor = tk.CENTER,
                tags = self._card_tag,
            )

    def _init_index(self) -> None:
        self._index_background: CanvasRectangle = CanvasRectangle(
            self._canvas,
            left = self._thumbnail_background.bounds.right + _IMAGE_PADDING.right + _INDEX_BACKGROUND_PADDING.left,
            top = self._card_background.bounds.top + _INDEX_BACKGROUND_PADDING.top,
            width = _INDEX_BACKGROUND_SIZE.width,
            height = _INDEX_BACKGROUND_SIZE.height,
            fill = Colour.CardPanel.VALUE_INDEX_BACK,
            tags = self._card_tag,
        )

        self._index_text: CanvasPlainText = CanvasPlainText(
            self._canvas,
            origin_x = self._index_background.bounds.right - _INDEX_VALUE_PADDING.right,
            origin_y = self._index_background.bounds.top + _INDEX_VALUE_PADDING.top,
            text = str(self._tease_index + 1),
            font = self._font,
            fill = Colour.CardPanel.VALUE_INDEX_FORE,
            anchor = tk.NE,
            tags = self._card_tag,
        )

    def _init_title(self) -> None:
        self._title_background: CanvasRectangle = CanvasRectangle(
            self._canvas,
            left = self._index_background.bounds.right +  _INDEX_BACKGROUND_PADDING.right + _TITLE_BACKGROUND_PADDING.left,
            top = self._index_background.bounds.top,
            right = self._card_background.bounds.right - _TITLE_BACKGROUND_PADDING.right,
            height = _TITLE_BACKGROUND_HEIGHT,
            fill = Colour.CardPanel.VALUE_TITLE_BACK,
            tags = self._card_tag,
        )

        left: int
        if self._tease_match.tease.is_deleted:
            self._deleted_tease_icon: CanvasImage = CanvasImage(
                self._canvas,
                image = ImageTk.PhotoImage(self._deleted_tease_image),
                x = self._title_background.bounds.left + _TITLE_ICON_PADDING.left,
                y = self._title_background.bounds.top + _TITLE_ICON_PADDING.top,
                anchor = tk.NW,
                tags = self._card_tag,
            )
            left = self._deleted_tease_icon.bounds.right + _TITLE_ICON_PADDING.right + _TITLE_VALUE_PADDING.left
        else:
            left = self._title_background.bounds.left + _TITLE_VALUE_PADDING.left

        self._title_text: CanvasSequenceText = CanvasSequenceText(
            self._canvas,
            origin_x = left,
            origin_y = self._title_background.bounds.top + _TITLE_VALUE_PADDING.top,
            text = self._tease_match.tease.title,
            font = self._font,
            align = TextAlign.LEFT,
            foreground = Colour.CardPanel.VALUE_TITLE_FORE,
            highlight_foreground = Colour.CardPanel.HIGHLIGHT_FORE,
            highlight_background = Colour.CardPanel.HIGHLIGHT_BACK,
            highlight_padding = _HIGHLIGHT_PADDING,
            list_of_indices = get_list_of_metadata_indices(TeaseProperty.title, self._tease_match.list_of_field_matches),
            tag = self._card_tag,
        )

    def _init_hits(self) -> None:
        self._hits_background: CanvasRectangle = CanvasRectangle(
            self._canvas,
            left = self._thumbnail_background.bounds.right + _IMAGE_PADDING.right + _HITS_BACKGROUND_PADDING.left,
            top = self._index_background.bounds.bottom + _INDEX_BACKGROUND_PADDING.bottom + _HITS_BACKGROUND_PADDING.top,
            width = _HITS_BACKGROUND_SIZE.width,
            height = _HITS_BACKGROUND_SIZE.height,
            fill = Colour.CardPanel.VALUE_BACK,
            tags = self._card_tag,
        )

        self._hits_text: CanvasPlainText = CanvasPlainText(
            self._canvas,
            origin_x = self._hits_background.bounds.right - _HITS_VALUE_PADDING.right,
            origin_y = self._hits_background.bounds.top + _HITS_VALUE_PADDING.top,
            text = str(self._tease_match.get_match_count()),
            font = self._font,
            fill = Colour.CardPanel.VALUE_HITS_FORE,
            anchor = tk.NE,
            tags = self._card_tag,
        )

    def _init_date(self) -> None:
        self._date_background: CanvasRectangle = CanvasRectangle(
            self._canvas,
            left = self._hits_background.bounds.right + _HITS_BACKGROUND_PADDING.right + _DATE_BACKGROUND_PADDING.left,
            top = self._hits_background.bounds.top,
            width = _DATE_BACKGROUND_SIZE.width,
            height = _DATE_BACKGROUND_SIZE.height,
            fill = Colour.CardPanel.VALUE_BACK,
            tags = self._card_tag,
        )

        self._date_text: CanvasSequenceText = CanvasSequenceText(
            self._canvas,
            origin_x = self._date_background.bounds.left + _DATE_VALUE_PADDING.right,
            origin_y = self._date_background.bounds.top + _DATE_VALUE_PADDING.top,
            text = self._tease_match.tease.date.isoformat(),
            align = TextAlign.LEFT,
            font = self._font,
            foreground = Colour.CardPanel.VALUE_DATE_FORE,
            highlight_foreground = Colour.CardPanel.HIGHLIGHT_FORE,
            highlight_background = Colour.CardPanel.HIGHLIGHT_BACK,
            highlight_padding = _HIGHLIGHT_PADDING,
            list_of_indices = get_list_of_metadata_indices(TeaseProperty.date, self._tease_match.list_of_field_matches),
            tag = self._card_tag,
        )

    def _init_rating(self) -> None:
        self._rating_background: CanvasRectangle = CanvasRectangle(
            self._canvas,
            left = self._date_background.bounds.right + _DATE_BACKGROUND_PADDING.right + _RATING_BACKGROUND_PADDING.left,
            top = self._date_background.bounds.top,
            width = _RATING_BACKGROUND_SIZE.width,
            height = _RATING_BACKGROUND_SIZE.height,
            fill = Colour.CardPanel.VALUE_BACK,
            tags = self._card_tag,
        )

        self._rating_text: CanvasSequenceText = CanvasSequenceText(
            self._canvas,
            origin_x = self._rating_background.bounds.left + _RATING_VALUE_PADDING.left,
            origin_y = self._rating_background.bounds.top + _RATING_VALUE_PADDING.top,
            text = str(self._tease_match.tease.rating_value),
            font = self._font,
            align = TextAlign.LEFT,
            foreground = Colour.CardPanel.VALUE_RATING_FORE,
            highlight_foreground = Colour.CardPanel.HIGHLIGHT_FORE,
            highlight_background = Colour.CardPanel.HIGHLIGHT_BACK,
            highlight_padding = _HIGHLIGHT_PADDING,
            list_of_indices = get_list_of_metadata_indices(TeaseProperty.rating_value, self._tease_match.list_of_field_matches),
            tag = self._card_tag,
        )

        rating_split_width: int = floor(self._rating_filled_image.width * self._tease_match.tease.rating_value / 5.0)
        rating_filled_image: Image.Image = self._rating_filled_image.crop((0, 0, rating_split_width, self._rating_filled_image.height))
        rating_hollow_image: Image.Image = self._rating_hollow_image.crop((rating_split_width, 0, self._rating_filled_image.width, self._rating_filled_image.height))

        self._rating_filled_graphic: CanvasImage = CanvasImage(
            self._canvas,
            image = ImageTk.PhotoImage(rating_filled_image),
            x = self._rating_text.bounds.right + _RATING_VALUE_PADDING.right + _RATING_IMAGE_PADDING.left,
            y = self._rating_background.bounds.top + _RATING_IMAGE_PADDING.top,
            anchor = tk.NW,
            tags = self._card_tag,
        )

        self._rating_hollow_graphic: CanvasImage = CanvasImage(
            self._canvas,
            image = ImageTk.PhotoImage(rating_hollow_image),
            x = self._rating_filled_graphic.bounds.right,
            y = self._rating_filled_graphic.bounds.top,
            anchor = tk.NW,
            tags = self._card_tag,
        )

    def _init_author(self) -> None:
        self._author_background: CanvasRectangle = CanvasRectangle(
            self._canvas,
            left = self._rating_background.bounds.right + _RATING_BACKGROUND_PADDING.right + _AUTHOR_BACKGROUND_PADDING.left,
            top = self._rating_background.bounds.top,
            right = self._card_background.bounds.right - _AUTHOR_BACKGROUND_PADDING.right,
            height = _AUTHOR_BACKGROUND_HEIGHT,
            fill = Colour.CardPanel.VALUE_BACK,
            tags = self._card_tag,
        )

        self._author_text: CanvasPlainText | CanvasSequenceText
        if self._tease_match.tease.author.status is AuthorStatus.UNKNOWN:
            self._unknown_author_icon: CanvasImage = CanvasImage(
                self._canvas,
                image = ImageTk.PhotoImage(self._unknown_author_image),
                x = self._author_background.bounds.left + _AUTHOR_ICON_PADDING.left,
                y = self._author_background.bounds.top + _AUTHOR_ICON_PADDING.top,
                anchor = tk.NW,
                tags = self._card_tag,
            )
            self._author_text = CanvasPlainText(
                self._canvas,
                origin_x = self._unknown_author_icon.bounds.right + _AUTHOR_ICON_PADDING.right + _AUTHOR_VALUE_PADDING.left,
                origin_y = self._author_background.bounds.top + _AUTHOR_VALUE_PADDING.top,
                text = 'unknown',
                font = self._italic_font,
                fill = Colour.CardPanel.VALUE_AUTHOR_UNKNOWN_FORE,
                anchor = tk.NW,
                tags = self._card_tag,
            )
        else:
            left: int = self._author_background.bounds.left + _AUTHOR_VALUE_PADDING.left
            if self._tease_match.tease.author.status is AuthorStatus.GONE:
                self._author_icon = CanvasImage(
                    self._canvas,
                    image = ImageTk.PhotoImage(self._gone_author_image),
                    x = self._author_background.bounds.left + _AUTHOR_ICON_PADDING.left,
                    y = self._author_background.bounds.top + _AUTHOR_ICON_PADDING.top,
                    anchor = tk.NW,
                    tags = self._card_tag,
                )
                left = self._author_icon.bounds.right + _AUTHOR_ICON_PADDING.right + _AUTHOR_VALUE_PADDING.left
            self._author_text = CanvasSequenceText(
                self._canvas,
                origin_x = left,
                origin_y = self._author_background.bounds.top + _AUTHOR_VALUE_PADDING.top,
                text = self._tease_match.tease.author.name,
                align = TextAlign.LEFT,
                font = self._font,
                foreground = Colour.CardPanel.VALUE_AUTHOR_FORE,
                highlight_foreground = Colour.CardPanel.HIGHLIGHT_FORE,
                highlight_background = Colour.CardPanel.HIGHLIGHT_BACK,
                highlight_padding = _HIGHLIGHT_PADDING,
                list_of_indices = get_list_of_metadata_indices(TeaseProperty.author_name, self._tease_match.list_of_field_matches),
                tag = self._card_tag,
            )

    def _init_summary(self) -> None:
        self._summary_background: CanvasRectangle = CanvasRectangle(
            self._canvas,
            left = self._date_background.bounds.left,
            top = self._date_background.bounds.bottom + _DATE_BACKGROUND_PADDING.bottom + _SUMMARY_BACKGROUND_PADDING.top,
            right = self._card_background.bounds.right - _SUMMARY_BACKGROUND_PADDING.right,
            height = _SUMMARY_BACKGROUND_HEIGHT,
            fill = Colour.CardPanel.VALUE_BACK,
            tags = self._card_tag,
        )

        summary_text: StyledText = StyledText(
            master = self._canvas,
            style = Style.OnCard.SummaryText.STYLE_NAME,
            line_count = _SUMMARY_VALUE_LINE_COUNT,
            wrap = tk.WORD,
            disable_for_scrolling = True,
        )
        summary_text.tag_config(_TAG_HIGHLIGHT, background=Colour.CardPanel.HIGHLIGHT_BACK, foreground=Colour.CardPanel.HIGHLIGHT_FORE)

        self._canvas_summary_text: CanvasStyledText = CanvasStyledText(
            canvas = self._canvas,
            text_widget = summary_text,
            origin_x = self._summary_background.bounds.left + _SUMMARY_VALUE_PADDING.left,
            origin_y = self._summary_background.bounds.top + _SUMMARY_VALUE_PADDING.top,
            width = self._summary_background.bounds.width - _SUMMARY_VALUE_PADDING.width,
        )

        summary_text.config(state=tk.NORMAL)

        add_highlighted_text(
            text_widget = summary_text,
            text = self._tease_match.tease.summary,
            list_of_indices = get_list_of_metadata_indices(TeaseProperty.summary, self._tease_match.list_of_field_matches),
            tag_highlight = _TAG_HIGHLIGHT,
        )

        summary_text.config(state=tk.DISABLED)

    def _init_tags(self) -> None:
        self._tags_background: CanvasRectangle = CanvasRectangle(
            self._canvas,
            left = self._index_background.bounds.left,
            top = self._summary_background.bounds.bottom + _SUMMARY_BACKGROUND_PADDING.bottom + _TAGS_BACKGROUND_PADDING.top,
            right = self._card_background.bounds.right - _TAGS_BACKGROUND_PADDING.right,
            height = _TAGS_BACKGROUND_HEIGHT,
            fill = Colour.CardPanel.VALUE_BACK,
            tags = self._card_tag,
        )

        tag_offset_x: int = self._tags_background.bounds.left + _TAGS_VALUE_PADDING.left
        index_of_tag: int
        name_of_tag: str
        for index_of_tag, name_of_tag in enumerate(self._tease_match.tease.list_of_tags):
            if index_of_tag != 0:
                comma_text: CanvasPlainText = CanvasPlainText(
                    self._canvas,
                    origin_x = tag_offset_x,
                    origin_y = self._tags_background.bounds.top + _TAGS_VALUE_PADDING.top,
                    text = ', ',
                    font = self._font,
                    fill = Colour.CardPanel.VALUE_TAGS_FORE,
                    anchor = tk.NW,
                    tags = self._card_tag,
                )
                tag_offset_x += comma_text.bounds.width
            tag_text: CanvasSequenceText = CanvasSequenceText(
                self._canvas,
                origin_x = tag_offset_x,
                origin_y = self._tags_background.bounds.top + _TAGS_VALUE_PADDING.top,
                text = name_of_tag,
                align = TextAlign.LEFT,
                font = self._font,
                foreground = Colour.CardPanel.VALUE_TAGS_FORE,
                highlight_foreground = Colour.CardPanel.HIGHLIGHT_FORE,
                highlight_background = Colour.CardPanel.HIGHLIGHT_BACK,
                highlight_padding = _HIGHLIGHT_PADDING,
                list_of_indices = get_list_of_indexed_metadata_indices(TeaseProperty.list_of_tags, index_of_tag, self._tease_match.list_of_field_matches),
                tag = self._card_tag,
            )
            tag_offset_x += tag_text.bounds.width

    def _init_totm(self) -> None:
        self._totm_background: CanvasRectangle = CanvasRectangle(
            self._canvas,
            left = self._hits_background.bounds.left,
            top = self._hits_background.bounds.bottom + _HITS_BACKGROUND_PADDING.bottom + _TOTM_BACKGROUND_PADDING.top,
            width = _TOTM_BACKGROUND_SIZE.width,
            height = _TOTM_BACKGROUND_SIZE.height,
            fill = Colour.CardPanel.VALUE_BACK,
            tags = self._card_tag,
        )

        totm_image: Image.Image | None
        match self._tease_match.tease.totm_status:
            case TotmStatus.WINNER:
                totm_image = self._totm_winner_image
            case TotmStatus.NOMINEE:
                totm_image = self._totm_nominee_image
            case TotmStatus.NONE:
                totm_image = None

        if totm_image:
            self._totm_icon: CanvasImage = CanvasImage(
                self._canvas,
                ImageTk.PhotoImage(totm_image),
                x = self._totm_background.bounds.middle_x,
                y = self._totm_background.bounds.middle_y,
                anchor = tk.CENTER,
                tags = self._card_tag,
            )

    def _init_type(self) -> None:
        self._type_background: CanvasRectangle = CanvasRectangle(
            self._canvas,
            left = self._totm_background.bounds.left,
            top = self._totm_background.bounds.bottom + _TOTM_BACKGROUND_PADDING.bottom + _TYPE_BACKGROUND_PADDING.top,
            width = self._totm_background.bounds.width,
            bottom = self._summary_background.bounds.bottom,
            fill = Colour.CardPanel.VALUE_BACK,
            tags = self._card_tag,
        )

        type_image: Image.Image | None
        match self._tease_match.tease.tease_type:
            case TeaseType.EOS:
                type_image = self._eos_image
            case TeaseType.NYX:
                type_image = self._flash_image
            case TeaseType.REGULAR:
                type_image = self._classic_image
            case TeaseType.AUDIO:
                type_image = self._audio_image

        if type_image:
            self._type_icon: CanvasImage = CanvasImage(
                self._canvas,
                ImageTk.PhotoImage(type_image),
                x = self._type_background.bounds.middle_x,
                y = self._type_background.bounds.middle_y,
                anchor = tk.CENTER,
                tags = self._card_tag,
            )

    def resize(self, *, width: int) -> None:
        self._card_background.resize(width = width)
        self._title_background.change(right = self._card_background.bounds.right - _TITLE_BACKGROUND_PADDING.right)
        self._author_background.change(right = self._card_background.bounds.right - _AUTHOR_BACKGROUND_PADDING.right)
        self._summary_background.change(right = self._card_background.bounds.right - _SUMMARY_BACKGROUND_PADDING.right)
        self._canvas_summary_text.resize(width = self._summary_background.bounds.width - _SUMMARY_VALUE_PADDING.width)
        self._tags_background.change(right = self._card_background.bounds.right - _TAGS_BACKGROUND_PADDING.right)

    def select(self) -> None:
        self._card_background.set_fill(Colour.CardPanel.SELECTED_BACK)

    def deselect(self) -> None:
        self._card_background.set_fill(Colour.CardPanel.NORMAL_BACK)

    def destroy(self) -> None:
        self._canvas.delete(self._card_tag)
        self._canvas_summary_text.destroy()
