# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import contextlib
import tkinter as tk
from abc import ABC, abstractmethod
from collections.abc import Callable
from enum import Enum
from tkinter import ttk
from typing import override
from PIL import ImageTk
from milodb_client.database.tease import TeaseProperty
from milodb_client.view.gui.enum_option_menu import EnumOptionMenu
from milodb_client.view.gui.text_ex import TextEx
from milodb_client.view.gui.validator import IValidator, ValidationResult

class FieldStatus(Enum):
    ACTIVE = 0
    INACTIVE = 1
    ERROR = 2

class IFieldValidator(ABC):
    @abstractmethod
    def add_callback(self, callback: Callable[['IFieldValidator'], None]) -> None:
        pass

    @abstractmethod
    def remove_callback(self, callback: Callable[['IFieldValidator'], None]) -> None:
        pass

    @property
    @abstractmethod
    def field_name(self) -> str:
        pass

    @property
    @abstractmethod
    def tease_property(self) -> TeaseProperty.Any:
        pass

    @property
    @abstractmethod
    def verb_value(self) -> str:
        pass

    @property
    @abstractmethod
    def entry_widget(self) -> TextEx:
        pass

    @property
    @abstractmethod
    def status(self) -> FieldStatus:
        pass

class FieldValidator[E: Enum](IFieldValidator):
    def __init__(self, field_name: str, tease_property: TeaseProperty.Any, icon_widget: ttk.Label, verb_widget: EnumOptionMenu[E], entry_widget: TextEx,
                 map_of_field_status_to_icon: dict[FieldStatus, ImageTk.PhotoImage], map_of_verb_validators: dict[E, IValidator]) -> None:
        self._field_name: str = field_name
        self._tease_property: TeaseProperty.Any = tease_property
        self._icon_widget: ttk.Label = icon_widget
        self._verb_widget: EnumOptionMenu[E] = verb_widget
        self._entry_widget: TextEx = entry_widget
        self._map_of_field_status_to_icon: dict[FieldStatus, ImageTk.PhotoImage] = map_of_field_status_to_icon
        self._map_of_verb_validators: dict[E, IValidator] = map_of_verb_validators
        self._list_of_callbacks: list[Callable[[FieldValidator[E]], None]] = []
        self._status: FieldStatus = FieldStatus.INACTIVE

        self._verb_widget.add_callback(self._on_verb_modified)
        self._entry_widget.bind('<<Modified>>', self._on_entry_modified)

    @override
    def add_callback(self, callback: Callable[['FieldValidator[E]'], None]) -> None:
        self._list_of_callbacks.append(callback)

    @override
    def remove_callback(self, callback: Callable[['FieldValidator[E]'], None]) -> None:
        with contextlib.suppress(ValueError):
            self._list_of_callbacks.remove(callback)

    @property
    @override
    def field_name(self) -> str:
        return self._field_name

    @property
    @override
    def tease_property(self) -> TeaseProperty.Any:
        return self._tease_property

    @property
    @override
    def verb_value(self) -> str:
        return str(self._verb_widget.enum.value)

    @property
    @override
    def entry_widget(self) -> TextEx:
        return self._entry_widget

    @property
    @override
    def status(self) -> FieldStatus:
        return self._status

    def _on_verb_modified(self, _: tk.Widget) -> None:
        self._on_modified()

    def _on_entry_modified(self, _: object) -> None:
        if self._entry_widget.edit_modified():
            self._entry_widget.edit_modified(arg=False)
            self._on_modified()

    def _on_modified(self) -> None:
        self._status = FieldStatus.INACTIVE
        validator: IValidator | None = self._map_of_verb_validators.get(self._verb_widget.enum)
        if validator is not None:
            match validator.validate():
                case ValidationResult.EMPTY:
                    self._status = FieldStatus.INACTIVE
                case ValidationResult.VALID:
                    self._status = FieldStatus.ACTIVE
                case ValidationResult.INVALID:
                    self._status = FieldStatus.ERROR

        icon: ImageTk.PhotoImage | None = self._map_of_field_status_to_icon.get(self._status)
        if icon:
            self._icon_widget.config(image=icon)
        else:
            self._icon_widget.config(image='')

        for callback in self._list_of_callbacks:
            callback(self)
