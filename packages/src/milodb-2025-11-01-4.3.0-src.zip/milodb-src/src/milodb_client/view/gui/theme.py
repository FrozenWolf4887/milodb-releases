# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from __future__ import annotations
import sys
import tkinter as tk
from pathlib import Path
from tkinter import font as tkfont, ttk
from typing import TYPE_CHECKING
from PIL import Image, ImageTk
from milodb_client.resources import resource_path
from milodb_client.view.gui import general_layout
from milodb_client.view.gui.util.singleton import RaiiSingleton
if TYPE_CHECKING:
    from collections.abc import Sequence

_LIGHTER_BY: int = 2
_DARKER_BY: int = -2
_MAP_OF_NIBBLE_TO_INT: dict[str, int] = { f'{value:X}': value for value in range(16) }

def _adjust_hex_nibble(nibble: str, adjustment: int) -> str:
    new_value: int = max(0, min(15, _MAP_OF_NIBBLE_TO_INT[nibble] + adjustment))
    return f'{new_value:X}'

def _adjust_colour(text: str, adjustment: int) -> str:
    return f'#{_adjust_hex_nibble(text[1], adjustment)}{_adjust_hex_nibble(text[2], adjustment)}{_adjust_hex_nibble(text[3], adjustment)}'

def _lighten(text: str) -> str:
    return _adjust_colour(text, _LIGHTER_BY)

def _darken(text: str) -> str:
    return _adjust_colour(text, _DARKER_BY)

_COL_WINDOW_BACK: str = '#888'
_COL_PANEL_BACK: str = '#444'
_COL_PANEL_TEXT_FORE: str = '#CCC'
_COL_HEADER_BACK: str = '#533'
_COL_HEADER_FORE: str = '#FFF'
_COL_VALUE_BACK: str = '#333'
_COL_VALUE_FORE: str = '#DDD'

class Style:
    class Generic:
        class Frame:
            STYLE_NAME: str = 'XFrame'
            COL_BACK: str = _COL_PANEL_BACK

        class PanelFrame:
            STYLE_NAME: str = 'Panel.XFrame'
            COL_BACK: str = _COL_PANEL_BACK

        class TopLevelFrame:
            STYLE_NAME: str = 'Top.XFrame'
            COL_BACK: str = _COL_WINDOW_BACK

        class LogFrame:
            STYLE_NAME: str = 'Log.XFrame'

        class HeaderFrame:
            STYLE_NAME: str = 'Header.XFrame'
            COL_BACK: str = _COL_HEADER_BACK

        class ValueFrame:
            STYLE_NAME: str = 'Value.XFrame'
            COL_BACK: str = _COL_VALUE_BACK

        class Canvas:
            STYLE_NAME: str = 'XCanvas'
            COL_BACK: str = _COL_PANEL_BACK

        class HeaderCanvas:
            STYLE_NAME: str = 'Header.XCanvas'
            COL_BACK: str = _COL_PANEL_BACK

        class TableCanvas:
            STYLE_NAME: str = 'Table.XCanvas'
            COL_BACK: str = _COL_PANEL_BACK

        class SortableHeaderCanvas:
            STYLE_NAME: str = 'Sortable.Header.XCanvas'

        class Label:
            STYLE_NAME: str = 'TLabel'
            COL_BACK: str = _COL_PANEL_BACK
            COL_FORE: str = _COL_PANEL_TEXT_FORE

        class ValueLabel:
            STYLE_NAME: str = 'Value.TLabel'
            COL_BACK: str = _COL_VALUE_BACK
            COL_FORE: str = _COL_VALUE_FORE

        class ProgressBar:
            STYLE_NAME: str = 'Horizontal.TProgressbar'
            COL_FORE: str = _COL_HEADER_FORE
            COL_BACK: str = _COL_HEADER_BACK

        class Text:
            STYLE_NAME: str = 'XText'
            COL_BACK: str = _COL_VALUE_BACK
            COL_FORE: str = '#FFF'
            COL_SELECTED_BACK: str = '#CCC'
            COL_SELECTED_FORE: str = '#000'
            COL_SELECTED_INACTIVE_BACK: str = '#AAA'
            COL_SELECTED_INACTIVE_FORE: str = '#000'
            COL_CARET: str = '#CCC'
            COL_ACTIVE_BORDER: str = '#FFF'
            COL_INACTIVE_BORDER: str = '#888'

        class Button:
            STYLE_NAME: str = 'TButton'
            COL_BORDER: str = '#9AB'
            COL_BACK: str = '#345'
            COL_FORE: str = '#FFF'
            COL_HOVER_BACK: str = _lighten(COL_BACK)
            COL_HOVER_FORE: str = COL_FORE
            COL_PRESSED_BACK: str = _lighten(COL_HOVER_BACK)
            COL_PRESSED_FORE: str = COL_FORE
            COL_DISABLED_BACK: str = '#444'
            COL_DISABLED_FORE: str = '#333'

        class WideButton:
            STYLE_NAME: str = 'Wide.TButton'

        class Notebook:
            STYLE_NAME: str = 'TNotebook'
            COL_BACK: str = '#123'
            COL_BORDER: str = '#FFF'

        class NotebookTab:
            STYLE_NAME: str = 'TNotebook.Tab'
            COL_BORDER: str = '#9AB'
            COL_ACTIVE_BACK: str = '#345'
            COL_ACTIVE_FORE: str = '#FFF'
            COL_INACTIVE_BACK: str = _darken(COL_ACTIVE_BACK)
            COL_INACTIVE_FORE: str = _darken(COL_ACTIVE_FORE)
            COL_HOVER_BACK: str = _lighten(COL_ACTIVE_BACK)
            COL_HOVER_FORE: str = COL_ACTIVE_FORE
            COL_PRESSED_BACK: str = _lighten(COL_HOVER_BACK)
            COL_PRESSED_FORE: str = COL_ACTIVE_FORE
            COL_DISABLED_BACK: str = '#444'
            COL_DISABLED_FORE: str = '#333'

        class Scrollbar:
            STYLE_NAME: str = 'TScrollbar'
            COL_BORDER: str = '#9AB'
            COL_BAR: str = '#345'
            COL_TROUGH: str = _darken(COL_BAR)
            COL_ARROW: str = '#FFF'
            COL_BAR_HOVER: str = _lighten(COL_BAR)
            COL_BAR_PRESSED: str = _lighten(COL_BAR_HOVER)

        class PanedWindow:
            STYLE_NAME: str = 'TPanedwindow'
            COL_SPLITTER: str = '#DDD'
            COL_BACKGROUND: str = _COL_PANEL_BACK

        class Checkbox:
            STYLE_NAME: str = 'TCheckbutton'
            COL_BACK: str = _COL_PANEL_BACK
            COL_FORE: str = _COL_VALUE_FORE
            COL_HOVER_BACK: str = _lighten(COL_BACK)
            COL_HOVER_FORE: str = COL_FORE
            COL_PRESSED_BACK: str = _darken(COL_HOVER_BACK)
            COL_PRESSED_FORE: str = COL_FORE
            COL_DISABLED_BACK: str = COL_BACK
            COL_DISABLED_FORE: str = '#333'

        class TableFrame:
            STYLE_NAME: str = 'Table.XFrame'
            COL_BACK: str = '#888'

    class OnDialog:
        class LogText:
            STYLE_NAME: str = 'Log.XText'
            COL_BACK: str = _COL_VALUE_BACK
            COL_FORE: str = '#DDD'

        class HeadingLabel:
            STYLE_NAME: str = 'Heading.Dialog.TLabel'
            COL_BACK: str = _COL_PANEL_BACK
            COL_FORE: str = '#FFF'

        class DetailLabel:
            STYLE_NAME: str = 'Detail.Dialog.TLabel'
            COL_BACK: str = _COL_PANEL_BACK
            COL_FORE: str = '#DDD'

        class StatusLabel:
            class Okay:
                STYLE_NAME: str = 'Okay.Status.TLabel'
                COL_FORE: str = '#FFF'
                COL_BACK: str = '#060'

            class Ready:
                STYLE_NAME: str = 'Ready.Status.TLabel'
                COL_FORE: str = '#FFF'
                COL_BACK: str = '#606'

            class Error:
                STYLE_NAME: str = 'Error.Status.TLabel'
                COL_FORE: str = '#FFF'
                COL_BACK: str = '#600'

    class InTable:
        class CellFrame:
            STYLE_NAME: str = 'Cell.Table.XFrame'
            COL_BACK: str = _COL_VALUE_BACK

        class EditableText:
            STYLE_NAME: str = 'Table.XText'
            COL_BACK: str = '#345'
            COL_FORE: str = _COL_VALUE_FORE
            COL_ACTIVE_BORDER: str = '#FFF'
            COL_INACTIVE_BORDER: str = COL_BACK

        class ReadonlyText:
            STYLE_NAME: str = 'Borderless.Table.XText'
            COL_BACK: str = _COL_VALUE_BACK
            COL_FORE: str = _COL_VALUE_FORE

        class BaseLabel:
            STYLE_NAME: str = 'Table.TLabel'

        class HeaderLabel:
            STYLE_NAME: str = 'Header.Table.TLabel'
            COL_BACK: str = '#533'
            COL_FORE: str = '#FFF'

        class ValueLabel:
            STYLE_NAME: str = 'Value.Table.TLabel'
            COL_BACK: str = _COL_VALUE_BACK
            COL_FORE: str = _COL_VALUE_FORE

        class NewValueLabel:
            STYLE_NAME: str = 'NewValue.Table.TLabel'
            COL_FORE: str = '#CFC'
            COL_BACK: str = '#141'

        class SubHeaderLabel:
            STYLE_NAME: str = 'SubHeader.Table.TLabel'
            COL_BACK: str = '#323'
            COL_FORE: str = _COL_HEADER_FORE

        class OptionMenu:
            STYLE_NAME: str = 'TMenubutton'
            COL_BORDER: str = '#9AB'
            COL_BACK: str = '#345'
            COL_FORE: str = '#FFF'
            COL_HOVER_BACK: str = _lighten(COL_BACK)
            COL_HOVER_FORE: str = COL_FORE
            COL_PRESSED_BACK: str = _lighten(COL_HOVER_BACK)
            COL_PRESSED_FORE: str = COL_FORE
            COL_DISABLED_BACK: str = '#444'
            COL_DISABLED_FORE: str = '#333'
            COL_MENU_BACK: str = COL_BACK
            COL_MENU_FORE: str = COL_FORE
            COL_MENU_HOVER_BACK: str = COL_HOVER_BACK
            COL_MENU_HOVER_FORE: str = COL_HOVER_FORE
            COL_MENU_TICK_BACK: str = COL_FORE
            PAD_X: int = 4
            PAD_Y: int = 0

        class Checkbox:
            STYLE_NAME: str = 'Table.TCheckbutton'
            COL_BACK: str = _COL_VALUE_BACK
            COL_FORE: str = _COL_VALUE_FORE
            COL_HOVER_BACK: str = _lighten(COL_BACK)
            COL_HOVER_FORE: str = COL_FORE
            COL_PRESSED_BACK: str = _lighten(COL_HOVER_BACK)
            COL_PRESSED_FORE: str = COL_FORE
            COL_DISABLED_BACK: str = COL_BACK
            COL_DISABLED_FORE: str = '#333'

    class OnCard:
        class SummaryText:
            STYLE_NAME: str = 'Summary.Card.XText'
            COL_FORE: str = '#DDD'

    class OnValueFrame:
        class Checkbox:
            STYLE_NAME: str = 'Value.TCheckbutton'
            COL_FORE: str = _COL_VALUE_FORE
            COL_BACK: str = _COL_VALUE_BACK
            COL_HOVER_BACK: str = _lighten(COL_BACK)
            COL_HOVER_FORE: str = COL_FORE
            COL_PRESSED_BACK: str = _lighten(COL_HOVER_BACK)
            COL_PRESSED_FORE: str = COL_FORE
            COL_DISABLED_BACK: str = COL_BACK
            COL_DISABLED_FORE: str = '#333'

# Reused colours

_COL_X_BANNER_FORE: str = '#DDD'
_COL_X_NORMAL_BACK: str = Style.Generic.TableFrame.COL_BACK
_COL_X_SELECTED_BACK: str = '#DD0'
_COL_X_SELECTED_FORE: str = '#000'
_COL_X_HIGHLIGHT_BACK: str = '#464'
_COL_X_HIGHLIGHT_FORE: str = '#AFA'

class Colour:
    class TopLevel:
        MAIN_WINDOW_BACK: str = _COL_WINDOW_BACK
        DIALOG_BACK: str = _COL_PANEL_BACK
        LOG_DIALOG_BACK: str = _COL_PANEL_BACK

    class LogText:
        WARNING_BACK: str = '#440'
        WARNING_FORE: str = '#FFD'
        ERROR_BACK: str = '#400'
        ERROR_FORE: str = '#FDD'
        FATAL_BACK: str = '#800'
        FATAL_FORE: str = '#FFF'

    class QueryPanel:
        ARG_FIELD_FORE: str = '#FFF'
        ARG_VERB_FORE: str = '#FF8'
        ARG_TEXT_FORE: str = '#FDF'
        ARG_REGEX_FORE: str = '#FDF'
        ARG_ENUM_FORE: str = '#FC8'
        ARG_INT_FORE: str = '#AF6'
        ARG_FLOAT_FORE: str = '#AF6'
        ARG_DATE_FORE: str = '#AF6'
        ARG_VARIABLE_FORE: str = '#CCC'
        ARG_OPERATOR_FORE: str = '#BFF'
        ERROR_BACK: str = '#844'
        ERROR_FORE: str = '#FCC'
        ERROR_SELECTED_BACK: str = '#B77'
        ERROR_SELECTED_FORE: str = '#000'
        ERROR_UNDERLINE: str = '#FCC'

    class ListPanel:
        BANNER_FORE: str = _COL_X_BANNER_FORE
        LINE: str = Style.Generic.TableFrame.COL_BACK
        ROW_BACK: str = _COL_VALUE_BACK
        HEADER_BACK: str = _COL_HEADER_BACK
        HEADER_BACK_SORT_ASCENDING: str = _darken(_COL_HEADER_BACK)
        HEADER_BACK_SORT_DESCENDING: str = _darken(_COL_HEADER_BACK)
        SELECTED_ROW_BACK: str = _COL_X_SELECTED_BACK
        SELECTED_ROW_FORE: str = _COL_X_SELECTED_FORE
        HEADER_INDEX_FORE: str = _COL_HEADER_FORE
        HEADER_HITS_FORE: str = _COL_HEADER_FORE
        HEADER_TEASEID_FORE: str = _COL_HEADER_FORE
        HEADER_TYPE_FORE: str = _COL_HEADER_FORE
        HEADER_RATING_FORE: str = _COL_HEADER_FORE
        HEADER_DATE_FORE: str = _COL_HEADER_FORE
        HEADER_TOTM_FORE: str = _COL_HEADER_FORE
        HEADER_TEASE_STATUS_FORE: str = _COL_HEADER_FORE
        HEADER_AUTHOR_STATUS_FORE: str = _COL_HEADER_FORE
        HEADER_TITLE_FORE: str = _COL_HEADER_FORE
        HEADER_AUTHOR_FORE: str = _COL_HEADER_FORE
        HEADER_AUTHORID_FORE: str = _COL_HEADER_FORE
        HEADER_IMAGE_COUNT_FORE: str = _COL_HEADER_FORE
        HEADER_UNIQUE_IMAGE_COUNT_FORE: str = _COL_HEADER_FORE
        HEADER_AUDIO_COUNT_FORE: str = _COL_HEADER_FORE
        HEADER_UNIQUE_AUDIO_COUNT_FORE: str = _COL_HEADER_FORE
        VALUE_INDEX_FORE: str = _COL_VALUE_FORE
        VALUE_HITS_FORE: str = _COL_VALUE_FORE
        VALUE_RATING_FORE: str = _COL_VALUE_FORE
        VALUE_DATE_FORE: str = _COL_VALUE_FORE
        VALUE_TITLE_FORE: str = _COL_VALUE_FORE
        VALUE_AUTHOR_FORE: str = '#FE8'
        VALUE_AUTHOR_UNKNOWN_FORE: str = '#AAA'
        VALUE_TEASEID_FORE: str = _COL_VALUE_FORE
        VALUE_AUTHORID_FORE: str =_COL_VALUE_FORE
        VALUE_WORD_COUNT_FORE: str = _COL_VALUE_FORE
        VALUE_IMAGE_COUNT_FORE: str = _COL_VALUE_FORE
        VALUE_UNIQUE_IMAGE_COUNT_FORE: str = _COL_VALUE_FORE
        VALUE_AUDIO_COUNT_FORE: str = _COL_VALUE_FORE
        VALUE_UNIQUE_AUDIO_COUNT_FORE: str = _COL_VALUE_FORE
        HIGHLIGHT_BACK: str = _COL_X_HIGHLIGHT_BACK
        HIGHLIGHT_FORE: str = _COL_X_HIGHLIGHT_FORE

    class CardPanel:
        BANNER_FORE: str = _COL_X_BANNER_FORE
        NORMAL_BACK: str = _COL_X_NORMAL_BACK
        SELECTED_BACK: str = _COL_X_SELECTED_BACK
        VALUE_BACK: str = _COL_VALUE_BACK
        VALUE_INDEX_BACK: str = '#444'
        VALUE_INDEX_FORE: str = _COL_VALUE_FORE
        VALUE_HITS_FORE: str = _COL_VALUE_FORE
        VALUE_RATING_FORE: str = _COL_VALUE_FORE
        VALUE_DATE_FORE: str = _COL_VALUE_FORE
        VALUE_TITLE_BACK: str = _COL_HEADER_BACK
        VALUE_TITLE_FORE: str = _COL_HEADER_FORE
        VALUE_AUTHOR_FORE: str = '#FE8'
        VALUE_AUTHOR_UNKNOWN_FORE: str = '#AAA'
        VALUE_TAGS_FORE: str = '#CCF'
        THUMBNAIL_BACK: str = _COL_VALUE_BACK
        THUMBNAIL_TEXT_PLACEHOLDER_FORE: str = '#AAA'
        HIGHLIGHT_BACK: str = _COL_X_HIGHLIGHT_BACK
        HIGHLIGHT_FORE: str = _COL_X_HIGHLIGHT_FORE

    class TextMatchesPanel:
        BANNER_FORE: str = _COL_X_BANNER_FORE
        NORMAL_BACK: str = _COL_X_NORMAL_BACK
        SELECTED_BACK: str = _COL_X_SELECTED_BACK
        VALUE_PAGE_FORE: str = _COL_HEADER_FORE
        VALUE_PAGE_BACK: str = _COL_HEADER_BACK
        VALUE_TEXT_BACK: str = _COL_VALUE_BACK
        HIGHLIGHT_BACK: str = _COL_X_HIGHLIGHT_BACK
        HIGHLIGHT_FORE: str = _COL_X_HIGHLIGHT_FORE
        ELLIPSIS_BACK: str = '#929'
        ELLIPSIS_FORE: str = '#F8F'

class Font:
    class Normal:
        SIZE: int = 11
        NAME: str = 'Liberation Sans'
        TUPLE: tuple[str, int] = (NAME, SIZE)

    class Bold:
        SIZE: int = 11
        NAME: str = 'Liberation Sans'
        TUPLE: tuple[str, int, str] = (NAME, SIZE, 'bold')

    class Italic:
        SIZE: int = 11
        NAME: str = 'Liberation Sans'
        TUPLE: tuple[str, int, str] = (NAME, SIZE, 'italic')

    class Edit:
        SIZE: int = 11
        NAME: str = 'Liberation Sans'
        TUPLE: tuple[str, int] = (NAME, SIZE)

    class Banner:
        SIZE: int = 14
        NAME: str = 'Liberation Sans'
        TUPLE: tuple[str, int, str] = (NAME, SIZE, 'italic')

    class Mono:
        SIZE: int = 11
        NAME: str = 'Liberation Mono'
        TUPLE: tuple[str, int] = (NAME, SIZE)

def configure_ttk_styles(master: tk.Tk) -> ttk.Style:
    _set_application_icon(master)

    style: ttk.Style = ttk.Style(master=master)
    style.theme_use('clam')
    style.configure(Style.Generic.PanedWindow.STYLE_NAME, background=Style.Generic.PanedWindow.COL_SPLITTER, foreground=Style.Generic.PanedWindow.COL_BACKGROUND)
    style.configure(Style.Generic.ProgressBar.STYLE_NAME, background=Style.Generic.ProgressBar.COL_BACK, foreground=Style.Generic.ProgressBar.COL_FORE)
    _configure_ttk_label_style(style)
    _configure_ttk_text_style(style)
    _configure_ttk_button_style(style)
    _configure_ttk_optionmenu_style(style)
    _configure_ttk_scrollbar_style(style)
    _configure_ttk_checkbutton_style(style)
    _configure_ttk_notebook_style(style)
    _configure_ttk_frame_style(style)
    _configure_ttk_canvas_style(style)
    return style

def get_font_of_themed_widget(root: tk.Misc, widget: ttk.Label | tk.Text) -> tkfont.Font:
    font_name: str = widget.cget('font')
    return tkfont.Font(root, font_name)

class _AppIcons:
    def __init__(self) -> None:
        self._list_of_images: list[Image.Image] = []
        self._list_of_photo_images: list[ImageTk.PhotoImage] = []

        image_original: Image.Image
        with Image.open(resource_path(Path('app-icon.png'))) as image_original:
            for size in (16, 24, 32, 64):
                self._list_of_images.append(image_original.resize((size, size), Image.Resampling.BICUBIC))

    def prepare_photo_images(self) -> Sequence[ImageTk.PhotoImage]:
        self._list_of_photo_images = [
            ImageTk.PhotoImage(image) for image in self._list_of_images
        ]
        return self._list_of_photo_images

_APP_ICONS_SINGLETON = RaiiSingleton(_AppIcons)

def _set_application_icon(master: tk.Tk) -> None:
    if sys.platform == 'win32':
        master.iconbitmap(resource_path(Path('app-icon.ico')))
    else:
        app_icons: _AppIcons = _APP_ICONS_SINGLETON.instance
        master.iconphoto(
            True, # noqa: FBT003 Boolean positional value in function call
            *app_icons.prepare_photo_images(),
        )

def _configure_ttk_label_style(style: ttk.Style) -> None:
    style.layout(
        Style.Generic.Label.STYLE_NAME, [ (
        'Label.padding', {
            'sticky': tk.NSEW,
            'children': [ (
                    'Label.label', {
                        'sticky': tk.NSEW,
                    },
                ),
            ],
        },
    ) ] )
    style.configure(
        Style.Generic.Label.STYLE_NAME,
        font = Font.Normal.TUPLE,
        foreground = Style.Generic.Label.COL_FORE,
        background = Style.Generic.Label.COL_BACK,
        padding = (general_layout.LABEL_PADDING_X, general_layout.LABEL_PADDING_Y),
    )
    style.configure(
        Style.Generic.ValueLabel.STYLE_NAME,
        foreground = Style.Generic.ValueLabel.COL_FORE,
        background = Style.Generic.ValueLabel.COL_BACK,
    )
    style.configure(
        Style.InTable.BaseLabel.STYLE_NAME,
        padding = (general_layout.TABLE_CELL_PADDING_X, general_layout.TABLE_CELL_PADDING_Y),
    )
    style.configure(
        Style.InTable.ValueLabel.STYLE_NAME,
        foreground = Style.InTable.ValueLabel.COL_FORE,
        background = Style.InTable.ValueLabel.COL_BACK,
    )
    style.configure(
        Style.InTable.NewValueLabel.STYLE_NAME,
        foreground = Style.InTable.NewValueLabel.COL_FORE,
        background = Style.InTable.NewValueLabel.COL_BACK,
    )
    style.configure(
        Style.InTable.HeaderLabel.STYLE_NAME,
        foreground = Style.InTable.HeaderLabel.COL_FORE,
        background = Style.InTable.HeaderLabel.COL_BACK,
    )
    style.configure(
        Style.InTable.SubHeaderLabel.STYLE_NAME,
        foreground = Style.InTable.SubHeaderLabel.COL_FORE,
        background = Style.InTable.SubHeaderLabel.COL_BACK,
    )
    style.configure(
        Style.OnDialog.StatusLabel.Okay.STYLE_NAME,
        font = Font.Normal.TUPLE,
        foreground = Style.OnDialog.StatusLabel.Okay.COL_FORE,
        background = Style.OnDialog.StatusLabel.Okay.COL_BACK,
    )
    style.configure(
        Style.OnDialog.StatusLabel.Ready.STYLE_NAME,
        font = Font.Normal.TUPLE,
        foreground = Style.OnDialog.StatusLabel.Ready.COL_FORE,
        background = Style.OnDialog.StatusLabel.Ready.COL_BACK,
    )
    style.configure(
        Style.OnDialog.StatusLabel.Error.STYLE_NAME,
        font = Font.Normal.TUPLE,
        foreground = Style.OnDialog.StatusLabel.Error.COL_FORE,
        background = Style.OnDialog.StatusLabel.Error.COL_BACK,
    )

def _configure_ttk_text_style(style: ttk.Style) -> None:
    style.configure(
        Style.Generic.Text.STYLE_NAME,
        background = Style.Generic.Text.COL_BACK,
        blockcursor = False,
        borderwidth = 0,
        cursor = "xterm",
        font = Font.Edit.TUPLE,
        foreground = Style.Generic.Text.COL_FORE,
        highlightbackground = Style.Generic.Text.COL_INACTIVE_BORDER,
        highlightcolor = Style.Generic.Text.COL_ACTIVE_BORDER,
        highlightthickness = 1,
        inactiveselectedbackground = Style.Generic.Text.COL_SELECTED_INACTIVE_BACK,
        inactiveselectedforeground = Style.Generic.Text.COL_SELECTED_INACTIVE_FORE,
        insertbackground = Style.Generic.Text.COL_CARET,
        insertborderwidth = 0,
        insertofftime = 300,
        insertontime = 600,
        insertunfocussed = 'none',
        insertwidth = 2,
        padx = general_layout.LABEL_PADDING_X,
        pady = general_layout.LABEL_PADDING_Y,
        relief = tk.SOLID,
        selectedbackground = Style.Generic.Text.COL_SELECTED_BACK,
        selectedforeground = Style.Generic.Text.COL_SELECTED_FORE,
        selectedborderwidth = 0,
    )
    style.configure(
        Style.OnDialog.LogText.STYLE_NAME,
        font = Font.Mono.TUPLE,
        background = Style.OnDialog.LogText.COL_BACK,
        foreground = Style.OnDialog.LogText.COL_FORE,
        highlightthickness = 0,
        relief = tk.FLAT,
    )
    style.configure(
        Style.OnDialog.HeadingLabel.STYLE_NAME,
        font = Font.Bold.TUPLE,
        background = Style.OnDialog.HeadingLabel.COL_BACK,
        foreground = Style.OnDialog.HeadingLabel.COL_FORE,
        highlightthickness = 0,
        relief = tk.FLAT,
    )
    style.configure(
        Style.OnDialog.DetailLabel.STYLE_NAME,
        font = Font.Normal.TUPLE,
        background = Style.OnDialog.DetailLabel.COL_BACK,
        foreground = Style.OnDialog.DetailLabel.COL_FORE,
        highlightthickness = 0,
        relief = tk.FLAT,
    )
    style.configure(
        Style.InTable.EditableText.STYLE_NAME,
        padx = general_layout.TABLE_CELL_PADDING_X,
        pady = general_layout.TABLE_CELL_PADDING_Y,
        foreground = Style.InTable.EditableText.COL_FORE,
        background = Style.InTable.EditableText.COL_BACK,
        highlightbackground = Style.InTable.EditableText.COL_INACTIVE_BORDER,
        highlightcolor = Style.InTable.EditableText.COL_ACTIVE_BORDER,
    )
    style.configure(
        Style.InTable.ReadonlyText.STYLE_NAME,
        highlightthickness = 0,
        relief = tk.FLAT,
        foreground = Style.InTable.ReadonlyText.COL_FORE,
        background = Style.InTable.ReadonlyText.COL_BACK,
    )
    style.configure(
        Style.OnCard.SummaryText.STYLE_NAME,
        font = Font.Normal.TUPLE,
        highlightthickness = 0,
        relief = tk.FLAT,
        foreground = Style.OnCard.SummaryText.COL_FORE,
        background = _COL_VALUE_BACK,
        cursor = '',
        padx = 0,
        pady = 0,
    )

def apply_text_style(widget: tk.Text, style_name: str) -> None:
    configurator: _WidgetStyleConfigurator = _WidgetStyleConfigurator(widget, style_name)
    configurator.include_attribute('background', (str,))
    configurator.include_attribute('blockcursor', (bool,), allow_empty=True)
    configurator.include_attribute('borderwidth', (int,), allow_empty=True)
    configurator.include_attribute('cursor', (str,))
    configurator.include_attribute('font', (str, tuple, tkfont.Font))
    configurator.include_attribute('foreground', (str,))
    configurator.include_attribute('highlightbackground', (str,))
    configurator.include_attribute('highlightcolor', (str,))
    configurator.include_attribute('highlightthickness', (int,), allow_empty=True)
    configurator.include_attribute('inactiveselectedbackground', (str,), arg_name='inactiveselectbackground')
    configurator.include_attribute('insertbackground', (str,))
    configurator.include_attribute('insertborderwidth', (int,), allow_empty=True)
    configurator.include_attribute('insertofftime', (int,), allow_empty=True)
    configurator.include_attribute('insertontime', (int,), allow_empty=True)
    configurator.include_attribute('insertunfocussed', (str,))
    configurator.include_attribute('insertwidth', (int,), allow_empty=True)
    configurator.include_attribute('padx', (int,), allow_empty=True)
    configurator.include_attribute('pady', (int,), allow_empty=True)
    configurator.include_attribute('relief', (str,))
    configurator.include_attribute('selectedbackground', (str,), arg_name='selectbackground')
    configurator.include_attribute('selectedborderwidth', (int,), allow_empty=True, arg_name='selectborderwidth')
    configurator.include_attribute('selectedforeground', (str,), arg_name='selectforeground')
    configurator.apply_to_widget()

def _configure_ttk_button_style(style: ttk.Style) -> None:
    style.configure(
        Style.Generic.Button.STYLE_NAME,
        font = Font.Normal.TUPLE,
        foreground = Style.Generic.Button.COL_FORE,
        background = Style.Generic.Button.COL_BACK,
        padding = (general_layout.BUTTON_PADDING_X, general_layout.BUTTON_PADDING_Y),
        relief = general_layout.BUTTON_BORDER_RELIEF,
        bordercolor = Style.Generic.Button.COL_BORDER,
    )
    style.configure(
        Style.Generic.WideButton.STYLE_NAME,
        padding = (general_layout.BUTTON_WIDE_PADDING_X, general_layout.BUTTON_WIDE_PADDING_Y),
    )
    style.map(
        Style.Generic.Button.STYLE_NAME,
        background = [ ("pressed", Style.Generic.Button.COL_PRESSED_BACK), ("active", Style.Generic.Button.COL_HOVER_BACK), ("disabled", Style.Generic.Button.COL_DISABLED_BACK) ],
        foreground = [ ("pressed", Style.Generic.Button.COL_PRESSED_FORE), ("active", Style.Generic.Button.COL_HOVER_FORE), ("disabled", Style.Generic.Button.COL_DISABLED_FORE) ],
        embossed = [ ("disabled", True) ],
    )

def _configure_ttk_optionmenu_style(style: ttk.Style) -> None:
    style.configure(
        Style.InTable.OptionMenu.STYLE_NAME,
        font = Font.Normal.TUPLE,
        foreground = Style.InTable.OptionMenu.COL_FORE,
        background = Style.InTable.OptionMenu.COL_BACK,
        arrowcolor = Style.InTable.OptionMenu.COL_FORE,
        bordercolor = Style.InTable.OptionMenu.COL_BORDER,
        borderwidth = 1,
        relief = tk.SOLID,
        padding = (Style.InTable.OptionMenu.PAD_X, Style.InTable.OptionMenu.PAD_Y),
        menu_font = Font.Normal.TUPLE,
        menu_foreground = Style.InTable.OptionMenu.COL_MENU_FORE,
        menu_background = Style.InTable.OptionMenu.COL_MENU_BACK,
        menu_activeforeground = Style.InTable.OptionMenu.COL_MENU_HOVER_FORE,
        menu_activebackground = Style.InTable.OptionMenu.COL_MENU_HOVER_BACK,
        menu_selectcolor = Style.InTable.OptionMenu.COL_MENU_TICK_BACK,
    )
    style.map(
        Style.InTable.OptionMenu.STYLE_NAME,
        background = [ ("pressed", Style.InTable.OptionMenu.COL_PRESSED_BACK), ("active", Style.InTable.OptionMenu.COL_HOVER_BACK), ("disabled", Style.InTable.OptionMenu.COL_DISABLED_BACK) ],
        foreground = [ ("pressed", Style.InTable.OptionMenu.COL_PRESSED_FORE), ("active", Style.InTable.OptionMenu.COL_HOVER_FORE), ("disabled", Style.InTable.OptionMenu.COL_DISABLED_FORE) ],
        arrowcolor = [ ("pressed", Style.InTable.OptionMenu.COL_PRESSED_FORE), ("active", Style.InTable.OptionMenu.COL_HOVER_FORE), ("disabled", Style.InTable.OptionMenu.COL_DISABLED_FORE) ],
    )

def apply_optionmenu_style(widget: ttk.OptionMenu, style_name: str) -> None:
    configurator: _WidgetStyleConfigurator = _WidgetStyleConfigurator(widget, style_name)
    configurator.include_attribute('padding', (int,int))
    configurator.apply_to_widget()

    menu_widget: tk.Widget = widget['menu']
    menu_configurator: _WidgetStyleConfigurator = _WidgetStyleConfigurator(menu_widget, style_name)
    menu_configurator.include_attribute('menu_foreground', (str,), arg_name='foreground')
    menu_configurator.include_attribute('menu_background', (str,), arg_name='background')
    menu_configurator.include_attribute('menu_activeforeground', (str,), arg_name='activeforeground')
    menu_configurator.include_attribute('menu_activebackground', (str,), arg_name='activebackground')
    menu_configurator.include_attribute('menu_selectcolor', (str,), arg_name='selectcolor')
    menu_configurator.apply_to_widget()

def _configure_ttk_scrollbar_style(style: ttk.Style) -> None:
    style.configure(
        Style.Generic.Scrollbar.STYLE_NAME,
        font = Font.Normal.TUPLE,
        background = Style.Generic.Scrollbar.COL_BAR,
        bordercolor = Style.Generic.Scrollbar.COL_BORDER,
        troughcolor = Style.Generic.Scrollbar.COL_TROUGH,
        lightcolor = Style.Generic.Scrollbar.COL_BAR,
        darkcolor = Style.Generic.Scrollbar.COL_BAR,
        arrowcolor = Style.Generic.Scrollbar.COL_ARROW,
        arrowsize = general_layout.SCROLLBAR_WIDTH,
        gripcount = 0,
    )
    style.map(
        Style.Generic.Scrollbar.STYLE_NAME,
        background = [ ("pressed", Style.Generic.Scrollbar.COL_BAR_PRESSED), ("active", Style.Generic.Scrollbar.COL_BAR_HOVER) ],
    )

def _configure_ttk_checkbutton_style(style: ttk.Style) -> None:
    style.configure(
        Style.Generic.Checkbox.STYLE_NAME,
        font = Font.Normal.TUPLE,
        foreground = Style.Generic.Checkbox.COL_FORE,
        background = Style.Generic.Checkbox.COL_BACK,
        borderwidth = 0,
        highlightthickness = 0,
    )
    style.configure(
        Style.InTable.Checkbox.STYLE_NAME,
        foreground = Style.InTable.Checkbox.COL_FORE,
        background = Style.InTable.Checkbox.COL_BACK,
        padding = (general_layout.TABLE_CELL_PADDING_X, general_layout.TABLE_CELL_PADDING_Y),
    )
    style.configure(
        Style.OnValueFrame.Checkbox.STYLE_NAME,
        foreground = Style.OnValueFrame.Checkbox.COL_FORE,
        background = Style.OnValueFrame.Checkbox.COL_BACK,
    )
    style.map(
        Style.Generic.Checkbox.STYLE_NAME,
        foreground = [ ("pressed", Style.Generic.Checkbox.COL_PRESSED_FORE), ("active", Style.Generic.Checkbox.COL_HOVER_FORE), ("disabled", Style.Generic.Checkbox.COL_DISABLED_FORE) ],
        background = [ ("pressed", Style.Generic.Checkbox.COL_PRESSED_BACK), ("active", Style.Generic.Checkbox.COL_HOVER_BACK), ("disabled", Style.Generic.Checkbox.COL_DISABLED_BACK) ],
        embossed = [ ("disabled", True) ],
    )
    style.map(
        Style.InTable.Checkbox.STYLE_NAME,
        foreground = [ ("pressed", Style.InTable.Checkbox.COL_PRESSED_FORE), ("active", Style.InTable.Checkbox.COL_HOVER_FORE), ("disabled", Style.InTable.Checkbox.COL_DISABLED_FORE) ],
        background = [ ("pressed", Style.InTable.Checkbox.COL_PRESSED_BACK), ("active", Style.InTable.Checkbox.COL_HOVER_BACK), ("disabled", Style.InTable.Checkbox.COL_DISABLED_BACK) ],
        embossed = [ ("disabled", True) ],
    )
    style.map(
        Style.OnValueFrame.Checkbox.STYLE_NAME,
        foreground = [ ("pressed", Style.OnValueFrame.Checkbox.COL_PRESSED_FORE), ("active", Style.OnValueFrame.Checkbox.COL_HOVER_FORE), ("disabled", Style.OnValueFrame.Checkbox.COL_DISABLED_FORE) ],
        background = [ ("pressed", Style.OnValueFrame.Checkbox.COL_PRESSED_BACK), ("active", Style.OnValueFrame.Checkbox.COL_HOVER_BACK), ("disabled", Style.OnValueFrame.Checkbox.COL_DISABLED_BACK) ],
        embossed = [ ("disabled", True) ],
    )

def _configure_ttk_notebook_style(style: ttk.Style) -> None:
    style.configure(
        Style.Generic.Notebook.STYLE_NAME,
        background = Style.Generic.Notebook.COL_BACK,
        bordercolor = Style.Generic.Notebook.COL_BORDER,
        darkcolor = Style.Generic.Notebook.COL_BORDER,
        lightcolor = Style.Generic.Notebook.COL_BORDER,
        relief = tk.FLAT,
    )
    style.configure(
        Style.Generic.NotebookTab.STYLE_NAME,
        font = Font.Normal.TUPLE,
        foreground = Style.Generic.NotebookTab.COL_INACTIVE_FORE,
        background = Style.Generic.NotebookTab.COL_INACTIVE_BACK,
        relief = tk.FLAT,
    )
    style.map(
        Style.Generic.NotebookTab.STYLE_NAME,
        foreground = [ ("pressed", Style.Generic.NotebookTab.COL_PRESSED_FORE), ("active", Style.Generic.NotebookTab.COL_HOVER_FORE), ("selected", Style.Generic.NotebookTab.COL_ACTIVE_FORE), ("disabled", Style.Generic.NotebookTab.COL_DISABLED_FORE) ],
        background = [ ("pressed", Style.Generic.NotebookTab.COL_PRESSED_BACK), ("active", Style.Generic.NotebookTab.COL_HOVER_BACK), ("selected", Style.Generic.NotebookTab.COL_ACTIVE_BACK), ("disabled", Style.Generic.NotebookTab.COL_DISABLED_BACK) ],
        bordercolor = [ ('', Style.Generic.NotebookTab.COL_BORDER) ],
        darkcolor = [ ('', Style.Generic.NotebookTab.COL_BORDER) ],
        lightcolor = [ ('', Style.Generic.NotebookTab.COL_BORDER) ],
        embossed = [ ("disabled", True) ],
    )

def _configure_ttk_frame_style(style: ttk.Style) -> None:
    style.configure(
        Style.Generic.Frame.STYLE_NAME,
        background = Style.Generic.Frame.COL_BACK,
        relief = tk.FLAT,
        borderwidth = 0,
    )
    style.configure(
        Style.Generic.LogFrame.STYLE_NAME,
        padx = general_layout.PANEL_PADDING_X,
        pady = general_layout.PANEL_PADDING_Y,
    )
    style.configure(
        Style.Generic.HeaderFrame.STYLE_NAME,
        background = Style.Generic.HeaderFrame.COL_BACK,
    )
    style.configure(
        Style.Generic.ValueFrame.STYLE_NAME,
        background = Style.Generic.ValueFrame.COL_BACK,
    )
    style.configure(
        Style.Generic.PanelFrame.STYLE_NAME,
        background = Style.Generic.PanelFrame.COL_BACK,
    )
    style.configure(
        Style.Generic.TopLevelFrame.STYLE_NAME,
        background = Style.Generic.TopLevelFrame.COL_BACK,
    )
    style.configure(
        Style.Generic.TableFrame.STYLE_NAME,
        background = Style.Generic.TableFrame.COL_BACK,
    )
    style.configure(
        Style.InTable.CellFrame.STYLE_NAME,
        background = Style.InTable.CellFrame.COL_BACK,
    )

def apply_frame_style(widget: tk.Frame, style_name: str) -> None:
    configurator: _WidgetStyleConfigurator = _WidgetStyleConfigurator(widget, style_name)
    configurator.include_attribute('background', (str,))
    configurator.include_attribute('borderwidth', (int,), allow_empty=True)
    configurator.include_attribute('cursor', (str,))
    configurator.include_attribute('padx', (int,), allow_empty=True)
    configurator.include_attribute('pady', (int,), allow_empty=True)
    configurator.include_attribute('relief', (str,))
    configurator.apply_to_widget()

def _configure_ttk_canvas_style(style: ttk.Style) -> None:
    style.configure(
        Style.Generic.Canvas.STYLE_NAME,
        background = Style.Generic.Canvas.COL_BACK,
        relief = tk.FLAT,
        borderwidth = 0,
        highlightthickness = 0,
    )
    style.configure(
        Style.Generic.HeaderCanvas.STYLE_NAME,
        background = Style.Generic.HeaderCanvas.COL_BACK,
    )
    style.configure(
        Style.Generic.TableCanvas.STYLE_NAME,
        background = Style.Generic.TableCanvas.COL_BACK,
    )
    style.configure(
        Style.Generic.SortableHeaderCanvas.STYLE_NAME,
        cursor = 'sb_down_arrow',
    )

def apply_canvas_style(widget: tk.Canvas, style_name: str) -> None:
    configurator: _WidgetStyleConfigurator = _WidgetStyleConfigurator(widget, style_name)
    configurator.include_attribute('background', (str,))
    configurator.include_attribute('borderwidth', (int,), allow_empty=True)
    configurator.include_attribute('cursor', (str,))
    configurator.include_attribute('highlightbackground', (str,))
    configurator.include_attribute('highlightcolor', (str,))
    configurator.include_attribute('highlightthickness', (int,), allow_empty=True)
    configurator.include_attribute('insertbackground', (str,))
    configurator.include_attribute('insertborderwidth', (int,), allow_empty=True)
    configurator.include_attribute('insertofftime', (int,), allow_empty=True)
    configurator.include_attribute('insertontime', (int,), allow_empty=True)
    configurator.include_attribute('insertwidth', (int,), allow_empty=True)
    configurator.include_attribute('padx', (int,), allow_empty=True)
    configurator.include_attribute('pady', (int,), allow_empty=True)
    configurator.include_attribute('relief', (str,))
    configurator.include_attribute('selectedborderwidth', (int,), allow_empty=True, arg_name='selectborderwidth')
    configurator.include_attribute('selectedforeground', (str,), arg_name='selectforeground')
    configurator.include_attribute('selectedbackground', (str,), arg_name='selectbackground')
    configurator.apply_to_widget()

class _WidgetStyleConfigurator:
    def __init__(self, widget: tk.Widget, style_name: str) -> None:
        self._widget: tk.Widget = widget
        self._style_name: str = style_name

        self._style: ttk.Style = ttk.Style(widget)
        self._kwargs: dict[str, object] = {}

    def include_attribute(self, name: str, list_of_types: Sequence[type], *, allow_empty: bool=False, arg_name: str | None=None, state: Sequence[str] | None=None) -> None:
        if not arg_name:
            arg_name = name
        value: object = self._style.lookup(self._style_name, name, state)
        if any(isinstance(value, possible_type) for possible_type in list_of_types) and (allow_empty or value):
            self._kwargs[arg_name] = value

    def apply_to_widget(self) -> None:
        self._widget.configure(**self._kwargs)
