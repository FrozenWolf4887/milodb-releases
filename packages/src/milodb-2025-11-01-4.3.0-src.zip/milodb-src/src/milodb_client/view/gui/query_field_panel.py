# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import tkinter as tk
from enum import Enum
from tkinter import font as tkfont, ttk
from PIL import ImageTk
from milodb_client.database.tease import TeaseProperty
from milodb_client.view.gui import generated_images
from milodb_client.view.gui.command_generator import CommandGenerator
from milodb_client.view.gui.enum_option_menu import EnumOptionMenu
from milodb_client.view.gui.field_validator import FieldStatus, FieldValidator
from milodb_client.view.gui.styled_frame import StyledFrame
from milodb_client.view.gui.text_ex import TextEx
from milodb_client.view.gui.theme import Font
from milodb_client.view.gui.validator import RegexValidator, TrueValidator

_ERROR_TAG: str = 'err'

class TextVerbs(Enum):
    MATCHES = 'matches'
    CONTAINS = 'contains'

class TagVerbs(Enum):
    MATCHES = 'matches'
    CONTAINS = 'contains'
    IS = 'is'

class QueryFieldPanel(StyledFrame):
    def __init__(self, master: tk.Misc) -> None: # pylint: disable=too-many-statements
        super().__init__(master)

        self._font: tkfont.Font = tkfont.Font(self, Font.Normal.TUPLE)
        self._text_height: int = self._font.metrics('linespace')
        ttk.Label(self, text='Title').grid(row=0, column=0, sticky=tk.W)
        ttk.Label(self, text='Summary').grid(row=1, column=0, sticky=tk.W)
        ttk.Label(self, text='Text').grid(row=2, column=0, sticky=tk.W)
        ttk.Label(self, text='Date').grid(row=3, column=0, sticky=tk.W)
        ttk.Label(self, text='Author').grid(row=4, column=0, sticky=tk.W)
        ttk.Label(self, text='Tag').grid(row=5, column=0, sticky=tk.W)
        ttk.Label(self, text='Awards').grid(row=6, column=0, sticky=tk.W)
        ttk.Label(self, text='Type').grid(row=7, column=0, sticky=tk.W)
        ttk.Label(self, text='Command').grid(row=8, column=0, sticky=tk.NW)

        field_active_image: ImageTk.PhotoImage = ImageTk.PhotoImage(generated_images.render_input_valid_image(image_height=self._text_height))
        field_inactive_image: ImageTk.PhotoImage = ImageTk.PhotoImage(generated_images.render_input_unused_image(image_height=self._text_height))
        field_invalid_image: ImageTk.PhotoImage = ImageTk.PhotoImage(generated_images.render_input_invalid_image(image_height=self._text_height))

        map_of_field_status_to_icon: dict[FieldStatus, ImageTk.PhotoImage] = {
            FieldStatus.INACTIVE: field_inactive_image,
            FieldStatus.ACTIVE: field_active_image,
            FieldStatus.ERROR: field_invalid_image,
        }

        # TITLE
        title_icon: ttk.Label = ttk.Label(self, image=field_inactive_image)
        title_icon.grid(row=0, column=1)
        title_verb: EnumOptionMenu[TextVerbs] = EnumOptionMenu(self, TextVerbs.CONTAINS, TextVerbs)
        title_verb.grid(row=0, column=2, sticky=tk.W)
        title_entry: TextEx = TextEx(self)
        title_entry.grid(row=0, column=3, sticky=tk.EW)
        title_validator: FieldValidator[TextVerbs] = FieldValidator('title', TeaseProperty.title, title_icon, title_verb, title_entry, map_of_field_status_to_icon, {
            TextVerbs.CONTAINS: TrueValidator(title_entry, _ERROR_TAG),
            TextVerbs.MATCHES: RegexValidator(title_entry, _ERROR_TAG),
        })

        # SUMMARY
        summary_icon: ttk.Label = ttk.Label(self, image=field_inactive_image)
        summary_icon.grid(row=1, column=1)
        summary_verb: EnumOptionMenu[TextVerbs] = EnumOptionMenu(self, TextVerbs.CONTAINS, TextVerbs)
        summary_verb.grid(row=1, column=2, sticky=tk.W)
        summary_entry: TextEx = TextEx(self)
        summary_entry.grid(row=1, column=3, sticky=tk.EW)
        summary_validator: FieldValidator[TextVerbs] = FieldValidator('summary', TeaseProperty.summary, summary_icon, summary_verb, summary_entry, map_of_field_status_to_icon, {
            TextVerbs.CONTAINS: TrueValidator(summary_entry, _ERROR_TAG),
            TextVerbs.MATCHES: RegexValidator(summary_entry, _ERROR_TAG),
        })

        # TEXT
        text_icon: ttk.Label = ttk.Label(self, image=field_inactive_image)
        text_icon.grid(row=2, column=1)
        text_verb: EnumOptionMenu[TextVerbs] = EnumOptionMenu(self, TextVerbs.CONTAINS, TextVerbs)
        text_verb.grid(row=2, column=2, sticky=tk.W)
        text_entry: TextEx = TextEx(self)
        text_entry.grid(row=2, column=3, sticky=tk.EW)
        text_validator: FieldValidator[TextVerbs] = FieldValidator('text', TeaseProperty.list_of_pages, text_icon, text_verb, text_entry, map_of_field_status_to_icon, {
            TextVerbs.CONTAINS: TrueValidator(text_entry, _ERROR_TAG),
            TextVerbs.MATCHES: RegexValidator(text_entry, _ERROR_TAG),
        })

        # TAG
        tag_icon: ttk.Label = ttk.Label(self, image=field_inactive_image)
        tag_icon.grid(row=5, column=1)
        tag_verb: EnumOptionMenu[TagVerbs] = EnumOptionMenu(self, TagVerbs.IS, TagVerbs)
        tag_verb.grid(row=5, column=2, sticky=tk.W)
        tag_entry: TextEx = TextEx(self)
        tag_entry.grid(row=5, column=3, sticky=tk.EW)
        tag_validator: FieldValidator[TagVerbs] = FieldValidator('tag', TeaseProperty.list_of_tags, tag_icon, tag_verb, tag_entry, map_of_field_status_to_icon, {
            TagVerbs.CONTAINS: TrueValidator(tag_entry, _ERROR_TAG),
            TagVerbs.MATCHES: RegexValidator(tag_entry, _ERROR_TAG),
            TagVerbs.IS: TrueValidator(tag_entry, _ERROR_TAG),
        })

        # COMMAND
        command_text: tk.Text = tk.Text(self, wrap=tk.WORD, state=tk.DISABLED, takefocus=True)
        command_text.grid(row=8, column=1, columnspan=3, sticky=tk.NSEW)
        command_text.bind("<1>", lambda _event: command_text.focus_set())
        CommandGenerator(command_text, [
            title_validator,
            summary_validator,
            tag_validator,
            text_validator,
        ])

        self.columnconfigure(3, weight=1)
        self.rowconfigure(8, weight=1)
