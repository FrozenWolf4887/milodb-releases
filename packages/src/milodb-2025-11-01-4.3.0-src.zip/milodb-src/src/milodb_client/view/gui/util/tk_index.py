# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from __future__ import annotations
from typing import TYPE_CHECKING, override
if TYPE_CHECKING:
    from collections.abc import Sequence

_NUMBER_OF_EMOJI_UTF16_BYTES: int = 6
_NUMBER_OF_EMOJI_CODE_POINTS: int = 2
_NUMBER_OF_NORMAL_CODE_POINTS: int = 1
_PARTS_PER_CHARACTER_INDEX: int = 2

class TkIndex:
    def __init__(self, *, row: int=1, column: int=0) -> None:
        self.row: int = row
        self.column: int = column

    def move_with_text(self, text: str) -> TkIndex:
        char: str
        for char in text:
            if char == '\n':
                self.row += 1
                self.column = 0
            elif len(char.encode('utf-16')) >= _NUMBER_OF_EMOJI_UTF16_BYTES:
                self.column += _NUMBER_OF_EMOJI_CODE_POINTS
            else:
                self.column += _NUMBER_OF_NORMAL_CODE_POINTS
        return self

    def copy(self) -> TkIndex:
        return TkIndex(row=self.row, column=self.column)

    def to_string_index(self, text: str) -> int:
        row: int = 1
        column: int = 0

        index: int = -1
        char: str
        for index, char in enumerate(text):
            if row > self.row or (row == self.row and column >= self.column):
                return index

            if char == '\n':
                if row == self.row:
                    return index
                row +=1
                column = 0
            elif len(char.encode('utf-16')) >= _NUMBER_OF_EMOJI_UTF16_BYTES:
                column += _NUMBER_OF_EMOJI_CODE_POINTS
            else:
                column += _NUMBER_OF_NORMAL_CODE_POINTS

        return index + 1

    @staticmethod
    def from_text(text: str) -> TkIndex:
        tk_index: TkIndex = TkIndex()
        tk_index.move_with_text(text)
        return tk_index

    @staticmethod
    def try_parse_str_index(index: str) -> TkIndex | None:
        parts: Sequence[str] = index.split('.')
        if len(parts) == _PARTS_PER_CHARACTER_INDEX:
            try:
                row = int(parts[0])
                column = int(parts[1])
            except ValueError:
                return None
            if row < 1 or column < 0:
                return None
            return TkIndex(row=row, column=column)
        return None

    @classmethod
    def parse_str_index_or_default(cls, index: str | None) -> TkIndex:
        return cls.try_parse_str_index(index) or TkIndex() if index else TkIndex()

    @override
    def __str__(self) -> str:
        return f'{self.row}.{self.column}'
