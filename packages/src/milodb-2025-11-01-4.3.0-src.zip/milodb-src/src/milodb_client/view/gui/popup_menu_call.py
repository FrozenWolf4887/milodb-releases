# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import tkinter as tk
from enum import Enum
from typing import Protocol
from milodb_client.database.tease_page import TeasePage
from milodb_client.query.tease_match import TeaseMatch

class PopupOrigin(Enum):
    LIST_ROW = 0
    TEASE_CARD = 1

class PopupTeaseMenuCallback(Protocol):
    def __call__(self, parent: tk.Misc, x_root: int, y_root: int, tease_match: TeaseMatch, popup_origin: PopupOrigin) -> None:
        pass

class PopupPageMenuCallback(Protocol):
    def __call__(self, parent: tk.Misc, x_root: int, y_root: int, tease_match: TeaseMatch, tease_page: TeasePage | None, *, has_matching_pages: bool) -> None:
        pass
