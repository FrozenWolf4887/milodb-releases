# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import tkinter as tk
from milodb_client.view.gui import tk_type
from milodb_client.view.gui.theme import Style, apply_frame_style

class StyledFrame(tk.Frame):
    def __init__(
            self, master: tk.Misc,
            style: str = Style.Generic.Frame.STYLE_NAME,
            *,
            height: tk_type.ScreenUnits = 0,
            width: tk_type.ScreenUnits = 0,
        ) -> None:
        super().__init__(
            master,
            height = height,
            width = width,
        )

        self._style_name: str = style
        self._change_theme_event_id: str | None = None

        apply_frame_style(self, self._style_name)
        self.bind('<<ThemeChanged>>', self._on_theme_changed)

    def _on_theme_changed(self, _event: object) -> None:
        if self._change_theme_event_id is None:
            self._change_theme_event_id = self.after_idle(self._on_idle_update_theme)

    def _on_idle_update_theme(self) -> None:
        self._change_theme_event_id = None
        apply_frame_style(self, self._style_name)
