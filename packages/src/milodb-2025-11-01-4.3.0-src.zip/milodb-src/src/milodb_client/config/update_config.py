# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from pathlib import Path
from milodb_client.config.config_schema import CONFIG_SCHEMA
from milodb_common.config.framework import IConfig

class UpdateConfig:
    def __init__(self, config: IConfig) -> None:
        self._config = config

    @property
    def backup_directory(self) -> Path:
        return Path(CONFIG_SCHEMA.update.backup_directory.fetch_value_or_default(self._config))

    @property
    def update_directory_url(self) -> str:
        return CONFIG_SCHEMA.update.update_directory_url.fetch_value_or_default(self._config)
