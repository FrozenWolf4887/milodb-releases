# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import datetime
from abc import ABC, abstractmethod
from collections.abc import Callable
from typing import override
from milodb_client.database.tease import TeaseProperty
from milodb_client.query.field_predicate import IFieldAuthorStatusPredicate, IFieldDatePredicate, IFieldFloatPredicate, IFieldIntPredicate, IFieldPageListPredicate, IFieldStatusPredicate, IFieldStrListPredicate, IFieldStrPredicate, IFieldTotmPredicate, IFieldTypePredicate
from milodb_client.query.query import IQuery
from milodb_common.parser.expanding_token_stream import ExpandingTokenStream
from milodb_common.types.partial_date import PartialDate

class IFieldVerb(ABC):
    @abstractmethod
    def create_query(self, token_stream: ExpandingTokenStream) -> IQuery:
        pass

class FieldFloatVerb(IFieldVerb):
    def __init__(self, tease_property: TeaseProperty.Float, field_predicate: type[IFieldFloatPredicate], compare_func: Callable[[float, float], bool]) -> None:
        self._tease_property: TeaseProperty.Float = tease_property
        self._field_predicate: type[IFieldFloatPredicate] = field_predicate
        self._compare_func: Callable[[float, float], bool] = compare_func

    @override
    def create_query(self, token_stream: ExpandingTokenStream) -> IQuery:
        return self._field_predicate(self._tease_property, token_stream, self._compare_func)

class FieldIntVerb(IFieldVerb):
    def __init__(self, tease_property: TeaseProperty.Int, field_predicate: type[IFieldIntPredicate], compare_func: Callable[[int, int], bool]) -> None:
        self._tease_property: TeaseProperty.Int = tease_property
        self._field_predicate = field_predicate
        self._compare_func: Callable[[int, int], bool] = compare_func

    @override
    def create_query(self, token_stream: ExpandingTokenStream) -> IQuery:
        return self._field_predicate(self._tease_property, token_stream, self._compare_func)

class FieldStrVerb(IFieldVerb):
    def __init__(self, tease_property: TeaseProperty.Str, field_predicate: type[IFieldStrPredicate]) -> None:
        self._tease_property: TeaseProperty.Str = tease_property
        self._field_predicate: type[IFieldStrPredicate] = field_predicate

    @override
    def create_query(self, token_stream: ExpandingTokenStream) -> IQuery:
        return self._field_predicate(self._tease_property, token_stream)

class FieldStrListVerb(IFieldVerb):
    def __init__(self, tease_property: TeaseProperty.StrList, field_predicate: type[IFieldStrListPredicate]) -> None:
        self._tease_property: TeaseProperty.StrList = tease_property
        self._field_predicate: type[IFieldStrListPredicate] = field_predicate

    @override
    def create_query(self, token_stream: ExpandingTokenStream) -> IQuery:
        return self._field_predicate(self._tease_property, token_stream)

class FieldTypeVerb(IFieldVerb):
    def __init__(self, tease_property: TeaseProperty.TeaseTyp, field_predicate: type[IFieldTypePredicate]) -> None:
        self._tease_property: TeaseProperty.TeaseTyp = tease_property
        self._field_predicate: type[IFieldTypePredicate] = field_predicate

    @override
    def create_query(self, token_stream: ExpandingTokenStream) -> IQuery:
        return self._field_predicate(self._tease_property, token_stream)

class FieldDateVerb(IFieldVerb):
    def __init__(self, tease_property: TeaseProperty.Date, field_predicate: type[IFieldDatePredicate], compare_func: Callable[[datetime.date, PartialDate], bool]) -> None:
        self._tease_property: TeaseProperty.Date = tease_property
        self._field_predicate: type[IFieldDatePredicate] = field_predicate
        self._compare_func: Callable[[datetime.date, PartialDate], bool] = compare_func

    @override
    def create_query(self, token_stream: ExpandingTokenStream) -> IQuery:
        return self._field_predicate(self._tease_property, token_stream, self._compare_func)

class FieldTotmVerb(IFieldVerb):
    def __init__(self, field_predicate: type[IFieldTotmPredicate]) -> None:
        self._field_predicate: type[IFieldTotmPredicate] = field_predicate

    @override
    def create_query(self, token_stream: ExpandingTokenStream) -> IQuery:
        return self._field_predicate(token_stream)

class FieldStatusVerb(IFieldVerb):
    def __init__(self, field_predicate: type[IFieldStatusPredicate]) -> None:
        self._field_predicate: type[IFieldStatusPredicate] = field_predicate

    @override
    def create_query(self, token_stream: ExpandingTokenStream) -> IQuery:
        return self._field_predicate(token_stream)

class FieldAuthorStatusVerb(IFieldVerb):
    def __init__(self, field_predicate: type[IFieldAuthorStatusPredicate]) -> None:
        self._field_predicate: type[IFieldAuthorStatusPredicate] = field_predicate

    @override
    def create_query(self, token_stream: ExpandingTokenStream) -> IQuery:
        return self._field_predicate(token_stream)

class FieldPageListVerb(IFieldVerb):
    def __init__(self, field_predicate: type[IFieldPageListPredicate]) -> None:
        self._field_predicate: type[IFieldPageListPredicate] = field_predicate

    @override
    def create_query(self, token_stream: ExpandingTokenStream) -> IQuery:
        return self._field_predicate(token_stream)
