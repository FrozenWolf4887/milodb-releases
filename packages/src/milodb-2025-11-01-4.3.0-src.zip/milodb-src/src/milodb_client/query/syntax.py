# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import operator
from collections.abc import Mapping, Sequence, Set as AbstractSet
from milodb_client.database.tease import TeaseProperty
from milodb_client.query.boolean_operator import And, Not, Or
from milodb_client.query.field_comparators import FieldAuthorStatusIs, FieldDateCompare, FieldPageListContains, FieldPageListMatches, FieldStatusIs, FieldStrContains, FieldStrIs, FieldStrListContains, FieldStrListIs, FieldStrListMatches, FieldStrMatches, FieldTotmIs, FieldTypeIs, FieldUnsignedFloatCompare, FieldUnsignedIntCompare
from milodb_client.query.field_verb import FieldAuthorStatusVerb, FieldDateVerb, FieldFloatVerb, FieldIntVerb, FieldPageListVerb, FieldStatusVerb, FieldStrListVerb, FieldStrVerb, FieldTotmVerb, FieldTypeVerb, IFieldVerb
from milodb_client.query.query import IQuery
from milodb_common.types.partial_date import PartialDate

MAP_OF_TEASE_FIELDNAME_TO_VERBS: Mapping[str, Mapping[str, IFieldVerb]] = {
    'teaseId': {
        '=': FieldIntVerb(TeaseProperty.tease_id, FieldUnsignedIntCompare, operator.eq),
        '>': FieldIntVerb(TeaseProperty.tease_id, FieldUnsignedIntCompare, operator.gt),
        '<': FieldIntVerb(TeaseProperty.tease_id, FieldUnsignedIntCompare, operator.lt),
        '>=': FieldIntVerb(TeaseProperty.tease_id, FieldUnsignedIntCompare, operator.ge),
        '<=': FieldIntVerb(TeaseProperty.tease_id, FieldUnsignedIntCompare, operator.le),
    },
    'authorId': {
        '=': FieldIntVerb(TeaseProperty.author_id, FieldUnsignedIntCompare, operator.eq),
        '>': FieldIntVerb(TeaseProperty.author_id, FieldUnsignedIntCompare, operator.gt),
        '<': FieldIntVerb(TeaseProperty.author_id, FieldUnsignedIntCompare, operator.lt),
        '>=': FieldIntVerb(TeaseProperty.author_id, FieldUnsignedIntCompare, operator.ge),
        '<=': FieldIntVerb(TeaseProperty.author_id, FieldUnsignedIntCompare, operator.le),
    },
    'type': {
        'is': FieldTypeVerb(TeaseProperty.tease_type, FieldTypeIs),
    },
    'title': {
        'is': FieldStrVerb(TeaseProperty.title, FieldStrIs),
        'contains': FieldStrVerb(TeaseProperty.title, FieldStrContains),
        'matches': FieldStrVerb(TeaseProperty.title, FieldStrMatches),
    },
    'summary': {
        'is': FieldStrVerb(TeaseProperty.summary, FieldStrIs),
        'contains': FieldStrVerb(TeaseProperty.summary, FieldStrContains),
        'matches': FieldStrVerb(TeaseProperty.summary, FieldStrMatches),
    },
    'author': {
        'is': FieldStrVerb(TeaseProperty.author_name, FieldStrIs),
        'contains': FieldStrVerb(TeaseProperty.author_name, FieldStrContains),
        'matches': FieldStrVerb(TeaseProperty.author_name, FieldStrMatches),
    },
    'tag': {
        'is': FieldStrListVerb(TeaseProperty.list_of_tags, FieldStrListIs),
        'contains': FieldStrListVerb(TeaseProperty.list_of_tags, FieldStrListContains),
        'matches': FieldStrListVerb(TeaseProperty.list_of_tags, FieldStrListMatches),
    },
    'date': {
        '=': FieldDateVerb(TeaseProperty.date, FieldDateCompare, PartialDate.is_eq),
        '>': FieldDateVerb(TeaseProperty.date, FieldDateCompare, PartialDate.is_gt),
        '<': FieldDateVerb(TeaseProperty.date, FieldDateCompare, PartialDate.is_lt),
        '>=': FieldDateVerb(TeaseProperty.date, FieldDateCompare, PartialDate.is_ge),
        '<=': FieldDateVerb(TeaseProperty.date, FieldDateCompare, PartialDate.is_le),
    },
    'rating': {
        '=': FieldFloatVerb(TeaseProperty.rating_value, FieldUnsignedFloatCompare, operator.eq),
        '>': FieldFloatVerb(TeaseProperty.rating_value, FieldUnsignedFloatCompare, operator.gt),
        '<': FieldFloatVerb(TeaseProperty.rating_value, FieldUnsignedFloatCompare, operator.lt),
        '>=': FieldFloatVerb(TeaseProperty.rating_value, FieldUnsignedFloatCompare, operator.ge),
        '<=': FieldFloatVerb(TeaseProperty.rating_value, FieldUnsignedFloatCompare, operator.le),
    },
    'text': {
        'contains': FieldPageListVerb(FieldPageListContains),
        'matches': FieldPageListVerb(FieldPageListMatches),
    },
    'totm': {
        'is': FieldTotmVerb(FieldTotmIs),
    },
    'status': {
        'is': FieldStatusVerb(FieldStatusIs),
    },
    'authorStatus': {
        'is': FieldAuthorStatusVerb(FieldAuthorStatusIs),
    },
}

MAP_OF_BINARY_OPERATORS_TO_QUERY_CLASS: Mapping[str, type[IQuery]] = {
    'and': And,
    'or': Or,
}

MAP_OF_UNARY_OPERATORS_TO_QUERY_CLASS: Mapping[str, type[IQuery]] = {
    'not': Not,
}

LIST_OF_FIELD_NAMES: Sequence[str] = sorted(MAP_OF_TEASE_FIELDNAME_TO_VERBS)
SET_OF_VERB_NAMES: AbstractSet[str] = { verb for verb_dictionary in MAP_OF_TEASE_FIELDNAME_TO_VERBS.values() for verb in verb_dictionary }
LIST_OF_VERB_NAMES: Sequence[str] = sorted(SET_OF_VERB_NAMES)
LIST_OF_OPERATORS: Sequence[str] = sorted(list(MAP_OF_BINARY_OPERATORS_TO_QUERY_CLASS) + list(MAP_OF_UNARY_OPERATORS_TO_QUERY_CLASS) + ['(', ')'])
