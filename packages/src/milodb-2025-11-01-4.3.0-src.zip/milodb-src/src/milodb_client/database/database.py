# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import datetime
import json
import lzma
from collections.abc import Iterable, Mapping, Sequence
from pathlib import Path
from milodb_client.database.author import Author
from milodb_client.database.tease import Tease, TeaseLoadError, load_tease
from milodb_client.output.print_timed_activity import PrintTimedActivity
from milodb_common.output.print.i_printer import IPrinter

_DATABASE_FORMAT_KEY: str = 'fmt'
_DATABASE_FORMAT_VALUE: int = 6
_DATABASE_AUTHORS_KEY: str = 'ats'
_DATABASE_TEASES_KEY: str = 'tss'

def load_teases_from_database_file(database_filepath: Path, normal_printer: IPrinter, error_printer: IPrinter) -> list[Tease]:
    with PrintTimedActivity(normal_printer, 'Load database\n', 'Load completed: '):
        try:
            return _load_from_file(database_filepath, normal_printer)
        except _LoadError as ex:
            error_printer.writeln(str(ex))
        return []

def try_get_oldest_tease_date(list_of_teases: Iterable[Tease]) -> datetime.date | None:
    if list_of_teases:
        return min(tease.date for tease in list_of_teases)
    return None

def try_get_newest_tease_date(list_of_teases: Iterable[Tease]) -> datetime.date | None:
    if list_of_teases:
        return max(tease.date for tease in list_of_teases)
    return None

def try_get_tease(tease_id: int, list_of_teases: Iterable[Tease]) -> Tease | None:
    tease: Tease
    for tease in list_of_teases:
        if tease_id == tease.tease_id:
            return tease
    return None

def get_teases_by_author_id(author_id: int, list_of_teases: Iterable[Tease]) -> Sequence[Tease]:
    return [ tease for tease in list_of_teases if author_id == tease.author.author_id ]

class _LoadError(Exception):
    pass

def _load_from_file(database_filepath: Path, normal_printer: IPrinter) -> list[Tease]:
    raw_file_contents: bytes = _read_file(database_filepath, normal_printer)
    file_contents: bytes = _unpack_contents(raw_file_contents, normal_printer)
    json_dict: Mapping[object, object] = _parse_json(file_contents, normal_printer)
    _check_format(json_dict)
    map_of_json_authors: Mapping[object, object] = _get_json_map_of_authors(json_dict)
    map_of_json_teases: Mapping[object, object] = _get_json_map_of_teases(json_dict)
    return _build_tease_list(map_of_json_authors, map_of_json_teases, normal_printer)

def _read_file(database_filepath: Path, normal_printer: IPrinter) -> bytes:
    with PrintTimedActivity(normal_printer, '  Read', '     : '):
        try:
            return database_filepath.read_bytes()
        except OSError as ex:
            msg = f"File access error: {ex}"
            raise _LoadError(msg) from ex

def _unpack_contents(raw_file_contents: bytes, normal_printer: IPrinter) -> bytes:
    with PrintTimedActivity(normal_printer, '  Unpack', '   : '):
        try:
            return lzma.decompress(raw_file_contents)
        except lzma.LZMAError as ex:
            msg = f"Unpack failed: {ex}"
            raise _LoadError(msg) from ex

def _parse_json(file_contents: bytes, normal_printer: IPrinter) -> Mapping[object, object]:
    with PrintTimedActivity(normal_printer, '  Parse', '    : '):
        try:
            json_root: object = json.loads(file_contents)
        except json.JSONDecodeError as ex:
            msg = f"JSON decode error: {ex}"
            raise _LoadError(msg) from ex

        if not isinstance(json_root, Mapping):
            msg = 'Database root is not a dictionary'
            raise _LoadError(msg)

        return json_root

def _check_format(json_dict: Mapping[object, object]) -> None:
    raw_format: object = json_dict.get(_DATABASE_FORMAT_KEY)
    if raw_format is None:
        msg = f"Database format key '{_DATABASE_FORMAT_KEY}' missing"
        raise _LoadError(msg)
    if not isinstance(raw_format, int):
        msg = f"Database format key value '{_DATABASE_FORMAT_KEY}' is not an integer"
        raise _LoadError(msg)
    if raw_format != _DATABASE_FORMAT_VALUE:
        msg = f"Database has format '{raw_format}' which is not the expected format '{_DATABASE_FORMAT_VALUE}'"
        raise _LoadError(msg)

def _get_json_map_of_authors(json_dict: Mapping[object, object]) -> dict[object, object]:
    json_list: object = json_dict.get(_DATABASE_AUTHORS_KEY)
    if json_list is None:
        msg = f"Database authors key '{_DATABASE_AUTHORS_KEY}' missing"
        raise _LoadError(msg)
    if not isinstance(json_list, dict):
        msg = f"Database authors key value '{_DATABASE_AUTHORS_KEY}' is not a dictionary"
        raise _LoadError(msg)
    return json_list

def _get_json_map_of_teases(json_dict: Mapping[object, object]) -> dict[object, object]:
    json_list: object = json_dict.get(_DATABASE_TEASES_KEY)
    if json_list is None:
        msg = f"Database teases key '{_DATABASE_TEASES_KEY}' missing"
        raise _LoadError(msg)
    if not isinstance(json_list, dict):
        msg = f"Database teases key value '{_DATABASE_TEASES_KEY}' is not a dictionary"
        raise _LoadError(msg)
    return json_list

def _build_tease_list(map_of_json_authors: Mapping[object, object], map_of_json_teases: Mapping[object, object], normal_printer: IPrinter) -> list[Tease]:
    with PrintTimedActivity(normal_printer, '  Assemble', ' : '):
        map_of_author_id_to_author: dict[int, Author] = _deserialise_authors(map_of_json_authors)
        map_of_tease_id_to_tease: dict[int, Tease] = _deserialise_teases(map_of_json_teases, map_of_author_id_to_author)
        return list(map_of_tease_id_to_tease.values())

def _deserialise_authors(map_of_json_authors: Mapping[object, object]) -> dict[int, Author]:
    map_of_author_id_to_author: dict[int, Author] = {}

    raw_author_id: object
    author_obj: object
    for raw_author_id, author_obj in map_of_json_authors.items():
        author_id: int = _get_key_as_author_id(raw_author_id)

        if not isinstance(author_obj, Mapping):
            msg = f"Database author object @{author_id} is not a dictionary"
            raise _LoadError(msg)

        try:
            author: Author = Author(author_id, author_obj)
        except Author.LoadError as ex:
            msg = f"Author load error: {ex}"
            raise _LoadError(msg) from ex

        map_of_author_id_to_author[author_id] = author

    return map_of_author_id_to_author

def _deserialise_teases(map_of_json_teases: Mapping[object, object], map_of_author_id_to_author: Mapping[int, Author]) -> dict[int, Tease]:
    map_of_tease_id_to_tease: dict[int, Tease] = {}

    raw_tease_id: object
    tease_obj: object
    for raw_tease_id, tease_obj in map_of_json_teases.items():
        tease_id: int = _get_key_as_tease_id(raw_tease_id)

        if not isinstance(tease_obj, Mapping):
            msg = f"Database tease object #{tease_id} is not a dictionary"
            raise _LoadError(msg)

        try:
            tease: Tease = load_tease(tease_id, tease_obj, map_of_author_id_to_author)
        except TeaseLoadError as ex:
            msg = f"Tease load error: {ex}"
            raise _LoadError(msg) from ex

        map_of_tease_id_to_tease[tease_id] = tease

    return map_of_tease_id_to_tease

def _get_key_as_author_id(raw_id: object) -> int:
    try:
        author_id: int = _get_key_as_id(raw_id)
    except _IdError as ex:
        msg = ex.get_message('authorId')
        raise _LoadError(msg) from ex

    if author_id < 0:
        msg = f"Out of range authorId '{author_id}'"
        raise _LoadError(msg)

    return author_id

def _get_key_as_tease_id(raw_id: object) -> int:
    try:
        tease_id: int = _get_key_as_id(raw_id)
    except _IdError as ex:
        msg = ex.get_message('teaseId')
        raise _LoadError(msg) from ex

    if tease_id < 1:
        msg = f"Out of range teaseId '{tease_id}'"
        raise _LoadError(msg)

    return tease_id

class _IdError(Exception):
    def get_message(self, name_of_id: str) -> str:
        return str(self).replace('%', name_of_id)

def _get_key_as_id(raw_id: object) -> int:
    """Decode the id integer from the raw_id.

    ### Raises
    - _IdError
    """
    identifier: int

    if isinstance(raw_id, int):
        identifier = raw_id
    elif isinstance(raw_id, str):
        try:
            identifier = int(raw_id)
        except ValueError as ex:
            msg = f"Invalid % value '{raw_id}'"
            raise _IdError(msg) from ex
    else:
        msg = f"Unexpected % type of '{type(raw_id).__name__}'"
        raise _IdError(msg)

    return identifier
