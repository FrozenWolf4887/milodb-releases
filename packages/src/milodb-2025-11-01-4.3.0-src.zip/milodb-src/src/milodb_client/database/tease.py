# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from __future__ import annotations
import datetime
from collections.abc import Callable, Mapping, Sequence
from enum import Enum
from typing import NamedTuple, TYPE_CHECKING
from milodb_client.database.author import AuthorStatus
from milodb_client.database.metadata_getter import MetadataGetter
from milodb_client.database.tease_page import TeasePage
if TYPE_CHECKING:
    from milodb_client.database.author import Author

class TeaseType(Enum):
    REGULAR = 'reg'
    AUDIO = 'aud'
    NYX = 'nyx'
    EOS = 'eos'

class TotmStatus(Enum):
    NONE = 0
    NOMINEE = 1
    WINNER = 2

class TeaseLoadError(Exception):
    pass

class Tease(NamedTuple):
    tease_id: int
    author: Author
    has_author: bool
    tease_type: TeaseType
    title: str
    summary: str
    thumbnail: str
    list_of_tags: Sequence[str]
    date: datetime.date
    rating_value: float
    totm_status: TotmStatus
    list_of_pages: Sequence[TeasePage]
    count_of_images: int
    count_of_unique_images: int
    count_of_audio: int
    count_of_unique_audio: int
    word_count: int
    is_deleted: bool

class TeaseProperty:
    type Str = Callable[[Tease], str]
    type Int = Callable[[Tease], int]
    type Float = Callable[[Tease], float]
    type Bool = Callable[[Tease], bool]
    type TeaseTyp = Callable[[Tease], TeaseType]
    type AuthorStat = Callable[[Tease], AuthorStatus]
    type Date = Callable[[Tease], datetime.date]
    type Totm = Callable[[Tease], TotmStatus]
    type StrList = Callable[[Tease], Sequence[str]]
    type PageList = Callable[[Tease], Sequence[TeasePage]]

    type AnyType = str | int | float | bool | TeaseType | AuthorStatus | datetime.date | TotmStatus | Sequence[str] | Sequence[TeasePage]
    type Any = Callable[[Tease], AnyType]

    @staticmethod
    def tease_id(tease: Tease) -> int:
        return tease.tease_id
    @staticmethod
    def author_id(tease: Tease) -> int:
        return tease.author.author_id
    @staticmethod
    def has_author(tease: Tease) -> bool:
        return tease.has_author
    @staticmethod
    def author_name(tease: Tease) -> str:
        return tease.author.name
    @staticmethod
    def author_status(tease: Tease) -> AuthorStatus:
        return tease.author.status
    @staticmethod
    def tease_type(tease: Tease) -> TeaseType:
        return tease.tease_type
    @staticmethod
    def title(tease: Tease) -> str:
        return tease.title
    @staticmethod
    def summary(tease: Tease) -> str:
        return tease.summary
    @staticmethod
    def thumbnail(tease: Tease) -> str:
        return tease.thumbnail
    @staticmethod
    def list_of_tags(tease: Tease) -> Sequence[str]:
        return tease.list_of_tags
    @staticmethod
    def date(tease: Tease) -> datetime.date:
        return tease.date
    @staticmethod
    def rating_value(tease: Tease) -> float:
        return tease.rating_value
    @staticmethod
    def totm_status(tease: Tease) -> TotmStatus:
        return tease.totm_status
    @staticmethod
    def list_of_pages(tease: Tease) -> Sequence[TeasePage]:
        return tease.list_of_pages
    @staticmethod
    def count_of_images(tease: Tease) -> int:
        return tease.count_of_images
    @staticmethod
    def count_of_unique_images(tease: Tease) -> int:
        return tease.count_of_unique_images
    @staticmethod
    def count_of_audio(tease: Tease) -> int:
        return tease.count_of_audio
    @staticmethod
    def count_of_unique_audio(tease: Tease) -> int:
        return tease.count_of_unique_audio
    @staticmethod
    def word_count(tease: Tease) -> int:
        return tease.word_count
    @staticmethod
    def is_deleted(tease: Tease) -> bool:
        return tease.is_deleted

def load_tease(tease_id: int, metadata: Mapping[object, object], map_of_author_id_to_author: Mapping[int, Author]) -> Tease:
    """Create a Tease object from JSON metadata.

    ### Raises
    - TeaseLoadError
    """
    getter: MetadataGetter = MetadataGetter(metadata, TeaseLoadError)
    author_id: int = getter.get_int(_KEY_AUTHOR_ID, min_value=0, max_value=None, default_value_if_none=0)
    try:
        author: Author = map_of_author_id_to_author[author_id]
    except KeyError as ex:
        msg = f'Unknown authorId @{author_id}'
        raise TeaseLoadError(msg) from ex

    raw_tags: str = getter.get_str_or_blank(_KEY_TAGS)
    list_of_tags = [tag for tag in raw_tags.split(':') if tag]
    totm_status: TotmStatus = TotmStatus.NONE
    if _TAG_TOTM_NOMINEE in list_of_tags:
        totm_status = TotmStatus.NOMINEE
    if _TAG_TOTM_WINNER in list_of_tags:
        totm_status = TotmStatus.WINNER

    return Tease(
        tease_id = tease_id,
        author = author,
        has_author = bool(author.author_id),
        tease_type = getter.get_dict_value(_KEY_TEASE_TYPE, lambda key: getter.get_int(key, min_value=None, max_value=None, default_value_if_none=None), _MAP_OF_RAW_TYPE_TO_COOKED_TYPE),
        title = getter.get_str_or_blank(_KEY_TITLE),
        summary = getter.get_str_or_blank(_KEY_SUMMARY),
        thumbnail = getter.get_str_or_blank(_KEY_THUMBNAIL),
        list_of_tags = list_of_tags,
        date = getter.get_date(_KEY_DATE),
        rating_value = getter.get_float(_KEY_RATING, min_value=0.0, max_value=5.0, default_value_if_none=0.0),
        totm_status = totm_status,
        list_of_pages = _load_list_of_pages(_KEY_PAGES, getter),
        count_of_images = getter.get_int(_KEY_IMAGE_COUNT, min_value=0, max_value=None, default_value_if_none=0),
        count_of_unique_images = getter.get_int(_KEY_UNIQUE_IMAGE_COUNT, min_value=0, max_value=None, default_value_if_none=0),
        count_of_audio = getter.get_int(_KEY_AUDIO_COUNT, min_value=0, max_value=None, default_value_if_none=0),
        count_of_unique_audio = getter.get_int(_KEY_UNIQUE_AUDIO_COUNT, min_value=0, max_value=None, default_value_if_none=0),
        word_count = getter.get_int(_KEY_WORD_COUNT, min_value=0, max_value=None, default_value_if_none=0),
        is_deleted = getter.get_bool_or_default(_KEY_DELETED, default=False),
    )

def get_text_of_tease_property(value: TeaseProperty.AnyType) -> str:
    str_value: str
    match value:
        case bool():
            str_value = str(value)
        case str():
            str_value = value
        case float():
            str_value = str(value)
        case int():
            str_value = str(value)
        case TeaseType():
            str_value = value.value
        case AuthorStatus():
            str_value = value.name
        case datetime.date():
            str_value = value.isoformat()
        case TotmStatus():
            str_value = value.name
        case Sequence():
            str_value = ''
    return str_value

def _load_list_of_pages(key: str, getter: MetadataGetter) -> Sequence[TeasePage]:
    list_of_pages: list[TeasePage] = []

    list_of_pages_json: Sequence[Mapping[object, object]] = getter.get_dict_list_or_empty(key)

    page_json: Mapping[object, object]
    for page_json in list_of_pages_json:
        page_getter: MetadataGetter = getter.sub_metadata(page_json)
        page_ref: str = page_getter.get_str(_KEY_PAGE_REF)
        page_text: str = page_getter.get_str(_KEY_PAGE_TEXT)
        list_of_pages.append(TeasePage(page_ref, page_text))

    return list_of_pages

_KEY_AUTHOR_ID: str = 'aid'
_KEY_TEASE_TYPE: str = 'typ'
_KEY_TITLE: str = 'ttl'
_KEY_SUMMARY: str = 'sum'
_KEY_THUMBNAIL: str = 'thm'
_KEY_TAGS: str = 'tgs'
_KEY_DATE: str = 'dat'
_KEY_RATING: str = 'rvl'
_KEY_PAGES: str = 'pgs'
_KEY_PAGE_REF: str = 'ref'
_KEY_PAGE_TEXT: str = 'txt'
_KEY_IMAGE_COUNT: str = 'imr'
_KEY_UNIQUE_IMAGE_COUNT: str = 'imu'
_KEY_AUDIO_COUNT: str = 'aur'
_KEY_UNIQUE_AUDIO_COUNT: str = 'auu'
_KEY_DELETED: str = 'del'
_KEY_WORD_COUNT: str = 'wds'
_TAG_TOTM_WINNER: str = 'totm'
_TAG_TOTM_NOMINEE: str = 'totm-nominee'

_MAP_OF_RAW_TYPE_TO_COOKED_TYPE: Mapping[int, TeaseType] = {
    0: TeaseType.REGULAR,
    1: TeaseType.NYX,
    2: TeaseType.EOS,
    3: TeaseType.AUDIO,
}
