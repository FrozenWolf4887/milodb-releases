# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0

from dataclasses import dataclass

class Argument:
    NO_AUTOEXEC: str = '-n'
    WAIT_PID: str = '--wait-pid'
    PERFORM_UPDATE: str = '--perform-update'
    PURGE_TEMP_DIRECTORY: str = '--purge-temp-dir'

@dataclass
class CommandLine:
    list_of_pids_to_wait_on: list[int]
    list_of_temp_directories_to_purge: list[str]
    update_from_sequence_filepath: str | None
    autoexec: bool

def try_parse_command_line(list_of_args: list[str]) -> CommandLine | None: # NOSONAR
    list_of_pids_to_wait_on: list[int] = []
    list_of_temp_directories_to_purge: list[str] = []
    update_from_sequence_filepath: str | None = None
    autoexec: bool = True

    while list_of_args:
        arg: str = list_of_args.pop(0)
        match arg:
            case Argument.WAIT_PID:
                if not list_of_args:
                    print(f"Fatal: Command line argument '{arg}' missing parameter")
                    break
                pid_text: str = list_of_args.pop(0)
                try:
                    list_of_pids_to_wait_on.append(int(pid_text))
                except ValueError:
                    print(f"Fatal: Command line argument '{arg}' specified with invalid PID parameter '{pid_text}'")
                    break
            case Argument.PURGE_TEMP_DIRECTORY:
                if not list_of_args:
                    print(f"Fatal: Command line argument '{arg}' missing parameter")
                    break
                list_of_temp_directories_to_purge.append(list_of_args.pop(0))
            case Argument.PERFORM_UPDATE:
                if not list_of_args:
                    print(f"Fatal: Command line argument '{arg}' missing parameter")
                    break
                if update_from_sequence_filepath:
                    print(f"Fatal: Command line argument '{arg}' has already been specified")
                    break
                update_from_sequence_filepath = list_of_args.pop(0)
            case Argument.NO_AUTOEXEC:
                autoexec = False
            case _:
                print(f"Fatal: Command line argument '{arg}' is unknown")
                break
    else:
        return CommandLine(
            list_of_pids_to_wait_on,
            list_of_temp_directories_to_purge,
            update_from_sequence_filepath,
            autoexec)

    return None
