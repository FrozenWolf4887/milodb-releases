# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
import os
import subprocess
import sys
from abc import ABC, abstractmethod
from pathlib import Path
from milodb_client.startup.command_line import Argument

class IShutdownAction(ABC):
    @abstractmethod
    def perform_action(self) -> int:
        pass

class RestartToPerformUpdateAction(IShutdownAction):
    def __init__(self, *, temp_application_filepath: Path, update_sequence_filepath: Path) -> None:
        self._temp_application_filepath: Path = temp_application_filepath
        self._update_sequence_filepath: Path = update_sequence_filepath

    def perform_action(self) -> int:
        print('Restarting application to perform update...')
        return _launch(self._temp_application_filepath, [
            Argument.PERFORM_UPDATE, self._update_sequence_filepath])

class RestartToCompleteUpdateAction(IShutdownAction):
    def __init__(self, *, new_application_filepath: Path, temp_application_filepath: Path, update_sequence_filepath: Path, temp_directory: Path) -> None:
        self._new_application_filepath: Path = new_application_filepath
        self._temp_application_filepath: Path = temp_application_filepath
        self._update_sequence_filepath: Path = update_sequence_filepath
        self._temp_directory: Path = temp_directory

    def perform_action(self) -> int:
        print('Restarting application to complete update...')
        return _launch(self._new_application_filepath, [Argument.PURGE_TEMP_DIRECTORY, self._temp_directory])

def _launch(application_filepath: Path, command_line: list[str | Path]) -> int:
    try:
        if sys.platform == 'win32':
            print(f"Launching win32 '{application_filepath}'")
            subprocess.Popen([application_filepath, Argument.WAIT_PID, str(os.getpid())] + command_line, start_new_session=True, creationflags=subprocess.CREATE_NEW_CONSOLE) # pylint: disable=consider-using-with
        else:
            print(f"Launching POSIX '{application_filepath}'")
            os.execv(application_filepath, (application_filepath,) + tuple(command_line))
    except OSError as ex:
        print(f'Fatal: Failed to start application: {ex}')
        return 1

    return 0
