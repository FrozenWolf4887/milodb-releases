# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
import time
from milodb_client.updater.i_guid_generator import IGuidGenerator

class TimeGuidGenerator(IGuidGenerator):
    _guid_offset: int = 0

    def create_guid(self) -> int:
        guid: int = time.time_ns() + self._guid_offset
        self._guid_offset += 1
        return guid
