# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
import datetime
from collections.abc import Callable
from typing import Any, Generic, TypeVar
from milodb_client.updater.manifest.i_schema_types import IGroup, IItem, IKey, IKeyCreator, ITypedItem, ITypedKey, KeyParseError, SchemaLoadError

_BaseKeyT = TypeVar('_BaseKeyT')
_BaseItemT = TypeVar('_BaseItemT')
_ItemT = TypeVar('_ItemT', bound='IItem')

class Item(IItem):
    def __init__(self, parent: IGroup | None, key: IKey | str) -> None:
        self._parent: IGroup | None = parent
        self._key: IKey = TextKey(key) if isinstance(key, str) else key
        if parent:
            parent.add_child(self)

    @property
    def parent(self) -> IGroup | None:
        return self._parent

    @property
    def key(self) -> IKey:
        return self._key

    @property
    def full_path(self) -> str:
        if self._parent is not None:
            parent_path: str = self._parent.full_path
            if parent_path:
                return f'{parent_path}/{self._key.name}'
        return self._key.name

class StaticGroup(Item, IGroup):
    def __init__(self, parent: IGroup | None, key: IKey | str) -> None:
        super().__init__(parent, key)
        self._map_of_key_to_child: dict[IKey, IItem] = {}

    @property
    def is_mandatory(self) -> bool:
        return True

    def add_child(self, child: IItem) -> None:
        self._map_of_key_to_child[child.key] = child

    def load(self, value: Any) -> None:
        if not isinstance(value, dict):
            raise SchemaLoadError(f"Key '{self.full_path}' value is not a group")

        set_of_child_keys: set[str] = set()
        child_key_name: Any
        child_value: Any
        for child_key_name, child_value in value.items():
            if not isinstance(child_key_name, str):
                raise SchemaLoadError(f"Key '{self._path_of_key(child_key_name)}' is not text")
            if not child_key_name:
                raise SchemaLoadError(f"Key '{self.full_path}/' is blank")
            child: IItem | None = self._find_child_of_key(child_key_name)
            if child is None:
                raise SchemaLoadError(f"Key '{self._path_of_key(child_key_name)}' is unknown")
            child.load(child_value)
            set_of_child_keys.add(child_key_name)

        set_of_mandatory_child_keys: set[str] = { key.name for key, child in self._map_of_key_to_child.items() if child.is_mandatory }
        missing_child_key: str
        for missing_child_key in set_of_mandatory_child_keys.difference(set_of_child_keys):
            raise SchemaLoadError(f"Key '{self._path_of_key(missing_child_key)}' is missing")

    def save(self) -> Any:
        map_of_key_name_to_child_value: dict[str, Any] = {}
        key: IKey
        child: IItem
        for key, child in self._map_of_key_to_child.items():
            child_value: Any = child.save()
            if child_value is not None or child.is_mandatory:
                map_of_key_name_to_child_value[key.name] = child_value
        return map_of_key_name_to_child_value

    def _find_child_of_key(self, key_name: str) -> IItem | None:
        key: IKey
        child: IItem
        for key, child in self._map_of_key_to_child.items():
            if key.name == key_name:
                return child
        return None

    def _path_of_key(self, key: str) -> str:
        this_path: str = self.full_path
        if this_path:
            return f'{this_path}/{key}'
        return key

class DynamicGroup(Item, Generic[_BaseKeyT, _ItemT], IGroup):
    def __init__(self, parent: IGroup | None, key: IKey | str, key_creator: IKeyCreator[_BaseKeyT], child_creator_delegate: Callable[[IGroup, ITypedKey[_BaseKeyT]], _ItemT]) -> None:
        super().__init__(parent, key)
        self._key_creator: IKeyCreator[_BaseKeyT] = key_creator
        self._child_creator_delegate: Callable[[IGroup, ITypedKey[_BaseKeyT]], _ItemT] = child_creator_delegate
        self._map_of_key_to_child: dict[ITypedKey[_BaseKeyT], _ItemT] = {}

    @property
    def is_mandatory(self) -> bool:
        return True

    def add_child(self, child: IItem) -> None:
        """Children are added as they are loaded to maintain type coherence"""

    def load(self, value: Any) -> None:
        if not isinstance(value, dict):
            raise SchemaLoadError(f"Key '{self.full_path}' value is not a group")

        child_key_name: Any
        child_value: Any
        for child_key_name, child_value in value.items():
            if not isinstance(child_key_name, str):
                raise SchemaLoadError(f"Key '{self.full_path}/{child_key_name}' is not text")
            if not child_key_name:
                raise SchemaLoadError(f"Key '{self.full_path}/' is blank")
            try:
                child_key: ITypedKey[_BaseKeyT] = self._key_creator.parse(child_key_name)
            except KeyParseError as ex:
                raise SchemaLoadError(f"Key '{self.full_path}/{child_key_name}': {ex}") from ex

            child: _ItemT = self._child_creator_delegate(self, child_key)
            child.load(child_value)
            self._map_of_key_to_child[child_key] = child

    def save(self) -> Any:
        return {
            key.name: child.save() for key, child in self._map_of_key_to_child.items()
        }

    def get(self) -> dict[ITypedKey[_BaseKeyT], _ItemT]:
        return self._map_of_key_to_child

    def get_key(self, key_value: _BaseKeyT) -> _ItemT | None:
        child_key: ITypedKey[_BaseKeyT]
        child_value: _ItemT
        for child_key, child_value in self._map_of_key_to_child.items():
            if child_key.get_key_value() == key_value:
                return child_value
        return None

    def add_key(self, key_value: _BaseKeyT) -> _ItemT:
        item: _ItemT | None = self.get_key(key_value)
        if item:
            return item
        child_key = self._key_creator.from_base_type(key_value)
        self._child_creator_delegate(self, child_key)
        child: _ItemT = self._child_creator_delegate(self, child_key)
        self._map_of_key_to_child[child_key] = child
        return child

class ListGroup(Item, Generic[_BaseItemT], IGroup):
    def __init__(self, parent: IGroup | None, key: IKey | str, child_creator_delegate: Callable[[IGroup, IKey], ITypedItem[_BaseItemT]]) -> None:
        super().__init__(parent, key)
        self._child_creator_delegate: Callable[[IGroup, IKey], ITypedItem[_BaseItemT]] = child_creator_delegate
        self._list_of_children: list[ITypedItem[_BaseItemT]] = []

    @property
    def is_mandatory(self) -> bool:
        return True

    def add_child(self, child: IItem) -> None:
        """Children are added as they are loaded to maintain type coherence"""

    def load(self, value: Any) -> None:
        if not isinstance(value, list):
            raise SchemaLoadError(f"Key '{self.full_path}' value is not a list")

        child_value: Any
        for child_value in value:
            child: ITypedItem[_BaseItemT] = self._child_creator_delegate(self, self.key)
            child.load(child_value)
            self._list_of_children.append(child)

    def save(self) -> Any:
        return [
            child.save() for child in self._list_of_children
        ]

    def get(self) -> list[ITypedItem[_BaseItemT]]:
        return self._list_of_children

    def add_item(self) -> _BaseItemT:
        child: ITypedItem[_BaseItemT] = self._child_creator_delegate(self, self.key)
        self._list_of_children.append(child)
        return child.get_item_value()

class TextItem(Item, ITypedItem[str]):
    def __init__(self, parent: IGroup | None, key: IKey | str) -> None:
        super().__init__(parent, key)
        self._value: str = ''

    @property
    def is_mandatory(self) -> bool:
        return True

    def __str__(self) -> str:
        return self._value

    def load(self, value: Any) -> None:
        if not isinstance(value, str):
            raise SchemaLoadError(f"Key '{self.full_path}' value is not text")
        if not value:
            raise SchemaLoadError(f"Key '{self.full_path}' value is blank")
        self._value = value

    def save(self) -> Any:
        return self._value

    def get_item_value(self) -> str:
        return self._value

    def set(self, value: str) -> None:
        self._value = value

class IntegerItem(Item, ITypedItem[int]):
    def __init__(self, parent: IGroup | None, key: IKey | str) -> None:
        super().__init__(parent, key)
        self._value: int = 0

    @property
    def is_mandatory(self) -> bool:
        return True

    def __str__(self) -> str:
        return str(self._value)

    def load(self, value: Any) -> None:
        if not isinstance(value, int):
            raise SchemaLoadError(f"Key '{self.full_path}' value is not an integer")
        self._value = value

    def save(self) -> Any:
        return self._value

    def get_item_value(self) -> int:
        return self._value

    def set(self, value: int) -> None:
        self._value = value

class DateItem(Item, ITypedItem[datetime.date]):
    def __init__(self, parent: IGroup | None, key: IKey | str) -> None:
        super().__init__(parent, key)
        self._value: datetime.date = datetime.date.min

    @property
    def is_mandatory(self) -> bool:
        return True

    def __str__(self) -> str:
        return self._value.isoformat()

    def load(self, value: Any) -> None:
        if not isinstance(value, str):
            raise SchemaLoadError(f"Key '{self.full_path}' value is not text")
        if not value:
            raise SchemaLoadError(f"Key '{self.full_path}' value is blank")
        try:
            self._value = datetime.date.fromisoformat(value)
        except ValueError as ex:
            raise SchemaLoadError(f"Key '{self.full_path}' value '{value}' is not an ISO date") from ex

    def save(self) -> Any:
        return self._value.isoformat()

    def get_item_value(self) -> datetime.date:
        return self._value

    def set(self, value: datetime.date) -> None:
        self._value = value

class BooleanItem(Item, ITypedItem[bool]):
    def __init__(self, parent: IGroup | None, key: IKey | str) -> None:
        super().__init__(parent, key)
        self._value: bool = False

    @property
    def is_mandatory(self) -> bool:
        return True

    def __str__(self) -> str:
        return str(self._value)

    def load(self, value: Any) -> None:
        if not isinstance(value, bool):
            raise SchemaLoadError(f"Key '{self.full_path}' value is not a boolean")
        self._value = value

    def save(self) -> Any:
        return self._value

    def get_item_value(self) -> bool:
        return self._value

    def set(self, value: bool) -> None:
        self._value = value

class OptionalTextItem(Item, ITypedItem[str | None]):
    def __init__(self, parent: IGroup | None, key: IKey | str) -> None:
        super().__init__(parent, key)
        self._value: str | None = None

    @property
    def is_mandatory(self) -> bool:
        return False

    def __str__(self) -> str:
        return str(self._value)

    def load(self, value: Any) -> None:
        if not isinstance(value, str):
            raise SchemaLoadError(f"Key '{self.full_path}' value is not text")
        if not value:
            raise SchemaLoadError(f"Key '{self.full_path}' value is blank")
        self._value = value

    def save(self) -> Any:
        return self._value

    def get_item_value(self) -> str | None:
        return self._value

    def set(self, value: str) -> None:
        self._value = value

    def remove(self) -> None:
        self._value = None

class OptionalBooleanItem(Item, ITypedItem[bool | None]):
    def __init__(self, parent: IGroup | None, key: IKey | str) -> None:
        super().__init__(parent, key)
        self._value: bool | None = None

    @property
    def is_mandatory(self) -> bool:
        return False

    def __str__(self) -> str:
        return str(self._value)

    def load(self, value: Any) -> None:
        if not isinstance(value, bool):
            raise SchemaLoadError(f"Key '{self.full_path}' value is not a boolean")
        self._value = value

    def save(self) -> Any:
        return self._value

    def get_item_value(self) -> bool | None:
        return self._value

    def set(self, value: bool) -> None:
        self._value = value

    def remove(self) -> None:
        self._value = None

def root_key() -> IKey:
    return TextKey('')

class TextKey(ITypedKey[str]):
    def __init__(self, key_name: str) -> None:
        self._key_name: str = key_name

    def __str__(self) -> str:
        return self._key_name

    @property
    def name(self) -> str:
        return self._key_name

    def get_key_value(self) -> str:
        return self._key_name

    class Creator(IKeyCreator[str]):
        def parse(self, key_name: str) -> ITypedKey[str]:
            return TextKey(key_name)

        def from_base_type(self, value: str) -> ITypedKey[str]:
            return TextKey(value)

class IntegerKey(ITypedKey[int]):
    def __init__(self, key_value: int) -> None:
        self._key_value: int = key_value

    def __str__(self) -> str:
        return str(self._key_value)

    @property
    def name(self) -> str:
        return str(self._key_value)

    def get_key_value(self) -> int:
        return self._key_value

    class Creator(IKeyCreator[int]):
        def parse(self, key_name: str) -> ITypedKey[int]:
            try:
                key_value: int = int(key_name)
            except ValueError as ex:
                raise KeyParseError(f"'{key_name}' is not an integer") from ex
            return IntegerKey(key_value)

        def from_base_type(self, value: int) -> ITypedKey[int]:
            return IntegerKey(value)
