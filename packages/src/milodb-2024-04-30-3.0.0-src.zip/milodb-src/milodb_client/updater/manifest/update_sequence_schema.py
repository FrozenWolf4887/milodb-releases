# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from collections.abc import Mapping, Sequence
from typing import Any
from milodb_client.updater.manifest.common_manifest_schema import validate_format_field
from milodb_client.updater.manifest.cooked_schema_types import CookedDictionary, CookedList
from milodb_client.updater.manifest.i_schema_types import IGroup, IKey, ITypedItem, ITypedKey
from milodb_client.updater.manifest.schema_types import DynamicGroup, IntegerItem, IntegerKey, ListGroup, OptionalBooleanItem, OptionalTextItem, StaticGroup, TextItem, root_key
from milodb_client.updater.manifest.update_sequence import IDeleteFile, IDeleteFilesAction, IEmplaceFile, IEmplaceFilesAction, IMoveFile, IMoveFilesAction, ISetFileAttribute, ISetFilesAttributeAction, IUpdateSequence

_EXPECTED_FORMAT_VERSION: int = 1

class UpdateSequenceSchema(StaticGroup, IUpdateSequence):
    def __init__(self) -> None:
        super().__init__(None, root_key())
        self.field_format = IntegerItem(self, 'format')
        self.field_format.set(_EXPECTED_FORMAT_VERSION)
        self.field_root_directory = TextItem(self, 'rootDirectory')
        self.field_temp_directory = TextItem(self, 'tempDirectory')
        self.field_move_files_actions = DynamicGroup(self, 'moveFilesActions', IntegerKey.Creator(), MoveFilesAction)
        self.field_emplace_files_actions = DynamicGroup(self, 'emplaceFilesActions', IntegerKey.Creator(), EmplaceFilesAction)
        self.field_delete_files_actions = DynamicGroup(self, 'deleteFilesActions', IntegerKey.Creator(), DeleteFilesAction)
        self.field_set_files_attribute_actions = DynamicGroup(self, 'setFileAttributeActions', IntegerKey.Creator(), SetFilesAttributeAction)
        self.field_launch_filename = OptionalTextItem(self, 'launchFilename')

    def load(self, value: Any) -> None:
        validate_format_field(value, _EXPECTED_FORMAT_VERSION, 'update sequence')
        return super().load(value)

    @property
    def format(self) -> int:
        return self.field_format.get_item_value()

    @property
    def root_directory(self) -> str:
        return self.field_root_directory.get_item_value()

    @property
    def temp_directory(self) -> str:
        return self.field_temp_directory.get_item_value()

    @property
    def move_files_actions(self) -> Mapping[int, 'IMoveFilesAction']:
        return CookedDictionary(self.field_move_files_actions.get())

    @property
    def emplace_files_actions(self) -> Mapping[int, 'IEmplaceFilesAction']:
        return CookedDictionary(self.field_emplace_files_actions.get())

    @property
    def delete_files_actions(self) -> Mapping[int, 'IDeleteFilesAction']:
        return CookedDictionary(self.field_delete_files_actions.get())

    @property
    def set_files_attribute_actions(self) -> Mapping[int, 'ISetFilesAttributeAction']:
        return CookedDictionary(self.field_set_files_attribute_actions.get())

    @property
    def launch_filename(self) -> str | None:
        return self.field_launch_filename.get_item_value()

class MoveFile(StaticGroup, IMoveFile, ITypedItem['MoveFile']): # pylint: disable=too-many-ancestors
    def __init__(self, parent: IGroup, key: IKey | str) -> None:
        super().__init__(parent, key)
        self.field_original_filename = TextItem(self, 'originalFilename')
        self.field_new_filename = TextItem(self, 'newFilename')

    def get_item_value(self) -> 'MoveFile':
        return self

    @property
    def original_filename(self) -> str:
        return self.field_original_filename.get_item_value()

    @property
    def new_filename(self) -> str:
        return self.field_new_filename.get_item_value()

class MoveFilesAction(ListGroup[MoveFile], IMoveFilesAction):
    def __init__(self, parent: IGroup, key: ITypedKey[int]) -> None:
        super().__init__(parent, key, MoveFile)
        self._priority: int = key.get_key_value()

    @property
    def priority(self) -> int:
        return self._priority

    @property
    def files(self) -> Sequence[MoveFile]:
        return CookedList(self.get())

class EmplaceFile(StaticGroup, IEmplaceFile, ITypedItem['EmplaceFile']): # pylint: disable=too-many-ancestors
    def __init__(self, parent: IGroup, key: IKey | str) -> None:
        super().__init__(parent, key)
        self.field_source_filename = TextItem(self, 'sourceFilename')
        self.field_target_filename = TextItem(self, 'targetFilename')

    def get_item_value(self) -> 'EmplaceFile':
        return self

    @property
    def source_filename(self) -> str:
        return self.field_source_filename.get_item_value()

    @property
    def target_filename(self) -> str:
        return self.field_target_filename.get_item_value()

class EmplaceFilesAction(ListGroup[EmplaceFile], IEmplaceFilesAction):
    def __init__(self, parent: IGroup, key: ITypedKey[int]) -> None:
        super().__init__(parent, key, EmplaceFile)
        self._priority: int = key.get_key_value()

    @property
    def priority(self) -> int:
        return self._priority

    @property
    def files(self) -> Sequence[EmplaceFile]:
        return CookedList(self.get())

class DeleteFile(StaticGroup, IDeleteFile, ITypedItem['DeleteFile']): # pylint: disable=too-many-ancestors
    def __init__(self, parent: IGroup, key: IKey | str) -> None:
        super().__init__(parent, key)
        self.field_filename = TextItem(self, 'filename')

    def get_item_value(self) -> 'DeleteFile':
        return self

    @property
    def filename(self) -> str:
        return self.field_filename.get_item_value()

class DeleteFilesAction(ListGroup[DeleteFile], IDeleteFilesAction):
    def __init__(self, parent: IGroup, key: ITypedKey[int]) -> None:
        super().__init__(parent, key, DeleteFile)
        self._priority: int = key.get_key_value()

    @property
    def priority(self) -> int:
        return self._priority

    @property
    def files(self) -> Sequence[DeleteFile]:
        return CookedList(self.get())

class SetFileAttribute(StaticGroup, ISetFileAttribute, ITypedItem['SetFileAttribute']): # pylint: disable=too-many-ancestors
    def __init__(self, parent: IGroup, key: IKey | str) -> None:
        super().__init__(parent, key)
        self.field_filename = TextItem(self, 'filename')
        self.field_is_readonly = OptionalBooleanItem(self, 'isReadonly')
        self.field_is_executable = OptionalBooleanItem(self, 'isExecutable')

    def get_item_value(self) -> 'SetFileAttribute':
        return self

    @property
    def filename(self) -> str:
        return self.field_filename.get_item_value()

    @property
    def is_readonly(self) -> bool:
        return self.field_is_readonly.get_item_value() or False

    @property
    def is_executable(self) -> bool:
        return self.field_is_executable.get_item_value() or False

class SetFilesAttributeAction(StaticGroup, ISetFilesAttributeAction):
    def __init__(self, parent: IGroup, key: ITypedKey[int]) -> None:
        super().__init__(parent, key)
        self._priority: int = key.get_key_value()
        self.field_files = ListGroup(self, 'files', SetFileAttribute)

    @property
    def priority(self) -> int:
        return self._priority

    @property
    def files(self) -> Sequence[SetFileAttribute]:
        return CookedList(self.field_files.get())
