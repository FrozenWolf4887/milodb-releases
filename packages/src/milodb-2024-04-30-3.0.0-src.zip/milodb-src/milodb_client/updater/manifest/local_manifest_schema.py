# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
import datetime
from collections.abc import Mapping, Sequence
from typing import Any
from milodb_client.updater.manifest.common_manifest import IConfigFile, IVersionNumber
from milodb_client.updater.manifest.common_manifest_schema import ConfigFileItem, VersionNumberItem, validate_format_field
from milodb_client.updater.manifest.cooked_schema_types import CookedDictionary, CookedList
from milodb_client.updater.manifest.local_manifest import ILocalManifest
from milodb_client.updater.manifest.schema_types import DateItem, DynamicGroup, IntegerItem, IntegerKey, ListGroup, StaticGroup, TextItem, root_key

_EXPECTED_FORMAT_VERSION: int = 1

class LocalManifestSchema(StaticGroup, ILocalManifest):
    def __init__(self) -> None:
        super().__init__(None, root_key())
        self.field_format = IntegerItem(self, 'format')
        self.field_variant_name = TextItem(self, 'variant')
        self.field_version_number = VersionNumberItem(self, 'version')
        self.field_date = DateItem(self, 'date')
        self.field_core_files = ListGroup(self, 'coreFiles', TextItem)
        self.field_config_files = DynamicGroup(self, 'configFiles', IntegerKey.Creator(), ConfigFileItem)

    def load(self, value: Any) -> None:
        validate_format_field(value, _EXPECTED_FORMAT_VERSION, 'local manifest')
        return super().load(value)

    @property
    def format(self) -> int:
        return self.field_format.get_item_value()

    @property
    def variant_name(self) -> str:
        return self.field_variant_name.get_item_value()

    @property
    def version_number(self) -> IVersionNumber:
        return self.field_version_number.get()

    @property
    def date(self) -> datetime.date:
        return self.field_date.get_item_value()

    @property
    def core_files(self) -> Sequence[str]:
        return CookedList(self.field_core_files.get())

    @property
    def config_files(self) -> Mapping[int, IConfigFile]:
        return CookedDictionary(self.field_config_files.get())
