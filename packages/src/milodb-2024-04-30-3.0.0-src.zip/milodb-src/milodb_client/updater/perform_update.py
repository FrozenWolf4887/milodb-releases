# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from collections.abc import Sequence
from pathlib import Path
from typing import Any
from milodb_client.updater.i_temp_directory import ITempDirectory
from milodb_client.updater.manifest.update_sequence import IDeleteFile, IDeleteFilesAction, IEmplaceFile, IEmplaceFilesAction, IMoveFile, IMoveFilesAction, ISetFileAttribute, ISetFilesAttributeAction, IUpdateSequence
from milodb_client.updater.set_file_attributes import set_file_attributes
from milodb_client.updater.temp_directory import TempDirectory
from milodb_common.output.print.i_printer import IPrinter

class PerformUpdateError(Exception):
    pass

def perform_update(
        update_sequence: IUpdateSequence,
        normal_printer: IPrinter,
        warning_printer: IPrinter) -> None:
    """
    ### Raises
    - PerformUpdateError
    """
    temp_directory: ITempDirectory = TempDirectory(update_sequence.temp_directory)

    set_of_all_action_priorities: set[int] = set(
        update_sequence.delete_files_actions.keys()).union(
        update_sequence.move_files_actions.keys()).union(
        update_sequence.emplace_files_actions.keys()).union(
        update_sequence.set_files_attribute_actions.keys())

    priority: int
    for priority in set_of_all_action_priorities:
        delete_action: IDeleteFilesAction | None = update_sequence.delete_files_actions.get(priority)
        if delete_action:
            perform_delete_action(update_sequence.root_directory, delete_action, normal_printer, warning_printer)
        move_action: IMoveFilesAction | None = update_sequence.move_files_actions.get(priority)
        if move_action:
            perform_move_action(update_sequence.root_directory, move_action, normal_printer)
        emplace_action: IEmplaceFilesAction | None = update_sequence.emplace_files_actions.get(priority)
        if emplace_action:
            perform_emplace_action(update_sequence.root_directory, temp_directory, emplace_action, normal_printer)
        set_attribute_action: ISetFilesAttributeAction | None = update_sequence.set_files_attribute_actions.get(priority)
        if set_attribute_action:
            perform_set_attribute_action(update_sequence.root_directory, set_attribute_action, normal_printer)

def perform_delete_action(root_directory: str, delete_action: IDeleteFilesAction, normal_printer: IPrinter, warning_printer: IPrinter) -> None:
    """
    Remove the specified list of files and their directories if empty.

    ### Raises
    - PerformUpdateError
    """
    normal_printer.writeln('Removing files')

    file: IDeleteFile
    for file in delete_action.files:
        filepath: Path = Path(root_directory, file.filename)
        normal_printer.writeln(f"  Removing '{filepath}'")
        try:
            filepath.unlink()
        except OSError as ex:
            raise PerformUpdateError(f"Failed to remove file '{filepath}': {ex}") from ex

    normal_printer.writeln('Removing directories')

    map_of_directories: dict[str, dict[str, Any]] = {}
    for file in delete_action.files:
        sub_map: dict[str, dict[str, Any]] = map_of_directories
        for part in Path(file.filename).parent.parts:
            sub_map = sub_map.setdefault(part, {})

    _prune_directory_map(Path(root_directory), map_of_directories, normal_printer, warning_printer)

def _prune_directory_map(parent_path: Path, map_of_directories: dict[str, dict[str, Any]], normal_printer: IPrinter, warning_printer: IPrinter) -> None:
    dirname: str
    sub_map: dict[str, dict[str, Any]]
    for dirname, sub_map in map_of_directories.items():
        path: Path = parent_path.joinpath(dirname)
        if sub_map:
            _prune_directory_map(path, sub_map, normal_printer, warning_printer)

        has_contents: bool
        try:
            next(path.iterdir())
        except StopIteration:
            has_contents = False
        except OSError as ex:
            warning_printer.writeln(f"Unable to check contents of directory '{path}': {ex}")
            has_contents = True
        else:
            has_contents = True

        if not has_contents:
            normal_printer.writeln(f"  Removing '{path}'")
            try:
                path.rmdir()
            except OSError as ex:
                warning_printer.writeln(f"  Failed to remove directory '{path}': {ex}")
        else:
            normal_printer.writeln(f"  Leaving populated directory '{path}'")

def perform_move_action(root_directory: str, move_action: IMoveFilesAction, printer: IPrinter) -> None:
    """
    ### Raises
    - PerformUpdateError
    """
    printer.writeln('Moving files')
    file: IMoveFile
    for file in move_action.files:
        printer.writeln(f"  Move '{file.original_filename}' to '{file.new_filename}'")
        original_path: Path = Path(root_directory, file.original_filename)
        new_path: Path = Path(root_directory, file.new_filename)
        try:
            original_path.rename(new_path)
        except OSError as ex:
            raise PerformUpdateError(f"Failed to rename file '{original_path}' to '{new_path}': {ex}") from ex

def perform_emplace_action(root_directory: str, temp_directory: ITempDirectory, emplace_action: IEmplaceFilesAction, printer: IPrinter) -> None:
    """
    ### Raises
    - PerformUpdateError
    """
    printer.writeln('Emplacing files')

    file: IEmplaceFile
    for file in emplace_action.files:
        source_path: Path = temp_directory.path_of(file.source_filename)
        target_path: Path = Path(root_directory, file.target_filename)

        try:
            with source_path.open('rb') as input_file:
                file_data: bytes = input_file.read()
        except OSError as ex:
            raise PerformUpdateError(f"Asset '{source_path}' for file '{target_path}' is unavailable: {ex}") from ex

        printer.writeln(f"  Emplacing '{file.target_filename}'")

        try:
            target_path.parent.mkdir(parents=True, exist_ok=True)
            with target_path.open('wb') as output:
                output.write(file_data)
        except OSError as ex:
            raise PerformUpdateError(f"Failed to write file '{target_path}': {ex}") from ex

def perform_set_attribute_action(root_directory: str, set_attribute_action: ISetFilesAttributeAction, printer: IPrinter) -> None:
    """
    ### Raises
    - PerformUpdateError
    """
    printer.writeln('Setting file attributes')

    file: ISetFileAttribute
    for file in set_attribute_action.files:
        path: Path = Path(root_directory, file.filename)
        try:
            list_of_mode_changes: Sequence[str] = set_file_attributes(path, is_executable=file.is_executable, is_readonly=file.is_readonly)
        except OSError as ex:
            raise PerformUpdateError(f"Failed to set attributes of file '{path}': {ex}") from ex
        if list_of_mode_changes:
            printer.writeln(f"  Changed '{file.filename}' to {','.join(list_of_mode_changes)}")
