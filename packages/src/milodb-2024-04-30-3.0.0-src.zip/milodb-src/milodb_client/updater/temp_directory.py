# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
import os
import tempfile
from pathlib import Path
from milodb_client.updater.i_temp_directory import ITempDirectory, ITempDirectoryCreator, TempDirectoryError
from milodb_client.updater.set_file_attributes import set_file_attributes

_FILENAME_PREFIX: str = 'mdbu-'

class TempDirectory(ITempDirectory):
    def __init__(self, path_to_directory: str) -> None:
        self._path_to_directory: Path = Path(path_to_directory)

    @property
    def path(self) -> Path:
        return self._path_to_directory

    def path_of(self, filename: str) -> Path:
        return self._path_to_directory.joinpath(f'{_FILENAME_PREFIX}{filename}')

    def store_file(self, filename: str, data: bytes, *, is_executable: bool = False) -> None:
        filepath: Path = self._path_to_directory.joinpath(f'{_FILENAME_PREFIX}{filename}')
        try:
            with filepath.open('wb') as file:
                file.write(data)
            set_file_attributes(filepath, is_executable=is_executable, is_readonly=False)
        except OSError as ex:
            raise TempDirectoryError(f"Unable to store file '{filepath}': {ex}") from ex

    def destroy(self) -> None:
        filename: str
        try:
            for filename in os.listdir(self._path_to_directory):
                filepath: Path = self._path_to_directory.joinpath(filename)
                if filename.startswith(_FILENAME_PREFIX):
                    filepath.unlink()
                else:
                    raise TempDirectoryError(f"Refusing to delete temp file '{filepath}' because it doesn't start with '{_FILENAME_PREFIX}'")
            self._path_to_directory.rmdir()
        except OSError as ex:
            raise TempDirectoryError(f"Failed to delete temp directory '{self._path_to_directory}': {ex}") from ex

class TempDirectoryCreator(ITempDirectoryCreator):
    def create(self) -> ITempDirectory:
        try:
            path_to_directory: str = tempfile.mkdtemp(prefix='milodb-', suffix='-updater')
        except OSError as ex:
            raise TempDirectoryError(f"Cannot create temp directory: {ex}") from ex
        return TempDirectory(path_to_directory)
