# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from abc import ABC, abstractmethod
from pathlib import Path

class ITempDirectory(ABC):
    @property
    @abstractmethod
    def path(self) -> Path:
        pass

    @abstractmethod
    def path_of(self, filename: str) -> Path:
        pass

    @abstractmethod
    def store_file(self, filename: str, data: bytes, *, is_executable: bool = False) -> None:
        """
        ### Raises
        - TempDirectoryError
            - If the file can't be stored
        """

    @abstractmethod
    def destroy(self) -> None:
        """
        ### Raises
        - TempDirectoryError
            - If the directory cannot be removed
        """

class ITempDirectoryCreator(ABC):
    @abstractmethod
    def create(self) -> ITempDirectory:
        """
        ### Raises
        - TempDirectoryError
            - If the directory can't be created
        """

class TempDirectoryError(Exception):
    pass
