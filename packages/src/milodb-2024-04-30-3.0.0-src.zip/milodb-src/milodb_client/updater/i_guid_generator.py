# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from abc import ABC, abstractmethod

class IGuidGenerator(ABC):
    @abstractmethod
    def create_guid(self) -> int:
        pass
