# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from collections.abc import Sequence
from datetime import datetime
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile
from milodb_client.updater.i_temp_directory import ITempDirectory, TempDirectoryError
from milodb_client.updater.manifest.update_directory import IAssetRegister
from milodb_client.updater.manifest.update_sequence_schema import DeleteFile, DeleteFilesAction, EmplaceFile, EmplaceFilesAction, MoveFile, MoveFilesAction, SetFileAttribute, SetFilesAttributeAction, UpdateSequenceSchema
from milodb_client.updater.manifest.version_manifest import ICoreFile
from milodb_client.updater.update_strategy import FileRename, UpdateStrategy
from milodb_common.internet.i_uri_scraper_factory import IUriScraperFactory, UriScraperFactoryError
from milodb_common.internet.i_web_scraper import IWebScraper, ScrapeResult
from milodb_common.output.print.i_printer import IPrinter

class PrepareUpdateError(Exception):
    pass

def prepare_update(
        update_strategy: UpdateStrategy,
        backup_directory: str,
        time_stamp: datetime,
        directory_uri: str,
        asset_register: IAssetRegister,
        temp_directory: ITempDirectory,
        web_scraper_factory: IUriScraperFactory,
        normal_printer: IPrinter) -> UpdateSequenceSchema:
    """
    ### Raises
    - PrepareUpdateError
    """
    list_of_files_to_emplace: Sequence[ICoreFile] = fetch_assets_to_temp_directory(update_strategy, directory_uri, asset_register, temp_directory, web_scraper_factory, normal_printer)
    backup_files(update_strategy, backup_directory, time_stamp, normal_printer)
    return determine_update_sequence(update_strategy, temp_directory, list_of_files_to_emplace)

def fetch_assets_to_temp_directory(update_strategy: UpdateStrategy, directory_uri: str, asset_register: IAssetRegister, temp_directory: ITempDirectory, web_scraper_factory: IUriScraperFactory, normal_printer: IPrinter) -> Sequence[ICoreFile]:
    """
    ### Raises
    - PrepareUpdateError
    """
    list_of_files_to_acquire: list[ICoreFile] = \
        update_strategy.core_file_changes.list_of_new_files_to_acquire + \
        update_strategy.core_file_changes.list_of_missing_files_to_acquire + \
        update_strategy.core_file_changes.list_of_changed_files_to_acquire

    normal_printer.writeln(f"Downloading {len(list_of_files_to_acquire)} assets")

    core_file: ICoreFile
    for core_file in list_of_files_to_acquire:
        asset_uri: str | None = asset_register.resolve_asset_uri(directory_uri, core_file.digest)
        if not asset_uri:
            raise PrepareUpdateError(f"Asset '{core_file.digest}' for file '{core_file.filename}' is not in the asset register")

        normal_printer.writeln(f"  Fetching asset '{core_file.digest}' for file '{core_file.filename}'")

        web_scraper: IWebScraper
        asset_path: str
        try:
            web_scraper, asset_path = web_scraper_factory.get_scraper_and_filepath(asset_uri)
        except UriScraperFactoryError as ex:
            raise PrepareUpdateError(f"Asset '{core_file.digest}' for file '{core_file.filename}' with URI '{asset_uri}' is inaccessible: {ex}") from ex

        scrape_result: ScrapeResult = web_scraper.try_scrape(asset_path, lambda msg: normal_printer.writeln(f"    {msg}"))
        if scrape_result.error_message:
            raise PrepareUpdateError(f"Asset '{core_file.digest}' for file '{core_file.filename}' with URI '{asset_uri}' download error: {scrape_result.error_message}")

        try:
            temp_directory.store_file(str(core_file.digest), scrape_result.content)
        except TempDirectoryError as ex:
            raise PrepareUpdateError(f"Asset '{core_file.digest}' for file '{core_file.filename}' failed to store in temp directory: {ex}") from ex

    return list_of_files_to_acquire

def backup_files(update_strategy: UpdateStrategy, backup_directory: str, time_stamp: datetime, normal_printer: IPrinter) -> None:
    """
    ### Raises
    - PrepareUpdateError
    """
    list_of_files_to_backup: list[str] = \
        update_strategy.backup_file_set.list_of_core_files_to_backup + \
        update_strategy.backup_file_set.list_of_config_files_to_backup + \
        update_strategy.backup_file_set.list_of_clobbered_files_to_backup

    zip_filename: str = (
        f'{time_stamp.year:04}-{time_stamp.month:02}-{time_stamp.day:02}_{time_stamp.hour:02}-{time_stamp.minute:02}-{time_stamp.second:02}'
        f'_{update_strategy.local_manifest.variant_name}_{update_strategy.local_manifest.version_number}.zip'
    )
    zip_filepath: Path = Path(update_strategy.root_directory, backup_directory, zip_filename)
    normal_printer.writeln(f"Backing up files to '{zip_filepath}'")

    try:
        zip_filepath.parent.mkdir(parents=True, exist_ok=True)
    except OSError as ex:
        raise PrepareUpdateError(ex) from ex

    try:
        with zip_filepath.open('wb') as raw_zip_file:
            with ZipFile(raw_zip_file, mode='w', compression=ZIP_DEFLATED, compresslevel=9) as zip_file:
                source_filename: str
                for source_filename in list_of_files_to_backup:
                    source_path: Path = Path(update_strategy.root_directory, source_filename)
                    target_path: Path = Path(source_filename)
                    if source_path.exists():
                        normal_printer.writeln(f"  Saving '{source_path}'")
                        zip_file.write(source_path, target_path)
                    else:
                        normal_printer.writeln(f"  Skipping '{source_path}'")
    except OSError as ex:
        raise PrepareUpdateError(ex) from ex

def determine_update_sequence(update_strategy: UpdateStrategy, temp_directory: ITempDirectory, list_of_files_to_emplace: Sequence[ICoreFile]) -> UpdateSequenceSchema:
    list_of_files_to_remove: list[str] = \
        [ file.filename for file in update_strategy.core_file_changes.list_of_changed_files_to_acquire ] + \
        update_strategy.core_file_changes.list_of_files_that_are_deprecated + \
        update_strategy.config_file_changes.list_of_files_that_are_deprecated

    update_sequence: UpdateSequenceSchema = UpdateSequenceSchema()

    update_sequence.field_root_directory.set(update_strategy.root_directory)
    update_sequence.field_temp_directory.set(str(temp_directory.path))

    delete_action: DeleteFilesAction = update_sequence.field_delete_files_actions.add_key(1)
    filename: str
    for filename in list_of_files_to_remove:
        delete_item: DeleteFile = delete_action.add_item()
        delete_item.field_filename.set(filename)

    move_action: MoveFilesAction = update_sequence.field_move_files_actions.add_key(2)
    file_rename: FileRename
    for file_rename in update_strategy.config_file_changes.list_of_files_to_rename:
        move_item: MoveFile = move_action.add_item()
        move_item.field_original_filename.set(file_rename.original_filename)
        move_item.field_new_filename.set(file_rename.new_filename)

    emplace_action: EmplaceFilesAction = update_sequence.field_emplace_files_actions.add_key(3)
    set_attributes_action: SetFilesAttributeAction = update_sequence.field_set_files_attribute_actions.add_key(4)
    core_file: ICoreFile
    for core_file in list_of_files_to_emplace:
        emplace_item: EmplaceFile = emplace_action.add_item()
        emplace_item.field_source_filename.set(str(core_file.digest))
        emplace_item.field_target_filename.set(core_file.filename)
        if core_file.exe:
            set_item: SetFileAttribute = set_attributes_action.field_files.add_item()
            set_item.field_filename.set(core_file.filename)
            set_item.field_is_executable.set(True)

    if update_strategy.launch_executable:
        update_sequence.field_launch_filename.set(update_strategy.launch_executable.filename)

    return update_sequence
