#!/usr/bin/env python3
# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0

import sys
if sys.version_info >= (3, 10):
    from typing import NoReturn
    from milodb_client.startup.startup import StartupResult, startup
else:
    print("Python version 3.10 or greater required")
    print("Actual version is " + sys.version)
    sys.exit(1)

def _main(list_of_args: list[str]) -> NoReturn:
    exit_code: int = 0
    startup_result: StartupResult = startup(list_of_args)
    if startup_result.shutdown_action:
        exit_code = startup_result.shutdown_action.perform_action()
    else:
        exit_code = startup_result.exit_code
    sys.exit(exit_code)

if __name__ == "__main__":
    _main(sys.argv[1:])
