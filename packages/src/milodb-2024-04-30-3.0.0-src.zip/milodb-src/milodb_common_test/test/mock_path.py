# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from pathlib import Path

map_of_absolute_resolution: dict[Path, Path] = {}
map_of_relative_to_resolution: dict[tuple[Path, Path], Path] = {}

def absolute(this: Path) -> Path:
    return map_of_absolute_resolution[this]

def relative_to(full_path: Path, sub_path: Path) -> Path:
    return map_of_relative_to_resolution[(full_path, sub_path)]
