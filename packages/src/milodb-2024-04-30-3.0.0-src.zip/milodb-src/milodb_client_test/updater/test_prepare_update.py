# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
import os
import unittest
from datetime import datetime
from pathlib import Path
from unittest.mock import ANY, Mock, PropertyMock, call
from zipfile import ZipFile, ZipInfo
from mockito import when # type: ignore
from milodb_client.updater.i_temp_directory import ITempDirectory, TempDirectoryError
from milodb_client.updater.manifest.common_manifest import IVersionNumber
from milodb_client.updater.manifest.local_manifest import ILocalManifest
from milodb_client.updater.manifest.update_directory import IAssetRegister
from milodb_client.updater.manifest.update_sequence import IDeleteFilesAction, IEmplaceFilesAction, IMoveFilesAction
from milodb_client.updater.manifest.update_sequence_schema import UpdateSequenceSchema
from milodb_client.updater.manifest.version_manifest import ICoreFile
from milodb_client.updater.prepare_update import PrepareUpdateError, backup_files, determine_update_sequence, fetch_assets_to_temp_directory
from milodb_client.updater.update_strategy import BackupFileSet, ConfigFileChanges, CoreFileChanges, FileRename, UpdateStrategy
from milodb_client_test.test.fake_data import FAKE_DATA_A, FAKE_DATA_B, FAKE_DATA_C, FAKE_DATA_D, FAKE_HEXDIGEST_A, FAKE_HEXDIGEST_B, FAKE_HEXDIGEST_C, FAKE_HEXDIGEST_D
from milodb_client_test.test.test_directory import FakeFile, TestDirectory
from milodb_common.internet.i_uri_scraper_factory import IUriScraperFactory, UriScraperFactoryError
from milodb_common.internet.i_web_scraper import IWebScraper, ScrapeResult
from milodb_common.output.print.i_printer import IPrinter
from milodb_common_test.test.strict_mock import StrictDataclassMock, StrictMock

FAKE_DIRECTORY_URI: str = 'https://example.com'

FAKE_URI_A: str = 'Morbi tincidunt augue interdum velit euismod in'
FAKE_URI_B: str = 'Elementum sagittis vitae et leo. Erat pellentesque adipiscing commodo elit at imperdiet dui'
FAKE_URI_C: str = 'Dui vivamus arcu felis bibendum ut tristique'
FAKE_URI_D: str = 'Consectetur a erat nam at lectus urna duis. Lacinia at quis risus sed vulputate odio'
FAKE_URI_E: str = 'Turpis nunc eget lorem dolor sed viverra'
FAKE_URI_F: str = 'Vitae justo eget magna fermentum iaculis'
FAKE_URI_FILEPATH_A: str = 'euismod'
FAKE_URI_FILEPATH_B: str = 'sagittis'
FAKE_URI_FILEPATH_C: str = 'tristique'
FAKE_URI_FILEPATH_D: str = 'lectus'
FAKE_URI_FILEPATH_E: str = 'vulputate'
FAKE_URI_FILEPATH_F: str = 'justo'

_STUB_DATETIME_2020: datetime = datetime(2020, 12, 31, 13, 45, 28)

class TestPrepareUpdateFetchAssetsToTempDirectory(unittest.TestCase):
    def setUp(self) -> None:
        super().setUp()
        self.asset_register = StrictMock(IAssetRegister)
        self.temp_directory = StrictMock(ITempDirectory)
        self.web_scraper_factory = StrictMock(IUriScraperFactory)
        self.web_scraper = StrictMock(IWebScraper)
        self.printer = StrictMock(IPrinter)

        self.core_file_1 = StrictMock(ICoreFile,
            digest = PropertyMock(return_value=FAKE_HEXDIGEST_A),
            filename = PropertyMock(return_value='mango.txt')
        )
        self.core_file_2 = StrictMock(ICoreFile,
            digest = PropertyMock(return_value=FAKE_HEXDIGEST_B),
            filename = PropertyMock(return_value='fruit.dat')
        )
        self.core_file_3 = StrictMock(ICoreFile,
            digest = PropertyMock(return_value=FAKE_HEXDIGEST_C),
            filename = PropertyMock(return_value='apple.exe')
        )
        self.core_file_4 = StrictMock(ICoreFile,
            digest = PropertyMock(return_value=FAKE_HEXDIGEST_D),
            filename = PropertyMock(return_value='pear.log')
        )

    def test_given_no_file_changes_does_nothing(self) -> None:
        self.printer.writeln = Mock()

        update_strategy = StrictDataclassMock(UpdateStrategy,
            core_file_changes = StrictDataclassMock(CoreFileChanges,
                list_of_new_files_to_acquire = [],
                list_of_missing_files_to_acquire = [],
                list_of_changed_files_to_acquire = []
            )
        )

        fetch_assets_to_temp_directory(update_strategy, FAKE_DIRECTORY_URI, self.asset_register, self.temp_directory, self.web_scraper_factory, self.printer)

        self.printer.writeln.assert_called_once_with('Downloading 0 assets')

    def test_downloads_and_stores_file_to_temp_directory(self) -> None:
        self.printer.writeln = Mock()
        self.asset_register.resolve_asset_uri = Mock()
        self.web_scraper_factory.get_scraper_and_filepath = Mock()
        self.web_scraper.try_scrape = Mock()
        self.temp_directory.store_file = Mock()
        when(self.asset_register).resolve_asset_uri(FAKE_DIRECTORY_URI, self.core_file_1.digest).thenReturn(FAKE_URI_A)
        when(self.web_scraper_factory).get_scraper_and_filepath(FAKE_URI_A).thenReturn((self.web_scraper, FAKE_URI_FILEPATH_A))
        when(self.web_scraper).try_scrape(FAKE_URI_FILEPATH_A, ANY).thenReturn(ScrapeResult(None, FAKE_DATA_A))

        update_strategy = StrictDataclassMock(UpdateStrategy,
            core_file_changes = StrictDataclassMock(CoreFileChanges,
                list_of_new_files_to_acquire = [self.core_file_1],
                list_of_missing_files_to_acquire = [],
                list_of_changed_files_to_acquire = []
            )
        )

        fetch_assets_to_temp_directory(update_strategy, FAKE_DIRECTORY_URI, self.asset_register, self.temp_directory, self.web_scraper_factory, self.printer)

        self.printer.writeln.assert_has_calls([
            call('Downloading 1 assets'),
            call(f"  Fetching asset '{self.core_file_1.digest}' for file '{self.core_file_1.filename}'")
        ])
        self.temp_directory.store_file.assert_called_once_with(str(self.core_file_1.digest), FAKE_DATA_A)

    def test_downloads_and_stores_multiple_files_to_temp_directory(self) -> None:
        self.printer.writeln = Mock()
        self.asset_register.resolve_asset_uri = Mock()
        self.web_scraper_factory.get_scraper_and_filepath = Mock()
        self.web_scraper.try_scrape = Mock()
        self.temp_directory.store_file = Mock()
        when(self.asset_register).resolve_asset_uri(FAKE_DIRECTORY_URI, self.core_file_1.digest).thenReturn(FAKE_URI_A)
        when(self.asset_register).resolve_asset_uri(FAKE_DIRECTORY_URI, self.core_file_2.digest).thenReturn(FAKE_URI_B)
        when(self.asset_register).resolve_asset_uri(FAKE_DIRECTORY_URI, self.core_file_3.digest).thenReturn(FAKE_URI_C)
        when(self.asset_register).resolve_asset_uri(FAKE_DIRECTORY_URI, self.core_file_4.digest).thenReturn(FAKE_URI_D)
        when(self.web_scraper_factory).get_scraper_and_filepath(FAKE_URI_A).thenReturn((self.web_scraper, FAKE_URI_FILEPATH_A))
        when(self.web_scraper_factory).get_scraper_and_filepath(FAKE_URI_B).thenReturn((self.web_scraper, FAKE_URI_FILEPATH_B))
        when(self.web_scraper_factory).get_scraper_and_filepath(FAKE_URI_C).thenReturn((self.web_scraper, FAKE_URI_FILEPATH_C))
        when(self.web_scraper_factory).get_scraper_and_filepath(FAKE_URI_D).thenReturn((self.web_scraper, FAKE_URI_FILEPATH_D))
        when(self.web_scraper).try_scrape(FAKE_URI_FILEPATH_A, ANY).thenReturn(ScrapeResult(None, FAKE_DATA_A))
        when(self.web_scraper).try_scrape(FAKE_URI_FILEPATH_B, ANY).thenReturn(ScrapeResult(None, FAKE_DATA_B))
        when(self.web_scraper).try_scrape(FAKE_URI_FILEPATH_C, ANY).thenReturn(ScrapeResult(None, FAKE_DATA_C))
        when(self.web_scraper).try_scrape(FAKE_URI_FILEPATH_D, ANY).thenReturn(ScrapeResult(None, FAKE_DATA_D))

        update_strategy = StrictDataclassMock(UpdateStrategy,
            core_file_changes = StrictDataclassMock(CoreFileChanges,
                list_of_new_files_to_acquire = [
                    self.core_file_4
                ],
                list_of_missing_files_to_acquire = [
                    self.core_file_1
                ],
                list_of_changed_files_to_acquire = [
                    self.core_file_2,
                    self.core_file_3
                ]
            )
        )

        fetch_assets_to_temp_directory(update_strategy, FAKE_DIRECTORY_URI, self.asset_register, self.temp_directory, self.web_scraper_factory, self.printer)

        self.printer.writeln.assert_has_calls([
            call('Downloading 4 assets'),
            call(f"  Fetching asset '{self.core_file_1.digest}' for file '{self.core_file_1.filename}'"),
            call(f"  Fetching asset '{self.core_file_2.digest}' for file '{self.core_file_2.filename}'"),
            call(f"  Fetching asset '{self.core_file_3.digest}' for file '{self.core_file_3.filename}'"),
            call(f"  Fetching asset '{self.core_file_4.digest}' for file '{self.core_file_4.filename}'")
        ], any_order=True)
        self.temp_directory.store_file.assert_has_calls([
            call(str(self.core_file_1.digest), FAKE_DATA_A),
            call(str(self.core_file_2.digest), FAKE_DATA_B),
            call(str(self.core_file_3.digest), FAKE_DATA_C),
            call(str(self.core_file_4.digest), FAKE_DATA_D)
        ], any_order=True)

    def test_raises_error_when_web_scraper_not_avaiable_from_factory(self) -> None:
        self.printer.writeln = Mock()
        self.asset_register.resolve_asset_uri = Mock()
        self.web_scraper_factory.get_scraper_and_filepath = Mock()
        when(self.asset_register).resolve_asset_uri(FAKE_DIRECTORY_URI, self.core_file_1.digest).thenReturn(FAKE_URI_A)
        when(self.web_scraper_factory).get_scraper_and_filepath(FAKE_URI_A).thenRaise(UriScraperFactoryError('test exception message'))

        update_strategy = StrictDataclassMock(UpdateStrategy,
            core_file_changes = StrictDataclassMock(CoreFileChanges,
                list_of_new_files_to_acquire = [self.core_file_1],
                list_of_missing_files_to_acquire = [],
                list_of_changed_files_to_acquire = []
            )
        )

        with self.assertRaises(PrepareUpdateError) as ex:
            fetch_assets_to_temp_directory(update_strategy, FAKE_DIRECTORY_URI, self.asset_register, self.temp_directory, self.web_scraper_factory, self.printer)

        self.assertEqual(f"Asset '{self.core_file_1.digest}' for file '{self.core_file_1.filename}' with URI '{FAKE_URI_A}' is inaccessible: test exception message", str(ex.exception))

    def test_raises_error_when_web_scraper_cannot_download_file(self) -> None:
        self.printer.writeln = Mock()
        self.asset_register.resolve_asset_uri = Mock()
        self.web_scraper_factory.get_scraper_and_filepath = Mock()
        self.web_scraper.try_scrape = Mock()
        when(self.asset_register).resolve_asset_uri(FAKE_DIRECTORY_URI, self.core_file_1.digest).thenReturn(FAKE_URI_A)
        when(self.web_scraper_factory).get_scraper_and_filepath(FAKE_URI_A).thenReturn((self.web_scraper, FAKE_URI_FILEPATH_A))
        when(self.web_scraper).try_scrape(FAKE_URI_FILEPATH_A, ANY).thenReturn(ScrapeResult('error during scrape', bytes()))

        update_strategy = StrictDataclassMock(UpdateStrategy,
            core_file_changes = StrictDataclassMock(CoreFileChanges,
                list_of_new_files_to_acquire = [self.core_file_1],
                list_of_missing_files_to_acquire = [],
                list_of_changed_files_to_acquire = []
            )
        )

        with self.assertRaises(PrepareUpdateError) as ex:
            fetch_assets_to_temp_directory(update_strategy, FAKE_DIRECTORY_URI, self.asset_register, self.temp_directory, self.web_scraper_factory, self.printer)

        self.assertEqual(f"Asset '{self.core_file_1.digest}' for file '{self.core_file_1.filename}' with URI '{FAKE_URI_A}' download error: error during scrape", str(ex.exception))

    def test_raises_error_when_file_cannot_be_stored_in_temp_directory(self) -> None:
        self.printer.writeln = Mock()
        self.asset_register.resolve_asset_uri = Mock()
        self.web_scraper_factory.get_scraper_and_filepath = Mock()
        self.web_scraper.try_scrape = Mock()
        self.temp_directory.store_file = Mock()
        when(self.asset_register).resolve_asset_uri(FAKE_DIRECTORY_URI, self.core_file_1.digest).thenReturn(FAKE_URI_A)
        when(self.web_scraper_factory).get_scraper_and_filepath(FAKE_URI_A).thenReturn((self.web_scraper, FAKE_URI_FILEPATH_A))
        when(self.web_scraper).try_scrape(FAKE_URI_FILEPATH_A, ANY).thenReturn(ScrapeResult(None, FAKE_DATA_A))
        when(self.temp_directory).store_file(str(self.core_file_1.digest), FAKE_DATA_A).thenRaise(TempDirectoryError('some issue'))

        update_strategy = StrictDataclassMock(UpdateStrategy,
            core_file_changes = StrictDataclassMock(CoreFileChanges,
                list_of_new_files_to_acquire = [self.core_file_1],
                list_of_missing_files_to_acquire = [],
                list_of_changed_files_to_acquire = []
            )
        )

        with self.assertRaises(PrepareUpdateError) as ex:
            fetch_assets_to_temp_directory(update_strategy, FAKE_DIRECTORY_URI, self.asset_register, self.temp_directory, self.web_scraper_factory, self.printer)

        self.assertEqual(f"Asset '{self.core_file_1.digest}' for file '{self.core_file_1.filename}' failed to store in temp directory: some issue", str(ex.exception))

class TestPrepareUpdateBackupFiles(unittest.TestCase):
    def setUp(self) -> None:
        super().setUp()

        self.timestamp: datetime = _STUB_DATETIME_2020
        self.variant_name: str = 'bar'
        self.version_number = StrictMock(IVersionNumber)
        setattr(self.version_number, '__str__', Mock(return_value='hello-world'))
        self.normal_printer = StrictMock(IPrinter,
            writeln = Mock()
        )

    def test_creates_empty_backup_zip_file_in_subdirectory(self) -> None:
        with TestDirectory(self, 'backup') as backup_dir:
            update_strategy = StrictDataclassMock(UpdateStrategy,
                root_directory = '.',
                local_manifest = StrictMock(ILocalManifest,
                    variant_name = PropertyMock(return_value=self.variant_name),
                    version_number = PropertyMock(return_value=self.version_number)
                ),
                backup_file_set = StrictDataclassMock(BackupFileSet,
                    list_of_core_files_to_backup = [],
                    list_of_config_files_to_backup = [],
                    list_of_clobbered_files_to_backup = []
                )
            )

            subdir: Path = Path('some', 'sub', 'dir')

            backup_files(update_strategy, str(backup_dir.path.joinpath(subdir)), self.timestamp, self.normal_printer)

            expected_zip_filename: Path = Path(subdir, f'{_date_text(self.timestamp)}_{self.variant_name}_{self.version_number}.zip')
            expected_zip_filepath: Path = backup_dir.path_of(expected_zip_filename)
            backup_dir.assert_file_exists(expected_zip_filename)

        self.normal_printer.writeln.assert_called_once_with(f"Backing up files to '{expected_zip_filepath}'")

    def test_saves_files_to_zip_file(self) -> None:
        with TestDirectory(self, 'source') as root_dir:
            file1 = FakeFile(root_dir, 'bongo.txt', 821)
            file2 = FakeFile(root_dir, 'fruit.exe', 19, is_executable=True)
            file3 = FakeFile(root_dir, Path('subdir1', 'something.dat'), 642)
            file4 = FakeFile(root_dir, Path('subdir2', 'subdir3', 'apple.map'), 2031)

            update_strategy = StrictDataclassMock(UpdateStrategy,
                root_directory = str(root_dir.path),
                local_manifest = StrictMock(ILocalManifest,
                    variant_name = PropertyMock(return_value=self.variant_name),
                    version_number = PropertyMock(return_value=self.version_number)
                ),
                backup_file_set = StrictDataclassMock(BackupFileSet,
                    list_of_core_files_to_backup = [file1.filename],
                    list_of_config_files_to_backup = [file2.filename, file3.filename],
                    list_of_clobbered_files_to_backup = [file4.filename]
                )
            )

            with TestDirectory(self, 'backup') as backup_dir:
                backup_files(update_strategy, str(backup_dir.path), self.timestamp, self.normal_printer)

                expected_zip_filepath: Path = backup_dir.path.joinpath(f'{_date_text(self.timestamp)}_{self.variant_name}_{self.version_number}.zip')
                with TestDirectory(self, 'extraction') as extraction_dir:
                    _unzip_file(expected_zip_filepath, extraction_dir.path)

                    extraction_dir.assert_file_exists(file1, file1.size)
                    extraction_dir.assert_file_exists(file2, file2.size, is_executable=True)
                    extraction_dir.assert_file_exists(file3, file3.size)
                    extraction_dir.assert_file_exists(file4, file4.size)

    def test_raises_error_when_backup_directory_cannot_be_created(self) -> None:
        with TestDirectory(self) as path:
            not_a_directory = FakeFile(path, 'not-a-directory', 100)

            update_strategy = StrictDataclassMock(UpdateStrategy,
                root_directory = str(path),
                local_manifest = StrictMock(ILocalManifest,
                    variant_name = PropertyMock(return_value=self.variant_name),
                    version_number = PropertyMock(return_value=self.version_number)
                ),
                backup_file_set = StrictDataclassMock(BackupFileSet,
                    list_of_core_files_to_backup = [],
                    list_of_config_files_to_backup = [],
                    list_of_clobbered_files_to_backup = []
                )
            )

            with self.assertRaises(PrepareUpdateError):
                backup_files(update_strategy, str(not_a_directory.filepath), self.timestamp, self.normal_printer)

    def test_skips_files_that_do_not_exist(self) -> None:
        with TestDirectory(self, 'source') as root_dir:
            file1 = FakeFile(root_dir, 'bongo.txt', 821)
            file2 = FakeFile(root_dir, 'fruit.exe', 19, is_executable=True)
            file3 = FakeFile(root_dir, Path('subdir1', 'something.dat'), 642)
            file4 = FakeFile(root_dir, Path('subdir2', 'subdir3', 'apple.map'), 2031)

            update_strategy = StrictDataclassMock(UpdateStrategy,
                root_directory = str(root_dir.path),
                local_manifest = StrictMock(ILocalManifest,
                    variant_name = PropertyMock(return_value=self.variant_name),
                    version_number = PropertyMock(return_value=self.version_number)
                ),
                backup_file_set = StrictDataclassMock(BackupFileSet,
                    list_of_core_files_to_backup = [file1.filename, 'missing1.txt', file2.filename],
                    list_of_config_files_to_backup = [file3.filename, 'missing-directory/missing2.txt'],
                    list_of_clobbered_files_to_backup = ['some/missing/directory/missing3.txt', file4.filename]
                )
            )

            with TestDirectory(self, 'backup') as backup_dir:
                backup_files(update_strategy, str(backup_dir.path), self.timestamp, self.normal_printer)

                expected_zip_filepath: Path = backup_dir.path.joinpath(f'{_date_text(self.timestamp)}_{self.variant_name}_{self.version_number}.zip')
                with TestDirectory(self, 'extraction') as extraction_dir:
                    _unzip_file(expected_zip_filepath, extraction_dir.path)

                    extraction_dir.assert_file_exists(file1, file1.size)
                    extraction_dir.assert_file_exists(file2, file2.size, is_executable=True)
                    extraction_dir.assert_file_exists(file3, file3.size)
                    extraction_dir.assert_file_exists(file4, file4.size)
                    extraction_dir.assert_file_missing('missing1.txt')
                    extraction_dir.assert_file_missing(Path('missing-directory', 'missing2.txt'))
                    extraction_dir.assert_file_missing(Path('some', 'missing-directory', 'missing3.txt'))

class TestPrepareUpdateDetermineUpdateSequence(unittest.TestCase):
    def setUp(self) -> None:
        super().setUp()
        self.update_strategy = StrictDataclassMock(UpdateStrategy,
            root_directory = 'test-directory',
            core_file_changes = StrictDataclassMock(CoreFileChanges,
                list_of_changed_files_to_acquire = [
                    StrictMock(ICoreFile,
                        filename = PropertyMock(return_value='orange.txt')
                    ),
                    StrictMock(ICoreFile,
                        filename = PropertyMock(return_value='mango.dat')
                    )
                ],
                list_of_files_that_are_deprecated = [
                    'cheese.exe',
                    'salad.log'
                ]
            ),
            config_file_changes = StrictDataclassMock(ConfigFileChanges,
                list_of_files_that_are_deprecated = [
                    'setup.cfg',
                    'settings.json'
                ],
                list_of_files_to_rename = [
                    StrictDataclassMock(FileRename,
                        original_filename = 'config.ini',
                        new_filename = 'config.toml'
                    ),
                    StrictDataclassMock(FileRename,
                        original_filename = 'default.css',
                        new_filename = 'light.css'
                    )
                ]
            ),
            launch_executable = None
        )

        self.list_of_files_to_emplace: list[ICoreFile] = [
            StrictMock(ICoreFile,
                filename = PropertyMock(return_value='winApp.exe'),
                digest = PropertyMock(return_value=FAKE_HEXDIGEST_A),
                exe = PropertyMock(return_value=False)
            ),
            StrictMock(ICoreFile,
                filename = PropertyMock(return_value='linApp'),
                digest = PropertyMock(return_value=FAKE_HEXDIGEST_B),
                exe = PropertyMock(return_value=True)
            ),
        ]

        self.temp_directory = StrictMock(ITempDirectory,
            path = PropertyMock(return_value=Path('example', 'temp_directory'))
        )

    def test_records_root_directory_and_temp_directory(self) -> None:
        update_sequence: UpdateSequenceSchema = determine_update_sequence(self.update_strategy, self.temp_directory, self.list_of_files_to_emplace)

        self.assertEqual(self.update_strategy.root_directory, update_sequence.root_directory)
        self.assertEqual(str(self.temp_directory.path), update_sequence.temp_directory)

    def test_creates_delete_action_for_deleted_files(self) -> None:
        update_sequence: UpdateSequenceSchema = determine_update_sequence(self.update_strategy, self.temp_directory, self.list_of_files_to_emplace)

        list_of_actual_files_to_delete: list[str] = []
        action: IDeleteFilesAction
        for action in update_sequence.delete_files_actions.values():
            list_of_actual_files_to_delete.extend([file.filename for file in action.files])

        self.assertCountEqual([
                'orange.txt',
                'mango.dat',
                'cheese.exe',
                'salad.log',
                'setup.cfg',
                'settings.json'
            ],
            list_of_actual_files_to_delete)

    def test_creates_move_action_for_renamed_files(self) -> None:
        update_sequence: UpdateSequenceSchema = determine_update_sequence(self.update_strategy, self.temp_directory, self.list_of_files_to_emplace)

        list_of_actual_files_to_move: list[tuple[str, str]] = []
        action: IMoveFilesAction
        for action in update_sequence.move_files_actions.values():
            list_of_actual_files_to_move.extend([(file.original_filename, file.new_filename) for file in action.files])

        self.assertCountEqual([
                ('config.ini', 'config.toml'),
                ('default.css', 'light.css')
            ],
            list_of_actual_files_to_move)

    def test_creates_emplace_action_for_new_and_changed_files(self) -> None:
        update_sequence: UpdateSequenceSchema = determine_update_sequence(self.update_strategy, self.temp_directory, self.list_of_files_to_emplace)

        list_of_actual_files_to_emplace: list[tuple[str, str]] = []
        action: IEmplaceFilesAction
        for action in update_sequence.emplace_files_actions.values():
            list_of_actual_files_to_emplace.extend([(file.source_filename, file.target_filename) for file in action.files])

        self.assertCountEqual([
                (str(FAKE_HEXDIGEST_A), 'winApp.exe'),
                (str(FAKE_HEXDIGEST_B), 'linApp')
            ],
            list_of_actual_files_to_emplace)

    def test_actions_are_in_correct_key_order(self) -> None:
        update_sequence: UpdateSequenceSchema = determine_update_sequence(self.update_strategy, self.temp_directory, self.list_of_files_to_emplace)

        list_of_delete_action_keys: list[int] = list(update_sequence.delete_files_actions.keys())
        list_of_move_action_keys: list[int] = list(update_sequence.move_files_actions.keys())
        list_of_emplace_action_keys: list[int] = list(update_sequence.emplace_files_actions.keys())

        self.assertLess(max(list_of_delete_action_keys), min(list_of_move_action_keys))
        self.assertLess(max(list_of_move_action_keys), min(list_of_emplace_action_keys))

def _date_text(date: datetime) -> str:
    return f'{date.year:04}-{date.month:02}-{date.day:02}_{date.hour:02}-{date.minute:02}-{date.second:02}'

def _unzip_file(zip_filepath: Path, target_path: Path) -> None:
    with ZipFile(zip_filepath) as zip_file:
        zip_info: ZipInfo
        for zip_info in zip_file.filelist:
            zip_file.extract(zip_info, target_path)
            attr: int = zip_info.external_attr >> 16
            if attr:
                os.chmod(Path(target_path, zip_info.filename), zip_info.external_attr >> 16)
