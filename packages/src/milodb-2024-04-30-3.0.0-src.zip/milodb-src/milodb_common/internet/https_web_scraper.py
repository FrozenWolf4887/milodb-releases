# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
import gzip
import socket
import sys
from collections.abc import Callable
from http import HTTPStatus
from http.client import HTTPException, HTTPResponse, HTTPSConnection
from milodb_common.internet.i_web_scraper import IWebScraper, ScrapeResult

_DEFAULT_TIMEOUT_SECONDS: int = 60
_SCHEME_NAME: str = 'https'
_GET_REQUEST: str = 'GET'
_GZIP_ENCODING: str = 'gzip'
_REQUEST_HEADERS: dict[str, str] = {
    'Accept': '*/*',
    'Accept-Encoding': _GZIP_ENCODING,
    'Connection': 'keep-alive',
    'User-Agent': f'MiloDB ({sys.platform})'
}

class HttpsWebScraper(IWebScraper):
    def __init__(self, host_name: str, host_port: int = HTTPSConnection.default_port) -> None:
        self._connection: HTTPSConnection = HTTPSConnection(host_name, host_port, timeout=_DEFAULT_TIMEOUT_SECONDS)
        self._progress_callback: Callable[[str], None] | None = None
        self._error_message: str | None = None

    def get_path_text(self, filepath: str) -> str:
        return f'{_SCHEME_NAME}://{self._connection.host}:{self._connection.port}{filepath}'

    def try_scrape(self, filepath: str, progress_callback: Callable[[str], None]) -> ScrapeResult:
        self._progress_callback = progress_callback
        self._error_message = None
        if self._connect_to_host() and self._send_request(filepath):
            response: HTTPResponse | None = self._receive_response()
            if response:
                content: bytes | None = self._read_data(response)
                if content is not None:
                    return ScrapeResult(None, content)

        return ScrapeResult(self._error_message, bytes())

    def close(self) -> None:
        if self._is_connected:
            self._log('Closing connection')
            self._connection.close()

    @property
    def _is_connected(self) -> bool:
        return self._connection.sock is not None

    def _connect_to_host(self) -> bool:
        if not self._is_connected:
            self._log(f"Connecting to '{self._connection.host}:{self._connection.port}'")
            try:
                self._connection.connect()
            except socket.error as ex:
                self._error_message = str(ex)
                return False
        return True

    def _send_request(self, filepath: str) -> bool:
        self._log(f"Sending {_GET_REQUEST} request '{filepath}'")
        try:
            self._connection.request(_GET_REQUEST, filepath, headers=_REQUEST_HEADERS)
        except (HTTPException, socket.error) as ex:
            self._error_message = str(ex)
            return False
        return True

    def _receive_response(self) -> HTTPResponse | None:
        self._log('Receiving response')
        try:
            response: HTTPResponse = self._connection.getresponse()
        except (HTTPException, socket.error) as ex:
            self._error_message = str(ex)
            return None

        if response.status != HTTPStatus.OK:
            self._error_message = f'Request failed with response: {response.status} {response.reason}'
            try:
                response.read()
            except (HTTPException, socket.error) as ex:
                self._error_message += f' and {ex}'
            return None
        return response

    def _read_data(self, response: HTTPResponse) -> bytes | None:
        self._log('Reading received data')
        try:
            content: bytes = response.read()
        except (HTTPException, socket.error) as ex:
            self._error_message = str(ex)
            return None

        content_type: str = response.getheader('Content-Type') or 'unspecified'
        content_encoding: str = response.getheader('Content-Encoding') or 'unspecified'
        self._log(f"Received {len(content):,} bytes of type '{content_type}' encoded as '{content_encoding}'")

        if response.getheader('Connection') == 'close':
            self._log('Closing connection at request of server')
            self._connection.close()

        if _GZIP_ENCODING in content_encoding:
            self._log('Decompressing received data')
            try:
                content = gzip.decompress(content)
            except gzip.BadGzipFile as ex:
                self._error_message = str(ex)
                return None
            self._log(f"Decompressed data is {len(content):,} bytes")

        return content

    def _log(self, message: str) -> None:
        if self._progress_callback:
            self._progress_callback(message)
