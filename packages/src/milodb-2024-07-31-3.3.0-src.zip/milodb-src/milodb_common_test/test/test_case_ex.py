# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
import unittest
from typing import TypeGuard, TypeVar
from unittest.util import safe_repr

_T = TypeVar("_T")

class TestCaseEx(unittest.TestCase):
    def assert_is_not_none(self, obj: _T | None, msg: str | None = None) -> TypeGuard[_T]:
        if obj is None:
            self.fail(msg or 'unexpectedly None')
        return True

    def assert_is_instance(self, obj: object, cls: type[_T]) -> TypeGuard[_T]:
        if not isinstance(obj, cls):
            self.fail(f'{safe_repr(obj)} is not an instance of {cls!r}')
        return True
