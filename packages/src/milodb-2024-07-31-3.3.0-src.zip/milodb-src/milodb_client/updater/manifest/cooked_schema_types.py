# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from collections.abc import Iterator, Mapping, Sequence
from typing import Generic, TypeVar, overload
from milodb_client.updater.manifest.i_schema_types import IItem, ITypedItem, ITypedKey

_BaseKeyT = TypeVar('_BaseKeyT')
_BaseItemT = TypeVar('_BaseItemT')
_ItemT = TypeVar('_ItemT', bound=IItem)

class CookedDictionary(Generic[_BaseKeyT, _ItemT], Mapping[_BaseKeyT, _ItemT]):
    def __init__(self, mapping: Mapping[ITypedKey[_BaseKeyT], _ItemT]) -> None:
        self._mapping: Mapping[ITypedKey[_BaseKeyT], _ItemT] = mapping

    def __str__(self) -> str:
        return ', '.join(f'{{{key}: {value}}}' for key, value in self.items())

    def __len__(self) -> int:
        return len(self._mapping)

    def __getitem__(self, __key: _BaseKeyT) -> _ItemT:
        key: ITypedKey[_BaseKeyT]
        value: _ItemT
        for key, value in self._mapping.items():
            if key.get_key_value() == __key:
                return value
        raise KeyError

    def __iter__(self) -> Iterator[_BaseKeyT]:
        key: ITypedKey[_BaseKeyT]
        for key in self._mapping:
            yield key.get_key_value()

class CookedList(Generic[_BaseItemT], Sequence[_BaseItemT]):
    def __init__(self, sequence: Sequence[ITypedItem[_BaseItemT]]) -> None:
        self._sequence: Sequence[ITypedItem[_BaseItemT]] = sequence

    @overload
    def __getitem__(self, index: int) -> _BaseItemT:
        ...
    @overload
    def __getitem__(self, index: slice) -> Sequence[_BaseItemT]:
        ...
    def __getitem__(self, index: int | slice) -> _BaseItemT | Sequence[_BaseItemT]:
        if isinstance(index, slice):
            return [ item.get_item_value() for item in self._sequence.__getitem__(index) ]
        return self._sequence[index].get_item_value()

    def __len__(self) -> int:
        return len(self._sequence)
