# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from abc import ABC, abstractmethod
from collections.abc import MutableSequence, Sequence
from milodb_client.database.tease import TeaseProperty, TeaseStrListProperty
from milodb_client.database.tease_page import TeasePage

class IFieldMatch(ABC):
    class Indices:
        def __init__(self, start_index: int, end_index: int) -> None:
            self._start_index = start_index
            self._end_index = end_index

        @staticmethod
        def whole_match() -> 'IFieldMatch.Indices':
            return IFieldMatch.Indices(0, 0)

        @property
        def is_whole_match(self) -> bool:
            return (self._start_index == 0) and (self._end_index == 0)

        @property
        def start_index(self) -> int:
            return self._start_index

        @property
        def end_index(self) -> int:
            return self._end_index

    @property
    @abstractmethod
    def list_of_indices(self) -> Sequence[Indices]:
        pass

class FieldItemMatch(IFieldMatch):
    def __init__(self, tease_property: TeaseProperty, list_of_indices: MutableSequence[IFieldMatch.Indices]) -> None:
        self._tease_property: TeaseProperty = tease_property
        self._list_of_indices: MutableSequence[IFieldMatch.Indices] = list_of_indices

    @property
    def list_of_indices(self) -> MutableSequence[IFieldMatch.Indices]:
        return self._list_of_indices

    @property
    def tease_property(self) -> TeaseProperty:
        return self._tease_property

class FieldListMatch(IFieldMatch):
    def __init__(self, tease_property: TeaseStrListProperty, index_of_block: int, list_of_indices: MutableSequence[IFieldMatch.Indices]) -> None:
        self._tease_property: TeaseStrListProperty = tease_property
        self._index_of_block: int = index_of_block
        self._list_of_indices: MutableSequence[IFieldMatch.Indices] = list_of_indices

    @property
    def list_of_indices(self) -> MutableSequence[IFieldMatch.Indices]:
        return self._list_of_indices

    @property
    def tease_property(self) -> TeaseStrListProperty:
        return self._tease_property

    @property
    def index_of_block(self) -> int:
        return self._index_of_block

class FieldPageListMatch(IFieldMatch):
    def __init__(self, page: TeasePage, index_of_page: int, list_of_indices: MutableSequence[IFieldMatch.Indices]) -> None:
        self._page: TeasePage = page
        self._index_of_page: int = index_of_page
        self._list_of_indices: MutableSequence[IFieldMatch.Indices] = list_of_indices

    @property
    def page(self) -> TeasePage:
        return self._page

    @property
    def list_of_indices(self) -> MutableSequence[IFieldMatch.Indices]:
        return self._list_of_indices

    @property
    def index_of_page(self) -> int:
        return self._index_of_page
