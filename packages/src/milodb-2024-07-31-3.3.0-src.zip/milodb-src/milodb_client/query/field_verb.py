# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
import datetime
from abc import ABC, abstractmethod
from collections.abc import Callable
from milodb_client.database.tease import TeaseDateProperty, TeaseFloatProperty, TeaseIntProperty, TeaseStrListProperty, TeaseStrProperty, TeaseTypeProperty
from milodb_client.query.field_predicate import IFieldAuthorStatusPredicate, IFieldDatePredicate, IFieldFloatPredicate, IFieldIntPredicate, IFieldPageListPredicate, IFieldStatusPredicate, IFieldStrListPredicate, IFieldStrPredicate, IFieldTotmPredicate, IFieldTypePredicate
from milodb_client.query.query import IQuery
from milodb_common.command_framework.argument_stream import ArgumentStream
from milodb_common.types.partial_date import PartialDate

class IFieldVerb(ABC):
    @abstractmethod
    def create_query(self, argument_stream: ArgumentStream) -> IQuery:
        pass

class FieldFloatVerb(IFieldVerb):
    def __init__(self, tease_property: TeaseFloatProperty, field_predicate: type[IFieldFloatPredicate], compare_func: Callable[[float, float], bool]) -> None:
        self._tease_property: TeaseFloatProperty = tease_property
        self._field_predicate: type[IFieldFloatPredicate] = field_predicate
        self._compare_func: Callable[[float, float], bool] = compare_func

    def create_query(self, argument_stream: ArgumentStream) -> IQuery:
        return self._field_predicate(self._tease_property, argument_stream, self._compare_func)

class FieldIntVerb(IFieldVerb):
    def __init__(self, tease_property: TeaseIntProperty, field_predicate: type[IFieldIntPredicate], compare_func: Callable[[int, int], bool]) -> None:
        self._tease_property: TeaseIntProperty = tease_property
        self._field_predicate = field_predicate
        self._compare_func: Callable[[int, int], bool] = compare_func

    def create_query(self, argument_stream: ArgumentStream) -> IQuery:
        return self._field_predicate(self._tease_property, argument_stream, self._compare_func)

class FieldStrVerb(IFieldVerb):
    def __init__(self, tease_property: TeaseStrProperty, field_predicate: type[IFieldStrPredicate]) -> None:
        self._tease_property: TeaseStrProperty = tease_property
        self._field_predicate: type[IFieldStrPredicate] = field_predicate

    def create_query(self, argument_stream: ArgumentStream) -> IQuery:
        return self._field_predicate(self._tease_property, argument_stream)

class FieldStrListVerb(IFieldVerb):
    def __init__(self, tease_property: TeaseStrListProperty, field_predicate: type[IFieldStrListPredicate]) -> None:
        self._tease_property: TeaseStrListProperty = tease_property
        self._field_predicate: type[IFieldStrListPredicate] = field_predicate

    def create_query(self, argument_stream: ArgumentStream) -> IQuery:
        return self._field_predicate(self._tease_property, argument_stream)

class FieldTypeVerb(IFieldVerb):
    def __init__(self, tease_property: TeaseTypeProperty, field_predicate: type[IFieldTypePredicate]) -> None:
        self._tease_property: TeaseTypeProperty = tease_property
        self._field_predicate: type[IFieldTypePredicate] = field_predicate

    def create_query(self, argument_stream: ArgumentStream) -> IQuery:
        return self._field_predicate(self._tease_property, argument_stream)

class FieldDateVerb(IFieldVerb):
    def __init__(self, tease_property: TeaseDateProperty, field_predicate: type[IFieldDatePredicate], compare_func: Callable[[datetime.date, PartialDate], bool]) -> None:
        self._tease_property: TeaseDateProperty = tease_property
        self._field_predicate: type[IFieldDatePredicate] = field_predicate
        self._compare_func: Callable[[datetime.date, PartialDate], bool] = compare_func

    def create_query(self, argument_stream: ArgumentStream) -> IQuery:
        return self._field_predicate(self._tease_property, argument_stream, self._compare_func)

class FieldTotmVerb(IFieldVerb):
    def __init__(self, field_predicate: type[IFieldTotmPredicate]) -> None:
        self._field_predicate: type[IFieldTotmPredicate] = field_predicate

    def create_query(self, argument_stream: ArgumentStream) -> IQuery:
        return self._field_predicate(argument_stream)

class FieldStatusVerb(IFieldVerb):
    def __init__(self, field_predicate: type[IFieldStatusPredicate]) -> None:
        self._field_predicate: type[IFieldStatusPredicate] = field_predicate

    def create_query(self, argument_stream: ArgumentStream) -> IQuery:
        return self._field_predicate(argument_stream)

class FieldAuthorStatusVerb(IFieldVerb):
    def __init__(self, field_predicate: type[IFieldAuthorStatusPredicate]) -> None:
        self._field_predicate: type[IFieldAuthorStatusPredicate] = field_predicate

    def create_query(self, argument_stream: ArgumentStream) -> IQuery:
        return self._field_predicate(argument_stream)

class FieldPageListVerb(IFieldVerb):
    def __init__(self, field_predicate: type[IFieldPageListPredicate]) -> None:
        self._field_predicate: type[IFieldPageListPredicate] = field_predicate

    def create_query(self, argument_stream: ArgumentStream) -> IQuery:
        return self._field_predicate(argument_stream)
