# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from collections.abc import Callable, Mapping, Sequence
from milodb_client.config.config_schema import CONFIG_SCHEMA
from milodb_client.config.framework import IConfig, IConfigGroup, IConfigLeaf, IPersistentConfig
from milodb_common.command_framework.argument_stream import ArgumentStream
from milodb_common.command_framework.candidate_text import CandidateText
from milodb_common.command_framework.i_command import CommandLoaderError, CommandLoaderResult
from milodb_common.command_framework.i_help_info import IHelpInfo
from milodb_common.output.print.i_printer import IPrinter
from milodb_common.parser.token import Token

_PATH_DIVIDER_CHAR: str = '/'

def load(argument_stream: ArgumentStream, config: IPersistentConfig, config_schema: IConfigGroup, normal_printer: IPrinter, warning_printer: IPrinter, error_printer: IPrinter) -> CommandLoaderResult:
    map_of_action_to_subcommand_loader: Mapping[str, Callable[[], CommandLoaderResult]] = {
        'get': lambda: load_get(config, config_schema, normal_printer, argument_stream),
        'purge': lambda: load_purge(config, normal_printer, warning_printer, error_printer, argument_stream),
    }
    loader: Callable[[], CommandLoaderResult] = argument_stream.pop_dict_value(map_of_action_to_subcommand_loader)
    return loader()

def load_get(config: IConfig, config_schema: IConfigGroup, normal_printer: IPrinter, argument_stream: ArgumentStream) -> CommandLoaderResult:
    argument_stream.set_keep_delimiters(_PATH_DIVIDER_CHAR)
    traverse_tree: _TraverseTree = _TraverseTree(config, config_schema)
    argument_stream.for_each(argument_stream.pop_optional_token, traverse_tree.process_token)
    argument_stream.fail_if_not_empty()
    return CommandLoaderResult(
        lambda: execute_get(config, traverse_tree.group, traverse_tree.leaf, normal_printer),
        _get_list_of_candidate_text_for_group(traverse_tree.group) if not traverse_tree.leaf else [],
    )

def load_purge(config: IPersistentConfig, normal_printer: IPrinter, warning_printer: IPrinter, error_printer: IPrinter, argument_stream: ArgumentStream) -> CommandLoaderResult:
    argument_stream.fail_if_not_empty()
    return CommandLoaderResult(
        lambda: execute_purge(config, normal_printer, warning_printer, error_printer),
        [],
    )

def execute_get(config: IConfig, group: IConfigGroup, leaf: IConfigLeaf | None, normal_printer: IPrinter) -> None:
    _PrintTree(config, normal_printer).print(group, leaf)

def execute_purge(config: IPersistentConfig, normal_printer: IPrinter, warning_printer: IPrinter, error_printer: IPrinter) -> None:
    if config.try_purge(normal_printer):
        config.save(normal_printer, warning_printer, error_printer)
    else:
        normal_printer.writeln('No entries found to purge')

class Help(IHelpInfo):
    def get_one_line_summary(self) -> str:
        return "Views and edits entries within the configuration"

    def get_detailed_summary(self) -> str:
        return (
            "Arguments: get|purge\r"
            "  get   [path to config group/item]\r"
            "  purge\n"
            f"The path to a config group is a sequence of names separated by a '{_PATH_DIVIDER_CHAR}'."
            f" For example, '{CONFIG_SCHEMA.commands.open.launch_option.full_path}'.\n"
            "The 'purge' subcommand removes redundant or unknown entries from the configuration file.\n"
            "Example:\r"
            "  \tShow the ANSI matching text highlight colour\r"
            f"  > \tconfig get {CONFIG_SCHEMA.format.ansi.colour.matching_text.full_path}\r"
            "Example:\r"
            "  \tShow all of the BBCODE text colours\r"
            f"  > \tconfig get {CONFIG_SCHEMA.format.bbcode.colour.full_path}"
            "Example:\r"
            "  \tPurge redundant entries\r"
            f"  > \tconfig purge"
        )

class _PrintTree:
    def __init__(self, config: IConfig, normal_printer: IPrinter) -> None:
        self._config: IConfig = config
        self._normal_printer: IPrinter = normal_printer

    def print(self, group: IConfigGroup, leaf: IConfigLeaf | None) -> None:
        if leaf:
            self._normal_printer.writeln(f" Leaf: {leaf.full_path} = '{leaf.fetch_value_or_default(self._config)}'")
        else:
            self._normal_printer.writeln(f'Group: {group.full_path}')
            child_leaf: IConfigLeaf
            for child_leaf in group.list_of_child_leaves:
                self.print(group, child_leaf)
            child_group: IConfigGroup
            for child_group in group.list_of_child_groups:
                self.print(child_group, None)

class _TraverseTree:
    def __init__(self, config: IConfig, config_schema: IConfigGroup) -> None:
        self._config: IConfig = config
        self._last_token: Token | None = None
        self._last_non_divider_token: Token | None = None
        self._current_group: IConfigGroup = config_schema
        self._leaf: IConfigLeaf | None = None
        self._is_expecting_path_divider: bool = False

    def process_token(self, token: Token) -> bool:
        """Process the token to traverse the path.

        ### Raises:
        - CommandLoaderError
        """
        self._last_token = token

        if self._is_expecting_path_divider:
            if token.text != _PATH_DIVIDER_CHAR:
                msg = f"Expected path divider '{_PATH_DIVIDER_CHAR}' after '{self._current_group.full_path}'"
                raise CommandLoaderError(msg, token, [CandidateText(_PATH_DIVIDER_CHAR, '')])
            self._is_expecting_path_divider = False
            return True

        self._last_non_divider_token = token

        name_of_group_or_leaf: str = token.text.strip()
        leaf: IConfigLeaf | None = self._current_group.try_find_child_leaf(name_of_group_or_leaf)
        if leaf:
            self._leaf = leaf
            return False

        group: IConfigGroup | None = self._current_group.try_find_child_group(name_of_group_or_leaf)
        if group:
            self._current_group = group
            self._is_expecting_path_divider = True
        else:
            msg = f"Unrecognised config group or leaf '{name_of_group_or_leaf}' within '{self._current_group.full_path}'"
            raise CommandLoaderError(msg, token, _get_list_of_candidate_text_for_group(self._current_group))

        return True

    @property
    def last_token(self) -> Token | None:
        return self._last_token

    @property
    def last_non_divider_token(self) -> Token | None:
        return self._last_non_divider_token

    @property
    def group(self) -> IConfigGroup:
        return self._current_group

    @property
    def leaf(self) -> IConfigLeaf | None:
        return self._leaf

def _get_list_of_candidate_text_for_group(group: IConfigGroup) -> Sequence[CandidateText]:
    list_of_candidate_text: Sequence[CandidateText] = [
        CandidateText(child_group.key_name, _PATH_DIVIDER_CHAR) for child_group in group.list_of_child_groups
    ] + [
        CandidateText(leaf.key_name, ' ') for leaf in group.list_of_child_leaves
    ]
    return list_of_candidate_text
