# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from typing import TYPE_CHECKING
from milodb_client.commands.word_wrapper import WordWrapper
from milodb_common.command_framework.argument_stream import ArgumentStream
from milodb_common.command_framework.candidate_text import CandidateText
from milodb_common.command_framework.i_command import CommandLoaderError, CommandLoaderResult
from milodb_common.command_framework.i_command_factory import ICommandFactory
from milodb_common.command_framework.i_help_info import IHelpInfo
from milodb_common.output.print.i_printer import IPrinter
if TYPE_CHECKING:
    from collections.abc import Sequence
    from milodb_common.parser.token import Token

def load(argument_stream: ArgumentStream, command_factory: ICommandFactory, normal_printer: IPrinter) -> CommandLoaderResult:
    command_name_token: Token | None = argument_stream.pop_optional_token()
    if command_name_token:
        command_class_help: IHelpInfo | None = command_factory.try_get_command_help_from_name(command_name_token.text)
        if command_class_help:
            argument_stream.fail_if_not_empty()
            return CommandLoaderResult(
                lambda: execute_command_help(command_class_help, normal_printer),
                [],
            )
        msg = 'Unrecognised command name'
        raise CommandLoaderError(msg, command_name_token, CandidateText.space_delimited_list(command_factory.get_list_of_command_names()))
    return CommandLoaderResult(
        lambda: execute_summary_help(command_factory, normal_printer),
        CandidateText.space_delimited_list(command_factory.get_list_of_command_names()),
    )

def execute_summary_help(command_factory: ICommandFactory, normal_printer: IPrinter) -> None:
    text: str = (
        'Run queries on the database to retrieve matches and provide results in a variety of'
        ' formats.\n'
        'For example, perform a query against teases that contain the text "cookies" in'
        ' any of the pages, and show the matching text results for each tease:\r'
        '  > \tquery text contains cookies\r'
        '  > \tshow\n'
        'List of commands:'
    )

    list_of_command_names: Sequence[str] = sorted(command_factory.get_list_of_command_names())
    length_of_longest_command_name = max(len(name) for name in list_of_command_names)

    command_name: str
    for command_name in list_of_command_names:
        command_class_help: IHelpInfo | None = command_factory.try_get_command_help_from_name(command_name)
        if command_class_help:
            summary_text: str = command_class_help.get_one_line_summary()
            text += f'\r{command_name:>{length_of_longest_command_name}}  \t{summary_text}'

    text += (
        "\nUse 'help <command name>' for detailed information on a specific command.\r"
        'Press <TAB> once to complete command names and arguments where possible.\r'
        'Press <TAB> twice to get a list of suggestions for command names and arguments.\r'
        'Press <UP>/<DOWN> to see previously entered commands.\n'
    )

    _print_help(text, normal_printer)

def execute_command_help(command_class_help: IHelpInfo, normal_printer: IPrinter) -> None:
    _print_help((
        f"{command_class_help.get_one_line_summary()}.\n"
        f"{command_class_help.get_detailed_summary()}"
    ), normal_printer)

class Help(IHelpInfo):
    def get_one_line_summary(self) -> str:
        return "Prints the list of commands or detailed help for a specific command"

    def get_detailed_summary(self) -> str:
        return (
            "Arguments: [command name]\n"
            "Provides details of the specified command including examples where appropriate.\n"
            "When used without arguments, summary help information is shown with the list of"
            " commands available.\n"
            "Example:\r"
            "  Show the help summary\r"
            "  > help\r"
            "Example:\r"
            "  Show detailed help for the query command\r"
            "  > help query\n"
        )

def _print_help(text: str, normal_printer: IPrinter) -> None:
    text = text.strip().replace('\n', '\n\n').replace('\r', '\n')
    text = WordWrapper(text, 80).text
    normal_printer.writeln(text)
