# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from collections.abc import Iterable, Sequence
from typing import TYPE_CHECKING
from milodb_client.commands.sort_keys import ISortKey, OrderedSortKey
from milodb_client.commands.tease_match_sorter import ITeaseMatchSorter
from milodb_client.query.tease_match import TeaseMatch
from milodb_common.command_framework.argument_stream import ArgumentStream
from milodb_common.command_framework.candidate_text import CandidateText
from milodb_common.command_framework.i_command import CommandLoaderResult
from milodb_common.command_framework.i_help_info import IHelpInfo
from milodb_common.datum.ref_datum import RefDatum
from milodb_common.output.print.i_printer import IPrinter
if TYPE_CHECKING:
    from milodb_common.parser.token import Token

def load(argument_stream: ArgumentStream, ref_list_of_tease_matches: RefDatum[Sequence[TeaseMatch]], tease_match_sorter: ITeaseMatchSorter, ref_list_of_active_sort_keys: RefDatum[Sequence[OrderedSortKey]], list_of_available_sort_keys: Sequence[ISortKey], normal_printer: IPrinter) -> CommandLoaderResult:
    map_of_names_to_sort_keys: dict[str, ISortKey] = {}
    sort_key: ISortKey
    for sort_key in list_of_available_sort_keys:
        map_of_names_to_sort_keys[sort_key.get_name()] = sort_key
        map_of_names_to_sort_keys['-' + sort_key.get_name()] = sort_key

    def accumulate_sort_key() -> OrderedSortKey | None:
        ordered_sort_key: OrderedSortKey | None = None
        sort_key_and_token: tuple[ISortKey, Token] | None = argument_stream.pop_optional_dict_value_and_token(map_of_names_to_sort_keys)
        if sort_key_and_token:
            sort_key = sort_key_and_token[0]
            token: Token = sort_key_and_token[1]
            del map_of_names_to_sort_keys[sort_key.get_name()]
            del map_of_names_to_sort_keys[f'-{sort_key.get_name()}']
            is_ascending: bool = token.text[0] != '-'
            ordered_sort_key = OrderedSortKey(sort_key, is_ascending=is_ascending)
        return ordered_sort_key

    new_list_of_active_sort_keys: Sequence[OrderedSortKey] = ArgumentStream.pop_list(accumulate_sort_key)
    if new_list_of_active_sort_keys:
        return CommandLoaderResult(
            lambda: execute_change(new_list_of_active_sort_keys, ref_list_of_tease_matches, tease_match_sorter, ref_list_of_active_sort_keys, normal_printer),
            CandidateText.space_delimited_list(map_of_names_to_sort_keys.keys()),
        )
    return CommandLoaderResult(
        lambda: execute_print(ref_list_of_active_sort_keys.get(), list_of_available_sort_keys, normal_printer),
        CandidateText.space_delimited_list(map_of_names_to_sort_keys.keys()),
    )

def execute_print(list_of_active_sort_keys: Sequence[OrderedSortKey], list_of_available_sort_keys: Sequence[ISortKey], normal_printer: IPrinter) -> None:
    normal_printer.writeln(f"Current sorting keys are {[ ('' if sort_key.is_ascending() else '-') + sort_key.get_name() for sort_key in list_of_active_sort_keys ]}")
    normal_printer.writeln(f"Available keys are {sorted([ sort_key.get_name() for sort_key in list_of_available_sort_keys ])}")

def execute_change(new_list_of_active_sort_keys: Sequence[OrderedSortKey], ref_list_of_tease_matches: RefDatum[Sequence[TeaseMatch]], tease_match_sorter: ITeaseMatchSorter, ref_list_of_active_sort_keys: RefDatum[Sequence[OrderedSortKey]], normal_printer: IPrinter) -> None:
    ref_list_of_active_sort_keys.set(new_list_of_active_sort_keys)
    normal_printer.writeln(f"Changed sorting keys to {[ ('' if sort_key.is_ascending() else '-') + sort_key.get_name() for sort_key in ref_list_of_active_sort_keys.get() ]}")
    ref_list_of_tease_matches.set(tease_match_sorter.sort(ref_list_of_tease_matches.get(), ref_list_of_active_sort_keys.get()))

class Help(IHelpInfo):
    def __init__(self, list_of_available_sort_keys: Iterable[ISortKey]) -> None:
        self._list_of_available_sort_keys = list_of_available_sort_keys

    def get_one_line_summary(self) -> str:
        return "Sorts the list of teases by specific fields"

    def get_detailed_summary(self) -> str:
        sort_key_help_text: str = ''
        sort_key: ISortKey
        for sort_key in self._list_of_available_sort_keys:
            if sort_key_help_text:
                sort_key_help_text += '\r'
            sort_key_help_text += f'  {sort_key.get_name():<8} : \t{sort_key.get_description()}'

        return (
            "Arguments: [list of sort keys]\n"
            "Sets the sorting order for the display of teases. More than one key can be"
            " specified to determine secondary, tertiary, etc. ordering.\n"
            "Keys:\r"
            f'{sort_key_help_text}\n'
            "Keys can be prefixed with '-' to indicate a descending order, otherwise the"
            " order defaults to ascending.\n"
            "When used without arguments, the current sorting keys are shown.\n"
            "Example:\r"
            "  \tSort by teaseId\r"
            "  > \tsort teaseId\r"
            "Example:\r"
            "  \tSort by rating (ascending) and date (descending)\r"
            "  > \tsort rating -date\n"
            "See also:\r"
            "  \tlist\n"
            )
