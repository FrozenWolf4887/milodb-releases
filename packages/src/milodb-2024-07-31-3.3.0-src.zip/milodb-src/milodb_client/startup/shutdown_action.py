# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
import os
import subprocess
import sys
from abc import ABC, abstractmethod
from collections.abc import Iterable
from pathlib import Path
from milodb_client.startup.command_line import Argument
from milodb_client.startup.output import print_fatal_and_prompt_to_continue
from milodb_common.output.print.i_printer import IPrinter

class IShutdownAction(ABC):
    @abstractmethod
    def perform_action(self) -> int:
        pass

class RestartToPerformUpdateAction(IShutdownAction):
    def __init__(self, *, temp_application_filepath: Path, update_sequence_filepath: Path, normal_printer: IPrinter, fatal_printer: IPrinter) -> None:
        self._temp_application_filepath: Path = temp_application_filepath
        self._update_sequence_filepath: Path = update_sequence_filepath
        self._normal_printer: IPrinter = normal_printer
        self._fatal_printer: IPrinter = fatal_printer

    def perform_action(self) -> int:
        self._normal_printer.writeln('Restarting application to perform update...')
        return _launch(self._temp_application_filepath, [Argument.PERFORM_UPDATE, self._update_sequence_filepath], self._normal_printer, self._fatal_printer)

class RestartToCompleteUpdateAction(IShutdownAction):
    def __init__(self, *, new_application_filepath: Path, temp_application_filepath: Path, update_sequence_filepath: Path, temp_directory: Path, normal_printer: IPrinter, fatal_printer: IPrinter) -> None:
        self._new_application_filepath: Path = new_application_filepath
        self._temp_application_filepath: Path = temp_application_filepath
        self._update_sequence_filepath: Path = update_sequence_filepath
        self._temp_directory: Path = temp_directory
        self._normal_printer: IPrinter = normal_printer
        self._fatal_printer: IPrinter = fatal_printer

    def perform_action(self) -> int:
        self._normal_printer.writeln('Restarting application to complete update...')
        return _launch(self._new_application_filepath, [Argument.PURGE_TEMP_DIRECTORY, self._temp_directory], self._normal_printer, self._fatal_printer)

def _launch(application_filepath: Path, command_line: Iterable[str | Path], normal_printer: IPrinter, fatal_printer: IPrinter) -> int:
    try:
        if sys.platform == 'win32':
            normal_printer.writeln(f"Launching win32 '{application_filepath}'")
            subprocess.Popen( # pylint: disable=consider-using-with # noqa: S603 `subprocess` call: check for execution of untrusted input
                [application_filepath, Argument.WAIT_PID, str(os.getpid()), *command_line],
                start_new_session=True,
                creationflags=subprocess.CREATE_NEW_CONSOLE)
        else:
            normal_printer.writeln(f"Launching POSIX '{application_filepath}'")
            # Note: Ruff error S606 suggests to use subprocess.Popen(), but that can't do the same thing as os.execv() which
            #       replaces the currently running executable with the new one.
            os.execv(application_filepath, (application_filepath, *command_line)) # noqa: S606 Starting a process without a shell
    except OSError as ex:
        print_fatal_and_prompt_to_continue(f'Failed to start application: {ex}', fatal_printer)
        return 1

    return 0
