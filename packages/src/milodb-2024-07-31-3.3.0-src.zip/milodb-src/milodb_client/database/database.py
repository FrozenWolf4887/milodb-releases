# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
import datetime
import json
import lzma
from collections.abc import Iterable, Mapping, Sequence
from pathlib import Path
from milodb_client.database.tease import Tease
from milodb_client.output.print_timed_activity import PrintTimedActivity
from milodb_common.output.print.i_printer import IPrinter

_DATABASE_FORMAT_KEY: str = 'fmt'
_DATABASE_FORMAT_VALUE: int = 2
_DATABASE_TEASES_KEY: str = 'tss'

def load_teases_from_database_file(database_filepath: Path, fatal_printer: IPrinter) -> list[Tease]:
    with PrintTimedActivity('Load database\n', 'Load completed: '):
        try:
            return _load_from_file(database_filepath)
        except _LoadError as ex:
            fatal_printer.writeln(str(ex))
        return []

def try_get_oldest_tease_date(list_of_teases: Iterable[Tease]) -> datetime.date | None:
    if list_of_teases:
        return min(tease.date() for tease in list_of_teases)
    return None

def try_get_newest_tease_date(list_of_teases: Iterable[Tease]) -> datetime.date | None:
    if list_of_teases:
        return max(tease.date() for tease in list_of_teases)
    return None

def try_get_tease(tease_id: int, list_of_teases: Iterable[Tease]) -> Tease | None:
    tease: Tease
    for tease in list_of_teases:
        if tease_id == tease.tease_id():
            return tease
    return None

def get_teases_by_author_id(author_id: int, list_of_teases: Iterable[Tease]) -> Sequence[Tease]:
    return [ tease for tease in list_of_teases if author_id == tease.author_id() ]

class _LoadError(Exception):
    pass

def _load_from_file(database_filepath: Path) -> list[Tease]:
    raw_file_contents: bytes = _read_file(database_filepath)
    file_contents: bytes = _unpack_contents(raw_file_contents)
    json_dict: Mapping[object, object] = _parse_json(file_contents)
    _check_format(json_dict)
    json_list: Sequence[object] = _get_json_list_of_teases(json_dict)
    return _build_tease_list(json_list)

def _read_file(database_filepath: Path) -> bytes:
    with PrintTimedActivity('  Read', '     : '):
        try:
            with database_filepath.open('rb') as file:
                return file.read()
        except OSError as ex:
            msg = f"File access error: {ex}"
            raise _LoadError(msg) from ex

def _unpack_contents(raw_file_contents: bytes) -> bytes:
    with PrintTimedActivity('  Unpack', '   : '):
        try:
            return lzma.decompress(raw_file_contents)
        except lzma.LZMAError as ex:
            msg = f"Unpack failed: {ex}"
            raise _LoadError(msg) from ex

def _parse_json(file_contents: bytes) -> Mapping[object, object]:
    with PrintTimedActivity('  Parse', '    : '):
        try:
            json_root: object = json.loads(file_contents)
        except json.JSONDecodeError as ex:
            msg = f"JSON decode error: {ex}"
            raise _LoadError(msg) from ex

        if not isinstance(json_root, Mapping):
            msg = 'Database root is not a dictionary'
            raise _LoadError(msg)

        return json_root

def _check_format(json_dict: Mapping[object, object]) -> None:
    raw_format: object = json_dict.get(_DATABASE_FORMAT_KEY)
    if raw_format is None:
        msg = f"Database format key '{_DATABASE_FORMAT_KEY}' missing"
        raise _LoadError(msg)
    if not isinstance(raw_format, int):
        msg = f"Database format key value '{_DATABASE_FORMAT_KEY}' is not an integer"
        raise _LoadError(msg)
    if raw_format != _DATABASE_FORMAT_VALUE:
        msg = f"Database has format '{raw_format}' which is not the expected format '{_DATABASE_FORMAT_VALUE}'"
        raise _LoadError(msg)

def _get_json_list_of_teases(json_dict: Mapping[object, object]) -> Sequence[object]:
    json_list: object = json_dict.get(_DATABASE_TEASES_KEY)
    if json_list is None:
        msg = f"Database teases key '{_DATABASE_TEASES_KEY}' missing"
        raise _LoadError(msg)
    if not isinstance(json_list, Sequence):
        msg = f"Database teases key value '{_DATABASE_TEASES_KEY}' is not a list"
        raise _LoadError(msg)
    return json_list

def _build_tease_list(json_list: Iterable[object]) -> list[Tease]:
    list_of_teases: list[Tease] = []

    with PrintTimedActivity('  Assemble', ' : '):
        index: int
        tease_obj: object
        for index, tease_obj in enumerate(json_list):
            if not isinstance(tease_obj, Mapping):
                msg = f"Database teases index '{index}' is not a dictionary"
                raise _LoadError(msg)
            try:
                tease: Tease = Tease(tease_obj)
            except Tease.LoadError as ex:
                msg = f"Tease load error: {ex}"
                raise _LoadError(msg) from ex
            list_of_teases.append(tease)

    return list_of_teases
