# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
import unittest
from collections.abc import Mapping, Sequence, Set as AbstractSet
from typing import TypeVar

from milodb_client.updater.manifest.i_schema_types import ITypedItem, ITypedKey

KeyT = TypeVar('KeyT')
ValueT = TypeVar('ValueT')

def assert_typed_mapping_equal(test_case: unittest.TestCase, left: Mapping[KeyT, ValueT], right: Mapping[ITypedKey[KeyT], ITypedItem[ValueT]]) -> None:
    set_of_left_keys: AbstractSet[KeyT] = set(left)
    set_of_right_keys: AbstractSet[KeyT] = { key.get_key_value() for key in right }

    set_of_unique_left_keys: AbstractSet[KeyT] = set_of_left_keys - set_of_right_keys
    set_of_unique_right_keys: AbstractSet[KeyT] = set_of_right_keys - set_of_left_keys

    if set_of_unique_left_keys:
        test_case.fail(f"Keys of left {set_of_unique_left_keys} missing from right")
    if set_of_unique_right_keys:
        test_case.fail(f"Keys of right {set_of_unique_right_keys} missing from left")

    right_typed_key: ITypedKey[KeyT]
    right_typed_value: ITypedItem[ValueT]
    for right_typed_key, right_typed_value in right.items():
        left_value: ValueT = left[right_typed_key.get_key_value()]
        test_case.assertEqual(left_value, right_typed_value.get_item_value())

def assert_typed_sequence_equal(test_case: unittest.TestCase, left: Sequence[ValueT], right: Sequence[ITypedItem[ValueT]]) -> None:
    if len(left) != len(right):
        test_case.fail(f"Left sequence has {len(left)} items and right sequence as {len(right)} items")

    index: int
    left_value: ValueT
    for index, left_value in enumerate(left):
        right_typed_value: ITypedItem[ValueT] = right[index]
        test_case.assertEqual(left_value, right_typed_value.get_item_value(), f'Mismatch at index {index}')
