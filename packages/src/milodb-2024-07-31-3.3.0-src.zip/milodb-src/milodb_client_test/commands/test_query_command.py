# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from collections.abc import Sequence
from dataclasses import dataclass, field
from unittest.mock import Mock
from milodb_client.commands import query_command
from milodb_client.commands.sort_keys import OrderedSortKey, RATING_SORT_KEY, TYPE_SORT_KEY
from milodb_client.commands.tease_match_sorter import ITeaseMatchSorter
from milodb_client.database.tease import Tease
from milodb_client.output.format.i_formatter import IFormatter
from milodb_client.output.format.i_formatter_factory import IFormatterCreator
from milodb_client.query.infix_query_parser import IInfixQueryParser, PostfixQuery
from milodb_client.query.postfix_query_executor import IPostfixQueryExecutor, PostfixQueryResult
from milodb_client.query.query import IQuery
from milodb_client.query.tease_match import TeaseMatch
from milodb_client_test.test import fake_teases
from milodb_common.command_framework.argument_stream import ArgumentStream
from milodb_common.command_framework.i_command import CommandLoaderResult
from milodb_common.datum.ref_datum import RefDatum
from milodb_common.output.print.i_printer import IPrinter
from milodb_common_test.commands.test_command_base import CommandTestBase
from milodb_common_test.test.strict_mock import InterfaceMock

_DEFAULT_LIST_OF_TEASES: Sequence[Tease] = [
    fake_teases.TEASE_ID_1000_AUTHOR_ID_4567,
    fake_teases.TEASE_ID_1234_AUTHOR_ID_6431,
    fake_teases.TEASE_ID_5678_AUTHOR_ID_4567,
    fake_teases.TEASE_ID_2000_AUTHOR_ID_6431,
    fake_teases.TEASE_ID_8721_AUTHOR_ID_7213,
]

@dataclass
class _Args:
    list_of_teases: Sequence[Tease] = field(default_factory=lambda: list(_DEFAULT_LIST_OF_TEASES))
    infix_parser: InterfaceMock = field(default_factory=lambda: InterfaceMock(IInfixQueryParser))
    postfix_executor: InterfaceMock = field(default_factory=lambda: InterfaceMock(IPostfixQueryExecutor))
    list_of_tease_matches: RefDatum[Sequence[TeaseMatch]] = field(default_factory=lambda: RefDatum[Sequence[TeaseMatch]]([]))
    tease_match_sorter: InterfaceMock = field(default_factory=lambda: InterfaceMock(ITeaseMatchSorter))
    list_of_active_sort_keys: Sequence[OrderedSortKey] = field(default_factory=list)
    formatter_creator: InterfaceMock = field(default_factory=lambda: InterfaceMock(IFormatterCreator))
    normal_printer: InterfaceMock = field(default_factory=lambda: InterfaceMock(IPrinter))
    warning_printer: InterfaceMock = field(default_factory=lambda: InterfaceMock(IPrinter))
    error_printer: InterfaceMock = field(default_factory=lambda: InterfaceMock(IPrinter))

class TestQueryCommand(CommandTestBase):
    def setUp(self) -> None:
        self._args: _Args = _Args()
        return super().setUp()

    def load_command(self, argument_stream: ArgumentStream) -> CommandLoaderResult:
        return query_command.load(
            argument_stream,
            self._args.list_of_teases,
            self._args.infix_parser,
            self._args.postfix_executor,
            self._args.list_of_tease_matches,
            self._args.tease_match_sorter,
            self._args.list_of_active_sort_keys,
            self._args.formatter_creator,
            self._args.normal_printer,
            self._args.warning_printer,
            self._args.error_printer,
        )

    def test_query_outputs_sorted_list(self) -> None:
        list_of_tease_matches: Sequence[TeaseMatch] = [
            TeaseMatch(1, fake_teases.TEASE_ID_5678_AUTHOR_ID_4567, []),
            TeaseMatch(2, fake_teases.TEASE_ID_8721_AUTHOR_ID_7213, []),
            TeaseMatch(3, fake_teases.TEASE_ID_2000_AUTHOR_ID_6431, []),
            TeaseMatch(4, fake_teases.TEASE_ID_1000_AUTHOR_ID_4567, []),
        ]
        list_of_sorted_tease_matches: Sequence[TeaseMatch] = [
            TeaseMatch(1, fake_teases.TEASE_ID_8721_AUTHOR_ID_7213, []),
            TeaseMatch(2, fake_teases.TEASE_ID_2000_AUTHOR_ID_6431, []),
            TeaseMatch(3, fake_teases.TEASE_ID_5678_AUTHOR_ID_4567, []),
            TeaseMatch(4, fake_teases.TEASE_ID_1000_AUTHOR_ID_4567, []),
        ]
        mock_list_of_queries: Sequence[IQuery] = [InterfaceMock(IQuery), InterfaceMock(IQuery)]
        self._args.infix_parser.convert_to_postfix = Mock(return_value=PostfixQuery(mock_list_of_queries, []))
        self._args.postfix_executor.execute = Mock(return_value=PostfixQueryResult(
            total_match_count = 5,
            max_match_count = 100,
            was_max_match_count_reached = False,
            total_tease_count = 350,
            queried_tease_count = 350,
            list_of_tease_matches = list_of_tease_matches))
        self._args.tease_match_sorter.sort = Mock(return_value=list_of_sorted_tease_matches)
        self._args.list_of_active_sort_keys = [OrderedSortKey(TYPE_SORT_KEY, is_ascending=False), OrderedSortKey(RATING_SORT_KEY, is_ascending=True)]
        formatter: InterfaceMock = InterfaceMock(IFormatter)
        formatter.print_list_of_teases = Mock()
        self._args.formatter_creator.create = Mock(return_value=formatter)
        self.command_load_and_execute(['one', 'two', 'three'])
        self._args.infix_parser.convert_to_postfix.assert_called_once_with(self.argument_stream)
        self._args.postfix_executor.execute.assert_called_once_with(self._args.list_of_teases, mock_list_of_queries, 10_000_000)
        self._args.tease_match_sorter.sort.assert_called_once_with(list_of_tease_matches, self._args.list_of_active_sort_keys)
        self.assertIs(list_of_sorted_tease_matches, self._args.list_of_tease_matches.get())
        self._args.formatter_creator.create.assert_called_once_with(self._args.normal_printer)
        formatter.print_list_of_teases.assert_called_once_with(list_of_sorted_tease_matches)
