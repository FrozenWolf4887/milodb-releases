# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from dataclasses import dataclass, field
from unittest.mock import Mock, call
from milodb_client.commands import ellipsis_command
from milodb_common.command_framework.argument_stream import ArgumentStream
from milodb_common.command_framework.i_command import CommandLoaderResult
from milodb_common.datum.ref_datum import RefDatum
from milodb_common.output.print.i_printer import IPrinter
from milodb_common_test.commands.error_messages import ErrorMessage
from milodb_common_test.commands.test_command_base import CommandTestBase
from milodb_common_test.test.strict_mock import InterfaceMock

@dataclass
class _Args:
    use_ellipsis: RefDatum[bool] = field(default_factory=lambda: RefDatum(True))
    normal_printer: InterfaceMock = field(default_factory=lambda: InterfaceMock(IPrinter))

class TestEllipsisCommand(CommandTestBase):
    def setUp(self) -> None:
        self._args: _Args = _Args()
        return super().setUp()

    def load_command(self, argument_stream: ArgumentStream) -> CommandLoaderResult:
        return ellipsis_command.load(
            argument_stream,
            self._args.use_ellipsis,
            self._args.normal_printer,
        )

    def test_without_arguments_prints_current_setting_without_change(self) -> None:
        for initial_use_ellipsis in (True, False):
            with self.subTest(initial_use_ellipsis=initial_use_ellipsis):
                self.setUp()
                self._args.use_ellipsis.set(initial_use_ellipsis)
                self._args.normal_printer.writeln = Mock()
                self.command_load_and_execute([])
                current_setting: str = 'on' if initial_use_ellipsis else 'off'
                self._args.normal_printer.writeln.assert_has_calls([
                    call(f"Current ellipsis mode is '{current_setting}'"),
                    call("Available options are ['on', 'off']")])
                self.assertEqual(initial_use_ellipsis, self._args.use_ellipsis.get())
                self.assert_next_text(['on', 'off'])

    def test_with_argument_changes_setting_regardless_of_initial_setting(self) -> None:
        for initial_use_ellipsis in (True, False):
            for change_use_ellipsis in (True, False):
                with self.subTest(initial_use_ellipsis=initial_use_ellipsis, change_use_ellipsis=change_use_ellipsis):
                    self.setUp()
                    self._args.use_ellipsis.set(initial_use_ellipsis)
                    self._args.normal_printer.writeln = Mock()
                    new_setting: str = 'on' if change_use_ellipsis else 'off'
                    self.command_load_and_execute([new_setting])
                    self._args.normal_printer.writeln.assert_called_once_with(f"Changed ellipsis mode to '{new_setting}'")
                    self.assertEqual(change_use_ellipsis, self._args.use_ellipsis.get())

    def test_with_invalid_argument_returns_failure(self) -> None:
        self.command_load(['mango'])
        self.assert_argument_error(1, ErrorMessage.INVALID_ENUM, ['on', 'off'])

    def test_with_redundant_argument_returns_failure(self) -> None:
        self.command_load(['on', 'off'])
        self.assert_argument_error(2, ErrorMessage.UNEXPECTED, [])
