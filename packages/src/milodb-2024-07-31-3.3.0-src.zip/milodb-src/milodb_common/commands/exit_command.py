# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from milodb_common.command_framework.argument_stream import ArgumentStream
from milodb_common.command_framework.i_command import CommandLoaderResult
from milodb_common.command_framework.i_help_info import IHelpInfo
from milodb_common.command_framework.quit_flag import QuitFlag

def load(argument_stream: ArgumentStream, quit_flag: QuitFlag) -> CommandLoaderResult:
    argument_stream.fail_if_not_empty()
    return CommandLoaderResult(quit_flag.set, [])

class Help(IHelpInfo):
    def get_one_line_summary(self) -> str:
        return "Exits the application"

    def get_detailed_summary(self) -> str:
        return (
            "Arguments: none\n"
            "Exits the application.\n"
            "Example:\r"
            "  > \texit\n"
        )
