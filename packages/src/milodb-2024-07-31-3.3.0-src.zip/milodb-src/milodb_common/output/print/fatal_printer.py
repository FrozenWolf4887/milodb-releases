# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from milodb_common.output.print.redirectable_printer import RedirectablePrinter

class FatalPrinter(RedirectablePrinter):
    def writeln(self, text: str | None = None) -> None:
        if text:
            self._target_printer.writeln(f'FATAL: {text}')
        else:
            self._target_printer.writeln()
