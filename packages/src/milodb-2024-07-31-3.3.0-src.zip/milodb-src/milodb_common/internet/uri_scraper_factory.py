# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from collections.abc import Callable
from milodb_common.internet.i_uri_scraper_factory import IUriScraperFactory
from milodb_common.internet.i_uri_scraper_pool import IUriScraperPool
from milodb_common.internet.uri_scraper_pool import UriScraperPool

class UriScraperFactory(IUriScraperFactory):
    def new_pool(self, close_callback: Callable[[str], None] | None = None) -> IUriScraperPool:
        return UriScraperPool(close_callback)
