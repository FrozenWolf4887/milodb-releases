# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from abc import abstractmethod
from collections.abc import Callable
from types import TracebackType
from milodb_common.internet.i_uri_scraper import IUriScraper
from milodb_common.internet.scrape_result import ScrapeResult

class IUriScraperPool:
    @abstractmethod
    def __enter__(self) -> IUriScraper:
        pass

    @abstractmethod
    def __exit__(self, exc_type: type[BaseException] | None, exc_value: BaseException | None, traceback: TracebackType | None) -> None:
        pass

    @abstractmethod
    def try_scrape(self, url: str, progress_callback: Callable[[str], None] | None) -> ScrapeResult:
        pass
