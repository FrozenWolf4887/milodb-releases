# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
import json
from collections.abc import Mapping, Sequence
from pathlib import Path
from milodb_common.output.print.i_printer import IPrinter
from milodb_common.variables.i_user_variables import IPersistentUserVariables, VARIABLE_NAME_PATTERN

class FileUserVariables(IPersistentUserVariables):
    def __init__(self, filepath: Path) -> None:
        self._filepath: Path = filepath
        self._map_of_name_to_value: dict[str, str] = {}
        self._load_was_successful: bool = True

    def load(self, normal_printer: IPrinter, warning_printer: IPrinter, error_printer: IPrinter) -> None:
        try:
            with self._filepath.open(encoding='utf-8') as file:
                json_object: object = json.load(file)
        except FileNotFoundError:
            pass
        except (OSError, json.JSONDecodeError) as ex:
            error_printer.writeln(f"Unable to load variables from '{self._filepath}': {ex}")
            self._load_was_successful = False
        else:
            normal_printer.writeln(f"Loaded variables from '{self._filepath}'")
            if isinstance(json_object, Mapping):
                self._map_of_name_to_value = self._validate_config(json_object, error_printer)
            else:
                error_printer.writeln("Root of variables file is not a JSON dictionary")
                self._load_was_successful = False

        if not self._load_was_successful:
            warning_printer.writeln("Variables set or changed at runtime will not be saved to prevent corruption")

    def save(self, normal_printer: IPrinter, warning_printer: IPrinter, error_printer: IPrinter) -> None:
        if self._load_was_successful:
            try:
                with self._filepath.open("w", encoding='utf-8') as file:
                    json.dump(self._map_of_name_to_value, file, indent=4, ensure_ascii=False, sort_keys=True)
            except OSError as ex:
                error_printer.writeln(f"Unable to save variables to '{self._filepath}': {ex}")
            else:
                normal_printer.writeln(f"Saved variables to '{self._filepath}'")
        else:
            warning_printer.writeln('Variables not saved due to initial loading error')

    def set(self, name: str, value: str) -> None:
        self._map_of_name_to_value[name] = value

    def try_retrieve(self, name: str) -> str | None:
        value: object = self._map_of_name_to_value.get(name)
        return value if isinstance(value, str) else None

    def try_delete(self, name: str) -> bool:
        return self._map_of_name_to_value.pop(name, None) is not None

    def get_list_of_names(self) -> Sequence[str]:
        return list(self._map_of_name_to_value)

    def get_list_of_variables(self) -> Sequence[tuple[str, str]]:
        return list(self._map_of_name_to_value.items())

    def _validate_config(self, some_dictionary: Mapping[object, object], error_printer: IPrinter) -> dict[str, str]:
        map_of_name_to_value: dict[str, str] = {}

        index: int
        name: object
        value: object
        for index, (name, value) in enumerate(some_dictionary.items()):
            if isinstance(name, str) and isinstance(value, str):
                map_of_name_to_value[name] = value
            else:
                self._load_was_successful = False
                if not isinstance(name, str):
                    error_printer.writeln(f'Variable at index #{index} has a non string name')
                elif not name:
                    error_printer.writeln(f'Variable at index #{index} has a blank name')
                elif not VARIABLE_NAME_PATTERN.fullmatch(name):
                    error_printer.writeln(f"Variable at index #{index} named '{name}' does not conform to pattern '{VARIABLE_NAME_PATTERN.pattern}'")
                if not isinstance(value, str):
                    error_printer.writeln(f"Variable at index #{index} named '{name}' has a value that is not a string")

        return map_of_name_to_value
