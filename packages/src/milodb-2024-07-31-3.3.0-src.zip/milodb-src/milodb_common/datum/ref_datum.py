# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from typing import Generic, TypeVar

RefT = TypeVar('RefT')

class RefDatum(Generic[RefT]):
    def __init__(self, default: RefT) -> None:
        self._ref: RefT = default

    def set(self, ref: RefT) -> None:
        self._ref = ref

    def get(self) -> RefT:
        return self._ref

    def __bool__(self) -> bool:
        return bool(self._ref)
