# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from milodb_client.output.format.i_formatter import IFormatter
from milodb_common.command_framework.argument_stream import ArgumentStream
from milodb_common.command_framework.candidate_text import CandidateText
from milodb_common.command_framework.i_command import ICommand
from milodb_common.command_framework.i_help_info import IHelpInfo
from milodb_common.datum.ref_datum import RefDatum
from milodb_common.output.print.i_printer import IPrinter

class FormatCommand(ICommand):
    def __init__(self, current_formatter: RefDatum[IFormatter], list_of_formatters: list[IFormatter], normal_printer: IPrinter) -> None:
        self._current_formatter: RefDatum[IFormatter] = current_formatter
        self._list_of_formatters: list[IFormatter] = list_of_formatters
        self._normal_printer: IPrinter = normal_printer
        self._new_formatter: (IFormatter | None) = None

    def load(self, argument_stream: ArgumentStream) -> list[CandidateText]:
        map_of_format_name_to_object: dict[str, IFormatter] = {}
        for formatter in self._list_of_formatters:
            map_of_format_name_to_object[formatter.get_name()] = formatter
        self._new_formatter = argument_stream.pop_optional_dict_value(map_of_format_name_to_object)
        if self._new_formatter is not None:
            argument_stream.fail_if_not_empty()
            return []
        return CandidateText.space_delimited_list(_get_list_of_formatter_names(self._list_of_formatters))

    def execute(self) -> None:
        if self._new_formatter:
            self._current_formatter.set(self._new_formatter)
            self._normal_printer.writeln(f"Changed format to '{self._new_formatter.get_name()}'")
        else:
            self._normal_printer.writeln(f"Current format is '{self._current_formatter.get().get_name()}'")
            self._normal_printer.writeln(f"Available formats are {_get_list_of_formatter_names(self._list_of_formatters)}")

    class Help(IHelpInfo):
        def __init__(self, list_of_formatters: list[IFormatter]) -> None:
            self._list_of_formatters: list[IFormatter] = list_of_formatters

        def get_one_line_summary(self) -> str:
            return "Sets the formatting used in the output of commands"

        def get_detailed_summary(self) -> str:
            return (
                f"Arguments: [{'|'.join(_get_list_of_formatter_names(self._list_of_formatters))}]\n"
                "Changes the output format that is produced by commands such as list, summary,"
                " and show. Some of the formats are more suitable for copy-pasting into another"
                " application that supports that format; 'bbcode' for example is suitable to be"
                " pasted into the Milovana forums.\n"
                "When used without arguments, the current setting is shown.\n"
                "Example:\r"
                "  \tSelect the bbcode output format\r"
                "  > \tformat bbcode\r"
                "Example:\r"
                "  \tShow the current setting\r"
                "  > \tformat\n"
                "See also:\r"
                "  \tlist, summary, show, ellipsis, highlight\n"
            )

def _get_list_of_formatter_names(list_of_formatters: list[IFormatter]) -> list[str]:
    return [formatter.get_name() for formatter in list_of_formatters]
