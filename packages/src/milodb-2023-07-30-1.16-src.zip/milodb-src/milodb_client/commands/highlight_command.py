# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from milodb_common.command_framework.argument_stream import ArgumentStream
from milodb_common.command_framework.candidate_text import CandidateText
from milodb_common.command_framework.i_command import ICommand
from milodb_common.command_framework.i_help_info import IHelpInfo
from milodb_common.commands.enums import OnOrOff
from milodb_common.datum.ref_datum import RefDatum
from milodb_common.output.print.i_printer import IPrinter

class HighlightCommand(ICommand):
    def __init__(self, use_highlighting: RefDatum[bool], normal_printer: IPrinter) -> None:
        self._use_highlighting: RefDatum[bool] = use_highlighting
        self._normal_printer: IPrinter = normal_printer
        self._new_highlighting: (OnOrOff | None) = None

    def load(self, argument_stream: ArgumentStream) -> list[CandidateText]:
        self._new_highlighting = argument_stream.pop_optional_enum(OnOrOff)
        if self._new_highlighting is not None:
            argument_stream.fail_if_not_empty()
            return []
        return CandidateText.space_delimited_list(OnOrOff.lowercase_names())

    def execute(self) -> None:
        if self._new_highlighting:
            self._use_highlighting.set(self._new_highlighting.value)
            self._normal_printer.writeln(f"Changed highlighting to '{self._new_highlighting.name.lower()}'")
        else:
            self._normal_printer.writeln(f"Current highlighting is '{OnOrOff(self._use_highlighting.get()).name.lower()}'")
            self._normal_printer.writeln(f"Available options are {OnOrOff.lowercase_names()}")

    class Help(IHelpInfo):
        def get_one_line_summary(self) -> str:
            return "Sets whether text matches are highlighted in the output"

        def get_detailed_summary(self) -> str:
            return (
                f"Arguments: [{'|'.join(OnOrOff.lowercase_names())}]\n"
                "Enables or disables the highlighting of matching text in fields and paragraphs.\n"
                "When used without arguments, the current setting is shown.\n"
                "Highlighting will only be shown on the console when a suitable output format has"
                " been selected with the format command.\n"
                "Example:\r"
                "  \tTurn off highlighting\r"
                "  > \thighlight off\r"
                "Example:\r"
                "  \tShow the current setting\r"
                "  > \thighlight\n"
                "See also:\r"
                "  \tlist, show, browse, browseall, ellipsis, format, pagerefs\n"
            )
