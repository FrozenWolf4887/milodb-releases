# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from milodb_client.commands.sort_keys import OrderedSortKey
from milodb_client.commands.tease_match_sorter import ITeaseMatchSorter
from milodb_client.database.tease import Tease
from milodb_client.output.format.i_formatter import IFormatter
from milodb_client.query.infix_query_parser import IInfixQueryParser, InfixError, PostfixQuery
from milodb_client.query.postfix_query_executor import IPostfixQueryExecutor, PostfixError, PostfixQueryResult
from milodb_client.query.syntax import get_list_of_field_names, get_list_of_operators, get_list_of_verb_names
from milodb_client.query.tease_match import TeaseMatch
from milodb_common.command_framework.argument_stream import ArgumentStream
from milodb_common.command_framework.candidate_text import CandidateText
from milodb_common.command_framework.i_command import CommandLoadError, ICommand
from milodb_common.command_framework.i_help_info import IHelpInfo
from milodb_common.datum.ref_datum import RefDatum
from milodb_common.output.print.i_printer import IPrinter

_HELP_FIELD_NAMES: list[str] = sorted(get_list_of_field_names())
_HELP_VERB_NAMES: list[str] = sorted(get_list_of_verb_names())
_HELP_OPERATORS: list[str] = sorted(get_list_of_operators())

class QueryCommand(ICommand):
    def __init__(self, list_of_teases: list[Tease], infix_parser: IInfixQueryParser, postfix_executor: IPostfixQueryExecutor, list_of_tease_matches: RefDatum[list[TeaseMatch]], tease_match_sorter: ITeaseMatchSorter, list_of_active_sort_keys: list[OrderedSortKey], formatter: IFormatter, use_highlighting: bool, normal_printer: IPrinter, warning_printer: IPrinter, error_printer: IPrinter) -> None:
        self._list_of_teases: list[Tease] = list_of_teases
        self._infix_parser: IInfixQueryParser = infix_parser
        self._postfix_executor: IPostfixQueryExecutor = postfix_executor
        self._list_of_tease_matches: RefDatum[list[TeaseMatch]] = list_of_tease_matches
        self._tease_match_sorter: ITeaseMatchSorter = tease_match_sorter
        self._list_of_active_sort_keys: list[OrderedSortKey] = list_of_active_sort_keys
        self._formatter: IFormatter = formatter
        self._use_highlighting: bool = use_highlighting
        self._normal_printer: IPrinter = normal_printer
        self._warning_printer: IPrinter = warning_printer
        self._error_printer: IPrinter = error_printer
        self._postfix_query: PostfixQuery

    def load(self, argument_stream: ArgumentStream) -> list[CandidateText]:
        argument_stream.set_keep_delimiters('()')
        try:
            self._postfix_query = self._infix_parser.convert_to_postfix(argument_stream)
        except InfixError as ex:
            raise CommandLoadError(
                ex.message,
                ex.fault_token,
                ex.list_of_candidate_text) from ex
        return self._postfix_query.list_of_candidate_text

    def execute(self) -> None:
        try:
            result: PostfixQueryResult = self._postfix_executor.execute(self._list_of_teases, self._postfix_query.postfix_query_chain, 10_000_000)
        except PostfixError as ex:
            self._error_printer.writeln(f'Unexpected fault in postfix query chain: {ex.message}')
            return

        self._list_of_tease_matches.set(self._tease_match_sorter.sort(result.list_of_tease_matches, self._list_of_active_sort_keys))
        if self._list_of_tease_matches:
            self._formatter.print_list_of_teases(self._list_of_tease_matches.get(), self._use_highlighting, self._normal_printer)
        else:
            self._normal_printer.writeln("No matches")
        if result.was_max_match_count_reached:
            self._normal_printer.writeln()
            self._warning_printer.writeln(f'Limit of {result.max_match_count:,} matching items was reached')
            self._normal_printer.writeln(f'   Note: Search stopped with {result.total_match_count:,} matching items')
            percentage_searched: float = 0.0
            if result.queried_tease_count != 0:
                percentage_searched = 100.0 * result.queried_tease_count / result.total_tease_count
            self._normal_printer.writeln(f'   Note: Searched {result.queried_tease_count:,} of {result.total_tease_count:,} teases ({percentage_searched:.1f}%)')

    class Help(IHelpInfo):
        def get_one_line_summary(self) -> str:
            return "Performs a deep search against metadata and text content"

        def get_detailed_summary(self) -> str:
            return (
                "Arguments: <infix query expression>\n"
                "A simple query is in the form: <field> <verb> <regex>. More complex"
                " queries can be constructed with parentheses and boolean operators.\n"
                "Fields:\r"
                f"  \t{', '.join(_HELP_FIELD_NAMES)}\r"
                "Verbs:\r"
                f"  \t{', '.join(_HELP_VERB_NAMES)}\r"
                "Operators:\r"
                f"  \t{', '.join(_HELP_OPERATORS)}\n"
                "The 'contains' and 'is' verbs are a plain text search where 'contains' will match text"
                " anywhere within the specified field, and 'is' will match against the whole field.\n"
                "The 'match' verb is a regular expression search. For more information on regular"
                " expression syntax, see 'https://pythex.org/'. When the regular expression contains"
                " a space or groups, surround the text with single or double quotes.\n"
                "The '=', '>', '>=', '<', '<=' verbs perform value comparisons against numerical and date"
                " fields.\n"
                "The 'not' operator is used before a conditional expression to negate it, such as 'not"
                " type is eos'.\n"
                "The list of results found by the query are sorted according to the current sort"
                " criteria specified with the sort command, and shown with the list command.\n"
                'Teases that have no known authors have an implicit authorId of 0 and authorName of "",'
                " and therefore can be queried with either 'authorId = 0' or 'authorName is \"\"'\n"
                "Example:\r"
                "  \tSearch all text paragraphs for a word\r"
                "  > \tquery text contains banana\r"
                "Example:\r"
                "  \tSearch the title field\r"
                "  \tNote: Quotes are used here because of the space\r"
                '  > \tquery title contains "lexi belle"\r'
                "Example:\r"
                "  \tSearch all text paragraphs for a regular expression\r"
                "  \tNote: Quotes are used here because of the parentheses\r"
                "  > \tquery text matches '(8|eight).?ball'\r"
                "Example:\r"
                "  \tSearch for all teases over a certain rating\r"
                '  > \tquery rating >= 4.5\r'
                "Example:\r"
                "  \tSearch for all teases on or newer than a certain date\r"
                '  > \tquery date >= 2019-03-14\r'
                "Example:\r"
                "  \tPerform a search for multiple fields\r"
                "  > \tquery title matches denial.+part and rating > 4 and text contains denied\r"
                "Example:\r"
                "  \tPerform a search using parentheses\r"
                '  > \tquery (type is nyx or type is eos) and text matches "chastity.?(belt|cage)"\n'
                "See also:\r"
                "  \tlist, sort, show, summary, browse, browseall\n"
            )
