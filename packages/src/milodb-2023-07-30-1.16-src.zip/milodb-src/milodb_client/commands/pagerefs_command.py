# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from milodb_common.command_framework.argument_stream import ArgumentStream
from milodb_common.command_framework.candidate_text import CandidateText
from milodb_common.command_framework.i_command import ICommand
from milodb_common.command_framework.i_help_info import IHelpInfo
from milodb_common.commands.enums import OnOrOff
from milodb_common.datum.ref_datum import RefDatum
from milodb_common.output.print.i_printer import IPrinter

class PageRefsCommand(ICommand):
    def __init__(self, show_pagerefs: RefDatum[bool], normal_printer: IPrinter) -> None:
        self._show_pagerefs: RefDatum[bool] = show_pagerefs
        self._normal_printer: IPrinter = normal_printer
        self._new_show_pagerefs: OnOrOff | None = None

    def load(self, argument_stream: ArgumentStream) -> list[CandidateText]:
        self._new_show_pagerefs = argument_stream.pop_optional_enum(OnOrOff)
        if self._new_show_pagerefs is not None:
            argument_stream.fail_if_not_empty()
            return []
        return CandidateText.space_delimited_list(OnOrOff.lowercase_names())

    def execute(self) -> None:
        if self._new_show_pagerefs:
            self._show_pagerefs.set(self._new_show_pagerefs.value)
            self._normal_printer.writeln(f"Changed display of pagerefs to '{self._new_show_pagerefs.name.lower()}'")
        else:
            self._normal_printer.writeln(f"Current display of pagerefs is '{OnOrOff(self._show_pagerefs.get()).name.lower()}'")
            self._normal_printer.writeln(f"Available options are {OnOrOff.lowercase_names()}")

    class Help(IHelpInfo):
        def get_one_line_summary(self) -> str:
            return "Sets whether page references are displayed with the text blocks"

        def get_detailed_summary(self) -> str:
            return (
                f"Arguments: [{'|'.join(OnOrOff.lowercase_names())}]\n"
                "Page references can be shown alongside the text blocks if desired. This defaults"
                " to false because the page references can be a distraction.\n"
                "When used without arguments, the current setting is shown.\n"
                "Example:\r"
                "  \tTurn on page references\r"
                "  > \tpagerefs on\r"
                "Example:\r"
                "  \tShow the current setting\r"
                "  > \tpagerefs\n"
                "See also:\r"
                "  \tshow, browse, format, highlight, ellipsis\n"
            )
