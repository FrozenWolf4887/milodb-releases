# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
import tempfile
from abc import abstractmethod
from pathlib import Path
from milodb_client.commands.database_support import try_create_list_of_tease_matches_from_ref_ids
from milodb_client.commands.launcher import launch
from milodb_client.config.commands_config import ILaunchConfig
from milodb_client.config.config_schema import CONFIG_SCHEMA
from milodb_client.database.tease import Tease
from milodb_client.output.format.i_html_formatter import IHtmlFormatter
from milodb_client.query.tease_match import TeaseMatch
from milodb_common.command_framework.argument_stream import ArgumentStream
from milodb_common.command_framework.candidate_text import CandidateText
from milodb_common.command_framework.i_command import ICommand
from milodb_common.command_framework.i_help_info import IHelpInfo
from milodb_common.command_framework.ref_id import RefId
from milodb_common.output.print.file_printer import FilePrinter
from milodb_common.output.print.i_printer import IPrinter

_ICON_DATA_URI: str = r"data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20xml:space='preserve'%20width='122mm'%20height='123mm'%20viewBox='0%200%20122%20123'%3e%3cg%20transform='translate(-47%20-120)'%3e%3cpath%20d='m131%20192%2037%2037a6.35%206.35%2090%200%201%200%208l-5%205a6.35%206.35%200%200%201-8%200l-37-37z'%20style='fill:%23fff;stroke-width:0;stroke-linecap:round;stroke-linejoin:round'/%3e%3ccircle%20cx='97'%20cy='170'%20r='50'%20style='fill:%23fff;fill-opacity:1;stroke:none;stroke-width:0;stroke-linecap:round;stroke-linejoin:round;stroke-dasharray:none;stroke-opacity:1'/%3e%3cpath%20d='m131%20197%208%207-9%209-7-8z'%20style='fill:%23616161;stroke-width:0;stroke-linecap:round;stroke-linejoin:round'/%3e%3ccircle%20cx='97'%20cy='170'%20r='47'%20style='fill:%23616161;fill-opacity:1;stroke:none;stroke-width:0;stroke-linecap:round;stroke-linejoin:round;stroke-dasharray:none;stroke-opacity:1'/%3e%3ccircle%20cx='97'%20cy='170'%20r='40'%20style='fill:%23f1c3c3;fill-opacity:1;stroke:none;stroke-width:0;stroke-linecap:round;stroke-linejoin:round;stroke-dasharray:none;stroke-opacity:1'/%3e%3cpath%20d='M88%20190c-1-3-1-7-10-15-11.9-13-1-32%2013-22%206%203%208%203%2012%201%2020-16%2027%2018%203%2034-11%209-16%2013-18%202z'%20style='fill:%23b85a5a;fill-opacity:1;stroke:none;stroke-width:12.011;stroke-dasharray:none;stroke-opacity:1'/%3e%3cpath%20d='M88%20190c-1-3-2-8-10-15-12.3-12-1-32%2013-22%206%203%208%203%2012%201%2020-16%2027%2018%203%2034-11%209-16%2013-18%202z'%20style='mix-blend-mode:normal;fill:none;fill-opacity:1;stroke:%23b14d4d;stroke-width:12.011;stroke-dasharray:none;stroke-opacity:.459'/%3e%3cpath%20d='m139%20204%2026%2026a3.97%203.97%2090%200%201%200%206l-3%203a3.97%203.97%20180%200%201-6%200l-26-26z'%20style='fill:%2337474f;fill-opacity:1;stroke-width:0;stroke-linecap:round;stroke-linejoin:round'/%3e%3c/g%3e%3c/svg%3e"

_CONFIG_HELP_TEXT: str = (
    "Config:\r"
    f"  \t{CONFIG_SCHEMA.commands.browse.launch_option.full_path}\r"
    "    \tDetermines how the webbrowser is launched to open the generated file. The options"
    f" are {CONFIG_SCHEMA.commands.browse.launch_option.enum_class.lowercase_names()}.\r"
    f"  \t{CONFIG_SCHEMA.commands.browse.custom_launch_command.full_path}\r"
    f"    \tWhen '{CONFIG_SCHEMA.commands.browse.launch_option.key_name}' is set to"
    f" '{CONFIG_SCHEMA.commands.browse.launch_option.enum_class.CUSTOM.name.lower()}'"
    " this specifies the custom command to be executed where the following symbols can be"
    " specified:\r"
    "      $p  \tFull path to the generated file\r"
    "      $u  \tURI to the generated file"
)

class _BrowseCommandCommon(ICommand):
    def __init__(self, list_of_teases: list[Tease], list_of_tease_matches: list[TeaseMatch], launch_config: ILaunchConfig, html_formatter: IHtmlFormatter, use_highlighting: bool, show_pagerefs: bool, normal_printer: IPrinter, error_printer: IPrinter) -> None:
        self._list_of_teases: list[Tease] = list_of_teases
        self._list_of_tease_matches: list[TeaseMatch] = list_of_tease_matches
        self._launch_config: ILaunchConfig = launch_config
        self._html_formatter: IHtmlFormatter = html_formatter
        self._use_highlighting: bool = use_highlighting
        self._show_pagerefs: bool = show_pagerefs
        self._normal_printer: IPrinter = normal_printer
        self._error_printer: IPrinter = error_printer
        self._list_of_ref_ids: list[RefId] = []

    def load(self, argument_stream: ArgumentStream) -> list[CandidateText]:
        self._list_of_ref_ids = ArgumentStream.pop_list(argument_stream.pop_optional_ref_id)
        return []

    def execute(self) -> None:
        list_of_tease_matches: (list[TeaseMatch] | None) = None
        if self._list_of_ref_ids:
            list_of_tease_matches = try_create_list_of_tease_matches_from_ref_ids(self._list_of_teases, self._list_of_tease_matches, self._list_of_ref_ids, self._error_printer)
        else:
            list_of_tease_matches = self._list_of_tease_matches

        if list_of_tease_matches:
            self._generate_html_and_launch(list_of_tease_matches)
        else:
            self._error_printer.writeln("No teases available to browse")

    def _generate_html_and_launch(self, list_of_tease_matches: list[TeaseMatch]) -> None:
        try:
            with tempfile.NamedTemporaryFile(mode='w+t', suffix='.html', encoding='utf-8', delete=False) as file:
                file_printer: FilePrinter = FilePrinter(file)
                was_successful = self._write_html_to_file(list_of_tease_matches, _ICON_DATA_URI, file_printer)
        except IOError as ex:
            self._error_printer.writeln(f'Unable to create temporary file: {ex}')
        else:
            if was_successful:
                self._normal_printer.writeln(f"Created '{file.name}'")
                launch(self._launch_config, file.name, Path(file.name).as_uri(), self._normal_printer, self._error_printer)

    @abstractmethod
    def _write_html_to_file(self, list_of_tease_matches: list[TeaseMatch], icon_data_uri: str, file_printer: IPrinter) -> bool:
        pass

class BrowseCommand(_BrowseCommandCommon):
    def __init__(self, list_of_teases: list[Tease], list_of_tease_matches: list[TeaseMatch], launch_config: ILaunchConfig, html_formatter: IHtmlFormatter, use_highlighting: bool, use_ellipsis: bool, ellipsis_max_width: int, show_pagerefs: bool, normal_printer: IPrinter, error_printer: IPrinter) -> None:
        super().__init__(list_of_teases, list_of_tease_matches, launch_config, html_formatter, use_highlighting, show_pagerefs, normal_printer, error_printer)
        self._use_ellipsis: bool = use_ellipsis
        self._ellipsis_max_width: int = ellipsis_max_width

    def _write_html_to_file(self, list_of_tease_matches: list[TeaseMatch], icon_data_uri: str, file_printer: IPrinter) -> bool:
        return self._html_formatter.try_write_browse_file_of_text_matches(list_of_tease_matches, self._use_highlighting, self._ellipsis_max_width if self._use_ellipsis else None, self._show_pagerefs, file_printer, self._error_printer, icon_data_uri)

    class Help(IHelpInfo):
        def get_one_line_summary(self) -> str:
            return "Opens a webpage for the results with the matching paragraphs of text"

        def get_detailed_summary(self) -> str:
            return (
                "Arguments: [list of RefIds]\n"
                "Generates a webpage that contains details for each tease including the matching"
                " text paragraphs if appropriate.\n"
                "When used without arguments, all teases that were found from the last query are"
                " included. When one or more RefIds are specified, only those teases are included.\n"
                "RefIds can be an index into the list of matches such as '3', a teaseId such as"
                " '#38664', or an authorId such as '@43937'.\n"
                "Matching fields and text may be highlighted which can be controlled with the"
                " highlight command.\n"
                "The text paragraphs may be abbreviated with an ellipsis which can be controlled"
                " with the ellipsis command.\n"
                f"{_CONFIG_HELP_TEXT}\n"
                "Example:\r"
                "  \tOpen a webpage with the last query results\r"
                "  > \tbrowse\r"
                "Example:\r"
                "  \tOpen a webpage for matched teases by index\r"
                "  > \tbrowse 3 7\r"
                "Example:\r"
                "  \tOpen a webpage for some specific teaseIds\r"
                "  > \tbrowse #16830 #1465 #38664\r"
                "Example:\r"
                "  \tOpen a webpage for teases from some specific authorId\r"
                "  > \tbrowse @43937\n"
                "See also:\r"
                "  \tbrowseall, ellipsis, highlight\n"
            )

class BrowseAllCommand(_BrowseCommandCommon):
    def _write_html_to_file(self, list_of_tease_matches: list[TeaseMatch], icon_data_uri: str, file_printer: IPrinter) -> bool:
        return self._html_formatter.try_write_browse_file_of_all_text(list_of_tease_matches, self._use_highlighting, self._show_pagerefs, file_printer, self._error_printer, icon_data_uri)

    class Help(IHelpInfo):
        def get_one_line_summary(self) -> str:
            return "Opens a webpage for the results with all paragraphs of text"

        def get_detailed_summary(self) -> str:
            return (
                "Arguments: [list of RefIds]\n"
                "Generates a webpage that contains details for each tease including all text"
                " paragraphs.\n"
                "When used without arguments, all teases that were found from the last query are"
                " included. When one or more RefIds are specified, only those teases are included.\n"
                "RefIds can be an index into the list of matches such as '3', a teaseId such as"
                " '#38664', or an authorId such as '@43937'.\n"
                "Matching fields and text may be highlighted which can be controlled with the"
                " highlight command.\n"
                "The ellipsis setting is ignored with this command so that all of the text is"
                " shown regardless of whether it matched or not.\n"
                f"{_CONFIG_HELP_TEXT}\n"
                "Example:\r"
                "  \tOpen a webpage with the last query results\r"
                "  > \tbrowseall\r"
                "Example:\r"
                "  \tOpen a webpage for matched teases by index\r"
                "  > \tbrowseall 3 7\r"
                "Example:\r"
                "  \tOpen a webpage for some specific teaseIds\r"
                "  > \tbrowseall #16830 #1465 #38664\r"
                "Example:\r"
                "  \tOpen a webpage for teases from some specific authorId\r"
                "  > \tbrowseall @43937\n"
                "See also:\r"
                "  \tbrowse, ellipsis, highlight\n"
            )
