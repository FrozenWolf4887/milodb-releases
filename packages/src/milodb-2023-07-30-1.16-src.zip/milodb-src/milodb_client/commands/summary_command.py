# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from milodb_client.commands.database_support import try_create_list_of_tease_matches_from_ref_ids
from milodb_client.database.tease import Tease
from milodb_client.output.format.i_formatter import IFormatter
from milodb_client.query.tease_match import TeaseMatch
from milodb_common.command_framework.argument_stream import ArgumentStream
from milodb_common.command_framework.candidate_text import CandidateText
from milodb_common.command_framework.i_command import ICommand
from milodb_common.command_framework.i_help_info import IHelpInfo
from milodb_common.command_framework.ref_id import RefId
from milodb_common.output.print.i_printer import IPrinter

class SummaryCommand(ICommand):
    def __init__(self, list_of_teases: list[Tease], list_of_tease_matches: list[TeaseMatch], formatter: IFormatter, use_highlighting: bool, normal_printer: IPrinter, error_printer: IPrinter) -> None:
        self._list_of_teases: list[Tease] = list_of_teases
        self._list_of_tease_matches: list[TeaseMatch] = list_of_tease_matches
        self._formatter: IFormatter = formatter
        self._use_highlighting: bool = use_highlighting
        self._normal_printer: IPrinter = normal_printer
        self._error_printer: IPrinter = error_printer
        self._list_of_ref_ids: list[RefId] = []

    def load(self, argument_stream: ArgumentStream) -> list[CandidateText]:
        self._list_of_ref_ids = ArgumentStream.pop_list(argument_stream.pop_optional_ref_id)
        return []

    def execute(self) -> None:
        list_of_tease_matches: (list[TeaseMatch] | None) = None
        if self._list_of_ref_ids:
            list_of_tease_matches = try_create_list_of_tease_matches_from_ref_ids(self._list_of_teases, self._list_of_tease_matches, self._list_of_ref_ids, self._error_printer)
        else:
            list_of_tease_matches = self._list_of_tease_matches

        if list_of_tease_matches:
            is_first_tease: bool = True
            tease_match: TeaseMatch
            for tease_match in list_of_tease_matches:
                if is_first_tease:
                    is_first_tease = False
                else:
                    self._normal_printer.writeln()
                self._formatter.print_summary_of_tease(tease_match, self._use_highlighting, self._normal_printer)
        else:
            self._error_printer.writeln("No teases available to summarise")

    class Help(IHelpInfo):
        def get_one_line_summary(self) -> str:
            return "Prints the summaries for the current results"

        def get_detailed_summary(self) -> str:
            return (
                "Arguments: [list of RefIds]\n"
                "Shows summary details for each tease without any matching text paragraphs. The"
                " formatting used for the details can be controlled with the format command.\n"
                "When used without arguments, all teases that were found from the last query are"
                " included. When one or more RefIds are specified, only those teases are included.\n"
                "RefIds can be an index into the list of matches such as '3', a teaseId such as"
                " '#38664', or an authorId such as '@43937'.\n"
                "Matching fields may be highlighted which can be controlled with the highlight"
                " command.\n"
                "Example:\r"
                "  \tShow details of the last query results\r"
                "  > \tsummary\r"
                "Example:\r"
                "  \tShow details of a tease by index in the match list\r"
                "  > \tsummary 3\r"
                "Example:\r"
                "  \tShow details for some specific teaseIds\r"
                "  > \tsummary #16830 #1465 #38664\r"
                "Example:\r"
                "  \tShow details of the teases from a specific authorId\r"
                "  > \topen @43937\n"
                "See also:\r"
                "  \tshow, format, highlight\n"
            )
