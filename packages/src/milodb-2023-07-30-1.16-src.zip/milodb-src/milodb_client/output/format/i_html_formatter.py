# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from abc import abstractmethod
from milodb_client.output.format.i_formatter import IFormatter
from milodb_client.query.tease_match import TeaseMatch
from milodb_common.output.print.i_printer import IPrinter

class IHtmlFormatter(IFormatter):
    @abstractmethod
    def try_write_browse_file_of_text_matches(self, list_of_tease_matches: list[TeaseMatch], use_highlighting: bool, ellipsis_max_width: int | None, show_pagerefs: bool, normal_printer: IPrinter, error_printer: IPrinter, icon_data_uri: str) -> bool:
        pass

    @abstractmethod
    def try_write_browse_file_of_all_text(self, list_of_tease_matches: list[TeaseMatch], use_highlighting: bool, show_pagerefs: bool, normal_printer: IPrinter, error_printer: IPrinter, icon_data_uri: str) -> bool:
        pass
