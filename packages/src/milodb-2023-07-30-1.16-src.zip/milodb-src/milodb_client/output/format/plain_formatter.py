# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from milodb_client.database.tease import TotmStatus
from milodb_client.database.tease_page import TeasePage
from milodb_client.output.format.i_formatter import IFormatter
from milodb_client.output.support import EllipsisLocation, ellipsify_text, get_matching_indices_for_page, get_url_of_author, get_url_of_tease, iterate_through_indices
from milodb_client.query.field_match import IFieldMatch
from milodb_client.query.tease_match import TeaseMatch
from milodb_common.output.print.i_printer import IPrinter

_MAP_OF_TOTM_STATUS_TO_TEXT: dict[TotmStatus, str] = {
    TotmStatus.NONE: ' ',
    TotmStatus.NOMINEE: 'n',
    TotmStatus.WINNER: 'w'
}

_TEXT_SEPARATOR_LINE: str = 40 * '-'

class PlainFormatter(IFormatter):
    def get_name(self) -> str:
        return 'plain'

    def print_list_of_teases(self, list_of_tease_matches: list[TeaseMatch], use_highlighting: bool, normal_printer: IPrinter) -> None:
        tease_match: TeaseMatch
        for tease_match in list_of_tease_matches:
            _print_oneline_of_tease(tease_match, normal_printer)

    def print_summary_of_tease(self, tease_match: TeaseMatch, use_highlighting: bool, normal_printer: IPrinter) -> None:
        match_index: str = str(tease_match.index_of_match) if tease_match.index_of_match else 'none'
        tease_id: int = tease_match.tease.tease_id()
        author_id: int = tease_match.tease.author_id()
        tease_id_text: str = f'#{tease_id}'
        tease_type: str = tease_match.tease.type().value
        tease_rating: float = tease_match.tease.rating_value()
        tease_tags: str = ', '.join(tease_match.tease.list_of_tags())
        tease_date: str = tease_match.tease.date().isoformat()
        tease_title: str = tease_match.tease.title()
        author_name: str = f"'{tease_match.tease.author_name()}'" if tease_match.tease.has_author() else 'unknown'
        author_id_text: str = f'@{author_id}' if tease_match.tease.has_author() else 'unknown'
        summary: str = tease_match.tease.summary()
        deleted_text: str = '[DELETED] ' if tease_match.tease.is_deleted() else ''
        url_of_tease: str = get_url_of_tease(tease_id)
        url_of_author: str = get_url_of_author(author_id)
        normal_printer.writeln(f"Index   {match_index:>7}   Hits   {tease_match.get_match_count()}")
        normal_printer.writeln(f"Tease   {tease_id_text:>7}   Title  {deleted_text}'{tease_title}'")
        normal_printer.writeln(f"Author  {author_id_text:>7}   Name   {author_name}")
        normal_printer.writeln(f"Type    {tease_type:>7}   Date   {tease_date}")
        normal_printer.writeln(f"Rating  {tease_rating:>7}   Tags   {tease_tags}")
        normal_printer.writeln(f"Tease   {url_of_tease}")
        if tease_match.tease.has_author():
            normal_printer.writeln(f"Author  {url_of_author}")
        normal_printer.writeln("Summary")
        normal_printer.writeln(summary or 'None')

    def print_all_text_of_list_of_teases(self, list_of_tease_matches: list[TeaseMatch], use_highlighting: bool, show_pagerefs: bool, normal_printer: IPrinter) -> None:
        index: int
        tease_match: TeaseMatch
        for index, tease_match in enumerate(list_of_tease_matches):
            if index > 0:
                normal_printer.writeln()
            self.print_summary_of_tease(tease_match, use_highlighting, normal_printer)
            _print_all_text_of_tease(tease_match, show_pagerefs, normal_printer)

    def print_matching_text_of_list_of_teases(self, list_of_tease_matches: list[TeaseMatch], use_highlighting: bool, ellipsis_max_width: int | None, show_pagerefs: bool, normal_printer: IPrinter) -> None:
        index: int
        tease_match: TeaseMatch
        for index, tease_match in enumerate(list_of_tease_matches):
            if index > 0:
                normal_printer.writeln()
            self.print_summary_of_tease(tease_match, use_highlighting, normal_printer)
            _print_matching_text_of_tease(tease_match, ellipsis_max_width, show_pagerefs, normal_printer)

def _print_all_text_of_tease(tease_match: TeaseMatch, show_pagerefs: bool, normal_printer: IPrinter) -> None:
    index_of_block: int
    page: TeasePage | None = None
    for index_of_block, page in enumerate(tease_match.tease.list_of_pages()):
        if index_of_block == 0:
            normal_printer.writeln('Text')
        normal_printer.writeln(_page_separator(page if show_pagerefs else None))
        normal_printer.writeln(page.text)
    if page:
        normal_printer.writeln(_page_separator(None))

def _print_matching_text_of_tease(tease_match: TeaseMatch, ellipsis_max_width: int | None, show_pagerefs: bool, normal_printer: IPrinter) -> None:
    is_first_match: bool = True
    page: TeasePage | None = None
    for page in tease_match.tease.list_of_pages():
        list_of_indices: list[IFieldMatch.Indices] = get_matching_indices_for_page(page, tease_match.list_of_field_matches)
        if list_of_indices:
            if is_first_match:
                is_first_match = False
                normal_printer.writeln('Matching text')
            normal_printer.writeln(_page_separator(page if show_pagerefs else None))
            if ellipsis_max_width:
                ellipsified_text_block: str = _ellipsify_text(page.text, list_of_indices, ellipsis_max_width)
                normal_printer.writeln(ellipsified_text_block)
            else:
                normal_printer.writeln(page.text)
    if page:
        normal_printer.writeln(_page_separator(None))

def _print_oneline_of_tease(tease_match: TeaseMatch, normal_printer: IPrinter) -> None:
    match_index: str = str(tease_match.index_of_match) if tease_match.index_of_match else '-'
    hits: str = '*' + str(tease_match.get_match_count())
    tease_id: str = '#' + str(tease_match.tease.tease_id())
    tease_type: str = tease_match.tease.type().value
    tease_rating: float = tease_match.tease.rating_value()
    tease_date: str = tease_match.tease.date().isoformat()
    tease_title: str = tease_match.tease.title()
    author_text: str = 'unknown author'
    if tease_match.tease.has_author():
        author_text = f"{tease_match.tease.author_name()}, @{tease_match.tease.author_id()}"
    totm_text: str = _MAP_OF_TOTM_STATUS_TO_TEXT.get(tease_match.tease.totm_status(), ' ')
    deleted_text: str = '[DELETED] ' if tease_match.tease.is_deleted() else ''
    normal_printer.writeln((
        f'{match_index:>3}:'
        f' {hits:>4}'
        f'  {tease_id:>6}'
        f'  {tease_type}'
        f'  {tease_rating:>3}'
        f'  {totm_text}'
        f'  {tease_date}'
        f'  {deleted_text}{tease_title}'
        f' : [{author_text}]'))

def _page_separator(page: TeasePage | None) -> str:
    return f"-- Page: '{page.page_ref}' {_TEXT_SEPARATOR_LINE}"[:len(_TEXT_SEPARATOR_LINE)] if page else _TEXT_SEPARATOR_LINE

def _ellipsify_text(text: str, list_of_indices: list[IFieldMatch.Indices], ellipsis_max_width: int) -> str:
    formatted_text = ''

    def on_normal_text(text: str, is_first_item: bool, is_last_item: bool) -> None:
        nonlocal formatted_text
        formatted_text += _ellipsify_text_item(text, is_first_item, is_last_item, ellipsis_max_width)

    def on_matched_text(text: str, _is_first_item: bool, _is_last_item: bool) -> None:
        nonlocal formatted_text
        formatted_text += text

    iterate_through_indices(text, list_of_indices, on_normal_text, on_matched_text)

    return formatted_text

def _ellipsify_text_item(text: str, is_first_item: bool, is_last_item: bool, ellipsis_max_width: int) -> str:
    formatted_text: str = ''

    def on_text(text: str) -> None:
        nonlocal formatted_text
        formatted_text += text

    def on_ellipsis() -> None:
        nonlocal formatted_text
        formatted_text += '\u2026'

    ellipsify_text(text, ellipsis_max_width, EllipsisLocation.from_position(is_first_item, is_last_item), on_text, on_ellipsis)

    return formatted_text
