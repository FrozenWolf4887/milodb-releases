# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from milodb_client.config.framework import ConfigEnumLeaf, ConfigGroup, ConfigTextLeaf, IConfigGroup
from milodb_common.commands.enums import EnumEx

class CommandLaunchOption(EnumEx):
    DEFAULT = 1
    NONE = 2
    CUSTOM = 3

# pylint: disable=too-many-statements
class ConfigSchema(ConfigGroup):
    def __init__(self) -> None:
        super().__init__(None, '')
        self.version = ConfigTextLeaf(self, 'configVersion', '1')
        self.commands = self.CommandsGroup(self, 'commands')
        self.format = self.FormatGroup(self, 'format')
    class CommandsGroup(ConfigGroup):
        def __init__(self, parent: IConfigGroup, key_name: str) -> None:
            super().__init__(parent, key_name)
            self.browse = self.LaunchGroup(self, 'browse')
            self.open = self.LaunchGroup(self, 'open')
        class LaunchGroup(ConfigGroup):
            def __init__(self, parent: IConfigGroup, key_name: str) -> None:
                super().__init__(parent, key_name)
                self.launch_option = ConfigEnumLeaf(self, 'launchOption', CommandLaunchOption, CommandLaunchOption.DEFAULT)
                self.custom_launch_command = ConfigTextLeaf(self, 'customLaunchCommand', '')
    class FormatGroup(ConfigGroup):
        def __init__(self, parent: IConfigGroup, key_name: str) -> None:
            super().__init__(parent, key_name)
            self.ansi = self.AnsiGroup(self, 'ansi')
            self.bbcode = self.BBCodeGroup(self, 'bbcode')
            self.html = self.HtmlGroup(self, 'html')
        class AnsiGroup(ConfigGroup):
            def __init__(self, parent: IConfigGroup, key_name: str) -> None:
                super().__init__(parent, key_name)
                self.colour = self.ColourGroup(self, 'colour')
            class ColourGroup(ConfigGroup):
                def __init__(self, parent: IConfigGroup, key_name: str) -> None:
                    super().__init__(parent, key_name)
                    self.index_heading = ConfigTextLeaf(self, 'indexHeading', '0')
                    self.hits_heading = ConfigTextLeaf(self, 'hitsHeading', '0')
                    self.tease_heading = ConfigTextLeaf(self, 'teaseHeading', '34')
                    self.author_heading = ConfigTextLeaf(self, 'authorHeading', '32')
                    self.type_heading = ConfigTextLeaf(self, 'typeHeading', '33')
                    self.date_heading = ConfigTextLeaf(self, 'dateHeading', '33')
                    self.rating_heading = ConfigTextLeaf(self, 'ratingHeading', '35')
                    self.tags_heading = ConfigTextLeaf(self, 'tagsHeading', '35')
                    self.summary_heading = ConfigTextLeaf(self, 'summaryHeading', '36')
                    self.deleted_heading = ConfigTextLeaf(self, 'deletedHeading', '33;1')
                    self.page_heading = ConfigTextLeaf(self, 'pageHeading', '1')
                    self.page_name = ConfigTextLeaf(self, 'pageName', '1')
                    self.matching_text_heading = ConfigTextLeaf(self, 'matchingTextHeading', '34')
                    self.matching_text = ConfigTextLeaf(self, 'matchingText', '4;31')
                    self.ellipsis = ConfigTextLeaf(self, 'ellipsis', '30;1')
        class BBCodeGroup(ConfigGroup):
            def __init__(self, parent: IConfigGroup, key_name: str) -> None:
                super().__init__(parent, key_name)
                self.colour = self.ColourGroup(self, 'colour')
            class ColourGroup(ConfigGroup):
                def __init__(self, parent: IConfigGroup, key_name: str) -> None:
                    super().__init__(parent, key_name)
                    self.index_heading = ConfigTextLeaf(self, 'indexHeading', '#808080')
                    self.hits_heading = ConfigTextLeaf(self, 'hitsHeading', '#808080')
                    self.tease_heading = ConfigTextLeaf(self, 'teaseHeading', '#000060')
                    self.author_heading = ConfigTextLeaf(self, 'authorHeading', '#006000')
                    self.type_heading = ConfigTextLeaf(self, 'typeHeading', '#606000')
                    self.date_heading = ConfigTextLeaf(self, 'dateHeading', '#606000')
                    self.rating_heading = ConfigTextLeaf(self, 'ratingHeading', '#600060')
                    self.tags_heading = ConfigTextLeaf(self, 'tagsHeading', '#600060')
                    self.summary_heading = ConfigTextLeaf(self, 'summaryHeading', '#007070')
                    self.deleted_heading = ConfigTextLeaf(self, 'deletedHeading', '#909000')
                    self.page_heading = ConfigTextLeaf(self, 'pageHeading', '#808080')
                    self.page_name = ConfigTextLeaf(self, 'pageName', '#000000')
                    self.matching_text_heading = ConfigTextLeaf(self, 'matchingTextHeading', '#600060')
                    self.matching_text = ConfigTextLeaf(self, 'matchingText', '#FF0000')
                    self.ellipsis = ConfigTextLeaf(self, 'ellipsis', '#808080')
        class HtmlGroup(ConfigGroup):
            def __init__(self, parent: IConfigGroup, key_name: str) -> None:
                super().__init__(parent, key_name)
                self.css = self.CSSGroup(self, 'css')
            class CSSGroup(ConfigGroup):
                def __init__(self, parent: IConfigGroup, key_name: str) -> None:
                    super().__init__(parent, key_name)
                    self.file_path = ConfigTextLeaf(self, 'filePath', 'default.css')
                    self.colour = self.ColourGroup(self, 'colour')
                class ColourGroup(ConfigGroup):
                    def __init__(self, parent: IConfigGroup, key_name: str) -> None:
                        super().__init__(parent, key_name)
                        self.page_background = ConfigTextLeaf(self, "pageBackground", '#F2CFCF')
                        self.list_table_background = ConfigTextLeaf(self, "listTableBackground", '#933737')
                        self.list_table_header_background = ConfigTextLeaf(self, "listTableHeaderBackground", '#933737')
                        self.list_table_header_text_index = ConfigTextLeaf(self, "listTableHeaderTextIndex", 'white')
                        self.list_table_header_text_hits = ConfigTextLeaf(self, "listTableHeaderTextHits", 'white')
                        self.list_table_header_text_tease_id = ConfigTextLeaf(self, "listTableHeaderTextTeaseId", 'white')
                        self.list_table_header_text_type = ConfigTextLeaf(self, "listTableHeaderTextType", 'yellow')
                        self.list_table_header_text_rating = ConfigTextLeaf(self, "listTableHeaderTextRating", '#CAF')
                        self.list_table_header_text_date = ConfigTextLeaf(self, "listTableHeaderTextDate", '#DDD')
                        self.list_table_header_text_title = ConfigTextLeaf(self, "listTableHeaderTextTitle", '#F2CFCF')
                        self.list_table_header_text_author = ConfigTextLeaf(self, "listTableHeaderTextAuthor", 'greenyellow')
                        self.list_table_header_text_deleted = ConfigTextLeaf(self, "listTableHeaderTextDeleted", '#A80')
                        self.list_table_value_background = ConfigTextLeaf(self, "listTableValueBackground", 'white')
                        self.list_table_value_background_index = ConfigTextLeaf(self, "listTableValueBackgroundIndex", 'lightgrey')
                        self.list_table_value_border = ConfigTextLeaf(self, "listTableValueBorder", '#F2CFCF')
                        self.list_table_value_text_index = ConfigTextLeaf(self, "listTableValueTextIndex", 'black')
                        self.list_table_value_text_hits = ConfigTextLeaf(self, "listTableValueTextHits", 'black')
                        self.list_table_value_text_tease_id = ConfigTextLeaf(self, "listTableValueTextTeaseId", 'black')
                        self.list_table_value_text_type = ConfigTextLeaf(self, "listTableValueTextType", '#660')
                        self.list_table_value_text_rating = ConfigTextLeaf(self, "listTableValueTextRating", 'seagreen')
                        self.list_table_value_text_date = ConfigTextLeaf(self, "listTableValueTextDate", '#444')
                        self.list_table_value_text_title = ConfigTextLeaf(self, "listTableValueTextTitle", '#848')
                        self.list_table_value_text_author = ConfigTextLeaf(self, "listTableValueTextAuthor", 'darkgreen')
                        self.list_table_value_text_total_matches = ConfigTextLeaf(self, "listTableValueTextTotalMatches", 'black')
                        self.list_table_matching_text_foreground = ConfigTextLeaf(self, "listTableMatchingTextForeground", '#933737')
                        self.list_table_matching_text_background = ConfigTextLeaf(self, "listTableMatchingTextBackground", '#F2CFCF')
                        self.list_table_matching_text_border = ConfigTextLeaf(self, "listTableMatchingTextBorder", '#933737')
                        self.summary_table_background = ConfigTextLeaf(self, "summaryTableBackground", '#933737')
                        self.summary_table_thumbnail_background = ConfigTextLeaf(self, "summaryTableThumbnailBackground", '#744')
                        self.summary_table_thumbnail_border = ConfigTextLeaf(self, "summaryTableThumbnailBorder", '#C28F8F')
                        self.summary_table_header_background = ConfigTextLeaf(self, "summaryTableHeaderBackground", '#933737')
                        self.summary_table_header_text_index = ConfigTextLeaf(self, "summaryTableHeaderTextIndex", 'white')
                        self.summary_table_header_text_hits = ConfigTextLeaf(self, "summaryTableHeaderTextHits", 'white')
                        self.summary_table_header_text_tease_id = ConfigTextLeaf(self, "summaryTableHeaderTextTeaseId", 'white')
                        self.summary_table_header_text_title = ConfigTextLeaf(self, "summaryTableHeaderTextTitle", '#F2CFCF')
                        self.summary_table_header_text_author_id = ConfigTextLeaf(self, "summaryTableHeaderTextAuthorId", 'greenyellow')
                        self.summary_table_header_text_author_name = ConfigTextLeaf(self, "summaryTableHeaderTextAuthorName", 'greenyellow')
                        self.summary_table_header_text_type = ConfigTextLeaf(self, "summaryTableHeaderTextType", 'yellow')
                        self.summary_table_header_text_date = ConfigTextLeaf(self, "summaryTableHeaderTextDate", '#DDD')
                        self.summary_table_header_text_rating = ConfigTextLeaf(self, "summaryTableHeaderTextRating", '#CAF')
                        self.summary_table_header_text_tags = ConfigTextLeaf(self, "summaryTableHeaderTextTags", '#BDF')
                        self.summary_table_header_text_summary = ConfigTextLeaf(self, "summaryTableHeaderTextSummary", 'khaki')
                        self.summary_table_header_text_deleted = ConfigTextLeaf(self, "summaryTableHeaderTextDeleted", '#A80')
                        self.summary_table_value_background = ConfigTextLeaf(self, "summaryTableValueBackground", 'white')
                        self.summary_table_value_background_index = ConfigTextLeaf(self, "summaryTableValueBackgroundIndex", 'lightgrey')
                        self.summary_table_value_border = ConfigTextLeaf(self, "summaryTableValueBorder", '#F2CFCF')
                        self.summary_table_value_text_index = ConfigTextLeaf(self, "summaryTableValueTextIndex", 'black')
                        self.summary_table_value_text_hits = ConfigTextLeaf(self, "summaryTableValueTextHits", 'black')
                        self.summary_table_value_text_tease_id = ConfigTextLeaf(self, "summaryTableValueTextTeaseId", 'black')
                        self.summary_table_value_text_title = ConfigTextLeaf(self, "summaryTableValueTextTitle", '#848')
                        self.summary_table_value_text_author_id = ConfigTextLeaf(self, "summaryTableValueTextAuthorId", 'darkgreen')
                        self.summary_table_value_text_author_name = ConfigTextLeaf(self, "summaryTableValueTextAuthorName", 'darkgreen')
                        self.summary_table_value_text_type = ConfigTextLeaf(self, "summaryTableValueTextType", '#660')
                        self.summary_table_value_text_date = ConfigTextLeaf(self, "summaryTableValueTextDate", 'black')
                        self.summary_table_value_text_rating = ConfigTextLeaf(self, "summaryTableValueTextRating", 'seagreen')
                        self.summary_table_value_text_tags = ConfigTextLeaf(self, "summaryTableValueTextTags", 'black')
                        self.summary_table_value_text_summary = ConfigTextLeaf(self, "summaryTableValueTextSummary", 'black')
                        self.summary_table_matching_text_foreground = ConfigTextLeaf(self, "summaryTableMatchingTextForeground", '#933737')
                        self.summary_table_matching_text_background = ConfigTextLeaf(self, "summaryTableMatchingTextBackground", '#F2CFCF')
                        self.summary_table_matching_text_border = ConfigTextLeaf(self, "summaryTableMatchingTextBorder", '#933737')
                        self.text_table_background = ConfigTextLeaf(self, "textTableBackground", '#933737')
                        self.text_table_header_background = ConfigTextLeaf(self, "textTableHeaderBackground", '#933737')
                        self.text_table_header_foreground_page = ConfigTextLeaf(self, "textTableHeaderForegroundPage", 'white')
                        self.text_table_header_foreground_text = ConfigTextLeaf(self, "textTableHeaderForegroundText", 'white')
                        self.text_table_value_foreground_page = ConfigTextLeaf(self, "textTableValueForegroundPage", 'black')
                        self.text_table_value_background_page = ConfigTextLeaf(self, "textTableValueBackgroundPage", 'lightgrey')
                        self.text_table_content_background = ConfigTextLeaf(self, "textTableContentBackground", 'white')
                        self.text_table_content_foreground = ConfigTextLeaf(self, "textTableContentForeground", 'black')
                        self.text_table_content_border = ConfigTextLeaf(self, "textTableContentBorder", '#F2CFCF')
                        self.text_table_ellipsis_foreground = ConfigTextLeaf(self, "textTableEllipsisForeground", 'white')
                        self.text_table_ellipsis_background = ConfigTextLeaf(self, "textTableEllipsisBackground", '#CCC')
                        self.text_table_matching_text_foreground = ConfigTextLeaf(self, "textTableMatchingTextForeground", '#933737')
                        self.text_table_matching_text_background = ConfigTextLeaf(self, "textTableMatchingTextBackground", '#F2CFCF')
                        self.text_table_matching_text_border = ConfigTextLeaf(self, "textTableMatchingTextBorder", '#933737')

CONFIG_SCHEMA: ConfigSchema = ConfigSchema()
