# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
import datetime
import re
from collections.abc import Callable
from milodb_client.database.tease import Tease, TeaseDateProperty, TeaseFloatProperty, TeaseIntProperty, TeaseStrListProperty, TeaseStrProperty, TeaseType, TeaseTypeProperty, TotmStatus
from milodb_client.database.tease_page import TeasePage
from milodb_client.query.field_match import FieldItemMatch, FieldListMatch, FieldPageListMatch, IFieldMatch
from milodb_client.query.field_predicate import IFieldDatePredicate, IFieldFloatPredicate, IFieldIntPredicate, IFieldPageListPredicate, IFieldStatusPredicate, IFieldStrListPredicate, IFieldStrPredicate, IFieldTotmPredicate, IFieldTypePredicate
from milodb_client.query.match_result import FalseMatchResult, IMatchResult, TrueMatchResult
from milodb_common.command_framework.argument_stream import ArgumentStream

_REGEX_PATTERN_FLAGS: int = re.MULTILINE | re.DOTALL | re.IGNORECASE

class FieldStrIs(IFieldStrPredicate):
    def __init__(self, tease_property: TeaseStrProperty, argument_stream: ArgumentStream) -> None:
        self._tease_property: TeaseStrProperty = tease_property
        self._plain_text: str = argument_stream.pop_text().lower()

    def perform_query(self, stack_of_match_results: list[IMatchResult], tease: Tease) -> None:
        field_value: str = tease.get_text_of_property(self._tease_property).lower()
        if field_value == self._plain_text:
            indices: IFieldMatch.Indices = IFieldMatch.Indices(0, len(field_value))
            stack_of_match_results.append(TrueMatchResult([FieldItemMatch(self._tease_property, [indices])]))
        else:
            stack_of_match_results.append(FalseMatchResult())

class FieldStrContains(IFieldStrPredicate):
    def __init__(self, tease_property: TeaseStrProperty, argument_stream: ArgumentStream) -> None:
        self._tease_property: TeaseStrProperty = tease_property
        self._plain_text: str = argument_stream.pop_text().lower()

    def perform_query(self, stack_of_match_results: list[IMatchResult], tease: Tease) -> None:
        list_of_indices: list[IFieldMatch.Indices] = []

        field_value: str = tease.get_text_of_property(self._tease_property).lower()
        search_index: int = 0
        while search_index != -1:
            search_index = field_value.find(self._plain_text, search_index)
            if search_index != -1:
                indices: IFieldMatch.Indices = IFieldMatch.Indices(search_index, search_index + len(self._plain_text))
                list_of_indices.append(indices)
                search_index += len(self._plain_text)

        if list_of_indices:
            stack_of_match_results.append(TrueMatchResult([FieldItemMatch(self._tease_property, list_of_indices)]))
        else:
            stack_of_match_results.append(FalseMatchResult())

class FieldStrMatches(IFieldStrPredicate):
    def __init__(self, tease_property: TeaseStrProperty, argument_stream: ArgumentStream) -> None:
        self._tease_property: TeaseStrProperty = tease_property
        self._pattern: re.Pattern[str] = argument_stream.pop_regex(_REGEX_PATTERN_FLAGS)

    def perform_query(self, stack_of_match_results: list[IMatchResult], tease: Tease) -> None:
        field_value: str = tease.get_text_of_property(self._tease_property)
        list_of_matches: list[re.Match[str]] = list(self._pattern.finditer(field_value))
        if list_of_matches:
            list_of_indices: list[IFieldMatch.Indices] = [IFieldMatch.Indices(match.start(), match.end()) for match in list_of_matches]
            stack_of_match_results.append(TrueMatchResult(
                [FieldItemMatch(self._tease_property, list_of_indices)]))
        else:
            stack_of_match_results.append(FalseMatchResult())

class FieldStrListIs(IFieldStrListPredicate):
    def __init__(self, tease_property: TeaseStrListProperty, argument_stream: ArgumentStream) -> None:
        self._tease_property: TeaseStrListProperty = tease_property
        self._plain_text: str = argument_stream.pop_text().lower()

    def perform_query(self, stack_of_match_results: list[IMatchResult], tease: Tease) -> None:
        list_of_field_matches: list[IFieldMatch] = []

        list_index: int
        text: str
        for list_index, text in enumerate(self._tease_property(tease)):
            if text.lower() == self._plain_text:
                indices: IFieldMatch.Indices = IFieldMatch.Indices(0, len(text))
                list_of_field_matches.append(FieldListMatch(self._tease_property, list_index, [indices]))

        if list_of_field_matches:
            stack_of_match_results.append(TrueMatchResult(list_of_field_matches))
        else:
            stack_of_match_results.append(FalseMatchResult())

class FieldStrListMatches(IFieldStrListPredicate):
    def __init__(self, tease_property: TeaseStrListProperty, argument_stream: ArgumentStream) -> None:
        self._tease_property: TeaseStrListProperty = tease_property
        self._pattern: re.Pattern[str] = argument_stream.pop_regex(_REGEX_PATTERN_FLAGS)

    def perform_query(self, stack_of_match_results: list[IMatchResult], tease: Tease) -> None:
        list_of_field_matches: list[IFieldMatch] = []

        index: int
        text: str
        for index, text in enumerate(self._tease_property(tease)):
            list_of_matches: list[re.Match[str]] = list(self._pattern.finditer(text))
            if list_of_matches:
                list_of_indices: list[IFieldMatch.Indices] = [IFieldMatch.Indices(match.start(), match.end()) for match in list_of_matches]
                list_of_field_matches.append(FieldListMatch(self._tease_property, index, list_of_indices))

        if list_of_field_matches:
            stack_of_match_results.append(TrueMatchResult(list_of_field_matches))
        else:
            stack_of_match_results.append(FalseMatchResult())

class FieldStrListContains(IFieldStrListPredicate):
    def __init__(self, tease_property: TeaseStrListProperty, argument_stream: ArgumentStream) -> None:
        self._tease_property: TeaseStrListProperty = tease_property
        self._plain_text: str = argument_stream.pop_text().lower()

    def perform_query(self, stack_of_match_results: list[IMatchResult], tease: Tease) -> None:
        list_of_field_matches: list[IFieldMatch] = []

        index: int
        text: str
        for index, text in enumerate(self._tease_property(tease)):
            lowercase_text: str = text.lower()
            list_of_indices: list[IFieldMatch.Indices] = []
            search_index: int = 0
            while search_index != -1:
                search_index = lowercase_text.find(self._plain_text, search_index)
                if search_index != -1:
                    indices: IFieldMatch.Indices = IFieldMatch.Indices(search_index, search_index + len(self._plain_text))
                    list_of_indices.append(indices)
                    search_index += len(self._plain_text)

            if list_of_indices:
                list_of_field_matches.append(FieldListMatch(self._tease_property, index, list_of_indices))

        if list_of_field_matches:
            stack_of_match_results.append(TrueMatchResult(list_of_field_matches))
        else:
            stack_of_match_results.append(FalseMatchResult())

class FieldUnsignedIntCompare(IFieldIntPredicate):
    def __init__(self, tease_property: TeaseIntProperty, argument_stream: ArgumentStream, compare_func: Callable[[int, int], bool]) -> None:
        self._tease_property: TeaseIntProperty = tease_property
        self._compare_func: Callable[[int, int], bool] = compare_func
        self._value: int = argument_stream.pop_uint()

    def perform_query(self, stack_of_match_results: list[IMatchResult], tease: Tease) -> None:
        field_value: int = self._tease_property(tease)
        if self._compare_func(field_value, self._value):
            stack_of_match_results.append(TrueMatchResult(
                [FieldItemMatch(self._tease_property, [IFieldMatch.Indices.whole_match()])]))
        else:
            stack_of_match_results.append(FalseMatchResult())

class FieldUnsignedFloatCompare(IFieldFloatPredicate):
    def __init__(self, tease_property: TeaseFloatProperty, argument_stream: ArgumentStream, compare_func: Callable[[float, float], bool]) -> None:
        self._tease_property: TeaseFloatProperty = tease_property
        self._compare_func: Callable[[float, float], bool] = compare_func
        self._value: float = argument_stream.pop_ufloat()

    def perform_query(self, stack_of_match_results: list[IMatchResult], tease: Tease) -> None:
        field_value: float = self._tease_property(tease)
        if self._compare_func(field_value, self._value):
            stack_of_match_results.append(TrueMatchResult(
                [FieldItemMatch(self._tease_property, [IFieldMatch.Indices.whole_match()])]))
        else:
            stack_of_match_results.append(FalseMatchResult())

class FieldTypeIs(IFieldTypePredicate):
    def __init__(self, tease_property: TeaseTypeProperty, argument_stream: ArgumentStream) -> None:
        self._tease_property: TeaseTypeProperty = tease_property
        self._tease_type: TeaseType = argument_stream.pop_enum_by_value(TeaseType)

    def perform_query(self, stack_of_match_results: list[IMatchResult], tease: Tease) -> None:
        field_value: TeaseType = self._tease_property(tease)
        if field_value == self._tease_type:
            stack_of_match_results.append(TrueMatchResult(
                [FieldItemMatch(self._tease_property, [IFieldMatch.Indices.whole_match()])]))
        else:
            stack_of_match_results.append(FalseMatchResult())

class FieldDateCompare(IFieldDatePredicate):
    def __init__(self, tease_property: TeaseDateProperty, argument_stream: ArgumentStream, compare_func: Callable[[datetime.date, datetime.date], bool]) -> None:
        self._tease_property: TeaseDateProperty = tease_property
        self._compare_func: Callable[[datetime.date, datetime.date], bool] = compare_func
        self._value: datetime.date = argument_stream.pop_date()

    def perform_query(self, stack_of_match_results: list[IMatchResult], tease: Tease) -> None:
        field_value: datetime.date = self._tease_property(tease)
        if self._compare_func(field_value, self._value):
            stack_of_match_results.append(TrueMatchResult(
                [FieldItemMatch(self._tease_property, [IFieldMatch.Indices.whole_match()])]))
        else:
            stack_of_match_results.append(FalseMatchResult())

class FieldTotmIs(IFieldTotmPredicate):
    _MAP_OF_VALUE_TO_COMPARATOR: dict[str, Callable[[Tease], bool]] = {
        'winner': lambda tease: tease.totm_status() == TotmStatus.WINNER,
        'nominee': lambda tease: tease.totm_status() == TotmStatus.NOMINEE,
        'either': lambda tease: tease.totm_status() != TotmStatus.NONE
    }

    def __init__(self, argument_stream: ArgumentStream) -> None:
        self._comparator: Callable[[Tease], bool] = argument_stream.pop_dict_value(FieldTotmIs._MAP_OF_VALUE_TO_COMPARATOR)

    def perform_query(self, stack_of_match_results: list[IMatchResult], tease: Tease) -> None:
        if self._comparator(tease):
            stack_of_match_results.append(TrueMatchResult(
                [FieldItemMatch(Tease.totm_status, [IFieldMatch.Indices.whole_match()])]))
        else:
            stack_of_match_results.append(FalseMatchResult())

class FieldStatusIs(IFieldStatusPredicate):
    _MAP_OF_VALUE_TO_COMPARATOR: dict[str, Callable[[Tease], bool]] = {
        'active': lambda tease: not tease.is_deleted(),
        'deleted': lambda tease: tease.is_deleted()
    }

    def __init__(self, argument_stream: ArgumentStream) -> None:
        self._comparator: Callable[[Tease], bool] = argument_stream.pop_dict_value(FieldStatusIs._MAP_OF_VALUE_TO_COMPARATOR)

    def perform_query(self, stack_of_match_results: list[IMatchResult], tease: Tease) -> None:
        if self._comparator(tease):
            stack_of_match_results.append(TrueMatchResult(
                [FieldItemMatch(Tease.totm_status, [IFieldMatch.Indices.whole_match()])]))
        else:
            stack_of_match_results.append(FalseMatchResult())

class FieldPageListMatches(IFieldPageListPredicate):
    def __init__(self, argument_stream: ArgumentStream) -> None:
        self._pattern: re.Pattern[str] = argument_stream.pop_regex(_REGEX_PATTERN_FLAGS)

    def perform_query(self, stack_of_match_results: list[IMatchResult], tease: Tease) -> None:
        list_of_field_matches: list[IFieldMatch] = []

        index: int
        page: TeasePage
        for index, page in enumerate(tease.list_of_pages()):
            list_of_matches: list[re.Match[str]] = list(self._pattern.finditer(page.text))
            if list_of_matches:
                list_of_indices: list[IFieldMatch.Indices] = [IFieldMatch.Indices(match.start(), match.end()) for match in list_of_matches]
                list_of_field_matches.append(FieldPageListMatch(page, index, list_of_indices))

        if list_of_field_matches:
            stack_of_match_results.append(TrueMatchResult(list_of_field_matches))
        else:
            stack_of_match_results.append(FalseMatchResult())

class FieldPageListContains(IFieldPageListPredicate):
    def __init__(self, argument_stream: ArgumentStream) -> None:
        self._plain_text: str = argument_stream.pop_text().lower()

    def perform_query(self, stack_of_match_results: list[IMatchResult], tease: Tease) -> None:
        list_of_field_matches: list[IFieldMatch] = []

        index: int
        page: TeasePage
        for index, page in enumerate(tease.list_of_pages()):
            lowercase_text: str = page.text.lower()
            list_of_indices: list[IFieldMatch.Indices] = []
            search_index: int = 0
            while search_index != -1:
                search_index = lowercase_text.find(self._plain_text, search_index)
                if search_index != -1:
                    indices: IFieldMatch.Indices = IFieldMatch.Indices(search_index, search_index + len(self._plain_text))
                    list_of_indices.append(indices)
                    search_index += len(self._plain_text)

            if list_of_indices:
                list_of_field_matches.append(FieldPageListMatch(page, index, list_of_indices))

        if list_of_field_matches:
            stack_of_match_results.append(TrueMatchResult(list_of_field_matches))
        else:
            stack_of_match_results.append(FalseMatchResult())
