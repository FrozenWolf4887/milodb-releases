# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from collections.abc import Callable
from milodb_common.command_framework.argument_stream import ArgumentStream
from milodb_common.command_framework.candidate_text import CandidateText
from milodb_common.command_framework.i_command import CommandLoadError, ICommand
from milodb_common.command_framework.i_help_info import IHelpInfo
from milodb_common.input.default_input import IDefaultInputText
from milodb_common.output.print.i_printer import IPrinter
from milodb_common.variables.i_user_variables import IPersistentUserVariables

class VarCommand(ICommand):
    def __init__(self, user_variables: IPersistentUserVariables, default_input_text: IDefaultInputText, normal_printer: IPrinter, warning_printer: IPrinter, error_printer: IPrinter) -> None:
        self._user_variables: IPersistentUserVariables = user_variables
        self._default_input_text: IDefaultInputText = default_input_text
        self._normal_printer: IPrinter = normal_printer
        self._warning_printer: IPrinter = warning_printer
        self._error_printer: IPrinter = error_printer
        self._execute_action: (Callable[[], None] | None) = None
        self._variable_name: (str | None) = None
        self._variable_value: (str | None) = None
        self._new_variable_name: (str | None) = None

    def load(self, argument_stream: ArgumentStream) -> list[CandidateText]:
        argument_stream.disable_expansion()

        map_of_action_to_delegate: dict[str, Callable[[ArgumentStream], None]] = {
            'set': self._load_action_set,
            'get': self._load_action_get,
            'delete': self._load_action_delete,
            'rename': self._load_action_rename,
            'copy': self._load_action_copy,
            'edit': self._load_action_edit
        }

        load_action: Callable[[ArgumentStream], None] | None = argument_stream.pop_optional_dict_value(map_of_action_to_delegate)
        if load_action:
            load_action(argument_stream)
            return []
        self._execute_action = self._execute_action_list
        return CandidateText.space_delimited_list(map_of_action_to_delegate.keys())

    def execute(self) -> None:
        if self._execute_action:
            self._execute_action()

    def _load_action_set(self, argument_stream: ArgumentStream) -> None:
        self._variable_name = argument_stream.pop_variable_name(self._user_variables.get_list_of_names())
        self._variable_value = argument_stream.get_remaining_raw_text().strip()
        if not self._variable_value:
            raise CommandLoadError("Expected some text to set as the variable value", None, [])
        self._execute_action = self._execute_action_set

    def _load_action_get(self, argument_stream: ArgumentStream) -> None:
        self._variable_name = argument_stream.pop_variable_name(self._user_variables.get_list_of_names())
        argument_stream.fail_if_not_empty()
        self._execute_action = self._execute_action_get

    def _load_action_delete(self, argument_stream: ArgumentStream) -> None:
        self._variable_name = argument_stream.pop_variable_name(self._user_variables.get_list_of_names())
        argument_stream.fail_if_not_empty()
        self._execute_action = self._execute_action_delete

    def _load_action_rename(self, argument_stream: ArgumentStream) -> None:
        self._variable_name = argument_stream.pop_variable_name(self._user_variables.get_list_of_names())
        self._new_variable_name = argument_stream.pop_variable_name([])
        argument_stream.fail_if_not_empty()
        self._execute_action = self._execute_action_rename

    def _load_action_copy(self, argument_stream: ArgumentStream) -> None:
        self._variable_name = argument_stream.pop_variable_name(self._user_variables.get_list_of_names())
        self._new_variable_name = argument_stream.pop_variable_name([])
        argument_stream.fail_if_not_empty()
        self._execute_action = self._execute_action_copy

    def _load_action_edit(self, argument_stream: ArgumentStream) -> None:
        self._variable_name = argument_stream.pop_variable_name(self._user_variables.get_list_of_names())
        argument_stream.fail_if_not_empty()
        self._execute_action = self._execute_action_edit

    def _execute_action_set(self) -> None:
        if self._variable_name and self._variable_value:
            self._user_variables.set(self._variable_name, self._variable_value)
            self._save_variables()

    def _execute_action_get(self) -> None:
        if self._variable_name:
            value: (str | None) = self._user_variables.try_retrieve(self._variable_name)
            if value is not None:
                self._print_variable(self._variable_name, value)
            else:
                self._error_printer.writeln(f"Unknown variable '{self._variable_name}'")

    def _execute_action_rename(self) -> None:
        if self._variable_name and self._new_variable_name:
            if self._variable_name != self._new_variable_name:
                value: (str | None) = self._user_variables.try_retrieve(self._variable_name)
                if value is not None:
                    if self._user_variables.try_retrieve(self._new_variable_name) is None:
                        self._user_variables.set(self._new_variable_name, value)
                        self._user_variables.try_delete(self._variable_name)
                        self._save_variables()
                    else:
                        self._error_printer.writeln(f"Cannot rename variable '{self._variable_name}' to '{self._new_variable_name}' because '{self._new_variable_name}' already exists")
                else:
                    self._error_printer.writeln(f"Unknown variable '{self._variable_name}'")
            else:
                self._error_printer.writeln(f"Variable '{self._variable_name}' cannot be renamed to itself")

    def _execute_action_copy(self) -> None:
        if self._variable_name and self._new_variable_name:
            if self._variable_name != self._new_variable_name:
                value: (str | None) = self._user_variables.try_retrieve(self._variable_name)
                if value is not None:
                    if self._user_variables.try_retrieve(self._new_variable_name) is None:
                        self._user_variables.set(self._new_variable_name, value)
                        self._save_variables()
                    else:
                        self._error_printer.writeln(f"Cannot copy variable '{self._variable_name}' to '{self._new_variable_name}' because '{self._new_variable_name}' already exists")
                else:
                    self._error_printer.writeln(f"Unknown variable '{self._variable_name}'")
            else:
                self._error_printer.writeln(f"Variable '{self._variable_name}' cannot be copied to itself")

    def _execute_action_edit(self) -> None:
        if self._variable_name:
            value: (str | None) = self._user_variables.try_retrieve(self._variable_name)
            if value is not None:
                self._default_input_text.set(f'var set {self._variable_name} {value}')
            else:
                self._error_printer.writeln(f"Unknown variable '{self._variable_name}'")

    def _execute_action_list(self) -> None:
        name: str
        value: str
        list_of_variables: list[tuple[str, str]] = self._user_variables.get_list_of_variables()
        if list_of_variables:
            max_name_width: int = max(len(name) for name, _ in list_of_variables)
            for name, value in list_of_variables:
                self._print_variable(name, value, max_name_width)
        else:
            self._normal_printer.writeln('No variables available to list')

    def _execute_action_delete(self) -> None:
        if self._variable_name:
            if self._user_variables.try_delete(self._variable_name):
                self._save_variables()
            else:
                self._error_printer.writeln(f"Unknown variable '{self._variable_name}'")

    def _save_variables(self) -> None:
        save_result: IPersistentUserVariables.SaveResult = self._user_variables.try_save()
        if not save_result.was_successful:
            if save_result.error_message:
                self._error_printer.writeln(save_result.error_message)
            if save_result.warning_message:
                self._warning_printer.writeln(save_result.warning_message)

    def _print_variable(self, name: str, value: str, max_name_width: int = 0) -> None:
        self._normal_printer.writeln(f'  {name:<{max_name_width}} : {value}')

    class Help(IHelpInfo):
        def get_one_line_summary(self) -> str:
            return "Manages the values of user variables"

        def get_detailed_summary(self) -> str:
            return (
                "Arguments: [get|set|delete|rename|copy|edit]\r"
                "           get VariableName\r"
                "           set VariableName ...\r"
                "           delete VariableName\r"
                "           rename VariableName VariableName\r"
                "           copy VariableName VariableName\r"
                "           edit VariableName\n"
                "Variables can help to provide shortcuts when composing a command and are expanded as"
                " the input is processed. A variable reference can appear anywhere in the input by"
                " prefixing it with '$' and is a standalone delimited token such as:\r"
                "  > \tquery $year2020 and author is FrozenWolf\r"
                "  > \t$myQuery and author is FrozenWolf\n"
                "VariableName consists of alphanumeric characters, underscore, minus, and plus symbols.\n"
                "Each variable persists in a variables file that will be created or updated when a"
                " variable is set or changed. When the application is started, the variables file is"
                " loaded.\n"
                "When a variable is 'set', all text following the name is accepted verbatim.\n"
                "TAB completion for variable names within other commands will only provide suggestions"
                " when the '$' prefix is typed; this is to prevent variables getting mixed in with the"
                " regular options. TAB completion on inputs containing variables will behave as if the"
                " variable has been expanded.\n"
                "Variable expansion is recursive, allowing for variable values to reference other"
                " variables if needed.\n"
                "When this command is called without arguments, the list of variables is displayed.\n"
                "Example:\r"
                "  \tSet a variable to help with a query\r"
                "  > \tvar set year2020 date >= 2020-01-01 and date < 2021-01-01\r"
                "  \tUse the variable in a query\r"
                "  > \tquery $year2020 and text contains holiday\r"
                "  \tWhich is equivalent to\r"
                "  > \tquery date >= 2020-01-01 and date < 2021-01-01 and text contains holiday\r"
                "Example:\r"
                "  \tList all the variables\r"
                "  > \tvar\r"
                "Example:\r"
                "  \tDelete one of the variables\r"
                "  > \tvar delete year2020\r"
                "Example:\r"
                "  \tRename one of the variables\r"
                "  > \tvar rename year2020 agesAgo\r"
                "Example:\r"
                "  \tCopy one of the variables\r"
                "  > \tvar copy year2020 agesAgo\r"
                "Example:\r"
                "  \tEdit one of the variables\r"
                "  > \tvar edit year2020\n"
            )
