# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import TypeAlias
from milodb_common.command_framework.argument_stream import ArgumentStream
from milodb_common.command_framework.candidate_text import CandidateText
from milodb_common.command_framework.i_command import ICommand
from milodb_common.parser.token import Token

@dataclass
class EmptyInputResult:
    list_of_command_names: list[str]

@dataclass
class SuccessfulLoadResult:
    command: ICommand
    list_of_candidate_text: list[CandidateText]

@dataclass
class FailedLoadResult:
    command_class: (type[ICommand] | None)
    fault_token: (Token | None)
    fault_text: str
    input_text: str
    list_of_candidate_text: list[CandidateText]

LoadResult: TypeAlias = SuccessfulLoadResult | FailedLoadResult | EmptyInputResult

@dataclass
class CommandLoadDelegateError(Exception):
    load_result: LoadResult

class ICommandLoader(ABC):
    @abstractmethod
    def try_load(self, argument_stream: ArgumentStream) -> LoadResult:
        pass
