#!/bin/bash
# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0

COL_RED='\x1b[31m'
COL_GREEN='\x1b[32m'
COL_YELLOW='\x1b[33m'
COL_PURPLE_UNDERLINE='\x1b[35;4m'
COL_NONE='\x1b[0m'

COL_OK="$COL_GREEN"
COL_ERROR="$COL_RED"
COL_WARNING="$COL_YELLOW"
COL_NOTE="$COL_PURPLE_UNDERLINE"

set -e
cd ..

assemblyDirpath="/tmp/milodb-assembly"
versionFilepath="milodb_client/version.py"

listOfIncludeBinFiles=(
    "tools/bin/milodb.exe"
    "tools/bin/milodb"
    "database.mdb"
    "default.css"
    "changelog.md"
)
listOfIncludeSrcFiles=(
    "default.css"
    "changelog.md"
    "run.py"
    "test.py"
    "LICENSE.txt"
)
listOfIncludeSrcDirs=(
    "tools/"
    "milodb_client/"
    "milodb_client_test/"
    "milodb_common/"
    "milodb_common_test/"
)
listOfExcludeSrcPaths=(
    "__pycache__/"
    "tools/bin/"
    "tools/dist/"
    ".mypy_cache/"
)

function pass()
{
    messages=("$@")

    isFirstLine=1
    for line in "${messages[@]}"
    do
        if [ $isFirstLine -eq 1 ]
        then
            echo -e "  ${COL_OK}OK${COL_NONE}: $line"
            isFirstLine=0
        else
            echo "    $line"
        fi
    done
}

function fail()
{
    messages=("$@")

    isFirstLine=1
    for line in "${messages[@]}"
    do
        if [ $isFirstLine -eq 1 ]
        then
            echo -e "${COL_ERROR}Error${COL_NONE}: $line" 1>&2
            isFirstLine=0
        else
            echo "  $line" 1>&2
        fi
    done
    echo -e "${COL_WARNING}Aborting${COL_NONE}" 1>&2
    exit 1
}

function note()
{
    messages=("$@")

    isFirstLine=1
    for line in "${messages[@]}"
    do
        if [ $isFirstLine -eq 1 ]
        then
            echo -e "${COL_NOTE}$line${COL_NONE}"
            isFirstLine=0
        else
            echo "  $line"
        fi
    done
}

function assertToolExists()
{
    toolName="$1"
    if ! which "$toolName" > /dev/null
    then
        fail "Tool '$toolName' not installed or not avaialable"
    else
        pass "Tool '$toolName' exists"
    fi
}

function assertFileExists()
{
    filePath="$1"
    if [ ! -f "$filePath" ]
    then
        fail "File '$filePath' missing"
    else
        pass "File '$filePath' exists"
    fi
}

function assertDirExists()
{
    dirPath="$1"
    if [ ! -d "$dirPath" ]
    then
        fail "Directory '$dirPath' missing"
    else
        pass "Directory '$dirPath' exists"
    fi
}

function assertListOfFilesExists()
{
    listOfFiles=("$@")
    for file in "${listOfFiles[@]}"
    do
        assertFileExists "$file"
    done
}

function assertListOfDirsExists()
{
    listOfDirs=("$@")
    for dir in "${listOfDirs[@]}"
    do
        assertDirExists "$dir"
    done
}

function assertDirDoesntExist()
{
    dirPath="$1"
    if [ -d "$dirPath" ]
    then
        fail "Directory '$dirPath' already exists" "Please remove this output directory first"
    else
        pass "Directory '$filePath' doesn't exist"
    fi
}

function assertFileIsNewerThanFile()
{
    filepath1="$1"
    filepath2="$2"
    timestamp1=$(stat "$filepath1" --format=%Y)
    timestamp2=$(stat "$filepath2" --format=%Y)
    if [ "$timestamp1" -lt "$timestamp2" ]
    then
        fail "File '$filepath1' must be newer than '$filepath2'"
    fi
}

startingDirpath="$(pwd)"

note 'Content check'
assertToolExists zip
assertListOfFilesExists "${listOfIncludeBinFiles[@]}"
assertListOfFilesExists "${listOfIncludeSrcFiles[@]}"
assertListOfDirsExists "${listOfIncludeSrcDirs[@]}"
assertFileIsNewerThanFile "tools/bin/milodb" "$versionFilepath"
assertFileIsNewerThanFile "tools/bin/milodb.exe" "$versionFilepath"
assertDirDoesntExist "tools/dist"
assertDirDoesntExist "$assemblyDirpath"

versionNumberLine=$(grep -o "MILODB_VERSION:.*=.*" "$versionFilepath")
if [[ "$versionNumberLine" =~ =\ *[\'\"]([0-9]+(\.[0-9]+)+)[\'\"]$ ]]
then
    versionNumber="${BASH_REMATCH[1]}"
else
    fail "Version number has not been set." \
         "Was not found in 'version.py' that contained line:" \
         "    $versionNumberLine"
fi

versionDateLine=$(grep -o "MILODB_DATE:.*=.*" "$versionFilepath")
if [[ "$versionDateLine" =~ =\ *[\'\"](20[0-9][0-9]-[0-9][0-9]-[0-9][0-9])[\'\"]$ ]]
then
    versionDate="${BASH_REMATCH[1]}"
else
    fail "Version date has not been set." \
         "Was not found in 'version.py' that contained line:" \
         "    $versionDateLine"
fi

expectedChangeLogEntry="$versionNumber, $versionDate"
if ! grep "$expectedChangeLogEntry" "changelog.md" > /dev/null
then
    fail "Change log doesn't include current version" "Expected: '$expectedChangeLogEntry'"
fi

assemblyBinDirpath="$assemblyDirpath/milodb"
echo "Assembling binaries to '$assemblyBinDirpath'"
mkdir -p "$assemblyBinDirpath"
for binFile in "${listOfIncludeBinFiles[@]}"
do
    cp "$binFile" "$assemblyBinDirpath/"
done

assemblySrcDirpath="$assemblyDirpath/milodb-src"
note "Assembling source to '$assemblySrcDirpath'"
mkdir -p "$assemblySrcDirpath"
excludeArgs=()
for excludeSrcPath in "${listOfExcludeSrcPaths[@]}"
do
    excludeArgs+=("--exclude" "$excludeSrcPath")
done
rsync --recursive --relative --prune-empty-dirs "${excludeArgs[@]}" "${listOfIncludeSrcFiles[@]}" "${listOfIncludeSrcDirs[@]}" "$assemblySrcDirpath"

zipBinFilename="milodb-$versionDate-$versionNumber.zip"
note "Packing binaries to '$zipBinFilename'"
echo
cd "$assemblyDirpath"
zip -r9 "$zipBinFilename" milodb
cd "$startingDirpath"

zipSrcFilename="milodb-$versionDate-$versionNumber-src.zip"
echo
note "Packing source to '$zipSrcFilename'"
echo
cd "$assemblyDirpath"
zip -r9 "$zipSrcFilename" milodb-src
cd "$startingDirpath"

mkdir "tools/dist"
cp "$assemblyDirpath/$zipBinFilename" "tools/dist/"
cp "$assemblyDirpath/$zipSrcFilename" "tools/dist/"

echo
note Done
echo
ls -lh "tools/dist/"
