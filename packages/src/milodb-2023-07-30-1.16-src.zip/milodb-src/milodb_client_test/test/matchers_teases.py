# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from typing import Any
from milodb_client.database.tease import Tease
from milodb_client.query.field_match import FieldItemMatch, FieldListMatch, FieldPageListMatch, IFieldMatch
from milodb_client.query.tease_match import TeaseMatch

class NonIndexedTeaseMatch:
    def __init__(self, expected_tease: Tease):
        self._expected_tease: Tease = expected_tease

    def __eq__(self, other: object) -> bool:
        return isinstance(other, TeaseMatch) and other.index_of_match is None and len(other.list_of_field_matches) == 0 and other.tease == self._expected_tease

    def __hash__(self) -> int:
        return hash(self._expected_tease)

    def __repr__(self) -> str:
        return f"TeaseMatch(None, {self._expected_tease}, [])"

class ListOfTeaseMatchesMatch:
    def __init__(self, list_of_expected_tease_matches: list[TeaseMatch], debug: bool = False):
        self._list_of_expected_tease_matches: list[TeaseMatch] = list_of_expected_tease_matches
        self._debug: bool = debug

    def __eq__(self, other: object) -> bool:
        is_equal: bool = True

        if isinstance(other, list) and len(other) == len(self._list_of_expected_tease_matches):
            index: int
            expected_tease_match: TeaseMatch
            for index, expected_tease_match in enumerate(self._list_of_expected_tease_matches):
                actual_tease_match: TeaseMatch | Any = other[index]
                if isinstance(actual_tease_match, TeaseMatch):
                    if not is_equal_tease_match(expected_tease_match, actual_tease_match, self._debug):
                        is_equal = False
                else:
                    is_equal = False
        else:
            is_equal = False

        return is_equal

    def __hash__(self) -> int:
        return hash(self._list_of_expected_tease_matches)

    def __repr__(self) -> str:
        return f"<TeaseMatch List> '{self._list_of_expected_tease_matches}'"

def is_equal_list_of_tease_matches(left: list[TeaseMatch], right: list[TeaseMatch], debug: bool = False) -> bool:
    if left is right:
        return True

    is_equal: bool = True

    if len(left) == len(right):
        index: int
        left_tease_match: TeaseMatch
        for index, left_tease_match in enumerate(left):
            right_tease_match: TeaseMatch = right[index]
            if not is_equal_tease_match(left_tease_match, right_tease_match, debug):
                if debug:
                    print(f'Mismatched TeaseMatch[{index}]')
                is_equal = False
    else:
        if debug:
            print(f'Mismatched len(list[TeaseMatch]): left={len(left)}, right={len(right)}')
        is_equal = False

    return is_equal

def is_equal_tease_match(left: TeaseMatch, right: TeaseMatch, debug: bool = False) -> bool:
    if left is right:
        return True

    is_equal: bool = True

    if left.index_of_match != right.index_of_match:
        if debug:
            print(f'Mismatched TeaseMatch.index_of_match: left={left.index_of_match}, right={right.index_of_match}')
        is_equal = False

    if left.tease is not right.tease:
        if debug:
            print(f'Mismatched TeaseMatch.tease: left={left.tease}, right={right.tease}')
        is_equal = False

    if not is_equal_list_of_field_matches(left.list_of_field_matches, right.list_of_field_matches, debug):
        if debug:
            print('Mismatched TeaseMatch.list_of_field_matches')
        is_equal = False

    return is_equal

def is_equal_list_of_field_matches(left: list[IFieldMatch], right: list[IFieldMatch], debug: bool = False) -> bool:
    if left is right:
        return True

    is_equal: bool = True

    if len(left) == len(right):
        index: int
        left_field_match: IFieldMatch
        for index, left_field_match in enumerate(left):
            right_field_match: IFieldMatch = right[index]
            if not is_equal_field_match(left_field_match, right_field_match, debug):
                if debug:
                    print(f'Mismatched IFieldMatch[{index}]')
                is_equal = False
    else:
        if debug:
            print(f'Mismatched len(list[IFieldMatch]): left={len(left)}, right={len(right)}')
        is_equal = False

    return is_equal

def is_equal_field_match(left: IFieldMatch, right: IFieldMatch, debug: bool = False) -> bool: # pylint: disable=too-complex
    if left is right:
        return True

    is_equal: bool = True

    if isinstance(right, type(left)):
        if isinstance(left, FieldItemMatch | FieldListMatch) and isinstance(right, FieldItemMatch | FieldListMatch):
            if left.tease_property != right.tease_property:
                is_equal = False
                if debug:
                    print(f'Mismatched FieldItemMatch.tease_property: left={left.tease_property}, right={right.tease_property}')
        elif isinstance(left, FieldPageListMatch) and isinstance(right, FieldPageListMatch):
            if left.index_of_page != right.index_of_page or left.page is not right.page:
                is_equal = False
                if debug:
                    print(f'Mismatched FieldPageListMatch: left={left.page}, {left.index_of_page}, right={right.page}, {right.index_of_page}')
    else:
        is_equal = False
        if debug:
            print(f'Mismatched Type[IFieldMatch]: left={type(left)}, right={type(right)}')

    if not is_equal_list_of_indices(left.list_of_indices, right.list_of_indices, debug):
        is_equal = False
        if debug:
            print('Mismatched IFieldMatch.list_of_indices')

    return is_equal

def is_equal_list_of_indices(left: list[IFieldMatch.Indices], right: list[IFieldMatch.Indices], debug: bool = False) -> bool:
    if left is right:
        return True

    is_equal: bool = True

    if len(left) == len(right):
        index: int
        left_indices: IFieldMatch.Indices
        for index, left_indices in enumerate(left):
            right_indices: IFieldMatch.Indices = right[index]
            if not is_equal_indices(left_indices, right_indices, debug):
                if debug:
                    print(f'Mismatched IFieldMatch.Indices[{index}]')
                is_equal = False
    else:
        if debug:
            print(f'Mismatched len(list[IFieldMatch.Indices]): left={len(left)}, right={len(right)}')
        is_equal = False

    return is_equal

def is_equal_indices(left: IFieldMatch.Indices, right: IFieldMatch.Indices, debug: bool = False) -> bool:
    if left is right:
        return True

    is_equal: bool = True

    if left.start_index != right.start_index:
        if debug:
            print(f'Mismatched IFieldMatch.Indices.start_index: left={left.start_index}, right={right.start_index}')
        is_equal = False

    if left.end_index != right.end_index:
        if debug:
            print(f'Mismatched IFieldMatch.Indices.end_index: left={left.end_index}, right={right.end_index}')
        is_equal = False

    return is_equal
