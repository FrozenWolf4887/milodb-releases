# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from dataclasses import dataclass, field
from unittest.mock import Mock, call
from milodb_client.commands.format_command import FormatCommand
from milodb_client.output.format.i_formatter import IFormatter
from milodb_common.command_framework.i_command import ICommand
from milodb_common.datum.ref_datum import RefDatum
from milodb_common.output.print.i_printer import IPrinter
from milodb_common_test.commands.error_messages import ErrorMessage
from milodb_common_test.commands.test_command_base import CommandTestBase
from milodb_common_test.test.strict_mock import StrictMock

MOCK_FORMATTER_CHEESE: StrictMock = StrictMock(IFormatter)
MOCK_FORMATTER_CHEESE.get_name = Mock(return_value='Cheese')
MOCK_FORMATTER_BISCUITS: StrictMock = StrictMock(IFormatter)
MOCK_FORMATTER_BISCUITS.get_name = Mock(return_value='Biscuits')
MOCK_FORMATTER_WHISKEY: StrictMock = StrictMock(IFormatter)
MOCK_FORMATTER_WHISKEY.get_name = Mock(return_value='Whiskey')

@dataclass
class _Args:
    current_formatter: RefDatum[IFormatter] = field(default_factory=lambda: RefDatum(MOCK_FORMATTER_CHEESE))
    list_of_formatters: list[IFormatter] = field(default_factory=lambda: [MOCK_FORMATTER_CHEESE, MOCK_FORMATTER_BISCUITS, MOCK_FORMATTER_WHISKEY])
    normal_printer: StrictMock = field(default_factory=lambda: StrictMock(IPrinter))

class TestFormatCommand(CommandTestBase):
    def setUp(self) -> None:
        self._args: _Args = _Args()
        return super().setUp()

    def create_command(self) -> ICommand:
        return FormatCommand(
            self._args.current_formatter,
            self._args.list_of_formatters,
            self._args.normal_printer
        )

    def test_without_arguments_prints_current_setting_without_change(self) -> None:
        for initial_formatter in (MOCK_FORMATTER_CHEESE, MOCK_FORMATTER_BISCUITS, MOCK_FORMATTER_WHISKEY):
            with self.subTest(initial_formatter=initial_formatter):
                self.setUp()
                self._args.current_formatter = RefDatum(initial_formatter)
                self._args.normal_printer.writeln = Mock()
                self.command_load_and_execute([])
                self._args.normal_printer.writeln.assert_has_calls([
                    call(f"Current format is '{initial_formatter.get_name()}'"),
                    call("Available formats are ['Cheese', 'Biscuits', 'Whiskey']")])
                self.assertIs(initial_formatter, self._args.current_formatter.get())
                self.assert_next_text(['Cheese', 'Biscuits', 'Whiskey'])

    def test_with_argument_changes_setting_regardless_of_initial_setting(self) -> None:
        for initial_formatter in (MOCK_FORMATTER_CHEESE, MOCK_FORMATTER_BISCUITS, MOCK_FORMATTER_WHISKEY):
            for new_formatter in (MOCK_FORMATTER_CHEESE, MOCK_FORMATTER_BISCUITS, MOCK_FORMATTER_WHISKEY):
                with self.subTest(initial_formatter=initial_formatter):
                    self.setUp()
                    self._args.current_formatter = RefDatum(initial_formatter)
                    self._args.normal_printer.writeln = Mock()
                    self.command_load_and_execute([new_formatter.get_name()])
                    self._args.normal_printer.writeln.assert_called_once_with(f"Changed format to '{new_formatter.get_name()}'")
                    self.assertIs(new_formatter, self._args.current_formatter.get())
                    self.assert_next_text([])

    def test_with_one_invalid_argument_returns_failure(self) -> None:
        self.command_load(['Wine'])
        self.assert_argument_error(1, ErrorMessage.INVALID, ['Cheese', 'Biscuits', 'Whiskey'])

    def test_with_redundant_argument_returns_failure(self) -> None:
        self.command_load(['Whiskey', 'Biscuits'])
        self.assert_argument_error(2, ErrorMessage.UNEXPECTED, [])
