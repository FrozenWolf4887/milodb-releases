# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
import re
from dataclasses import dataclass, field
from unittest.mock import Mock, call
from milodb_client.commands.help_command import HelpCommand
from milodb_common.command_framework.i_command import ICommand
from milodb_common.command_framework.i_command_factory import ICommandFactory
from milodb_common.command_framework.i_help_info import IHelpInfo
from milodb_common.output.print.i_printer import IPrinter
from milodb_common_test.commands.error_messages import ErrorMessage
from milodb_common_test.commands.test_command_base import CommandTestBase
from milodb_common_test.test.matchers_strings import RegexSubstringMatch
from milodb_common_test.test.strict_mock import StrictMock

@dataclass
class _Args:
    command_factory: StrictMock = field(default_factory=lambda: StrictMock(ICommandFactory))
    normal_printer: StrictMock = field(default_factory=lambda: StrictMock(IPrinter))

class TestHelpCommand(CommandTestBase):
    def setUp(self) -> None:
        self._args: _Args = _Args()
        return super().setUp()

    def create_command(self) -> ICommand:
        return HelpCommand(
            self._args.command_factory,
            self._args.normal_printer
        )

    def test_without_arguments_prints_generic_help_for_commands(self) -> None:
        command_one_help: StrictMock = StrictMock(IHelpInfo)
        command_one_help.get_one_line_summary = Mock(return_value='This is the summary of the first command')
        command_two_help: StrictMock = StrictMock(IHelpInfo)
        command_two_help.get_one_line_summary = Mock(return_value='The second command summary')
        map_of_command_name_to_help: dict[str, StrictMock] = {
            'first': command_one_help,
            'second': command_two_help
        }
        self._args.command_factory.get_list_of_command_names = Mock(return_value=list(map_of_command_name_to_help.keys()))
        self._args.command_factory.try_get_command_help_from_name = Mock(side_effect=map_of_command_name_to_help.get)
        self._args.normal_printer.writeln = Mock()
        self.command_load_and_execute([])
        self._args.command_factory.get_list_of_command_names.assert_called()
        self._args.command_factory.try_get_command_help_from_name.assert_has_calls([call(name) for name in map_of_command_name_to_help])
        self._args.normal_printer.writeln.assert_called_once_with(RegexSubstringMatch('first +This is the summary of the first command.+second +The second command summary', re.DOTALL))

    def test_with_known_command_argument_returns_success(self) -> None:
        help_info: StrictMock = StrictMock(IHelpInfo)
        help_info.get_one_line_summary = Mock(return_value='Summary of the first command')
        help_info.get_detailed_summary = Mock(return_value='Detailed command summary')
        self._args.command_factory.try_get_command_help_from_name = Mock(return_value=help_info)
        self._args.normal_printer.writeln = Mock()
        self.command_load_and_execute(['fake_command'])
        self._args.command_factory.try_get_command_help_from_name.assert_called_once_with('fake_command')
        self._args.normal_printer.writeln.assert_called_once_with(RegexSubstringMatch('Summary of the first command.+Detailed command summary', re.DOTALL))

    def test_with_unknown_command_name_returns_failure(self) -> None:
        map_of_command_name_to_help: dict[str, StrictMock] = {
            'first': StrictMock(IHelpInfo),
            'second': StrictMock(IHelpInfo)
        }
        self._args.command_factory.get_list_of_command_names = Mock(return_value=list(map_of_command_name_to_help.keys()))
        self._args.command_factory.try_get_command_help_from_name = Mock(side_effect=map_of_command_name_to_help.get)
        self.command_load(['mango'])
        self.assert_load_error(1, ErrorMessage.INVALID_COMMAND, list(map_of_command_name_to_help.keys()))

    def test_with_redundant_argument_returns_failure(self) -> None:
        map_of_command_name_to_help: dict[str, StrictMock] = {
            'first': StrictMock(IHelpInfo),
            'second': StrictMock(IHelpInfo)
        }
        self._args.command_factory.get_list_of_command_names = Mock(return_value=list(map_of_command_name_to_help.keys()))
        self._args.command_factory.try_get_command_help_from_name = Mock(side_effect=map_of_command_name_to_help.get)
        self.command_load(['first', 'second'])
        self.assert_argument_error(2, ErrorMessage.UNEXPECTED, [])
