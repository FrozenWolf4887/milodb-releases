# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from dataclasses import dataclass, field
from unittest.mock import Mock
from milodb_client.commands.query_command import QueryCommand
from milodb_client.commands.sort_keys import OrderedSortKey, RATING_SORT_KEY, TYPE_SORT_KEY
from milodb_client.commands.tease_match_sorter import ITeaseMatchSorter
from milodb_client.database.tease import Tease
from milodb_client.output.format.i_formatter import IFormatter
from milodb_client.query.infix_query_parser import IInfixQueryParser, PostfixQuery
from milodb_client.query.postfix_query_executor import IPostfixQueryExecutor, PostfixQueryResult
from milodb_client.query.query import IQuery
from milodb_client.query.tease_match import TeaseMatch
from milodb_client_test.test import fake_teases
from milodb_common.command_framework.i_command import ICommand
from milodb_common.datum.ref_datum import RefDatum
from milodb_common.output.print.i_printer import IPrinter
from milodb_common_test.commands.test_command_base import CommandTestBase
from milodb_common_test.test.strict_mock import StrictMock

_DEFAULT_LIST_OF_TEASES: list[Tease] = [
    fake_teases.TEASE_ID_1000_AUTHOR_ID_4567,
    fake_teases.TEASE_ID_1234_AUTHOR_ID_6431,
    fake_teases.TEASE_ID_5678_AUTHOR_ID_4567,
    fake_teases.TEASE_ID_2000_AUTHOR_ID_6431,
    fake_teases.TEASE_ID_8721_AUTHOR_ID_7213
]

@dataclass
class _Args:
    list_of_teases: list[Tease] = field(default_factory=_DEFAULT_LIST_OF_TEASES.copy)
    infix_parser: StrictMock = field(default_factory=lambda: StrictMock(IInfixQueryParser))
    postfix_executor: StrictMock = field(default_factory=lambda: StrictMock(IPostfixQueryExecutor))
    list_of_tease_matches: RefDatum[list[TeaseMatch]] = field(default_factory=lambda: RefDatum[list[TeaseMatch]]([]))
    tease_match_sorter: StrictMock = field(default_factory=lambda: StrictMock(ITeaseMatchSorter))
    list_of_active_sort_keys: list[OrderedSortKey] = field(default_factory=list)
    formatter: StrictMock = field(default_factory=lambda: StrictMock(IFormatter))
    use_highlighting: bool = True
    normal_printer: StrictMock = field(default_factory=lambda: StrictMock(IPrinter))
    warning_printer: StrictMock = field(default_factory=lambda: StrictMock(IPrinter))
    error_printer: StrictMock = field(default_factory=lambda: StrictMock(IPrinter))

class TestQueryCommand(CommandTestBase):
    def setUp(self) -> None:
        self._args: _Args = _Args()
        return super().setUp()

    def create_command(self) -> ICommand:
        return QueryCommand(
            self._args.list_of_teases,
            self._args.infix_parser,
            self._args.postfix_executor,
            self._args.list_of_tease_matches,
            self._args.tease_match_sorter,
            self._args.list_of_active_sort_keys,
            self._args.formatter,
            self._args.use_highlighting,
            self._args.normal_printer,
            self._args.warning_printer,
            self._args.error_printer
        )

    def test_query_outputs_sorted_list(self) -> None:
        list_of_tease_matches: list[TeaseMatch] = [
            TeaseMatch(1, fake_teases.TEASE_ID_5678_AUTHOR_ID_4567, []),
            TeaseMatch(2, fake_teases.TEASE_ID_8721_AUTHOR_ID_7213, []),
            TeaseMatch(3, fake_teases.TEASE_ID_2000_AUTHOR_ID_6431, []),
            TeaseMatch(4, fake_teases.TEASE_ID_1000_AUTHOR_ID_4567, [])
        ]
        list_of_sorted_tease_matches: list[TeaseMatch] = [
            TeaseMatch(1, fake_teases.TEASE_ID_8721_AUTHOR_ID_7213, []),
            TeaseMatch(2, fake_teases.TEASE_ID_2000_AUTHOR_ID_6431, []),
            TeaseMatch(3, fake_teases.TEASE_ID_5678_AUTHOR_ID_4567, []),
            TeaseMatch(4, fake_teases.TEASE_ID_1000_AUTHOR_ID_4567, [])
        ]
        mock_list_of_queries: list[IQuery] = [StrictMock(IQuery), StrictMock(IQuery)]
        self._args.infix_parser.convert_to_postfix = Mock(return_value=PostfixQuery(mock_list_of_queries, []))
        self._args.postfix_executor.execute = Mock(return_value=PostfixQueryResult(5, 100, False, 350, 350, list_of_tease_matches))
        self._args.tease_match_sorter.sort = Mock(return_value=list_of_sorted_tease_matches)
        self._args.list_of_active_sort_keys = [OrderedSortKey(TYPE_SORT_KEY, False), OrderedSortKey(RATING_SORT_KEY, True)]
        self._args.formatter.print_list_of_teases = Mock()
        self.command_load_and_execute(['one', 'two', 'three'])
        self._args.infix_parser.convert_to_postfix.assert_called_once_with(self.argument_stream)
        self._args.postfix_executor.execute.assert_called_once_with(self._args.list_of_teases, mock_list_of_queries, 10_000_000)
        self._args.tease_match_sorter.sort.assert_called_once_with(list_of_tease_matches, self._args.list_of_active_sort_keys)
        self.assertIs(list_of_sorted_tease_matches, self._args.list_of_tease_matches.get())
        self._args.formatter.print_list_of_teases.assert_called_once_with(list_of_sorted_tease_matches, self._args.use_highlighting, self._args.normal_printer)
