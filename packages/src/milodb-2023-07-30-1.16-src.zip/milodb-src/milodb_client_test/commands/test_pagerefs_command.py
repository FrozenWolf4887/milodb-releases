# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from dataclasses import dataclass, field
from unittest.mock import Mock, call
from milodb_client.commands.pagerefs_command import PageRefsCommand
from milodb_common.command_framework.i_command import ICommand
from milodb_common.datum.ref_datum import RefDatum
from milodb_common.output.print.i_printer import IPrinter
from milodb_common_test.commands.error_messages import ErrorMessage
from milodb_common_test.commands.test_command_base import CommandTestBase
from milodb_common_test.test.strict_mock import StrictMock

@dataclass
class _Args:
    show_pagerefs: RefDatum[bool] = field(default_factory=lambda: RefDatum(True))
    normal_printer: StrictMock = field(default_factory=lambda: StrictMock(IPrinter))

class TestPageRefsCommand(CommandTestBase):
    def setUp(self) -> None:
        self._args: _Args = _Args()
        return super().setUp()

    def create_command(self) -> ICommand:
        return PageRefsCommand(
            self._args.show_pagerefs,
            self._args.normal_printer
        )

    def test_without_arguments_prints_current_setting_without_change(self) -> None:
        for initial_show_pagerefs in (True, False):
            with self.subTest(initial_show_pagerefs=initial_show_pagerefs):
                self.setUp()
                self._args.show_pagerefs.set(initial_show_pagerefs)
                self._args.normal_printer.writeln = Mock()
                self.command_load_and_execute([])
                current_setting: str = 'on' if initial_show_pagerefs else 'off'
                self._args.normal_printer.writeln.assert_has_calls([
                    call(f"Current display of pagerefs is '{current_setting}'"),
                    call("Available options are ['on', 'off']")])
                self.assertEqual(initial_show_pagerefs, self._args.show_pagerefs.get())
                self.assert_next_text(['on', 'off'])

    def test_with_argument_changes_setting_regardless_of_initial_setting(self) -> None:
        for initial_show_pagerefs in (True, False):
            for change_show_pagerefs in (True, False):
                with self.subTest(initial_show_pagerefs=initial_show_pagerefs, change_show_pagerefs=change_show_pagerefs):
                    self.setUp()
                    self._args.show_pagerefs.set(initial_show_pagerefs)
                    self._args.normal_printer.writeln = Mock()
                    new_setting: str = 'on' if change_show_pagerefs else 'off'
                    self.command_load_and_execute([new_setting])
                    self._args.normal_printer.writeln.assert_called_once_with(f"Changed display of pagerefs to '{new_setting}'")
                    self.assertEqual(change_show_pagerefs, self._args.show_pagerefs.get())

    def test_with_invalid_argument_returns_failure(self) -> None:
        self.command_load(['mango'])
        self.assert_argument_error(1, ErrorMessage.INVALID_ENUM, ['on', 'off'])

    def test_with_redundant_argument_returns_failure(self) -> None:
        self.command_load(['on', 'off'])
        self.assert_argument_error(2, ErrorMessage.UNEXPECTED, [])
