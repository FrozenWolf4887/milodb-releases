from typing import Optional

MILODB_VERSION: Optional[str] = '1.1'
MILODB_DATE: Optional[str] = '2022-04-30'
