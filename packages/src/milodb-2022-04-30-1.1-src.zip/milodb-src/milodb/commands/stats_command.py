from dataclasses import dataclass
from milodb.commands.argument_stream import ArgumentStream
from milodb.commands.command import Command, CommandContext
from milodb.commands.command_support import count_words
from milodb.tease import Tease, TotmStatus
from typing import Callable, Dict, List, Optional, Tuple

class StatsCommand(Command):
    def __init__(self, context: CommandContext) -> None:
        self._context = context
        self._stats_delegate: Callable[[StatsCommand], None] = StatsCommand._display_general

    def load(self, argument_stream: ArgumentStream) -> Optional[List[str]]:
        if not argument_stream.is_empty():
            self._stats_delegate = argument_stream.pop_dict_value(_MAP_OF_CHOICES_TO_DELEGATE)
            argument_stream.fail_if_not_empty()
            return None
        else:
            return list(_MAP_OF_CHOICES_TO_DELEGATE.keys())

    def execute(self) -> None:
        self._stats_delegate(self)

    @classmethod
    def get_one_line_summary(cls) -> str:
        return "Show some database related statistics (just for fun)"

    @classmethod
    def get_detailed_summary(cls, context: CommandContext) -> str:
        return (
            f"Arguments: [{'|'.join(list(_MAP_OF_CHOICES_TO_DELEGATE.keys()))}]\n"
            "When used without arguments, general statistics are shown.\n"
            "Note that the tags associated with each tease are known to be an incomplete list, therefore"
            " the statistics are probably not very accurate. The number of words found in a tease doesn't"
            " include all of the cleverness of page navigation, scripting, etc.; the words themselves"
            " are counted by finding stuff separated by whitespace.\n"
            "Example:\r"
            "  \tDisplay some general statistics\r"
            "  > \tstats\r"
            "Example:\r"
            "  \tDisplay statistics for content\r"
            "  > \tstats content\r"
        )

    def _display_general(self) -> None:
        stats: _Stats = _Stats(self._context.database.list_of_teases)
        print(f'{len(self._context.database.list_of_teases):>12,}  teases')
        print(f'{stats.count_of_missing_authors:>12,}  teases by unknown authors')
        print(f'{len(stats.map_of_author_to_tease_count.keys()):>12,}  authors')
        print(f'{len(stats.map_of_tag_to_occurrence_count.keys()):>12,}  unique tags')
        print(f'{stats.count_of_totm_winners:>12,}  TOTM winners')
        print(f'{stats.count_of_totm_nominees:>12,}  TOTM nominees')
        print(f'{stats.total_count_of_words:>12,}  total content words')

    def _display_tags(self) -> None:
        stats: _Stats = _Stats(self._context.database.list_of_teases)

        print('Top occurrences of tags:')
        sorted_list_of_tags_and_occurrence_count: List[Tuple[str, int]] = sorted(stats.map_of_tag_to_occurrence_count.items(), key=lambda x: x[1], reverse=True)
        tag: str
        count: int
        for tag, count in sorted_list_of_tags_and_occurrence_count[:20]:
            print(f'{count:>8,}  {tag}')

    def _display_authors(self) -> None:
        stats: _Stats = _Stats(self._context.database.list_of_teases)

        print('Top number of teases by author:')
        sorted_list_of_authors_and_tease_count: List[Tuple[str, int]] = sorted(stats.map_of_author_to_tease_count.items(), key=lambda x: x[1], reverse=True)
        author: str
        tease_count: int
        for author, tease_count in sorted_list_of_authors_and_tease_count[:20]:
            print(f'{tease_count:>8,}  {author}')

        print('\nTop TOTM awards by author:')
        sorted_list_of_authors_and_totm_stats: List[Tuple[str, _TotmStats]] = sorted(stats.map_of_author_to_totm_stats.items(), key=lambda x: (x[1].wins, x[1].nominations), reverse=True)
        totm_stats: _TotmStats
        for author, totm_stats in sorted_list_of_authors_and_totm_stats[:20]:
            print(f'{totm_stats.wins:>6,} wins  {totm_stats.nominations:>4,} nominations  {author}')

    def _display_content(self) -> None:
        stats: _Stats = _Stats(self._context.database.list_of_teases)

        print('Top word count by tease:')
        sorted_list_of_content_stats: List[_TeaseContentStats] = sorted(stats.list_of_content_stats, key=lambda stat: stat.word_count, reverse=True)
        content_stats: _TeaseContentStats
        for content_stats in sorted_list_of_content_stats[:20]:
            tease_id_text: str = '#' + str(content_stats.tease.tease_id)
            print(f'{content_stats.word_count:>12,}  {tease_id_text:>7}  {content_stats.tease.title} : [{content_stats.tease.author_name}, @{content_stats.tease.author_id}]')

        print('\nTop word count by author:')
        sorted_list_of_authors_and_word_count: List[Tuple[str, int]] = sorted(stats.map_of_author_to_word_count.items(), key=lambda x: x[1], reverse=True)
        author: str
        word_count: int
        for author, word_count in sorted_list_of_authors_and_word_count[:20]:
            print(f'{word_count:>12,}  {author}')

@dataclass
class _TeaseContentStats:
    tease: Tease
    word_count: int
    text_size: int

@dataclass
class _TotmStats:
    author_name: str
    wins: int
    nominations: int

class _Stats:
    def __init__(self, list_of_teases: List[Tease]) -> None:
        self._list_of_teases: List[Tease] = list_of_teases
        self._map_of_tag_to_occurrence_count: Optional[Dict[str, int]] = None
        self._map_of_author_to_tease_count: Optional[Dict[str, int]] = None
        self._count_of_missing_authors: Optional[int] = None
        self._total_count_of_words: Optional[int] = None
        self._list_of_content_stats: Optional[List[_TeaseContentStats]] = None
        self._map_of_author_to_word_count: Optional[Dict[str, int]] = None
        self._map_of_author_to_totm_stats: Optional[Dict[str, _TotmStats]] = None
        self._count_of_totm_winners: Optional[int] = None
        self._count_of_totm_nominees: Optional[int] = None

    @property
    def map_of_tag_to_occurrence_count(self) -> Dict[str, int]:
        if self._map_of_tag_to_occurrence_count is None:
            self._gather_tag_stats()
        return self._map_of_tag_to_occurrence_count or {}

    @property
    def map_of_author_to_tease_count(self) -> Dict[str, int]:
        if self._map_of_author_to_tease_count is None:
            self._gather_author_stats()
        return self._map_of_author_to_tease_count or {}

    @property
    def count_of_missing_authors(self) -> int:
        if self._count_of_missing_authors is None:
            self._gather_author_stats()
        return self._count_of_missing_authors or 0

    @property
    def total_count_of_words(self) -> int:
        if self._total_count_of_words is None:
            self._gather_content_stats()
        return self._total_count_of_words or 0

    @property
    def list_of_content_stats(self) -> List[_TeaseContentStats]:
        if self._list_of_content_stats is None:
            self._gather_content_stats()
        return self._list_of_content_stats or []

    @property
    def map_of_author_to_word_count(self) -> Dict[str, int]:
        if self._map_of_author_to_word_count is None:
            self._gather_content_stats()
        return self._map_of_author_to_word_count or {}

    @property
    def map_of_author_to_totm_stats(self) -> Dict[str, _TotmStats]:
        if self._map_of_author_to_totm_stats is None:
            self._gather_totm_stats()
        return self._map_of_author_to_totm_stats or {}

    @property
    def count_of_totm_winners(self) -> int:
        if self._count_of_totm_winners is None:
            self._gather_totm_stats()
        return self._count_of_totm_winners or 0

    @property
    def count_of_totm_nominees(self) -> int:
        if self._count_of_totm_nominees is None:
            self._gather_totm_stats()
        return self._count_of_totm_nominees or 0

    def _gather_tag_stats(self) -> None:
        self._map_of_tag_to_occurrence_count = {}
        tease: Tease
        for tease in self._list_of_teases:
            tag: str
            for tag in tease.list_of_tags:
                try:
                    value: int = self._map_of_tag_to_occurrence_count[tag]
                    self._map_of_tag_to_occurrence_count[tag] = value + 1
                except KeyError:
                    self._map_of_tag_to_occurrence_count[tag] = 1

    def _gather_author_stats(self) -> None:
        self._map_of_author_to_tease_count = {}
        self._count_of_missing_authors = 0
        tease: Tease
        for tease in self._list_of_teases:
            if tease.author_id == 0:
                self._count_of_missing_authors += 1
            else:
                try:
                    value: int = self._map_of_author_to_tease_count[tease.author_name]
                    self._map_of_author_to_tease_count[tease.author_name] = value + 1
                except KeyError:
                    self._map_of_author_to_tease_count[tease.author_name] = 1

    def _gather_content_stats(self) -> None:
        self._list_of_content_stats = []
        self._map_of_author_to_word_count = {}
        self._total_count_of_words = 0

        tease: Tease
        for tease in self._list_of_teases:
            tease_count_of_words: int = 0
            tease_text_size: int = 0
            text: str
            for text in tease.list_of_text_blocks:
                tease_count_of_words += count_words(text)
                tease_text_size += len(text)
            self._list_of_content_stats.append(_TeaseContentStats(tease, tease_count_of_words, tease_text_size))
            self._total_count_of_words += tease_count_of_words
            if tease.author_id != 0:
                try:
                    value: int = self._map_of_author_to_word_count[tease.author_name]
                    self._map_of_author_to_word_count[tease.author_name] = value + tease_count_of_words
                except KeyError:
                    self._map_of_author_to_word_count[tease.author_name] = tease_count_of_words

    def _gather_totm_stats(self) -> None:
        self._map_of_author_to_totm_stats = {}
        self._count_of_totm_winners = 0
        self._count_of_totm_nominees = 0
        tease: Tease
        for tease in self._list_of_teases:
            delta_wins: int = 0
            delta_nominations: int = 0
            if tease.totm_status == TotmStatus.WINNER:
                delta_wins = 1
            elif tease.totm_status == TotmStatus.NOMINEE:
                delta_nominations = 1

            self._count_of_totm_winners += delta_wins
            self._count_of_totm_nominees += delta_nominations

            if tease.author_id != 0 and (delta_wins != 0 or delta_nominations != 0):
                try:
                    stats: _TotmStats = self._map_of_author_to_totm_stats[tease.author_name]
                    stats.wins += delta_wins
                    stats.nominations += delta_nominations
                except KeyError:
                    self._map_of_author_to_totm_stats[tease.author_name] = _TotmStats(tease.author_name, delta_wins, delta_nominations)

_MAP_OF_CHOICES_TO_DELEGATE: Dict[str, Callable[[StatsCommand], None]] = {
    'tags': StatsCommand._display_tags,
    'authors': StatsCommand._display_authors,
    'content': StatsCommand._display_content
}
