@REM MiloDB by FrozenWolf is marked with CC0 1.0.
@REM To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
@echo off

REM spell-checker: ignore PYTHONOPTIMIZE distpath mvdb setlocal venv workpath
setlocal EnableDelayedExpansion
goto main

:buildType %= type: 'terminal' or 'gui' =%
    set TYPE=%1

    echo ** Prepare virtual environment for '!TYPE!'
    python -m venv "%TEMP%\mvdb\venv-!TYPE!" --clear --upgrade-deps
    call "%TEMP%\mvdb\venv-!TYPE!\Scripts\activate.bat"

    echo ** Install packages for '!TYPE!'
    pip install -r requirements-build.txt -r "requirements-run-!TYPE!.txt"

    echo ** Build executable for '!TYPE!'
    set PYTHONOPTIMIZE=2
    pyinstaller --distpath bin --workpath "%TEMP%\mvdb\build-!TYPE!" --clean "milodb-!TYPE!.spec"

    echo ** Dump requirements for '!TYPE!'
    pip freeze

    call "%TEMP%\mvdb\venv-!TYPE!\Scripts\deactivate.bat"
    goto :EOF

:main
set BUILD_TERMINAL=false
set BUILD_GUI=false
if "%~1" == "" (
    set BUILD_TERMINAL=true
    set BUILD_GUI=true
) else (
    :nextArg
    if "%~1" == "" (
        goto endOfArgs
    ) else if "%~1" == "terminal" (
        set BUILD_TERMINAL=true
    ) else if "%~1" == "gui" (
        set BUILD_GUI=true
    ) else (
        echo Unknown build option '%~1'
        exit /b 1
    )
    shift
    goto nextArg
)
:endOfArgs

if !BUILD_TERMINAL! == true call :buildType terminal
if !BUILD_GUI! == true call :buildType gui
