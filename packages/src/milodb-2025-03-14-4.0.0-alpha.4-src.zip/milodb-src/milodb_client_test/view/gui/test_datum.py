# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from typing import TYPE_CHECKING
from unittest import TestCase
from unittest.mock import ANY, Mock, call
from milodb_client.view.gui.datum import IDatum, SimpleDatum, SuppressingDatum
from milodb_common_test.test.strict_mock import InterfaceMock
if TYPE_CHECKING:
    from collections.abc import Callable

class TestSimpleDatum(TestCase):
    def test_get_returns_default_value(self) -> None:
        self.assertEqual(None, SimpleDatum(None).get())
        self.assertEqual('Frog', SimpleDatum('Frog').get())
        self.assertEqual(True, SimpleDatum(True).get())
        self.assertEqual(False, SimpleDatum(False).get())

    def test_get_returns_set_value(self) -> None:
        datum1 = SimpleDatum('Frog')
        datum1.set('Cat')
        self.assertEqual('Cat', datum1.get())

        datum2 = SimpleDatum(True)
        datum2.set(False)
        self.assertEqual(False, datum2.get())

    @staticmethod
    def test_add_listener_with_call_immediately_causes_listener_to_be_called() -> None:
        listener = Mock()
        datum1 = SimpleDatum('Frog')
        datum1.add_listener(listener, call_immediately=True)
        listener.assert_called_once_with(datum1)

    @staticmethod
    def test_add_listener_with_call_immediately_causes_only_new_listener_to_be_called() -> None:
        listener1 = Mock()
        listener2 = Mock()
        datum1 = SimpleDatum('Frog')
        datum1.add_listener(listener1)
        datum1.add_listener(listener2, call_immediately=True)
        listener1.assert_not_called()

    @staticmethod
    def test_add_listener_without_call_immediately_does_not_call_listener() -> None:
        listener = Mock()
        datum1 = SimpleDatum('Frog')
        datum1.add_listener(listener)
        listener.assert_not_called()

    @staticmethod
    def test_set_causes_listener_to_be_called() -> None:
        listener = Mock()
        datum = SimpleDatum('Frog')
        datum.add_listener(listener)
        datum.set('Cat')
        listener.assert_called_once_with(datum)

    @staticmethod
    def test_set_causes_all_listeners_to_be_called() -> None:
        listener1 = Mock()
        listener2 = Mock()
        listener3 = Mock()
        datum = SimpleDatum('Frog')
        datum.add_listener(listener1)
        datum.add_listener(listener2)
        datum.add_listener(listener3)
        datum.set('Cat')
        listener1.assert_called_once_with(datum)
        listener2.assert_called_once_with(datum)
        listener3.assert_called_once_with(datum)

    @staticmethod
    def test_set_with_same_default_value_does_not_call_listeners() -> None:
        listener = Mock()
        datum = SimpleDatum('Frog')
        datum.add_listener(listener)
        datum.set('Frog')
        listener.assert_not_called()

    @staticmethod
    def test_set_with_same_new_value_does_not_call_listeners() -> None:
        listener = Mock()
        datum = SimpleDatum('Frog')
        datum.add_listener(listener)
        datum.set('Cat')
        datum.set('Cat')
        listener.assert_called_once_with(datum)

    @staticmethod
    def test_set_with_two_new_values_calls_listeners() -> None:
        listener = Mock()
        datum = SimpleDatum('Frog')
        datum.add_listener(listener)
        datum.set('Cat')
        datum.set('Frog')
        listener.assert_has_calls([call(datum), call(datum)])

    @staticmethod
    def test_removing_listener_prevents_call() -> None:
        listener1 = Mock()
        listener2 = Mock()
        listener3 = Mock()
        datum = SimpleDatum('Frog')
        datum.add_listener(listener1)
        datum.add_listener(listener2)
        datum.add_listener(listener3)
        datum.remove_listener(listener2)
        datum.set('Cat')
        listener1.assert_called_once_with(datum)
        listener2.assert_not_called()
        listener3.assert_called_once_with(datum)

    @staticmethod
    def test_removing_non_existant_listener_is_harmless() -> None:
        listener1 = Mock()
        listener2 = Mock()
        listener3 = Mock()
        datum = SimpleDatum('Frog')
        datum.add_listener(listener1)
        datum.add_listener(listener3)
        datum.remove_listener(listener2)
        datum.set('Cat')
        listener1.assert_called_once_with(datum)
        listener2.assert_not_called()
        listener3.assert_called_once_with(datum)

    @staticmethod
    def test_removing_all_listeners_causes_no_callbacks() -> None:
        listener1 = Mock()
        listener2 = Mock()
        listener3 = Mock()
        datum = SimpleDatum('Frog')
        datum.add_listener(listener1)
        datum.add_listener(listener2)
        datum.add_listener(listener3)
        datum.remove_listener(listener2)
        datum.remove_listener(listener1)
        datum.remove_listener(listener3)
        datum.set('Cat')
        listener1.assert_not_called()
        listener2.assert_not_called()
        listener3.assert_not_called()

class TestSuppressingDatum(TestCase):
    def test_get_calls_proxy(self) -> None:
        proxy_datum = InterfaceMock(IDatum)
        proxy_datum.get = Mock(return_value=1234)
        datum: SuppressingDatum[int] = SuppressingDatum(proxy_datum)
        self.assertEqual(1234, datum.get())

    @staticmethod
    def test_set_calls_proxy() -> None:
        proxy_datum = InterfaceMock(IDatum)
        proxy_datum.set = Mock()
        datum: SuppressingDatum[int] = SuppressingDatum(proxy_datum)
        datum.set(5678)
        proxy_datum.set.assert_called_once_with(5678)

    @staticmethod
    def test_add_listener_attaches_to_proxy() -> None:
        proxy_datum = InterfaceMock(IDatum)
        proxy_datum.add_listener = Mock()
        listener = Mock()
        datum: SuppressingDatum[int] = SuppressingDatum(proxy_datum)
        datum.add_listener(listener)
        proxy_datum.add_listener.assert_called_once()

    @staticmethod
    def test_add_listener_multiple_times_attaches_to_proxy_once() -> None:
        proxy_datum = InterfaceMock(IDatum)
        proxy_datum.add_listener = Mock()
        listener1 = Mock()
        listener2 = Mock()
        listener3 = Mock()
        datum: SuppressingDatum[int] = SuppressingDatum(proxy_datum)
        datum.add_listener(listener1)
        datum.add_listener(listener2)
        datum.add_listener(listener3)
        proxy_datum.add_listener.assert_called_once()

    @staticmethod
    def test_remove_listener_detaches_from_proxy() -> None:
        proxy_datum = InterfaceMock(IDatum)
        proxy_datum.add_listener = Mock()
        proxy_datum.remove_listener = Mock()
        listener = Mock()
        datum: SuppressingDatum[int] = SuppressingDatum(proxy_datum)
        datum.add_listener(listener)
        datum.remove_listener(listener)
        proxy_datum.remove_listener.assert_called_once()

    @staticmethod
    def test_remove_subset_of_listeners_does_not_detach_from_proxy() -> None:
        proxy_datum = InterfaceMock(IDatum)
        proxy_datum.add_listener = Mock()
        proxy_datum.remove_listener = Mock()
        listener1 = Mock()
        listener2 = Mock()
        listener3 = Mock()
        datum: SuppressingDatum[int] = SuppressingDatum(proxy_datum)
        datum.add_listener(listener1)
        datum.add_listener(listener2)
        datum.add_listener(listener3)
        datum.remove_listener(listener3)
        datum.remove_listener(listener1)
        proxy_datum.remove_listener.assert_not_called()

    @staticmethod
    def test_remove_all_listeners_detaches_from_proxy() -> None:
        proxy_datum = InterfaceMock(IDatum)
        proxy_datum.add_listener = Mock()
        proxy_datum.remove_listener = Mock()
        listener1 = Mock()
        listener2 = Mock()
        listener3 = Mock()
        datum: SuppressingDatum[int] = SuppressingDatum(proxy_datum)
        datum.add_listener(listener1)
        datum.add_listener(listener2)
        datum.add_listener(listener3)
        datum.remove_listener(listener3)
        datum.remove_listener(listener1)
        datum.remove_listener(listener2)
        proxy_datum.remove_listener.assert_called_once()

    @staticmethod
    def test_remove_and_add_listener_reattaches_to_proxy() -> None:
        proxy_datum = InterfaceMock(IDatum)
        proxy_datum.add_listener = Mock()
        proxy_datum.remove_listener = Mock()
        listener = Mock()
        datum: SuppressingDatum[int] = SuppressingDatum(proxy_datum)
        datum.add_listener(listener)
        datum.remove_listener(listener)
        datum.add_listener(listener)
        proxy_datum.add_listener.assert_has_calls([call(ANY), call(ANY)])

    @staticmethod
    def test_set_does_not_call_listeners() -> None:
        proxy_datum = InterfaceMock(IDatum)
        proxy_datum.add_listener = Mock()
        listener = Mock()

        datum: SuppressingDatum[int] = SuppressingDatum(proxy_datum)
        datum.add_listener(listener)

        proxy_listener: Callable[[IDatum[int]], None] = proxy_datum.add_listener.call_args[0][0]
        proxy_datum.set = Mock(side_effect=lambda _: proxy_listener(proxy_datum))

        datum.set(1234)

        listener.assert_not_called()

    @staticmethod
    def test_call_to_proxy_listener_calls_listeners() -> None:
        proxy_datum = InterfaceMock(IDatum)
        proxy_datum.add_listener = Mock()
        listener = Mock()

        datum: SuppressingDatum[int] = SuppressingDatum(proxy_datum)
        datum.add_listener(listener)

        proxy_listener: Callable[[IDatum[int]], None] = proxy_datum.add_listener.call_args[0][0]
        proxy_listener(proxy_datum)

        listener.assert_called_once_with(datum)

    @staticmethod
    def test_call_to_proxy_listener_calls_multiple_listeners() -> None:
        proxy_datum = InterfaceMock(IDatum)
        proxy_datum.add_listener = Mock()
        listener1 = Mock()
        listener2 = Mock()
        listener3 = Mock()

        datum: SuppressingDatum[int] = SuppressingDatum(proxy_datum)
        datum.add_listener(listener1)
        datum.add_listener(listener2)
        datum.add_listener(listener3)

        proxy_listener: Callable[[IDatum[int]], None] = proxy_datum.add_listener.call_args[0][0]
        proxy_listener(proxy_datum)

        listener1.assert_called_once_with(datum)
        listener2.assert_called_once_with(datum)
        listener3.assert_called_once_with(datum)
