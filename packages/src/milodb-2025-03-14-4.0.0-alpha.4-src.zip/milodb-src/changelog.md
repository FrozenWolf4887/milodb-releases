# MiloDB Experimental GUI, Change Log

## 4.0.0-alpha.4, 2025-03-14

* Changed: 'Open Author...' in popup menu will be disabled if author is not known
* Added: Popup menu now includes opening of a tease author's tease list
* Added: Popup menu now includes copying of tease and author URIs

## 4.0.0-alpha.3, 2025-03-13

* Fixed: Update no longer tries to execute 'None' when switching to a non-supported platform
* Fixed: Update no longer fails when trying to delete non-existent deprecated config files
* Changed: During update, temporary files are placed in subdirectory of main application instead of system temp
* Added: Warn user when trying to update/switch to a variant with an unsupported main executable
* Added: Scroll selected tease into view in other panels if not visible
* Added: Popup menu to open tease/author profile

## 4.0.0-alpha.2, 2025-03-10

* Fixed: Windows - Scrolling the card panel up and down with the scroll bar crashed the application

## 4.0.0-alpha.1, 2025-03-09

* Added: Initial release of GUI for evaluation edition