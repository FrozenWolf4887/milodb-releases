# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
import itertools
import tkinter as tk
import tkinter.font as tkfont
from collections.abc import Callable, Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, override
from PIL import Image, ImageTk
from milodb_client.database.author import AuthorStatus
from milodb_client.database.tease import Tease, TotmStatus
from milodb_client.output.support import get_list_of_metadata_indices
from milodb_client.query.tease_match import TeaseMatch
from milodb_client.resources import resource_path
from milodb_client.util.sort_keys import AUTHOR_ID_SORT_KEY, DATE_SORT_KEY, ISortKey, MATCH_COUNT_SORT_KEY, OrderedSortKey, RATING_SORT_KEY, TEASE_ID_SORT_KEY, TITLE_SORT_KEY, TOTM_SORT_KEY, TYPE_SORT_KEY
from milodb_client.util.tease_match_sorter import ITeaseMatchSorter
from milodb_client.view.gui import general_colours, general_layout
from milodb_client.view.gui.banner_text import BANNER_FONT_NAME, BANNER_NO_MATCHING_TEASES
from milodb_client.view.gui.canvas_widgets import CanvasPlainText, CanvasSequenceText, get_canvas_event_relative_coord
from milodb_client.view.gui.datum import IDatum, SuppressingDatum
from milodb_common.util.ref import IRef
from milodb_common.view.gui.metrics import Bounds, MutableBounds, Padding, Point, Size
if TYPE_CHECKING:
    from milodb_client.view.gui.widget_id import WidgetId

# spell-checker: ignore activebackground borderwidth highlightthickness linespace padx pady scrollregion troughcolor tkfont xscrollcommand yscrollcommand

_LINUX_AND_OSX_MOUSEWHEEL_UP_BUTTON: int = 5
_LINUX_AND_OSX_MOUSEWHEEL_DOWN_BUTTON: int = 4

_SCROLL_PAGE_UNITS: int = 10

_HEADER_TEXT_PADDING: Padding = Padding(left=5, top=2, right=5, bottom=2)
_HEADER_VERTICAL_LINE_WIDTH: int = 1
_HEADER_HORIZONTAL_LINE_HEIGHT: int = 1
_CONTENT_TEXT_PADDING: Padding = Padding(left=5, top=2, right=5, bottom=2)
_CONTENT_VERTICAL_LINE_WIDTH: int = 1
_CONTENT_HORIZONTAL_LINE_HEIGHT: int = 1
_CONTENT_HIGHLIGHT_PADDING: Padding = Padding(left=2, top=1, right=2, bottom=1)
_BANNER_PADDING_TOP: int = 4

_HORIZONTAL_LINE_TAG: str = 'hl'
_VERTICAL_LINE_TAG: str = 'vl'

_COL_PANEL_BACK: str = general_colours.PANEL_BACK
_COL_HEADING_BACK: str = general_colours.HEADER_BACK
_COL_BANNER_FORE: str = general_colours.VALUE_TEXT_FORE
_COL_SCROLLBAR_BACK: str = general_colours.SCROLLBAR_BACK
_COL_SCROLLBAR_FORE: str = general_colours.SCROLLBAR_FORE
_COL_SCROLLBAR_ACTIVE: str = general_colours.SCROLLBAR_ACTIVE
_SCROLLBAR_WIDTH: int = 15

_COL_HEADER_INDEX_FORE: str = general_colours.HEADER_INDEX_FORE
_COL_HEADER_HITS_FORE: str = general_colours.HEADER_HITS_FORE
_COL_HEADER_TEASEID_FORE: str = general_colours.HEADER_TEASEID_FORE
_COL_HEADER_TYPE_FORE: str = general_colours.HEADER_TYPE_FORE
_COL_HEADER_RATING_FORE: str = general_colours.HEADER_RATING_FORE
_COL_HEADER_DATE_FORE: str = general_colours.HEADER_DATE_FORE
_COL_HEADER_TITLE_FORE: str = general_colours.HEADER_TITLE_FORE
_COL_HEADER_AUTHOR_FORE: str = general_colours.HEADER_AUTHOR_FORE
_COL_HEADER_TOTM_FORE: str = '#FFF'
_COL_HEADER_TEASE_STATUS_FORE: str = '#FFF'
_COL_HEADER_AUTHOR_STATUS_FORE: str = '#FFF'
_COL_HEADER_AUTHORID_FORE: str = '#FFF'
_COL_HEADER_IMAGE_COUNT_FORE: str = '#FFF'
_COL_HEADER_UNIQUE_IMAGE_COUNT_FORE: str = '#FFF'

_COL_VALUE_INDEX_FORE: str = general_colours.VALUE_INDEX_FORE
_COL_VALUE_HITS_FORE: str = general_colours.VALUE_HITS_FORE
_COL_VALUE_TEASEID_FORE: str = '#FFF'
_COL_VALUE_TYPE_FORE: str = '#FFF'
_COL_VALUE_RATING_FORE: str = general_colours.VALUE_RATING_FORE
_COL_VALUE_DATE_FORE: str = general_colours.VALUE_DATE_FORE
_COL_VALUE_TEASE_STATUS_FORE: str = '#FFF'
_COL_VALUE_TITLE_FORE: str = general_colours.VALUE_TITLE_FORE
_COL_VALUE_AUTHOR_FORE: str = general_colours.VALUE_AUTHOR_FORE
_COL_VALUE_AUTHOR_STATUS_FORE: str = '#FFF'
_COL_VALUE_AUTHOR_ID_FORE: str = '#FFF'
_COL_VALUE_IMAGE_COUNT_FORE: str = '#FFF'
_COL_VALUE_UNIQUE_IMAGE_COUNT_FORE: str = '#FFF'
_COL_HIGHLIGHT_TEXT_BACK: str = general_colours.HIGHLIGHT_TEXT_BACK
_COL_HIGHLIGHT_TEXT_FORE: str = general_colours.HIGHLIGHT_TEXT_FORE
_COL_HIGHLIGHT_TEXT_BORDER: str = general_colours.HIGHLIGHT_TEXT_BORDER
_COL_SELECTED_ROW_BACK: str = '#443'
_COL_ROW_DIVIDER_LINE: str = general_colours.ITEM_NORMAL_BACK

_LAYOUT_RELIEF: general_layout.Relief = general_layout.PANEL_RELIEF
_LAYOUT_BORDER_WIDTH: int = general_layout.PANEL_BORDER_WIDTH
_LAYOUT_PADDING_X: int = general_layout.PANEL_PADDING_X
_LAYOUT_PADDING_Y: int = general_layout.PANEL_PADDING_Y

@dataclass
class _Column:
    heading_name: str
    heading_colour: str
    renderer: Callable[[int, int, str, TeaseMatch], Bounds]
    sort_key: ISortKey | None
    heading_width: int = 0
    current_width: int = 0
    max_content_width: int = 0

class TableListPanel(tk.Frame):
    def __init__(self, master: tk.Misc, list_of_tease_matches: IDatum[Sequence[TeaseMatch]], selected_tease_index: IDatum[int | None], tease_match_sorter: ITeaseMatchSorter, list_of_active_sort_keys: IRef[Sequence[OrderedSortKey]], call_open_tease: Callable[[Tease], None], call_popup_tease_menu: Callable[[tk.Misc, int, int, TeaseMatch], None]) -> None:
        super().__init__(master, background=_COL_PANEL_BACK, relief=_LAYOUT_RELIEF, padx=_LAYOUT_PADDING_X, pady=_LAYOUT_PADDING_Y, borderwidth=_LAYOUT_BORDER_WIDTH)
        self._list_of_tease_matches: IDatum[Sequence[TeaseMatch]] = list_of_tease_matches
        self._selected_tease_index: SuppressingDatum[int | None] = SuppressingDatum(selected_tease_index)
        self._tease_match_sorter: ITeaseMatchSorter = tease_match_sorter
        self._list_of_active_sort_keys: IRef[Sequence[OrderedSortKey]] = list_of_active_sort_keys
        self._call_open_tease: Callable[[Tease], None] = call_open_tease
        self._call_popup_tease_menu: Callable[[tk.Misc, int, int, TeaseMatch], None] = call_popup_tease_menu

        self._font: tkfont.Font = tkfont.Font(self, 'Arial 11')
        self._banner_font: tkfont.Font = tkfont.Font(self, BANNER_FONT_NAME)
        self._text_height: int = self._font.metrics('linespace')
        self._row_height: int = self._text_height + _CONTENT_TEXT_PADDING.height + _CONTENT_HORIZONTAL_LINE_HEIGHT
        self._totm_icon_size: Size = Size(self._text_height, self._text_height)
        self._banner_text: CanvasPlainText | None = None

        totm_nominee_image: ImageTk.PhotoImage = ImageTk.PhotoImage(Image.open(resource_path(Path('milodb-totm-nominee.png'))).resize(self._totm_icon_size.to_tuple()))
        totm_winner_image: ImageTk.PhotoImage = ImageTk.PhotoImage(Image.open(resource_path(Path('milodb-totm-winner.png'))).resize(self._totm_icon_size.to_tuple()))

        self._map_of_totm_to_image: dict[TotmStatus, ImageTk.PhotoImage] = {
            TotmStatus.NOMINEE: totm_nominee_image,
            TotmStatus.WINNER: totm_winner_image,
        }

        self._list_of_columns: list[_Column] = [
            _Column('Idx', _COL_HEADER_INDEX_FORE, self._render_match_index, None),
            _Column('Hits', _COL_HEADER_HITS_FORE, self._render_match_hits, MATCH_COUNT_SORT_KEY),
            _Column('TID', _COL_HEADER_TEASEID_FORE, self._render_tease_id, TEASE_ID_SORT_KEY),
            _Column('Type', _COL_HEADER_TYPE_FORE, self._render_tease_type, TYPE_SORT_KEY),
            _Column('Rating', _COL_HEADER_RATING_FORE, self._render_tease_rating, RATING_SORT_KEY),
            _Column('TOTM', _COL_HEADER_TOTM_FORE, self._render_totm_status, TOTM_SORT_KEY),
            _Column('Date', _COL_HEADER_DATE_FORE, self._render_tease_date, DATE_SORT_KEY),
            _Column('Status', _COL_HEADER_TEASE_STATUS_FORE, self._render_tease_status, None),
            _Column('Title', _COL_HEADER_TITLE_FORE, self._render_tease_title, TITLE_SORT_KEY),
            _Column('Author', _COL_HEADER_AUTHOR_FORE, self._render_tease_author, None),
            _Column('Status', _COL_HEADER_AUTHOR_STATUS_FORE, self._render_tease_author_status, None),
            _Column('AID', _COL_HEADER_AUTHORID_FORE, self._render_author_id, AUTHOR_ID_SORT_KEY),
            _Column('Img', _COL_HEADER_IMAGE_COUNT_FORE, self._render_image_count, None),
            _Column('Umg', _COL_HEADER_UNIQUE_IMAGE_COUNT_FORE, self._render_unique_image_count, None),
        ]

        self._content_bounds: MutableBounds = Bounds.empty()
        self._selection_bar_id: WidgetId | None = None
        self._current_top_index: int = 0
        self._current_bottom_index: int = -1

        self._create_header_canvas()
        self._create_content_canvas()
        self._redraw_header()
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=1)

        self._list_of_tease_matches.add_listener(self._on_list_of_tease_matches_changed, call_immediately=True)
        self._selected_tease_index.add_listener(self._on_selected_tease_index_changed, call_immediately=True)

    @override
    def destroy(self) -> None:
        self._list_of_tease_matches.remove_listener(self._on_list_of_tease_matches_changed)
        self._selected_tease_index.remove_listener(self._on_selected_tease_index_changed)
        self._destroy_banner_text()
        super().destroy()

    def _on_list_of_tease_matches_changed(self, _: IDatum[Sequence[TeaseMatch]]) -> None:
        column: _Column
        for column in self._list_of_columns:
            column.current_width = 0
            column.max_content_width = 0
        self._heading_canvas.xview_moveto(0)
        self._redraw_header()

        self._content_canvas.delete(tk.ALL)
        self._content_canvas.xview_moveto(0)
        self._content_canvas.yview_moveto(0)
        self._selection_bar_id = None
        self._current_top_index = 0
        self._current_bottom_index = -1
        self._content_bounds = MutableBounds(0, 0, 0, (len(self._list_of_tease_matches.get()) * self._row_height) - _CONTENT_HORIZONTAL_LINE_HEIGHT)
        self._content_canvas.config(scrollregion=self._content_bounds.to_tuple())
        self._redraw_vertical_content_lines(self._content_bounds.height)
        self._update_visible_rows()

    def _on_selected_tease_index_changed(self, _: IDatum[int | None]) -> None:
        row: int | None = self._selected_tease_index.get()
        self._redraw_selection_bar(row)
        if row is not None:
            self._ensure_visible_row(row)

    def _ensure_visible_row(self, row: int) -> None:
        number_of_rows: int = len(self._list_of_tease_matches.get())
        top_index, bottom_index = self._get_visible_top_and_bottom_row_indices(include_partially_visible=False)
        if row < top_index or row > bottom_index:
            max_rows_per_panel: float = self._content_canvas.winfo_height() / self._row_height
            scroll_position: float = max(0.0, (row - (max_rows_per_panel / 2) + 0.5) / number_of_rows)
            self._content_canvas.yview_moveto(scroll_position)
            self._update_visible_rows()
        self._redraw_selection_bar(row)

    def _update_visible_rows(self) -> None:
        self._destroy_banner_text()
        if not self._list_of_tease_matches:
            self._add_banner_text(BANNER_NO_MATCHING_TEASES)

        top_index: int
        bottom_index: int
        top_index, bottom_index = self._get_visible_top_and_bottom_row_indices(include_partially_visible=True)
        bottom_index = min(bottom_index, len(self._list_of_tease_matches.get()) - 1)

        # Draw rows coming into view

        for index in itertools.chain(
            range(max(self._current_bottom_index + 1, top_index), bottom_index + 1),
            range(top_index, min(self._current_top_index, bottom_index + 1)),
            ):
            self._draw_row(index)

        # Remove rows dropped out of view

        for index in itertools.chain(
            range(self._current_top_index, min(top_index, self._current_bottom_index + 1)),
            range(max(bottom_index + 1, self._current_top_index), self._current_bottom_index + 1),
            ):
            self._remove_row(index)

        self._current_top_index = top_index
        self._current_bottom_index = bottom_index

        self._redraw_if_any_columns_are_wider()

        # Redraw horizontal lines

        self._content_canvas.delete(_HORIZONTAL_LINE_TAG)

        line_width: int = max(self._content_bounds.width, self._content_canvas.winfo_width())
        offset_y = (top_index + 1) * self._row_height - _CONTENT_HORIZONTAL_LINE_HEIGHT
        for _ in range(top_index, bottom_index):
            self._content_canvas.create_line(0, offset_y, line_width, offset_y, width=_CONTENT_HORIZONTAL_LINE_HEIGHT, fill=_COL_ROW_DIVIDER_LINE, tags=_HORIZONTAL_LINE_TAG)
            offset_y += self._row_height

        # Ensure selection bar is lowest in Z-order

        if self._selection_bar_id is not None:
            self._content_canvas.tag_lower(self._selection_bar_id, tk.ALL)

    def _redraw_if_any_columns_are_wider(self) -> None:
        if any(column.max_content_width > column.current_width for column in self._list_of_columns):
            total_row_width: int = 0
            for column in self._list_of_columns:
                column.current_width = max(column.heading_width, column.max_content_width)
                total_row_width += column.current_width + _HEADER_VERTICAL_LINE_WIDTH
            self._content_bounds.right = total_row_width - _HEADER_VERTICAL_LINE_WIDTH
            self._content_canvas.config(scrollregion=self._content_bounds.to_tuple())
            self._heading_canvas.config(scrollregion=(0, 0, self._content_bounds.width, 0))
            self._redraw_header()
            for index in range(self._current_top_index, self._current_bottom_index + 1):
                self._remove_row(index)
                self._draw_row(index)

            self._redraw_vertical_content_lines(self._content_bounds.height)
            self._redraw_selection_bar(self._selected_tease_index.get())

    def _draw_row(self, index: int) -> None:
        cell_x: int = 0
        cell_y = index * self._row_height

        bounds: Bounds | None = None
        column: _Column
        for column in self._list_of_columns:
            bounds = column.renderer(cell_x, cell_y, f'row{index}', self._list_of_tease_matches.get()[index])
            column.max_content_width = max(column.max_content_width, bounds.width)
            cell_x += column.current_width + _CONTENT_VERTICAL_LINE_WIDTH

    def _remove_row(self, index: int) -> None:
        self._content_canvas.delete(f'row{index}')

    def _render_match_index(self, x: int, y: int, row_tag: str, tease_match: TeaseMatch) -> Bounds:
        text = CanvasSequenceText(
            self._content_canvas,
            x + _CONTENT_TEXT_PADDING.left, y + _CONTENT_TEXT_PADDING.top,
            text = str(tease_match.index_of_match),
            font = self._font,
            foreground = _COL_VALUE_INDEX_FORE,
            highlight_foreground = _COL_HIGHLIGHT_TEXT_FORE,
            highlight_background = _COL_HIGHLIGHT_TEXT_BACK,
            highlight_border = _COL_HIGHLIGHT_TEXT_BORDER,
            highlight_padding = _CONTENT_HIGHLIGHT_PADDING,
            list_of_indices = [],
            tag = row_tag,
        )
        return Bounds(x, y, text.bounds.right + _CONTENT_TEXT_PADDING.right, text.bounds.bottom + _CONTENT_TEXT_PADDING.bottom)

    def _render_match_hits(self, x: int, y: int, row_tag: str, tease_match: TeaseMatch) -> Bounds:
        text = CanvasSequenceText(
            self._content_canvas,
            x + _CONTENT_TEXT_PADDING.left, y + _CONTENT_TEXT_PADDING.top,
            text = str(tease_match.get_match_count()),
            font = self._font,
            foreground = _COL_VALUE_HITS_FORE,
            highlight_foreground = _COL_HIGHLIGHT_TEXT_FORE,
            highlight_background = _COL_HIGHLIGHT_TEXT_BACK,
            highlight_border = _COL_HIGHLIGHT_TEXT_BORDER,
            highlight_padding = _CONTENT_HIGHLIGHT_PADDING,
            list_of_indices = [],
            tag = row_tag,
        )
        return Bounds(x, y, text.bounds.right + _CONTENT_TEXT_PADDING.right, text.bounds.bottom + _CONTENT_TEXT_PADDING.bottom)

    def _render_tease_id(self, x: int, y: int, row_tag: str, tease_match: TeaseMatch) -> Bounds:
        text = CanvasSequenceText(
            self._content_canvas,
            x + _CONTENT_TEXT_PADDING.left, y + _CONTENT_TEXT_PADDING.top,
            text = str(tease_match.tease.get_tease_id()),
            font = self._font,
            foreground = _COL_VALUE_TEASEID_FORE,
            highlight_foreground = _COL_HIGHLIGHT_TEXT_FORE,
            highlight_background = _COL_HIGHLIGHT_TEXT_BACK,
            highlight_border = _COL_HIGHLIGHT_TEXT_BORDER,
            highlight_padding = _CONTENT_HIGHLIGHT_PADDING,
            list_of_indices = get_list_of_metadata_indices(Tease.get_tease_id, tease_match.list_of_field_matches),
            tag = row_tag,
        )
        return Bounds(x, y, text.bounds.right + _CONTENT_TEXT_PADDING.right, text.bounds.bottom + _CONTENT_TEXT_PADDING.bottom)

    def _render_tease_type(self, x: int, y: int, row_tag: str, tease_match: TeaseMatch) -> Bounds:
        text = CanvasSequenceText(
            self._content_canvas,
            x + _CONTENT_TEXT_PADDING.left, y + _CONTENT_TEXT_PADDING.top,
            text = tease_match.tease.get_text_of_property(Tease.get_type),
            font = self._font,
            foreground = _COL_VALUE_TYPE_FORE,
            highlight_foreground = _COL_HIGHLIGHT_TEXT_FORE,
            highlight_background = _COL_HIGHLIGHT_TEXT_BACK,
            highlight_border = _COL_HIGHLIGHT_TEXT_BORDER,
            highlight_padding = _CONTENT_HIGHLIGHT_PADDING,
            list_of_indices = get_list_of_metadata_indices(Tease.get_type, tease_match.list_of_field_matches),
            tag = row_tag,
        )
        return Bounds(x, y, text.bounds.right + _CONTENT_TEXT_PADDING.right, text.bounds.bottom + _CONTENT_TEXT_PADDING.bottom)

    def _render_tease_rating(self, x: int, y: int, row_tag: str, tease_match: TeaseMatch) -> Bounds:
        text = CanvasSequenceText(
            self._content_canvas,
            x + _CONTENT_TEXT_PADDING.left, y + _CONTENT_TEXT_PADDING.top,
            text = str(tease_match.tease.get_rating_value()),
            font = self._font,
            foreground = _COL_VALUE_RATING_FORE,
            highlight_foreground = _COL_HIGHLIGHT_TEXT_FORE,
            highlight_background = _COL_HIGHLIGHT_TEXT_BACK,
            highlight_border = _COL_HIGHLIGHT_TEXT_BORDER,
            highlight_padding = _CONTENT_HIGHLIGHT_PADDING,
            list_of_indices = get_list_of_metadata_indices(Tease.get_rating_value, tease_match.list_of_field_matches),
            tag = row_tag,
        )
        return Bounds(x, y, text.bounds.right + _CONTENT_TEXT_PADDING.right, text.bounds.bottom + _CONTENT_TEXT_PADDING.bottom)

    def _render_totm_status(self, x: int, y: int, row_tag: str, tease_match: TeaseMatch) -> Bounds:
        image: ImageTk.PhotoImage | None = self._map_of_totm_to_image.get(tease_match.tease.get_totm_status())
        if image:
            self._content_canvas.create_image(x + _CONTENT_TEXT_PADDING.left, y + _CONTENT_TEXT_PADDING.top, image=image, anchor=tk.NW, tags=row_tag)
            return Bounds(x, y, x + self._totm_icon_size.width + _CONTENT_TEXT_PADDING.width, y + self._totm_icon_size.height + _CONTENT_TEXT_PADDING.height)
        return Bounds(x, y, x, y)

    def _render_tease_date(self, x: int, y: int, row_tag: str, tease_match: TeaseMatch) -> Bounds:
        text = CanvasSequenceText(
            self._content_canvas,
            x + _CONTENT_TEXT_PADDING.left, y + _CONTENT_TEXT_PADDING.top,
            text = tease_match.tease.get_date().isoformat(),
            font = self._font,
            foreground = _COL_VALUE_DATE_FORE,
            highlight_foreground = _COL_HIGHLIGHT_TEXT_FORE,
            highlight_background = _COL_HIGHLIGHT_TEXT_BACK,
            highlight_border = _COL_HIGHLIGHT_TEXT_BORDER,
            highlight_padding = _CONTENT_HIGHLIGHT_PADDING,
            list_of_indices = get_list_of_metadata_indices(Tease.get_date, tease_match.list_of_field_matches),
            tag = row_tag,
        )
        return Bounds(x, y, text.bounds.right + _CONTENT_TEXT_PADDING.right, text.bounds.bottom + _CONTENT_TEXT_PADDING.bottom)

    def _render_tease_status(self, x: int, y: int, row_tag: str, tease_match: TeaseMatch) -> Bounds:
        if tease_match.tease.is_deleted():
            text = CanvasSequenceText(
                self._content_canvas,
                x + _CONTENT_TEXT_PADDING.left, y + _CONTENT_TEXT_PADDING.top,
                text = 'Deleted',
                font = self._font,
                foreground = _COL_VALUE_TEASE_STATUS_FORE,
                highlight_foreground = _COL_HIGHLIGHT_TEXT_FORE,
                highlight_background = _COL_HIGHLIGHT_TEXT_BACK,
                highlight_border = _COL_HIGHLIGHT_TEXT_BORDER,
                highlight_padding = _CONTENT_HIGHLIGHT_PADDING,
                list_of_indices = get_list_of_metadata_indices(Tease.is_deleted, tease_match.list_of_field_matches),
                tag = row_tag,
            )
            return Bounds(x, y, text.bounds.right + _CONTENT_TEXT_PADDING.right, text.bounds.bottom + _CONTENT_TEXT_PADDING.bottom)
        return Bounds(x, y, x, y)

    def _render_tease_title(self, x: int, y: int, row_tag: str, tease_match: TeaseMatch) -> Bounds:
        text = CanvasSequenceText(
            self._content_canvas,
            x + _CONTENT_TEXT_PADDING.left, y + _CONTENT_TEXT_PADDING.top,
            text = tease_match.tease.get_title(),
            font = self._font,
            foreground = _COL_VALUE_TITLE_FORE,
            highlight_foreground = _COL_HIGHLIGHT_TEXT_FORE,
            highlight_background = _COL_HIGHLIGHT_TEXT_BACK,
            highlight_border = _COL_HIGHLIGHT_TEXT_BORDER,
            highlight_padding = _CONTENT_HIGHLIGHT_PADDING,
            list_of_indices = get_list_of_metadata_indices(Tease.get_title, tease_match.list_of_field_matches),
            tag = row_tag,
        )
        return Bounds(x, y, text.bounds.right + _CONTENT_TEXT_PADDING.right, text.bounds.bottom + _CONTENT_TEXT_PADDING.bottom)

    def _render_tease_author(self, x: int, y: int, row_tag: str, tease_match: TeaseMatch) -> Bounds:
        if tease_match.tease.author.has_author:
            text = CanvasSequenceText(
                self._content_canvas,
                x + _CONTENT_TEXT_PADDING.left, y + _CONTENT_TEXT_PADDING.top,
                text = tease_match.tease.get_author_name(),
                font = self._font,
                foreground = _COL_VALUE_AUTHOR_FORE,
                highlight_foreground = _COL_HIGHLIGHT_TEXT_FORE,
                highlight_background = _COL_HIGHLIGHT_TEXT_BACK,
                highlight_border = _COL_HIGHLIGHT_TEXT_BORDER,
                highlight_padding = _CONTENT_HIGHLIGHT_PADDING,
                list_of_indices = get_list_of_metadata_indices(Tease.get_author_name, tease_match.list_of_field_matches),
                tag = row_tag,
            )
            return Bounds(x, y, text.bounds.right + _CONTENT_TEXT_PADDING.right, text.bounds.bottom + _CONTENT_TEXT_PADDING.bottom)
        return Bounds(x, y, x, y)

    def _render_tease_author_status(self, x: int, y: int, row_tag: str, tease_match: TeaseMatch) -> Bounds:
        text = CanvasSequenceText(
            self._content_canvas,
            x + _CONTENT_TEXT_PADDING.left, y + _CONTENT_TEXT_PADDING.top,
            text = _MAP_OF_AUTHOR_STATUS_TO_TEXT.get(tease_match.tease.get_author_status()) or '?',
            font = self._font,
            foreground = _COL_VALUE_AUTHOR_STATUS_FORE,
            highlight_foreground = _COL_HIGHLIGHT_TEXT_FORE,
            highlight_background = _COL_HIGHLIGHT_TEXT_BACK,
            highlight_border = _COL_HIGHLIGHT_TEXT_BORDER,
            highlight_padding = _CONTENT_HIGHLIGHT_PADDING,
            list_of_indices = get_list_of_metadata_indices(Tease.get_author_status, tease_match.list_of_field_matches),
            tag = row_tag,
        )
        return Bounds(x, y, text.bounds.right + _CONTENT_TEXT_PADDING.right, text.bounds.bottom + _CONTENT_TEXT_PADDING.bottom)

    def _render_author_id(self, x: int, y: int, row_tag: str, tease_match: TeaseMatch) -> Bounds:
        if tease_match.tease.author.has_author:
            text = CanvasSequenceText(
                self._content_canvas,
                x + _CONTENT_TEXT_PADDING.left, y + _CONTENT_TEXT_PADDING.top,
                text = str(tease_match.tease.get_author_id()),
                font = self._font,
                foreground = _COL_VALUE_AUTHOR_ID_FORE,
                highlight_foreground = _COL_HIGHLIGHT_TEXT_FORE,
                highlight_background = _COL_HIGHLIGHT_TEXT_BACK,
                highlight_border = _COL_HIGHLIGHT_TEXT_BORDER,
                highlight_padding = _CONTENT_HIGHLIGHT_PADDING,
                list_of_indices = get_list_of_metadata_indices(Tease.get_author_id, tease_match.list_of_field_matches),
                tag = row_tag,
            )
            return Bounds(x, y, text.bounds.right + _CONTENT_TEXT_PADDING.right, text.bounds.bottom + _CONTENT_TEXT_PADDING.bottom)
        return Bounds(x, y, x, y)

    def _render_image_count(self, x: int, y: int, row_tag: str, tease_match: TeaseMatch) -> Bounds:
        text = CanvasSequenceText(
            self._content_canvas,
            x + _CONTENT_TEXT_PADDING.left, y + _CONTENT_TEXT_PADDING.top,
            text = f'{tease_match.tease.get_count_of_images():,}',
            font = self._font,
            foreground = _COL_VALUE_IMAGE_COUNT_FORE,
            highlight_foreground = _COL_HIGHLIGHT_TEXT_FORE,
            highlight_background = _COL_HIGHLIGHT_TEXT_BACK,
            highlight_border = _COL_HIGHLIGHT_TEXT_BORDER,
            highlight_padding = _CONTENT_HIGHLIGHT_PADDING,
            list_of_indices = [],
            tag = row_tag,
        )
        return Bounds(x, y, text.bounds.right + _CONTENT_TEXT_PADDING.right, text.bounds.bottom + _CONTENT_TEXT_PADDING.bottom)

    def _render_unique_image_count(self, x: int, y: int, row_tag: str, tease_match: TeaseMatch) -> Bounds:
        text = CanvasSequenceText(
            self._content_canvas,
            x + _CONTENT_TEXT_PADDING.left, y + _CONTENT_TEXT_PADDING.top,
            text = f'{tease_match.tease.get_count_of_unique_images():,}',
            font = self._font,
            foreground = _COL_VALUE_UNIQUE_IMAGE_COUNT_FORE,
            highlight_foreground = _COL_HIGHLIGHT_TEXT_FORE,
            highlight_background = _COL_HIGHLIGHT_TEXT_BACK,
            highlight_border = _COL_HIGHLIGHT_TEXT_BORDER,
            highlight_padding = _CONTENT_HIGHLIGHT_PADDING,
            list_of_indices = [],
            tag = row_tag,
        )
        return Bounds(x, y, text.bounds.right + _CONTENT_TEXT_PADDING.right, text.bounds.bottom + _CONTENT_TEXT_PADDING.bottom)

    def _create_header_canvas(self) -> None:
        self._heading_canvas: tk.Canvas = tk.Canvas(self, background=_COL_HEADING_BACK, borderwidth=0, highlightthickness=0, cursor='sb_down_arrow')
        self._heading_canvas.grid(row=0, column=0, sticky=tk.EW)
        self._heading_canvas.bind('<Configure>', self._on_header_canvas_resized)
        self._heading_canvas.bind('<Button-1>', self._on_header_mouse_click)

    def _create_content_canvas(self) -> None:
        self._content_canvas: tk.Canvas = tk.Canvas(self, background=_COL_PANEL_BACK, borderwidth=0, highlightthickness=0)
        self._content_canvas.grid(row=1, column=0, sticky=tk.NSEW)
        self._content_canvas.bind('<Configure>', self._on_content_canvas_resized)

        self._vertical_scrollbar: tk.Scrollbar = tk.Scrollbar(self, orient=tk.VERTICAL, command=self._on_vertical_scroll, background=_COL_SCROLLBAR_FORE, troughcolor=_COL_SCROLLBAR_BACK, activebackground=_COL_SCROLLBAR_ACTIVE, relief=tk.SOLID, width=_SCROLLBAR_WIDTH)
        self._vertical_scrollbar.grid(row=1, column=1, sticky=tk.NS)
        self._content_canvas.config(yscrollcommand=self._vertical_scrollbar.set)

        horizontal_scrollbar: tk.Scrollbar = tk.Scrollbar(self, orient=tk.HORIZONTAL, command=self._on_horizontal_scroll, background=_COL_SCROLLBAR_FORE, troughcolor=_COL_SCROLLBAR_BACK, activebackground=_COL_SCROLLBAR_ACTIVE, relief=tk.SOLID, width=_SCROLLBAR_WIDTH)
        horizontal_scrollbar.grid(row=2, column=0, sticky=tk.EW)
        self._heading_canvas.config(xscrollcommand=horizontal_scrollbar.set)
        self._content_canvas.config(xscrollcommand=horizontal_scrollbar.set)

        self._content_canvas.bind("<MouseWheel>", lambda event: self._scroll_vertically(_get_scroll_direction_from_event(event)))
        self._content_canvas.bind("<Button-4>", lambda event: self._scroll_vertically(_get_scroll_direction_from_event(event)))
        self._content_canvas.bind("<Button-5>", lambda event: self._scroll_vertically(_get_scroll_direction_from_event(event)))
        self._content_canvas.bind("<Control-MouseWheel>", lambda event: self._scroll_vertically(_get_scroll_direction_from_event(event) * _SCROLL_PAGE_UNITS))
        self._content_canvas.bind("<Control-Button-4>", lambda event: self._scroll_vertically(_get_scroll_direction_from_event(event) * _SCROLL_PAGE_UNITS))
        self._content_canvas.bind("<Control-Button-5>", lambda event: self._scroll_vertically(_get_scroll_direction_from_event(event) * _SCROLL_PAGE_UNITS))
        self._content_canvas.bind("<Shift-MouseWheel>", lambda event: self._scroll_horizontally(_get_scroll_direction_from_event(event)))
        self._content_canvas.bind("<Shift-Button-4>", lambda event: self._scroll_horizontally(_get_scroll_direction_from_event(event)))
        self._content_canvas.bind("<Shift-Button-5>", lambda event: self._scroll_horizontally(_get_scroll_direction_from_event(event)))
        self._content_canvas.bind("<Control-Shift-MouseWheel>", lambda event: self._scroll_horizontally(_get_scroll_direction_from_event(event) * _SCROLL_PAGE_UNITS))
        self._content_canvas.bind("<Control-Shift-Button-4>", lambda event: self._scroll_horizontally(_get_scroll_direction_from_event(event) * _SCROLL_PAGE_UNITS))
        self._content_canvas.bind("<Control-Shift-Button-5>", lambda event: self._scroll_horizontally(_get_scroll_direction_from_event(event) * _SCROLL_PAGE_UNITS))

        self._content_canvas.bind('<Button-1>', self._on_content_mouse_click)
        self._content_canvas.bind('<Double-1>', self._on_content_mouse_double_click)
        self._content_canvas.bind('<Button-2>', self._on_content_mouse_right_click)
        self._content_canvas.bind('<Button-3>', self._on_content_mouse_right_click)

    def _redraw_header(self) -> None:
        self._heading_canvas.delete(tk.ALL)

        offset_x: int = 0
        column_index: int
        column: _Column
        for column_index, column in enumerate(self._list_of_columns):
            self._heading_canvas.create_text(offset_x + _HEADER_TEXT_PADDING.left, _HEADER_TEXT_PADDING.top, text=column.heading_name, font=self._font, fill=column.heading_colour, anchor=tk.NW)
            text_width: int = self._font.measure(column.heading_name)
            column.heading_width = text_width + _HEADER_TEXT_PADDING.width
            column.current_width = max(column.current_width, column.heading_width)
            offset_x += column.current_width
            if column_index != len(self._list_of_columns) -1:
                self._heading_canvas.create_line(offset_x, 0, offset_x, self._text_height + _HEADER_TEXT_PADDING.height, width=_HEADER_VERTICAL_LINE_WIDTH)
            offset_x += _HEADER_VERTICAL_LINE_WIDTH

        canvas_height: int = self._text_height + _HEADER_TEXT_PADDING.height + _HEADER_HORIZONTAL_LINE_HEIGHT - 1
        self._heading_canvas.config(height=canvas_height)

        self._redraw_header_horizontal_line()

    def _redraw_header_horizontal_line(self) -> None:
        self._heading_canvas.delete(_HORIZONTAL_LINE_TAG)
        line_y: int = self._heading_canvas.winfo_height() - _HEADER_HORIZONTAL_LINE_HEIGHT
        line_width: int = max(self._content_bounds.width, self._heading_canvas.winfo_width())
        self._heading_canvas.create_line(0, line_y, line_width - 1, line_y, width=_HEADER_HORIZONTAL_LINE_HEIGHT, tags=_HORIZONTAL_LINE_TAG)

    def _get_visible_top_and_bottom_row_indices(self, *, include_partially_visible: bool) -> tuple[int, int]:
        canvas_height: int = self._content_canvas.winfo_height()
        top_index: int
        bottom_index: int
        if include_partially_visible:
            top_index = int(self._content_canvas.canvasy(0) // self._row_height)
            bottom_index = int(self._content_canvas.canvasy(canvas_height - 1) // self._row_height)
        else:
            top_index = int(self._content_canvas.canvasy(self._row_height) // self._row_height)
            bottom_index = int(self._content_canvas.canvasy(canvas_height - 1 - self._row_height) // self._row_height)
        return top_index, bottom_index

    def _add_banner_text(self, text: str) -> None:
        self._banner_text = CanvasPlainText(
            self._content_canvas,
            origin_x = self._content_canvas.winfo_width() // 2,
            origin_y = _BANNER_PADDING_TOP,
            text = text,
            fill = _COL_BANNER_FORE,
            font = self._banner_font,
            justify = tk.CENTER,
            anchor = tk.N,
        )

    def _destroy_banner_text(self) -> None:
        if self._banner_text:
            self._banner_text.destroy()
            self._banner_text = None

    def _on_vertical_scroll(self, *args: object) -> None:
        if self._content_canvas.yview() != (0.0, 1.0):
            self._content_canvas.yview(*args)
            self._update_visible_rows()

    def _on_horizontal_scroll(self, *args: object) -> None:
        if self._content_canvas.xview() != (0.0, 1.0):
            self._heading_canvas.xview(*args)
            self._content_canvas.xview(*args)

    def _scroll_vertically(self, scroll_value: int) -> None:
        if scroll_value and self._content_canvas.yview() != (0.0, 1.0):
            self._content_canvas.yview_scroll(scroll_value, tk.UNITS)
            self._update_visible_rows()

    def _scroll_horizontally(self, scroll_value: int) -> None:
        if scroll_value and self._content_canvas.xview() != (0.0, 1.0):
            self._heading_canvas.xview_scroll(scroll_value, tk.UNITS)
            self._content_canvas.xview_scroll(scroll_value, tk.UNITS)

    def _on_header_canvas_resized(self, _event: object) -> None:
        self._redraw_header_horizontal_line()

    def _on_header_mouse_click(self, event: tk.Event) -> None: # type: ignore[type-arg]
        point: Point = get_canvas_event_relative_coord(self._heading_canvas, event)
        sort_key: ISortKey | None = None
        column: _Column
        column_right_x: int = 0
        for column in self._list_of_columns:
            column_right_x += column.current_width + _HEADER_VERTICAL_LINE_WIDTH
            if point.x < column_right_x:
                sort_key = column.sort_key
                break
        if sort_key:
            self._sort_list(sort_key)

    def _sort_list(self, sort_key: ISortKey) -> None:
        self._list_of_active_sort_keys.set([OrderedSortKey(sort_key, is_ascending=False)])
        sorted_list_of_tease_matches: list[TeaseMatch] = self._tease_match_sorter.sort(self._list_of_tease_matches.get(), self._list_of_active_sort_keys.get())
        self._redraw_selection_bar(None)
        self._selected_tease_index.set(None)
        self._list_of_tease_matches.set(sorted_list_of_tease_matches)

    def _on_content_canvas_resized(self, _event: object) -> None:
        self._update_visible_rows()
        self._redraw_selection_bar(self._selected_tease_index.get())

    def _on_content_mouse_click(self, event: tk.Event) -> None: # type: ignore[type-arg]
        point: Point = get_canvas_event_relative_coord(self._content_canvas, event)
        row = int(point.y / self._row_height)
        if row < len(self._list_of_tease_matches.get()):
            self._redraw_selection_bar(row)
            self._selected_tease_index.set(row)

    def _on_content_mouse_double_click(self, event: tk.Event) -> None: # type: ignore[type-arg]
        point: Point = get_canvas_event_relative_coord(self._content_canvas, event)
        row = int(point.y / self._row_height)
        if row < len(self._list_of_tease_matches.get()):
            self._call_open_tease(self._list_of_tease_matches.get()[row].tease)

    def _on_content_mouse_right_click(self, event: tk.Event) -> str: # type: ignore[type-arg]
        point: Point = get_canvas_event_relative_coord(self._content_canvas, event)
        row = int(point.y / self._row_height)
        if row < len(self._list_of_tease_matches.get()):
            self._redraw_selection_bar(row)
            self._selected_tease_index.set(row)
            tease_match: TeaseMatch = self._list_of_tease_matches.get()[row]
            self._call_popup_tease_menu(self._content_canvas, event.x_root, event.y_root, tease_match)
        return 'break'

    def _redraw_vertical_content_lines(self, content_height: int) -> None:
        self._content_canvas.delete(_VERTICAL_LINE_TAG)

        offset_x: int = 0
        column_index: int
        column: _Column
        for column_index, column in enumerate(self._list_of_columns):
            if column_index > 0:
                self._content_canvas.create_line(offset_x, 0, offset_x, content_height, width=_CONTENT_VERTICAL_LINE_WIDTH, fill=_COL_ROW_DIVIDER_LINE, tags=_VERTICAL_LINE_TAG)
                offset_x += _CONTENT_VERTICAL_LINE_WIDTH
            offset_x += column.current_width

    def _redraw_selection_bar(self, row: int | None) -> None:
        if self._selection_bar_id is not None:
            self._content_canvas.delete(self._selection_bar_id)
            self._selection_bar_id = None

        if row is not None and row in range(len(self._list_of_tease_matches.get())):
            display_bounds: Bounds = Bounds(0, 0, self._content_canvas.winfo_width(), self._content_canvas.winfo_height())
            max_bounds: Bounds = Bounds.union(self._content_bounds, display_bounds)
            top: int = row * self._row_height
            bottom: int = top + self._row_height - _CONTENT_HORIZONTAL_LINE_HEIGHT - 1
            self._selection_bar_id = self._content_canvas.create_rectangle(max_bounds.left, top, max_bounds.right - 1, bottom, fill=_COL_SELECTED_ROW_BACK)
            self._content_canvas.tag_lower(self._selection_bar_id, tk.ALL)

def _get_scroll_direction_from_event(event: tk.Event) -> int: # type: ignore[type-arg]
    if event.num == _LINUX_AND_OSX_MOUSEWHEEL_UP_BUTTON or event.delta < 0:
        return 1
    if event.num == _LINUX_AND_OSX_MOUSEWHEEL_DOWN_BUTTON or event.delta > 0:
        return -1
    return 0

_MAP_OF_AUTHOR_STATUS_TO_TEXT: dict[AuthorStatus, str] = {
    AuthorStatus.ACTIVE: 'Active',
    AuthorStatus.UNKNOWN: 'Unknown',
    AuthorStatus.GONE: 'Gone',
}
