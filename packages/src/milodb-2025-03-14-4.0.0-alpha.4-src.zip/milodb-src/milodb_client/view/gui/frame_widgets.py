# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
import tkinter as tk
from typing import Any

# spell-checker: ignore padx wraplength

class WrappingLabel(tk.Label):
    def __init__(self, master: tk.Misc, **kwargs: Any) -> None: # noqa: ANN401 Dynamically typed expressions (typing.Any) are disallowed:
        super().__init__(master, **kwargs)
        self.bind("<Configure>", self._on_configure)
        self._current_width: int = -1

    def _on_configure(self, _: object) -> None:
        width: int = self._get_width_within_container()
        if width not in (-1, self._current_width):
            self._current_width = width
            self.configure(wraplength=width)

    def _get_width_within_container(self) -> int:
        if self.winfo_manager() != 'grid':
            return self.winfo_width()

        grid_info = self.grid_info()
        try:
            column: int = grid_info['column']
            row: int = grid_info['row']
            cell_padx: object = grid_info['padx']
            label_padx: object = self['padx']
        except AttributeError:
            return -1

        bounding_box: tuple[int, int, int, int] | None = self.master.grid_bbox(column, row)
        if bounding_box is None:
            return -1

        width: int = bounding_box[2]

        if isinstance(cell_padx, int):
            width -= cell_padx * 2
        elif isinstance(cell_padx, list):
            width -= sum(cell_padx)
        else:
            return -1

        if isinstance(label_padx, int):
            width -= label_padx * 2
        elif isinstance(label_padx, list):
            width -= sum(label_padx)
        else:
            return -1

        return width
