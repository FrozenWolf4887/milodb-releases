# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from abc import abstractmethod
from math import ceil, pi
from typing import override
from PIL import Image, ImageDraw
from milodb_client.view.gui.geometric_shapes import make_star_points
from milodb_client.view.gui.turtle import Alignment, Flip, Turtle, TurtleShape
from milodb_common.view.gui.metrics import Point

class RatingImage:
    _STAR_POINTS: int = 5
    _OUTER_RADIUS: float = 500.0
    _INNER_RADIUS: float = 200.0
    _OUTER_ROTATION_RADIANS: float = pi / 4.2
    _INNER_ROTATION_RADIANS: float = _OUTER_ROTATION_RADIANS
    _FILLED_COLOUR: str = '#FD3'
    _FILLED_LINE_THICKNESS: int = 0
    _FILLED_LINE_COLOUR: str = '#000'
    _HOLLOW_COLOUR: str = '#888'
    _HOLLOW_LINE_THICKNESS: int = 0
    _HOLLOW_LINE_COLOUR: str = '#000'

    _NUMBER_OF_STARS: int = 5
    _WIDTH_OF_STAR: int = ceil(_OUTER_RADIUS * 2)
    _SPACING_BETWEEN_STARS: int = ceil(_OUTER_RADIUS * 2 * 0.83)
    _HEIGHT_OF_STAR: int = ceil(_OUTER_RADIUS * 2)

    _IMAGE_WIDTH: int = _SPACING_BETWEEN_STARS * (_NUMBER_OF_STARS - 1) + _WIDTH_OF_STAR
    _IMAGE_HEIGHT: int = _HEIGHT_OF_STAR
    _SCALED_IMAGE_HEIGHT: int = 15
    _SCALED_IMAGE_WIDTH: int = _SCALED_IMAGE_HEIGHT * _IMAGE_WIDTH // _IMAGE_HEIGHT

    def __init__(self) -> None:
        self._image_filled: Image.Image = Image.new('RGBA', size=(self._IMAGE_WIDTH, self._IMAGE_HEIGHT))
        self._image_hollow: Image.Image = Image.new('RGBA', size=(self._IMAGE_WIDTH, self._IMAGE_HEIGHT))
        draw_filled: ImageDraw.ImageDraw = ImageDraw.Draw(self._image_filled)
        draw_hollow: ImageDraw.ImageDraw = ImageDraw.Draw(self._image_hollow)

        for star in range(self._NUMBER_OF_STARS):
            self._draw_star(draw_filled, star * self._SPACING_BETWEEN_STARS, 0, outline=self._FILLED_LINE_COLOUR, outline_width=self._FILLED_LINE_THICKNESS, fill=self._FILLED_COLOUR)
            self._draw_star(draw_hollow, star * self._SPACING_BETWEEN_STARS, 0, outline=self._HOLLOW_LINE_COLOUR, outline_width=self._HOLLOW_LINE_THICKNESS, fill=self._HOLLOW_COLOUR)

        self._image_filled = self._image_filled.resize((self._SCALED_IMAGE_WIDTH, self._SCALED_IMAGE_HEIGHT), resample=Image.Resampling.BICUBIC)
        self._image_hollow = self._image_hollow.resize((self._SCALED_IMAGE_WIDTH, self._SCALED_IMAGE_HEIGHT), resample=Image.Resampling.BICUBIC)

    @property
    def image_filled(self) -> Image.Image:
        return self._image_filled

    @property
    def image_hollow(self) -> Image.Image:
        return self._image_hollow

    @classmethod
    def _draw_star(cls, draw: ImageDraw.ImageDraw, left: int, top: int, outline: str, outline_width: int, fill: str) -> None:
        list_of_points: list[Point] = make_star_points(
            left = left,
            top = top,
            number_of_points = cls._STAR_POINTS,
            outer_radius = cls._OUTER_RADIUS,
            inner_radius = cls._INNER_RADIUS,
            outer_rotation_radians = cls._OUTER_ROTATION_RADIANS,
            inner_rotation_radians = cls._INNER_ROTATION_RADIANS,
        )
        draw.polygon(list_of_points, outline=outline, width=outline_width, fill=fill)

class MissingAuthorImage:
    _SCALED_IMAGE_HEIGHT: int = 15
    _LINE_COLOUR: str = '#858'
    _FILL_COLOUR: str = '#B8B'
    _LINE_THICKNESS: int = 10
    _DOT_RADIUS: int = 37

    def __init__(self) -> None:
        turtle: Turtle = Turtle()
        shape: TurtleShape = TurtleShape(turtle, Point(47, 78))
        shape \
            .bezier(Point(78, 9), Point(137, 58)) \
            .bezier(Point(204, 116), Point(118, 172)) \
            .bezier(Point(103, 187), Point(99, 205)) \
            .bezier(Point(88, 236), Point(65, 205)) \
            .bezier(Point(61, 190), Point(119, 131)) \
            .bezier(Point(152, 91), Point(102, 71)) \
            .bezier(Point(75, 67), Point(71, 91)) \
            .bezier(Point(71, 100), Point(63, 106)) \
            .bezier(Point(29, 116), shape.origin) \
            .scale(width = 1.8)

        width: int = ceil(shape.calc_width())
        height: int = ceil(shape.calc_height())
        dot_center: Point = Point(width / 2 - 30, height + 50)
        width += self._LINE_THICKNESS
        height = ceil(dot_center.y + self._DOT_RADIUS + self._LINE_THICKNESS / 2)

        self._image = Image.new('RGBA', size=(width, height))
        draw: ImageDraw.ImageDraw = ImageDraw.Draw(self._image)

        list_of_poly_points: list[Point] = shape.calc_points(Alignment.NORTH_WEST, align_x=ceil(self._LINE_THICKNESS / 2), align_y=ceil(self._LINE_THICKNESS / 2))
        draw.polygon(list_of_poly_points, fill=self._FILL_COLOUR)
        draw.line(list_of_poly_points, fill=self._LINE_COLOUR, width=self._LINE_THICKNESS, joint='curve')

        draw.ellipse((dot_center.x - self._DOT_RADIUS, dot_center.y - self._DOT_RADIUS, dot_center.x + self._DOT_RADIUS, dot_center.y + self._DOT_RADIUS), fill=self._FILL_COLOUR, outline=self._LINE_COLOUR, width=self._LINE_THICKNESS)

        self._image = self._image.resize((self._SCALED_IMAGE_HEIGHT * width // height, self._SCALED_IMAGE_HEIGHT), resample=Image.Resampling.BICUBIC)

    @property
    def image(self) -> Image.Image:
        return self._image

class _DeletedImage:
    _IMAGE_WIDTH: int = 50
    _IMAGE_HEIGHT: int = 50
    _SCALED_IMAGE_WIDTH: int = 15
    _SCALED_IMAGE_HEIGHT: int = 15
    _LINE_WIDTH: int = 10
    _LINE_COLOUR: str = '#F31'
    _BORDER_THICKNESS: int = _IMAGE_WIDTH // 10

    def __init__(self) -> None:
        self._image: Image.Image = Image.new('RGBA', size=(self._IMAGE_WIDTH, self._IMAGE_HEIGHT))
        draw: ImageDraw.ImageDraw = ImageDraw.Draw(self._image)
        draw.line((self._BORDER_THICKNESS, self._BORDER_THICKNESS, self._IMAGE_WIDTH - self._BORDER_THICKNESS, self._IMAGE_HEIGHT - self._BORDER_THICKNESS), fill=self._LINE_COLOUR, width=self._LINE_WIDTH)
        draw.line((self._BORDER_THICKNESS, self._IMAGE_HEIGHT - self._BORDER_THICKNESS, self._IMAGE_WIDTH - self._BORDER_THICKNESS, self._BORDER_THICKNESS), fill=self._LINE_COLOUR, width=self._LINE_WIDTH)
        self._image = self._image.resize((self._SCALED_IMAGE_WIDTH, self._SCALED_IMAGE_HEIGHT), resample=Image.Resampling.BICUBIC)

    @property
    def image(self) -> Image.Image:
        return self._image

class _TotmImage:
    _LINE_COLOUR: str = '#444'
    _LINE_THICKNESS: int = 5
    _SCALED_IMAGE_HEIGHT: int = 23

    def __init__(self) -> None:
        turtle: Turtle = Turtle()
        trophy_body: TurtleShape = TurtleShape(turtle, Point(60, 60))
        trophy_body \
            .line(Point(170, 60)) \
            .bezier(Point(170, 210), Point(60, 210), trophy_body.origin)

        right_handle: TurtleShape = TurtleShape(turtle, Point(159, 80))
        right_handle \
            .bezier(Point(181, 51), Point(225, 65), Point(205, 101)) \
            .bezier(Point(185, 132), Point(178, 116), Point(167, 140)) \
            .bezier(Point(154, 164), Point(148, 124), Point(159, 120)) \
            .bezier(Point(197, 105), Point(209, 70), Point(182, 80)) \
            .bezier(Point(170, 84), Point(159, 100)) \
            .line(right_handle.origin)

        left_handle: TurtleShape = right_handle.copy()
        left_handle.flip(Flip.HORIZONTAL_AT_LEFT)
        left_handle.translate(left=77)

        trophy_base: TurtleShape = TurtleShape(turtle, Point(70, 200))
        trophy_base \
            .bezier(Point(100, 190), Point(100, 160)) \
            .bezier(Point(100, 130), Point(130, 130), Point(130, 160)) \
            .bezier(Point(130, 190), Point(160, 200)) \
            .line(Point(160, 220)) \
            .line(Point(70, 220)) \
            .line(trophy_base.origin) \

        trophy_body.raise_to_top()

        image_width: int = ceil(turtle.calc_width()) + self._LINE_THICKNESS
        image_height: int = ceil(turtle.calc_height()) + self._LINE_THICKNESS

        self._image: Image.Image = Image.new('RGBA', size=(image_width, image_height))
        draw: ImageDraw.ImageDraw = ImageDraw.Draw(self._image)

        shape: TurtleShape
        for shape in turtle.list_of_shapes:
            list_of_poly_points: list[Point] = shape.calc_points(Alignment.NORTH_WEST, align_x=self._LINE_THICKNESS / 2, align_y=self._LINE_THICKNESS / 2)
            draw.polygon(list_of_poly_points, fill=self._fill_colour)
            draw.line(list_of_poly_points, fill=self._LINE_COLOUR, width=self._LINE_THICKNESS, joint='curve')

        self._image = self._image.resize((self._SCALED_IMAGE_HEIGHT * image_width // image_height, self._SCALED_IMAGE_HEIGHT), resample=Image.Resampling.BICUBIC)

    @property
    def image(self) -> Image.Image:
        return self._image

    @property
    @abstractmethod
    def _fill_colour(self) -> str:
        pass

class TotmNomineeImage(_TotmImage):
    @property
    @override
    def _fill_colour(self) -> str:
        return '#CCC'

class TotmWinnerImage(_TotmImage):
    @property
    @override
    def _fill_colour(self) -> str:
        return '#FF3'

class EosImage:
    _FILL_COLOUR: str = '#FFF'
    _LINE_COLOUR: str = '#78A'
    _OUTLINE_THICKNESS: int = 9
    _BONE_THICKNESS: int = 5
    _SCALED_IMAGE_HEIGHT: int = 23

    def __init__(self) -> None:
        turtle: Turtle = Turtle()
        feather: TurtleShape = TurtleShape(turtle, Point(0, 132))
        feather \
            .bezier(Point(0, 32), Point(100, 47), Point(126, 0)) \
            .bezier(Point(126, 100), Point(26, 85), feather.origin)

        feather_bone: TurtleShape = TurtleShape(turtle, feather.origin)
        feather_bone.bezier(Point(0, 56), Point(126, 56), Point(126, 0))

        image_width: int = ceil(turtle.calc_width()) + self._OUTLINE_THICKNESS
        image_height: int = ceil(turtle.calc_height()) + self._OUTLINE_THICKNESS

        self._image: Image.Image = Image.new('RGBA', size=(image_width, image_height))
        draw: ImageDraw.ImageDraw = ImageDraw.Draw(self._image)

        list_of_poly_points: list[Point] = feather.calc_points(Alignment.NORTH_WEST, align_x=self._OUTLINE_THICKNESS / 2, align_y=self._OUTLINE_THICKNESS / 2)
        draw.polygon(list_of_poly_points, fill=self._FILL_COLOUR)
        draw.line(list_of_poly_points, fill=self._LINE_COLOUR, width=self._OUTLINE_THICKNESS, joint='curve')

        list_of_poly_points = feather_bone.calc_points(Alignment.NORTH_WEST, align_x=self._OUTLINE_THICKNESS / 2, align_y=self._OUTLINE_THICKNESS / 2)
        draw.line(list_of_poly_points, fill=self._LINE_COLOUR, width=self._BONE_THICKNESS, joint='curve')

        self._image = self._image.resize((self._SCALED_IMAGE_HEIGHT * image_width // image_height, self._SCALED_IMAGE_HEIGHT), resample=Image.Resampling.BICUBIC)

    @property
    def image(self) -> Image.Image:
        return self._image

class FlashImage:
    _FILL_COLOUR: str = '#FFF'
    _LINE_COLOUR: str = '#78A'
    _LINE_THICKNESS: int = 9
    _SCALED_IMAGE_HEIGHT: int = 23

    def __init__(self) -> None:
        turtle: Turtle = Turtle()
        shape: TurtleShape = TurtleShape(turtle, Point(0, 116))
        shape \
            .bezier(Point(78, 116), Point(27, 0), Point(135, 0)) \
            .line(Point(135, 34)) \
            .bezier(Point(91, 34), Point(91, 63)) \
            .line(Point(113, 63)) \
            .line(Point(113, 94)) \
            .line(Point(80, 94)) \
            .bezier(Point(41, 156), Point(15, 156)) \
            .line(Point(0, 156)) \
            .line(shape.origin)

        image_width: int = ceil(turtle.calc_width()) + self._LINE_THICKNESS
        image_height: int = ceil(turtle.calc_height()) + self._LINE_THICKNESS

        self._image: Image.Image = Image.new('RGBA', size=(image_width, image_height))
        draw: ImageDraw.ImageDraw = ImageDraw.Draw(self._image)

        list_of_poly_points: list[Point] = shape.calc_points(Alignment.NORTH_WEST, align_x=self._LINE_THICKNESS / 2, align_y=self._LINE_THICKNESS / 2)
        draw.polygon(list_of_poly_points, fill=self._FILL_COLOUR)
        draw.line(list_of_poly_points, fill=self._LINE_COLOUR, width=self._LINE_THICKNESS, joint='curve')

        self._image = self._image.resize((self._SCALED_IMAGE_HEIGHT * image_width // image_height, self._SCALED_IMAGE_HEIGHT), resample=Image.Resampling.BICUBIC)

    @property
    def image(self) -> Image.Image:
        return self._image

class AudioImage:
    _FILL_COLOUR: str = '#78A'
    _LINE_COLOUR: str = '#FFF'
    _SHAPE_THICKNESS: int = 20
    _LINE_THICKNESS: int = 7
    _SCALED_IMAGE_HEIGHT: int = 23

    def __init__(self) -> None:
        turtle: Turtle = Turtle()
        shape: TurtleShape = TurtleShape(turtle, Point(8, 82))
        shape \
            .line(Point(23, 58)) \
            .line(Point(38, 101)) \
            .line(Point(68, 7)) \
            .line(Point(78, 119)) \
            .line(Point(94, 47)) \
            .line(Point(107, 81)) \
            .line(Point(122, 52)) \
            .line(Point(132, 70))

        image_width: int = ceil(turtle.calc_width()) + self._SHAPE_THICKNESS
        image_height: int = ceil(turtle.calc_height()) + self._SHAPE_THICKNESS

        self._image: Image.Image = Image.new('RGBA', size=(image_width, image_height))
        draw: ImageDraw.ImageDraw = ImageDraw.Draw(self._image)

        list_of_poly_points: list[Point] = shape.calc_points(Alignment.NORTH_WEST, align_x=self._SHAPE_THICKNESS / 2, align_y=self._SHAPE_THICKNESS / 2)
        draw.line(list_of_poly_points, fill=self._FILL_COLOUR, width=self._SHAPE_THICKNESS, joint='curve')
        draw.line(list_of_poly_points, fill=self._LINE_COLOUR, width=self._LINE_THICKNESS, joint='curve')

        self._image = self._image.resize((self._SCALED_IMAGE_HEIGHT * image_width // image_height, self._SCALED_IMAGE_HEIGHT), resample=Image.Resampling.BICUBIC)

    @property
    def image(self) -> Image.Image:
        return self._image

class ClassicImage:
    _FILL_COLOUR: str = '#FFF'
    _LINE_COLOUR: str = '#78A'
    _OUTLINE_THICKNESS: int = 6
    _SCALED_IMAGE_HEIGHT: int = 23

    def __init__(self) -> None:
        turtle: Turtle = Turtle()

        left_page_top: TurtleShape = TurtleShape(turtle, Point(115, 161))
        left_page_top \
            .bezier(Point(88, 135), Point(50, 145)) \
            .line(Point(50, 237)) \
            .bezier(Point(88, 231), Point(115, 258)) \
            .line(left_page_top.origin)

        left_page_top.copy() \
            .scale(width=0.9, height=0.6) \
            .align(Alignment.SOUTH_EAST, left_page_top.calc_bottom_right()) \
            .lower_to_bottom()

        left_page_top.copy() \
            .scale(width=0.8, height=0.2) \
            .align(Alignment.SOUTH_EAST, left_page_top.calc_bottom_right()) \
            .lower_to_bottom()

        right_page_top: TurtleShape = left_page_top.copy() \
            .flip(Flip.HORIZONTAL_AT_RIGHT)

        right_page_top.copy() \
            .scale(width=0.9, height=0.6) \
            .align(Alignment.SOUTH_WEST, right_page_top.calc_bottom_left()) \
            .lower_to_bottom()

        right_page_top.copy() \
            .scale(width=0.8, height=0.2) \
            .align(Alignment.SOUTH_WEST, right_page_top.calc_bottom_left()) \
            .lower_to_bottom()

        left_text_line: TurtleShape = TurtleShape(turtle, Point(105, 167)) \
            .bezier(Point(83, 150), Point(62, 156))

        right_text_line: TurtleShape = left_text_line.copy() \
            .flip(Flip.HORIZONTAL_AT_RIGHT) \
            .translate(right = 2 * (left_page_top.calc_max_x() - left_text_line.calc_max_x()))

        for _ in range(6):
            left_text_line = left_text_line.copy().translate(down=11)
            right_text_line = right_text_line.copy().translate(down=11)

        image_width: int = ceil(turtle.calc_width()) + self._OUTLINE_THICKNESS
        image_height: int = ceil(turtle.calc_height()) + self._OUTLINE_THICKNESS

        self._image = Image.new('RGBA', size=(image_width, image_height))
        draw: ImageDraw.ImageDraw = ImageDraw.Draw(self._image)

        shape: TurtleShape
        for shape in turtle.list_of_shapes:
            list_of_poly_points: list[Point] = shape.calc_points(Alignment.NORTH_WEST, align_x=self._OUTLINE_THICKNESS / 2, align_y=self._OUTLINE_THICKNESS / 2)
            draw.polygon(list_of_poly_points, fill=self._FILL_COLOUR)
            draw.line(list_of_poly_points, fill=self._LINE_COLOUR, width=self._OUTLINE_THICKNESS, joint='curve')

        self._image = self._image.resize((self._SCALED_IMAGE_HEIGHT * image_width // image_height, self._SCALED_IMAGE_HEIGHT), resample=Image.Resampling.BICUBIC)

    @property
    def image(self) -> Image.Image:
        return self._image

GoneAuthorImage = _DeletedImage
DeletedTeaseImage = _DeletedImage
