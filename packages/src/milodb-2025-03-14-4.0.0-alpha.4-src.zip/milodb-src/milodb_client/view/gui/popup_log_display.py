# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
import tkinter as tk
import tkinter.font as tkfont
from pathlib import Path
from tkinter.scrolledtext import ScrolledText
from types import TracebackType
from typing import Self, override
from PIL import Image, ImageTk
from milodb_client.resources import resource_path
from milodb_client.view.gui import general_colours
from milodb_client.view.i_log_display import ILogDisplay
from milodb_common.output.print.i_printer import IPrinter
from milodb_common.output.print.prefix_printer import PrefixPrinter

# spell-checker: ignore activebackground borderwidth tkfont troughcolor padx pady

_COL_SCROLLBAR_BACK: str = general_colours.SCROLLBAR_BACK
_COL_SCROLLBAR_FORE: str = general_colours.SCROLLBAR_FORE
_COL_SCROLLBAR_ACTIVE: str = general_colours.SCROLLBAR_ACTIVE
_SCROLLBAR_WIDTH: int = 15

class PopupLogDisplay(ILogDisplay):
    def __init__(self) -> None:
        self._window: tk.Tk = tk.Tk()
        self._window.config(background = '#444')
        self._window.title('MiloDB')

        icon: Image.Image
        with Image.open(resource_path(Path('milodb-search-icon.ico'))) as icon:
            self._window.iconphoto(True, ImageTk.PhotoImage(icon)) # noqa: FBT003 Boolean positional value in function call
        self._window.geometry('400x300')

        font: tkfont.Font = tkfont.Font(self._window, 'Arial 11')
        self._textbox: ScrolledText = ScrolledText(self._window, height=3, background='#222', foreground='#DDD', font=font, border=0, borderwidth=0, padx=5, pady=2)
        self._textbox.vbar.configure(background=_COL_SCROLLBAR_FORE, troughcolor=_COL_SCROLLBAR_BACK, activebackground=_COL_SCROLLBAR_ACTIVE, relief=tk.SOLID, width=_SCROLLBAR_WIDTH)
        self._textbox.pack(fill=tk.BOTH, expand=True)
        self._okay_flag: tk.BooleanVar = tk.BooleanVar(self._window)
        self._window.protocol("WM_DELETE_WINDOW", lambda: self._okay_flag.set(True))

        self._text_widget_printer: _TextWidgetPrinter = _TextWidgetPrinter(self._textbox)
        self._warning_printer: IPrinter = PrefixPrinter('Warning: ', self._text_widget_printer)
        self._error_printer: IPrinter = PrefixPrinter('Error: ', self._text_widget_printer)
        self._fatal_printer: IPrinter = PrefixPrinter('FATAL: ', self._text_widget_printer)

    @property
    @override
    def normal_printer(self) -> IPrinter:
        return self._text_widget_printer

    @property
    @override
    def warning_printer(self) -> IPrinter:
        return self._warning_printer

    @property
    @override
    def error_printer(self) -> IPrinter:
        return self._error_printer

    @override
    def prompt_to_continue(self) -> None:
        button: tk.Button = tk.Button(self._window, text='OK', command=lambda: self._okay_flag.set(True))
        button.pack(side = tk.BOTTOM)
        button.focus()
        self._okay_flag.set(False)
        self._window.wait_variable(self._okay_flag)
        button.destroy()

    @override
    def print_warning_and_prompt_to_continue(self, message: str) -> None:
        self._warning_printer.writeln(message)
        self.prompt_to_continue()

    @override
    def print_fatal_and_prompt_to_continue(self, message: str) -> None:
        self._fatal_printer.writeln(message)
        self.prompt_to_continue()

    @override
    def __enter__(self) -> Self:
        self._window.wait_visibility()
        return self

    @override
    def __exit__(self, exc_type: type[BaseException] | None, exc_value: BaseException | None, traceback: TracebackType | None) -> None:
        self._window.destroy()

class _TextWidgetPrinter(IPrinter):
    def __init__(self, textbox: tk.Text) -> None:
        self._textbox: tk.Text = textbox
        self._is_on_newline: bool = True

    @override
    def write(self, text: str) -> None:
        if text:
            self._textbox.insert(tk.END, text)
            self._is_on_newline = text[-1] == '\n'
            self._textbox.see(tk.END)
            self._textbox.update()

    @override
    def writeln(self, text: str | None = None) -> None:
        if text:
            self._textbox.insert(tk.END, text + '\n')
        else:
            self._textbox.insert(tk.END, '\n')
        self._is_on_newline = True
        self._textbox.see(tk.END)
        self._textbox.update()

    @property
    @override
    def is_on_new_line(self) -> bool:
        return self._is_on_newline
