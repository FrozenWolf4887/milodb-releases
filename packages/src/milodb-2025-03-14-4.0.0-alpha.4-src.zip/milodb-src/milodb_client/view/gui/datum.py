# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from __future__ import annotations
import contextlib
from abc import abstractmethod
from typing import TYPE_CHECKING, override
from milodb_common.util.ref import IRef
if TYPE_CHECKING:
    from collections.abc import Callable

class IDatum[T](IRef[T]):
    @abstractmethod
    def add_listener(self, listener: Callable[[IDatum[T]], None], *, call_immediately: bool=False) -> None:
        pass

    @abstractmethod
    def remove_listener(self, listener: Callable[[IDatum[T]], None]) -> None:
        pass

class SimpleDatum[T](IDatum[T]):
    def __init__(self, default: T) -> None:
        self._ref: T = default
        self._set_of_listeners: set[Callable[[IDatum[T]], None]] = set()

    @override
    def set(self, ref: T) -> None:
        if self._ref != ref:
            self._ref = ref
            listener: Callable[[IDatum[T]], None]
            for listener in self._set_of_listeners:
                listener(self)

    @override
    def get(self) -> T:
        return self._ref

    @override
    def __bool__(self) -> bool:
        return bool(self._ref)

    @override
    def add_listener(self, listener: Callable[[IDatum[T]], None], *, call_immediately: bool=False) -> None:
        self._set_of_listeners.add(listener)
        if call_immediately:
            listener(self)

    @override
    def remove_listener(self, listener: Callable[[IDatum[T]], None]) -> None:
        with contextlib.suppress(KeyError):
            self._set_of_listeners.remove(listener)

class SuppressingDatum[T](IDatum[T]):
    def __init__(self, proxy_datum: IDatum[T]) -> None:
        self._proxy_datum: IDatum[T] = proxy_datum
        self._is_observing_proxy: bool = False
        self._set_of_listeners: set[Callable[[IDatum[T]], None]] = set()
        self._suppress_callbacks: bool = False

    @override
    def set(self, ref: T) -> None:
        self._suppress_callbacks = True
        self._proxy_datum.set(ref)
        self._suppress_callbacks = False

    @override
    def get(self) -> T:
        return self._proxy_datum.get()

    @override
    def __bool__(self) -> bool:
        return bool(self._proxy_datum)

    @override
    def add_listener(self, listener: Callable[[IDatum[T]], None], *, call_immediately: bool=False) -> None:
        self._set_of_listeners.add(listener)
        if not self._is_observing_proxy:
            self._proxy_datum.add_listener(self._on_proxy_value_changed)
            self._is_observing_proxy = True
        if call_immediately:
            listener(self)

    @override
    def remove_listener(self, listener: Callable[[IDatum[T]], None]) -> None:
        with contextlib.suppress(KeyError):
            self._set_of_listeners.remove(listener)
        if not self._set_of_listeners and self._is_observing_proxy:
            self._proxy_datum.remove_listener(self._on_proxy_value_changed)
            self._is_observing_proxy = False

    def _on_proxy_value_changed(self, _: IDatum[T]) -> None:
        if not self._suppress_callbacks:
            for listener in self._set_of_listeners:
                listener(self)
