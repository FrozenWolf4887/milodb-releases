# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
import tkinter as tk
import tkinter.font as tkfont
from tkinter.scrolledtext import ScrolledText
from typing import override
from milodb_client.view.gui.util import set_text_readonly
from milodb_common.output.print.i_printer import IPrinter
from milodb_common.output.print.prefix_printer import PrefixPrinter

# spell-checker: ignore tkfont

class LogText(ScrolledText):
    def __init__(self, master: tk.Misc) -> None:
        super().__init__(master, height=3, background='#222', foreground='#DDD')
        self.config(font=tkfont.Font(self, 'Arial 11'))
        set_text_readonly(self)

        self._text_widget_printer: _TextWidgetPrinter = _TextWidgetPrinter(self)
        self._warning_printer: CountingPrinter = CountingPrinter(PrefixPrinter('Warning: ', self._text_widget_printer))
        self._error_printer: CountingPrinter = CountingPrinter(PrefixPrinter('Error: ', self._text_widget_printer))
        self._fatal_printer: CountingPrinter = CountingPrinter(PrefixPrinter('FATAL: ', self._text_widget_printer))

    @property
    def normal_printer(self) -> IPrinter:
        return self._text_widget_printer

    @property
    def warning_printer(self) -> IPrinter:
        return self._warning_printer

    @property
    def error_printer(self) -> IPrinter:
        return self._error_printer

    @property
    def fatal_printer(self) -> IPrinter:
        return self._fatal_printer

    @property
    def any_warnings_or_errors(self) -> bool:
        return any([self._warning_printer.count, self._error_printer.count, self._fatal_printer.count])

class CountingPrinter(IPrinter):
    def __init__(self, delegate: IPrinter) -> None:
        self._delegate: IPrinter = delegate
        self._count: int = 0

    @property
    def count(self) -> int:
        return self._count

    @override
    def write(self, text: str) -> None:
        self._count += 1
        self._delegate.write(text)

    @override
    def writeln(self, text: str | None = None) -> None:
        self._count += 1
        self._delegate.writeln(text)

    @property
    @override
    def is_on_new_line(self) -> bool:
        return self._delegate.is_on_new_line

class _TextWidgetPrinter(IPrinter):
    def __init__(self, textbox: tk.Text) -> None:
        self._textbox: tk.Text = textbox
        self._is_on_newline: bool = True

    @override
    def write(self, text: str) -> None:
        if text:
            self._textbox.insert(tk.END, text)
            self._is_on_newline = text[-1] == '\n'
            self._textbox.see(tk.END)
            self._textbox.update()

    @override
    def writeln(self, text: str | None = None) -> None:
        if text:
            self._textbox.insert(tk.END, text + '\n')
        else:
            self._textbox.insert(tk.END, '\n')
        self._is_on_newline = True
        self._textbox.see(tk.END)
        self._textbox.update()

    @property
    @override
    def is_on_new_line(self) -> bool:
        return self._is_on_newline
