# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
import tkinter as tk

type Relief = tk._Relief # pylint: disable=protected-access, no-member # type: ignore[reportPrivateUsage] # noqa: SLF001 Private member accessed

PANEL_RELIEF: Relief = tk.GROOVE
PANEL_BORDER_WIDTH: int = 4
PANEL_PADDING_X: int = 2
PANEL_PADDING_Y: int = 2
PANEL_MARGIN_X: int = 2
PANEL_MARGIN_Y: int = 1
