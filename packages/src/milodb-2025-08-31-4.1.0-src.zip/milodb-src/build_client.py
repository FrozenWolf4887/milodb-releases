#!/usr/bin/env python3
# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import sys
if sys.version_info < (3, 12):
    print("Python version 3.12 or greater required")
    print("Actual version is " + sys.version)
    sys.exit(1)

# spell-checker: ignore distpath pythonoptimize venv workpath

# pylint: disable=wrong-import-position
import os
import subprocess
import venv
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from pathlib import Path
# pylint: enable=wrong-import-position

_THIS_DIRECTORY: Path = Path(__file__).parent.resolve()
_SPEC_DIRECTORY: Path = _THIS_DIRECTORY/'tools'
_REQUIREMENTS_DIRECTORY: Path = _THIS_DIRECTORY/'tools'
_OUTPUT_DIRECTORY: Path = _THIS_DIRECTORY/'build'/'bin'
_IS_WINDOWS: bool = sys.platform == 'win32'

@dataclass(kw_only=True)
class _BuildDetails:
    type_name: str
    list_of_requirements_filepaths: Sequence[Path]
    spec_filepath: Path

_LIST_OF_BUILD_DETAILS: Sequence[_BuildDetails] = [
    _BuildDetails(
        type_name = 'terminal',
        list_of_requirements_filepaths = [
            _REQUIREMENTS_DIRECTORY/'requirements-run-terminal.txt',
            _REQUIREMENTS_DIRECTORY/'requirements-build-terminal.txt',
        ],
        spec_filepath = _SPEC_DIRECTORY/'milodb-terminal.spec',
    ),
    _BuildDetails(
        type_name = 'gui',
        list_of_requirements_filepaths = [
            _REQUIREMENTS_DIRECTORY/'requirements-run-gui.txt',
            _REQUIREMENTS_DIRECTORY/'requirements-build-gui.txt',
        ],
        spec_filepath = _SPEC_DIRECTORY/'milodb-gui.spec',
    ),
]

_MAP_OF_BUILD_TYPE_TO_DETAILS: Mapping[str, _BuildDetails] = {
    build_details.type_name: build_details for build_details in _LIST_OF_BUILD_DETAILS
}

def _get_python_interpreter() -> Path:
    python_path: Path = Path(sys.executable)
    if python_path.name.startswith('python'):
        return python_path
    print(f"Error: '{python_path}' is not recognised as a python interpreter")
    sys.exit(1)

def _build(build_details: _BuildDetails) -> None:
    python_path: Path = _get_python_interpreter()
    print(f'Python executable: {python_path}')
    print(f'Python version: {sys.version}')

    venv_directory: Path = _OUTPUT_DIRECTORY/'venv'/f'{sys.platform}-{build_details.type_name}'
    obj_directory: Path = _OUTPUT_DIRECTORY/'obj'/f'{sys.platform}-{build_details.type_name}'

    print(f"** Prepare virtual environment for '{build_details.type_name}'")
    virtual_environment: _VirtualEnvironment = _VirtualEnvironment(venv_directory)
    virtual_environment.initialise()

    print(f"** Install packages for '{build_details.type_name}'")
    virtual_environment.run_pip(
        list_of_args = [
            'install',
            '--disable-pip-version-check',
            '--no-deps',
            *[ arg for requirements_filepath in build_details.list_of_requirements_filepaths for arg in ('-r', requirements_filepath) ],
        ],
    )

    print(f"** Build executable for '{build_details.type_name}'")
    virtual_environment.run_pyinstaller(
        extra_environment = {
            'PYTHONOPTIMIZE': '1',
        },
        list_of_args = [
            '--distpath', _OUTPUT_DIRECTORY,
            '--workpath', obj_directory,
            '--clean',
            build_details.spec_filepath,
        ],
    )

    print(f"** Dump requirements for '{build_details.type_name}'")
    virtual_environment.run_pip(
        list_of_args = [
            'freeze',
        ],
    )

class _VirtualEnvironment:
    def __init__(self, path: Path) -> None:
        self._path: Path = path.resolve()

    def initialise(self) -> None:
        venv.create(self._path, clear=True, with_pip=True, symlinks=False)

    def run_pip(self, *, extra_environment: Mapping[str, str] | None = None, list_of_args: Sequence[str | Path]) -> None:
        self._run(self._pip_path, extra_environment=extra_environment, list_of_args=list_of_args)

    def run_pyinstaller(self, *, extra_environment: Mapping[str, str] | None = None, list_of_args: Sequence[str | Path]) -> None:
        self._run(self._pyinstaller_path, extra_environment=extra_environment, list_of_args=list_of_args)

    @staticmethod
    def _run(executable_path: Path, *, extra_environment: Mapping[str, str] | None = None, list_of_args: Sequence[str | Path]) -> None:
        environment: dict[str, str] = dict(os.environ)
        if extra_environment:
            environment.update(extra_environment)

        try:
            subprocess.run([ # noqa: S603 `subprocess` call: check for execution of untrusted input
                executable_path,
                *list_of_args,
                ],
                env = environment,
                check = True,
            )
        except subprocess.CalledProcessError as ex:
            print(f'ABORTED: {ex}')
            sys.exit(1)

    @property
    def _pip_path(self) -> Path:
        if _IS_WINDOWS:
            return self._path/'Scripts'/'pip.exe'
        return self._path/'bin'/'pip'

    @property
    def _pyinstaller_path(self) -> Path:
        if _IS_WINDOWS:
            return self._path/'Scripts'/'pyinstaller.exe'
        return self._path/'bin'/'pyinstaller'

def main(app_name: str, list_of_args: list[str]) -> None:
    if '--help' in list_of_args or '-h' in list_of_args:
        print(f'Syntax: {app_name} [-h|--help] [{"|".join(_MAP_OF_BUILD_TYPE_TO_DETAILS)}]')
        sys.exit(0)

    list_of_selected_build_details: list[_BuildDetails] = []
    arg: str
    for arg in set(list_of_args):
        try:
            list_of_selected_build_details.append(_MAP_OF_BUILD_TYPE_TO_DETAILS[arg])
        except KeyError:
            print(f"Error: Unknown build type '{arg}'")
            sys.exit(1)

    build_details: _BuildDetails
    for build_details in list_of_selected_build_details or _LIST_OF_BUILD_DETAILS:
        _build(build_details)

if __name__ == "__main__":
    main(Path(sys.argv[0]).name, sys.argv[1:])
