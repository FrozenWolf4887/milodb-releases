# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import operator
from collections.abc import Mapping, Sequence, Set as AbstractSet
from milodb_client.database.tease import Tease
from milodb_client.query.boolean_operator import And, Not, Or
from milodb_client.query.field_comparators import FieldAuthorStatusIs, FieldDateCompare, FieldPageListContains, FieldPageListMatches, FieldStatusIs, FieldStrContains, FieldStrIs, FieldStrListContains, FieldStrListIs, FieldStrListMatches, FieldStrMatches, FieldTotmIs, FieldTypeIs, FieldUnsignedFloatCompare, FieldUnsignedIntCompare
from milodb_client.query.field_verb import FieldAuthorStatusVerb, FieldDateVerb, FieldFloatVerb, FieldIntVerb, FieldPageListVerb, FieldStatusVerb, FieldStrListVerb, FieldStrVerb, FieldTotmVerb, FieldTypeVerb, IFieldVerb
from milodb_client.query.query import IQuery
from milodb_common.types.partial_date import PartialDate

MAP_OF_TEASE_FIELDNAME_TO_VERBS: Mapping[str, Mapping[str, IFieldVerb]] = {
    'teaseId': {
        '=': FieldIntVerb(Tease.get_tease_id, FieldUnsignedIntCompare, operator.eq),
        '>': FieldIntVerb(Tease.get_tease_id, FieldUnsignedIntCompare, operator.gt),
        '<': FieldIntVerb(Tease.get_tease_id, FieldUnsignedIntCompare, operator.lt),
        '>=': FieldIntVerb(Tease.get_tease_id, FieldUnsignedIntCompare, operator.ge),
        '<=': FieldIntVerb(Tease.get_tease_id, FieldUnsignedIntCompare, operator.le),
    },
    'authorId': {
        '=': FieldIntVerb(Tease.get_author_id, FieldUnsignedIntCompare, operator.eq),
        '>': FieldIntVerb(Tease.get_author_id, FieldUnsignedIntCompare, operator.gt),
        '<': FieldIntVerb(Tease.get_author_id, FieldUnsignedIntCompare, operator.lt),
        '>=': FieldIntVerb(Tease.get_author_id, FieldUnsignedIntCompare, operator.ge),
        '<=': FieldIntVerb(Tease.get_author_id, FieldUnsignedIntCompare, operator.le),
    },
    'type': {
        'is': FieldTypeVerb(Tease.get_type, FieldTypeIs),
    },
    'title': {
        'is': FieldStrVerb(Tease.get_title, FieldStrIs),
        'contains': FieldStrVerb(Tease.get_title, FieldStrContains),
        'matches': FieldStrVerb(Tease.get_title, FieldStrMatches),
    },
    'summary': {
        'is': FieldStrVerb(Tease.get_summary, FieldStrIs),
        'contains': FieldStrVerb(Tease.get_summary, FieldStrContains),
        'matches': FieldStrVerb(Tease.get_summary, FieldStrMatches),
    },
    'author': {
        'is': FieldStrVerb(Tease.get_author_name, FieldStrIs),
        'contains': FieldStrVerb(Tease.get_author_name, FieldStrContains),
        'matches': FieldStrVerb(Tease.get_author_name, FieldStrMatches),
    },
    'tag': {
        'is': FieldStrListVerb(Tease.get_list_of_tags, FieldStrListIs),
        'contains': FieldStrListVerb(Tease.get_list_of_tags, FieldStrListContains),
        'matches': FieldStrListVerb(Tease.get_list_of_tags, FieldStrListMatches),
    },
    'date': {
        '=': FieldDateVerb(Tease.get_date, FieldDateCompare, PartialDate.is_eq),
        '>': FieldDateVerb(Tease.get_date, FieldDateCompare, PartialDate.is_gt),
        '<': FieldDateVerb(Tease.get_date, FieldDateCompare, PartialDate.is_lt),
        '>=': FieldDateVerb(Tease.get_date, FieldDateCompare, PartialDate.is_ge),
        '<=': FieldDateVerb(Tease.get_date, FieldDateCompare, PartialDate.is_le),
    },
    'rating': {
        '=': FieldFloatVerb(Tease.get_rating_value, FieldUnsignedFloatCompare, operator.eq),
        '>': FieldFloatVerb(Tease.get_rating_value, FieldUnsignedFloatCompare, operator.gt),
        '<': FieldFloatVerb(Tease.get_rating_value, FieldUnsignedFloatCompare, operator.lt),
        '>=': FieldFloatVerb(Tease.get_rating_value, FieldUnsignedFloatCompare, operator.ge),
        '<=': FieldFloatVerb(Tease.get_rating_value, FieldUnsignedFloatCompare, operator.le),
    },
    'text': {
        'contains': FieldPageListVerb(FieldPageListContains),
        'matches': FieldPageListVerb(FieldPageListMatches),
    },
    'totm': {
        'is': FieldTotmVerb(FieldTotmIs),
    },
    'status': {
        'is': FieldStatusVerb(FieldStatusIs),
    },
    'authorStatus': {
        'is': FieldAuthorStatusVerb(FieldAuthorStatusIs),
    },
}

MAP_OF_BINARY_OPERATORS_TO_QUERY_CLASS: Mapping[str, type[IQuery]] = {
    'and': And,
    'or': Or,
}

MAP_OF_UNARY_OPERATORS_TO_QUERY_CLASS: Mapping[str, type[IQuery]] = {
    'not': Not,
}

LIST_OF_FIELD_NAMES: Sequence[str] = sorted(MAP_OF_TEASE_FIELDNAME_TO_VERBS)
SET_OF_VERB_NAMES: AbstractSet[str] = { verb for verb_dictionary in MAP_OF_TEASE_FIELDNAME_TO_VERBS.values() for verb in verb_dictionary }
LIST_OF_VERB_NAMES: Sequence[str] = sorted(SET_OF_VERB_NAMES)
LIST_OF_OPERATORS: Sequence[str] = sorted(list(MAP_OF_BINARY_OPERATORS_TO_QUERY_CLASS) + list(MAP_OF_UNARY_OPERATORS_TO_QUERY_CLASS) + ['(', ')'])
