# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import json
from pathlib import Path
from typing import TYPE_CHECKING
from milodb_client.config.config_schema import CONFIG_SCHEMA
from milodb_client.config.migration import try_migrate_config
from milodb_client.database.database import load_teases_from_database_file
from milodb_client.database.thumbnail_database import ThumbnailDatabase, load_thumbnail_database
from milodb_client.startup.shutdown_action import IShutdownAction
from milodb_client.updater.manifest.i_schema_types import SchemaLoadError
from milodb_client.updater.manifest.local_manifest_schema import LocalManifestSchema
from milodb_client.util import app_info
from milodb_client.view.gui.main_window import MainWindow
from milodb_client.view.gui.popup_log_display import PopupLogDisplay
from milodb_common.config.json_config_file import JsonConfigFile
from milodb_common.output.print.i_printer import IPrinter
from milodb_common.util.ref import IRef, SimpleRef
from milodb_common.variables.file_user_variables import FileUserVariables
if TYPE_CHECKING:
    from collections.abc import Sequence
    from milodb_client.database.tease import Tease
    from milodb_common.variables.i_user_variables import IPersistentUserVariables

_LOCAL_MANIFEST_FILENAME: Path = Path('milodb-manifest.ver')
_TEASES_DATABASE_FILENAME: Path = Path('milodb-teases.dat')
_THUMBS_DATABASE_FILENAME: Path = Path('milodb-thumbs.dat')
_CONFIG_FILENAME: Path = Path('user-config.json')
_VARIABLES_FILENAME: Path = Path('user-variables.json')

class MainGui:
    def __init__(self, log_display: PopupLogDisplay, *, no_load: bool) -> None:
        self._local_manifest: LocalManifestSchema | None = _load_local_manifest(_LOCAL_MANIFEST_FILENAME, log_display.warning_printer, log_display.error_printer)
        log_display.normal_printer.writeln(app_info.get_version_one_line(self._local_manifest))

        self._system_config: JsonConfigFile = JsonConfigFile(_CONFIG_FILENAME, CONFIG_SCHEMA, try_migrate_config)
        self._system_config.load(log_display.normal_printer, log_display.warning_printer, log_display.error_printer)

        self._user_variables: IPersistentUserVariables = FileUserVariables(_VARIABLES_FILENAME)
        self._user_variables.load(log_display.normal_printer, log_display.warning_printer, log_display.error_printer)

        log_display.normal_printer.writeln()
        self._list_of_teases: Sequence[Tease] = [] if no_load else load_teases_from_database_file(_TEASES_DATABASE_FILENAME, log_display.normal_printer, log_display.error_printer)

        log_display.normal_printer.writeln()
        self._thumbnail_database: ThumbnailDatabase = ThumbnailDatabase({}, b'') if no_load else load_thumbnail_database(_THUMBS_DATABASE_FILENAME, log_display.normal_printer, log_display.error_printer)

        log_display.normal_printer.writeln()
        log_display.normal_printer.writeln(app_info.get_database_info_one_line(self._list_of_teases))
        log_display.normal_printer.writeln(f'{self._thumbnail_database.number_of_thumbnails:,} thumbnails loaded')

    def run(self) -> IShutdownAction | None:
        shutdown_action: IRef[IShutdownAction | None] = SimpleRef(None)
        MainWindow(self._local_manifest, self._system_config, CONFIG_SCHEMA, self._list_of_teases, self._thumbnail_database, self._user_variables, shutdown_action)
        return shutdown_action.get()

def _load_local_manifest(filename: Path, warning_printer: IPrinter, error_printer: IPrinter) -> LocalManifestSchema | None:
    try:
        json_root: object = json.loads(filename.read_bytes())
    except FileNotFoundError:
        warning_printer.writeln(f"Local manifest '{filename}' unavailable")
    except (OSError, json.JSONDecodeError, UnicodeDecodeError) as ex:
        error_printer.writeln(f"Unable to read from local manifest '{filename}': {ex}")
    else:
        manifest: LocalManifestSchema = LocalManifestSchema()
        try:
            manifest.load(json_root)
        except SchemaLoadError as ex:
            error_printer.writeln(f"Invalid local manifest '{filename}': {ex}")
        else:
            return manifest
    return None
