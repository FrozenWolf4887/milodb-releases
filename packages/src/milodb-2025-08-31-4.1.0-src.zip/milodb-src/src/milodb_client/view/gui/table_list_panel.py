# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import itertools
import tkinter as tk
import tkinter.font as tkfont
from collections.abc import Callable, Iterable, Sequence
from dataclasses import dataclass
from tkinter import ttk
from typing import Protocol, TYPE_CHECKING, override
from PIL import ImageTk
from milodb_client.database.author import AuthorStatus
from milodb_client.database.tease import Tease, TeaseType, TotmStatus
from milodb_client.output.support import get_list_of_metadata_indices
from milodb_client.query.tease_match import TeaseMatch
from milodb_client.util import sort_keys
from milodb_client.util.sort_keys import ISortKey, OrderedSortKey
from milodb_client.util.tease_match_sorter import ITeaseMatchSorter
from milodb_client.view.gui import general_colours, general_font, general_style, generated_images
from milodb_client.view.gui.banner_text import BANNER_NO_MATCHING_TEASES
from milodb_client.view.gui.canvas_widgets import CanvasPlainText, CanvasSequenceText, TextAlign, get_canvas_event_relative_coord
from milodb_client.view.gui.popup_menu_call import PopupOrigin, PopupTeaseMenuCallback
from milodb_client.view.gui.styled_canvas import StyledCanvas
from milodb_client.view.gui.styled_frame import StyledFrame
from milodb_client.view.gui.util.datum import IValueDatum
from milodb_common.util.ref import IRef
from milodb_common.view.gui.metrics import Bounds, MutableBounds, Padding, Point, Size
if TYPE_CHECKING:
    from milodb_client.view.gui.widget_id import WidgetId

_LINUX_AND_OSX_MOUSEWHEEL_UP_BUTTON: int = 5
_LINUX_AND_OSX_MOUSEWHEEL_DOWN_BUTTON: int = 4

_SCROLL_PAGE_UNITS: int = 10

_HEADER_TEXT_PADDING: Padding = Padding(left=5, top=2, right=5, bottom=2)
_HEADER_VERTICAL_LINE_WIDTH: int = 1
_HEADER_HORIZONTAL_LINE_HEIGHT: int = 1
_HEADING_BORDER_THICKNESS: int = 2
_CONTENT_TEXT_PADDING: Padding = Padding(left=5, top=2, right=5, bottom=2)
_CONTENT_VERTICAL_LINE_WIDTH: int = 1
_CONTENT_HORIZONTAL_LINE_HEIGHT: int = 1
_CONTENT_HIGHLIGHT_PADDING: Padding = Padding(left=2, top=1, right=2, bottom=1)
_BANNER_PADDING_TOP: int = 4

_HORIZONTAL_LINE_TAG: str = 'hl'
_VERTICAL_LINE_TAG: str = 'vl'

_COL_HEADING_BORDER_SORT_ASCENDING: str = '#FF0'
_COL_HEADING_BORDER_SORT_DESCENDING: str = '#0FF'
_COL_BANNER_FORE: str = general_colours.VALUE_TEXT_FORE

_COL_HEADER_INDEX_FORE: str = general_colours.HEADER_INDEX_FORE
_COL_HEADER_HITS_FORE: str = general_colours.HEADER_HITS_FORE
_COL_HEADER_TEASEID_FORE: str = general_colours.HEADER_TEASEID_FORE
_COL_HEADER_TYPE_FORE: str = general_colours.HEADER_TYPE_FORE
_COL_HEADER_RATING_FORE: str = general_colours.HEADER_RATING_FORE
_COL_HEADER_DATE_FORE: str = general_colours.HEADER_DATE_FORE
_COL_HEADER_TITLE_FORE: str = general_colours.HEADER_TITLE_FORE
_COL_HEADER_AUTHOR_FORE: str = general_colours.HEADER_AUTHOR_FORE
_COL_HEADER_TOTM_FORE: str = '#FFF'
_COL_HEADER_TEASE_STATUS_FORE: str = '#FFF'
_COL_HEADER_AUTHOR_STATUS_FORE: str = '#FFF'
_COL_HEADER_AUTHORID_FORE: str = '#FFF'
_COL_HEADER_IMAGE_COUNT_FORE: str = '#FFF'
_COL_HEADER_UNIQUE_IMAGE_COUNT_FORE: str = '#FFF'

_COL_VALUE_INDEX_FORE: str = general_colours.VALUE_INDEX_FORE
_COL_VALUE_HITS_FORE: str = general_colours.VALUE_HITS_FORE
_COL_VALUE_TEASEID_FORE: str = '#FFF'
_COL_VALUE_RATING_FORE: str = general_colours.VALUE_RATING_FORE
_COL_VALUE_DATE_FORE: str = general_colours.VALUE_DATE_FORE
_COL_VALUE_TITLE_FORE: str = general_colours.VALUE_TITLE_FORE
_COL_VALUE_AUTHOR_FORE: str = general_colours.VALUE_AUTHOR_FORE
_COL_VALUE_AUTHOR_UNKNOWN_FORE: str = general_colours.VALUE_AUTHOR_GONE_FORE
_COL_VALUE_AUTHOR_ID_FORE: str = '#AAA'
_COL_VALUE_WORD_COUNT_FORE: str = '#AAA'
_COL_VALUE_IMAGE_COUNT_FORE: str = '#AAA'
_COL_VALUE_UNIQUE_IMAGE_COUNT_FORE: str = '#AAA'
_COL_VALUE_AUDIO_COUNT_FORE: str = '#AAA'
_COL_VALUE_UNIQUE_AUDIO_COUNT_FORE: str = '#AAA'
_COL_HIGHLIGHT_TEXT_BACK: str = general_colours.HIGHLIGHT_TEXT_BACK
_COL_HIGHLIGHT_TEXT_FORE: str = general_colours.HIGHLIGHT_TEXT_FORE
_COL_HIGHLIGHT_TEXT_BORDER: str = general_colours.HIGHLIGHT_TEXT_BORDER
_COL_SELECTED_ROW_BACK: str = general_colours.ITEM_SELECTED_BACK
_COL_SELECTED_ROW_FORE: str = general_colours.ITEM_SELECTED_FORE
_COL_ROW_DIVIDER_LINE: str = general_colours.ITEM_NORMAL_BACK

class _RendererCall(Protocol):
    def __call__(self, bounds: Bounds, row_tag: str, tease_match: TeaseMatch, *, is_selected: bool) -> Size:
        ...

@dataclass
class _Column:
    name: str
    heading: ImageTk.PhotoImage | str
    align: TextAlign
    heading_colour: str
    renderer: _RendererCall
    visible_by_default: bool
    sort_key: ISortKey | None
    default_sort_ascending: bool = False
    heading_width: int = 0
    current_width: int = 0
    max_content_width: int = 0
    visible_variable: tk.BooleanVar | None = None

    @property
    def is_visible(self) -> bool:
        return self.visible_variable.get() if self.visible_variable else self.visible_by_default

class TableListPanel(StyledFrame):
    def __init__(self, master: tk.Misc, list_of_tease_matches: IValueDatum[Sequence[TeaseMatch]], selected_tease_index: IValueDatum[int | None], tease_match_sorter: ITeaseMatchSorter, list_of_active_sort_keys: IRef[Sequence[OrderedSortKey]], call_open_tease: Callable[[Tease], None], call_popup_tease_menu: PopupTeaseMenuCallback) -> None:
        super().__init__(master, style=general_style.FRAME_PANEL)
        self._list_of_tease_matches: IValueDatum[Sequence[TeaseMatch]] = list_of_tease_matches
        self._selected_tease_index: IValueDatum[int | None] = selected_tease_index
        self._tease_match_sorter: ITeaseMatchSorter = tease_match_sorter
        self._list_of_active_sort_keys: IRef[Sequence[OrderedSortKey]] = list_of_active_sort_keys
        self._call_open_tease: Callable[[Tease], None] = call_open_tease
        self._call_popup_tease_menu: PopupTeaseMenuCallback = call_popup_tease_menu

        self._font: tkfont.Font = tkfont.Font(self, general_font.NORMAL_FONT_TUPLE)
        self._italic_font: tkfont.Font = tkfont.Font(self, general_font.ITALIC_FONT_TUPLE)
        self._banner_font: tkfont.Font = tkfont.Font(self, general_font.BANNER_FONT_TUPLE)
        self._text_height: int = self._font.metrics('linespace')
        self._row_height: int = self._text_height + _CONTENT_TEXT_PADDING.height + _CONTENT_HORIZONTAL_LINE_HEIGHT
        self._totm_icon_size: Size = Size(self._text_height, self._text_height)
        self._banner_text: CanvasPlainText | None = None

        self._deleted_tease_image: ImageTk.PhotoImage = ImageTk.PhotoImage(generated_images.render_deleted_tease_image(image_height=self._text_height))
        self._gone_author_image: ImageTk.PhotoImage = ImageTk.PhotoImage(generated_images.render_gone_author_image(image_height=self._text_height))
        self._unknown_author_image: ImageTk.PhotoImage = ImageTk.PhotoImage(generated_images.render_unknown_author_image(image_height=self._text_height))
        self._eos_image: ImageTk.PhotoImage = ImageTk.PhotoImage(generated_images.render_eos_image(image_height=self._text_height))
        self._flash_image: ImageTk.PhotoImage = ImageTk.PhotoImage(generated_images.render_flash_image(image_height=self._text_height))
        self._audio_image: ImageTk.PhotoImage = ImageTk.PhotoImage(generated_images.render_audio_image(image_height=self._text_height))
        self._classic_image: ImageTk.PhotoImage = ImageTk.PhotoImage(generated_images.render_regular_image(image_height=self._text_height))
        self._totm_nominee_image: ImageTk.PhotoImage = ImageTk.PhotoImage(generated_images.render_totm_nominee_image(image_height=self._text_height))
        self._totm_winner_image: ImageTk.PhotoImage = ImageTk.PhotoImage(generated_images.render_totm_winner_image(image_height=self._text_height))
        self._totm_header_image: ImageTk.PhotoImage = ImageTk.PhotoImage(generated_images.render_totm_header_image(image_height=self._text_height))
        self._status_image: ImageTk.PhotoImage = ImageTk.PhotoImage(generated_images.render_status_image(image_height=self._text_height))

        self._list_of_columns: list[_Column] = [
            _Column('Index', 'Idx', TextAlign.RIGHT, _COL_HEADER_INDEX_FORE, self._render_match_index, visible_by_default=True, sort_key=None),
            _Column('Hits', 'Hits', TextAlign.RIGHT, _COL_HEADER_HITS_FORE, self._render_match_hits, visible_by_default=True, sort_key=sort_keys.MATCH_COUNT_SORT_KEY, default_sort_ascending=False),
            _Column('TeaseId', 'TID', TextAlign.RIGHT, _COL_HEADER_TEASEID_FORE, self._render_tease_id, visible_by_default=False, sort_key=sort_keys.TEASE_ID_SORT_KEY, default_sort_ascending=False),
            _Column('Date', 'Date', TextAlign.CENTER, _COL_HEADER_DATE_FORE, self._render_tease_date, visible_by_default=True, sort_key=sort_keys.DATE_SORT_KEY, default_sort_ascending=False),
            _Column('Rating', 'Rating', TextAlign.CENTER, _COL_HEADER_RATING_FORE, self._render_tease_rating, visible_by_default=True, sort_key=sort_keys.RATING_SORT_KEY, default_sort_ascending=False),
            _Column('Type', 'Type', TextAlign.CENTER, _COL_HEADER_TYPE_FORE, self._render_tease_type, visible_by_default=True, sort_key=sort_keys.TYPE_SORT_KEY, default_sort_ascending=False),
            _Column('TOTM', self._totm_header_image, TextAlign.CENTER, _COL_HEADER_TOTM_FORE, self._render_totm_status, visible_by_default=True, sort_key=sort_keys.TOTM_SORT_KEY, default_sort_ascending=False),
            _Column('Tease Status', self._status_image, TextAlign.CENTER, _COL_HEADER_TEASE_STATUS_FORE, self._render_tease_status, visible_by_default=True, sort_key=sort_keys.TEASE_STATUS_SORT_KEY, default_sort_ascending=False),
            _Column('Title', 'Title', TextAlign.LEFT, _COL_HEADER_TITLE_FORE, self._render_tease_title, visible_by_default=True, sort_key=sort_keys.TITLE_SORT_KEY, default_sort_ascending=True),
            _Column('Author Status', self._status_image, TextAlign.CENTER, _COL_HEADER_AUTHOR_STATUS_FORE, self._render_tease_author_status, visible_by_default=True, sort_key=sort_keys.AUTHOR_STATUS_SORT_KEY, default_sort_ascending=False),
            _Column('Author', 'Author', TextAlign.LEFT, _COL_HEADER_AUTHOR_FORE, self._render_tease_author, visible_by_default=True, sort_key=sort_keys.AUTHOR_NAME_SORT_KEY, default_sort_ascending=True),
            _Column('AuthorId', 'AID', TextAlign.RIGHT, _COL_HEADER_AUTHORID_FORE, self._render_author_id, visible_by_default=False, sort_key=sort_keys.AUTHOR_ID_SORT_KEY, default_sort_ascending=False),
            _Column('Words', 'Words', TextAlign.RIGHT, _COL_HEADER_IMAGE_COUNT_FORE, self._render_word_count, visible_by_default=True, sort_key=sort_keys.WORDS_SORT_KEY, default_sort_ascending=False),
            _Column('Images', 'Img', TextAlign.RIGHT, _COL_HEADER_IMAGE_COUNT_FORE, self._render_image_count, visible_by_default=True, sort_key=sort_keys.IMAGES_SORT_KEY, default_sort_ascending=False),
            _Column('Unique Images', 'UImg', TextAlign.RIGHT, _COL_HEADER_UNIQUE_IMAGE_COUNT_FORE, self._render_unique_image_count, visible_by_default=True, sort_key=sort_keys.UNIQUE_IMAGES_SORT_KEY, default_sort_ascending=False),
            _Column('Audio', 'Aud', TextAlign.RIGHT, _COL_HEADER_IMAGE_COUNT_FORE, self._render_audio_count, visible_by_default=True, sort_key=sort_keys.AUDIO_SORT_KEY, default_sort_ascending=False),
            _Column('Unique Audio', 'UAud', TextAlign.RIGHT, _COL_HEADER_UNIQUE_IMAGE_COUNT_FORE, self._render_unique_audio_count, visible_by_default=True, sort_key=sort_keys.UNIQUE_AUDIO_SORT_KEY, default_sort_ascending=False),
        ]

        self._content_bounds: MutableBounds = Bounds.empty()
        self._selection_bar_id: WidgetId | None = None
        self._current_top_index: int = 0
        self._current_bottom_index: int = -1

        self._create_header_canvas()
        self._create_content_canvas()
        self._redraw_header()
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=1)

        self._list_of_tease_matches.add_new_value_listener(self._on_list_of_tease_matches_changed, call_immediately=True)
        self._selected_tease_index.add_changed_value_listener(self._on_selected_tease_index_changed, call_immediately=True)

    @override
    def destroy(self) -> None:
        self._list_of_tease_matches.remove_listener(self._on_list_of_tease_matches_changed)
        self._selected_tease_index.remove_listener(self._on_selected_tease_index_changed)
        self._destroy_banner_text()
        super().destroy()

    def _on_list_of_tease_matches_changed(self, new_value: Sequence[TeaseMatch]) -> None:
        column: _Column
        for column in self._iterate_visible_columns():
            column.current_width = 0
            column.max_content_width = 0
        self._heading_canvas.xview_moveto(0)
        self._redraw_header()

        self._content_canvas.delete(tk.ALL)
        self._content_canvas.xview_moveto(0)
        self._content_canvas.yview_moveto(0)
        self._selection_bar_id = None
        self._current_top_index = 0
        self._current_bottom_index = -1
        self._content_bounds = MutableBounds(0, 0, 0, (len(new_value) * self._row_height) - _CONTENT_HORIZONTAL_LINE_HEIGHT)
        self._content_canvas.config(scrollregion=self._content_bounds.to_tuple())
        self._redraw_vertical_content_lines(self._content_bounds.height)
        self._update_visible_rows()

    def _on_selected_tease_index_changed(self, old_value: int | None, new_value: int | None) -> None:
        if new_value is not None:
            self._ensure_visible_row(new_value)
        self._redraw_selection_bar(old_row=old_value, new_row=new_value)

    def _ensure_visible_row(self, row: int) -> None:
        number_of_rows: int = len(self._list_of_tease_matches.get())
        top_index, bottom_index = self._get_visible_top_and_bottom_row_indices(include_partially_visible=False)
        if row < top_index or row > bottom_index:
            max_rows_per_panel: float = self._content_canvas.winfo_height() / self._row_height
            scroll_position: float = max(0.0, (row - (max_rows_per_panel / 2) + 0.5) / number_of_rows)
            self._content_canvas.yview_moveto(scroll_position)
            self._update_visible_rows()

    def _update_visible_rows(self) -> None:
        self._destroy_banner_text()
        if not self._list_of_tease_matches:
            self._add_banner_text(BANNER_NO_MATCHING_TEASES)

        top_index: int
        bottom_index: int
        top_index, bottom_index = self._get_visible_top_and_bottom_row_indices(include_partially_visible=True)
        bottom_index = min(bottom_index, len(self._list_of_tease_matches.get()) - 1)

        # Draw rows coming into view

        for index in itertools.chain(
            range(max(self._current_bottom_index + 1, top_index), bottom_index + 1),
            range(top_index, min(self._current_top_index, bottom_index + 1)),
            ):
            self._draw_row(index)

        # Remove rows dropped out of view

        for index in itertools.chain(
            range(self._current_top_index, min(top_index, self._current_bottom_index + 1)),
            range(max(bottom_index + 1, self._current_top_index), self._current_bottom_index + 1),
            ):
            self._remove_row(index)

        self._current_top_index = top_index
        self._current_bottom_index = bottom_index

        self._redraw_if_any_column_widths_have_changed()
        self._redraw_horizontal_content_lines()

        # Ensure selection bar is lowest in Z-order

        if self._selection_bar_id is not None:
            self._content_canvas.tag_lower(self._selection_bar_id, tk.ALL)

    def _redraw_if_any_column_widths_have_changed(self) -> None:
        if any(column.max_content_width != column.current_width for column in self._iterate_visible_columns()):
            total_row_width: int = 0
            for column in self._iterate_visible_columns():
                column.current_width = max(column.heading_width, column.max_content_width)
                total_row_width += column.current_width + _HEADER_VERTICAL_LINE_WIDTH
            self._content_bounds.right = total_row_width - _HEADER_VERTICAL_LINE_WIDTH
            self._content_canvas.config(scrollregion=self._content_bounds.to_tuple())
            self._heading_canvas.config(scrollregion=(0, 0, self._content_bounds.width, 0))
            self._redraw_header()
            self._redraw_content()

    def _redraw_horizontal_content_lines(self) -> None:
        self._content_canvas.delete(_HORIZONTAL_LINE_TAG)

        line_width: int = max(self._content_bounds.width, self._content_canvas.winfo_width())
        offset_y = (self._current_top_index + 1) * self._row_height - _CONTENT_HORIZONTAL_LINE_HEIGHT
        for _ in range(self._current_top_index, self._current_bottom_index):
            self._content_canvas.create_line(0, offset_y, line_width, offset_y, width=_CONTENT_HORIZONTAL_LINE_HEIGHT, fill=_COL_ROW_DIVIDER_LINE, tags=_HORIZONTAL_LINE_TAG)
            offset_y += self._row_height

    def _redraw_content(self) -> None:
        for index in range(self._current_top_index, self._current_bottom_index + 1):
            self._remove_row(index)
            self._draw_row(index)
        self._redraw_vertical_content_lines(self._content_bounds.height)
        self._redraw_selection_bar(old_row=None, new_row=self._selected_tease_index.get())

    def _draw_row(self, index: int) -> None:
        is_selected: bool = index == self._selected_tease_index.get()
        cell_x: int = 0
        cell_y = index * self._row_height

        column: _Column
        for column in self._iterate_visible_columns():
            bounds: Bounds = Bounds(cell_x, cell_y, cell_x + column.current_width, cell_y + self._row_height)
            size: Size = column.renderer(bounds, f'row{index}', self._list_of_tease_matches.get()[index], is_selected=is_selected)
            column.max_content_width = max(column.max_content_width, size.width)
            cell_x += column.current_width + _CONTENT_VERTICAL_LINE_WIDTH

    def _remove_row(self, index: int) -> None:
        self._content_canvas.delete(f'row{index}')

    def _render_match_index(self, bounds: Bounds, row_tag: str, tease_match: TeaseMatch, *, is_selected: bool) -> Size:
        text = CanvasPlainText(
            self._content_canvas,
            bounds.right - _CONTENT_TEXT_PADDING.right, bounds.top + _CONTENT_TEXT_PADDING.top,
            text = str(tease_match.index_of_match),
            font = self._font,
            fill = _COL_VALUE_INDEX_FORE if not is_selected else _COL_SELECTED_ROW_FORE,
            anchor = tk.NE,
            tags = row_tag,
        )
        return Size(text.bounds.width + _CONTENT_TEXT_PADDING.width, text.bounds.height + _CONTENT_TEXT_PADDING.height)

    def _render_match_hits(self, bounds: Bounds, row_tag: str, tease_match: TeaseMatch, *, is_selected: bool) -> Size:
        text = CanvasPlainText(
            self._content_canvas,
            bounds.right - _CONTENT_TEXT_PADDING.right, bounds.top + _CONTENT_TEXT_PADDING.top,
            text = f'{tease_match.get_match_count():,}',
            font = self._font,
            fill = _COL_VALUE_HITS_FORE if not is_selected else _COL_SELECTED_ROW_FORE,
            anchor = tk.NE,
            tags = row_tag,
        )
        return Size(text.bounds.width + _CONTENT_TEXT_PADDING.width, text.bounds.height + _CONTENT_TEXT_PADDING.height)

    def _render_tease_id(self, bounds: Bounds, row_tag: str, tease_match: TeaseMatch, *, is_selected: bool) -> Size:
        text = CanvasSequenceText(
            self._content_canvas,
            bounds.right - _CONTENT_TEXT_PADDING.right, bounds.top + _CONTENT_TEXT_PADDING.top,
            text = str(tease_match.tease.get_tease_id()),
            align = TextAlign.RIGHT,
            font = self._font,
            foreground = _COL_VALUE_TEASEID_FORE if not is_selected else _COL_SELECTED_ROW_FORE,
            highlight_foreground = _COL_HIGHLIGHT_TEXT_FORE,
            highlight_background = _COL_HIGHLIGHT_TEXT_BACK,
            highlight_border = _COL_HIGHLIGHT_TEXT_BORDER,
            highlight_padding = _CONTENT_HIGHLIGHT_PADDING,
            list_of_indices = get_list_of_metadata_indices(Tease.get_tease_id, tease_match.list_of_field_matches),
            tag = row_tag,
        )
        return Size(text.bounds.width + _CONTENT_TEXT_PADDING.width, text.bounds.height + _CONTENT_TEXT_PADDING.height)

    def _render_tease_type(self, bounds: Bounds, row_tag: str, tease_match: TeaseMatch, *, is_selected: bool) -> Size: # pylint: disable=W0613:unused-argument # noqa: ARG002 Unused function argument
        type_image: ImageTk.PhotoImage
        match tease_match.tease.get_type():
            case TeaseType.EOS:
                type_image = self._eos_image
            case TeaseType.NYX:
                type_image = self._flash_image
            case TeaseType.REGULAR:
                type_image = self._classic_image
            case TeaseType.AUDIO:
                type_image = self._audio_image

        self._content_canvas.create_image(bounds.left + bounds.width // 2, bounds.top + _CONTENT_TEXT_PADDING.top, image=type_image, anchor=tk.N, tags=row_tag)
        return Size(type_image.width() + _CONTENT_TEXT_PADDING.width, type_image.height() + _CONTENT_TEXT_PADDING.height)

    def _render_tease_rating(self, bounds: Bounds, row_tag: str, tease_match: TeaseMatch, *, is_selected: bool) -> Size:
        text = CanvasSequenceText(
            self._content_canvas,
            bounds.middle_x, bounds.top + _CONTENT_TEXT_PADDING.top,
            text = str(tease_match.tease.get_rating_value()),
            align = TextAlign.CENTER,
            font = self._font,
            foreground = _COL_VALUE_RATING_FORE if not is_selected else _COL_SELECTED_ROW_FORE,
            highlight_foreground = _COL_HIGHLIGHT_TEXT_FORE,
            highlight_background = _COL_HIGHLIGHT_TEXT_BACK,
            highlight_border = _COL_HIGHLIGHT_TEXT_BORDER,
            highlight_padding = _CONTENT_HIGHLIGHT_PADDING,
            list_of_indices = get_list_of_metadata_indices(Tease.get_rating_value, tease_match.list_of_field_matches),
            tag = row_tag,
        )
        return Size(text.bounds.width + _CONTENT_TEXT_PADDING.width, text.bounds.height + _CONTENT_TEXT_PADDING.height)

    def _render_totm_status(self, bounds: Bounds, row_tag: str, tease_match: TeaseMatch, *, is_selected: bool) -> Size: # pylint: disable=W0613:unused-argument # noqa: ARG002 Unused function argument
        totm_image: ImageTk.PhotoImage | None
        match tease_match.tease.get_totm_status():
            case TotmStatus.WINNER:
                totm_image = self._totm_winner_image
            case TotmStatus.NOMINEE:
                totm_image = self._totm_nominee_image
            case TotmStatus.NONE:
                totm_image = None
        if totm_image:
            self._content_canvas.create_image(bounds.left + bounds.width // 2, bounds.top + _CONTENT_TEXT_PADDING.top, image=totm_image, anchor=tk.N, tags=row_tag)
            return Size(self._totm_icon_size.width + _CONTENT_TEXT_PADDING.width, self._totm_icon_size.height + _CONTENT_TEXT_PADDING.height)
        return Size(0, 0)

    def _render_tease_date(self, bounds: Bounds, row_tag: str, tease_match: TeaseMatch, *, is_selected: bool) -> Size:
        text = CanvasSequenceText(
            self._content_canvas,
            bounds.middle_x, bounds.top + _CONTENT_TEXT_PADDING.top,
            text = tease_match.tease.get_date().isoformat(),
            align = TextAlign.CENTER,
            font = self._font,
            foreground = _COL_VALUE_DATE_FORE if not is_selected else _COL_SELECTED_ROW_FORE,
            highlight_foreground = _COL_HIGHLIGHT_TEXT_FORE,
            highlight_background = _COL_HIGHLIGHT_TEXT_BACK,
            highlight_border = _COL_HIGHLIGHT_TEXT_BORDER,
            highlight_padding = _CONTENT_HIGHLIGHT_PADDING,
            list_of_indices = get_list_of_metadata_indices(Tease.get_date, tease_match.list_of_field_matches),
            tag = row_tag,
        )
        return Size(text.bounds.width + _CONTENT_TEXT_PADDING.width, text.bounds.height + _CONTENT_TEXT_PADDING.height)

    def _render_tease_status(self, bounds: Bounds, row_tag: str, tease_match: TeaseMatch, *, is_selected: bool) -> Size: # pylint: disable=W0613:unused-argument # noqa: ARG002 Unused function argument
        if tease_match.tease.is_deleted():
            self._content_canvas.create_image(bounds.left + bounds.width // 2, bounds.top + _CONTENT_TEXT_PADDING.top, image=self._deleted_tease_image, anchor=tk.N, tags=row_tag)
            return Size(self._totm_icon_size.width + _CONTENT_TEXT_PADDING.width, self._totm_icon_size.height + _CONTENT_TEXT_PADDING.height)
        return Size(0, 0)

    def _render_tease_title(self, bounds: Bounds, row_tag: str, tease_match: TeaseMatch, *, is_selected: bool) -> Size:
        text = CanvasSequenceText(
            self._content_canvas,
            bounds.left + _CONTENT_TEXT_PADDING.left, bounds.top + _CONTENT_TEXT_PADDING.top,
            text = tease_match.tease.get_title(),
            align = TextAlign.LEFT,
            font = self._font,
            foreground = _COL_VALUE_TITLE_FORE if not is_selected else _COL_SELECTED_ROW_FORE,
            highlight_foreground = _COL_HIGHLIGHT_TEXT_FORE,
            highlight_background = _COL_HIGHLIGHT_TEXT_BACK,
            highlight_border = _COL_HIGHLIGHT_TEXT_BORDER,
            highlight_padding = _CONTENT_HIGHLIGHT_PADDING,
            list_of_indices = get_list_of_metadata_indices(Tease.get_title, tease_match.list_of_field_matches),
            tag = row_tag,
        )
        return Size(text.bounds.width + _CONTENT_TEXT_PADDING.width, text.bounds.height + _CONTENT_TEXT_PADDING.height)

    def _render_tease_author(self, bounds: Bounds, row_tag: str, tease_match: TeaseMatch, *, is_selected: bool) -> Size:
        text: CanvasSequenceText | CanvasPlainText
        if tease_match.tease.author.has_author:
            text = CanvasSequenceText(
                self._content_canvas,
                bounds.left + _CONTENT_TEXT_PADDING.left, bounds.top + _CONTENT_TEXT_PADDING.top,
                text = tease_match.tease.get_author_name(),
                align = TextAlign.LEFT,
                font = self._font,
                foreground = _COL_VALUE_AUTHOR_FORE if not is_selected else _COL_SELECTED_ROW_FORE,
                highlight_foreground = _COL_HIGHLIGHT_TEXT_FORE,
                highlight_background = _COL_HIGHLIGHT_TEXT_BACK,
                highlight_border = _COL_HIGHLIGHT_TEXT_BORDER,
                highlight_padding = _CONTENT_HIGHLIGHT_PADDING,
                list_of_indices = get_list_of_metadata_indices(Tease.get_author_name, tease_match.list_of_field_matches),
                tag = row_tag,
            )
        else:
            text = CanvasPlainText(
                self._content_canvas,
                bounds.left + _CONTENT_TEXT_PADDING.left, bounds.top + _CONTENT_TEXT_PADDING.top,
                text = 'unknown',
                font = self._italic_font,
                fill = _COL_VALUE_AUTHOR_UNKNOWN_FORE,
                anchor = tk.NW,
                tags = row_tag,
            )

        return Size(text.bounds.width + _CONTENT_TEXT_PADDING.width, text.bounds.height + _CONTENT_TEXT_PADDING.height)

    def _render_tease_author_status(self, bounds: Bounds, row_tag: str, tease_match: TeaseMatch, *, is_selected: bool) -> Size: # pylint: disable=W0613:unused-argument # noqa: ARG002 Unused function argument
        status_image: ImageTk.PhotoImage | None
        match tease_match.tease.get_author_status():
            case AuthorStatus.GONE:
                status_image = self._gone_author_image
            case AuthorStatus.UNKNOWN:
                status_image = self._unknown_author_image
            case AuthorStatus.ACTIVE:
                status_image = None
        if status_image:
            self._content_canvas.create_image(bounds.left + bounds.width // 2, bounds.top + _CONTENT_TEXT_PADDING.top, image=status_image, anchor=tk.N, tags=row_tag)
            return Size(self._totm_icon_size.width + _CONTENT_TEXT_PADDING.width, self._totm_icon_size.height + _CONTENT_TEXT_PADDING.height)
        return Size(0, 0)

    def _render_author_id(self, bounds: Bounds, row_tag: str, tease_match: TeaseMatch, *, is_selected: bool) -> Size:
        if tease_match.tease.author.has_author:
            text = CanvasSequenceText(
                self._content_canvas,
                bounds.right - _CONTENT_TEXT_PADDING.right, bounds.top + _CONTENT_TEXT_PADDING.top,
                text = str(tease_match.tease.get_author_id()),
                align = TextAlign.RIGHT,
                font = self._font,
                foreground = _COL_VALUE_AUTHOR_ID_FORE if not is_selected else _COL_SELECTED_ROW_FORE,
                highlight_foreground = _COL_HIGHLIGHT_TEXT_FORE,
                highlight_background = _COL_HIGHLIGHT_TEXT_BACK,
                highlight_border = _COL_HIGHLIGHT_TEXT_BORDER,
                highlight_padding = _CONTENT_HIGHLIGHT_PADDING,
                list_of_indices = get_list_of_metadata_indices(Tease.get_author_id, tease_match.list_of_field_matches),
                tag = row_tag,
            )
            return Size(text.bounds.width + _CONTENT_TEXT_PADDING.width, text.bounds.height + _CONTENT_TEXT_PADDING.height)
        return Size(0, 0)

    def _render_word_count(self, bounds: Bounds, row_tag: str, tease_match: TeaseMatch, *, is_selected: bool) -> Size:
        text = CanvasPlainText(
            self._content_canvas,
            bounds.right - _CONTENT_TEXT_PADDING.right, bounds.top + _CONTENT_TEXT_PADDING.top,
            text = f'{tease_match.tease.get_word_count():,}',
            font = self._font,
            fill = _COL_VALUE_WORD_COUNT_FORE if not is_selected else _COL_SELECTED_ROW_FORE,
            anchor = tk.NE,
            tags = row_tag,
        )
        return Size(text.bounds.width + _CONTENT_TEXT_PADDING.width, text.bounds.height + _CONTENT_TEXT_PADDING.height)

    def _render_image_count(self, bounds: Bounds, row_tag: str, tease_match: TeaseMatch, *, is_selected: bool) -> Size:
        text = CanvasPlainText(
            self._content_canvas,
            bounds.right - _CONTENT_TEXT_PADDING.right, bounds.top + _CONTENT_TEXT_PADDING.top,
            text = f'{tease_match.tease.get_count_of_images():,}',
            font = self._font,
            fill = _COL_VALUE_IMAGE_COUNT_FORE if not is_selected else _COL_SELECTED_ROW_FORE,
            anchor = tk.NE,
            tags = row_tag,
        )
        return Size(text.bounds.width + _CONTENT_TEXT_PADDING.width, text.bounds.height + _CONTENT_TEXT_PADDING.height)

    def _render_unique_image_count(self, bounds: Bounds, row_tag: str, tease_match: TeaseMatch, *, is_selected: bool) -> Size:
        text = CanvasPlainText(
            self._content_canvas,
            bounds.right - _CONTENT_TEXT_PADDING.right, bounds.top + _CONTENT_TEXT_PADDING.top,
            text = f'{tease_match.tease.get_count_of_unique_images():,}',
            font = self._font,
            fill = _COL_VALUE_UNIQUE_IMAGE_COUNT_FORE if not is_selected else _COL_SELECTED_ROW_FORE,
            anchor = tk.NE,
            tag = row_tag,
        )
        return Size(text.bounds.width + _CONTENT_TEXT_PADDING.width, text.bounds.height + _CONTENT_TEXT_PADDING.height)

    def _render_audio_count(self, bounds: Bounds, row_tag: str, tease_match: TeaseMatch, *, is_selected: bool) -> Size:
        text = CanvasPlainText(
            self._content_canvas,
            bounds.right - _CONTENT_TEXT_PADDING.right, bounds.top + _CONTENT_TEXT_PADDING.top,
            text = f'{tease_match.tease.get_count_of_audio():,}',
            font = self._font,
            fill = _COL_VALUE_AUDIO_COUNT_FORE if not is_selected else _COL_SELECTED_ROW_FORE,
            anchor = tk.NE,
            tags = row_tag,
        )
        return Size(text.bounds.width + _CONTENT_TEXT_PADDING.width, text.bounds.height + _CONTENT_TEXT_PADDING.height)

    def _render_unique_audio_count(self, bounds: Bounds, row_tag: str, tease_match: TeaseMatch, *, is_selected: bool) -> Size:
        text = CanvasPlainText(
            self._content_canvas,
            bounds.right - _CONTENT_TEXT_PADDING.right, bounds.top + _CONTENT_TEXT_PADDING.top,
            text = f'{tease_match.tease.get_count_of_unique_audio():,}',
            font = self._font,
            fill = _COL_VALUE_UNIQUE_AUDIO_COUNT_FORE if not is_selected else _COL_SELECTED_ROW_FORE,
            anchor = tk.NE,
            tag = row_tag,
        )
        return Size(text.bounds.width + _CONTENT_TEXT_PADDING.width, text.bounds.height + _CONTENT_TEXT_PADDING.height)

    def _create_header_canvas(self) -> None:
        self._heading_canvas: StyledCanvas = StyledCanvas(self, style=general_style.CANVAS_SORTABLE_HEADER)
        self._heading_canvas.grid(row=0, column=0, sticky=tk.EW)
        self._heading_canvas.bind('<Configure>', self._on_header_canvas_resized)
        self._heading_canvas.bind('<Button-1>', self._on_header_mouse_click)
        self._heading_canvas.bind('<Button-2>', self._on_header_right_mouse_click)
        self._heading_canvas.bind('<Button-3>', self._on_header_right_mouse_click)

    def _create_content_canvas(self) -> None:
        self._content_canvas: StyledCanvas = StyledCanvas(self)
        self._content_canvas.grid(row=1, column=0, sticky=tk.NSEW)
        self._content_canvas.bind('<Configure>', self._on_content_canvas_resized)

        self._vertical_scrollbar: ttk.Scrollbar = ttk.Scrollbar(self, orient=tk.VERTICAL, command=self._on_vertical_scroll)
        self._vertical_scrollbar.grid(row=1, column=1, sticky=tk.NS)
        self._content_canvas.config(yscrollcommand=self._vertical_scrollbar.set)

        horizontal_scrollbar: ttk.Scrollbar = ttk.Scrollbar(self, orient=tk.HORIZONTAL, command=self._on_horizontal_scroll)
        horizontal_scrollbar.grid(row=2, column=0, sticky=tk.EW)
        self._heading_canvas.config(xscrollcommand=horizontal_scrollbar.set)
        self._content_canvas.config(xscrollcommand=horizontal_scrollbar.set)

        self._content_canvas.bind("<MouseWheel>", lambda event: self._scroll_vertically(_get_scroll_direction_from_event(event)))
        self._content_canvas.bind("<Button-4>", lambda event: self._scroll_vertically(_get_scroll_direction_from_event(event)))
        self._content_canvas.bind("<Button-5>", lambda event: self._scroll_vertically(_get_scroll_direction_from_event(event)))
        self._content_canvas.bind("<Control-MouseWheel>", lambda event: self._scroll_vertically(_get_scroll_direction_from_event(event) * _SCROLL_PAGE_UNITS))
        self._content_canvas.bind("<Control-Button-4>", lambda event: self._scroll_vertically(_get_scroll_direction_from_event(event) * _SCROLL_PAGE_UNITS))
        self._content_canvas.bind("<Control-Button-5>", lambda event: self._scroll_vertically(_get_scroll_direction_from_event(event) * _SCROLL_PAGE_UNITS))
        self._content_canvas.bind("<Shift-MouseWheel>", lambda event: self._scroll_horizontally(_get_scroll_direction_from_event(event)))
        self._content_canvas.bind("<Shift-Button-4>", lambda event: self._scroll_horizontally(_get_scroll_direction_from_event(event)))
        self._content_canvas.bind("<Shift-Button-5>", lambda event: self._scroll_horizontally(_get_scroll_direction_from_event(event)))
        self._content_canvas.bind("<Control-Shift-MouseWheel>", lambda event: self._scroll_horizontally(_get_scroll_direction_from_event(event) * _SCROLL_PAGE_UNITS))
        self._content_canvas.bind("<Control-Shift-Button-4>", lambda event: self._scroll_horizontally(_get_scroll_direction_from_event(event) * _SCROLL_PAGE_UNITS))
        self._content_canvas.bind("<Control-Shift-Button-5>", lambda event: self._scroll_horizontally(_get_scroll_direction_from_event(event) * _SCROLL_PAGE_UNITS))

        self._content_canvas.bind('<Button-1>', self._on_content_mouse_click)
        self._content_canvas.bind('<Double-1>', self._on_content_mouse_double_click)
        self._content_canvas.bind('<Button-2>', self._on_content_mouse_right_click)
        self._content_canvas.bind('<Button-3>', self._on_content_mouse_right_click)

    def _redraw_header(self) -> None:
        self._heading_canvas.delete(tk.ALL)

        canvas_height: int = self._text_height + _HEADER_TEXT_PADDING.height + _HEADER_HORIZONTAL_LINE_HEIGHT - 1

        offset_x: int = 0
        column_index: int
        column: _Column
        for column_index, column in enumerate(self._iterate_visible_columns()):
            self._draw_header_item(column, offset_x)

            sort_key: OrderedSortKey | None = self._get_active_sort_key_for_column(column)
            if sort_key:
                heading_border_colour: str = _COL_HEADING_BORDER_SORT_ASCENDING if sort_key.is_ascending else _COL_HEADING_BORDER_SORT_DESCENDING
                self._heading_canvas.create_rectangle(offset_x + _HEADING_BORDER_THICKNESS / 2, _HEADING_BORDER_THICKNESS / 2, offset_x + column.current_width -  _HEADING_BORDER_THICKNESS / 2, canvas_height - 1 - _HEADING_BORDER_THICKNESS / 2, width=_HEADING_BORDER_THICKNESS, outline=heading_border_colour)

            offset_x += column.current_width
            if column_index != len(self._list_of_columns) -1:
                self._heading_canvas.create_line(offset_x, 0, offset_x, self._text_height + _HEADER_TEXT_PADDING.height, width=_HEADER_VERTICAL_LINE_WIDTH)
            offset_x += _HEADER_VERTICAL_LINE_WIDTH

        self._heading_canvas.config(height=canvas_height)

        self._redraw_header_horizontal_line()

    def _draw_header_item(self, column: _Column, x: int) -> None:
        column.heading_width = 0

        match column.heading:
            case ImageTk.PhotoImage():
                match column.align:
                    case TextAlign.LEFT:
                        self._heading_canvas.create_image(x + _HEADER_TEXT_PADDING.left, _HEADER_TEXT_PADDING.top, image=column.heading, anchor=tk.NW)
                    case TextAlign.RIGHT:
                        self._heading_canvas.create_image(x + column.current_width - _HEADER_TEXT_PADDING.right, _HEADER_TEXT_PADDING.top, image=column.heading, anchor=tk.NE)
                    case TextAlign.CENTER:
                        self._heading_canvas.create_image(x + column.current_width // 2, _HEADER_TEXT_PADDING.top, image=column.heading, anchor=tk.N)
                column.heading_width = column.heading.width() + _HEADER_TEXT_PADDING.width
            case str():
                match column.align:
                    case TextAlign.LEFT:
                        self._heading_canvas.create_text(x + _HEADER_TEXT_PADDING.left, _HEADER_TEXT_PADDING.top, text=column.heading, font=self._font, fill=column.heading_colour, anchor=tk.NW)
                    case TextAlign.RIGHT:
                        self._heading_canvas.create_text(x + column.current_width - _HEADER_TEXT_PADDING.right, _HEADER_TEXT_PADDING.top, text=column.heading, font=self._font, fill=column.heading_colour, anchor=tk.NE)
                    case TextAlign.CENTER:
                        self._heading_canvas.create_text(x + column.current_width  // 2, _HEADER_TEXT_PADDING.top, text=column.heading, font=self._font, fill=column.heading_colour, anchor=tk.N)
                column.heading_width = self._font.measure(column.heading) + _HEADER_TEXT_PADDING.width

        column.current_width = max(column.current_width, column.heading_width)

    def _iterate_visible_columns(self) -> Iterable[_Column]:
        column: _Column
        for column in self._list_of_columns:
            if column.is_visible:
                yield column

    def _redraw_header_horizontal_line(self) -> None:
        self._heading_canvas.delete(_HORIZONTAL_LINE_TAG)
        line_y: int = self._heading_canvas.winfo_height() - _HEADER_HORIZONTAL_LINE_HEIGHT
        line_width: int = max(self._content_bounds.width, self._heading_canvas.winfo_width())
        self._heading_canvas.create_line(0, line_y, line_width - 1, line_y, width=_HEADER_HORIZONTAL_LINE_HEIGHT, tags=_HORIZONTAL_LINE_TAG)

    def _get_visible_top_and_bottom_row_indices(self, *, include_partially_visible: bool) -> tuple[int, int]:
        canvas_height: int = self._content_canvas.winfo_height()
        top_index: int
        bottom_index: int
        if include_partially_visible:
            top_index = int(self._content_canvas.canvasy(0) // self._row_height)
            bottom_index = int(self._content_canvas.canvasy(canvas_height - 1) // self._row_height)
        else:
            top_index = int(self._content_canvas.canvasy(self._row_height) // self._row_height)
            bottom_index = int(self._content_canvas.canvasy(canvas_height - 1 - self._row_height) // self._row_height)
        return top_index, bottom_index

    def _add_banner_text(self, text: str) -> None:
        self._banner_text = CanvasPlainText(
            self._content_canvas,
            origin_x = self._content_canvas.winfo_width() // 2,
            origin_y = _BANNER_PADDING_TOP,
            text = text,
            fill = _COL_BANNER_FORE,
            font = self._banner_font,
            justify = tk.CENTER,
            anchor = tk.N,
        )

    def _destroy_banner_text(self) -> None:
        if self._banner_text:
            self._banner_text.destroy()
            self._banner_text = None

    def _on_vertical_scroll(self, *args: object) -> None:
        if self._content_canvas.yview() != (0.0, 1.0):
            self._content_canvas.yview(*args)
            self._update_visible_rows()

    def _on_horizontal_scroll(self, *args: object) -> None:
        if self._content_canvas.xview() != (0.0, 1.0):
            self._heading_canvas.xview(*args)
            self._content_canvas.xview(*args)

    def _scroll_vertically(self, scroll_value: int) -> None:
        if scroll_value and self._content_canvas.yview() != (0.0, 1.0):
            self._content_canvas.yview_scroll(scroll_value, tk.UNITS)
            self._update_visible_rows()

    def _scroll_horizontally(self, scroll_value: int) -> None:
        if scroll_value and self._content_canvas.xview() != (0.0, 1.0):
            self._heading_canvas.xview_scroll(scroll_value, tk.UNITS)
            self._content_canvas.xview_scroll(scroll_value, tk.UNITS)

    def _on_header_canvas_resized(self, _event: object) -> None:
        self._redraw_header_horizontal_line()

    def _on_header_mouse_click(self, event: tk.Event) -> None:
        point: Point = get_canvas_event_relative_coord(self._heading_canvas, event)
        column: _Column | None = self._get_column_from_x_offset(point.x)
        if column and column.sort_key:
            ordered_sort_key: OrderedSortKey | None = self._get_active_sort_key_for_column(column)
            if ordered_sort_key:
                self._sort_list(column.sort_key, is_ascending=not ordered_sort_key.is_ascending)
            else:
                self._sort_list(column.sort_key, is_ascending=column.default_sort_ascending)

    def _on_header_right_mouse_click(self, event: tk.Event) -> None:
        popup_menu: tk.Menu = tk.Menu(self, tearoff=0)
        popup_menu.add_command(label='Reset columns to default', command=self._on_reset_visible_headers)
        popup_menu.add_separator()
        column: _Column
        for column in self._list_of_columns:
            if not column.visible_variable:
                column.visible_variable = tk.BooleanVar(self, column.visible_by_default)
            popup_menu.add_checkbutton(label=column.name, variable=column.visible_variable, command=self._on_visible_headers_changed)
        popup_menu.tk_popup(event.x_root, event.y_root)
        popup_menu.focus()
        popup_menu.bind('<FocusOut>', lambda _event: popup_menu.destroy())

    def _on_reset_visible_headers(self) -> None:
        column: _Column
        for column in self._list_of_columns:
            if column.visible_variable:
                column.visible_variable.set(column.visible_by_default)
        self._redraw_header()
        self._redraw_content()
        self._redraw_if_any_column_widths_have_changed()
        self._redraw_horizontal_content_lines()

    def _on_visible_headers_changed(self) -> None:
        column: _Column
        for column in self._list_of_columns:
            if not column.is_visible:
                column.max_content_width = 0
                column.current_width = 0
        self._redraw_header()
        self._redraw_content()
        self._redraw_if_any_column_widths_have_changed()
        self._redraw_horizontal_content_lines()

    def _get_column_from_x_offset(self, x_offset: float) -> _Column | None:
        column: _Column | None = None
        column_right_x: int = 0
        for column in self._iterate_visible_columns():
            column_right_x += column.current_width + _HEADER_VERTICAL_LINE_WIDTH
            if x_offset < column_right_x:
                return column
        return None

    def _get_active_sort_key_for_column(self, column: _Column) -> OrderedSortKey | None:
        sort_key: OrderedSortKey
        for sort_key in self._list_of_active_sort_keys.get():
            if column.sort_key is sort_key.original_sort_key:
                return sort_key
        return None

    def _sort_list(self, sort_key: ISortKey, *, is_ascending: bool) -> None:
        self._list_of_active_sort_keys.set([OrderedSortKey(sort_key, is_ascending=is_ascending)])
        sorted_list_of_tease_matches: list[TeaseMatch] = self._tease_match_sorter.sort(self._list_of_tease_matches.get(), self._list_of_active_sort_keys.get())
        self._redraw_header()
        self._selected_tease_index.set(None)
        self._list_of_tease_matches.set(sorted_list_of_tease_matches)

    def _on_content_canvas_resized(self, _event: object) -> None:
        self._update_visible_rows()
        self._redraw_selection_bar(old_row=None, new_row=self._selected_tease_index.get())

    def _on_content_mouse_click(self, event: tk.Event) -> None:
        point: Point = get_canvas_event_relative_coord(self._content_canvas, event)
        row = int(point.y / self._row_height)
        if row < len(self._list_of_tease_matches.get()):
            self._selected_tease_index.set(row)

    def _on_content_mouse_double_click(self, event: tk.Event) -> None:
        point: Point = get_canvas_event_relative_coord(self._content_canvas, event)
        row = int(point.y / self._row_height)
        if row < len(self._list_of_tease_matches.get()):
            self._call_open_tease(self._list_of_tease_matches.get()[row].tease)

    def _on_content_mouse_right_click(self, event: tk.Event) -> str:
        point: Point = get_canvas_event_relative_coord(self._content_canvas, event)
        row = int(point.y / self._row_height)
        if row < len(self._list_of_tease_matches.get()):
            self._selected_tease_index.set(row)
            tease_match: TeaseMatch = self._list_of_tease_matches.get()[row]
            self._call_popup_tease_menu(self._content_canvas, event.x_root, event.y_root, tease_match, PopupOrigin.LIST_ROW)
        return 'break'

    def _redraw_vertical_content_lines(self, content_height: int) -> None:
        self._content_canvas.delete(_VERTICAL_LINE_TAG)

        offset_x: int = 0
        column_index: int
        column: _Column
        for column_index, column in enumerate(self._iterate_visible_columns()):
            if column_index > 0:
                self._content_canvas.create_line(offset_x, 0, offset_x, content_height, width=_CONTENT_VERTICAL_LINE_WIDTH, fill=_COL_ROW_DIVIDER_LINE, tags=_VERTICAL_LINE_TAG)
                offset_x += _CONTENT_VERTICAL_LINE_WIDTH
            offset_x += column.current_width

    def _redraw_selection_bar(self, *, old_row: int | None, new_row: int | None) -> None:
        if self._selection_bar_id is not None:
            self._content_canvas.delete(self._selection_bar_id)
            self._selection_bar_id = None

        if old_row is not None and old_row in range(len(self._list_of_tease_matches.get())):
            self._remove_row(old_row)
            self._draw_row(old_row)

        if new_row is not None and new_row in range(len(self._list_of_tease_matches.get())):
            display_bounds: Bounds = Bounds(0, 0, self._content_canvas.winfo_width(), self._content_canvas.winfo_height())
            max_bounds: Bounds = Bounds.union(self._content_bounds, display_bounds)
            top: int = new_row * self._row_height
            bottom: int = top + self._row_height - _CONTENT_HORIZONTAL_LINE_HEIGHT - 1
            self._selection_bar_id = self._content_canvas.create_rectangle(max_bounds.left, top, max_bounds.right - 1, bottom, fill=_COL_SELECTED_ROW_BACK)
            self._content_canvas.tag_lower(self._selection_bar_id, tk.ALL)
            self._remove_row(new_row)
            self._draw_row(new_row)

def _get_scroll_direction_from_event(event: tk.Event) -> int:
    if event.num == _LINUX_AND_OSX_MOUSEWHEEL_UP_BUTTON or event.delta < 0:
        return 1
    if event.num == _LINUX_AND_OSX_MOUSEWHEEL_DOWN_BUTTON or event.delta > 0:
        return -1
    return 0
