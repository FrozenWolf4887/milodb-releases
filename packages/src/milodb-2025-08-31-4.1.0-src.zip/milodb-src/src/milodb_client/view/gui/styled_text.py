# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import tkinter as tk
from typing import Literal
from milodb_client.view.gui import general_style, tk_type
from milodb_client.view.gui.theme import apply_text_style

class StyledText(tk.Text):
    def __init__(
            self, master: tk.Misc,
            style: str = general_style.TEXT,
            *,
            autoseparators: bool = True,
            endline: int | Literal[''] = '',
            exportselection: bool = True,
            height: tk_type.ScreenUnits = 24,
            maxundo: int = 0,
            name: str = '',
            setgrid: bool = False,
            startline: int | Literal[''] = '',
            state: Literal['normal', 'disabled'] = tk.NORMAL,
            tabs: tk_type.ScreenUnits | tuple[tk_type.ScreenUnits, ...] = '',
            tabstyle: Literal['tabular', 'wordprocessor'] = 'tabular',
            takefocus: tk_type.TakeFocusValue = '',
            undo: bool = False,
            width: int = 80,
            wrap: Literal['none', 'char', 'word'] = tk.CHAR,
            xscrollcommand: tk_type.XYScrollCommand = '',
            yscrollcommand: tk_type.XYScrollCommand = '',
        ) -> None:
        super().__init__(
            master,
            autoseparators = autoseparators,
            endline = endline,
            exportselection = exportselection,
            height = height,
            maxundo = maxundo,
            name = name,
            setgrid = setgrid,
            startline = startline,
            state = state,
            tabs = tabs,
            tabstyle = tabstyle,
            takefocus = takefocus,
            undo = undo,
            width = width,
            wrap = wrap,
            xscrollcommand = xscrollcommand,
            yscrollcommand = yscrollcommand,
        )

        self._style_name: str = style
        self._change_theme_event_id: str | None = None

        apply_text_style(self, self._style_name)
        self.bind('<<ThemeChanged>>', self._on_theme_changed)

    def _on_theme_changed(self, _event: object) -> None:
        if self._change_theme_event_id is None:
            self._change_theme_event_id = self.after_idle(self._on_idle_update_theme)

    def _on_idle_update_theme(self) -> None:
        self._change_theme_event_id = None
        apply_text_style(self, self._style_name)
