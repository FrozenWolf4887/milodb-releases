# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import tkinter as tk
from typing import TYPE_CHECKING
from milodb_client.view.gui import general_style, tk_type
from milodb_client.view.gui.scrollable_canvas import ScrollableCanvas
from milodb_client.view.gui.styled_frame import StyledFrame
from milodb_common.view.gui.metrics import Size
if TYPE_CHECKING:
    from milodb_client.view.gui.widget_id import WidgetId

class ScrollableFrame:
    def __init__(self, master: tk.Misc,
            frame_style: str = general_style.FRAME,
            *,
            height: tk_type.ScreenUnits = 0,
            width: tk_type.ScreenUnits = 0,
        ) -> None:
        self._scrollable_canvas: ScrollableCanvas = ScrollableCanvas(master, self._on_canvas_resized)
        self._frame: StyledFrame = StyledFrame(self._scrollable_canvas.canvas, frame_style, height=height, width=width)
        self._window: WidgetId = self._scrollable_canvas.canvas.create_window(0, 0, window=self._frame, anchor=tk.NW)
        self._current_canvas_width: int = 0
        self._current_frame_height: int = 0

        self._frame.bindtags((str(self._frame), str(self._scrollable_canvas.canvas), tk.ALL))
        self._frame.bind('<Configure>', self._on_frame_changed)

    @property
    def top_frame(self) -> StyledFrame:
        return self._scrollable_canvas

    @property
    def content_frame(self) -> StyledFrame:
        return self._frame

    def set_child_bindtags_for_scrolling(self) -> None:
        canvas_name: str = str(self._scrollable_canvas.canvas)
        widget: tk.Widget
        for widget in self._frame.children.values():
            widget.bindtags((str(widget), widget.winfo_class(), canvas_name, tk.ALL))

    def reset_scroll(self) -> None:
        self._scrollable_canvas.reset_scroll()

    def _on_canvas_resized(self, size: Size) -> None:
        if size.width != self._current_canvas_width:
            self._current_canvas_width = size.width
            self._scrollable_canvas.canvas.itemconfigure(self._window, width=size.width)

    def _on_frame_changed(self, _event: object) -> None:
        bbox: tuple[int, int, int, int] | None = self._frame.grid_bbox()
        if bbox is not None:
            height: int = bbox[3]
            if height != self._current_frame_height:
                self._current_frame_height = height
                self._scrollable_canvas.set_content_height(height)
