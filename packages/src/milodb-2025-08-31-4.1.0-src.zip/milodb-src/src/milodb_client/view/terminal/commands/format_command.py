# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from collections.abc import Iterable
from typing import override
from milodb_client.output.format.i_formatter_factory import IFormatterCreator, IFormatterFactory
from milodb_common.output.print.i_printer import IPrinter
from milodb_common.parser import arg
from milodb_common.parser.arg_token_stream import ArgTokenStream
from milodb_common.parser.candidate_text import CandidateText
from milodb_common.util.ref import IRef
from milodb_common.view.terminal.command_framework.i_command import CommandLoaderResult
from milodb_common.view.terminal.command_framework.i_help_info import IHelpInfo

def load(arg_token_stream: ArgTokenStream, ref_formatter_creator: IRef[IFormatterCreator], formatter_factory: IFormatterFactory, normal_printer: IPrinter) -> CommandLoaderResult:
    new_formatter_creator: IFormatterCreator | None = arg.pop_optional(arg_token_stream, arg.DictValue(formatter_factory.map_of_name_to_formatter_creator, 'formatter'))
    if new_formatter_creator is not None:
        arg.fail_if_not_empty(arg_token_stream)
        return CommandLoaderResult(
            lambda: execute_change(new_formatter_creator, ref_formatter_creator, normal_printer),
            [],
        )
    return CommandLoaderResult(
        lambda: execute_print(ref_formatter_creator.get().get_name(), formatter_factory.get_list_of_formatter_names(), normal_printer),
        CandidateText.space_delimited_list(formatter_factory.get_list_of_formatter_names()),
    )

def execute_print(current_formatter_name: str, list_of_formatter_names: Iterable[str], normal_printer: IPrinter) -> None:
    normal_printer.writeln(f"Current format is '{current_formatter_name}'")
    normal_printer.writeln(f"Available formats are {list_of_formatter_names}")

def execute_change(new_formatter_creator: IFormatterCreator, ref_formatter_creator: IRef[IFormatterCreator], normal_printer: IPrinter) -> None:
    ref_formatter_creator.set(new_formatter_creator)
    normal_printer.writeln(f"Changed format to '{new_formatter_creator.get_name()}'")

class Help(IHelpInfo):
    def __init__(self, list_of_formatter_names: Iterable[str]) -> None:
        self._list_of_formatter_names: Iterable[str] = list_of_formatter_names

    @override
    def get_one_line_summary(self) -> str:
        return "Sets the formatting used in the output of commands"

    @override
    def get_detailed_summary(self) -> str:
        return (
            f"Arguments: [{'|'.join(self._list_of_formatter_names)}]\n"
            "Changes the output format that is produced by commands such as list, summary,"
            " and show. Some of the formats are more suitable for copy-pasting into another"
            " application that supports that format; 'bbcode' for example is suitable to be"
            " pasted into the Milovana forums.\n"
            "When used without arguments, the current setting is shown.\n"
            "Example:\r"
            "  \tSelect the bbcode output format\r"
            "  > \tformat bbcode\r"
            "Example:\r"
            "  \tShow the current setting\r"
            "  > \tformat\n"
            "See also:\r"
            "  \tlist, summary, show, ellipsis, highlight\n"
        )
