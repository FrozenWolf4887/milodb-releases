# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from collections.abc import Callable, Mapping, Sequence
from typing import override
from milodb_client.database.tease import Tease
from milodb_client.util.database_stats import DatabaseStats, TotmStats
from milodb_common.output.print.i_printer import IPrinter
from milodb_common.parser import arg
from milodb_common.parser.arg_token_stream import ArgTokenStream
from milodb_common.parser.candidate_text import CandidateText
from milodb_common.view.terminal.command_framework.i_command import CommandLoaderResult
from milodb_common.view.terminal.command_framework.i_help_info import IHelpInfo

def load(arg_token_stream: ArgTokenStream, database_stats: DatabaseStats, normal_printer: IPrinter) -> CommandLoaderResult:
    stats_delegate: Callable[[DatabaseStats, IPrinter], None] | None = arg.pop_optional(arg_token_stream, arg.DictValue(_MAP_OF_CHOICES_TO_DELEGATE, 'type of stat'))
    if stats_delegate:
        arg.fail_if_not_empty(arg_token_stream)
        return CommandLoaderResult(
            lambda: stats_delegate(database_stats, normal_printer),
            [],
        )
    return CommandLoaderResult(
        lambda: execute_display_general(database_stats, normal_printer),
        CandidateText.space_delimited_list(_MAP_OF_CHOICES_TO_DELEGATE.keys()),
    )

def execute_display_general(database_stats: DatabaseStats, normal_printer: IPrinter) -> None:
    normal_printer.writeln(f'{database_stats.number_of_teases:>12,}  teases')
    normal_printer.writeln(f'{database_stats.count_of_deleted_teases:>12,}  deleted teases')
    normal_printer.writeln(f'{database_stats.count_of_missing_authors:>12,}  teases by unknown authors')
    normal_printer.writeln(f'{database_stats.newest_tease_date.isoformat() if database_stats.newest_tease_date else "unknown":>12}  newest tease')
    normal_printer.writeln(f'{database_stats.oldest_tease_date.isoformat() if database_stats.oldest_tease_date else "unknown":>12}  oldest tease')
    normal_printer.writeln(f'{len(database_stats.map_of_author_to_tease_count.keys()):>12,}  authors')
    normal_printer.writeln(f'{len(database_stats.map_of_tag_to_occurrence_count.keys()):>12,}  unique tags')
    normal_printer.writeln(f'{database_stats.count_of_totm_winners:>12,}  TOTM winners')
    normal_printer.writeln(f'{database_stats.count_of_totm_nominees:>12,}  TOTM nominees')
    normal_printer.writeln(f'{database_stats.total_count_of_words:>12,}  total content words')

def execute_display_tags(database_stats: DatabaseStats, normal_printer: IPrinter) -> None:
    normal_printer.writeln('Top occurrences of tags:')
    sorted_list_of_tags_and_occurrence_count: Sequence[tuple[str, int]] = sorted(database_stats.map_of_tag_to_occurrence_count.items(), key=lambda x: x[1], reverse=True)
    tag: str
    count: int
    for tag, count in sorted_list_of_tags_and_occurrence_count[:20]:
        normal_printer.writeln(f'{count:>8,}  {tag}')

def execute_display_authors(database_stats: DatabaseStats, normal_printer: IPrinter) -> None:
    normal_printer.writeln('Top number of teases by author:')
    sorted_list_of_authors_and_tease_count: Sequence[tuple[str, int]] = sorted(database_stats.map_of_author_to_tease_count.items(), key=lambda x: x[1], reverse=True)
    author: str
    tease_count: int
    for author, tease_count in sorted_list_of_authors_and_tease_count[:20]:
        normal_printer.writeln(f'{tease_count:>8,}  {author}')

    normal_printer.writeln('\nTop TOTM awards by author:')
    sorted_list_of_authors_and_totm_stats: Sequence[tuple[str, TotmStats]] = sorted(database_stats.map_of_author_to_totm_stats.items(), key=lambda x: (x[1].wins, x[1].nominations), reverse=True)
    totm_stats: TotmStats
    for author, totm_stats in sorted_list_of_authors_and_totm_stats[:20]:
        normal_printer.writeln(f'{totm_stats.wins:>6,} wins  {totm_stats.nominations:>4,} nominations  {author}')

def execute_display_content(database_stats: DatabaseStats, normal_printer: IPrinter) -> None:
    normal_printer.writeln('Top word count by tease:')
    sorted_list_of_teases: Sequence[Tease] = sorted(database_stats.list_of_teases, key=lambda tease: tease.get_word_count(), reverse=True)
    for tease in sorted_list_of_teases[:20]:
        tease_id_text: str = '#' + str(tease.get_tease_id())
        normal_printer.writeln(f'{tease.get_word_count():>12,}  {tease_id_text:>7}  {tease.get_title()} : [{_get_author_text(tease)}]')

    normal_printer.writeln('\nTop word count by author:')
    sorted_list_of_authors_and_word_count: Sequence[tuple[str, int]] = sorted(database_stats.map_of_author_to_word_count.items(), key=lambda x: x[1], reverse=True)
    author: str
    word_count: int
    for author, word_count in sorted_list_of_authors_and_word_count[:20]:
        normal_printer.writeln(f'{word_count:>12,}  {author}')

def execute_display_images(database_stats: DatabaseStats, normal_printer: IPrinter) -> None:
    normal_printer.writeln('Top count of unique images by tease:')
    tease: Tease
    for tease in database_stats.list_of_teases_by_decreasing_image_count[:20]:
        tease_id_text: str = '#' + str(tease.get_tease_id())
        normal_printer.writeln(f'{tease.get_count_of_unique_images():>11,}  {tease_id_text:>7}  {tease.get_title()} : [{_get_author_text(tease)}]')

def execute_display_audio(database_stats: DatabaseStats, normal_printer: IPrinter) -> None:
    normal_printer.writeln('Top count of unique audio by tease:')
    tease: Tease
    for tease in database_stats.list_of_teases_by_decreasing_audio_count[:20]:
        tease_id_text: str = '#' + str(tease.get_tease_id())
        normal_printer.writeln(f'{tease.get_count_of_unique_audio():>11,}  {tease_id_text:>7}  {tease.get_title()} : [{_get_author_text(tease)}]')

_MAP_OF_CHOICES_TO_DELEGATE: Mapping[str, Callable[[DatabaseStats, IPrinter], None]] = {
    'tags': execute_display_tags,
    'authors': execute_display_authors,
    'content': execute_display_content,
    'images': execute_display_images,
    'audio': execute_display_audio,
}

class Help(IHelpInfo):
    @override
    def get_one_line_summary(self) -> str:
        return "Show some database related statistics (just for fun)"

    @override
    def get_detailed_summary(self) -> str:
        return (
            f"Arguments: [{'|'.join(list(_MAP_OF_CHOICES_TO_DELEGATE))}]\n"
            "When used without arguments, general statistics are shown.\n"
            "Note that the tags associated with each tease are known to be an incomplete list, therefore"
            " the statistics are probably not very accurate. The number of words found in a tease doesn't"
            " include all of the cleverness of page navigation, scripting, etc.; the words themselves"
            " are counted by finding stuff separated by whitespace. Deleted teases do not contribute to"
            " the statistics.\n"
            "Example:\r"
            "  \tDisplay some general statistics\r"
            "  > \tstats\r"
            "Example:\r"
            "  \tDisplay statistics for content\r"
            "  > \tstats content\r"
        )

def _get_author_text(tease: Tease) -> str:
    if tease.author.has_author:
        return f"{tease.author.name}, @{tease.author.author_id}"
    return 'unknown author'
