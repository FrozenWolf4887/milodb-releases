# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from __future__ import annotations
import sys
from typing import TYPE_CHECKING, override
from milodb_client.config.config_schema import CONFIG_SCHEMA
from milodb_client.view.terminal.commands import update_command
from milodb_common.parser import arg
from milodb_common.view.terminal.command_framework.i_command import CommandLoaderResult
from milodb_common.view.terminal.command_framework.i_help_info import IHelpInfo
if TYPE_CHECKING:
    from milodb_client.config.update_config import UpdateConfig
    from milodb_client.startup.shutdown_action import IShutdownAction
    from milodb_client.updater.i_file_hasher import IFileHasher
    from milodb_client.updater.i_file_tester import IFileTester
    from milodb_client.updater.i_temp_directory import ITempDirectoryCreator
    from milodb_client.updater.manifest.local_manifest import ILocalManifest
    from milodb_common.internet.i_scraper import IUrlScraperFactory
    from milodb_common.output.print.i_printer import IPrinter
    from milodb_common.parser.arg_token_stream import ArgTokenStream
    from milodb_common.util.ref import IRef
    from milodb_common.view.terminal.command_framework.quit_flag import QuitFlag

_CONFIG_HELP_TEXT: str = (
    "Config:\r"
    f"  \t'{CONFIG_SCHEMA.update.backup_directory.full_path}'\r"
    "    \tDirectory in which to store a backup of the existing application and configuration files"
    f" before performing the upgrade.\r"
    f"  \t'{CONFIG_SCHEMA.update.update_directory_url.full_path}'\r"
    f"    \tThe remote server URL hosting the upgrade metadata and assets.\n"
)

def load(arg_token_stream: ArgTokenStream, local_manifest: ILocalManifest | None, update_config: UpdateConfig, file_hasher: IFileHasher, file_tester: IFileTester, temp_directory_creator: ITempDirectoryCreator, url_scraper_factory: IUrlScraperFactory, quit_flag: QuitFlag, ref_shutdown_action: IRef[IShutdownAction | None], normal_printer: IPrinter, warning_printer: IPrinter, error_printer: IPrinter) -> CommandLoaderResult:
    arg.fail_if_not_empty(arg_token_stream)

    is_windows: bool = sys.platform == 'win32'
    target_variant_name: str = 'gui-windows' if is_windows else 'gui-linux'

    return CommandLoaderResult(
        lambda: update_command.execute_update(
            local_manifest,
            update_config,
            file_hasher,
            file_tester,
            temp_directory_creator,
            url_scraper_factory,
            quit_flag,
            ref_shutdown_action,
            normal_printer,
            warning_printer,
            error_printer,
            variant_name = target_variant_name,
        ),
        [],
    )

class Help(IHelpInfo):
    @override
    def get_one_line_summary(self) -> str:
        return "Upgrades from the MiloDB 'terminal' variant to the 'graphical' variant"

    @override
    def get_detailed_summary(self) -> str:
        return (
            "Arguments: None\n"
            "Before attempting the upgrade, the existing files are backed up. The assets for new and"
            " upgraded files are stored in a temporary directory that is automatically removed after a"
            " successful upgrade.\n"
            f"{_CONFIG_HELP_TEXT}"
            "Example:\r"
            "  \tPerform the upgrade\r"
            "  > \tgui-upgrade\r"
        )
