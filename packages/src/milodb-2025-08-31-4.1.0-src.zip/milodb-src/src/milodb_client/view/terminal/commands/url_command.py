# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from collections.abc import Iterable
from typing import override
from milodb_client.database.tease import Tease
from milodb_client.query.tease_match import TeaseMatch
from milodb_client.view.terminal.commands.database_support import try_get_tease_id_from_ref_id
from milodb_common.output.print.i_printer import IPrinter
from milodb_common.parser import arg
from milodb_common.parser.arg_token_stream import ArgTokenStream
from milodb_common.parser.ref_id import AuthorId, RefId
from milodb_common.util.get_url import get_url_of_author, get_url_of_tease
from milodb_common.view.terminal.command_framework.i_command import CommandLoaderResult
from milodb_common.view.terminal.command_framework.i_help_info import IHelpInfo

def load(arg_token_stream: ArgTokenStream, list_of_teases: Iterable[Tease], list_of_tease_matches: Iterable[TeaseMatch], normal_printer: IPrinter, error_printer: IPrinter) -> CommandLoaderResult:
    list_of_ref_ids: Iterable[RefId] = arg.pop_minimum_list(arg_token_stream, 1, arg.REF_ID)
    return CommandLoaderResult(
        lambda: execute(list_of_ref_ids, list_of_teases, list_of_tease_matches, normal_printer, error_printer),
        [],
    )

def execute(list_of_ref_ids: Iterable[RefId], list_of_teases: Iterable[Tease], list_of_tease_matches: Iterable[TeaseMatch], normal_printer: IPrinter, error_printer: IPrinter) -> None:
    ref_id: RefId
    for ref_id in list_of_ref_ids:
        if isinstance(ref_id, AuthorId):
            author_url: str = get_url_of_author(ref_id.author_id)
            normal_printer.writeln(author_url)
        else:
            tease_match: TeaseMatch | None = try_get_tease_id_from_ref_id(list_of_teases, list_of_tease_matches, ref_id, error_printer)
            if tease_match:
                tease_url: str = get_url_of_tease(tease_match.tease.get_tease_id())
                normal_printer.writeln(tease_url)

class Help(IHelpInfo):
    @override
    def get_one_line_summary(self) -> str:
        return "Displays the URL of some specified teases or author profiles"

    @override
    def get_detailed_summary(self) -> str:
        return (
            "Arguments: <list of RefIds>\n"
            "This command is often used with the copy command to copy the displayed URL to"
            " the clipboard.\n"
            "RefIds can be an index into the list of matches such as '3', a teaseId such as"
            " '#38664', or an authorId such as '@43937'.\n"
            "Example:\r"
            "  \tDisplay the URL of a tease by index in the match list\r"
            "  > \turl 3\r"
            "Example:\r"
            "  \tDisplay the URL of a tease by its specific teaseId\r"
            "  > \turl #16830\r"
            "Example:\r"
            "  \tDisplay the URL of an author's profile by specific authorId\r"
            "  > \turl @43937\n"
            "See also:\r"
            "  \tcopy, urlauthor, open, openauthor\n"
        )
