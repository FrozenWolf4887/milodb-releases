# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import datetime
from collections.abc import Callable, Iterable, Mapping, Sequence
from dataclasses import dataclass
from typing import override
from milodb_client.database.tease import Tease, TeaseType
from milodb_common.output.print.i_printer import IPrinter
from milodb_common.parser import arg
from milodb_common.parser.arg_token_stream import ArgTokenStream
from milodb_common.view.terminal.command_framework.i_command import CommandLoaderResult
from milodb_common.view.terminal.command_framework.i_help_info import IHelpInfo

def load(arg_token_stream: ArgTokenStream, list_of_teases: Sequence[Tease], normal_printer: IPrinter) -> CommandLoaderResult:
    chart_delegate: Callable[[Sequence[Tease], IPrinter], None] = arg.pop(arg_token_stream, arg.DictValue(_MAP_OF_CHOICES_TO_DELEGATE, 'type of stat'))
    arg.fail_if_not_empty(arg_token_stream)
    return CommandLoaderResult(
        lambda: chart_delegate(list_of_teases, normal_printer),
        [],
    )

def execute_tease_type_per_month(list_of_teases: Iterable[Tease], normal_printer: IPrinter) -> None:
    columns: _TeaseTypeValueColumns = _build_columns_of_stats_by_tease_value(
        list_of_teases,
        call_date_to_text = lambda date: f'{date.year}-{date.month:02}',
        call_update_tease_value = lambda _, counter: counter.increment(),
    )

    normal_printer.write('date,')
    for tease_type in columns.map_of_tease_type_to_value_column:
        normal_printer.write(f'{tease_type.value},')
    normal_printer.writeln()

    index: int
    date_text: str
    for index, date_text in enumerate(columns.date):
        normal_printer.write(f'{date_text},')
        type_count_column: list[int]
        for type_count_column in columns.map_of_tease_type_to_value_column.values():
            normal_printer.write(f'{type_count_column[index]},')
        normal_printer.writeln()

def execute_tease_type_per_quarter(list_of_teases: Iterable[Tease], normal_printer: IPrinter) -> None:
    columns: _TeaseTypeValueColumns = _build_columns_of_stats_by_tease_value(
        list_of_teases,
        call_date_to_text = lambda date: f'{date.year}-Q{1+(date.month-1)//3}',
        call_update_tease_value = lambda _, counter: counter.increment(),
    )

    normal_printer.write('date,')
    for tease_type in columns.map_of_tease_type_to_value_column:
        normal_printer.write(f'{tease_type.value},')
    normal_printer.writeln()

    index: int
    date_text: str
    for index, date_text in enumerate(columns.date):
        normal_printer.write(f'{date_text},')
        type_count_column: list[int]
        for type_count_column in columns.map_of_tease_type_to_value_column.values():
            normal_printer.write(f'{type_count_column[index]},')
        normal_printer.writeln()

def execute_total_teases_per_month(list_of_teases: Iterable[Tease], normal_printer: IPrinter) -> None:
    columns: _TeaseTypeValueColumns = _build_columns_of_stats_by_tease_value(
        list_of_teases,
        call_date_to_text = lambda date: f'{date.year}-{date.month:02}',
        call_update_tease_value = lambda _, counter: counter.increment(),
    )

    normal_printer.writeln('date,total')

    index: int
    date_text: str
    for index, date_text in enumerate(columns.date):
        normal_printer.write(f'{date_text},')
        total: int = sum(type_count_column[index] for type_count_column in columns.map_of_tease_type_to_value_column.values())
        normal_printer.writeln(f'{total},')

def execute_total_teases_per_quarter(list_of_teases: Iterable[Tease], normal_printer: IPrinter) -> None:
    columns: _TeaseTypeValueColumns = _build_columns_of_stats_by_tease_value(
        list_of_teases,
        call_date_to_text = lambda date: f'{date.year}-Q{1+(date.month-1)//3}',
        call_update_tease_value = lambda _, counter: counter.increment(),
    )

    normal_printer.writeln('date,total')

    index: int
    date_text: str
    for index, date_text in enumerate(columns.date):
        normal_printer.write(f'{date_text},')
        total: int = sum(type_count_column[index] for type_count_column in columns.map_of_tease_type_to_value_column.values())
        normal_printer.writeln(f'{total},')

def execute_total_words_per_month(list_of_teases: Iterable[Tease], normal_printer: IPrinter) -> None:
    columns: _TeaseTypeValueColumns = _build_columns_of_stats_by_tease_value(
        list_of_teases,
        call_date_to_text = lambda date: f'{date.year}-{date.month:02}',
        call_update_tease_value = lambda tease, counter: counter.add(tease.get_word_count()),
    )

    normal_printer.writeln('date,total')

    index: int
    date_text: str
    for index, date_text in enumerate(columns.date):
        normal_printer.write(f'{date_text},')
        total: int = sum(type_count_column[index] for type_count_column in columns.map_of_tease_type_to_value_column.values())
        normal_printer.writeln(f'{total},')

def execute_total_words_per_quarter(list_of_teases: Iterable[Tease], normal_printer: IPrinter) -> None:
    columns: _TeaseTypeValueColumns = _build_columns_of_stats_by_tease_value(
        list_of_teases,
        call_date_to_text = lambda date: f'{date.year}-Q{1+(date.month-1)//3}',
        call_update_tease_value = lambda tease, counter: counter.add(tease.get_word_count()),
    )

    normal_printer.writeln('date,total')

    index: int
    date_text: str
    for index, date_text in enumerate(columns.date):
        normal_printer.write(f'{date_text},')
        total: int = sum(type_count_column[index] for type_count_column in columns.map_of_tease_type_to_value_column.values())
        normal_printer.writeln(f'{total},')

_MAP_OF_CHOICES_TO_DELEGATE: Mapping[str, Callable[[Sequence[Tease], IPrinter], None]] = {
    'tease-type-per-month': execute_tease_type_per_month,
    'tease-type-per-quarter': execute_tease_type_per_month,
    'total-teases-per-month': execute_total_teases_per_month,
    'total-teases-per-quarter': execute_total_teases_per_quarter,
    'total-words-per-month': execute_total_words_per_month,
    'total-words-per-quarter': execute_total_words_per_quarter,
}

class _Counter:
    def __init__(self) -> None:
        self._count: int = 0

    def increment(self) -> None:
        self._count += 1

    def add(self, value: int) -> None:
        self._count += value

    @property
    def value(self) -> int:
        return self._count

@dataclass(kw_only=True)
class _TeaseTypeValueColumns:
    date: list[str]
    map_of_tease_type_to_value_column: dict[TeaseType, list[int]]

def _build_columns_of_stats_by_tease_value(list_of_teases: Iterable[Tease], *, call_date_to_text: Callable[[datetime.date], str], call_update_tease_value: Callable[[Tease, _Counter], None]) -> _TeaseTypeValueColumns:
    map_of_time_to_tease_value: dict[str, dict[TeaseType, _Counter]] = {}

    tease: Tease
    for tease in list_of_teases:
        tease_time_text: str = call_date_to_text(tease.get_date())
        call_update_tease_value(tease, map_of_time_to_tease_value.setdefault(tease_time_text, {}).setdefault(tease.get_type(), _Counter()))

    columns: _TeaseTypeValueColumns = _TeaseTypeValueColumns(
        date = [],
        map_of_tease_type_to_value_column = {
            tease_type: [] for tease_type in TeaseType
        },
    )

    for tease_time_text in sorted(map_of_time_to_tease_value):
        columns.date.append(tease_time_text)
        tease_type_count: dict[TeaseType, _Counter] = map_of_time_to_tease_value[tease_time_text]
        tease_type: TeaseType
        for tease_type in TeaseType:
            count: int = tease_type_count.get(tease_type, _Counter()).value
            columns.map_of_tease_type_to_value_column[tease_type].append(count)

    return columns

class Help(IHelpInfo):
    @override
    def get_one_line_summary(self) -> str:
        return "Creates CSV database statistics for spreadsheet charts (just for fun)"

    @override
    def get_detailed_summary(self) -> str:
        return (
            f"Arguments: {'|'.join(list(_MAP_OF_CHOICES_TO_DELEGATE))}\n"
            "When used without arguments, general statistics are shown.\n"
            "Note that the tags associated with each tease are known to be an incomplete list, therefore"
            " the statistics are probably not very accurate. The number of words found in a tease doesn't"
            " include all of the cleverness of page navigation, scripting, etc.; the words themselves"
            " are counted by finding stuff separated by whitespace. Deleted teases do not contribute to"
            " the statistics.\n"
            "Example:\r"
            "  \tGenerate data for teases published by type per month\r"
            "  > \tcharts tease-type-per-month\r"
        )
