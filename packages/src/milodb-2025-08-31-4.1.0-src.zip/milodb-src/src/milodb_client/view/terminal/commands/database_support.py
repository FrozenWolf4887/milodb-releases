# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from collections.abc import Iterable, Sequence
from milodb_client.database.database import get_teases_by_author_id, try_get_tease
from milodb_client.database.tease import Tease
from milodb_client.query.tease_match import TeaseMatch
from milodb_common.output.print.i_printer import IPrinter
from milodb_common.parser.ref_id import MatchIndex, RefId, TeaseId

def try_create_list_of_tease_matches_from_ref_ids(list_of_teases: Iterable[Tease], list_of_tease_matches: Iterable[TeaseMatch], list_of_ref_ids: Iterable[RefId], error_printer: IPrinter) -> Sequence[TeaseMatch] | None:
    subset_of_tease_matches: list[TeaseMatch] = []
    any_fault: bool = False
    tease_match: TeaseMatch | None = None
    ref_id: RefId
    for ref_id in list_of_ref_ids:
        if isinstance(ref_id, MatchIndex):
            tease_match = _try_find_tease_by_match_index(list_of_tease_matches, ref_id.match_index)
            if tease_match:
                subset_of_tease_matches.append(tease_match)
            else:
                error_printer.writeln(f"Match index '{ref_id.match_index}' is out of range")
                any_fault = True
        elif isinstance(ref_id, TeaseId):
            tease_match = _try_find_tease_by_tease_id(list_of_teases, list_of_tease_matches, ref_id.tease_id)
            if tease_match:
                subset_of_tease_matches.append(tease_match)
            else:
                error_printer.writeln(f"Unable to find tease for tease id '{ref_id.tease_id}'")
                any_fault = True
        else:
            author_tease_matches: Sequence[TeaseMatch] = _find_teases_by_author_id(list_of_teases, list_of_tease_matches, ref_id.author_id)
            if author_tease_matches:
                subset_of_tease_matches.extend(author_tease_matches)
            else:
                error_printer.writeln(f"Unable to find author id '{ref_id.author_id}'")
                any_fault = True

    return subset_of_tease_matches if not any_fault else None

def try_get_tease_id_from_ref_id(list_of_teases: Iterable[Tease], list_of_tease_matches: Iterable[TeaseMatch], ref_id: RefId, error_printer: IPrinter) -> TeaseMatch | None:
    tease_match: TeaseMatch | None = None

    if isinstance(ref_id, MatchIndex):
        tease_match = _try_find_tease_by_match_index(list_of_tease_matches, ref_id.match_index)
        if not tease_match:
            error_printer.writeln(f"Match index '{ref_id.match_index}' is out of range")
    elif isinstance(ref_id, TeaseId):
        tease_match = _try_find_tease_by_tease_id(list_of_teases, list_of_tease_matches, ref_id.tease_id)
        if not tease_match:
            error_printer.writeln(f"Unable to find tease for tease id '{ref_id.tease_id}'")

    return tease_match

def _try_find_tease_by_match_index(list_of_tease_matches: Iterable[TeaseMatch], match_index: int) -> TeaseMatch | None:
    if list_of_tease_matches:
        for tease_match in list_of_tease_matches:
            if tease_match.index_of_match == match_index:
                return tease_match
    return None

def _try_find_tease_by_tease_id(list_of_teases: Iterable[Tease], list_of_tease_matches: Iterable[TeaseMatch], tease_id: int) -> TeaseMatch | None:
    tease_match: TeaseMatch | None = None

    if list_of_tease_matches:
        search_tease_match: TeaseMatch
        for search_tease_match in list_of_tease_matches:
            if search_tease_match.tease.get_tease_id() == tease_id:
                tease_match = search_tease_match
                break

    if not tease_match:
        tease: Tease | None = try_get_tease(tease_id, list_of_teases)
        if tease:
            tease_match = TeaseMatch(None, tease, [])

    return tease_match

def _find_teases_by_author_id(list_of_teases: Iterable[Tease], list_of_tease_matches: Iterable[TeaseMatch], author_id: int) -> Sequence[TeaseMatch]:
    subset_of_tease_matches: list[TeaseMatch] = [
        tease_match for tease_match in list_of_tease_matches if tease_match.tease.author.author_id == author_id
    ]

    list_of_all_author_teases: Iterable[Tease] = get_teases_by_author_id(author_id, list_of_teases)
    tease: Tease
    for tease in list_of_all_author_teases:
        is_already_captured: bool = False
        for tease_match in list_of_tease_matches:
            if tease_match.tease.get_tease_id() == tease.get_tease_id():
                is_already_captured = True
                break
        if not is_already_captured:
            subset_of_tease_matches.append(TeaseMatch(None, tease, []))

    return subset_of_tease_matches
