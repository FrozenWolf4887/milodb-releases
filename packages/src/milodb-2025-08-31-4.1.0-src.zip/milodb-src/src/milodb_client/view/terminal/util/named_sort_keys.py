# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from collections.abc import Sequence
from typing import override
from milodb_client.query.tease_match import TeaseMatch
from milodb_client.util import sort_keys

class NamedSortKey(sort_keys.ISortKey):
    def __init__(self, name: str, sort_key: sort_keys.ISortKey, description: str) -> None:
        self._name: str = name
        self._sort_key: sort_keys.ISortKey = sort_key
        self._description: str = description

    @property
    def name(self) -> str:
        return self._name

    @property
    def description(self) -> str:
        return self._description

    @override
    def compare(self, left: TeaseMatch, right: TeaseMatch) -> sort_keys.SortCompareResult:
        return self._sort_key.compare(left, right)

class OrderedNamedSortKey(sort_keys.OrderedSortKey):
    def __init__(self, named_sort_key: NamedSortKey, *, is_ascending: bool) -> None:
        super().__init__(named_sort_key, is_ascending=is_ascending)
        self._named_sort_key: NamedSortKey = named_sort_key

    @property
    def named_sort_key(self) -> NamedSortKey:
        return self._named_sort_key

NAMED_TEASE_ID_SORT_KEY = NamedSortKey('teaseId', sort_keys.TEASE_ID_SORT_KEY, 'Numerical id of the tease')
NAMED_TEASE_STATUS_SORT_KEY = NamedSortKey('status', sort_keys.TEASE_STATUS_SORT_KEY, 'Status of the tease')
NAMED_AUTHOR_ID_SORT_KEY = NamedSortKey('authorId', sort_keys.AUTHOR_ID_SORT_KEY, 'Numerical id of the author')
NAMED_AUTHOR_NAME_SORT_KEY = NamedSortKey('author', sort_keys.AUTHOR_NAME_SORT_KEY, 'Name of the author')
NAMED_AUTHOR_STATUS_SORT_KEY = NamedSortKey('authorStatus', sort_keys.AUTHOR_STATUS_SORT_KEY, 'Status of the author')
NAMED_DATE_SORT_KEY = NamedSortKey('date', sort_keys.DATE_SORT_KEY, 'Published date of the tease')
NAMED_TITLE_SORT_KEY = NamedSortKey('title', sort_keys.TITLE_SORT_KEY, 'Title of the tease')
NAMED_RATING_SORT_KEY = NamedSortKey('rating', sort_keys.RATING_SORT_KEY, 'Value rating of the tease')
NAMED_TYPE_SORT_KEY = NamedSortKey('type', sort_keys.TYPE_SORT_KEY, 'EOS, regular, audio, etc. tease type')
NAMED_TOTM_SORT_KEY = NamedSortKey('totm', sort_keys.TOTM_SORT_KEY, 'Tease-Of-The-Month nominees and winners')
NAMED_MATCH_COUNT_SORT_KEY = NamedSortKey('hits', sort_keys.MATCH_COUNT_SORT_KEY, 'Number of tease field matches from the last query')
NAMED_WORDS_SORT_KEY = NamedSortKey('words', sort_keys.WORDS_SORT_KEY, 'Number of words in the tease')
NAMED_IMAGES_SORT_KEY = NamedSortKey('images', sort_keys.IMAGES_SORT_KEY, 'Number of images in the tease')
NAMED_UNIQUE_IMAGES_SORT_KEY = NamedSortKey('uniqueImages', sort_keys.UNIQUE_IMAGES_SORT_KEY, 'Number of unique images in the tease')
NAMED_AUDIO_SORT_KEY = NamedSortKey('audio', sort_keys.AUDIO_SORT_KEY, 'Number of audio files in the tease')
NAMED_UNIQUE_AUDIO_SORT_KEY = NamedSortKey('uniqueAudio', sort_keys.UNIQUE_AUDIO_SORT_KEY, 'Number of unique audio files in the tease')

LIST_OF_AVAILABLE_SORT_KEYS: Sequence[NamedSortKey] = [
    NAMED_TEASE_ID_SORT_KEY,
    NAMED_TEASE_STATUS_SORT_KEY,
    NAMED_AUTHOR_ID_SORT_KEY,
    NAMED_AUTHOR_NAME_SORT_KEY,
    NAMED_AUTHOR_STATUS_SORT_KEY,
    NAMED_DATE_SORT_KEY,
    NAMED_TITLE_SORT_KEY,
    NAMED_RATING_SORT_KEY,
    NAMED_TYPE_SORT_KEY,
    NAMED_TOTM_SORT_KEY,
    NAMED_MATCH_COUNT_SORT_KEY,
    NAMED_WORDS_SORT_KEY,
    NAMED_IMAGES_SORT_KEY,
    NAMED_UNIQUE_IMAGES_SORT_KEY,
    NAMED_AUDIO_SORT_KEY,
    NAMED_UNIQUE_AUDIO_SORT_KEY,
]
