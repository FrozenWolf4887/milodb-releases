# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from typing import override
from milodb_common.output.print.i_printer import IPrinter
from milodb_common.parser import arg
from milodb_common.parser.arg_token_stream import ArgTokenStream
from milodb_common.parser.candidate_text import CandidateText
from milodb_common.util import enums
from milodb_common.util.ref import IRef
from milodb_common.view.terminal.command_framework.i_command import CommandLoaderResult
from milodb_common.view.terminal.command_framework.i_help_info import IHelpInfo
from milodb_common.view.terminal.commands.enums import OnOrOff

def load(arg_token_stream: ArgTokenStream, ref_show_pagerefs: IRef[bool], normal_printer: IPrinter) -> CommandLoaderResult:
    new_show_pagerefs: OnOrOff | None = arg.pop_optional(arg_token_stream, arg.EnumFromName(OnOrOff))
    if new_show_pagerefs is not None:
        arg.fail_if_not_empty(arg_token_stream)
        return CommandLoaderResult(
            lambda: execute_change(new_show_pagerefs, ref_show_pagerefs, normal_printer),
            [],
        )
    return CommandLoaderResult(
        lambda: execute_print(normal_printer, show_pagerefs=ref_show_pagerefs.get()),
        CandidateText.space_delimited_list(enums.lowercase_names(OnOrOff)),
    )

def execute_print(normal_printer: IPrinter, *, show_pagerefs: bool) -> None:
    normal_printer.writeln(f"Current display of pagerefs is '{OnOrOff(show_pagerefs).name.lower()}'")
    normal_printer.writeln(f"Available options are {enums.lowercase_names(OnOrOff)}")

def execute_change(new_show_pagerefs: OnOrOff, ref_show_pagerefs: IRef[bool], normal_printer: IPrinter) -> None:
    ref_show_pagerefs.set(new_show_pagerefs.value)
    normal_printer.writeln(f"Changed display of pagerefs to '{new_show_pagerefs.name.lower()}'")

class Help(IHelpInfo):
    @override
    def get_one_line_summary(self) -> str:
        return "Sets whether page references are displayed with the text blocks"

    @override
    def get_detailed_summary(self) -> str:
        return (
            f"Arguments: [{'|'.join(enums.lowercase_names(OnOrOff))}]\n"
            "Page references can be shown alongside the text blocks if desired. This defaults"
            " to false because the page references can be a distraction.\n"
            "When used without arguments, the current setting is shown.\n"
            "Example:\r"
            "  \tTurn on page references\r"
            "  > \tpagerefs on\r"
            "Example:\r"
            "  \tShow the current setting\r"
            "  > \tpagerefs\n"
            "See also:\r"
            "  \tshow, browse, format, highlight, ellipsis\n"
        )
