# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from collections.abc import Callable, Sequence
from typing import override
from milodb_common.view.terminal.command_framework.i_command import CommandLoader
from milodb_common.view.terminal.command_framework.i_command_factory import ICommandFactory
from milodb_common.view.terminal.command_framework.i_help_info import IHelpInfo

class CommandFactory(ICommandFactory):
    def __init__(self) -> None:
        self._map_of_command_name_to_loader: dict[str, CommandLoader] = {}
        self._map_of_help_name_to_constructor: dict[str, Callable[[], IHelpInfo]] = {}

    def register_command(self, command_name: str, command_loader: CommandLoader, help_constructor: Callable[[], IHelpInfo]) -> None:
        self._map_of_command_name_to_loader[command_name] = command_loader
        self._map_of_help_name_to_constructor[command_name] = help_constructor

    @override
    def get_list_of_command_names(self) -> Sequence[str]:
        return list(self._map_of_command_name_to_loader)

    @override
    def try_get_command_loader_from_name(self, command_name: str) -> CommandLoader | None:
        loader: CommandLoader | None = self._map_of_command_name_to_loader.get(command_name)
        if loader:
            return loader
        return None

    @override
    def try_get_command_help_from_name(self, command_name: str) -> IHelpInfo | None:
        constructor: Callable[[], IHelpInfo] | None = self._map_of_help_name_to_constructor.get(command_name)
        if constructor:
            return constructor()
        return None
