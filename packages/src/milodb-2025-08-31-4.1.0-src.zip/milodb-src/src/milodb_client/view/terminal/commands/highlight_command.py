# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from typing import override
from milodb_common.output.print.i_printer import IPrinter
from milodb_common.parser import arg
from milodb_common.parser.arg_token_stream import ArgTokenStream
from milodb_common.parser.candidate_text import CandidateText
from milodb_common.util import enums
from milodb_common.util.ref import IRef
from milodb_common.view.terminal.command_framework.i_command import CommandLoaderResult
from milodb_common.view.terminal.command_framework.i_help_info import IHelpInfo
from milodb_common.view.terminal.commands.enums import OnOrOff

def load(arg_token_stream: ArgTokenStream, ref_use_highlighting: IRef[bool], normal_printer: IPrinter) -> CommandLoaderResult:
    new_use_highlighting: OnOrOff | None = arg.pop_optional(arg_token_stream, arg.EnumFromName(OnOrOff))
    if new_use_highlighting is not None:
        arg.fail_if_not_empty(arg_token_stream)
        return CommandLoaderResult(
            lambda: execute_change(new_use_highlighting, ref_use_highlighting, normal_printer),
            [],
        )
    return CommandLoaderResult(
        lambda: execute_print(normal_printer, use_highlighting=ref_use_highlighting.get()),
        CandidateText.space_delimited_list(enums.lowercase_names(OnOrOff)),
    )

def execute_print(normal_printer: IPrinter, *, use_highlighting: bool) -> None:
    normal_printer.writeln(f"Current highlighting is '{OnOrOff(use_highlighting).name.lower()}'")
    normal_printer.writeln(f"Available options are {enums.lowercase_names(OnOrOff)}")

def execute_change(new_use_highlighting: OnOrOff, ref_use_highlighting: IRef[bool], normal_printer: IPrinter) -> None:
    ref_use_highlighting.set(new_use_highlighting.value)
    normal_printer.writeln(f"Changed highlighting to '{new_use_highlighting.name.lower()}'")

class Help(IHelpInfo):
    @override
    def get_one_line_summary(self) -> str:
        return "Sets whether text matches are highlighted in the output"

    @override
    def get_detailed_summary(self) -> str:
        return (
            f"Arguments: [{'|'.join(enums.lowercase_names(OnOrOff))}]\n"
            "Enables or disables the highlighting of matching text in fields and paragraphs.\n"
            "When used without arguments, the current setting is shown.\n"
            "Highlighting will only be shown on the console when a suitable output format has"
            " been selected with the format command.\n"
            "Example:\r"
            "  \tTurn off highlighting\r"
            "  > \thighlight off\r"
            "Example:\r"
            "  \tShow the current setting\r"
            "  > \thighlight\n"
            "See also:\r"
            "  \tlist, show, browse, browseall, ellipsis, format, pagerefs\n"
        )
