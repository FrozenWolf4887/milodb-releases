# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from collections.abc import Callable, Iterable, Sequence
from typing import override
from milodb_client.database.tease import Tease
from milodb_client.output.format.i_formatter import IFormatter
from milodb_client.output.format.i_formatter_factory import IFormatterCreator
from milodb_client.query.tease_match import TeaseMatch
from milodb_client.view.terminal.commands.database_support import try_create_list_of_tease_matches_from_ref_ids
from milodb_common.output.print.i_printer import IPrinter
from milodb_common.parser import arg
from milodb_common.parser.arg_token_stream import ArgTokenStream
from milodb_common.parser.ref_id import RefId
from milodb_common.view.terminal.command_framework.i_command import CommandLoaderResult
from milodb_common.view.terminal.command_framework.i_help_info import IHelpInfo

def load(arg_token_stream: ArgTokenStream, list_of_teases: Iterable[Tease], list_of_tease_matches: Sequence[TeaseMatch], formatter_creator: IFormatterCreator, normal_printer: IPrinter, error_printer: IPrinter, *, show_all: bool) -> CommandLoaderResult:
    list_of_ref_ids: Sequence[RefId] = arg.pop_list(arg_token_stream, arg.REF_ID)
    return CommandLoaderResult(
        lambda: execute(_print_all_text if show_all else _print_matching_text, list_of_ref_ids, list_of_teases, list_of_tease_matches, formatter_creator, normal_printer, error_printer),
        [],
    )

def execute(print_call: Callable[[IFormatter, Iterable[TeaseMatch]], None], list_of_ref_ids: Sequence[RefId], list_of_teases: Iterable[Tease], list_of_tease_matches: Sequence[TeaseMatch], formatter_creator: IFormatterCreator, normal_printer: IPrinter, error_printer: IPrinter) -> None:
    list_of_tease_matches_to_show: Sequence[TeaseMatch] | None = None
    if list_of_ref_ids:
        list_of_tease_matches_to_show = try_create_list_of_tease_matches_from_ref_ids(list_of_teases, list_of_tease_matches, list_of_ref_ids, error_printer)
    else:
        list_of_tease_matches_to_show = list_of_tease_matches

    if list_of_tease_matches_to_show:
        formatter: IFormatter = formatter_creator.create(normal_printer)
        print_call(formatter, list_of_tease_matches_to_show)
    else:
        error_printer.writeln("No teases available to show")

def _print_matching_text(formatter: IFormatter, list_of_tease_matches: Iterable[TeaseMatch]) -> None:
    formatter.print_matching_text_of_list_of_teases(list_of_tease_matches)

def _print_all_text(formatter: IFormatter, list_of_tease_matches: Iterable[TeaseMatch]) -> None:
    formatter.print_all_text_of_list_of_teases(list_of_tease_matches)

class ShowHelp(IHelpInfo):
    @override
    def get_one_line_summary(self) -> str:
        return "Prints the summary and text matches for the current results"

    @override
    def get_detailed_summary(self) -> str:
        return (
            "Arguments: [list of RefIds]\n"
            "Shows details for each tease including the matching text paragraphs if"
            " appropriate. The formatting used for the details can be controlled with the"
            " format command.\n"
            "When used without arguments, all teases that were found from the last query are"
            " included. When one or more RefIds are specified, only those teases are included.\n"
            "RefIds can be an index into the list of matches such as '3', a teaseId such as"
            " '#38664', or an authorId such as '@43937'.\n"
            "Matching fields and text may be highlighted which can be controlled with the"
            " highlight command.\n"
            "The text paragraphs may be abbreviated with an ellipsis which can be controlled"
            " with the ellipsis command.\n"
            "Example:\r"
            "  \tShow details of the last query results\r"
            "  > \tshow\r"
            "Example:\r"
            "  \tShow details of some matched teases by index\r"
            "  > \tshow 3 7\r"
            "Example:\r"
            "  \tShow details of some specific teaseIds\r"
            "  > \tshow #16830 #1465 #38664\r"
            "Example:\r"
            "  \tShow details of teases from a specific authorId\r"
            "  > \tshow @43937\n"
            "See also:\r"
            "  \tshowall, summary, format, ellipsis, highlight\n"
        )

class ShowAllHelp(IHelpInfo):
    @override
    def get_one_line_summary(self) -> str:
        return "Prints the summary and all text paragraphs for the current results"

    @override
    def get_detailed_summary(self) -> str:
        return (
            "Arguments: [list of RefIds]\n"
            "Shows details for each tease with all text paragraphs. The formatting used for the"
            " details can be controlled with the format command.\n"
            "When used without arguments, all teases that were found from the last query are"
            " included. When one or more RefIds are specified, only those teases are included.\n"
            "RefIds can be an index into the list of matches such as '3', a teaseId such as"
            " '#38664', or an authorId such as '@43937'.\n"
            "Matching fields and text may be highlighted which can be controlled with the"
            " highlight command.\n"
            "The ellipsis setting is ignored with this command so that all of the text is"
            " shown regardless of whether it matched or not.\n"
            "Example:\r"
            "  \tShow details of the last query results\r"
            "  > \tshowall\r"
            "Example:\r"
            "  \tShow details of some matched teases by index\r"
            "  > \tshowall 3 7\r"
            "Example:\r"
            "  \tShow details of some specific teaseIds\r"
            "  > \tshowall #16830 #1465 #38664\r"
            "Example:\r"
            "  \tShow details of teases from a specific authorId\r"
            "  > \tshowall @43937\n"
            "See also:\r"
            "  \tshow, summary, format, ellipsis, highlight\n"
        )
