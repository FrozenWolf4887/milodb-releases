# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from abc import ABC, abstractmethod
from types import TracebackType
from typing import Self
from milodb_common.output.print.i_printer import IPrinter

class ILogDisplay(ABC):
    @property
    @abstractmethod
    def normal_printer(self) -> IPrinter:
        pass

    @property
    @abstractmethod
    def warning_printer(self) -> IPrinter:
        pass

    @property
    @abstractmethod
    def error_printer(self) -> IPrinter:
        pass

    @abstractmethod
    def prompt_to_continue(self) -> None:
        pass

    @abstractmethod
    def print_warning_and_prompt_to_continue(self, message: str) -> None:
        pass

    @abstractmethod
    def print_fatal_and_prompt_to_continue(self, message: str) -> None:
        pass

    @abstractmethod
    def __enter__(self) -> Self:
        pass

    @abstractmethod
    def __exit__(self, exc_type: type[BaseException] | None, exc_value: BaseException | None, traceback: TracebackType | None) -> None:
        pass
