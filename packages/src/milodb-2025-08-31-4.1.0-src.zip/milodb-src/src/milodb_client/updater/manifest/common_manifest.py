# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from __future__ import annotations
from abc import ABC, abstractmethod
from enum import Enum
from typing import TYPE_CHECKING, override
if TYPE_CHECKING:
    from pathlib import Path

class PreReleaseLabel(Enum):
    ALPHA = 'alpha'
    BETA = 'beta'
    RELEASE_CANDIDATE = 'rc'

class IPreRelease(ABC):
    @property
    @abstractmethod
    def label(self) -> PreReleaseLabel:
        pass

    @property
    @abstractmethod
    def number(self) -> int:
        pass

    @abstractmethod
    @override
    def __str__(self) -> str:
        pass

    @abstractmethod
    @override
    def __hash__(self) -> int:
        pass

    @abstractmethod
    @override
    def __eq__(self, other: object) -> bool:
        pass

    @abstractmethod
    @override
    def __ne__(self, other: object) -> bool:
        pass

    @abstractmethod
    def __lt__(self, other: IPreRelease) -> bool:
        pass

    @abstractmethod
    def __le__(self, other: IPreRelease) -> bool:
        pass

    @abstractmethod
    def __gt__(self, other: IPreRelease) -> bool:
        pass

    @abstractmethod
    def __ge__(self, other: IPreRelease) -> bool:
        pass

class IVersionNumber(ABC):
    @property
    @abstractmethod
    def major(self) -> int:
        pass

    @property
    @abstractmethod
    def minor(self) -> int:
        pass

    @property
    @abstractmethod
    def patch(self) -> int:
        pass

    @property
    @abstractmethod
    def pre_release(self) -> IPreRelease | None:
        pass

    @abstractmethod
    @override
    def __str__(self) -> str:
        pass

    @abstractmethod
    @override
    def __hash__(self) -> int:
        pass

    @abstractmethod
    @override
    def __eq__(self, other: object) -> bool:
        pass

    @abstractmethod
    @override
    def __ne__(self, other: object) -> bool:
        pass

    @abstractmethod
    def __lt__(self, other: IVersionNumber) -> bool:
        pass

    @abstractmethod
    def __le__(self, other: IVersionNumber) -> bool:
        pass

    @abstractmethod
    def __gt__(self, other: IVersionNumber) -> bool:
        pass

    @abstractmethod
    def __ge__(self, other: IVersionNumber) -> bool:
        pass

class IHexDigest(ABC):
    @abstractmethod
    @override
    def __str__(self) -> str:
        pass

    @abstractmethod
    @override
    def __hash__(self) -> int:
        pass

    @abstractmethod
    @override
    def __eq__(self, other: object) -> bool:
        pass

    @abstractmethod
    @override
    def __ne__(self, other: object) -> bool:
        pass

    @property
    @abstractmethod
    def digest_bytes(self) -> bytes:
        pass

class IConfigFile(ABC):
    @property
    @abstractmethod
    def config_key(self) -> int:
        pass

    @property
    @abstractmethod
    def filename(self) -> Path:
        pass

class ILaunchFile(ABC):
    @property
    @abstractmethod
    def operating_system(self) -> str:
        pass

    @property
    @abstractmethod
    def filename(self) -> Path:
        pass
