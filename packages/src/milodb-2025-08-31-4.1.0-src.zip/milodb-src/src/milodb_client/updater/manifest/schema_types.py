# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import datetime
from collections.abc import Callable, Mapping, Sequence, Set as AbstractSet
from pathlib import Path
from typing import override
from milodb_client.updater.manifest.i_schema_types import IGroup, IItem, IKey, IKeyCreator, ITypedItem, ITypedKey, KeyParseError, SchemaLoadError
from milodb_common.util.ref import IRef, SimpleRef

class Item(IItem):
    def __init__(self, parent: IGroup | None, key: IKey | str) -> None:
        self._parent: IGroup | None = parent
        self._key: IKey = TextKey(key) if isinstance(key, str) else key
        if parent:
            parent.add_child(self)

    @property
    @override
    def parent(self) -> IGroup | None:
        return self._parent

    @property
    @override
    def key(self) -> IKey:
        return self._key

    @property
    @override
    def full_path(self) -> str:
        if self._parent is not None:
            parent_path: str = self._parent.full_path
            if parent_path:
                return f'{parent_path}/{self._key.name}'
        return self._key.name

class StaticGroup(Item, IGroup):
    def __init__(self, parent: IGroup | None, key: IKey | str) -> None:
        super().__init__(parent, key)
        self._map_of_key_to_child: dict[IKey, IItem] = {}

    @property
    @override
    def is_mandatory(self) -> bool:
        return True

    @override
    def add_child(self, child: IItem) -> None:
        self._map_of_key_to_child[child.key] = child

    @override
    def load(self, value: object) -> None:
        if not isinstance(value, dict):
            msg = f"Key '{self.full_path}' value is not a group"
            raise SchemaLoadError(msg)

        set_of_child_keys: set[str] = set()
        child_key_name: object
        child_value: object
        for child_key_name, child_value in value.items():
            if not isinstance(child_key_name, str):
                msg = f"Key '{self.full_path}/{child_key_name}' is not text"
                raise SchemaLoadError(msg)
            if not child_key_name:
                msg = f"Key '{self.full_path}/' is blank"
                raise SchemaLoadError(msg)
            child: IItem | None = self._find_child_of_key(child_key_name)
            if child is None:
                msg = f"Key '{self._path_of_key(child_key_name)}' is unknown"
                raise SchemaLoadError(msg)
            child.load(child_value)
            set_of_child_keys.add(child_key_name)

        set_of_mandatory_child_keys: AbstractSet[str] = { key.name for key, child in self._map_of_key_to_child.items() if child.is_mandatory }
        missing_child_key: str
        for missing_child_key in set_of_mandatory_child_keys - set_of_child_keys:
            msg = f"Key '{self._path_of_key(missing_child_key)}' is missing"
            raise SchemaLoadError(msg)

    @override
    def save(self) -> object:
        map_of_key_name_to_child_value: dict[str, object] = {}
        key: IKey
        child: IItem
        for key, child in self._map_of_key_to_child.items():
            child_value: object = child.save()
            if child_value is not None or child.is_mandatory:
                map_of_key_name_to_child_value[key.name] = child_value
        return map_of_key_name_to_child_value

    def _find_child_of_key(self, key_name: str) -> IItem | None:
        key: IKey
        child: IItem
        for key, child in self._map_of_key_to_child.items():
            if key.name == key_name:
                return child
        return None

    def _path_of_key(self, key: str) -> str:
        this_path: str = self.full_path
        if this_path:
            return f'{this_path}/{key}'
        return key

class DynamicGroup[K, T: IItem](Item, IGroup):
    def __init__(self, parent: IGroup | None, key: IKey | str, key_creator: IKeyCreator[K], child_creator_delegate: Callable[[IGroup, ITypedKey[K]], T]) -> None:
        super().__init__(parent, key)
        self._key_creator: IKeyCreator[K] = key_creator
        self._child_creator_delegate: Callable[[IGroup, ITypedKey[K]], T] = child_creator_delegate
        self._map_of_key_to_child: dict[ITypedKey[K], T] = {}

    @property
    @override
    def is_mandatory(self) -> bool:
        return True

    @override
    def add_child(self, child: IItem) -> None:
        """Children are added as they are loaded to maintain type coherence."""

    @override
    def load(self, value: object) -> None:
        if not isinstance(value, dict):
            msg = f"Key '{self.full_path}' value is not a group"
            raise SchemaLoadError(msg)

        child_key_name: object
        child_value: object
        for child_key_name, child_value in value.items():
            if not isinstance(child_key_name, str):
                msg = f"Key '{self.full_path}/{child_key_name}' is not text"
                raise SchemaLoadError(msg)
            if not child_key_name:
                msg = f"Key '{self.full_path}/' is blank"
                raise SchemaLoadError(msg)
            try:
                child_key: ITypedKey[K] = self._key_creator.parse(child_key_name)
            except KeyParseError as ex:
                msg = f"Key '{self.full_path}/{child_key_name}': {ex}"
                raise SchemaLoadError(msg) from ex

            child: T = self._child_creator_delegate(self, child_key)
            child.load(child_value)
            self._map_of_key_to_child[child_key] = child

    @override
    def save(self) -> Mapping[str, object]:
        return {
            key.name: child.save() for key, child in self._map_of_key_to_child.items()
        }

    def get(self) -> Mapping[ITypedKey[K], T]:
        return self._map_of_key_to_child

    def get_key(self, key_value: K) -> T | None:
        child_key: ITypedKey[K]
        child_value: T
        for child_key, child_value in self._map_of_key_to_child.items():
            if child_key.get_key_value() == key_value:
                return child_value
        return None

    def add_key(self, key_value: K) -> T:
        item: T | None = self.get_key(key_value)
        if item:
            return item
        child_key = self._key_creator.from_base_type(key_value)
        child: T = self._child_creator_delegate(self, child_key)
        self._map_of_key_to_child[child_key] = child
        return child

class ListGroup[T](Item, IGroup):
    def __init__(self, parent: IGroup | None, key: IKey | str, child_creator_delegate: Callable[[IGroup, IKey], ITypedItem[T]]) -> None:
        super().__init__(parent, key)
        self._child_creator_delegate: Callable[[IGroup, IKey], ITypedItem[T]] = child_creator_delegate
        self._list_of_children: list[ITypedItem[T]] = []

    @property
    @override
    def is_mandatory(self) -> bool:
        return True

    @override
    def add_child(self, child: IItem) -> None:
        """Children are added as they are loaded to maintain type coherence."""

    @override
    def load(self, value: object) -> None:
        if not isinstance(value, list):
            msg = f"Key '{self.full_path}' value is not a list"
            raise SchemaLoadError(msg)

        child_value: object
        for child_value in value:
            child: ITypedItem[T] = self._child_creator_delegate(self, self.key)
            child.load(child_value)
            self._list_of_children.append(child)

    @override
    def save(self) -> Sequence[object]:
        return [
            child.save() for child in self._list_of_children
        ]

    def get(self) -> Sequence[ITypedItem[T]]:
        return self._list_of_children

    def add_item(self) -> T:
        child: ITypedItem[T] = self._child_creator_delegate(self, self.key)
        self._list_of_children.append(child)
        return child.get_item_value()

class TextItem(Item, ITypedItem[str]):
    def __init__(self, parent: IGroup | None, key: IKey | str) -> None:
        super().__init__(parent, key)
        self._value: str = ''

    @property
    @override
    def is_mandatory(self) -> bool:
        return True

    @override
    def __str__(self) -> str:
        return self._value

    @override
    def load(self, value: object) -> None:
        if not isinstance(value, str):
            msg = f"Key '{self.full_path}' value is not text"
            raise SchemaLoadError(msg)
        if not value:
            msg = f"Key '{self.full_path}' value is blank"
            raise SchemaLoadError(msg)
        self._value = value

    @override
    def save(self) -> str:
        return self._value

    @override
    def get_item_value(self) -> str:
        return self._value

    def set(self, value: str) -> None:
        self._value = value

class PathItem(Item, ITypedItem[IRef[Path]]):
    def __init__(self, parent: IGroup | None, key: IKey | str) -> None:
        super().__init__(parent, key)
        self._value: IRef[Path] = SimpleRef(Path())

    @property
    @override
    def is_mandatory(self) -> bool:
        return True

    @override
    def __str__(self) -> str:
        return str(self._value.get())

    @override
    def load(self, value: object) -> None:
        if not isinstance(value, str):
            msg = f"Key '{self.full_path}' value is not text"
            raise SchemaLoadError(msg)
        if not value:
            msg = f"Key '{self.full_path}' value is blank"
            raise SchemaLoadError(msg)
        self._value.set(Path(value))

    @override
    def save(self) -> str:
        return str(self._value.get())

    @override
    def get_item_value(self) -> IRef[Path]:
        return self._value

    def set(self, value: Path) -> None:
        self._value.set(value)

class IntegerItem(Item, ITypedItem[int]):
    def __init__(self, parent: IGroup | None, key: IKey | str) -> None:
        super().__init__(parent, key)
        self._value: int = 0

    @property
    @override
    def is_mandatory(self) -> bool:
        return True

    @override
    def __str__(self) -> str:
        return str(self._value)

    @override
    def load(self, value: object) -> None:
        if not isinstance(value, int):
            msg = f"Key '{self.full_path}' value is not an integer"
            raise SchemaLoadError(msg)
        self._value = value

    @override
    def save(self) -> int:
        return self._value

    @override
    def get_item_value(self) -> int:
        return self._value

    def set(self, value: int) -> None:
        self._value = value

class DateItem(Item, ITypedItem[datetime.date]):
    def __init__(self, parent: IGroup | None, key: IKey | str) -> None:
        super().__init__(parent, key)
        self._value: datetime.date = datetime.date.min

    @property
    @override
    def is_mandatory(self) -> bool:
        return True

    @override
    def __str__(self) -> str:
        return self._value.isoformat()

    @override
    def load(self, value: object) -> None:
        if not isinstance(value, str):
            msg = f"Key '{self.full_path}' value is not text"
            raise SchemaLoadError(msg)
        if not value:
            msg = f"Key '{self.full_path}' value is blank"
            raise SchemaLoadError(msg)
        try:
            self._value = datetime.date.fromisoformat(value)
        except ValueError as ex:
            msg = f"Key '{self.full_path}' value '{value}' is not an ISO date"
            raise SchemaLoadError(msg) from ex

    @override
    def save(self) -> str:
        return self._value.isoformat()

    @override
    def get_item_value(self) -> datetime.date:
        return self._value

    def set(self, value: datetime.date) -> None:
        self._value = value

class BooleanItem(Item, ITypedItem[bool]):
    def __init__(self, parent: IGroup | None, key: IKey | str) -> None:
        super().__init__(parent, key)
        self._value: bool = False

    @property
    @override
    def is_mandatory(self) -> bool:
        return True

    @override
    def __str__(self) -> str:
        return str(self._value)

    @override
    def load(self, value: object) -> None:
        if not isinstance(value, bool):
            msg = f"Key '{self.full_path}' value is not a boolean"
            raise SchemaLoadError(msg)
        self._value = value

    @override
    def save(self) -> bool:
        return self._value

    @override
    def get_item_value(self) -> bool:
        return self._value

    def set(self, value: bool) -> None: # noqa: FBT001 Boolean-typed positional argument in function definition
        self._value = value

class OptionalTextItem(Item, ITypedItem[str | None]):
    def __init__(self, parent: IGroup | None, key: IKey | str) -> None:
        super().__init__(parent, key)
        self._value: str | None = None

    @property
    @override
    def is_mandatory(self) -> bool:
        return False

    @override
    def __str__(self) -> str:
        return str(self._value)

    @override
    def load(self, value: object) -> None:
        if not isinstance(value, str):
            msg = f"Key '{self.full_path}' value is not text"
            raise SchemaLoadError(msg)
        if not value:
            msg = f"Key '{self.full_path}' value is blank"
            raise SchemaLoadError(msg)
        self._value = value

    @override
    def save(self) -> str | None:
        return self._value

    @override
    def get_item_value(self) -> str | None:
        return self._value

    def set(self, value: str) -> None:
        self._value = value

    def remove(self) -> None:
        self._value = None

class OptionalPathItem(Item, ITypedItem[Path | None]):
    def __init__(self, parent: IGroup | None, key: IKey | str) -> None:
        super().__init__(parent, key)
        self._value: Path | None = None

    @property
    @override
    def is_mandatory(self) -> bool:
        return False

    @override
    def __str__(self) -> str:
        return str(self._value)

    @override
    def load(self, value: object) -> None:
        if not isinstance(value, str):
            msg = f"Key '{self.full_path}' value is not text"
            raise SchemaLoadError(msg)
        if not value:
            msg = f"Key '{self.full_path}' value is blank"
            raise SchemaLoadError(msg)
        self._value = Path(value)

    @override
    def save(self) -> str | None:
        return str(self._value) if self._value else None

    @override
    def get_item_value(self) -> Path | None:
        return self._value

    def set(self, value: Path) -> None:
        self._value = value

    def remove(self) -> None:
        self._value = None

class OptionalBooleanItem(Item, ITypedItem[bool | None]):
    def __init__(self, parent: IGroup | None, key: IKey | str) -> None:
        super().__init__(parent, key)
        self._value: bool | None = None

    @property
    @override
    def is_mandatory(self) -> bool:
        return False

    @override
    def __str__(self) -> str:
        return str(self._value)

    @override
    def load(self, value: object) -> None:
        if not isinstance(value, bool):
            msg = f"Key '{self.full_path}' value is not a boolean"
            raise SchemaLoadError(msg)
        self._value = value

    @override
    def save(self) -> bool | None:
        return self._value

    @override
    def get_item_value(self) -> bool | None:
        return self._value

    def set(self, value: bool) -> None: # noqa: FBT001 Boolean-typed positional argument in function definition
        self._value = value

    def remove(self) -> None:
        self._value = None

def root_key() -> IKey:
    return TextKey('')

class TextKey(ITypedKey[str]):
    def __init__(self, key_name: str) -> None:
        self._key_name: str = key_name

    @override
    def __str__(self) -> str:
        return self._key_name

    @property
    @override
    def name(self) -> str:
        return self._key_name

    @override
    def get_key_value(self) -> str:
        return self._key_name

    class Creator(IKeyCreator[str]):
        @override
        def parse(self, key_name: str) -> ITypedKey[str]:
            return TextKey(key_name)

        @override
        def from_base_type(self, value: str) -> ITypedKey[str]:
            return TextKey(value)

class PathKey(ITypedKey[Path]):
    def __init__(self, key_value: Path) -> None:
        self._key_value: Path = key_value

    @override
    def __str__(self) -> str:
        return str(self._key_value)

    @property
    @override
    def name(self) -> str:
        return str(self._key_value)

    @override
    def get_key_value(self) -> Path:
        return self._key_value

    class Creator(IKeyCreator[Path]):
        @override
        def parse(self, key_name: str) -> ITypedKey[Path]:
            return PathKey(Path(key_name))

        @override
        def from_base_type(self, value: Path) -> ITypedKey[Path]:
            return PathKey(value)

class IntegerKey(ITypedKey[int]):
    def __init__(self, key_value: int) -> None:
        self._key_value: int = key_value

    @override
    def __str__(self) -> str:
        return str(self._key_value)

    @property
    @override
    def name(self) -> str:
        return str(self._key_value)

    @override
    def get_key_value(self) -> int:
        return self._key_value

    class Creator(IKeyCreator[int]):
        @override
        def parse(self, key_name: str) -> ITypedKey[int]:
            try:
                key_value: int = int(key_name)
            except ValueError as ex:
                msg = f"'{key_name}' is not an integer"
                raise KeyParseError(msg) from ex
            return IntegerKey(key_value)

        @override
        def from_base_type(self, value: int) -> ITypedKey[int]:
            return IntegerKey(value)
