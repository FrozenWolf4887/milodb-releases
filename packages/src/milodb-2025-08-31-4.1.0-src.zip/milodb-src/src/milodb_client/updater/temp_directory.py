# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import tempfile
from pathlib import Path
from typing import override
from milodb_client.updater.i_temp_directory import ITempDirectory, ITempDirectoryCreator, TempDirectoryError
from milodb_client.updater.set_file_attributes import set_file_attributes

_FILENAME_PREFIX: str = 'mdbu-'

class TempDirectory(ITempDirectory):
    def __init__(self, path_to_directory: Path) -> None:
        self._path_to_directory: Path = path_to_directory

    @property
    @override
    def path(self) -> Path:
        return self._path_to_directory

    @override
    def path_of(self, filename: Path) -> Path:
        return self._path_to_directory / f'{_FILENAME_PREFIX}{filename}'

    @override
    def store_file(self, filename: Path, data: bytes, *, is_executable: bool = False) -> None:
        if len(filename.parts) != 1:
            msg = f"Temporary filename '{filename}' may not contain directory components"
            raise TempDirectoryError(msg)

        filepath: Path = self._path_to_directory / f'{_FILENAME_PREFIX}{filename}'
        try:
            filepath.write_bytes(data)
        except OSError as ex:
            msg = f"Unable to store file '{filepath}': {ex}"
            raise TempDirectoryError(msg) from ex

        try:
            set_file_attributes(filepath, is_executable=is_executable, is_readonly=False)
        except OSError as ex:
            msg = f"Unable to set attributes of file '{filepath}': {ex}"
            raise TempDirectoryError(msg) from ex

    @override
    def destroy(self) -> None:
        filepath: Path
        try:
            for filepath in self._path_to_directory.iterdir():
                if filepath.name.startswith(_FILENAME_PREFIX):
                    filepath.unlink()
                else:
                    msg = f"Refusing to delete temp file '{filepath}' because it doesn't start with '{_FILENAME_PREFIX}'"
                    raise TempDirectoryError(msg)
            self._path_to_directory.rmdir()
        except OSError as ex:
            msg = f"Failed to delete temp directory '{self._path_to_directory}': {ex}"
            raise TempDirectoryError(msg) from ex

class TempDirectoryCreator(ITempDirectoryCreator):
    @override
    def create(self) -> ITempDirectory:
        try:
            path_to_directory: Path = Path(tempfile.mkdtemp(prefix='update-temp-', dir=Path()))
        except OSError as ex:
            msg = f"Cannot create temp directory: {ex}"
            raise TempDirectoryError(msg) from ex
        return TempDirectory(path_to_directory)
