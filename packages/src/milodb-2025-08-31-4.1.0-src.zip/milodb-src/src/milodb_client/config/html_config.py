# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from pathlib import Path
from milodb_client.config.config_schema import CONFIG_SCHEMA
from milodb_common.config.framework import IConfig

class HtmlConfig:
    def __init__(self, config: IConfig) -> None:
        self._config: IConfig = config

    @property
    def css_file_path(self) -> Path:
        return Path(CONFIG_SCHEMA.format.html.css_file_path.fetch_value_or_default(self._config))
