# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from typing import override
from milodb_common.parser import arg
from milodb_common.parser.arg_token_stream import ArgTokenStream
from milodb_common.view.terminal.command_framework.i_command import CommandLoaderResult
from milodb_common.view.terminal.command_framework.i_help_info import IHelpInfo
from milodb_common.view.terminal.command_framework.quit_flag import QuitFlag

def load(arg_token_stream: ArgTokenStream, quit_flag: QuitFlag) -> CommandLoaderResult:
    arg.fail_if_not_empty(arg_token_stream)
    return CommandLoaderResult(quit_flag.set, [])

class Help(IHelpInfo):
    @override
    def get_one_line_summary(self) -> str:
        return "Exits the application"

    @override
    def get_detailed_summary(self) -> str:
        return (
            "Arguments: none\n"
            "Exits the application.\n"
            "Example:\r"
            "  > \texit\n"
        )
