# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from collections.abc import Iterable
from prompt_toolkit.completion import Completion
from milodb_common.parser.arg_token_stream import ArgTokenStream
from milodb_common.parser.candidate_text import CandidateText
from milodb_common.parser.expanding_token_stream import ExpandedToken
from milodb_common.variables.i_user_variables import IUserVariables
from milodb_common.view.terminal.command_framework.i_command_constructor import ICommandConstructor

class InputSuggester:
    def __init__(self, command_constructor: ICommandConstructor, user_variables: IUserVariables) -> None:
        self._command_constructor = command_constructor
        self._user_variables = user_variables

    def get_possible_completions(self, text: str, cursor_index: int) -> list[Completion]:
        list_of_completions: list[Completion] = []

        text_of_tokens_before_cursor: str = text[:cursor_index]
        arg_token_stream: ArgTokenStream = ArgTokenStream(text_of_tokens_before_cursor, self._user_variables, None, None, cursor_index)
        construct_result: ICommandConstructor.ConstructResult = self._command_constructor.try_construct(arg_token_stream)
        stopped_on_token: ExpandedToken | None = arg_token_stream.get_stopped_on_token()

        if isinstance(construct_result, ICommandConstructor.EmptyInputResult):
            list_of_completions = _create_completion_list(CandidateText.space_delimited_list(construct_result.list_of_command_names), cursor_index, stopped_on_token)
        elif isinstance(construct_result, ICommandConstructor.SuccessfulResult) or not construct_result.fault_token:
            list_of_completions = _create_completion_list(construct_result.list_of_candidate_text, cursor_index, stopped_on_token)

        if stopped_on_token and stopped_on_token.text.startswith('$') and arg_token_stream.is_expansion_enabled():
            list_of_variable_names: Iterable[str] = [f'${name}' for name in self._user_variables.get_list_of_names()]
            list_of_completions.extend(_create_completion_list(CandidateText.space_delimited_list(list_of_variable_names), cursor_index, stopped_on_token))

        return list_of_completions

def _create_completion_list(list_of_candidate_text: Iterable[CandidateText], cursor_index: int, stopped_on_token: ExpandedToken | None = None) -> list[Completion]:
    if stopped_on_token and stopped_on_token.variable_depth == 0:
        return [Completion(candidate_text.text + candidate_text.following_delimiter, stopped_on_token.topmost_token.outer_indices.start - cursor_index) for candidate_text in list_of_candidate_text if candidate_text.text.startswith(stopped_on_token.text)]
    return [Completion(candidate_text.text + candidate_text.following_delimiter, 0) for candidate_text in list_of_candidate_text]
