# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from abc import ABC, abstractmethod
from collections.abc import Sequence
from milodb_common.view.terminal.command_framework.i_command import CommandLoader
from milodb_common.view.terminal.command_framework.i_help_info import IHelpInfo

class ICommandFactory(ABC):
    @abstractmethod
    def get_list_of_command_names(self) -> Sequence[str]:
        pass

    @abstractmethod
    def try_get_command_loader_from_name(self, command_name: str) -> CommandLoader | None:
        pass

    @abstractmethod
    def try_get_command_help_from_name(self, command_name: str) -> IHelpInfo | None:
        pass
