# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from pathlib import Path
from typing import TYPE_CHECKING
from milodb_common.output.print.i_printer import IPrinter
from milodb_common.variables.i_user_variables import IUserVariables
from milodb_common.view.terminal.command_framework.i_command_constructor import ICommandConstructor
from milodb_common.view.terminal.command_framework.quit_flag import QuitFlag
from milodb_common.view.terminal.input.process import process_user_input
if TYPE_CHECKING:
    from collections.abc import Sequence

def run_autoexec(filepath: Path, command_constructor: ICommandConstructor, user_variables: IUserVariables, quit_flag: QuitFlag, normal_printer: IPrinter, error_printer: IPrinter, *, ignore_if_not_found: bool = True) -> None:
    autoexec_lines: Sequence[str] | None = None

    try:
        autoexec_lines = filepath.read_text(encoding='utf-8').splitlines()
    except FileNotFoundError:
        if not ignore_if_not_found:
            error_printer.writeln(f"File '{filepath}' not found")
    except (OSError, UnicodeDecodeError) as ex:
        error_printer.writeln(f"File '{filepath}' read error: {ex}")

    if autoexec_lines:
        normal_printer.writeln(f"Running commands from '{filepath}':")
        line: str
        for line in autoexec_lines:
            if quit_flag:
                break
            if line:
                normal_printer.writeln(f'> {line}')
                process_user_input(line, command_constructor, user_variables, quit_flag, normal_printer, error_printer)
