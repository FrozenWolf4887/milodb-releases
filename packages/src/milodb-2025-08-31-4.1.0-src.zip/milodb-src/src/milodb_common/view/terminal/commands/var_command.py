# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from collections.abc import Callable
from typing import TYPE_CHECKING, override
from milodb_common.output.print.i_printer import IPrinter
from milodb_common.parser import arg
from milodb_common.parser.arg_token_stream import ArgTokenStream
from milodb_common.parser.candidate_text import CandidateText
from milodb_common.variables.i_user_variables import IPersistentUserVariables, IUserVariables
from milodb_common.view.terminal.command_framework.i_command import CommandLoaderError, CommandLoaderResult
from milodb_common.view.terminal.command_framework.i_help_info import IHelpInfo
from milodb_common.view.terminal.input.default_input import IDefaultInputText
if TYPE_CHECKING:
    from collections.abc import Mapping, Sequence

def load(arg_token_stream: ArgTokenStream, user_variables: IPersistentUserVariables, default_input_text: IDefaultInputText, normal_printer: IPrinter, warning_printer: IPrinter, error_printer: IPrinter) -> CommandLoaderResult:
    def load_action_set(arg_token_stream: ArgTokenStream) -> Callable[[], None]:
        variable_name: str = arg.pop(arg_token_stream, arg.VariableName(user_variables.get_list_of_names()))
        variable_value: str = arg_token_stream.get_remaining_raw_text().strip()
        if not variable_value:
            msg = "Expected some text to set as the variable value"
            raise CommandLoaderError(msg, None, [])
        return lambda: execute_set(variable_name, variable_value, user_variables, normal_printer, warning_printer, error_printer)

    def load_action_get(arg_token_stream: ArgTokenStream) -> Callable[[], None]:
        variable_name: str = arg.pop(arg_token_stream, arg.VariableName(user_variables.get_list_of_names()))
        arg.fail_if_not_empty(arg_token_stream)
        return lambda: execute_get(variable_name, user_variables, normal_printer, error_printer)

    def load_action_delete(arg_token_stream: ArgTokenStream) -> Callable[[], None]:
        variable_name: str = arg.pop(arg_token_stream, arg.VariableName(user_variables.get_list_of_names()))
        arg.fail_if_not_empty(arg_token_stream)
        return lambda: execute_delete(variable_name, user_variables, normal_printer, warning_printer, error_printer)

    def load_action_rename(arg_token_stream: ArgTokenStream) -> Callable[[], None]:
        variable_name: str = arg.pop(arg_token_stream, arg.VariableName(user_variables.get_list_of_names()))
        new_variable_name: str = arg.pop(arg_token_stream, arg.VariableName([]))
        arg.fail_if_not_empty(arg_token_stream)
        return lambda: execute_rename(variable_name, new_variable_name, user_variables, normal_printer, warning_printer, error_printer)

    def load_action_copy(arg_token_stream: ArgTokenStream) -> Callable[[], None]:
        variable_name: str = arg.pop(arg_token_stream, arg.VariableName(user_variables.get_list_of_names()))
        new_variable_name: str = arg.pop(arg_token_stream, arg.VariableName([]))
        arg.fail_if_not_empty(arg_token_stream)
        return lambda: execute_copy(variable_name, new_variable_name, user_variables, normal_printer, warning_printer, error_printer)

    def load_action_edit(arg_token_stream: ArgTokenStream) -> Callable[[], None]:
        variable_name: str = arg.pop(arg_token_stream, arg.VariableName(user_variables.get_list_of_names()))
        arg.fail_if_not_empty(arg_token_stream)
        return lambda: execute_edit(variable_name, user_variables, default_input_text, error_printer)

    arg_token_stream.disable_expansion()

    map_of_action_to_delegate: Mapping[str, Callable[[ArgTokenStream], Callable[[], None]]] = {
        'set': load_action_set,
        'get': load_action_get,
        'delete': load_action_delete,
        'rename': load_action_rename,
        'copy': load_action_copy,
        'edit': load_action_edit,
    }

    load_command: Callable[[ArgTokenStream], Callable[[], None]] | None = arg.pop_optional(arg_token_stream, arg.DictValue(map_of_action_to_delegate, 'subcommand'))
    if load_command:
        return CommandLoaderResult(load_command(arg_token_stream), [])
    return CommandLoaderResult(
        lambda: execute_list(user_variables, normal_printer),
        CandidateText.space_delimited_list(map_of_action_to_delegate.keys()))

def execute_set(variable_name: str, variable_value: str, user_variables: IPersistentUserVariables, normal_printer: IPrinter, warning_printer: IPrinter, error_printer: IPrinter) -> None:
    user_variables.set(variable_name, variable_value)
    user_variables.save(normal_printer, warning_printer, error_printer)

def execute_get(variable_name: str, user_variables: IUserVariables, normal_printer: IPrinter, error_printer: IPrinter) -> None:
    value: str | None = user_variables.try_retrieve(variable_name)
    if value is not None:
        _print_variable(normal_printer, variable_name, value)
    else:
        error_printer.writeln(f"Unknown variable '{variable_name}'")

def execute_rename(variable_name: str, new_variable_name: str, user_variables: IPersistentUserVariables, normal_printer: IPrinter, warning_printer: IPrinter, error_printer: IPrinter) -> None:
    if variable_name != new_variable_name:
        value: str | None = user_variables.try_retrieve(variable_name)
        if value is not None:
            if user_variables.try_retrieve(new_variable_name) is None:
                user_variables.set(new_variable_name, value)
                user_variables.try_delete(variable_name)
                user_variables.save(normal_printer, warning_printer, error_printer)
            else:
                error_printer.writeln(f"Cannot rename variable '{variable_name}' to '{new_variable_name}' because '{new_variable_name}' already exists")
        else:
            error_printer.writeln(f"Unknown variable '{variable_name}'")
    else:
        error_printer.writeln(f"Variable '{variable_name}' cannot be renamed to itself")

def execute_copy(variable_name: str, new_variable_name: str, user_variables: IPersistentUserVariables, normal_printer: IPrinter, warning_printer: IPrinter, error_printer: IPrinter) -> None:
    if variable_name != new_variable_name:
        value: str | None = user_variables.try_retrieve(variable_name)
        if value is not None:
            if user_variables.try_retrieve(new_variable_name) is None:
                user_variables.set(new_variable_name, value)
                user_variables.save(normal_printer, warning_printer, error_printer)
            else:
                error_printer.writeln(f"Cannot copy variable '{variable_name}' to '{new_variable_name}' because '{new_variable_name}' already exists")
        else:
            error_printer.writeln(f"Unknown variable '{variable_name}'")
    else:
        error_printer.writeln(f"Variable '{variable_name}' cannot be copied to itself")

def execute_edit(variable_name: str, user_variables: IPersistentUserVariables, default_input_text: IDefaultInputText, error_printer: IPrinter) -> None:
    value: str | None = user_variables.try_retrieve(variable_name)
    if value is not None:
        default_input_text.set(f'var set {variable_name} {value}')
    else:
        error_printer.writeln(f"Unknown variable '{variable_name}'")

def execute_list(user_variables: IUserVariables, normal_printer: IPrinter) -> None:
    name: str
    value: str
    list_of_variables: Sequence[tuple[str, str]] = user_variables.get_list_of_variables()
    if list_of_variables:
        max_name_width: int = max(len(name) for name, _ in list_of_variables)
        for name, value in list_of_variables:
            _print_variable(normal_printer, name, value, max_name_width)
    else:
        normal_printer.writeln('No variables available to list')

def execute_delete(variable_name: str, user_variables: IPersistentUserVariables, normal_printer: IPrinter, warning_printer: IPrinter, error_printer: IPrinter) -> None:
    if user_variables.try_delete(variable_name):
        user_variables.save(normal_printer, warning_printer, error_printer)
    else:
        error_printer.writeln(f"Unknown variable '{variable_name}'")

def _print_variable(normal_printer: IPrinter, name: str, value: str, max_name_width: int = 0) -> None:
    normal_printer.writeln(f'  {name:<{max_name_width}} : {value}')

class Help(IHelpInfo):
    @override
    def get_one_line_summary(self) -> str:
        return "Manages the values of user variables"

    @override
    def get_detailed_summary(self) -> str:
        return (
            "Arguments: [get|set|delete|rename|copy|edit]\r"
            "  get    <VariableName>\r"
            "  set    <VariableName> <...>\r"
            "  delete <VariableName>\r"
            "  rename <VariableName> <VariableName>\r"
            "  copy   <VariableName> <VariableName>\r"
            "  edit   <VariableName>\n"
            "Variables can help to provide shortcuts when composing a command and are expanded as"
            " the input is processed. A variable reference can appear anywhere in the input by"
            " prefixing it with '$' and is a standalone delimited token such as:\r"
            "  > \tquery $year2020 and author is FrozenWolf\r"
            "  > \t$myQuery and author is FrozenWolf\n"
            "VariableName consists of alphanumeric characters, underscore, minus, and plus symbols.\n"
            "Each variable persists in a variables file that will be created or updated when a"
            " variable is set or changed. When the application is started, the variables file is"
            " loaded.\n"
            "When a variable is 'set', all text following the name is accepted verbatim.\n"
            "TAB completion for variable names within other commands will only provide suggestions"
            " when the '$' prefix is typed; this is to prevent variables getting mixed in with the"
            " regular options. TAB completion on inputs containing variables will behave as if the"
            " variable has been expanded.\n"
            "Variable expansion is recursive, allowing for variable values to reference other"
            " variables if needed.\n"
            "When this command is called without arguments, the list of variables is displayed.\n"
            "Example:\r"
            "  \tSet a variable to help with a query\r"
            "  > \tvar set year2020 date >= 2020-01-01 and date < 2021-01-01\r"
            "  \tUse the variable in a query\r"
            "  > \tquery $year2020 and text contains holiday\r"
            "  \tWhich is equivalent to\r"
            "  > \tquery date >= 2020-01-01 and date < 2021-01-01 and text contains holiday\r"
            "Example:\r"
            "  \tList all the variables\r"
            "  > \tvar\r"
            "Example:\r"
            "  \tDelete one of the variables\r"
            "  > \tvar delete year2020\r"
            "Example:\r"
            "  \tRename one of the variables\r"
            "  > \tvar rename year2020 agesAgo\r"
            "Example:\r"
            "  \tCopy one of the variables\r"
            "  > \tvar copy year2020 agesAgo\r"
            "Example:\r"
            "  \tEdit one of the variables\r"
            "  > \tvar edit year2020\n"
        )
