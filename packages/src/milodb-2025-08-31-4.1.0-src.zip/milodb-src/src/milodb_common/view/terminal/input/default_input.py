# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from abc import ABC, abstractmethod
from typing import override

class IDefaultInputText(ABC):
    @abstractmethod
    def set(self, value: str) -> None:
        pass

    @abstractmethod
    def clear(self) -> None:
        pass

    @abstractmethod
    def get(self) -> str:
        pass

class DefaultInputText(IDefaultInputText):
    def __init__(self) -> None:
        self._text: str = ''

    @override
    def set(self, value: str) -> None:
        self._text = value

    @override
    def clear(self) -> None:
        self._text = ''

    @override
    def get(self) -> str:
        return self._text
