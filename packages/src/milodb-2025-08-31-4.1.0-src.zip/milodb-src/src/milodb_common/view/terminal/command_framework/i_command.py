# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from collections.abc import Callable, Sequence
from dataclasses import dataclass
from milodb_common.parser.arg_token_stream import ArgTokenStream
from milodb_common.parser.candidate_text import CandidateText
from milodb_common.parser.token import Token

@dataclass
class CommandLoaderResult:
    command: Callable[[], None]
    list_of_candidate_text: Sequence[CandidateText]

@dataclass
class CommandLoaderError(Exception):
    message: str
    fault_token: Token | None
    list_of_candidate_text: Sequence[CandidateText]

type CommandLoader = Callable[[ArgTokenStream], CommandLoaderResult]
