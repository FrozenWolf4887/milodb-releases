# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from typing import override
from milodb_common.parser.arg import ArgumentError
from milodb_common.parser.arg_token_stream import ArgTokenStream
from milodb_common.parser.candidate_text import CandidateText
from milodb_common.parser.expanding_token_stream import ExpandingTokenStream
from milodb_common.parser.token import Token
from milodb_common.parser.token_stream import TokenStreamError
from milodb_common.view.terminal.command_framework.i_command import CommandLoader, CommandLoaderError, CommandLoaderResult
from milodb_common.view.terminal.command_framework.i_command_constructor import ICommandConstructor
from milodb_common.view.terminal.command_framework.i_command_factory import ICommandFactory

class CommandConstructor(ICommandConstructor):
    def __init__(self, command_factory: ICommandFactory) -> None:
        self._command_factory: ICommandFactory = command_factory

    @override
    def try_construct(self, arg_token_stream: ArgTokenStream) -> ICommandConstructor.ConstructResult:
        command_token: Token | None = arg_token_stream.next()
        if command_token:
            return self._try_create_from_command_name(arg_token_stream, command_token)
        return ICommandConstructor.EmptyInputResult(list(self._command_factory.get_list_of_command_names()))

    def _try_create_from_command_name(self, arg_token_stream: ArgTokenStream, command_token: Token) -> ICommandConstructor.ConstructResult:
        command_name: str = command_token.text
        command_loader: CommandLoader | None = self._command_factory.try_get_command_loader_from_name(command_name)
        if command_loader:
            return _try_load_command(arg_token_stream, command_name, command_loader)
        return ICommandConstructor.FailedResult(
            command_name = None,
            fault_token = command_token,
            fault_text = 'Unknown command',
            input_text = _get_expanded_input_text(arg_token_stream),
            list_of_candidate_text = CandidateText.space_delimited_list(self._command_factory.get_list_of_command_names()))

def _try_load_command(arg_token_stream: ArgTokenStream, command_name: str, command_loader: CommandLoader) -> ICommandConstructor.ConstructResult:
    result: ICommandConstructor.ConstructResult

    try:
        load_result: CommandLoaderResult = command_loader(arg_token_stream)
    except TokenStreamError as ex:
        result = ICommandConstructor.FailedResult(
            command_name = command_name,
            fault_token = ex.fault_token,
            fault_text = f"Parsing error at character #{ex.fault_token.inner_indices.start} '{ex.cause_of_fault_text}'",
            input_text = _get_expanded_input_text(arg_token_stream),
            list_of_candidate_text = ex.list_of_candidate_text)
    except ArgumentError as ex:
        result = ICommandConstructor.FailedResult(
            command_name = command_name,
            fault_token = ex.fault_token,
            fault_text = ex.message,
            input_text = _get_expanded_input_text(arg_token_stream),
            list_of_candidate_text = ex.list_of_candidate_text)
    except CommandLoaderError as ex:
        result = ICommandConstructor.FailedResult(
            command_name = command_name,
            fault_token = ex.fault_token,
            fault_text = ex.message,
            input_text = _get_expanded_input_text(arg_token_stream),
            list_of_candidate_text = ex.list_of_candidate_text)
    except ICommandConstructor.DelegateError as ex:
        result = ex.construct_result
    else:
        result = ICommandConstructor.SuccessfulResult(load_result.command, load_result.list_of_candidate_text)

    return result

def _get_expanded_input_text(token_stream: ExpandingTokenStream) -> str:
    return token_stream.get_expanded_raw_text() + token_stream.get_remaining_raw_text()
