# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import json
from collections.abc import Mapping, Sequence
from pathlib import Path
from typing import override
from milodb_common.output.print.i_printer import IPrinter
from milodb_common.variables.i_user_variables import IPersistentUserVariables, VARIABLE_NAME_PATTERN

class FileUserVariables(IPersistentUserVariables):
    def __init__(self, filepath: Path) -> None:
        self._filepath: Path = filepath
        self._map_of_name_to_value: dict[str, str] = {}
        self._load_was_successful: bool = True

    @override
    def load(self, normal_printer: IPrinter, warning_printer: IPrinter, error_printer: IPrinter) -> None:
        try:
            json_object: object = json.loads(self._filepath.read_text(encoding='utf-8'))
        except FileNotFoundError:
            pass
        except (OSError, json.JSONDecodeError, UnicodeDecodeError) as ex:
            error_printer.writeln(f"Unable to load variables from '{self._filepath}': {ex}")
            self._load_was_successful = False
        else:
            normal_printer.writeln(f"Loaded variables from '{self._filepath}'")
            if isinstance(json_object, Mapping):
                self._map_of_name_to_value = self._validate_config(json_object, error_printer)
            else:
                error_printer.writeln("Root of variables file is not a JSON dictionary")
                self._load_was_successful = False

        if not self._load_was_successful:
            warning_printer.writeln("Variables set or changed at runtime will not be saved to prevent corruption")

    @override
    def save(self, normal_printer: IPrinter, warning_printer: IPrinter, error_printer: IPrinter) -> None:
        if self._load_was_successful:
            try:
                self._filepath.write_text(json.dumps(self._map_of_name_to_value, indent=4, ensure_ascii=False, sort_keys=True), encoding='utf-8')
            except (OSError, UnicodeEncodeError) as ex:
                error_printer.writeln(f"Unable to save variables to '{self._filepath}': {ex}")
            else:
                normal_printer.writeln(f"Saved variables to '{self._filepath}'")
        else:
            warning_printer.writeln('Variables not saved due to initial loading error')

    @override
    def set(self, name: str, value: str) -> None:
        self._map_of_name_to_value[name] = value

    @override
    def try_retrieve(self, name: str) -> str | None:
        value: object = self._map_of_name_to_value.get(name)
        return value if isinstance(value, str) else None

    @override
    def try_delete(self, name: str) -> bool:
        return self._map_of_name_to_value.pop(name, None) is not None

    @override
    def delete_all(self) -> None:
        self._map_of_name_to_value.clear()

    @override
    def get_list_of_names(self) -> Sequence[str]:
        return list(self._map_of_name_to_value)

    @override
    def get_list_of_variables(self) -> Sequence[tuple[str, str]]:
        return list(self._map_of_name_to_value.items())

    def _validate_config(self, some_dictionary: Mapping[object, object], error_printer: IPrinter) -> dict[str, str]:
        map_of_name_to_value: dict[str, str] = {}

        index: int
        name: object
        value: object
        for index, (name, value) in enumerate(some_dictionary.items()):
            if isinstance(name, str) and isinstance(value, str):
                map_of_name_to_value[name] = value
            else:
                self._load_was_successful = False
                if not isinstance(name, str):
                    error_printer.writeln(f'Variable at index #{index} has a non string name')
                elif not name:
                    error_printer.writeln(f'Variable at index #{index} has a blank name')
                elif not VARIABLE_NAME_PATTERN.fullmatch(name):
                    error_printer.writeln(f"Variable at index #{index} named '{name}' does not conform to pattern '{VARIABLE_NAME_PATTERN.pattern}'")
                if not isinstance(value, str):
                    error_printer.writeln(f"Variable at index #{index} named '{name}' has a value that is not a string")

        return map_of_name_to_value
