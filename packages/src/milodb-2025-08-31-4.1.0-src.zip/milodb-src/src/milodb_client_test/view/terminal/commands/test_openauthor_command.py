# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from collections.abc import Sequence
from dataclasses import dataclass, field
from typing import override
from milodb_client.database.tease import Tease
from milodb_client.query.tease_match import TeaseMatch
from milodb_client.view.terminal.commands import openauthor_command
from milodb_client_test.test import fake_teases
from milodb_common.config.i_launch_config import ILaunchConfig
from milodb_common.output.print.i_printer import IPrinter
from milodb_common.parser.arg_token_stream import ArgTokenStream
from milodb_common.view.terminal.command_framework.i_command import CommandLoaderResult
from milodb_common_test.parser.error_messages import ErrorMessage
from milodb_common_test.test.strict_mock import InterfaceMock
from milodb_common_test.test.test_command_base import CommandTestBase

_DEFAULT_LIST_OF_TEASES: Sequence[Tease] = [
    fake_teases.TEASE_ID_1000_AUTHOR_ID_4567,
    fake_teases.TEASE_ID_1234_AUTHOR_ID_6431,
    fake_teases.TEASE_ID_5678_AUTHOR_ID_4567,
    fake_teases.TEASE_ID_2000_AUTHOR_ID_6431,
    fake_teases.TEASE_ID_8721_AUTHOR_ID_7213,
]

@dataclass
class _Args:
    list_of_teases: Sequence[Tease] = field(default_factory=lambda: list(_DEFAULT_LIST_OF_TEASES))
    list_of_tease_matches: Sequence[TeaseMatch] = field(default_factory=list)
    launch_config: InterfaceMock = field(default_factory=lambda: InterfaceMock(ILaunchConfig))
    normal_printer: InterfaceMock = field(default_factory=lambda: InterfaceMock(IPrinter))
    warning_printer: InterfaceMock = field(default_factory=lambda: InterfaceMock(IPrinter))
    error_printer: InterfaceMock = field(default_factory=lambda: InterfaceMock(IPrinter))
    debug_printer: InterfaceMock = field(default_factory=lambda: InterfaceMock(IPrinter))

class OpenAuthorCommandTestBase(CommandTestBase):
    @override
    def setUp(self) -> None:
        self._args: _Args = _Args()
        return super().setUp()

    @override
    def load_command(self, arg_token_stream: ArgTokenStream) -> CommandLoaderResult:
        return openauthor_command.load(
            arg_token_stream,
            self._args.list_of_teases,
            self._args.list_of_tease_matches,
            self._args.launch_config,
            self._args.normal_printer,
            self._args.warning_printer,
            self._args.error_printer,
            self._args.debug_printer,
        )

class TestOpenAuthorCommandLoad(OpenAuthorCommandTestBase):
    def test_without_arguments_returns_failure(self) -> None:
        self.command_load([])
        self.assert_argument_error(None, ErrorMessage.INSUFFICIENT_EXPECTING_SOME_REFID, [])

    def test_with_signed_index_returns_failure(self) -> None:
        self.command_load(['1234', '-5678', '9012'])
        self.assert_argument_error(2, ErrorMessage.INVALID_EXPECTING_REFID, [])

    def test_with_signed_teaseid_returns_failure(self) -> None:
        self.command_load(['#1234', '#-5678', '#9012'])
        self.assert_argument_error(2, ErrorMessage.INVALID_EXPECTING_TEASEID, [])

    def test_with_signed_authorid_returns_failure(self) -> None:
        self.command_load(['@1234', '@-5678', '@9012'])
        self.assert_argument_error(2, ErrorMessage.INVALID_EXPECTING_AUTHORID, [])

    def test_with_non_refid_returns_failure(self) -> None:
        self.command_load(['mango', '5678', '9012'])
        self.assert_argument_error(1, ErrorMessage.INVALID_EXPECTING_REFID, [])
