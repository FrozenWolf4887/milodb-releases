# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from unittest import TestCase
from milodb_client.view.terminal.util.text import wrap_text

HELLO_WORLD: str = "Hello World"
QUICK_FOX: str = "quick brown fox jumps over the lazy dog"
MUSHROOM_CEILING: str = "The   mushroom          infested   ceiling"
INDENTED_ALICE: str = "    Alice was beginning to get very tired of sitting by her sister"
ALICE_PARAGRAPH: str = (
    "Alice was beginning to get very\n"
    "tired of sitting by her sister on\n"
    "the bank and of having nothing to do.")
HANGING_ALICE: str = "Alice   \twas beginning to get very tired of sitting by her sister"
HANGING_ALICE_PARAGRAPH: str = (
    "Alice   \twas beginning to get very tired of sitting by her sister\n"
    "on the bank and of having nothing to do.")

class TestWrapText(TestCase):
    def test_limit_longer_than_text_returns_as_is(self) -> None:
        self.check(HELLO_WORLD, len(HELLO_WORLD) + 2, HELLO_WORLD)
        self.check(HELLO_WORLD, len(HELLO_WORLD) + 1, HELLO_WORLD)
        self.check(QUICK_FOX, len(QUICK_FOX) + 2, QUICK_FOX)
        self.check(QUICK_FOX, len(QUICK_FOX) + 1, QUICK_FOX)

    def test_limit_same_as_text_returns_as_is(self) -> None:
        self.check(HELLO_WORLD, len(HELLO_WORLD), HELLO_WORLD)
        self.check(QUICK_FOX, len(QUICK_FOX), QUICK_FOX)

    def test_limit_one_less_than_text_returns_one_wrap(self) -> None:
        self.check(HELLO_WORLD, len(HELLO_WORLD) - 1, "Hello\nWorld")
        self.check(QUICK_FOX, len(QUICK_FOX) - 1, "quick brown fox jumps over the lazy\ndog")

    def test_limit_at_word_start_returns_one_wrap(self) -> None:
        self.check(HELLO_WORLD, HELLO_WORLD.find('World'), "Hello\nWorld")
        self.check(QUICK_FOX, QUICK_FOX.find('dog'), "quick brown fox jumps over the lazy\ndog")
        self.check(QUICK_FOX, QUICK_FOX.find('lazy'), "quick brown fox jumps over the\nlazy dog")
        self.check(QUICK_FOX, QUICK_FOX.find('the'), "quick brown fox jumps over\nthe lazy dog")

    def test_limit_at_space_start_returns_one_wrap(self) -> None:
        self.check(HELLO_WORLD, HELLO_WORLD.find('World') - 1, "Hello\nWorld")
        self.check(QUICK_FOX, QUICK_FOX.find('dog') - 1, "quick brown fox jumps over the lazy\ndog")
        self.check(QUICK_FOX, QUICK_FOX.find('lazy') - 1, "quick brown fox jumps over the\nlazy dog")
        self.check(QUICK_FOX, QUICK_FOX.find('the') - 1, "quick brown fox jumps over\nthe lazy dog")

    def test_wrapping_consumes_leading_and_trailing_space(self) -> None:
        self.check(MUSHROOM_CEILING, MUSHROOM_CEILING.find('infested'), "The   mushroom\ninfested   ceiling")
        self.check(MUSHROOM_CEILING, MUSHROOM_CEILING.find('infested') - 3, "The   mushroom\ninfested   ceiling")
        self.check(MUSHROOM_CEILING, MUSHROOM_CEILING.find('infested') + len('infested'), "The   mushroom          infested\nceiling")

    def test_wrapping_preserves_leading_space(self) -> None:
        self.check(INDENTED_ALICE, INDENTED_ALICE.find('sitting'), "    Alice was beginning to get very tired of\nsitting by her sister")

    def test_wrapping_occurs_for_each_long_line(self) -> None:
        self.check(QUICK_FOX, QUICK_FOX.find('fox') - 1, "quick brown\nfox jumps\nover the\nlazy dog")
        self.check(INDENTED_ALICE, INDENTED_ALICE.find('beginning'), "    Alice was\nbeginning to\nget very tired\nof sitting by\nher sister")

    def test_linefeeds_are_preserved_when_not_wrapping(self) -> None:
        self.check(ALICE_PARAGRAPH, len(ALICE_PARAGRAPH), ALICE_PARAGRAPH)

    def test_linefeeds_are_preserved_when_wrapping(self) -> None:
        self.check(ALICE_PARAGRAPH, ALICE_PARAGRAPH.find('get'), (
            "Alice was beginning to\n"
            "get very\n"
            "tired of sitting by her\n"
            "sister on\n"
            "the bank and of having\n"
            "nothing to do."))

    def test_hanging_text_wraps_with_indent(self) -> None:
        self.check(HANGING_ALICE, HANGING_ALICE.find('to'), (
            "Alice   was beginning\n"
            "        to get very\n"
            "        tired of\n"
            "        sitting by her\n"
            "        sister"))

    def test_hanging_is_cancelled_after_linefeed(self) -> None:
        self.check(HANGING_ALICE_PARAGRAPH, HANGING_ALICE_PARAGRAPH.find('to'), (
            "Alice   was beginning\n"
            "        to get very\n"
            "        tired of\n"
            "        sitting by her\n"
            "        sister\n"
            "on the bank and of\n"
            "having nothing to do."))

    def check(self, text: str, max_text_length: int, expected_text: str) -> None:
        result_text: str = wrap_text(text, max_text_length)
        self.assertEqual(result_text, expected_text)
        longest_line: int = max(len(line) for line in result_text.split('\n'))
        self.assertLessEqual(longest_line, max_text_length)
