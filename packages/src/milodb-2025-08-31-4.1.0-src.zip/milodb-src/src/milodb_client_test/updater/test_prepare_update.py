# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import time
import unittest
from pathlib import Path
from typing import TYPE_CHECKING, override
from unittest.mock import ANY, Mock, PropertyMock, call
from zipfile import ZipFile, ZipInfo
from mockito import when # type: ignore[import-untyped]
from milodb_client.updater.i_temp_directory import ITempDirectory, TempDirectoryError
from milodb_client.updater.manifest.common_manifest import IVersionNumber
from milodb_client.updater.manifest.local_manifest import ILocalManifest
from milodb_client.updater.manifest.update_directory import IAsset, IAssetRegister
from milodb_client.updater.manifest.version_manifest import ICoreFile
from milodb_client.updater.prepare_update import PrepareUpdateError, backup_files, determine_update_sequence, fetch_assets_to_temp_directory
from milodb_client.updater.update_strategy import BackupFileSet, ConfigFileChanges, CoreFileChanges, FileRename, UpdateStrategy
from milodb_client_test.test.fake_data import FAKE_DATA_A, FAKE_DATA_B, FAKE_DATA_C, FAKE_DATA_D, FAKE_DATA_F, FAKE_DATA_G, FAKE_HEXDIGEST_A, FAKE_HEXDIGEST_B, FAKE_HEXDIGEST_C, FAKE_HEXDIGEST_D, FAKE_HEXDIGEST_G
from milodb_client_test.test.test_directory import FakeFile, TestDirectory
from milodb_common.internet.i_scraper import IUrlScraper, ScrapeResult
from milodb_common.output.print.i_printer import IPrinter
from milodb_common_test.test.strict_mock import DataclassMock, InterfaceMock
if TYPE_CHECKING:
    from collections.abc import Sequence
    from milodb_client.updater.manifest.update_sequence_schema import UpdateSequenceSchema

FAKE_DIRECTORY_URL: str = 'https://example.com'

FAKE_URL_A: str = 'Morbi tincidunt augue interdum velit euismod in'
FAKE_URL_B: str = 'Elementum sagittis vitae et leo. Erat pellentesque adipiscing commodo elit at imperdiet dui'
FAKE_URL_C: str = 'Dui vivamus arcu felis bibendum ut tristique'
FAKE_URL_D: str = 'Consectetur a erat nam at lectus urna duis. Lacinia at quis risus sed vulputate odio'
FAKE_URL_E: str = 'Turpis nunc eget lorem dolor sed viverra'
FAKE_URL_F: str = 'Vitae justo eget magna fermentum iaculis'
FAKE_URL_FILEPATH_A: str = 'euismod'
FAKE_URL_FILEPATH_B: str = 'sagittis'
FAKE_URL_FILEPATH_C: str = 'tristique'
FAKE_URL_FILEPATH_D: str = 'lectus'
FAKE_URL_FILEPATH_E: str = 'vulputate'
FAKE_URL_FILEPATH_F: str = 'justo'

_STUB_DATETIME_2020: time.struct_time = time.strptime('2020-12-31 13:45:28', '%Y-%m-%d %H:%M:%S')

class TestPrepareUpdateFetchAssetsToTempDirectory(unittest.TestCase):
    @override
    def setUp(self) -> None:
        super().setUp()
        self.asset_register = InterfaceMock(IAssetRegister)
        self.temp_directory = InterfaceMock(ITempDirectory)
        self.url_scraper = InterfaceMock(IUrlScraper)
        self.printer = InterfaceMock(IPrinter)

        self.core_file_1 = InterfaceMock(ICoreFile,
            digest = PropertyMock(return_value=FAKE_HEXDIGEST_A),
            filename = PropertyMock(return_value=Path('mango.txt')),
        )
        self.core_file_2 = InterfaceMock(ICoreFile,
            digest = PropertyMock(return_value=FAKE_HEXDIGEST_B),
            filename = PropertyMock(return_value=Path('fruit.dat')),
        )
        self.core_file_3 = InterfaceMock(ICoreFile,
            digest = PropertyMock(return_value=FAKE_HEXDIGEST_C),
            filename = PropertyMock(return_value=Path('apple.exe')),
        )
        self.core_file_4 = InterfaceMock(ICoreFile,
            digest = PropertyMock(return_value=FAKE_HEXDIGEST_D),
            filename = PropertyMock(return_value=Path('pear.log')),
        )

    def test_given_no_file_changes_does_nothing(self) -> None:
        self.printer.writeln = Mock()

        update_strategy = DataclassMock(UpdateStrategy,
            core_file_changes = DataclassMock(CoreFileChanges,
                list_of_new_files_to_acquire = [],
                list_of_missing_files_to_acquire = [],
                list_of_changed_files_to_acquire = [],
            ),
        )

        list_of_files: Sequence[ICoreFile] = fetch_assets_to_temp_directory(update_strategy, FAKE_DIRECTORY_URL, self.asset_register, self.temp_directory, self.url_scraper, self.printer)

        self.assertFalse(list_of_files)
        self.printer.writeln.assert_called_once_with('Downloading 0 assets')

    def test_downloads_and_stores_file_to_temp_directory(self) -> None:
        self.printer.writeln = Mock()
        self.asset_register.resolve_asset_url = Mock()
        self.asset_register.assets = PropertyMock()
        self.asset_register.assets.get = Mock()
        self.url_scraper.try_scrape_url = Mock()
        self.temp_directory.store_file = Mock()
        asset_a = InterfaceMock(IAsset,
            size = PropertyMock(return_value=len(FAKE_DATA_A)),
        )
        when(self.asset_register).resolve_asset_url(FAKE_DIRECTORY_URL, self.core_file_1.digest).thenReturn(FAKE_URL_A)
        when(self.asset_register.assets).get(self.core_file_1.digest).thenReturn(asset_a)
        when(self.url_scraper).try_scrape_url(FAKE_URL_A, ANY).thenReturn(ScrapeResult(None, None, FAKE_DATA_A))

        update_strategy = DataclassMock(UpdateStrategy,
            core_file_changes = DataclassMock(CoreFileChanges,
                list_of_new_files_to_acquire = [self.core_file_1],
                list_of_missing_files_to_acquire = [],
                list_of_changed_files_to_acquire = [],
            ),
        )

        list_of_files: Sequence[ICoreFile] = fetch_assets_to_temp_directory(update_strategy, FAKE_DIRECTORY_URL, self.asset_register, self.temp_directory, self.url_scraper, self.printer)

        self.assertSequenceEqual([self.core_file_1], list_of_files)
        self.printer.writeln.assert_has_calls([
            call('Downloading 1 assets'),
            call(f"  Fetching asset '{self.core_file_1.digest}' for file '{self.core_file_1.filename}'"),
        ])
        self.temp_directory.store_file.assert_called_once_with(Path(str(self.core_file_1.digest)), FAKE_DATA_A)

    def test_downloads_and_stores_multiple_files_to_temp_directory(self) -> None:
        self.printer.writeln = Mock()
        self.asset_register.resolve_asset_url = Mock()
        self.asset_register.assets = PropertyMock()
        self.asset_register.assets.get = Mock()
        self.url_scraper.try_scrape_url = Mock()
        self.temp_directory.store_file = Mock()
        asset_a = InterfaceMock(IAsset,
            size = PropertyMock(return_value=len(FAKE_DATA_A)),
        )
        asset_b = InterfaceMock(IAsset,
            size = PropertyMock(return_value=len(FAKE_DATA_B)),
        )
        asset_c = InterfaceMock(IAsset,
            size = PropertyMock(return_value=len(FAKE_DATA_C)),
        )
        asset_d = InterfaceMock(IAsset,
            size = PropertyMock(return_value=len(FAKE_DATA_D)),
        )
        when(self.asset_register).resolve_asset_url(FAKE_DIRECTORY_URL, self.core_file_1.digest).thenReturn(FAKE_URL_A)
        when(self.asset_register).resolve_asset_url(FAKE_DIRECTORY_URL, self.core_file_2.digest).thenReturn(FAKE_URL_B)
        when(self.asset_register).resolve_asset_url(FAKE_DIRECTORY_URL, self.core_file_3.digest).thenReturn(FAKE_URL_C)
        when(self.asset_register).resolve_asset_url(FAKE_DIRECTORY_URL, self.core_file_4.digest).thenReturn(FAKE_URL_D)
        when(self.asset_register.assets).get(self.core_file_1.digest).thenReturn(asset_a)
        when(self.asset_register.assets).get(self.core_file_2.digest).thenReturn(asset_b)
        when(self.asset_register.assets).get(self.core_file_3.digest).thenReturn(asset_c)
        when(self.asset_register.assets).get(self.core_file_4.digest).thenReturn(asset_d)
        when(self.url_scraper).try_scrape_url(FAKE_URL_A, ANY).thenReturn(ScrapeResult(None, None, FAKE_DATA_A))
        when(self.url_scraper).try_scrape_url(FAKE_URL_B, ANY).thenReturn(ScrapeResult(None, None, FAKE_DATA_B))
        when(self.url_scraper).try_scrape_url(FAKE_URL_C, ANY).thenReturn(ScrapeResult(None, None, FAKE_DATA_C))
        when(self.url_scraper).try_scrape_url(FAKE_URL_D, ANY).thenReturn(ScrapeResult(None, None, FAKE_DATA_D))

        update_strategy = DataclassMock(UpdateStrategy,
            core_file_changes = DataclassMock(CoreFileChanges,
                list_of_new_files_to_acquire = [
                    self.core_file_4,
                ],
                list_of_missing_files_to_acquire = [
                    self.core_file_1,
                ],
                list_of_changed_files_to_acquire = [
                    self.core_file_2,
                    self.core_file_3,
                ],
            ),
        )

        list_of_files: Sequence[ICoreFile] = fetch_assets_to_temp_directory(update_strategy, FAKE_DIRECTORY_URL, self.asset_register, self.temp_directory, self.url_scraper, self.printer)

        self.assertCountEqual( [
                self.core_file_1,
                self.core_file_2,
                self.core_file_3,
                self.core_file_4,
            ], list_of_files)
        self.printer.writeln.assert_has_calls([
            call('Downloading 4 assets'),
            call(f"  Fetching asset '{self.core_file_1.digest}' for file '{self.core_file_1.filename}'"),
            call(f"  Fetching asset '{self.core_file_2.digest}' for file '{self.core_file_2.filename}'"),
            call(f"  Fetching asset '{self.core_file_3.digest}' for file '{self.core_file_3.filename}'"),
            call(f"  Fetching asset '{self.core_file_4.digest}' for file '{self.core_file_4.filename}'"),
        ], any_order=True)
        self.temp_directory.store_file.assert_has_calls([
            call(Path(str(self.core_file_1.digest)), FAKE_DATA_A),
            call(Path(str(self.core_file_2.digest)), FAKE_DATA_B),
            call(Path(str(self.core_file_3.digest)), FAKE_DATA_C),
            call(Path(str(self.core_file_4.digest)), FAKE_DATA_D),
        ], any_order=True)

    def test_raises_error_when_web_scraper_cannot_download_file(self) -> None:
        self.printer.writeln = Mock()
        self.asset_register.resolve_asset_url = Mock()
        self.asset_register.assets = PropertyMock()
        self.asset_register.assets.get = Mock()
        self.url_scraper.try_scrape_url = Mock()
        when(self.asset_register).resolve_asset_url(FAKE_DIRECTORY_URL, self.core_file_1.digest).thenReturn(FAKE_URL_A)
        when(self.asset_register.assets).get(self.core_file_1.digest).thenReturn(InterfaceMock(IAsset))
        when(self.url_scraper).try_scrape_url(FAKE_URL_A, ANY).thenReturn(ScrapeResult('error during scrape', None, b''))

        update_strategy = DataclassMock(UpdateStrategy,
            core_file_changes = DataclassMock(CoreFileChanges,
                list_of_new_files_to_acquire = [self.core_file_1],
                list_of_missing_files_to_acquire = [],
                list_of_changed_files_to_acquire = [],
            ),
        )

        with self.assertRaises(PrepareUpdateError) as ex:
            fetch_assets_to_temp_directory(update_strategy, FAKE_DIRECTORY_URL, self.asset_register, self.temp_directory, self.url_scraper, self.printer)

        self.assertEqual(f"Asset '{self.core_file_1.digest}' for file '{self.core_file_1.filename}' with URL '{FAKE_URL_A}' download error: error during scrape", str(ex.exception))

    def test_raises_error_when_file_cannot_be_stored_in_temp_directory(self) -> None:
        self.printer.writeln = Mock()
        self.asset_register.resolve_asset_url = Mock()
        self.asset_register.assets = PropertyMock()
        self.asset_register.assets.get = Mock()
        self.url_scraper.try_scrape_url = Mock()
        self.temp_directory.store_file = Mock()
        asset_a = InterfaceMock(IAsset,
            size = PropertyMock(return_value=len(FAKE_DATA_A)),
        )
        when(self.asset_register).resolve_asset_url(FAKE_DIRECTORY_URL, self.core_file_1.digest).thenReturn(FAKE_URL_A)
        when(self.asset_register.assets).get(self.core_file_1.digest).thenReturn(asset_a)
        when(self.url_scraper).try_scrape_url(FAKE_URL_A, ANY).thenReturn(ScrapeResult(None, None, FAKE_DATA_A))
        when(self.temp_directory).store_file(Path(str(self.core_file_1.digest)), FAKE_DATA_A).thenRaise(TempDirectoryError('some issue'))

        update_strategy = DataclassMock(UpdateStrategy,
            core_file_changes = DataclassMock(CoreFileChanges,
                list_of_new_files_to_acquire = [self.core_file_1],
                list_of_missing_files_to_acquire = [],
                list_of_changed_files_to_acquire = [],
            ),
        )

        with self.assertRaises(PrepareUpdateError) as ex:
            fetch_assets_to_temp_directory(update_strategy, FAKE_DIRECTORY_URL, self.asset_register, self.temp_directory, self.url_scraper, self.printer)

        self.assertEqual(f"Asset '{self.core_file_1.digest}' for file '{self.core_file_1.filename}' failed to store in temp directory: some issue", str(ex.exception))

    def test_raises_error_when_download_asset_has_size_mismatch(self) -> None:
        self.printer.writeln = Mock()
        self.asset_register.resolve_asset_url = Mock()
        self.asset_register.assets = PropertyMock()
        self.asset_register.assets.get = Mock()
        self.url_scraper.try_scrape_url = Mock()
        asset_f = InterfaceMock(IAsset,
            size = PropertyMock(return_value=len(FAKE_DATA_A) + 1),
        )
        when(self.asset_register).resolve_asset_url(FAKE_DIRECTORY_URL, self.core_file_1.digest).thenReturn(FAKE_URL_A)
        when(self.asset_register.assets).get(self.core_file_1.digest).thenReturn(asset_f)
        when(self.url_scraper).try_scrape_url(FAKE_URL_A, ANY).thenReturn(ScrapeResult(None, None, FAKE_DATA_A))

        update_strategy = DataclassMock(UpdateStrategy,
            core_file_changes = DataclassMock(CoreFileChanges,
                list_of_new_files_to_acquire = [self.core_file_1],
                list_of_missing_files_to_acquire = [],
                list_of_changed_files_to_acquire = [],
            ),
        )

        with self.assertRaises(PrepareUpdateError) as ex:
            fetch_assets_to_temp_directory(update_strategy, FAKE_DIRECTORY_URL, self.asset_register, self.temp_directory, self.url_scraper, self.printer)

        self.assertEqual(f"Asset '{self.core_file_1.digest}' for file '{self.core_file_1.filename}' size mismatch: Expected {len(FAKE_DATA_A)+1:,} bytes, got {len(FAKE_DATA_A):,} bytes", str(ex.exception))

    def test_raises_error_when_download_asset_has_digest_mismatch(self) -> None:
        self.printer.writeln = Mock()
        self.asset_register.resolve_asset_url = Mock()
        self.asset_register.assets = PropertyMock()
        self.asset_register.assets.get = Mock()
        self.url_scraper.try_scrape_url = Mock()
        asset_f = InterfaceMock(IAsset,
            size = PropertyMock(return_value=len(FAKE_DATA_F)),
        )
        when(self.asset_register).resolve_asset_url(FAKE_DIRECTORY_URL, self.core_file_1.digest).thenReturn(FAKE_URL_F)
        when(self.asset_register.assets).get(self.core_file_1.digest).thenReturn(asset_f)
        when(self.url_scraper).try_scrape_url(FAKE_URL_F, ANY).thenReturn(ScrapeResult(None, None, FAKE_DATA_G))

        update_strategy = DataclassMock(UpdateStrategy,
            core_file_changes = DataclassMock(CoreFileChanges,
                list_of_new_files_to_acquire = [self.core_file_1],
                list_of_missing_files_to_acquire = [],
                list_of_changed_files_to_acquire = [],
            ),
        )

        with self.assertRaises(PrepareUpdateError) as ex:
            fetch_assets_to_temp_directory(update_strategy, FAKE_DIRECTORY_URL, self.asset_register, self.temp_directory, self.url_scraper, self.printer)

        self.assertEqual(f"Asset '{self.core_file_1.digest}' for file '{self.core_file_1.filename}' integrity failure: Actual '{FAKE_HEXDIGEST_G}'", str(ex.exception))

class TestPrepareUpdateBackupFiles(unittest.TestCase):
    @override
    def setUp(self) -> None:
        super().setUp()

        self.timestamp: time.struct_time = _STUB_DATETIME_2020
        self.variant_name: str = 'bar'
        self.version_number = InterfaceMock(IVersionNumber)
        self.version_number.__str__ = Mock(return_value='hello-world') # type: ignore[method-assign]
        self.normal_printer = InterfaceMock(IPrinter,
            writeln = Mock(),
        )

    def test_creates_empty_backup_zip_file_in_subdirectory(self) -> None:
        with TestDirectory(self, 'backup') as backup_dir:
            update_strategy = DataclassMock(UpdateStrategy,
                root_directory = Path(),
                local_manifest = InterfaceMock(ILocalManifest,
                    variant_name = PropertyMock(return_value=self.variant_name),
                    version_number = PropertyMock(return_value=self.version_number),
                ),
                backup_file_set = DataclassMock(BackupFileSet,
                    list_of_core_files_to_backup = [],
                    list_of_config_files_to_backup = [],
                    list_of_clobbered_files_to_backup = [],
                ),
            )

            subdir: Path = Path('some', 'sub', 'dir')

            backup_files(update_strategy, backup_dir.path / subdir, self.timestamp, self.normal_printer)

            expected_zip_filename: Path = Path(subdir, f'{_date_text(self.timestamp)}_{self.variant_name}_{self.version_number}.zip')
            expected_zip_filepath: Path = backup_dir.path_of(expected_zip_filename)
            backup_dir.assert_file_exists(expected_zip_filename)

        self.normal_printer.writeln.assert_called_once_with(f"Backing up files to '{expected_zip_filepath}'")

    def test_saves_files_to_zip_file(self) -> None:
        with TestDirectory(self, 'source') as root_dir:
            file1 = FakeFile(root_dir, 'bongo.txt', 821)
            file2 = FakeFile(root_dir, 'fruit.exe', 19, is_executable=True)
            file3 = FakeFile(root_dir, Path('subdir1', 'something.dat'), 642)
            file4 = FakeFile(root_dir, Path('subdir2', 'subdir3', 'apple.map'), 2031)

            update_strategy = DataclassMock(UpdateStrategy,
                root_directory = root_dir.path,
                local_manifest = InterfaceMock(ILocalManifest,
                    variant_name = PropertyMock(return_value=self.variant_name),
                    version_number = PropertyMock(return_value=self.version_number),
                ),
                backup_file_set = DataclassMock(BackupFileSet,
                    list_of_core_files_to_backup = [file1.filename],
                    list_of_config_files_to_backup = [file2.filename, file3.filename],
                    list_of_clobbered_files_to_backup = [file4.filename],
                ),
            )

            with TestDirectory(self, 'backup') as backup_dir:
                backup_files(update_strategy, backup_dir.path, self.timestamp, self.normal_printer)

                expected_zip_filepath: Path = backup_dir.path.joinpath(f'{_date_text(self.timestamp)}_{self.variant_name}_{self.version_number}.zip')
                with TestDirectory(self, 'extraction') as extraction_dir:
                    _unzip_file(expected_zip_filepath, extraction_dir.path)

                    extraction_dir.assert_file_exists(file1, file1.size)
                    extraction_dir.assert_file_exists(file2, file2.size, is_executable=True)
                    extraction_dir.assert_file_exists(file3, file3.size)
                    extraction_dir.assert_file_exists(file4, file4.size)

    def test_raises_error_when_backup_directory_cannot_be_created(self) -> None:
        with TestDirectory(self) as path:
            not_a_directory = FakeFile(path, 'not-a-directory', 100)

            update_strategy = DataclassMock(UpdateStrategy,
                root_directory = path.path,
                local_manifest = InterfaceMock(ILocalManifest,
                    variant_name = PropertyMock(return_value=self.variant_name),
                    version_number = PropertyMock(return_value=self.version_number),
                ),
                backup_file_set = DataclassMock(BackupFileSet,
                    list_of_core_files_to_backup = [],
                    list_of_config_files_to_backup = [],
                    list_of_clobbered_files_to_backup = [],
                ),
            )

            with self.assertRaises(PrepareUpdateError):
                backup_files(update_strategy, not_a_directory.filepath, self.timestamp, self.normal_printer)

    def test_skips_files_that_do_not_exist(self) -> None:
        with TestDirectory(self, 'source') as root_dir:
            file1 = FakeFile(root_dir, 'bongo.txt', 821)
            file2 = FakeFile(root_dir, 'fruit.exe', 19, is_executable=True)
            file3 = FakeFile(root_dir, Path('subdir1', 'something.dat'), 642)
            file4 = FakeFile(root_dir, Path('subdir2', 'subdir3', 'apple.map'), 2031)

            update_strategy = DataclassMock(UpdateStrategy,
                root_directory = root_dir.path,
                local_manifest = InterfaceMock(ILocalManifest,
                    variant_name = PropertyMock(return_value=self.variant_name),
                    version_number = PropertyMock(return_value=self.version_number),
                ),
                backup_file_set = DataclassMock(BackupFileSet,
                    list_of_core_files_to_backup = [file1.filename, 'missing1.txt', file2.filename],
                    list_of_config_files_to_backup = [file3.filename, 'missing-directory/missing2.txt'],
                    list_of_clobbered_files_to_backup = ['some/missing/directory/missing3.txt', file4.filename],
                ),
            )

            with TestDirectory(self, 'backup') as backup_dir:
                backup_files(update_strategy, backup_dir.path, self.timestamp, self.normal_printer)

                expected_zip_filepath: Path = backup_dir.path.joinpath(f'{_date_text(self.timestamp)}_{self.variant_name}_{self.version_number}.zip')
                with TestDirectory(self, 'extraction') as extraction_dir:
                    _unzip_file(expected_zip_filepath, extraction_dir.path)

                    extraction_dir.assert_file_exists(file1, file1.size)
                    extraction_dir.assert_file_exists(file2, file2.size, is_executable=True)
                    extraction_dir.assert_file_exists(file3, file3.size)
                    extraction_dir.assert_file_exists(file4, file4.size)
                    extraction_dir.assert_file_missing('missing1.txt')
                    extraction_dir.assert_file_missing(Path('missing-directory', 'missing2.txt'))
                    extraction_dir.assert_file_missing(Path('some', 'missing-directory', 'missing3.txt'))

class TestPrepareUpdateDetermineUpdateSequence(unittest.TestCase):
    @override
    def setUp(self) -> None:
        super().setUp()
        self.update_strategy = DataclassMock(UpdateStrategy,
            root_directory = Path('test-directory'),
            core_file_changes = DataclassMock(CoreFileChanges,
                list_of_changed_files_to_acquire = [
                    InterfaceMock(ICoreFile,
                        filename = PropertyMock(return_value=Path('orange.txt')),
                    ),
                    InterfaceMock(ICoreFile,
                        filename = PropertyMock(return_value=Path('mango.dat')),
                    ),
                ],
                list_of_files_that_are_deprecated = [
                    Path('cheese.exe'),
                    Path('salad.log'),
                ],
            ),
            config_file_changes = DataclassMock(ConfigFileChanges,
                list_of_files_that_are_deprecated = [
                    Path('setup.cfg'),
                    Path('settings.json'),
                ],
                list_of_files_to_rename = [
                    DataclassMock(FileRename,
                        original_filename = Path('config.ini'),
                        new_filename = Path('config.toml'),
                    ),
                    DataclassMock(FileRename,
                        original_filename = Path('default.css'),
                        new_filename = Path('light.css'),
                    ),
                ],
            ),
            launch_executable = None,
        )

        self.list_of_files_to_emplace: Sequence[ICoreFile] = [
            InterfaceMock(ICoreFile,
                filename = PropertyMock(return_value=Path('winApp.exe')),
                digest = PropertyMock(return_value=FAKE_HEXDIGEST_A),
                exe = PropertyMock(return_value=False),
            ),
            InterfaceMock(ICoreFile,
                filename = PropertyMock(return_value=Path('linApp')),
                digest = PropertyMock(return_value=FAKE_HEXDIGEST_B),
                exe = PropertyMock(return_value=True),
            ),
        ]

        self.temp_directory = InterfaceMock(ITempDirectory,
            path = PropertyMock(return_value=Path('example', 'temp_directory')),
        )

    def test_records_root_directory_and_temp_directory(self) -> None:
        update_sequence: UpdateSequenceSchema = determine_update_sequence(self.update_strategy, self.temp_directory, self.list_of_files_to_emplace)

        self.assertEqual(self.update_strategy.root_directory, update_sequence.root_directory)
        self.assertEqual(self.temp_directory.path, update_sequence.temp_directory)

    def test_creates_delete_action_for_deleted_files(self) -> None:
        update_sequence: UpdateSequenceSchema = determine_update_sequence(self.update_strategy, self.temp_directory, self.list_of_files_to_emplace)

        list_of_actual_files_to_delete: Sequence[Path] = [
            file.filename for action in update_sequence.delete_files_actions.values() for file in action.files
        ]

        for action in update_sequence.delete_files_actions.values():
            for file in action.files:
                self.assertFalse(file.must_exist)

        self.assertCountEqual([
                Path('orange.txt'),
                Path('mango.dat'),
                Path('cheese.exe'),
                Path('salad.log'),
                Path('setup.cfg'),
                Path('settings.json'),
            ],
            list_of_actual_files_to_delete,
        )

    def test_creates_move_action_for_renamed_files(self) -> None:
        update_sequence: UpdateSequenceSchema = determine_update_sequence(self.update_strategy, self.temp_directory, self.list_of_files_to_emplace)

        list_of_actual_files_to_move: Sequence[tuple[Path, Path]] = [
            (file.original_filename, file.new_filename) for action in update_sequence.move_files_actions.values() for file in action.files
        ]

        for action in update_sequence.move_files_actions.values():
            for file in action.files:
                self.assertFalse(file.must_exist)

        self.assertCountEqual([
                (Path('config.ini'), Path('config.toml')),
                (Path('default.css'), Path('light.css')),
            ],
            list_of_actual_files_to_move)

    def test_creates_emplace_action_for_new_and_changed_files(self) -> None:
        update_sequence: UpdateSequenceSchema = determine_update_sequence(self.update_strategy, self.temp_directory, self.list_of_files_to_emplace)

        list_of_actual_files_to_emplace: Sequence[tuple[Path, Path]] = [
            (file.source_filename, file.target_filename) for action in update_sequence.emplace_files_actions.values() for file in action.files
        ]

        self.assertCountEqual([
                (Path(str(FAKE_HEXDIGEST_A)), Path('winApp.exe')),
                (Path(str(FAKE_HEXDIGEST_B)), Path('linApp')),
            ],
            list_of_actual_files_to_emplace)

    def test_actions_are_in_correct_key_order(self) -> None:
        update_sequence: UpdateSequenceSchema = determine_update_sequence(self.update_strategy, self.temp_directory, self.list_of_files_to_emplace)

        list_of_delete_action_keys: Sequence[int] = list(update_sequence.delete_files_actions)
        list_of_move_action_keys: Sequence[int] = list(update_sequence.move_files_actions)
        list_of_emplace_action_keys: Sequence[int] = list(update_sequence.emplace_files_actions)

        self.assertLess(max(list_of_delete_action_keys), min(list_of_move_action_keys))
        self.assertLess(max(list_of_move_action_keys), min(list_of_emplace_action_keys))

def _date_text(date: time.struct_time) -> str:
    return time.strftime("%Y-%m-%d_%H-%M-%S", date)

def _unzip_file(zip_filepath: Path, target_path: Path) -> None:
    with ZipFile(zip_filepath) as zip_file:
        zip_info: ZipInfo
        for zip_info in zip_file.filelist:
            zip_file.extract(zip_info, target_path)
            attr: int = zip_info.external_attr >> 16
            if attr:
                (target_path / zip_info.filename).chmod(zip_info.external_attr >> 16)
