# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import unittest
from collections.abc import Mapping, Sequence
from enum import Enum
from typing import TYPE_CHECKING, override
from unittest.mock import Mock
from milodb_common.parser import arg
from milodb_common.parser.arg_token_stream import ArgTokenStream
from milodb_common.parser.candidate_text import CandidateText
from milodb_common.parser.expanding_token_stream import ExpandingTokenStream
from milodb_common.util import enums
from milodb_common.variables.i_user_variables import IUserVariables
from milodb_common.view.terminal.command_framework.command_constructor import CommandConstructor
from milodb_common.view.terminal.command_framework.i_command import CommandLoader, CommandLoaderError, CommandLoaderResult
from milodb_common.view.terminal.command_framework.i_command_factory import ICommandFactory
from milodb_common.view.terminal.command_framework.i_help_info import IHelpInfo
from milodb_common.view.terminal.input.input_suggester import InputSuggester
from milodb_common_test.test.strict_mock import InterfaceMock
if TYPE_CHECKING:
    from prompt_toolkit.completion import Completion
    from milodb_common.parser.token import Token

class Colour(Enum):
    RED = 0
    BLACK = 1
    GREEN = 2
    BLUE = 3

class Food(Enum):
    PEACH = 10
    APPLE = 11
    ORANGE = 12
    PEAR = 13

class CompassPrimary(Enum):
    NORTH = 20
    EAST = 21
    SOUTH = 22
    WEST = 23

class CompassSecondary(Enum):
    EAST = 30
    WEST = 31

LIST_OF_COLOURS: Sequence[str] = enums.lowercase_names(Colour)
LIST_OF_FOOD: Sequence[str] = enums.lowercase_names(Food)
LIST_OF_COMPASS_PRIMARY: Sequence[str] = enums.lowercase_names(CompassPrimary)
LIST_OF_COMPASS_SECONDARY: Sequence[str] = enums.lowercase_names(CompassSecondary)

def fake_command() -> None:
    ...

def load_multicolour_command(arg_token_stream: ArgTokenStream) -> CommandLoaderResult:
    _ = arg.pop_list(arg_token_stream, arg.EnumFromName(Colour))
    return CommandLoaderResult(
        fake_command,
        CandidateText.space_delimited_list(LIST_OF_COLOURS))

def load_single_food_command(arg_token_stream: ArgTokenStream) -> CommandLoaderResult:
    _ = arg.pop(arg_token_stream, arg.EnumFromName(Food))
    arg.fail_if_not_empty(arg_token_stream)
    return CommandLoaderResult(
        fake_command,
        CandidateText.space_delimited_list(LIST_OF_FOOD))

def load_compass_command(arg_token_stream: ArgTokenStream) -> CommandLoaderResult:
    next_text: Sequence[str] = []

    compass_primary: CompassPrimary = arg.pop(arg_token_stream, arg.EnumFromName(CompassPrimary))
    if compass_primary in {CompassPrimary.NORTH, CompassPrimary.SOUTH}:
        if arg.pop_optional(arg_token_stream, arg.EnumFromName(CompassSecondary)):
            arg.fail_if_not_empty(arg_token_stream)
        else:
            next_text = enums.lowercase_names(CompassSecondary)
    else:
        arg.fail_if_not_empty(arg_token_stream)
        next_text = enums.lowercase_names(CompassSecondary)

    return CommandLoaderResult(
        fake_command,
        CandidateText.space_delimited_list(next_text))

class MockFailingCommand:
    _EXCEPTION_ON_TOKEN_NUMBER: int = 0
    _LIST_OF_CANDIDATE_TEXT: Sequence[CandidateText] = []

    @classmethod
    def reset(cls) -> None:
        MockFailingCommand._EXCEPTION_ON_TOKEN_NUMBER = 0
        MockFailingCommand._LIST_OF_CANDIDATE_TEXT = []

    @classmethod
    def set_exception_on_token(cls, token_number: int, list_of_candidate_text: Sequence[CandidateText]) -> None:
        MockFailingCommand._EXCEPTION_ON_TOKEN_NUMBER = token_number
        MockFailingCommand._LIST_OF_CANDIDATE_TEXT = list_of_candidate_text

    @classmethod
    def load(cls, token_stream: ExpandingTokenStream) -> CommandLoaderResult:
        token: Token | None = None
        for _ in range(MockFailingCommand._EXCEPTION_ON_TOKEN_NUMBER):
            token = token_stream.next()
        msg = 'failed'
        raise CommandLoaderError(msg, token, MockFailingCommand._LIST_OF_CANDIDATE_TEXT)

class MockCommandFactory(ICommandFactory):
    MAP_OF_COMMAND_NAME_TO_OBJECT: Mapping[str, CommandLoader] = {
        'colour': load_multicolour_command,
        'food': load_single_food_command,
        'compass': load_compass_command,
        'bad': MockFailingCommand.load,
    }

    LIST_OF_COMMAND_NAMES: Sequence[str] = list(MAP_OF_COMMAND_NAME_TO_OBJECT)

    @override
    def get_list_of_command_names(self) -> list[str]:
        return list(MockCommandFactory.MAP_OF_COMMAND_NAME_TO_OBJECT)

    @override
    def try_get_command_loader_from_name(self, command_name: str) -> CommandLoader | None:
        return MockCommandFactory.MAP_OF_COMMAND_NAME_TO_OBJECT.get(command_name)

    @override
    def try_get_command_help_from_name(self, command_name: str) -> IHelpInfo | None:
        return None

class TestInputSuggester(unittest.TestCase):
    @override
    def setUp(self) -> None:
        MockFailingCommand.reset()

        self.dictionary_of_variables: dict[str, str] = {}

        mock_user_variables = InterfaceMock(IUserVariables,
            try_retrieve = Mock(side_effect=self.dictionary_of_variables.get),
            get_list_of_names = Mock(side_effect=lambda: list(self.dictionary_of_variables)),
        )

        command_factory: MockCommandFactory = MockCommandFactory()
        command_constructor: CommandConstructor = CommandConstructor(command_factory)

        self._input_suggester: InputSuggester = InputSuggester(command_constructor, mock_user_variables)

    def check(self, text_with_placeholders: str, list_of_expected_text: Sequence[str]) -> None:
        text_either_side_of_cursor: Sequence[str] = text_with_placeholders.split('|')
        self.assertEqual(2, len(text_either_side_of_cursor), f"Input text '{text_with_placeholders}' missing or excessive cursor placeholder '|'")

        text_left_of_cursor: str = text_either_side_of_cursor[0]
        text_right_of_cursor: str = text_either_side_of_cursor[1]

        text_either_side_of_insertion_point: Sequence[str] = text_left_of_cursor.split('@')
        self.assertEqual(2, len(text_either_side_of_insertion_point), f"Input text '{text_with_placeholders}' missing or excessive insertion placeholder '@'")

        text_left_of_insertion_point: str = text_either_side_of_insertion_point[0]
        text_right_of_insertion_point: str = text_either_side_of_insertion_point[1]

        text: str = text_left_of_insertion_point + text_right_of_insertion_point + text_right_of_cursor
        insertion_index: int = len(text_left_of_insertion_point)
        cursor_index: int = len(text_left_of_insertion_point) + len(text_right_of_insertion_point)

        list_of_completions: Sequence[Completion] = self._input_suggester.get_possible_completions(text, cursor_index)

        self.assertEqual(len(list_of_expected_text), len(list_of_completions), f'Expected {len(list_of_expected_text)} completions but got {len(list_of_completions)}')

        list_of_delimited_expected_text: Sequence[str] = [text + ' ' for text in list_of_expected_text]

        i: int
        completion: Completion
        for i, completion in enumerate(list_of_completions):
            self.assertEqual(insertion_index - cursor_index, completion.start_position,
                             f'Mismatched relative insertion index for completion #{i}. Expected {insertion_index - cursor_index} but got {completion.start_position}')
            self.assertEqual(list_of_delimited_expected_text[i], completion.text,
                             f"Mismatched completion text for completion #{i}. Expected '{list_of_delimited_expected_text[i]}' but got '{completion.text}'")

    def test_command_name_completion_provides_suggestions(self) -> None:
        self.check('@|', MockCommandFactory.LIST_OF_COMMAND_NAMES)
        self.check('@c|', ['colour', 'compass'])
        self.check('@co|', ['colour', 'compass'])
        self.check('@col|', ['colour'])
        self.check('@c|o', ['colour', 'compass'])
        self.check('@c|ol', ['colour', 'compass'])
        self.check('@co|l', ['colour', 'compass'])
        self.check('@colour|', ['colour'])
        self.check('@|z', MockCommandFactory.LIST_OF_COMMAND_NAMES)
        self.check('@z|', [])
        self.check('@c|zz', ['colour', 'compass'])
        self.check('@col|zz', ['colour'])

    def test_colour_command_suggests_colours(self) -> None:
        self.check('colour @|', LIST_OF_COLOURS)
        self.check('colour @r|', ['red'])
        self.check('colour @red|', ['red'])
        self.check('colour @reds|', [])
        self.check('colour @g|', ['green'])
        self.check('colour @green|', ['green'])
        self.check('colour @greens|', [])
        self.check('colour @b|', ['black', 'blue'])
        self.check('colour @bl|', ['black', 'blue'])
        self.check('colour @blu|', ['blue'])
        self.check('colour @blue|', ['blue'])
        self.check('colour @bluez|', [])
        self.check('colour @|blue', LIST_OF_COLOURS)
        self.check('colour @bl|ue', ['black', 'blue'])
        self.check('colour @bl|uez', ['black', 'blue'])
        self.check('colour @bla|', ['black'])
        self.check('colour @black|', ['black'])
        self.check('colour @blackq|', [])

    def test_colour_command_suggests_colours_for_subsequent_token(self) -> None:
        self.check('colour red @|', ['red', 'black', 'green', 'blue'])
        self.check('colour red @bl|', ['black', 'blue'])
        self.check('colour red @blue|', ['blue'])
        self.check('colour red green blue black @|', ['red', 'black', 'green', 'blue'])

    def test_load_error_provides_suggestions_without_error_token(self) -> None:
        MockFailingCommand.set_exception_on_token(0, [])
        self.check('bad @|', [])
        self.check('bad @|ness', [])
        MockFailingCommand.set_exception_on_token(1, [])
        self.check('bad @ness|', [])
        MockFailingCommand.set_exception_on_token(0, CandidateText.space_delimited_list(['cat', 'dog']))
        self.check('bad @|', ['cat', 'dog'])
        MockFailingCommand.set_exception_on_token(1, CandidateText.space_delimited_list(['cat', 'dog']))
        self.check('bad @d|', ['dog'])
        self.check('bad @d|izzy', ['dog'])

    def test_command_expansion_suggests_primary_compass_directions(self) -> None:
        self.dictionary_of_variables['cmd'] = 'compass'
        self.check('$cmd @|', LIST_OF_COMPASS_PRIMARY)
        self.check('$cmd @|zap', LIST_OF_COMPASS_PRIMARY)
        self.check('$cmd @n|', ['north'])
        self.check('$cmd @e|', ['east'])
        self.check('$cmd @sout|', ['south'])
        self.check('$cmd @s|zap', ['south'])

    def test_command_expansion_suggests_secondary_compass_directions(self) -> None:
        self.dictionary_of_variables['cmd'] = 'compass'
        self.check('$cmd north @|', LIST_OF_COMPASS_SECONDARY)
        self.check('$cmd north @|zap', LIST_OF_COMPASS_SECONDARY)
        self.check('$cmd south @w|', ['west'])
        self.check('$cmd south @w|zap', ['west'])

    def test_parameter_does_not_suggest_variables_without_prefix(self) -> None:
        self.dictionary_of_variables['tasty'] = 'apple'
        self.dictionary_of_variables['fatty'] = 'avocado'
        self.dictionary_of_variables['sharp'] = 'lemon'
        self.dictionary_of_variables['sauce'] = 'tomato'
        self.check('food @|', LIST_OF_FOOD)
        self.check('food @|zap', LIST_OF_FOOD)
        self.check('food @|$tasty', LIST_OF_FOOD)

    def test_parameter_suggests_variables_with_prefix(self) -> None:
        self.dictionary_of_variables['tasty'] = 'apple'
        self.dictionary_of_variables['fatty'] = 'avocado'
        self.dictionary_of_variables['sharp'] = 'lemon'
        self.dictionary_of_variables['sauce'] = 'tomato'
        list_of_variables: Sequence[str] = [f'${name}' for name in self.dictionary_of_variables]
        self.check('food @$|', list_of_variables)
        self.check('food @$|zap', list_of_variables)
        self.check('food @$s|', ['$sharp', '$sauce'])
        self.check('food @$s|zap', ['$sharp', '$sauce'])

    def test_command_expansion_suggests_secondary_compass_directions_after_expansion(self) -> None:
        self.dictionary_of_variables['primaryDirection'] = 'east'
        self.check('compass $primaryDirection @|', LIST_OF_COMPASS_SECONDARY)
        self.check('compass $primaryDirection @|zap', LIST_OF_COMPASS_SECONDARY)
        self.dictionary_of_variables['primaryDirection'] = 'north'
        self.check('compass $primaryDirection @w|', ['west'])
        self.check('compass $primaryDirection @w|zap', ['west'])
