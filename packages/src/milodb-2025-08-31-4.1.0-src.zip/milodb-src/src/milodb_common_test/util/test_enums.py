# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import unittest
from enum import Enum
from milodb_common.util import enums

# pylint: disable=C0103:invalid-name
class Speed(Enum):
    FAST = 1
    slow = 'Two'
    STop = 3.0
# pylint: enable=C0103:invalid-name

class TestEnums(unittest.TestCase):
    def test_names(self) -> None:
        self.assertCountEqual([
            'FAST',
            'slow',
            'STop',
        ], enums.names(Speed))

    def test_lowercase_names(self) -> None:
        self.assertCountEqual([
            'fast',
            'slow',
            'stop',
        ], enums.lowercase_names(Speed))

    def test_uppercase_names(self) -> None:
        self.assertCountEqual([
            'FAST',
            'SLOW',
            'STOP',
        ], enums.uppercase_names(Speed))

    def test_text_of_values(self) -> None:
        self.assertCountEqual([
            '1',
            'Two',
            '3.0',
        ], enums.text_of_values(Speed))

    def test_lowercase_text_of_values(self) -> None:
        self.assertCountEqual([
            '1',
            'two',
            '3.0',
        ], enums.lowercase_text_of_values(Speed))

    def test_uppercase_text_of_values(self) -> None:
        self.assertCountEqual([
            '1',
            'TWO',
            '3.0',
        ], enums.uppercase_text_of_values(Speed))

    def test_try_lookup_name_case_sensitive_matches(self) -> None:
        self.assertEqual(Speed.FAST, enums.try_lookup_name(Speed, 'FAST', case_sensitive=True))
        self.assertEqual(Speed.slow, enums.try_lookup_name(Speed, 'slow', case_sensitive=True))
        self.assertEqual(Speed.STop, enums.try_lookup_name(Speed, 'STop', case_sensitive=True))

    def test_try_lookup_name_case_sensitive_mismatches(self) -> None:
        self.assertIsNone(enums.try_lookup_name(Speed, 'fast', case_sensitive=True))
        self.assertIsNone(enums.try_lookup_name(Speed, 'SLOW', case_sensitive=True))
        self.assertIsNone(enums.try_lookup_name(Speed, 'stop', case_sensitive=True))

    def test_try_lookup_name_case_insensitive_matches(self) -> None:
        self.assertEqual(Speed.FAST, enums.try_lookup_name(Speed, 'Fast', case_sensitive=False))
        self.assertEqual(Speed.slow, enums.try_lookup_name(Speed, 'slOW', case_sensitive=False))
        self.assertEqual(Speed.STop, enums.try_lookup_name(Speed, 'StOp', case_sensitive=False))

    def test_try_lookup_name_case_insensitive_mismatches(self) -> None:
        self.assertIsNone(enums.try_lookup_name(Speed, 'mast', case_sensitive=False))
        self.assertIsNone(enums.try_lookup_name(Speed, 'slOg', case_sensitive=False))
        self.assertIsNone(enums.try_lookup_name(Speed, 'SPOT', case_sensitive=False))
