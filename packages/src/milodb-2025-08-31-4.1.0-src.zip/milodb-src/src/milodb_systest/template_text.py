# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import re
from collections.abc import Callable

_KEYWORD_PATTERN: re.Pattern[str] = re.compile(r'\~([A-Z]{3}):([^\~]+)\~')

class TemplateText:
    def __init__(self, keyed_text: str) -> None:
        self._keyed_text: str = keyed_text

    def expand(self, **kwargs: str | float | Callable[[str], str]) -> str:
        def on_replace(match: re.Match[str]) -> str:
            var_name: str = match.group(1)
            var_value: str = match.group(2)
            if var_name in kwargs:
                action: object = kwargs[var_name]
                var_value = action(var_value) if callable(action) else str(action)
            return var_value

        return _KEYWORD_PATTERN.sub(on_replace, self._keyed_text)
