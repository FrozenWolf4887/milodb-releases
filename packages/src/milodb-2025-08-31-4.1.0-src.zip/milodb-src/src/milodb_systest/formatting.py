# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
class Ansi:
    @staticmethod
    def highlighted(text: str) -> str:
        return Ansi.coloured('4;31', text)

    @staticmethod
    def coloured(color_code: str, text: str) -> str:
        return f'\x1b[{color_code}m{text}\x1b[0m'

class BBCode:
    @staticmethod
    def highlighted(text: str) -> str:
        return BBCode.coloured('#FF0000', text)

    @staticmethod
    def coloured(color_code: str, text: str) -> str:
        return f'[b][color={color_code}]{text}[/color][/b]'

class Html:
    @staticmethod
    def highlighted(text: str) -> str:
        return f'<span class="matchingText">{text}</span>'

class Url:
    @staticmethod
    def tease(tease_id: int) -> str:
        return f'https://milovana.com/webteases/showtease.php?id={tease_id}'

    @staticmethod
    def author(author_id: int) -> str:
        return f'https://milovana.com/forum/memberlist.php?mode=viewprofile&u={author_id}'
