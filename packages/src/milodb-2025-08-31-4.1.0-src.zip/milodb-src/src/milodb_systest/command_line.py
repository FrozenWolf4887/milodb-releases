# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from collections.abc import Iterable, Mapping, MutableSequence
from typing import TYPE_CHECKING
from milodb_systest.options import Options
if TYPE_CHECKING:
    from collections.abc import Callable

class CommandLine:
    def __init__(self, list_of_args: Iterable[str]) -> None:
        self._is_help_requested: bool = False
        self._is_development_version: bool = False
        self._has_existing_config: bool = True
        self._has_existing_variables: bool = True
        self._error_message: str | None = ''

        self._load_from_command_line(list_of_args)

    def is_valid(self) -> bool:
        return self._error_message is None

    def is_help_requested(self) -> bool:
        return self._is_help_requested

    def get_error_message(self) -> str:
        return self._error_message or ''

    def get_options(self) -> Options:
        options: Options = Options()
        options.is_development_version = self._is_development_version
        options.has_existing_config = self._has_existing_config
        options.has_existing_variables = self._has_existing_variables
        return options

    @staticmethod
    def get_syntax_text() -> str:
        return (
            'Syntax: systest.py [options]\n'
            'Options:\n'
            '  -h   --help        Display this help.\n'
            '  -d   --dev         MiloDB is development version.\n'
            '  -nc  --noconfig    Config file does not yet exist.\n'
            '  -nv  --novars      Variables file does not exist yet.'
        )

    def _load_from_command_line(self, list_of_args: Iterable[str]) -> None:
        list_of_remaining_args: MutableSequence[str] = list(list_of_args)
        self._error_message = None

        if '-h' in list_of_remaining_args or '--help' in list_of_remaining_args:
            self._is_help_requested = True
            return

        map_of_switch_parsers: Mapping[str, Callable[[str, MutableSequence[str]], None]] = {
            '-d': self._parse_development_switch, '--dev': self._parse_development_switch,
            '-nc': self._parse_no_config_switch, '--noconfig': self._parse_no_config_switch,
            '-nv': self._parse_no_vars_switch, '--novars': self._parse_no_vars_switch,
        }

        while list_of_remaining_args and not self._error_message:
            switch: str = list_of_remaining_args.pop(0)
            switch_handler: Callable[[str, MutableSequence[str]], None] | None = map_of_switch_parsers.get(switch)
            if switch_handler:
                switch_handler(switch, list_of_remaining_args)
            else:
                self._error_message = f"Unknown switch '{switch}'"

    def _parse_development_switch(self, _switch: str, _list_of_remaining_args: MutableSequence[str]) -> None:
        self._is_development_version = True

    def _parse_no_config_switch(self, _switch: str, _list_of_remaining_args: MutableSequence[str]) -> None:
        self._has_existing_config = False

    def _parse_no_vars_switch(self, _switch: str, _list_of_remaining_args: MutableSequence[str]) -> None:
        self._has_existing_variables = False
