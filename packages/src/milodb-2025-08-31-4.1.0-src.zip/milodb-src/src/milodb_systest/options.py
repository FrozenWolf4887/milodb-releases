# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
class Options:
    is_development_version: bool = False
    has_existing_config: bool = False
    has_existing_variables: bool = False
