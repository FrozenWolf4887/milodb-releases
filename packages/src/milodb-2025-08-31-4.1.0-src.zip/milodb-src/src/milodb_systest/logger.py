# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from __future__ import annotations
from datetime import UTC, datetime
from typing import IO

_PASS_COLOUR: str = '\x1b[32m'
_FAIL_COLOUR: str = '\x1b[31;1m'
_NOTE_COLOUR: str = '\x1b[33m'
_RESET_COLOUR: str = '\x1b[0m'

_INFO_TEXT: str = 'INFO'
_PASS_TEXT: str = f'{_PASS_COLOUR}PASS{_RESET_COLOUR}'
_FAIL_TEXT: str = f'{_FAIL_COLOUR}FAIL{_RESET_COLOUR}'
_NOTE_TEXT: str = f'{_NOTE_COLOUR}NOTE{_RESET_COLOUR}'

class Logger:
    def __init__(self, file: IO[str]) -> None:
        self._file: IO[str] = file

    def log_info(self, message: str) -> None:
        self._log(f'{_INFO_TEXT}: {message}')

    def log_injection(self, message: str) -> None:
        self._log(f'{_INFO_TEXT}: <inject> {message}')

    def log_pass_output(self, message: str) -> None:
        self._log(f'{_PASS_TEXT}: <output> {message}')

    def log_pass_no_output(self) -> None:
        self._log(f'{_PASS_TEXT}: <no output>')

    def log_fail(self, message: str) -> None:
        self._log(f'{_FAIL_TEXT}: {message}')

    def log_fail_output(self, message: str) -> None:
        self._log(f'{_FAIL_TEXT}: <output> {message}')

    def log_fail_no_output(self) -> None:
        self._log(f'{_FAIL_TEXT}: <no output>')

    def log_note(self, message: str) -> None:
        self._log(f'{_NOTE_TEXT}: {message}')

    def _log(self, message: str) -> None:
        timestamp: str = datetime.now(tz=UTC).astimezone().strftime("%Y-%m-%d %H:%M:%S.%f")
        timestamped_message: str = f'{timestamp}  {message}'
        self._file.write(f'{timestamped_message}\n')
        print(timestamped_message)
