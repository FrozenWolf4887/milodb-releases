# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import tkinter as tk
from abc import ABC, abstractmethod
from tkinter import ttk
from typing import override
from milodb_client.view.gui import general_colours, general_font
from milodb_client.view.gui.frame_widgets import WrappingLabel
from milodb_client.view.gui.log_dialog import LogDialog
from milodb_client.view.gui.scrollable_frame import ScrollableFrame
from milodb_client.view.gui.util.datum import IDatum
from milodb_client.view.gui.util.datum_tk_binding import DatumBoolTkBinding
from milodb_client.view.gui.window_widgets import ModalDialog
from milodb_client.view.gui.wrapped_text import WrappedText
from milodb_common.config.framework import IConfig, IConfigGroup, IConfigLeaf, IConfigSetLeaf, IPersistentConfig

_COL_PANEL_BACK: str = general_colours.PANEL_BACK
_COL_TABLE_HEADER_BACK: str = general_colours.HEADER_BACK
_COL_TABLE_HEADER_FORE: str = general_colours.HEADER_FORE
_COL_TABLE_GROUP_BACK: str = '#434'
_COL_TABLE_GROUP_FORE: str = general_colours.HEADER_FORE
_COL_TABLE_CONTENT_BACK: str = general_colours.VALUE_BACK
_COL_TABLE_CONTENT_FORE: str = general_colours.VALUE_FORE
_COL_EDIT_BACK: str = general_colours.VALUE_BACK
_COL_EDIT_FORE: str = general_colours.VALUE_FORE
_COL_SELECT_BACK: str = general_colours.VALUE_SELECTED_BACK
_COL_SELECT_FORE: str = general_colours.VALUE_SELECTED_FORE

_TABLE_CELL_X_PADDING: int = 4
_TABLE_CELL_Y_PADDING: int = 1
_TABLE_BUTTON_X_PADDING: int = 4
_TABLE_BUTTON_Y_PADDING: int = 0
_TABLE_GRIDLINE_THICKNESS: int = 1
_DEPTH_INDENT_AMOUNT: int = 6

_CANCEL_BUTTON_COLUMN: int = 0
_SAVE_BUTTON_COLUMN: int = 1

# spell-checker: ignore activebackground activeforeground borderwidth columnspan highlightthickness insertbackground padx pady selectbackground selectcolor selectforeground

class ConfigDialog(ModalDialog):
    def __init__(self, master: tk.Tk, config: IPersistentConfig, config_schema: IConfigGroup, debug_enabled_ref: IDatum[bool]) -> None:
        super().__init__(master, width=800, title='Configuration')
        self._config: IPersistentConfig = config
        self._config_schema: IConfigGroup = config_schema
        self._debug_enabled_ref: IDatum[bool] = debug_enabled_ref

        self._list_of_datum_tk_bindings: list[DatumBoolTkBinding] = []

        notebook: ttk.Notebook = ttk.Notebook(self.content_frame)
        notebook.pack(fill=tk.BOTH, expand=True)
        persistent_frame: ScrollableFrame = self._create_persistent_frame(notebook)
        transient_frame: ScrollableFrame = self._create_transient_frame(notebook)
        notebook.add(persistent_frame.top_frame, text='Persistent')
        notebook.add(transient_frame.top_frame, text='Transient')
        self._persistent_tab: tk.Misc = persistent_frame.content_frame
        self._transient_tab: tk.Misc = transient_frame.content_frame

        self.add_button('Cancel', column=_CANCEL_BUTTON_COLUMN, command=self.destroy)
        self.add_button('Save', column=_SAVE_BUTTON_COLUMN, command=self._on_save)

    @override
    def destroy(self) -> None:
        binding: DatumBoolTkBinding
        for binding in self._list_of_datum_tk_bindings:
            binding.destroy()
        super().destroy()

    def _create_persistent_frame(self, master: tk.Misc) -> ScrollableFrame:
        frame: ScrollableFrame = ScrollableFrame(master, background=_COL_PANEL_BACK)

        tk.Label(frame.content_frame, text='Config Item', anchor=tk.W, justify=tk.LEFT, fg=_COL_TABLE_HEADER_FORE, bg=_COL_TABLE_HEADER_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=0, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
        tk.Label(frame.content_frame, text='Value', anchor=tk.W, justify=tk.LEFT, fg=_COL_TABLE_HEADER_FORE, bg=_COL_TABLE_HEADER_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=0, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
        tk.Label(frame.content_frame, text='Status', anchor=tk.W, justify=tk.LEFT, fg=_COL_TABLE_HEADER_FORE, bg=_COL_TABLE_HEADER_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=0, column=2, columnspan=2, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)

        frame.content_frame.columnconfigure(1, weight=1)

        self._list_of_leaf_viewers: list[_LeafViewer] = []
        self._populate_rows(frame.content_frame, 1, 0, self._config_schema)
        frame.set_child_bindtags_for_scrolling()

        return frame

    def _create_transient_frame(self, master: tk.Misc) -> ScrollableFrame:
        frame: ScrollableFrame = ScrollableFrame(master, background=_COL_PANEL_BACK)

        tk.Label(frame.content_frame, text='Setting', anchor=tk.W, justify=tk.LEFT, fg=_COL_TABLE_HEADER_FORE, bg=_COL_TABLE_HEADER_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=0, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
        tk.Label(frame.content_frame, text='Description', anchor=tk.W, justify=tk.LEFT, fg=_COL_TABLE_HEADER_FORE, bg=_COL_TABLE_HEADER_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=0, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)

        debug_launch: tk.BooleanVar = tk.BooleanVar(master, value=self._debug_enabled_ref.get())
        tk.Checkbutton(frame.content_frame, text='Debug launch', foreground=_COL_TABLE_CONTENT_FORE, background=_COL_TABLE_CONTENT_BACK, selectcolor=_COL_PANEL_BACK, activeforeground=_COL_TABLE_CONTENT_FORE, activebackground=_COL_TABLE_CONTENT_BACK, borderwidth=0, highlightthickness=0, variable=debug_launch).grid(row=1, column=0, sticky=tk.W)
        WrappingLabel(frame.content_frame, text=(
                'When opening a tease, author profile, or author tease list,'
                ' a dialog will typically popup and disappear if the launch was successful.'
                ' Setting this flag will display additional information about the launch attempt'
                ' and leave the dialog open.'
            ), anchor=tk.W, justify=tk.LEFT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=1, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
        self._list_of_datum_tk_bindings.append(DatumBoolTkBinding(self._debug_enabled_ref, debug_launch, on_change_callback=None))

        frame.content_frame.columnconfigure(1, weight=1)
        frame.set_child_bindtags_for_scrolling()

        return frame

    def _populate_rows(self, master: tk.Misc, row: int, depth: int, config_group: IConfigGroup) -> int:
        indent: str = ' ' * (depth * _DEPTH_INDENT_AMOUNT)
        config_leaf: IConfigLeaf
        for config_leaf in config_group.list_of_child_leaves:
            tk.Label(master, text=f'{indent}{config_leaf.key_name}', anchor=tk.W, justify=tk.LEFT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            self._add_row_leaf(master, config_leaf, row=row)
            row += 1
        config_subgroup: IConfigGroup
        for config_subgroup in config_group.list_of_child_groups:
            tk.Label(master, text=f'{indent}{config_subgroup.key_name}', anchor=tk.W, justify=tk.LEFT, fg=_COL_TABLE_GROUP_FORE, bg=_COL_TABLE_GROUP_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            tk.Frame(master, bg=_COL_PANEL_BACK).grid(row=row, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            row = self._populate_rows(master, row + 1, depth + 1, config_subgroup)
        return row

    def _add_row_leaf(self, master: tk.Misc, config_leaf: IConfigLeaf, *, row: int) -> None:
        viewer: _LeafViewer
        if config_leaf.is_protected:
            viewer = _ProtectedLeafViewer(config_leaf, self._config, master, row=row)
        elif isinstance(config_leaf, IConfigSetLeaf):
            viewer = _SetLeafEditor(config_leaf, self._config, master, row=row)
        else:
            viewer = _TextLeafEditor(config_leaf, self._config, master, row=row)
        self._list_of_leaf_viewers.append(viewer)

    def _on_save(self) -> None:
        viewer: _LeafViewer
        for viewer in self._list_of_leaf_viewers:
            if isinstance(viewer, _LeafEditor):
                viewer.save_value()
        log_dialog: LogDialog = LogDialog(self.content_frame.winfo_toplevel())
        self._config.save(log_dialog.log_text.normal_printer, log_dialog.log_text.warning_printer, log_dialog.log_text.error_printer)
        if log_dialog.log_text.any_warnings_or_errors:
            log_dialog.show_okay_button()
        else:
            log_dialog.destroy()
            self.destroy()

class _LeafViewer(ABC):
    @abstractmethod
    def get_value(self) -> str:
        pass

class _ProtectedLeafViewer(_LeafViewer):
    def __init__(self, config_leaf: IConfigLeaf, config: IConfig, parent: tk.Misc, *, row: int) -> None:
        self._text: str = config_leaf.fetch_value_or_default(config)
        self._label: WrappingLabel = WrappingLabel(parent, text=self._text, anchor=tk.W, justify=tk.LEFT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING)
        self._label.grid(row=row, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)

    @override
    def get_value(self) -> str:
        return self._text

class _LeafEditor(_LeafViewer):
    def __init__(self, config_leaf: IConfigLeaf, config: IPersistentConfig, parent: tk.Misc, *, row: int) -> None:
        self._config_leaf: IConfigLeaf = config_leaf
        self._config: IPersistentConfig = config

        self._revert_button: tk.Button = tk.Button(parent, text='Revert', padx=_TABLE_BUTTON_X_PADDING, pady=_TABLE_BUTTON_Y_PADDING, command=self._on_revert)
        self._revert_button.grid(row=row, column=2, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.EW)
        self._reset_button: tk.Button = tk.Button(parent, text='Reset', padx=_TABLE_BUTTON_X_PADDING, pady=_TABLE_BUTTON_Y_PADDING, command=self._on_reset)
        self._reset_button.grid(row=row, column=3, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.EW)

    def save_value(self) -> None:
        text: str = self.get_value()
        self._config_leaf.try_set_value(self._config, text)

    @abstractmethod
    def _replace_value_and_focus(self, text: str) -> None:
        pass

    def _on_revert(self) -> None:
        text: str = self._config_leaf.fetch_value_or_default(self._config)
        self._replace_value_and_focus(text)
        self._revert_button.grid_remove()
        self._update_reset_button(text)

    def _on_reset(self) -> None:
        text: str = self._config_leaf.default_value
        self._replace_value_and_focus(text)
        self._reset_button.grid_remove()
        self._update_revert_button(text)

    def _update_revert_button(self, text: str) -> None:
        if text == self._config_leaf.fetch_value_or_default(self._config):
            self._revert_button.grid_remove()
        else:
            self._revert_button.grid()

    def _update_reset_button(self, text: str) -> None:
        if text == self._config_leaf.default_value:
            self._reset_button.grid_remove()
        else:
            self._reset_button.grid()

class _TextLeafEditor(_LeafEditor):
    def __init__(self, config_leaf: IConfigLeaf, config: IPersistentConfig, parent: tk.Misc, *, row: int) -> None:
        super().__init__(config_leaf, config, parent, row=row)

        value: str = self._config_leaf.fetch_value_or_default(self._config)

        self._text_widget: WrappedText = WrappedText(parent, line_count='dynamic', foreground=_COL_EDIT_FORE, background=_COL_EDIT_BACK, insertbackground=_COL_EDIT_FORE, selectbackground=_COL_SELECT_BACK, selectforeground=_COL_SELECT_FORE, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING)
        self._text_widget.grid(row=row, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
        self._text_widget.insert('1.0', value)
        self._text_widget.bind(WrappedText.TEXT_CHANGED_BINDING, lambda _event: self._on_value_changed())

        self._update_revert_button(value)
        self._update_reset_button(value)

    @override
    def get_value(self) -> str:
        return self._text_widget.get('1.0', tk.END)[:-1]

    @override
    def _replace_value_and_focus(self, text: str) -> None:
        self._text_widget.delete('1.0', tk.END)
        self._text_widget.insert('1.0', text)
        self._text_widget.focus()

    def _on_value_changed(self) -> None:
        text: str = self._text_widget.get('1.0', tk.END)[:-1]
        self._update_revert_button(text)
        self._update_reset_button(text)

class _SetLeafEditor(_LeafEditor):
    def __init__(self, config_leaf: IConfigSetLeaf, config: IPersistentConfig, parent: tk.Misc, *, row: int) -> None:
        super().__init__(config_leaf, config, parent, row=row)

        value: str = config_leaf.fetch_value_or_default(self._config)

        self._text_variable: tk.StringVar = tk.StringVar(parent)
        self._choice_widget: ttk.OptionMenu = ttk.OptionMenu(parent, self._text_variable, value, *config_leaf.list_of_values, command=lambda _variable: self._on_value_changed())
        self._choice_widget.configure(padding=(_TABLE_BUTTON_X_PADDING, _TABLE_BUTTON_Y_PADDING))
        self._choice_widget['menu'].configure(foreground=_COL_EDIT_FORE, background=_COL_EDIT_BACK, selectcolor=_COL_EDIT_FORE, font=general_font.NORMAL_FONT_NAME)
        self._choice_widget.grid(row=row, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)

        self._update_revert_button(value)
        self._update_reset_button(value)

    @override
    def get_value(self) -> str:
        return self._text_variable.get()

    @override
    def _replace_value_and_focus(self, text: str) -> None:
        self._text_variable.set(text)
        self._choice_widget.focus()

    def _on_value_changed(self) -> None:
        text: str = self._text_variable.get()
        self._update_revert_button(text)
        self._update_reset_button(text)
