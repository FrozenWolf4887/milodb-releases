# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
NORMAL_FONT_NAME: str = 'Arial 11'
ITALIC_FONT_NAME: str = 'Arial 11 italic'
BANNER_FONT_NAME: str = 'Arial 14 italic'
