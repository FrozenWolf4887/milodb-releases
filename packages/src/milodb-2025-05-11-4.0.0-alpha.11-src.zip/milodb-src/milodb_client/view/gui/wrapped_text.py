# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import tkinter as tk
from collections.abc import Callable
from typing import Any, Literal
from milodb_client.view.gui.tk_interceptor import TkInterceptor

# spell-checker: ignore displaylines

class WrappedText(tk.Text):
    TEXT_CHANGED_BINDING: str = '<<TextChanged>>'

    def __init__(self, master: tk.Misc, *, is_multiline: bool = False, line_count: int | Literal['dynamic'], line_count_changed_callback: Callable[[], None] | None = None, **kwargs: Any) -> None: # noqa: ANN401 Dynamically typed expressions (typing.Any) are disallowed:
        self._is_multiline: bool = is_multiline
        self._line_count_changed_callback: Callable[[], None] | None = line_count_changed_callback
        self._current_line_count: int = 0 if line_count == 'dynamic' else line_count
        self._suppress_on_size_changed: bool = False

        super().__init__(
            master,
            height = self._current_line_count,
            wrap = tk.WORD,
            **kwargs,
        )

        if not self._is_multiline:
            self.bind('<Return>', lambda _event: 'break')
        self.bind('<<Paste>>', self._on_paste)
        self.bind('<<PasteSelection>>', self._on_paste)

        self.event_add(self.TEXT_CHANGED_BINDING, 'None')

        interceptor: TkInterceptor = TkInterceptor(self)
        interceptor.intercept_after("insert", self._post_insert)
        interceptor.intercept_after("delete", self._post_delete)

        if line_count == 'dynamic':
            self.bind('<Configure>', self._on_size_changed)

    @property
    def line_count(self) -> int:
        return self._current_line_count or 0

    def _post_insert(self, *args: object) -> None:
        self._update_widget_height()
        if len(args) == 2 and args[1]: # noqa: PLR2004 Magic value used in comparison
            self.event_generate(self.TEXT_CHANGED_BINDING)

    def _post_delete(self, *_args: object) -> None:
        self._update_widget_height()
        self.event_generate(self.TEXT_CHANGED_BINDING)

    def _on_size_changed(self, _: object) -> None:
        if self._suppress_on_size_changed:
            return
        self._update_widget_height()

    def _update_widget_height(self) -> None:
        line_count: int | None = self.count('1.0', tk.END, 'displaylines', 'update')
        if line_count is not None and self._current_line_count != line_count:
            self._current_line_count = line_count
            self._suppress_on_size_changed = True
            self.config(height=line_count)
            self._suppress_on_size_changed = False
            if self._line_count_changed_callback:
                self._line_count_changed_callback()

    def _on_paste(self, _: object) -> str | None:
        text: str | None = self._get_clipboard()
        if text is not None:
            if not self._is_multiline:
                text = _cut_text_at_line_break(text)
            self._delete_selection()
            self.insert(self.index(tk.INSERT), text)
            self.see(self.index(tk.INSERT))
        return 'break'

    def _delete_selection(self) -> None:
        index_of_selection_begin: str | None = None
        index_of_selection_end: str | None = None
        try:
            index_of_selection_begin = self.index(tk.SEL_FIRST)
            index_of_selection_end = self.index(tk.SEL_LAST)
        except tk.TclError:
            pass

        if index_of_selection_begin and index_of_selection_end:
            self.delete(index_of_selection_begin, index_of_selection_end)

    def _get_clipboard(self) -> str | None:
        text: object = None
        try:
            root: tk.Tk | tk.Toplevel = self.winfo_toplevel()
            text = root.clipboard_get()
        except tk.TclError:
            pass
        if isinstance(text, str):
            return text
        return None

def _cut_text_at_line_break(text: str) -> str:
    lf_pos: int = text.find('\n')
    cr_pos: int = text.find('\r')
    break_pos: int = -1
    if lf_pos != -1:
        break_pos = lf_pos
    if cr_pos != -1 and cr_pos < break_pos:
        break_pos = cr_pos
    if break_pos != -1:
        text = text[:break_pos]
    return text
