# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import tkinter as tk
from milodb_client.view.gui.tk_interceptor import TkInterceptor

def set_text_readonly(text: tk.Text) -> None:
    interceptor: TkInterceptor = TkInterceptor(text)
    interceptor.intercept_before('insert', _do_nothing, replace_method=False)
    interceptor.intercept_before('delete', _do_nothing, replace_method=False)

def _do_nothing(*_args: object) -> bool:
    return False
