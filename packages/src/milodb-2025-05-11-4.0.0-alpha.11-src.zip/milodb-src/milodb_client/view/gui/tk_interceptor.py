# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import tkinter as tk
from dataclasses import dataclass
from functools import partial
from typing import Any, Protocol

# spell-checker: ignore createcommand

class InterceptPreCall(Protocol):
    def __call__(self, *args: Any) -> bool: # noqa: ANN401 Dynamically typed expressions (typing.Any) are disallowed:
        ...

class InterceptPostCall(Protocol):
    def __call__(self, *args: Any) -> None: # noqa: ANN401 Dynamically typed expressions (typing.Any) are disallowed:
        ...

class TkInterceptor:
    def __init__(self, widget: tk.Widget) -> None:
        self._widget: tk.Widget = widget
        self._map_of_operation_to_handler: dict[str, _CallHost] = {}
        dispatch_operation: str = widget._w # type: ignore[attr-defined] # noqa: SLF001 Private member accessed
        self._original_dispatch_operation = f'{dispatch_operation}_original'
        self._widget.tk.call('rename', dispatch_operation, self._original_dispatch_operation)
        self._widget.tk.createcommand(dispatch_operation, self.dispatch) # type: ignore[no-untyped-call]

    def intercept_before(self, operation: str, handler: InterceptPreCall, *, replace_method: bool=True) -> None:
        self._map_of_operation_to_handler[operation] = _PreCallHost(handler)
        if replace_method:
            setattr(self._widget, operation, partial(self.dispatch, operation))
        else:
            setattr(self._widget, operation, partial(self._widget.tk.call, self._original_dispatch_operation, operation))

    def intercept_after(self, operation: str, handler: InterceptPostCall, *, replace_method: bool=True) -> None:
        self._map_of_operation_to_handler[operation] = _PostCallHost(handler)
        if replace_method:
            setattr(self._widget, operation, partial(self.dispatch, operation))
        else:
            setattr(self._widget, operation, partial(self._widget.tk.call, self._original_dispatch_operation, operation))

    def dispatch(self, operation: str, *args: Any) -> Any: # noqa: ANN401 Dynamically typed expressions (typing.Any) are disallowed:
        result: Any
        handler: _CallHost | None = self._map_of_operation_to_handler.get(operation)
        match handler:
            case _PreCallHost():
                if handler.handler(*args):
                    result = self._call_original_dispatcher(operation, *args)
                else:
                    result = None
            case _PostCallHost():
                result = self._call_original_dispatcher(operation, *args)
                handler.handler(*args)
            case None:
                result = self._call_original_dispatcher(operation, *args)
        return result

    def _call_original_dispatcher(self, operation: str, *args: Any) -> Any: # noqa: ANN401 Dynamically typed expressions (typing.Any) are disallowed:
        try:
            return self._widget.tk.call(self._original_dispatch_operation, operation, *args)
        except tk.TclError:
            return ''

@dataclass
class _PreCallHost:
    handler: InterceptPreCall

@dataclass
class _PostCallHost:
    handler: InterceptPostCall

type _CallHost = _PreCallHost | _PostCallHost
