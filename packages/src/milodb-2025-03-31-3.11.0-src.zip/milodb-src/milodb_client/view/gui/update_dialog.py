# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from __future__ import annotations
import functools
import time
import tkinter as tk
from pathlib import Path
from tkinter import messagebox, ttk
from typing import TYPE_CHECKING, override
from milodb_client.updater.cached_remote_update_data import CachedRemoteUpdateData
from milodb_client.updater.i_temp_directory import ITempDirectory, ITempDirectoryCreator, TempDirectoryError
from milodb_client.updater.prepare_update import PrepareUpdateError, prepare_update
from milodb_client.updater.update_potential import UpdatePotential
from milodb_client.updater.update_strategy import FileRename, UpdateStrategy, UpdateStrategyError, determine_update_strategy
from milodb_client.view.gui import general_colours
from milodb_client.view.gui.frame_widgets import WrappingLabel
from milodb_client.view.gui.log_text import LogText
from milodb_client.view.gui.scrollable_frame import ScrollableFrame
from milodb_common.util.unit_size import UnitSizeText, unit_size
if TYPE_CHECKING:
    from collections.abc import Callable
    from milodb_client.config.update_config import UpdateConfig
    from milodb_client.startup.shutdown_action import IShutdownAction
    from milodb_client.updater.i_file_hasher import IFileHasher
    from milodb_client.updater.i_file_tester import IFileTester
    from milodb_client.updater.manifest.local_manifest import ILocalManifest
    from milodb_client.updater.manifest.update_directory import IAsset, IAssetRegister
    from milodb_client.updater.manifest.version_manifest import ICoreFile, IVersion, IVariant
    from milodb_common.internet.i_uri_scraper_factory import IUriScraperFactory
    from milodb_common.util.ref import IRef

_COL_PANEL_BACK: str = general_colours.PANEL_BACK
_COL_BUTTON_BACK: str = general_colours.BUTTON_BACK
_COL_BUTTON_FORE: str = general_colours.BUTTON_FORE
_COL_STATUS_FORE: str = '#FFF'
_COL_STATUS_ERROR_BACK: str = '#600'
_COL_STATUS_NO_UPDATE_BACK: str = '#060'
_COL_STATUS_UPDATE_POSSIBLE_BACK: str = '#606'
_COL_TABLE_HEADER_BACK: str = general_colours.HEADER_BACK
_COL_TABLE_HEADER_FORE: str = general_colours.HEADER_FORE
_COL_TABLE_CONTENT_BACK: str = general_colours.VALUE_BACK
_COL_TABLE_CONTENT_FORE: str = general_colours.VALUE_FORE
_TABLE_CELL_X_PADDING: int = 4
_TABLE_CELL_Y_PADDING: int = 1
_TABLE_GRIDLINE_THICKNESS: int = 1

# spell-checker: ignore columnspan padx pady

class UpdateDialog(tk.Toplevel):
    def __init__(self, master: tk.Tk, update_config: UpdateConfig, local_manifest: ILocalManifest | None, file_hasher: IFileHasher, file_tester: IFileTester, uri_scraper_factory: IUriScraperFactory, temp_directory_creator: ITempDirectoryCreator, ref_shutdown_action: IRef[IShutdownAction | None], shutdown_app: Callable[[], None]) -> None:
        super().__init__(master)
        self._update_config: UpdateConfig = update_config
        self._local_manifest: ILocalManifest | None = local_manifest
        self._file_hasher: IFileHasher = file_hasher
        self._file_tester: IFileTester = file_tester
        self._uri_scraper_factory: IUriScraperFactory = uri_scraper_factory
        self._temp_directory_creator: ITempDirectoryCreator = temp_directory_creator
        self._ref_shutdown_action: IRef[IShutdownAction | None] = ref_shutdown_action
        self._shutdown_app: Callable[[], None] = shutdown_app

        self.geometry('640x480')

        self._notebook: ttk.Notebook = ttk.Notebook(self)
        self._notebook.grid(column=0, row=0, sticky=tk.NSEW)
        self._update_status_label: tk.Label = tk.Label(self, fg=_COL_STATUS_FORE)
        self._update_status_label.grid(column=0, row=1, sticky=tk.EW)
        self._button_frame: tk.Frame = tk.Frame(self)
        self._button_frame.grid(column=0, row=2)
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(0, weight=1)

        self._cancel_button: tk.Button = tk.Button(self._button_frame, text='Cancel', foreground=_COL_BUTTON_FORE, background=_COL_BUTTON_BACK, command=self._on_cancel_button)
        self._cancel_button.pack(side=tk.LEFT)
        self._update_button: tk.Button = tk.Button(self._button_frame, text='Update', foreground=_COL_BUTTON_FORE, background=_COL_BUTTON_BACK, command=self._on_update_button)

        self._log_text: LogText = LogText(self._notebook)
        self._log_text.pack(fill=tk.BOTH, expand=True)
        self._log_tab_index: object = self._notebook.index(tk.END) # type: ignore[no-untyped-call]
        self._notebook.add(self._log_text, text='Log')

        self._update_frame: ScrollableFrame = ScrollableFrame(self._notebook, background=_COL_PANEL_BACK)
        self._update_frame.top_frame.pack(fill=tk.BOTH, expand=True)
        self._update_tab_index: object = self._notebook.index(tk.END) # type: ignore[no-untyped-call]
        self._notebook.add(self._update_frame.top_frame, text='Update', state=tk.HIDDEN)

        self._analysis_frame: ScrollableFrame = ScrollableFrame(self._notebook, background=_COL_PANEL_BACK)
        self._analysis_frame.top_frame.pack(fill=tk.BOTH, expand=True)
        self._analysis_tab_index: object = self._notebook.index(tk.END) # type: ignore[no-untyped-call]
        self._notebook.add(self._analysis_frame.top_frame, text='Analysis', state=tk.HIDDEN)

        self._backup_frame: ScrollableFrame = ScrollableFrame(self._notebook, background=_COL_PANEL_BACK)
        self._backup_frame.top_frame.pack(fill=tk.BOTH, expand=True)
        self._backup_tab_index: object = self._notebook.index(tk.END) # type: ignore[no-untyped-call]
        self._notebook.add(self._backup_frame.top_frame, text='Backup', state=tk.HIDDEN)

        self._variants_frame: ScrollableFrame = ScrollableFrame(self._notebook, background=_COL_PANEL_BACK)
        self._variants_frame.top_frame.pack(fill=tk.BOTH, expand=True)
        self._variants_tab_index: object = self._notebook.index(tk.END) # type: ignore[no-untyped-call]
        self._notebook.add(self._variants_frame.top_frame, text='Variants', state=tk.HIDDEN)

        self.transient(master)
        self.wait_visibility()
        self.grab_set()

        self._requested_variant_name: str | None = None

        if self._local_manifest:
            self._check_for_updates(self._local_manifest)
        else:
            self._update_status_label.config(text='Local manifest unavailable, update impossible', bg=_COL_STATUS_ERROR_BACK)

    @override
    def destroy(self) -> None:
        self.grab_release()
        super().destroy()

    def _check_for_updates(self, local_manifest: ILocalManifest) -> None:
        self._notebook.select(self._log_tab_index)
        _hide_tabs(self._notebook, self._update_tab_index, self._analysis_tab_index, self._backup_tab_index, self._variants_tab_index)
        _clear_frames(self._variants_frame.content_frame, self._analysis_frame.content_frame, self._backup_frame.content_frame, self._update_frame.content_frame)
        self._update_button.pack_forget()

        remote_update_data: CachedRemoteUpdateData | None
        self._update_strategy: UpdateStrategy | None
        remote_update_data, self._update_strategy = self._try_get_update_strategy(
            self._update_config.update_directory_uri,
            local_manifest,
            self._file_hasher,
            self._file_tester,
            self._uri_scraper_factory,
            requested_variant_name = self._requested_variant_name,
        )

        if remote_update_data:
            self._init_variants_tab(local_manifest, remote_update_data)
            if self._update_strategy:
                update_potential: UpdatePotential = UpdatePotential(self._update_strategy)
                if update_potential.is_update_available:
                    self._init_analysis_tab(self._update_strategy)
                    self._init_backup_tab(self._update_strategy)
                    self._init_update_tab(self._update_strategy)
                    self._notebook.select(tab_id=self._update_tab_index)
                    self._update_button.pack(side=tk.LEFT)
                    self._update_status_label.config(text=update_potential.message, bg=_COL_STATUS_UPDATE_POSSIBLE_BACK)
                else:
                    self._update_status_label.config(text=update_potential.message, bg=_COL_STATUS_NO_UPDATE_BACK)
            else:
                self._update_status_label.config(text='Unable to determine update strategy', bg=_COL_STATUS_ERROR_BACK)
        else:
            self._update_status_label.config(text='Unable to fetch update manifests', bg=_COL_STATUS_ERROR_BACK)

        self._cancel_button.focus()

    def _init_variants_tab(self, local_manifest: ILocalManifest, remote_update_data: CachedRemoteUpdateData) -> None:
        tk.Label(self._variants_frame.content_frame, text='Variant Name', anchor=tk.W, justify=tk.LEFT, fg=_COL_TABLE_HEADER_FORE, bg=_COL_TABLE_HEADER_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=0, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
        tk.Label(self._variants_frame.content_frame, text='Summary', anchor=tk.W, justify=tk.LEFT, fg=_COL_TABLE_HEADER_FORE, bg=_COL_TABLE_HEADER_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=0, column=2, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
        tk.Label(self._variants_frame.content_frame, text='Status', anchor=tk.W, justify=tk.LEFT, fg=_COL_TABLE_HEADER_FORE, bg=_COL_TABLE_HEADER_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=0, column=3, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)

        row: int
        variant: IVariant
        for row, variant in enumerate(remote_update_data.version_manifest.variants.values()):
            tk.Label(self._variants_frame.content_frame, text=variant.name, anchor=tk.W, justify=tk.LEFT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row+1, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            WrappingLabel(self._variants_frame.content_frame, text=variant.summary, anchor=tk.W, justify=tk.LEFT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row+1, column=2, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            if variant.name == local_manifest.variant_name:
                tk.Label(self._variants_frame.content_frame, text='Current', anchor=tk.W, justify=tk.LEFT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row+1, column=3, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
                if self._requested_variant_name is not None and self._requested_variant_name != local_manifest.variant_name:
                    tk.Button(self._variants_frame.content_frame, text='Switch', anchor=tk.W, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING, command=functools.partial(self._on_switch_button_pressed, local_manifest, variant.name)).grid(row=row+1, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            elif self._requested_variant_name is not None and variant.name == self._requested_variant_name:
                tk.Label(self._variants_frame.content_frame, text='Selected', anchor=tk.W, justify=tk.LEFT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row+1, column=3, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            else:
                tk.Button(self._variants_frame.content_frame, text='Switch', anchor=tk.W, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING, command=functools.partial(self._on_switch_button_pressed, local_manifest, variant.name)).grid(row=row+1, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)

        self._variants_frame.content_frame.columnconfigure(2, weight=1)
        self._update_frame.set_child_bindtags_for_scrolling()

        self._notebook.tab(self._variants_tab_index, state=tk.NORMAL)

    def _on_switch_button_pressed(self, local_manifest: ILocalManifest, variant_name: str) -> None:
        self._requested_variant_name = variant_name
        self._check_for_updates(local_manifest)

    def _init_analysis_tab(self, update_strategy: UpdateStrategy) -> None: # pylint: disable=too-many-statements # noqa: PLR0915 Too many statements
        tk.Label(self._analysis_frame.content_frame, text='Type', anchor=tk.W, justify=tk.LEFT, fg=_COL_TABLE_HEADER_FORE, bg=_COL_TABLE_HEADER_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=0, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
        tk.Label(self._analysis_frame.content_frame, text='File', anchor=tk.W, justify=tk.LEFT, fg=_COL_TABLE_HEADER_FORE, bg=_COL_TABLE_HEADER_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=0, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
        tk.Label(self._analysis_frame.content_frame, text='Status', anchor=tk.W, justify=tk.LEFT, fg=_COL_TABLE_HEADER_FORE, bg=_COL_TABLE_HEADER_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=0, column=2, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
        tk.Label(self._analysis_frame.content_frame, text='Action', anchor=tk.W, justify=tk.LEFT, fg=_COL_TABLE_HEADER_FORE, bg=_COL_TABLE_HEADER_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=0, column=3, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
        tk.Label(self._analysis_frame.content_frame, text='Size', anchor=tk.W, justify=tk.LEFT, fg=_COL_TABLE_HEADER_FORE, bg=_COL_TABLE_HEADER_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=0, column=4, columnspan=2, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)

        row: int = 1
        core_file: ICoreFile
        for core_file in update_strategy.core_file_changes.list_of_new_files_to_acquire:
            unit_text_size: UnitSizeText = _asset_file_size(core_file, update_strategy.asset_register)
            tk.Label(self._analysis_frame.content_frame, text='Core', anchor=tk.W, justify=tk.LEFT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            tk.Label(self._analysis_frame.content_frame, text=str(core_file.filename), anchor=tk.W, justify=tk.LEFT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            tk.Label(self._analysis_frame.content_frame, text='New', anchor=tk.W, justify=tk.LEFT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row, column=2, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            tk.Label(self._analysis_frame.content_frame, text='Acquire', anchor=tk.W, justify=tk.LEFT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row, column=3, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            tk.Label(self._analysis_frame.content_frame, text=unit_text_size.size_text, anchor=tk.E, justify=tk.RIGHT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row, column=4, padx=(_TABLE_GRIDLINE_THICKNESS, 0), pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            tk.Label(self._analysis_frame.content_frame, text=unit_text_size.unit_text, anchor=tk.W, justify=tk.LEFT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row, column=5, padx=(0, _TABLE_GRIDLINE_THICKNESS), pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            row += 1

        for core_file in update_strategy.core_file_changes.list_of_changed_files_to_acquire:
            unit_text_size = _asset_file_size(core_file, update_strategy.asset_register)
            tk.Label(self._analysis_frame.content_frame, text='Core', anchor=tk.W, justify=tk.LEFT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            tk.Label(self._analysis_frame.content_frame, text=str(core_file.filename), anchor=tk.NW, justify=tk.LEFT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            tk.Label(self._analysis_frame.content_frame, text='Changed', anchor=tk.W, justify=tk.LEFT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row, column=2, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            tk.Label(self._analysis_frame.content_frame, text='Acquire', anchor=tk.W, justify=tk.LEFT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row, column=3, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            tk.Label(self._analysis_frame.content_frame, text=unit_text_size.size_text, anchor=tk.E, justify=tk.RIGHT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row, column=4, padx=(_TABLE_GRIDLINE_THICKNESS, 0), pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            tk.Label(self._analysis_frame.content_frame, text=unit_text_size.unit_text, anchor=tk.W, justify=tk.LEFT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row, column=5, padx=(0, _TABLE_GRIDLINE_THICKNESS), pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            row += 1

        for core_file in update_strategy.core_file_changes.list_of_missing_files_to_acquire:
            unit_text_size = _asset_file_size(core_file, update_strategy.asset_register)
            tk.Label(self._analysis_frame.content_frame, text='Core', anchor=tk.W, justify=tk.LEFT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            tk.Label(self._analysis_frame.content_frame, text=str(core_file.filename), anchor=tk.NW, justify=tk.LEFT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            tk.Label(self._analysis_frame.content_frame, text='Missing', anchor=tk.W, justify=tk.LEFT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row, column=2, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            tk.Label(self._analysis_frame.content_frame, text='Reacquire', anchor=tk.W, justify=tk.LEFT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row, column=3, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            tk.Label(self._analysis_frame.content_frame, text=unit_text_size.size_text, anchor=tk.E, justify=tk.RIGHT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row, column=4, padx=(_TABLE_GRIDLINE_THICKNESS, 0), pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            tk.Label(self._analysis_frame.content_frame, text=unit_text_size.unit_text, anchor=tk.W, justify=tk.LEFT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row, column=5, padx=(0, _TABLE_GRIDLINE_THICKNESS), pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            row += 1

        filename: Path
        for filename in update_strategy.core_file_changes.list_of_files_that_are_deprecated:
            tk.Label(self._analysis_frame.content_frame, text='Core', anchor=tk.W, justify=tk.LEFT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            tk.Label(self._analysis_frame.content_frame, text=str(filename), anchor=tk.NW, justify=tk.LEFT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            tk.Label(self._analysis_frame.content_frame, text='Redundant', anchor=tk.W, justify=tk.LEFT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row, column=2, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            tk.Label(self._analysis_frame.content_frame, text='Delete', anchor=tk.W, justify=tk.LEFT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row, column=3, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            row += 1

        for core_file in update_strategy.core_file_changes.list_of_unchanged_files:
            tk.Label(self._analysis_frame.content_frame, text='Core', anchor=tk.W, justify=tk.LEFT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            tk.Label(self._analysis_frame.content_frame, text=str(core_file.filename), anchor=tk.NW, justify=tk.LEFT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            tk.Label(self._analysis_frame.content_frame, text='Unchanged', anchor=tk.W, justify=tk.LEFT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row, column=2, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            tk.Label(self._analysis_frame.content_frame, text='None', anchor=tk.W, justify=tk.LEFT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row, column=3, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            row += 1

        file_rename: FileRename
        for file_rename in update_strategy.config_file_changes.list_of_files_to_rename:
            tk.Label(self._analysis_frame.content_frame, text='Config', anchor=tk.W, justify=tk.LEFT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            tk.Label(self._analysis_frame.content_frame, text=str(file_rename.original_filename), anchor=tk.NW, justify=tk.LEFT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            tk.Label(self._analysis_frame.content_frame, text='Renamed', anchor=tk.W, justify=tk.LEFT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row, column=2, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            tk.Label(self._analysis_frame.content_frame, text=f'Rename to {file_rename.new_filename!s}', anchor=tk.W, justify=tk.LEFT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row, column=3, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            row += 1

        for filename in update_strategy.config_file_changes.list_of_files_that_are_deprecated:
            tk.Label(self._analysis_frame.content_frame, text='Config', anchor=tk.W, justify=tk.LEFT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            tk.Label(self._analysis_frame.content_frame, text=str(filename), anchor=tk.NW, justify=tk.LEFT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            tk.Label(self._analysis_frame.content_frame, text='Redundant', anchor=tk.W, justify=tk.LEFT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row, column=2, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            tk.Label(self._analysis_frame.content_frame, text='Delete', anchor=tk.W, justify=tk.LEFT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row, column=3, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            row += 1

        for filename in update_strategy.config_file_changes.list_of_files_to_leave:
            tk.Label(self._analysis_frame.content_frame, text='Config', anchor=tk.W, justify=tk.LEFT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            tk.Label(self._analysis_frame.content_frame, text=str(filename), anchor=tk.NW, justify=tk.LEFT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            tk.Label(self._analysis_frame.content_frame, text='Relevant', anchor=tk.W, justify=tk.LEFT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row, column=2, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            tk.Label(self._analysis_frame.content_frame, text='None', anchor=tk.W, justify=tk.LEFT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row, column=3, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            row += 1

        for filename in update_strategy.config_file_changes.list_of_new_files:
            tk.Label(self._analysis_frame.content_frame, text='Config', anchor=tk.W, justify=tk.LEFT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            tk.Label(self._analysis_frame.content_frame, text=str(filename), anchor=tk.NW, justify=tk.LEFT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            tk.Label(self._analysis_frame.content_frame, text='New', anchor=tk.W, justify=tk.LEFT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row, column=2, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            tk.Label(self._analysis_frame.content_frame, text='None', anchor=tk.W, justify=tk.LEFT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row, column=3, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            row += 1

        self._notebook.add(self._analysis_frame.top_frame)

    def _init_backup_tab(self, update_strategy: UpdateStrategy) -> None:
        tk.Label(self._backup_frame.content_frame, text='Type', anchor=tk.W, justify=tk.LEFT, fg=_COL_TABLE_HEADER_FORE, bg=_COL_TABLE_HEADER_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=0, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
        tk.Label(self._backup_frame.content_frame, text='File', anchor=tk.W, justify=tk.LEFT, fg=_COL_TABLE_HEADER_FORE, bg=_COL_TABLE_HEADER_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=0, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)

        row: int = 1
        filename: Path
        for filename in update_strategy.backup_file_set.list_of_core_files_to_backup:
            tk.Label(self._backup_frame.content_frame, text='Core', anchor=tk.W, justify=tk.LEFT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            tk.Label(self._backup_frame.content_frame, text=str(filename), anchor=tk.NW, justify=tk.LEFT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            row += 1

        for filename in update_strategy.backup_file_set.list_of_config_files_to_backup:
            tk.Label(self._backup_frame.content_frame, text='Config', anchor=tk.W, justify=tk.LEFT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            tk.Label(self._backup_frame.content_frame, text=str(filename), anchor=tk.NW, justify=tk.LEFT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            row += 1

        for filename in update_strategy.backup_file_set.list_of_clobbered_files_to_backup:
            tk.Label(self._backup_frame.content_frame, text='Unknown', anchor=tk.W, justify=tk.LEFT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            tk.Label(self._backup_frame.content_frame, text=str(filename), anchor=tk.NW, justify=tk.LEFT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            row += 1

        self._notebook.add(self._backup_frame.top_frame)

    def _init_update_tab(self, update_strategy: UpdateStrategy) -> None:
        tk.Label(self._update_frame.content_frame, text='Version', anchor=tk.W, justify=tk.LEFT, fg=_COL_TABLE_HEADER_FORE, bg=_COL_TABLE_HEADER_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=0, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
        tk.Label(self._update_frame.content_frame, text='Date', anchor=tk.W, justify=tk.LEFT, fg=_COL_TABLE_HEADER_FORE, bg=_COL_TABLE_HEADER_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=0, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
        tk.Label(self._update_frame.content_frame, text='Changes', anchor=tk.W, justify=tk.LEFT, fg=_COL_TABLE_HEADER_FORE, bg=_COL_TABLE_HEADER_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=0, column=2, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)

        row: int
        version: IVersion
        for row, version in enumerate(sorted(update_strategy.list_of_newer_versions, key=lambda version: version.date, reverse=True)):
            tk.Label(self._update_frame.content_frame, text=str(version.number), anchor=tk.NW, justify=tk.LEFT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row+1, column=0, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            tk.Label(self._update_frame.content_frame, text=str(version.date), anchor=tk.NW, justify=tk.LEFT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row+1, column=1, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)
            WrappingLabel(self._update_frame.content_frame, text=version.log, anchor=tk.NW, justify=tk.LEFT, fg=_COL_TABLE_CONTENT_FORE, bg=_COL_TABLE_CONTENT_BACK, padx=_TABLE_CELL_X_PADDING, pady=_TABLE_CELL_Y_PADDING).grid(row=row+1, column=2, padx=_TABLE_GRIDLINE_THICKNESS, pady=_TABLE_GRIDLINE_THICKNESS, sticky=tk.NSEW)

        self._update_frame.content_frame.columnconfigure(2, weight=1)
        self._update_frame.set_child_bindtags_for_scrolling()

    def _on_cancel_button(self) -> None:
        self.destroy()

    def _on_update_button(self) -> None:
        if self._update_strategy and self._try_prepare_update(self._update_strategy):
            self.destroy()
            self._shutdown_app()

    def _try_get_update_strategy(self, update_directory_uri: str, local_manifest: ILocalManifest, file_hasher: IFileHasher, file_tester: IFileTester, uri_scraper_factory: IUriScraperFactory, *, requested_variant_name: str | None=None) -> tuple[CachedRemoteUpdateData | None, UpdateStrategy | None]:
        remote_update_data: CachedRemoteUpdateData | None = CachedRemoteUpdateData.fetch(update_directory_uri, uri_scraper_factory, self._log_text.normal_printer, self._log_text.error_printer)
        if not remote_update_data:
            return None, None

        try:
            update_strategy: UpdateStrategy = determine_update_strategy(Path(), None, requested_variant_name, local_manifest, remote_update_data.version_manifest, remote_update_data.update_directory.asset_register, file_hasher, file_tester)
        except UpdateStrategyError as ex:
            self._log_text.error_printer.writeln('Failed to determine update strategy')
            self._log_text.normal_printer.writeln(f'Cause: {ex}')
        else:
            return remote_update_data, update_strategy

        return remote_update_data, None

    def _try_prepare_update(self, update_strategy: UpdateStrategy) -> bool:
        if update_strategy.launch_executable is None:
            warning_message: messagebox.Message = messagebox.Message(
                self,
                parent = self,
                icon = messagebox.WARNING,
                title = 'Update Warning',
                message = 'Unsupported target platform',
                detail = (
                    'There is no main executable for the current operating system in the chosen target variant / version.\n'
                    'Following the update, the application will close and there can be no attempt to start the new application.\n'
                    'This problem can occur if you upgrade to a variant or version that supports a different operating system.\n'
                    'Are you sure you want to continue?\n'
                ),
                type = messagebox.YESNO,
                default = messagebox.NO,
            )
            if warning_message.show() != messagebox.YES: # type: ignore[no-untyped-call]
                return False

        self._notebook.select(tab_id=self._log_tab_index)

        try:
            temp_directory: ITempDirectory = self._temp_directory_creator.create()
        except TempDirectoryError as ex:
            self._log_text.normal_printer.writeln()
            self._log_text.error_printer.writeln(f'Failed to prepare update: {ex}')
            return False

        self._log_text.normal_printer.writeln(f"Created update temp directory '{temp_directory.path}'")

        try:
            shutdown_action: IShutdownAction = prepare_update(
                update_strategy = update_strategy,
                backup_directory = self._update_config.backup_directory,
                time_stamp = time.localtime(),
                directory_uri = self._update_config.update_directory_uri,
                asset_register = update_strategy.asset_register,
                temp_directory = temp_directory,
                uri_scraper_factory = self._uri_scraper_factory,
                normal_printer = self._log_text.normal_printer,
            )
        except PrepareUpdateError as ex:
            self._log_text.normal_printer.writeln()
            self._log_text.error_printer.writeln(f'Failed to prepare update: {ex}')
            return False

        self._ref_shutdown_action.set(shutdown_action)
        return True

def _asset_file_size(core_file: ICoreFile, asset_register: IAssetRegister) -> UnitSizeText:
    asset: IAsset | None = asset_register.assets.get(core_file.digest)
    if not asset:
        return UnitSizeText('unknown', '')
    return unit_size(asset.size)

def _hide_tabs(notebook: ttk.Notebook, *list_of_tab_indices: object) -> None:
    tab_index: object
    for tab_index in list_of_tab_indices:
        notebook.tab(tab_index, state=tk.HIDDEN)

def _clear_frames(*list_of_frames: tk.Misc) -> None:
    frame: tk.Misc
    for frame in list_of_frames:
        while frame.children:
            frame.children.popitem()[1].destroy()
