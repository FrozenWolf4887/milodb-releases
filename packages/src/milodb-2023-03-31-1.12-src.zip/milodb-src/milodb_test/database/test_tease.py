# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
import datetime
import unittest
from typing import Any
from milodb.database.tease import Tease, TeaseType, TotmStatus

_DICT_KEY_AUTHOR_ID: str = 'aid'
_DICT_KEY_AUTHOR_NAME: str = 'anm'
_DICT_KEY_DATE: str = 'dat'
_DICT_KEY_IMAGE_COUNT: str = 'imr'
_DICT_KEY_RATING: str = 'rvl'
_DICT_KEY_TAGS: str = 'tgs'
_DICT_KEY_TEASE_ID: str = 'tid'
_DICT_KEY_TEXT: str = 'txt'
_DICT_KEY_THUMBNAIL: str = 'thm'
_DICT_KEY_TITLE: str = 'ttl'
_DICT_KEY_TYPE: str = 'typ'
_DICT_KEY_UNIQUE_IMAGE_COUNT: str = 'imu'

_DICT_DEFAULT_VALUE_AUTHOR_ID: int = 123
_DICT_DEFAULT_VALUE_AUTHOR_NAME: str = 'Name of Author'
_DICT_DEFAULT_VALUE_DATE: str = '2018-07-30'
_DICT_DEFAULT_VALUE_IMAGE_COUNT: int = 456
_DICT_DEFAULT_VALUE_RATING: float = 2.5
_DICT_DEFAULT_VALUE_TAGS: str = ':first:second:third:'
_DICT_DEFAULT_VALUE_TEASE_ID: int = 246
_DICT_DEFAULT_VALUE_TEXT_1: str = 'First'
_DICT_DEFAULT_VALUE_TEXT_2: str = 'Second'
_DICT_DEFAULT_VALUE_TEXT_3: str = 'Third'
_DICT_DEFAULT_VALUE_THUMBNAIL: str = 'https://some.thumbnail/image.jpg'
_DICT_DEFAULT_VALUE_TITLE: str = 'This is a Title'
_DICT_DEFAULT_VALUE_TYPE: int = 0
_DICT_DEFAULT_VALUE_UNIQUE_IMAGE_COUNT: int = 789

_TEASE_DEFAULT_VALUE_AUTHOR_ID: int = 123
_TEASE_DEFAULT_VALUE_AUTHOR_NAME: str = 'Name of Author'
_TEASE_DEFAULT_VALUE_DATE: datetime.date = datetime.date(2018, 7, 30)
_TEASE_DEFAULT_VALUE_HAS_AUTHOR: bool = True
_TEASE_DEFAULT_VALUE_IMAGE_COUNT: int = 456
_TEASE_DEFAULT_VALUE_RATING: float = 2.5
_TEASE_DEFAULT_VALUE_TAGS: list[str] = ['first', 'second', 'third']
_TEASE_DEFAULT_VALUE_TEASE_ID: int = 246
_TEASE_DEFAULT_VALUE_TEXT: list[str] = ['First', 'Second', 'Third']
_TEASE_DEFAULT_VALUE_THUMBNAIL: str = 'https://some.thumbnail/image.jpg'
_TEASE_DEFAULT_VALUE_TITLE: str = 'This is a Title'
_TEASE_DEFAULT_VALUE_TOTM: TotmStatus = TotmStatus.NONE
_TEASE_DEFAULT_VALUE_TYPE: TeaseType = TeaseType.REGULAR
_TEASE_DEFAULT_VALUE_UNIQUE_IMAGE_COUNT: int = 789

_TEASE_METADATA: dict[Any, Any] = {
    _DICT_KEY_AUTHOR_ID          : _DICT_DEFAULT_VALUE_AUTHOR_ID,
    _DICT_KEY_AUTHOR_NAME        : _DICT_DEFAULT_VALUE_AUTHOR_NAME,
    _DICT_KEY_DATE               : _DICT_DEFAULT_VALUE_DATE,
    _DICT_KEY_IMAGE_COUNT        : _DICT_DEFAULT_VALUE_IMAGE_COUNT,
    _DICT_KEY_RATING             : _DICT_DEFAULT_VALUE_RATING,
    _DICT_KEY_TAGS               : _DICT_DEFAULT_VALUE_TAGS,
    _DICT_KEY_TEASE_ID           : _DICT_DEFAULT_VALUE_TEASE_ID,
    _DICT_KEY_TEXT : [
        _DICT_DEFAULT_VALUE_TEXT_1,
        _DICT_DEFAULT_VALUE_TEXT_2,
        _DICT_DEFAULT_VALUE_TEXT_3
    ],
    _DICT_KEY_THUMBNAIL          : _DICT_DEFAULT_VALUE_THUMBNAIL,
    _DICT_KEY_TITLE              : _DICT_DEFAULT_VALUE_TITLE,
    _DICT_KEY_TYPE               : _DICT_DEFAULT_VALUE_TYPE,
    _DICT_KEY_UNIQUE_IMAGE_COUNT : _DICT_DEFAULT_VALUE_UNIQUE_IMAGE_COUNT
}

class _TestTeaseBase(unittest.TestCase):
    def setUp(self) -> None:
        self.tease_metadata: dict[Any, Any] = _TEASE_METADATA.copy()
        self.expect_author_id: int = _TEASE_DEFAULT_VALUE_AUTHOR_ID
        self.expect_author_name: str = _TEASE_DEFAULT_VALUE_AUTHOR_NAME
        self.expect_date: datetime.date = _TEASE_DEFAULT_VALUE_DATE
        self.expect_has_author: bool = _TEASE_DEFAULT_VALUE_HAS_AUTHOR
        self.expect_image_count: int = _TEASE_DEFAULT_VALUE_IMAGE_COUNT
        self.expect_rating: float = _TEASE_DEFAULT_VALUE_RATING
        self.expect_tags: list[str] = _TEASE_DEFAULT_VALUE_TAGS
        self.expect_tease_id: int = _TEASE_DEFAULT_VALUE_TEASE_ID
        self.expect_text: list[str] = _TEASE_DEFAULT_VALUE_TEXT
        self.expect_thumbnail: str = _TEASE_DEFAULT_VALUE_THUMBNAIL
        self.expect_title: str = _TEASE_DEFAULT_VALUE_TITLE
        self.expect_totm: TotmStatus = _TEASE_DEFAULT_VALUE_TOTM
        self.expect_type: TeaseType = _TEASE_DEFAULT_VALUE_TYPE
        self.expect_unique_image_count: int = _TEASE_DEFAULT_VALUE_UNIQUE_IMAGE_COUNT

    def remove_key(self, key: str) -> None:
        del self.tease_metadata[key]

    def change_key(self, key: str, value: Any) -> None:
        self.tease_metadata[key] = value

    def load_and_verify(self) -> None:
        tease: Tease = Tease(self.tease_metadata)
        self.assertEqual(self.expect_author_id, tease.author_id())
        self.assertEqual(self.expect_author_name, tease.author_name())
        self.assertEqual(self.expect_date, tease.date())
        self.assertEqual(self.expect_has_author, tease.has_author())
        self.assertEqual(self.expect_image_count, tease.count_of_images())
        self.assertEqual(self.expect_rating, tease.rating_value())
        self.assertListEqual(self.expect_tags, tease.list_of_tags())
        self.assertEqual(self.expect_tease_id, tease.tease_id())
        self.assertListEqual(self.expect_text, tease.list_of_text_blocks())
        self.assertEqual(self.expect_thumbnail, tease.thumbnail())
        self.assertEqual(self.expect_title, tease.title())
        self.assertEqual(self.expect_type, tease.type())
        self.assertEqual(self.expect_unique_image_count, tease.count_of_unique_images())

    def load_and_verify_exception_missing_key(self, key: str) -> None:
        with self.assertRaises(Tease.LoadError) as ex:
            Tease(self.tease_metadata)
        self.assertEqual(f"Key '{key}' is missing", str(ex.exception))

    def load_and_verify_exception_not_an_integer(self, key: str) -> None:
        with self.assertRaises(Tease.LoadError) as ex:
            Tease(self.tease_metadata)
        self.assertEqual(f"Key '{key}' is not an integer", str(ex.exception))

    def load_and_verify_exception_not_a_decimal_number(self, key: str) -> None:
        with self.assertRaises(Tease.LoadError) as ex:
            Tease(self.tease_metadata)
        self.assertEqual(f"Key '{key}' is not a decimal", str(ex.exception))

    def load_and_verify_exception_unknown_type(self, type_value: int) -> None:
        with self.assertRaises(Tease.LoadError) as ex:
            Tease(self.tease_metadata)
        self.assertEqual(f"Type of tease '{type_value}' is unknown", str(ex.exception))

    def load_and_verify_exception_not_a_string(self, key: str) -> None:
        with self.assertRaises(Tease.LoadError) as ex:
            Tease(self.tease_metadata)
        self.assertEqual(f"Key '{key}' is not a string", str(ex.exception))

    def load_and_verify_exception_number_below_minimum(self, key: str, value: (int | float), min_value: (int | float)) -> None:
        with self.assertRaises(Tease.LoadError) as ex:
            Tease(self.tease_metadata)
        self.assertEqual(f"Key '{key}' value '{value}' should be at least '{min_value}'", str(ex.exception))

    def load_and_verify_exception_number_above_maximum(self, key: str, value: (int | float), max_value: (int | float)) -> None:
        with self.assertRaises(Tease.LoadError) as ex:
            Tease(self.tease_metadata)
        self.assertEqual(f"Key '{key}' value '{value}' should be at most '{max_value}'", str(ex.exception))

    def load_and_verify_exception_not_a_date(self, key: str, value: str) -> None:
        with self.assertRaises(Tease.LoadError) as ex:
            Tease(self.tease_metadata)
        self.assertEqual(f"Key '{key}' value '{value}' is not a valid ISO date", str(ex.exception))

    def load_and_verify_exception_not_a_list(self, key: str) -> None:
        with self.assertRaises(Tease.LoadError) as ex:
            Tease(self.tease_metadata)
        self.assertEqual(f"Key '{key}' is not a list", str(ex.exception))

    def load_and_verify_exception_not_a_string_in_list(self, key: str, index: int) -> None:
        with self.assertRaises(Tease.LoadError) as ex:
            Tease(self.tease_metadata)
        self.assertEqual(f"Key '{key}' list entry #{index} is not a string", str(ex.exception))

class TestTeaseDefaults(_TestTeaseBase):
    def test_defaults_produces_all_defaults(self) -> None:
        self.load_and_verify()

class TestTeaseType(_TestTeaseBase):
    def test_valid_values_produces_expected_field(self) -> None:
        self.change_key(_DICT_KEY_TYPE, 0)
        self.expect_type = TeaseType.REGULAR
        self.load_and_verify()

        self.change_key(_DICT_KEY_TYPE, 1)
        self.expect_type = TeaseType.NYX
        self.load_and_verify()

        self.change_key(_DICT_KEY_TYPE, 2)
        self.expect_type = TeaseType.EOS
        self.load_and_verify()

        self.change_key(_DICT_KEY_TYPE, 3)
        self.expect_type = TeaseType.AUDIO
        self.load_and_verify()

    def test_missing_keye_fails(self) -> None:
        self.remove_key(_DICT_KEY_TYPE)
        self.load_and_verify_exception_missing_key(_DICT_KEY_TYPE)

    def test_out_of_range_value_fails(self) -> None:
        self.change_key(_DICT_KEY_TYPE, -1)
        self.load_and_verify_exception_unknown_type(-1)

        self.change_key(_DICT_KEY_TYPE, 4)
        self.load_and_verify_exception_unknown_type(4)

    def test_non_integer_value_fails(self) -> None:
        self.change_key(_DICT_KEY_TYPE, 'hello')
        self.load_and_verify_exception_not_an_integer(_DICT_KEY_TYPE)

class TestTeaseTitle(_TestTeaseBase):
    def test_specific_value_produces_expected_value(self) -> None:
        self.change_key(_DICT_KEY_TITLE, 'another title')
        self.expect_title = 'another title'
        self.load_and_verify()

    def test_empty_value_produces_empty_field(self) -> None:
        self.change_key(_DICT_KEY_TITLE, '')
        self.expect_title = ''
        self.load_and_verify()

    def test_missing_key_produces_blank_field(self) -> None:
        self.remove_key(_DICT_KEY_TITLE)
        self.expect_title = ''
        self.load_and_verify()

    def test_non_string_value_fails(self) -> None:
        self.change_key(_DICT_KEY_TITLE, 77)
        self.load_and_verify_exception_not_a_string(_DICT_KEY_TITLE)

class TestTeaseAuthorId(_TestTeaseBase):
    def test_specific_value_produces_expected_value(self) -> None:
        self.change_key(_DICT_KEY_AUTHOR_ID, 38834)
        self.expect_author_id = 38834
        self.load_and_verify()

    def test_zero_value_produces_no_author(self) -> None:
        self.change_key(_DICT_KEY_AUTHOR_ID, 0)
        self.expect_author_id = 0
        self.expect_has_author = False
        self.load_and_verify()

    def test_negative_value_produces_no_author(self) -> None:
        self.change_key(_DICT_KEY_AUTHOR_ID, -1)
        self.expect_author_id = 0
        self.expect_has_author = False
        self.load_and_verify_exception_number_below_minimum(_DICT_KEY_AUTHOR_ID, -1, 0)

    def test_missing_key_produces_no_author(self) -> None:
        self.remove_key(_DICT_KEY_AUTHOR_ID)
        self.expect_author_id = 0
        self.expect_has_author = False
        self.load_and_verify()

    def test_non_number_value_fails(self) -> None:
        self.change_key(_DICT_KEY_AUTHOR_ID, 'food')
        self.load_and_verify_exception_not_an_integer(_DICT_KEY_AUTHOR_ID)

class TestTeaseDate(_TestTeaseBase):
    def test_specific_value_produces_expected_value(self) -> None:
        self.change_key(_DICT_KEY_DATE, '2035-09-16')
        self.expect_date = datetime.date(2035, 9, 16)
        self.load_and_verify()

    def test_invalid_value_fails(self) -> None:
        self.change_key(_DICT_KEY_DATE, '235-09-16')
        self.load_and_verify_exception_not_a_date(_DICT_KEY_DATE, '235-09-16')

    def test_missing_key_fails(self) -> None:
        self.remove_key(_DICT_KEY_DATE)
        self.load_and_verify_exception_missing_key(_DICT_KEY_DATE)

    def test_non_string_value_fails(self) -> None:
        self.change_key(_DICT_KEY_DATE, 1)
        self.load_and_verify_exception_not_a_string(_DICT_KEY_DATE)

class TestTeaseImageCount(_TestTeaseBase):
    def test_specific_value_produces_expected_value(self) -> None:
        self.change_key(_DICT_KEY_IMAGE_COUNT, 19451)
        self.expect_image_count = 19451
        self.load_and_verify()

    def test_out_of_range_value_fails(self) -> None:
        self.change_key(_DICT_KEY_IMAGE_COUNT, -1)
        self.load_and_verify_exception_number_below_minimum(_DICT_KEY_IMAGE_COUNT, -1, 0)

    def test_missing_key_uses_default(self) -> None:
        self.remove_key(_DICT_KEY_IMAGE_COUNT)
        self.expect_image_count = 0
        self.load_and_verify()

    def test_non_integer_value_fails(self) -> None:
        self.change_key(_DICT_KEY_IMAGE_COUNT, 'grub')
        self.load_and_verify_exception_not_an_integer(_DICT_KEY_IMAGE_COUNT)

class TestTeaseRating(_TestTeaseBase):
    def test_specific_value_produces_expected_value(self) -> None:
        self.change_key(_DICT_KEY_RATING, 2)
        self.expect_rating = 2
        self.load_and_verify()

        self.change_key(_DICT_KEY_RATING, 4.3)
        self.expect_rating = 4.3
        self.load_and_verify()

    def test_out_of_range_value_fails(self) -> None:
        self.change_key(_DICT_KEY_RATING, 0.9)
        self.load_and_verify_exception_number_below_minimum(_DICT_KEY_RATING, 0.9, 1)

        self.change_key(_DICT_KEY_RATING, 5.1)
        self.load_and_verify_exception_number_above_maximum(_DICT_KEY_RATING, 5.1, 5)

    def test_missing_key_uses_default(self) -> None:
        self.remove_key(_DICT_KEY_RATING)
        self.expect_rating = 0
        self.load_and_verify()

    def test_non_decimal_value_fails(self) -> None:
        self.change_key(_DICT_KEY_RATING, 'grub')
        self.load_and_verify_exception_not_a_decimal_number(_DICT_KEY_RATING)

class TestTeaseTeaseId(_TestTeaseBase):
    def test_specific_value_produces_expected_value(self) -> None:
        self.change_key(_DICT_KEY_TEASE_ID, 235911)
        self.expect_tease_id = 235911
        self.load_and_verify()

    def test_out_of_range_value_fails(self) -> None:
        self.change_key(_DICT_KEY_TEASE_ID, 0)
        self.load_and_verify_exception_number_below_minimum(_DICT_KEY_TEASE_ID, 0, 1)

    def test_missing_key_fails(self) -> None:
        self.remove_key(_DICT_KEY_TEASE_ID)
        self.load_and_verify_exception_missing_key(_DICT_KEY_TEASE_ID)

    def test_non_integer_value_fails(self) -> None:
        self.change_key(_DICT_KEY_TEASE_ID, 'plant')
        self.load_and_verify_exception_not_an_integer(_DICT_KEY_TEASE_ID)

class TestTeaseTags(_TestTeaseBase):
    def test_specific_value_produces_expected_value(self) -> None:
        self.change_key(_DICT_KEY_TAGS, ':ancient:frozen:wolf:')
        self.expect_tags = ['ancient', 'frozen', 'wolf']
        self.load_and_verify()

    def test_empty_value_produces_empty_list(self) -> None:
        self.change_key(_DICT_KEY_TAGS, '')
        self.expect_tags = []
        self.load_and_verify()

    def test_empty_value_with_only_delimiters_produces_empty_list(self) -> None:
        self.change_key(_DICT_KEY_TAGS, '::')
        self.expect_tags = []
        self.load_and_verify()

    def test_value_without_outer_delimiters_produces_list(self) -> None:
        self.change_key(_DICT_KEY_TAGS, 'chomp:paper:niche')
        self.expect_tags = ['chomp', 'paper', 'niche']
        self.load_and_verify()

    def test_value_with_black_tags_are_not_in_list(self) -> None:
        self.change_key(_DICT_KEY_TAGS, ':chomp::niche::')
        self.expect_tags = ['chomp', 'niche']
        self.load_and_verify()

    def test_missing_key_produces_empty_list(self) -> None:
        self.remove_key(_DICT_KEY_TAGS)
        self.expect_tags = []
        self.load_and_verify()

    def test_non_string_value_fails(self) -> None:
        self.change_key(_DICT_KEY_TAGS, 9211)
        self.load_and_verify_exception_not_a_string(_DICT_KEY_TAGS)

    def test_totm_nominee_tag_sets_totm_status(self) -> None:
        self.change_key(_DICT_KEY_TAGS, ':captain:totm-nominee:private:')
        self.expect_tags = ['captain', 'totm-nominee', 'private']
        self.expect_totm = TotmStatus.NOMINEE
        self.load_and_verify()

    def test_totm_tag_sets_totm_status(self) -> None:
        self.change_key(_DICT_KEY_TAGS, ':mad:crazy:totm:')
        self.expect_tags = ['mad', 'crazy', 'totm']
        self.expect_totm = TotmStatus.WINNER
        self.load_and_verify()

    def test_multiple_totm_tags_sets_totm_status(self) -> None:
        self.change_key(_DICT_KEY_TAGS, ':totm:mad:crazy:totm-nominee:')
        self.expect_tags = ['totm', 'mad', 'crazy', 'totm-nominee']
        self.expect_totm = TotmStatus.WINNER
        self.load_and_verify()

        self.change_key(_DICT_KEY_TAGS, ':mad:totm-nominee:crazy:totm')
        self.expect_tags = ['mad', 'totm-nominee', 'crazy', 'totm']
        self.expect_totm = TotmStatus.WINNER
        self.load_and_verify()

class TestTeaseText(_TestTeaseBase):
    def test_specific_value_produces_expected_value(self) -> None:
        self.change_key(_DICT_KEY_TEXT, ['bananas', 'and', 'cream'])
        self.expect_text = ['bananas', 'and', 'cream']
        self.load_and_verify()

    def test_empty_list_produces_empty_list(self) -> None:
        self.change_key(_DICT_KEY_TEXT, [])
        self.expect_text = []
        self.load_and_verify()

    def test_list_of_one_entry_produces_list_with_one_entry(self) -> None:
        self.change_key(_DICT_KEY_TEXT, ['mangos'])
        self.expect_text = ['mangos']
        self.load_and_verify()

    def test_missing_key_produces_empty_list(self) -> None:
        self.remove_key(_DICT_KEY_TEXT)
        self.expect_text = []
        self.load_and_verify()

    def test_non_list_fails(self) -> None:
        self.change_key(_DICT_KEY_TEXT, 'bongos')
        self.load_and_verify_exception_not_a_list(_DICT_KEY_TEXT)

    def test_list_with_non_string_entry_fails(self) -> None:
        self.change_key(_DICT_KEY_TEXT, ['scored', 'twenty', 21, 'one'])
        self.load_and_verify_exception_not_a_string_in_list(_DICT_KEY_TEXT, 2)

class TestTeaseThumbnail(_TestTeaseBase):
    def test_specific_value_produces_expected_value(self) -> None:
        self.change_key(_DICT_KEY_THUMBNAIL, 'another thumbnail')
        self.expect_thumbnail = 'another thumbnail'
        self.load_and_verify()

    def test_empty_value_produces_empty_field(self) -> None:
        self.change_key(_DICT_KEY_THUMBNAIL, '')
        self.expect_thumbnail = ''
        self.load_and_verify()

    def test_missing_key_produces_blank_field(self) -> None:
        self.remove_key(_DICT_KEY_THUMBNAIL)
        self.expect_thumbnail = ''
        self.load_and_verify()

    def test_non_string_value_fails(self) -> None:
        self.change_key(_DICT_KEY_THUMBNAIL, 77)
        self.load_and_verify_exception_not_a_string(_DICT_KEY_THUMBNAIL)

class TestTeaseUniqueImageCount(_TestTeaseBase):
    def test_specific_value_produces_expected_value(self) -> None:
        self.change_key(_DICT_KEY_UNIQUE_IMAGE_COUNT, 19451)
        self.expect_unique_image_count = 19451
        self.load_and_verify()

    def test_out_of_range_value_fails(self) -> None:
        self.change_key(_DICT_KEY_UNIQUE_IMAGE_COUNT, -1)
        self.load_and_verify_exception_number_below_minimum(_DICT_KEY_UNIQUE_IMAGE_COUNT, -1, 0)

    def test_missing_key_uses_default(self) -> None:
        self.remove_key(_DICT_KEY_UNIQUE_IMAGE_COUNT)
        self.expect_unique_image_count = 0
        self.load_and_verify()

    def test_non_integer_value_fails(self) -> None:
        self.change_key(_DICT_KEY_UNIQUE_IMAGE_COUNT, 'bonza')
        self.load_and_verify_exception_not_an_integer(_DICT_KEY_UNIQUE_IMAGE_COUNT)
