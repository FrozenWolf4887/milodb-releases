# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from dataclasses import dataclass, field
from unittest.mock import Mock
from milodb.command_framework.i_command import ICommand
from milodb.commands.url_command import UrlCommand
from milodb.database.tease import Tease
from milodb.output.output_writer import IOutputWriter
from milodb.query.tease_match import TeaseMatch
from milodb_test.commands import fake_teases
from milodb_test.commands.error_messages import ErrorMessage
from milodb_test.commands.test_command_base import CommandTestBase
from milodb_test.strict_mock import StrictMock

def _get_tease_url(tease_id: int) -> str:
    return f'https://milovana.com/webteases/showtease.php?id={tease_id}'

def _get_author_url(tease_id: int) -> str:
    return f'https://milovana.com/forum/memberlist.php?mode=viewprofile&u={tease_id}'

_DEFAULT_LIST_OF_TEASES: list[Tease] = [
    fake_teases.TEASE_ID_1000_AUTHOR_ID_4567,
    fake_teases.TEASE_ID_1234_AUTHOR_ID_6431,
    fake_teases.TEASE_ID_5678_AUTHOR_ID_4567
]

@dataclass
class _Args:
    list_of_teases: list[Tease] = field(default_factory=_DEFAULT_LIST_OF_TEASES.copy)
    list_of_tease_matches: list[TeaseMatch] = field(default_factory=list)
    normal_writer: StrictMock = field(default_factory=lambda: StrictMock(IOutputWriter))
    error_writer: StrictMock = field(default_factory=lambda: StrictMock(IOutputWriter))

class TestUrlCommand(CommandTestBase):
    def setUp(self) -> None:
        self._args = _Args()
        return super().setUp()

    def create_command(self) -> ICommand:
        return UrlCommand(
            self._args.list_of_teases,
            self._args.list_of_tease_matches,
            self._args.normal_writer,
            self._args.error_writer
        )

    def test_without_arguments_returns_failure(self) -> None:
        self.command_load([])
        self.assert_argument_error(None, ErrorMessage.INSUFFICIENT_EXPECTING_REFID, [])
        self.assert_next_text([])

    def test_with_matching_index_prints_url(self) -> None:
        self._args.list_of_tease_matches = [
            TeaseMatch(0, fake_teases.TEASE_ID_5678_AUTHOR_ID_4567, []),
            TeaseMatch(1, fake_teases.TEASE_ID_1234_AUTHOR_ID_6431, []),
            TeaseMatch(2, fake_teases.TEASE_ID_1000_AUTHOR_ID_4567, [])
        ]
        self._args.normal_writer.writeln = Mock()
        self.command_load_and_execute(['1'])
        self._args.normal_writer.writeln.assert_called_once_with(_get_tease_url(1234))
        self.assert_next_text([])

    def test_with_out_of_range_index_prints_error(self) -> None:
        self._args.list_of_tease_matches = [
            TeaseMatch(0, fake_teases.TEASE_ID_5678_AUTHOR_ID_4567, []),
            TeaseMatch(1, fake_teases.TEASE_ID_1234_AUTHOR_ID_6431, []),
            TeaseMatch(2, fake_teases.TEASE_ID_1000_AUTHOR_ID_4567, [])
        ]
        self._args.error_writer.writeln = Mock()
        self.command_load_and_execute(['3'])
        self._args.error_writer.writeln.assert_called_once_with("Match index '3' is out of range")
        self.assert_next_text([])

    def test_with_negative_index_returns_failure(self) -> None:
        self.command_load(['-1'])
        self.assert_argument_error(1, ErrorMessage.INVALID_REFID, [])

    def test_with_two_indices_returns_failure(self) -> None:
        self.command_load(['1234', '5678'])
        self.assert_argument_error(2, ErrorMessage.UNEXPECTED, [])

    def test_with_one_teaseid_prints_url(self) -> None:
        self._args.normal_writer.writeln = Mock()
        self.command_load_and_execute(['#1234'])
        self._args.normal_writer.writeln.assert_called_once_with(_get_tease_url(1234))
        self.assert_next_text([])

    def test_with_two_teaseids_returns_failure(self) -> None:
        self.command_load(['#1234', '#5678'])
        self.assert_argument_error(2, ErrorMessage.UNEXPECTED, [])

    def test_with_signed_teaseid_returns_failure(self) -> None:
        self.command_load(['#-5678'])
        self.assert_argument_error(1, ErrorMessage.INVALID_TEASEID, [])

    def test_with_unknown_teaseid_returns_failure(self) -> None:
        self._args.error_writer.writeln = Mock()
        self.command_load_and_execute(['#5001'])
        self._args.error_writer.writeln.assert_called_once_with("Unable to find tease for tease id '5001'")
        self.assert_next_text([])

    def test_with_one_authorid_prints_url(self) -> None:
        self._args.normal_writer.writeln = Mock()
        self.command_load_and_execute(['@75310'])
        self._args.normal_writer.writeln.assert_called_once_with(_get_author_url(75310))
        self.assert_next_text([])

    def test_with_two_authorids_returns_failure(self) -> None:
        self.command_load(['@75310', '@8642'])
        self.assert_argument_error(2, ErrorMessage.UNEXPECTED, [])

    def test_with_signed_authorid_returns_failure(self) -> None:
        self.command_load(['@-8642'])
        self.assert_argument_error(1, ErrorMessage.INVALID_AUTHORID, [])

    def test_with_unknown_authorid_prints_url(self) -> None:
        self._args.normal_writer.writeln = Mock()
        self.command_load_and_execute(['@12345'])
        self._args.normal_writer.writeln.assert_called_once_with(_get_author_url(12345))
        self.assert_next_text([])

    def test_with_non_refid_returns_failure(self) -> None:
        self.command_load(['mango'])
        self.assert_argument_error(1, ErrorMessage.INVALID_REFID, [])
