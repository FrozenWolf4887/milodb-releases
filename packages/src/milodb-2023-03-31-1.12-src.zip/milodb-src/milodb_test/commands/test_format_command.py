# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from dataclasses import dataclass, field
from unittest.mock import Mock, call
from milodb.command_framework.i_command import ICommand
from milodb.commands.format_command import FormatCommand
from milodb.datum.ref_datum import RefDatum
from milodb.output.output_writer import IOutputWriter
from milodb.output.outputter import IOutputter
from milodb_test.commands.error_messages import ErrorMessage
from milodb_test.commands.test_command_base import CommandTestBase
from milodb_test.strict_mock import StrictMock

MOCK_OUTPUTTER_CHEESE: StrictMock = StrictMock(IOutputter)
MOCK_OUTPUTTER_CHEESE.get_name = Mock(return_value='Cheese')
MOCK_OUTPUTTER_BISCUITS: StrictMock = StrictMock(IOutputter)
MOCK_OUTPUTTER_BISCUITS.get_name = Mock(return_value='Biscuits')
MOCK_OUTPUTTER_WHISKEY: StrictMock = StrictMock(IOutputter)
MOCK_OUTPUTTER_WHISKEY.get_name = Mock(return_value='Whiskey')

@dataclass
class _Args:
    current_outputter: RefDatum[IOutputter] = field(default_factory=lambda: RefDatum(MOCK_OUTPUTTER_CHEESE))
    list_of_outputters: list[IOutputter] = field(default_factory=lambda: [MOCK_OUTPUTTER_CHEESE, MOCK_OUTPUTTER_BISCUITS, MOCK_OUTPUTTER_WHISKEY])
    normal_writer: StrictMock = field(default_factory=lambda: StrictMock(IOutputWriter))

class TestFormatCommand(CommandTestBase):
    def setUp(self) -> None:
        self._args: _Args = _Args()
        return super().setUp()

    def create_command(self) -> ICommand:
        return FormatCommand(
            self._args.current_outputter,
            self._args.list_of_outputters,
            self._args.normal_writer
        )

    def test_without_arguments_prints_current_setting_without_change(self) -> None:
        for initial_outputter in (MOCK_OUTPUTTER_CHEESE, MOCK_OUTPUTTER_BISCUITS, MOCK_OUTPUTTER_WHISKEY):
            with self.subTest(initial_outputter=initial_outputter):
                self.setUp()
                self._args.current_outputter = RefDatum(initial_outputter)
                self._args.normal_writer.writeln = Mock()
                self.command_load_and_execute([])
                self._args.normal_writer.writeln.assert_has_calls([
                    call(f"Current format is '{initial_outputter.get_name()}'"),
                    call("Available formats are ['Cheese', 'Biscuits', 'Whiskey']")])
                self.assertIs(initial_outputter, self._args.current_outputter.get())
                self.assert_next_text(['Cheese', 'Biscuits', 'Whiskey'])

    def test_with_argument_changes_setting_regardless_of_initial_setting(self) -> None:
        for initial_outputter in (MOCK_OUTPUTTER_CHEESE, MOCK_OUTPUTTER_BISCUITS, MOCK_OUTPUTTER_WHISKEY):
            for new_outputter in (MOCK_OUTPUTTER_CHEESE, MOCK_OUTPUTTER_BISCUITS, MOCK_OUTPUTTER_WHISKEY):
                with self.subTest(initial_outputter=initial_outputter):
                    self.setUp()
                    self._args.current_outputter = RefDatum(initial_outputter)
                    self._args.normal_writer.writeln = Mock()
                    self.command_load_and_execute([new_outputter.get_name()])
                    self._args.normal_writer.writeln.assert_called_once_with(f"Changed format to '{new_outputter.get_name()}'")
                    self.assertIs(new_outputter, self._args.current_outputter.get())
                    self.assert_next_text([])

    def test_with_one_invalid_argument_returns_failure(self) -> None:
        self.command_load(['Wine'])
        self.assert_argument_error(1, ErrorMessage.INVALID, ['Cheese', 'Biscuits', 'Whiskey'])

    def test_with_redundant_argument_returns_failure(self) -> None:
        self.command_load(['Whiskey', 'Biscuits'])
        self.assert_argument_error(2, ErrorMessage.UNEXPECTED, [])
