# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from dataclasses import dataclass, field
from unittest.mock import Mock
from milodb.command_framework.i_command import ICommand
from milodb.commands.browse_command import BrowseCommand
from milodb.database.tease import Tease
from milodb.output.html import IHtmlOutputter
from milodb.output.output_writer import IOutputWriter
from milodb.query.tease_match import TeaseMatch
from milodb_test.commands import fake_teases
from milodb_test.commands.test_command_base import CommandTestBase
from milodb_test.strict_mock import StrictMock

_DEFAULT_LIST_OF_TEASES: list[Tease] = [
    fake_teases.TEASE_ID_1000_AUTHOR_ID_4567,
    fake_teases.TEASE_ID_1234_AUTHOR_ID_6431,
    fake_teases.TEASE_ID_5678_AUTHOR_ID_4567,
    fake_teases.TEASE_ID_2000_AUTHOR_ID_6431,
    fake_teases.TEASE_ID_8721_AUTHOR_ID_7213
]

@dataclass
class _Args:
    list_of_teases: list[Tease] = field(default_factory=_DEFAULT_LIST_OF_TEASES.copy)
    list_of_tease_matches: list[TeaseMatch] = field(default_factory=list)
    outputter: StrictMock = field(default_factory=lambda: StrictMock(IHtmlOutputter))
    use_highlighting: bool = True
    use_ellipsis: bool = True
    ellipsis_max_width: int = 58
    normal_writer: StrictMock = field(default_factory=lambda: StrictMock(IOutputWriter))
    error_writer: StrictMock = field(default_factory=lambda: StrictMock(IOutputWriter))

class TestBrowseCommand(CommandTestBase):
    def setUp(self) -> None:
        self._args: _Args = _Args()
        return super().setUp()

    def create_command(self) -> ICommand:
        return BrowseCommand(
            self._args.list_of_teases,
            self._args.list_of_tease_matches,
            self._args.outputter,
            self._args.use_highlighting,
            self._args.use_ellipsis,
            self._args.ellipsis_max_width,
            self._args.normal_writer,
            self._args.error_writer
        )

    def test_without_arguments_and_no_matches_outputs_error(self) -> None:
        self._args.error_writer.writeln = Mock()
        self.command_load_and_execute([])
        self._args.error_writer.writeln.assert_called_once_with('No teases available to browse')
        self.assert_next_text([])
