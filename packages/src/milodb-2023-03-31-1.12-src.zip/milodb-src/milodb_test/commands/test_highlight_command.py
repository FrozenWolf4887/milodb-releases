# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from dataclasses import dataclass, field
from unittest.mock import Mock, call
from milodb.command_framework.i_command import ICommand
from milodb.commands.highlight_command import HighlightCommand
from milodb.datum.ref_datum import RefDatum
from milodb.output.output_writer import IOutputWriter
from milodb_test.commands.error_messages import ErrorMessage
from milodb_test.commands.test_command_base import CommandTestBase
from milodb_test.strict_mock import StrictMock

@dataclass
class _Args:
    use_highlighting: RefDatum[bool] = field(default_factory=lambda: RefDatum(True))
    normal_writer: StrictMock = field(default_factory=lambda: StrictMock(IOutputWriter))

class TestHighlightCommand(CommandTestBase):
    def setUp(self) -> None:
        self._args: _Args = _Args()
        return super().setUp()

    def create_command(self) -> ICommand:
        return HighlightCommand(
            self._args.use_highlighting,
            self._args.normal_writer
        )

    def test_without_arguments_prints_current_setting_without_change(self) -> None:
        for initial_use_highlighting in (True, False):
            with self.subTest(initial_use_highlighting=initial_use_highlighting):
                self.setUp()
                self._args.use_highlighting = RefDatum(initial_use_highlighting)
                self._args.normal_writer.writeln = Mock()
                self.command_load_and_execute([])
                current_setting: str = 'on' if initial_use_highlighting else 'off'
                self._args.normal_writer.writeln.assert_has_calls([
                    call(f"Current highlighting is '{current_setting}'"),
                    call("Available options are ['on', 'off']")])
                self.assertEqual(initial_use_highlighting, self._args.use_highlighting.get())
                self.assert_next_text(['on', 'off'])

    def test_with_argument_changes_setting_regardless_of_initial_setting(self) -> None:
        for initial_use_highlighting in (True, False):
            for change_use_highlighting in (True, False):
                with self.subTest(initial_use_highlighting=initial_use_highlighting):
                    self.setUp()
                    self._args.use_highlighting = RefDatum(initial_use_highlighting)
                    self._args.normal_writer.writeln = Mock()
                    new_setting: str = 'on' if change_use_highlighting else 'off'
                    self.command_load_and_execute([new_setting])
                    self._args.normal_writer.writeln.assert_called_once_with(f"Changed highlighting to '{new_setting}'")
                    self.assertEqual(change_use_highlighting, self._args.use_highlighting.get())
                    self.assert_next_text([])

    def test_with_invalid_argument_returns_failure(self) -> None:
        self.command_load(['mango'])
        self.assert_argument_error(1, ErrorMessage.INVALID_ENUM, ['on', 'off'])

    def test_with_redundant_argument_returns_failure(self) -> None:
        self.command_load(['on', 'off'])
        self.assert_argument_error(2, ErrorMessage.UNEXPECTED, [])
