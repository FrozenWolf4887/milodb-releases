# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
import datetime
from collections.abc import Callable
from enum import Enum
from typing import Any, TypeAlias
from milodb.commands.enums import EnumEx

class TeaseType(EnumEx):
    REGULAR = 'reg'
    AUDIO = 'aud'
    NYX = 'nyx'
    EOS = 'eos'

class TotmStatus(Enum):
    NONE = 0
    NOMINEE = 1
    WINNER = 2

TeasePropertyType: TypeAlias = str | int | float | TeaseType | list[str] | datetime.date | TotmStatus
TeaseProperty: TypeAlias = Callable[['Tease'], TeasePropertyType]
TeaseStrProperty: TypeAlias = Callable[['Tease'], str]
TeaseIntProperty: TypeAlias = Callable[['Tease'], int]
TeaseFloatProperty: TypeAlias = Callable[['Tease'], float]
TeaseTypeProperty: TypeAlias = Callable[['Tease'], TeaseType]
TeaseDateProperty: TypeAlias = Callable[['Tease'], datetime.date]
TeaseTotmProperty: TypeAlias = Callable[['Tease'], TotmStatus]
TeaseStrListProperty: TypeAlias = Callable[['Tease'], list[str]]

_KEY_TEASE_ID: str = 'tid'
_KEY_AUTHOR_ID: str = 'aid'
_KEY_TYPE: str = 'typ'
_KEY_TITLE: str = 'ttl'
_KEY_SUMMARY: str = 'sum'
_KEY_THUMBNAIL: str = 'thm'
_KEY_AUTHOR_NAME: str = 'anm'
_KEY_TAGS: str = 'tgs'
_KEY_DATE: str = 'dat'
_KEY_RATING: str = 'rvl'
_KEY_TEXT: str = 'txt'
_KEY_IMAGE_COUNT: str = 'imr'
_KEY_UNIQUE_IMAGE_COUNT: str = 'imu'
_TAG_TOTM_WINNER: str = 'totm'
_TAG_TOTM_NOMINEE: str = 'totm-nominee'

class Tease:
    class LoadError(Exception):
        pass

    def __init__(self, metadata: dict[Any, Any]) -> None:
        self._tease_id: int = _get_meta_int_with_min_value(metadata, _KEY_TEASE_ID, 1)
        self._author_id: (int | None) = _try_get_meta_int_with_min_value(metadata, _KEY_AUTHOR_ID, 0)
        raw_type: int = _get_meta_int(metadata, _KEY_TYPE)
        possible_type: (TeaseType | None) = _MAP_OF_RAW_TYPE_TO_COOKED_TYPE.get(raw_type)
        if not possible_type:
            raise Tease.LoadError(f"Type of tease '{raw_type}' is unknown")
        self._type: TeaseType = possible_type
        self._title: str = _get_meta_str_or_blank(metadata, _KEY_TITLE)
        self._summary: str = _get_meta_str_or_blank(metadata, _KEY_SUMMARY)
        self._thumbnail: str = _get_meta_str_or_blank(metadata, _KEY_THUMBNAIL)
        self._author_name: str = _get_meta_str_or_blank(metadata, _KEY_AUTHOR_NAME)
        raw_tags: str = _get_meta_str_or_blank(metadata, _KEY_TAGS)
        self._tags: list[str] = [tag for tag in raw_tags.split(':') if tag]
        self._date: datetime.date = _get_meta_date(metadata, _KEY_DATE)
        self._rating_value: float = _get_meta_float_or_default(metadata, _KEY_RATING, 1, 5, 0.0)
        self._list_of_text_blocks: list[str] = []
        self._totm_status = TotmStatus.NONE
        if _TAG_TOTM_NOMINEE in self._tags:
            self._totm_status = TotmStatus.NOMINEE
        if _TAG_TOTM_WINNER in self._tags:
            self._totm_status = TotmStatus.WINNER
        self._list_of_text_blocks = _get_meta_str_list_or_empty(metadata, _KEY_TEXT)
        self._count_of_images = _get_meta_int_with_min_value_or_default(metadata, _KEY_IMAGE_COUNT, 0, 0)
        self._count_of_unique_images = _get_meta_int_with_min_value_or_default(metadata, _KEY_UNIQUE_IMAGE_COUNT, 0, 0)

    def tease_id(self) -> int:
        return self._tease_id

    def has_author(self) -> bool:
        return bool(self._author_id)

    def author_id(self) -> int:
        return self._author_id or 0

    def type(self) -> TeaseType:
        return self._type

    def title(self) -> str:
        return self._title

    def summary(self) -> str:
        return self._summary

    def thumbnail(self) -> str:
        return self._thumbnail

    def author_name(self) -> str:
        return self._author_name

    def list_of_tags(self) -> list[str]:
        return self._tags

    def date(self) -> datetime.date:
        return self._date

    def rating_value(self) -> float:
        return self._rating_value

    def totm_status(self) -> TotmStatus:
        return self._totm_status

    def list_of_text_blocks(self) -> list[str]:
        return self._list_of_text_blocks

    def count_of_images(self) -> int:
        return self._count_of_images

    def count_of_unique_images(self) -> int:
        return self._count_of_unique_images

    def get_text_of_property(self, tease_property: TeaseProperty) -> str:
        value: TeasePropertyType = tease_property(self)
        if isinstance(value, TeaseType):
            return value.value
        if isinstance(value, str):
            return value
        if isinstance(value, (int, float)):
            return str(value)
        if isinstance(value, datetime.date):
            return value.isoformat()
        return ''

_MAP_OF_RAW_TYPE_TO_COOKED_TYPE: dict[int, TeaseType] = {
    0: TeaseType.REGULAR,
    1: TeaseType.NYX,
    2: TeaseType.EOS,
    3: TeaseType.AUDIO
}

def _try_get_meta_int(metadata: dict[str, Any], key: str) -> (int | None):
    value: Any = metadata.get(key)
    if value is None:
        return None
    if not isinstance(value, int):
        raise Tease.LoadError(f"Key '{key}' is not an integer")
    return value

def _try_get_meta_int_with_min_value(metadata: dict[str, Any], key: str, min_value: int) -> (int | None):
    value: (int | None) = _try_get_meta_int(metadata, key)
    if value is None:
        return None
    if value < min_value:
        raise Tease.LoadError(f"Key '{key}' value '{value}' should be at least '{min_value}'")
    return value

def _get_meta_int(metadata: dict[str, Any], key: str) -> int:
    value: (int | None) = _try_get_meta_int(metadata, key)
    if value is None:
        raise Tease.LoadError(f"Key '{key}' is missing")
    return value

def _get_meta_int_with_min_value(metadata: dict[str, Any], key: str, min_value: int) -> int:
    value: int = _get_meta_int(metadata, key)
    if value < min_value:
        raise Tease.LoadError(f"Key '{key}' value '{value}' should be at least '{min_value}'")
    return value

def _get_meta_int_with_min_value_or_default(metadata: dict[str, Any], key: str, min_value: int, default_value: int) -> int:
    value: (int | None) = _try_get_meta_int(metadata, key)
    if value is None:
        return default_value
    if value < min_value:
        raise Tease.LoadError(f"Key '{key}' value '{value}' should be at least '{min_value}'")
    return value

def _get_meta_float_or_default(metadata: dict[str, Any], key: str, min_value: float, max_value: float, default_value: float) -> float:
    value: Any = metadata.get(key)
    if value is None:
        return default_value
    if not isinstance(value, (float, int)):
        raise Tease.LoadError(f"Key '{key}' is not a decimal")
    if value < min_value:
        raise Tease.LoadError(f"Key '{key}' value '{value}' should be at least '{min_value}'")
    if value > max_value:
        raise Tease.LoadError(f"Key '{key}' value '{value}' should be at most '{max_value}'")
    return float(value)

def _get_meta_str_or_blank(metadata: dict[str, Any], key: str) -> str:
    value: Any = metadata.get(key, '')
    if isinstance(value, str):
        return value
    raise Tease.LoadError(f"Key '{key}' is not a string")

def _get_meta_date(metadata: dict[str, Any], key: str) -> datetime.date:
    value: Any = metadata.get(key)
    if value is None:
        raise Tease.LoadError(f"Key '{key}' is missing")
    if not isinstance(value, str):
        raise Tease.LoadError(f"Key '{key}' is not a string")
    try:
        return datetime.date.fromisoformat(value)
    except ValueError as ex:
        raise Tease.LoadError(f"Key '{key}' value '{value}' is not a valid ISO date") from ex

def _get_meta_str_list_or_empty(metadata: dict[str, Any], key: str) -> list[str]:
    value: Any = metadata.get(key)
    if value is None:
        return []
    if not isinstance(value, list):
        raise Tease.LoadError(f"Key '{key}' is not a list")
    list_of_values: list[Any] = value
    list_of_strings: list[str] = []
    index: int
    for index, value in enumerate(list_of_values):
        if not isinstance(value, str):
            raise Tease.LoadError(f"Key '{key}' list entry #{index} is not a string")
        list_of_strings.append(value)
    return list_of_strings
