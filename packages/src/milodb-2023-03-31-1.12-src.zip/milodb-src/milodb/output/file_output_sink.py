# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from typing import IO
from milodb.output.output_sink import IOutputSink

class FileOutputSink(IOutputSink):
    def __init__(self, file: IO[str]) -> None:
        self._file: IO[str] = file

    def write(self, text: str) -> None:
        self._file.write(text)
