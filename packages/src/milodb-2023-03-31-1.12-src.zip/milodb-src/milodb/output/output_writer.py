# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from abc import ABC, abstractmethod
from milodb.output.output_sink import IOutputSink
from milodb.output.string_builder import StringBuilder

class IOutputWriter(ABC):
    @abstractmethod
    def writeln(self, text: (str | None) = None) -> None:
        pass

class ISinkingWriter(ABC):
    @abstractmethod
    def get_sink(self) -> IOutputSink:
        pass

    @abstractmethod
    def set_sink(self, output_sink: IOutputSink) -> None:
        pass

class SinkingWriter(ISinkingWriter):
    def __init__(self, output_sink: IOutputSink) -> None:
        self._output_sink: IOutputSink = output_sink

    def get_sink(self) -> IOutputSink:
        return self._output_sink

    def set_sink(self, output_sink: IOutputSink) -> None:
        self._output_sink = output_sink

class NormalOutputWriter(SinkingWriter, IOutputWriter):
    def writeln(self, text: (str | None) = None) -> None:
        if text:
            self._output_sink.write(text)
        self._output_sink.write('\n')

class ErrorOutputWriter(SinkingWriter, IOutputWriter):
    def writeln(self, text: (str | None) = None) -> None:
        if text:
            self._output_sink.write(f'Error: {text}')
        self._output_sink.write('\n')

class WarningOutputWriter(SinkingWriter, IOutputWriter):
    def writeln(self, text: (str | None) = None) -> None:
        if text:
            self._output_sink.write(f'Warning: {text}')
        self._output_sink.write('\n')

class CapturingOutputWriter(IOutputWriter):
    def __init__(self) -> None:
        self._text: StringBuilder = StringBuilder()

    def writeln(self, text: (str | None) = None) -> None:
        if text:
            self._text.put(text)
            self._text.put('\n')

    def clear(self) -> None:
        self._text.clear()

    def __str__(self) -> str:
        return self.text

    @property
    def text(self) -> str:
        return self._text.get_text()
