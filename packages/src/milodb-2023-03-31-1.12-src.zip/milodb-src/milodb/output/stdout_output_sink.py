# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from milodb.output.output_sink import IOutputSink

class StdoutOutputSink(IOutputSink):
    def write(self, text: str) -> None:
        if text:
            print(text, end='')
