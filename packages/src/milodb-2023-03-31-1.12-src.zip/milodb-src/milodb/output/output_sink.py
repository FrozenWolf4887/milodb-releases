# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from abc import ABC, abstractmethod
from milodb.output.string_builder import StringBuilder

class IOutputSink(ABC):
    @abstractmethod
    def write(self, text: str) -> None:
        pass

class SplitOutputSink(IOutputSink):
    def __init__(self, list_of_output_sinks: list[IOutputSink]) -> None:
        self._list_of_output_sinks = list_of_output_sinks

    def write(self, text: str) -> None:
        output_sink: IOutputSink
        for output_sink in self._list_of_output_sinks:
            output_sink.write(text)

class CapturingOutputSink(IOutputSink):
    def __init__(self) -> None:
        self._text: StringBuilder = StringBuilder()

    def write(self, text: str) -> None:
        self._text.put(text)

    @property
    def text(self) -> str:
        return self._text.get_text()
