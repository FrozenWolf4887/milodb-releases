# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from abc import ABC, abstractmethod
from milodb.output.output_writer import IOutputWriter
from milodb.query.tease_match import TeaseMatch

class IOutputter(ABC):
    @abstractmethod
    def get_name(self) -> str:
        pass
    @abstractmethod
    def print_list_of_teases(self, list_of_tease_matches: list[TeaseMatch], use_highlighting: bool, normal_writer: IOutputWriter) -> None:
        pass
    @abstractmethod
    def print_summary_of_tease(self, tease_match: TeaseMatch, use_highlighting: bool, normal_writer: IOutputWriter) -> None:
        pass
    @abstractmethod
    def print_all_text_of_list_of_teases(self, list_of_tease_matches: list[TeaseMatch], use_highlighting: bool, normal_writer: IOutputWriter) -> None:
        pass
    @abstractmethod
    def print_matching_text_of_list_of_teases(self, list_of_tease_matches: list[TeaseMatch], use_highlighting: bool, ellipsis_max_width: (int | None), normal_writer: IOutputWriter) -> None:
        pass
