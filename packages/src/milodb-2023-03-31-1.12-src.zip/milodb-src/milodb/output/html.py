# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
import re
from abc import abstractmethod
from milodb.config.html_config import HtmlConfig
from milodb.database.tease import Tease, TeaseProperty, TeaseStrListProperty, TotmStatus
from milodb.output.output_writer import IOutputWriter
from milodb.output.outputter import IOutputter
from milodb.output.support import EllipsisLocation, ellipsify_text, get_list_of_indexed_metadata_indices, get_list_of_metadata_indices, get_url_of_author, get_url_of_tease, iterate_through_indices, iterate_through_lines
from milodb.query.field_match import IFieldMatch
from milodb.query.tease_match import TeaseMatch

_MAP_OF_TOTM_STATUS_TO_IMG_TAG: dict[TotmStatus, str] = {
    TotmStatus.NONE: '',
    TotmStatus.NOMINEE: '<img src="milodb-totm-nominee.png" alt="TOTM - Nominee!">',
    TotmStatus.WINNER: '<img src="milodb-totm-winner.png" alt="TOTM - Winner!">'
}

CSS_KEYWORD_PATTERN: re.Pattern[str] = re.compile(r'\${([a-zA-Z_-]+)}')

class IHtmlOutputter(IOutputter):
    @abstractmethod
    def try_write_browse_file_of_text_matches(self, list_of_tease_matches: list[TeaseMatch], use_highlighting: bool, ellipsis_max_width: (int | None), normal_writer: IOutputWriter, error_writer: IOutputWriter, icon_filepath: str) -> bool:
        pass

    @abstractmethod
    def try_write_browse_file_of_all_text(self, list_of_tease_matches: list[TeaseMatch], use_highlighting: bool, normal_writer: IOutputWriter, error_writer: IOutputWriter, icon_filepath: str) -> bool:
        pass

class HtmlOutputter(IHtmlOutputter):
    def __init__(self, html_config: HtmlConfig) -> None:
        self._html_config: HtmlConfig = html_config

    def get_name(self) -> str:
        return 'html'

    def print_list_of_teases(self, list_of_tease_matches: list[TeaseMatch], use_highlighting: bool, normal_writer: IOutputWriter) -> None:
        normal_writer.writeln((
            '<div class="listTable">\n'
            '<div class="th hits">Hits</div>'
            '<div class="th teaseId">Id</div>'
            '<div class="th type">Type</div>'
            '<div class="th rating">Rating</div>'
            '<div class="th date">Date</div>'
            '<div class="th title">Title</div>'
            '<div class="th author">Author</div>'))
        tease_match: TeaseMatch
        for tease_match in list_of_tease_matches:
            _print_oneline_of_tease(tease_match, use_highlighting, normal_writer)
        normal_writer.writeln('</div>')

        total_text = f"{len(list_of_tease_matches)} match{'es' if len(list_of_tease_matches) != 1 else ''}"
        normal_writer.writeln(f'<div class="totalMatches">{total_text}</div>')

    def print_summary_of_tease(self, tease_match: TeaseMatch, use_highlighting: bool, normal_writer: IOutputWriter) -> None:
        hit_count: int = tease_match.get_match_count()
        tease_id: int = tease_match.tease.tease_id()
        author_id: int = tease_match.tease.author_id()
        url_of_tease: str = get_url_of_tease(tease_id)
        url_of_author: str = get_url_of_author(author_id)
        formatted_tease_id: str = _highlight_metadata(tease_match, Tease.tease_id, use_highlighting)
        formatted_tease_title: str = _highlight_metadata(tease_match, Tease.title, use_highlighting)
        formatted_author_link: str = 'unknown'
        formatted_author_name: str = 'unknown'
        if tease_match.tease.has_author():
            formatted_author_id: str = _highlight_metadata(tease_match, Tease.author_id, use_highlighting)
            formatted_author_name = _highlight_metadata(tease_match, Tease.author_name, use_highlighting)
            formatted_author_link = f'<a href="{url_of_author}">{formatted_author_id}</a>'
        formatted_tease_date: str = _highlight_metadata(tease_match, Tease.date, use_highlighting)
        formatted_tease_type: str = _highlight_metadata(tease_match, Tease.type, use_highlighting)
        formatted_tags: str = ', '.join(_highlight_metadata_string_list(tease_match, Tease.list_of_tags, use_highlighting, None, False))
        formatted_tease_rating: str = _highlight_metadata(tease_match, Tease.rating_value, use_highlighting)
        formatted_summary: str = _highlight_metadata(tease_match, Tease.summary, use_highlighting)
        totm_img_tag: str = _MAP_OF_TOTM_STATUS_TO_IMG_TAG.get(tease_match.tease.totm_status(), '')
        normal_writer.writeln((
            '<div class="summaryTable">\n'
            f'<div class="td thumbnail"><a href="{url_of_tease}"><img src="{tease_match.tease.thumbnail()}" alt="Thumbnail"></a></div>'
            '<div class="th hits">Hits</div>'
            '<div class="th teaseId">Tease</div>'
            '<div class="th teaseTitle">Title</div>'
            '<div class="th authorId">Author</div>'
            '<div class="th authorName">Name</div>'
            '<div class="th type">Type</div>'
            '<div class="th date">Date</div>'
            '<div class="th rating">Rating</div>'
            '<div class="th tags">Tags</div>'
            '<div class="th summary">Summary</div>\n'
            f'<div class="td hits">{hit_count}</div>'
            f'<div class="td teaseId"><a href="{url_of_tease}">{formatted_tease_id}</a></div>'
            f'<div class="td authorId">{formatted_author_link}</div>'
            f'<div class="td type">{formatted_tease_type}</div>'
            f'<div class="td rating">{formatted_tease_rating}</div>'
            f'<div class="td summary">{formatted_summary if formatted_summary else "None"}</div>'
            f'<div class="td title">{totm_img_tag}{formatted_tease_title}</div>'
            f'<div class="td authorName">{formatted_author_name}</div>'
            f'<div class="td date">{formatted_tease_date}</div>'
            f'<div class="td tags">{formatted_tags}</div>\n'
            '</div>'))

    def print_all_text_of_list_of_teases(self, list_of_tease_matches: list[TeaseMatch], use_highlighting: bool, normal_writer: IOutputWriter) -> None:
        tease_match: TeaseMatch
        for tease_match in list_of_tease_matches:
            self.print_summary_of_tease(tease_match, use_highlighting, normal_writer)
            _print_all_text_of_tease(tease_match, use_highlighting, normal_writer)

    def print_matching_text_of_list_of_teases(self, list_of_tease_matches: list[TeaseMatch], use_highlighting: bool, ellipsis_max_width: (int | None), normal_writer: IOutputWriter) -> None:
        tease_match: TeaseMatch
        for tease_match in list_of_tease_matches:
            self.print_summary_of_tease(tease_match, use_highlighting, normal_writer)
            _print_matching_text_of_tease(tease_match, use_highlighting, ellipsis_max_width, normal_writer)

    def try_write_browse_file_of_text_matches(self, list_of_tease_matches: list[TeaseMatch], use_highlighting: bool, ellipsis_max_width: (int | None), normal_writer: IOutputWriter, error_writer: IOutputWriter, icon_filepath: str) -> bool:
        css: (str | None) = _try_load_css(self._html_config, error_writer)
        if css:
            _write_file_header(css, icon_filepath, normal_writer)
            self.print_list_of_teases(list_of_tease_matches, use_highlighting, normal_writer)
            self.print_matching_text_of_list_of_teases(list_of_tease_matches, use_highlighting, ellipsis_max_width, normal_writer)
            _write_file_footer(normal_writer)
            return True
        return False

    def try_write_browse_file_of_all_text(self, list_of_tease_matches: list[TeaseMatch], use_highlighting: bool, normal_writer: IOutputWriter, error_writer: IOutputWriter, icon_filepath: str) -> bool:
        css: (str | None) = _try_load_css(self._html_config, error_writer)
        if css:
            _write_file_header(css, icon_filepath, normal_writer)
            self.print_list_of_teases(list_of_tease_matches, use_highlighting, normal_writer)
            self.print_all_text_of_list_of_teases(list_of_tease_matches, use_highlighting, normal_writer)
            _write_file_footer(normal_writer)
            return True
        return False

def _print_oneline_of_tease(tease_match: TeaseMatch, use_highlighting: bool, normal_writer: IOutputWriter) -> None:
    hit_count: int = tease_match.get_match_count()
    tease_id: int = tease_match.tease.tease_id()
    author_id: int = tease_match.tease.author_id()
    url_of_tease: str = get_url_of_tease(tease_id)
    url_of_author: str = get_url_of_author(author_id)
    formatted_tease_id: str = _highlight_metadata(tease_match, Tease.tease_id, use_highlighting)
    formatted_tease_type: str = _highlight_metadata(tease_match, Tease.type, use_highlighting)
    formatted_tease_rating: str = _highlight_metadata(tease_match, Tease.rating_value, use_highlighting)
    formatted_tease_date: str = _highlight_metadata(tease_match, Tease.date, use_highlighting)
    formatted_tease_title: str = _highlight_metadata(tease_match, Tease.title, use_highlighting)
    formatted_author_text: str = 'unknown'
    if tease_match.tease.has_author():
        formatted_author_name: str = _highlight_metadata(tease_match, Tease.author_name, use_highlighting)
        formatted_author_text = f'<a href="{url_of_author}">{formatted_author_name}</a>'
    totm_img_tag: str = _MAP_OF_TOTM_STATUS_TO_IMG_TAG.get(tease_match.tease.totm_status(), '')
    normal_writer.writeln((
        f'<div class="td hits">{hit_count}</div>'
        f'<div class="td teaseId"><a href="{url_of_tease}">{formatted_tease_id}</a></div>'
        f'<div class="td type">{formatted_tease_type}</div>'
        f'<div class="td rating">{formatted_tease_rating}</div>'
        f'<div class="td date">{formatted_tease_date}</div>'
        f'<div class="td title">{totm_img_tag}{formatted_tease_title}</div>'
        f'<div class="td author">{formatted_author_text}</div>'))

def _print_all_text_of_tease(tease_match: TeaseMatch, use_highlighting: bool, normal_writer: IOutputWriter) -> None:
    list_of_formatted_text: list[str] = _highlight_metadata_string_list(tease_match, Tease.list_of_text_blocks, use_highlighting, None, False)
    if list_of_formatted_text:
        normal_writer.writeln((
            '<div class="textTable">\n'
            '<div class="th text">Text</div>\n'))

        formatted_text_block: str
        for formatted_text_block in list_of_formatted_text:
            normal_writer.writeln(f'<x-page>{formatted_text_block}</x-page>')

        normal_writer.writeln('</div>')

def _print_matching_text_of_tease(tease_match: TeaseMatch, use_highlighting: bool, ellipsis_max_width: (int | None), normal_writer: IOutputWriter) -> None:
    list_of_formatted_text = _highlight_metadata_string_list(tease_match, Tease.list_of_text_blocks, use_highlighting, ellipsis_max_width, True)
    if list_of_formatted_text:
        normal_writer.writeln((
            '<div class="textTable">\n'
            '<div class="th text">Matching text</div>'))

        formatted_text_block: str
        for formatted_text_block in list_of_formatted_text:
            normal_writer.writeln(f'<x-page>{formatted_text_block}</x-page>')

        normal_writer.writeln('</div>')

def _highlight_metadata(tease_match: TeaseMatch, tease_property: TeaseProperty, use_highlighting: bool) -> str:
    field_value: str = tease_match.tease.get_text_of_property(tease_property)
    formatted_value: str = _highlight_text(field_value, get_list_of_metadata_indices(tease_property, tease_match.list_of_field_matches), use_highlighting, None)
    return formatted_value

def _highlight_metadata_string_list(tease_match: TeaseMatch, tease_property: TeaseStrListProperty, use_highlighting: bool, ellipsis_max_width: (int | None), include_matching_only: bool) -> list[str]:
    list_of_formatted_text: list[str] = []

    index_of_block: int
    text_block: str
    for index_of_block, text_block in enumerate(tease_property(tease_match.tease)):
        list_of_indices: list[IFieldMatch.Indices] = get_list_of_indexed_metadata_indices(tease_property, index_of_block, tease_match.list_of_field_matches)
        formatted_text: (str | None) = None
        if list_of_indices:
            formatted_text = _highlight_text(text_block, list_of_indices, use_highlighting, ellipsis_max_width if ellipsis_max_width and include_matching_only else None)
        elif not include_matching_only:
            formatted_text = _escape_text(text_block)
            formatted_text = _convert_lines_to_paragraphs(formatted_text)

        if formatted_text is not None:
            list_of_formatted_text.append(formatted_text)

    return list_of_formatted_text

def _highlight_text(text: str, list_of_indices: list[IFieldMatch.Indices], use_highlighting: bool, ellipsis_max_width: (int | None)) -> str:
    formatted_text = ''

    def on_normal_text(text: str, is_first_item: bool, is_last_item: bool) -> None:
        nonlocal formatted_text
        if ellipsis_max_width:
            formatted_text += _ellipsify_and_escape_text_item(text, is_first_item, is_last_item, ellipsis_max_width)
        else:
            formatted_text += _escape_text(text)

    def on_matched_text(text: str, _is_first_item: bool, _is_last_item: bool) -> None:
        nonlocal formatted_text
        if use_highlighting:
            iterate_through_lines(text, on_highlight_text, on_end_of_line_text)
        else:
            formatted_text += _escape_text(text)

    def on_highlight_text(text: str) -> None:
        nonlocal formatted_text
        formatted_text += '<span class="matchingText">'
        formatted_text += _escape_text(text)
        formatted_text += '</span>'

    def on_end_of_line_text(text: str) -> None:
        nonlocal formatted_text
        formatted_text += text

    iterate_through_indices(text, list_of_indices, on_normal_text, on_matched_text)

    formatted_text = _convert_lines_to_paragraphs(formatted_text)
    return formatted_text

def _ellipsify_and_escape_text_item(text: str, is_first_item: bool, is_last_item: bool, ellipsis_max_width: int) -> str:
    formatted_text: str = ''

    def on_text(text: str) -> None:
        nonlocal formatted_text
        formatted_text += _escape_text(text)

    def on_ellipsis() -> None:
        nonlocal formatted_text
        formatted_text += '<span class="ellipsis">&hellip;</span>'

    ellipsify_text(text, ellipsis_max_width, EllipsisLocation.from_position(is_first_item, is_last_item), on_text, on_ellipsis)

    return formatted_text

def _try_load_css(html_config: HtmlConfig, error_writer: IOutputWriter) -> (str | None):
    css: (str | None) = None
    try:
        with open(html_config.css_file_path, 'rt', encoding='utf-8') as file:
            css = file.read()
    except IOError as ex:
        error_writer.writeln(f"Failed to load CSS file '{html_config.css_file_path}': {ex}")
    if css:
        css = CSS_KEYWORD_PATTERN.sub(lambda match: _replace_css_keyword(match, html_config, error_writer), css)
    return css

def _replace_css_keyword(match: re.Match[str], html_config: HtmlConfig, error_writer: IOutputWriter) -> str:
    keyword: str = match.group(1)
    replacement_text: (str | None) = html_config.try_get_colour_field(keyword)
    if replacement_text is None:
        error_writer.writeln(f"Unknown keyword '{keyword}' in CSS file '{html_config.css_file_path}'")
    return replacement_text or 'black'

def _write_file_header(css: str, icon_filepath: str, normal_writer: IOutputWriter) -> None:
    normal_writer.writeln((
        '<!DOCTYPE html>\n'
        '<html lang="en">\n'
        ' <head>\n'
        '  <meta charset="utf-8">\n'
        '  <title>MiloDB Results</title>\n'
        f'  <link rel="icon" type="image/png" href="{icon_filepath}">\n'
        '  <style>\n'
        f'{css}'
        '  </style>\n'
        ' </head>\n'
        ' <body>'))

def _write_file_footer(normal_writer: IOutputWriter) -> None:
    normal_writer.writeln((
        ' </body>\n'
        '</html>'))

def _escape_text(text: str) -> str:
    return text.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')

def _convert_lines_to_paragraphs(text: str) -> str:
    paragraph_text: str = ''
    line: str
    for line in text.split('\n'):
        paragraph_text += f'<div>{line}</div>'
    return paragraph_text
