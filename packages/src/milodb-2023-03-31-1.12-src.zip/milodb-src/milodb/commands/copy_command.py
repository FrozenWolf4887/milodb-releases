# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from typing import Any
import pyperclip # type: ignore
from milodb.command_framework.argument_stream import ArgumentStream
from milodb.command_framework.command_loader import CommandLoader
from milodb.command_framework.i_command import CommandLoadError, ICommand
from milodb.command_framework.i_command_factory import ICommandFactory
from milodb.command_framework.i_command_loader import CommandLoadDelegateError, EmptyInputResult, LoadResult, SuccessfulLoadResult
from milodb.command_framework.i_help_info import IHelpInfo
from milodb.output.output_sink import CapturingOutputSink, IOutputSink, SplitOutputSink
from milodb.output.output_writer import ISinkingWriter

class CopyCommand(ICommand):
    def __init__(self, command_factory: ICommandFactory, list_of_writers: list[ISinkingWriter]) -> None:
        self._command_factory: ICommandFactory = command_factory
        self._list_of_writers: list[ISinkingWriter] = list_of_writers
        self._delegate_command: (ICommand | None) = None

    def load(self, argument_stream: ArgumentStream) -> list[str]:
        command_loader: CommandLoader = CommandLoader(self._command_factory)
        load_result: LoadResult = command_loader.try_load(argument_stream)
        if isinstance(load_result, SuccessfulLoadResult):
            self._delegate_command = load_result.command
            return load_result.list_of_possible_next_text
        if isinstance(load_result, EmptyInputResult):
            raise CommandLoadError(
                'Expecting a following command', None, load_result.list_of_command_names)
        raise CommandLoadDelegateError(load_result)

    def execute(self) -> None:
        if self._delegate_command:
            with _Capture(self._list_of_writers):
                self._delegate_command.execute()

    class Help(IHelpInfo):
        def get_one_line_summary(self) -> str:
            return "Copies the output of the subsequent command to the clipboard"

        def get_detailed_summary(self) -> str:
            return (
                "Arguments: <subsequent command...>\n"
                "The output of the subsequent command is copied to the clipboard in the currently"
                " selected format.\n"
                "Example:\r"
                "  \tList the current query results and copy the list to the clipboard\r"
                "  > \tcopy list\n"
                "Example:\r"
                "  \tCopy the url of the author of match #3 to the clipboard\r"
                "  > \tcopy urlauthor 3\n"
                "See also:\r"
                "  \tformat, ellipsis, highlight\n"
            )

class _Capture:
    def __init__(self, list_of_writers: list[ISinkingWriter]) -> None:
        self._list_of_writers: list[ISinkingWriter] = list_of_writers
        self._list_of_sinks: list[IOutputSink] = []
        self._capturing_text_output: CapturingOutputSink

    def __enter__(self) -> None:
        self._capturing_text_output = CapturingOutputSink()
        writer: ISinkingWriter
        for writer in self._list_of_writers:
            current_sink: IOutputSink = writer.get_sink()
            self._list_of_sinks.append(current_sink)
            writer.set_sink(SplitOutputSink([current_sink, self._capturing_text_output]))

    def __exit__(self, exc_type: Any, exc_value: Any, traceback: Any) -> None:
        index: int
        writer: ISinkingWriter
        for index, writer in enumerate(self._list_of_writers):
            writer.set_sink(self._list_of_sinks[index])
        try:
            pyperclip.copy(self._capturing_text_output.text.rstrip())  # type: ignore
        except pyperclip.PyperclipException as ex:
            print(f'Error: Unable to copy to clipboard: {ex}')

    @property
    def text(self) -> str:
        return self._capturing_text_output.text
