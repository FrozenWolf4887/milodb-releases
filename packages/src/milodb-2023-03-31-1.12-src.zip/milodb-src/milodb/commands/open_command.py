# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
import webbrowser
from milodb.command_framework.argument_stream import ArgumentStream
from milodb.command_framework.i_command import ICommand
from milodb.command_framework.i_help_info import IHelpInfo
from milodb.command_framework.ref_id import AuthorId, RefId
from milodb.commands.database_support import try_create_list_of_tease_matches_from_ref_ids
from milodb.database.tease import Tease
from milodb.output.output_writer import IOutputWriter
from milodb.output.support import get_url_of_author, get_url_of_tease
from milodb.query.tease_match import TeaseMatch

class OpenCommand(ICommand):
    def __init__(self, list_of_teases: list[Tease], list_of_tease_matches: list[TeaseMatch], normal_writer: IOutputWriter, error_writer: IOutputWriter) -> None:
        self._list_of_teases: list[Tease] = list_of_teases
        self._list_of_tease_matches: list[TeaseMatch] = list_of_tease_matches
        self._normal_writer: IOutputWriter = normal_writer
        self._error_writer: IOutputWriter = error_writer
        self._list_of_ref_ids: list[RefId] = []
        self._list_of_author_ids: list[int] = []

    def load(self, argument_stream: ArgumentStream) -> list[str]:
        list_of_ref_ids: list[RefId] = ArgumentStream.pop_minimum_list(1, argument_stream.pop_ref_id, argument_stream.pop_optional_ref_id)
        ref_id: RefId
        for ref_id in list_of_ref_ids:
            if isinstance(ref_id, AuthorId):
                self._list_of_author_ids.append(ref_id.author_id)
            else:
                self._list_of_ref_ids.append(ref_id)
        return []

    def execute(self) -> None:
        list_of_tease_matches: (list[TeaseMatch] | None) = None
        is_ref_id_list_reasonable: bool = True
        if self._list_of_ref_ids:
            list_of_tease_matches = try_create_list_of_tease_matches_from_ref_ids(self._list_of_teases, self._list_of_tease_matches, self._list_of_ref_ids, self._error_writer)

            if list_of_tease_matches:
                tease_match: TeaseMatch
                for tease_match in list_of_tease_matches:
                    tease_url: str = get_url_of_tease(tease_match.tease.tease_id())
                    self._normal_writer.writeln(f"Opening '{tease_url}': {tease_match.tease.title()}")
                    webbrowser.open(tease_url)
            else:
                self._error_writer.writeln("No teases available to open")
                is_ref_id_list_reasonable = False

        if is_ref_id_list_reasonable:
            for author_id in self._list_of_author_ids:
                author_url: str = get_url_of_author(author_id)
                self._normal_writer.writeln(f"Opening '{author_url}'")
                webbrowser.open(author_url)

    class Help(IHelpInfo):
        def get_one_line_summary(self) -> str:
            return "Opens a specified tease or author profile in the default browser"

        def get_detailed_summary(self) -> str:
            return (
                "Arguments: <list of RefIds>\n"
                "Opens one or more teases or author profiles in the default browser from the list of"
                " RefIds. This effectively opens the link to the original tease or author profile on "
                " Milovana.\n"
                "RefIds can be an index into the list of matches such as '3', a teaseId such as"
                " '#38664', or an authorId such as '@43937'.\n"
                "Example:\r"
                "  \tOpen a tease by index in the match list\r"
                "  > \topen 3\r"
                "Example:\r"
                "  \tOpen a tease by its specific teaseId\r"
                "  > \topen #16830\r"
                "Example:\r"
                "  \tOpen the profile of a specific authorId\r"
                "  > \topen @43937\n"
                "See also:\r"
                "  \topenauthor, url, urlauthor"
            )
