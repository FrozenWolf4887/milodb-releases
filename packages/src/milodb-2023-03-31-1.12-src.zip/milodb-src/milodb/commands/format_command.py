# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from milodb.command_framework.argument_stream import ArgumentStream
from milodb.command_framework.i_command import ICommand
from milodb.command_framework.i_help_info import IHelpInfo
from milodb.datum.ref_datum import RefDatum
from milodb.output.output_writer import IOutputWriter
from milodb.output.outputter import IOutputter

class FormatCommand(ICommand):
    def __init__(self, current_outputter: RefDatum[IOutputter], list_of_outputters: list[IOutputter], normal_writer: IOutputWriter) -> None:
        self._current_outputter: RefDatum[IOutputter] = current_outputter
        self._list_of_outputters: list[IOutputter] = list_of_outputters
        self._normal_writer: IOutputWriter = normal_writer
        self._new_outputter: (IOutputter | None) = None

    def load(self, argument_stream: ArgumentStream) -> list[str]:
        map_of_outputter_name_to_object: dict[str, IOutputter] = {}
        for outputter in self._list_of_outputters:
            map_of_outputter_name_to_object[outputter.get_name()] = outputter
        self._new_outputter = argument_stream.pop_optional_dict_value(map_of_outputter_name_to_object)
        if self._new_outputter is not None:
            argument_stream.fail_if_not_empty()
            return []
        return _get_list_of_outputter_names(self._list_of_outputters)

    def execute(self) -> None:
        if self._new_outputter:
            self._current_outputter.set(self._new_outputter)
            self._normal_writer.writeln(f"Changed format to '{self._new_outputter.get_name()}'")
        else:
            self._normal_writer.writeln(f"Current format is '{self._current_outputter.get().get_name()}'")
            self._normal_writer.writeln(f"Available formats are {_get_list_of_outputter_names(self._list_of_outputters)}")

    class Help(IHelpInfo):
        def __init__(self, list_of_outputters: list[IOutputter]) -> None:
            self._list_of_outputters: list[IOutputter] = list_of_outputters

        def get_one_line_summary(self) -> str:
            return "Sets the formatting used in the output of commands"

        def get_detailed_summary(self) -> str:
            return (
                f"Arguments: [{'|'.join(_get_list_of_outputter_names(self._list_of_outputters))}]\n"
                "Changes the output format that is produced by commands such as list, summary,"
                " and show. Some of the formats are more suitable for copy-pasting into another"
                " application that supports that format; 'bbcode' for example is suitable to be"
                " pasted into the Milovana forums.\n"
                "When used without arguments, the current setting is shown.\n"
                "Example:\r"
                "  \tSelect the bbcode output format\r"
                "  > \tformat bbcode\r"
                "Example:\r"
                "  \tShow the current setting\r"
                "  > \tformat\n"
                "See also:\r"
                "  \tlist, summary, show, ellipsis, highlight\n"
            )

def _get_list_of_outputter_names(list_of_outputters: list[IOutputter]) -> list[str]:
    return [outputter.get_name() for outputter in list_of_outputters]
