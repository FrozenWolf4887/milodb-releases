# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
import os
import sys
from typing import BinaryIO

_root_path: str
if getattr(sys, 'frozen', False) and hasattr(sys, '_MEIPASS'):
    _root_path = sys._MEIPASS # type: ignore # pylint: disable=protected-access
else:
    _root_path = os.path.dirname(__file__)

def resource_path(relative_path: str) -> str:
    return os.path.join(_root_path, 'resources', relative_path)

def try_copy_file(source_filepath: str, target_filepath: str) -> bool:
    was_successful: bool = False

    try:
        source_file: BinaryIO
        target_file: BinaryIO
        with open(source_filepath, 'rb') as source_file:
            with open(target_filepath, 'w+b') as target_file:
                target_file.write(source_file.read())
        was_successful = True
    except IOError as ex:
        print(f"ERROR: Unable to copy '{source_filepath}' to '{target_filepath}': {ex}")

    return was_successful
