# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from milodb.config.config_schema import ConfigSchema
from milodb.config.framework import IConfig

class BBCodeConfig:
    def __init__(self, config: IConfig) -> None:
        self._config = config

    @property
    def index_heading_colour(self) -> str:
        return self._config.get_config_value(ConfigSchema.format_bbcode_colour_index_heading)

    @property
    def hits_heading_colour(self) -> str:
        return self._config.get_config_value(ConfigSchema.format_bbcode_colour_hits_heading)

    @property
    def tease_heading_colour(self) -> str:
        return self._config.get_config_value(ConfigSchema.format_bbcode_colour_tease_heading)

    @property
    def author_heading_colour(self) -> str:
        return self._config.get_config_value(ConfigSchema.format_bbcode_colour_author_heading)

    @property
    def type_heading_colour(self) -> str:
        return self._config.get_config_value(ConfigSchema.format_bbcode_colour_type_heading)

    @property
    def date_heading_colour(self) -> str:
        return self._config.get_config_value(ConfigSchema.format_bbcode_colour_date_heading)

    @property
    def rating_heading_colour(self) -> str:
        return self._config.get_config_value(ConfigSchema.format_bbcode_colour_rating_heading)

    @property
    def tags_heading_colour(self) -> str:
        return self._config.get_config_value(ConfigSchema.format_bbcode_colour_tags_heading)

    @property
    def summary_heading_colour(self) -> str:
        return self._config.get_config_value(ConfigSchema.format_bbcode_colour_summary_heading)

    @property
    def matching_text_heading_colour(self) -> str:
        return self._config.get_config_value(ConfigSchema.format_bbcode_colour_matching_text_heading)

    @property
    def matching_text_colour(self) -> str:
        return self._config.get_config_value(ConfigSchema.format_bbcode_colour_matching_text)

    @property
    def ellipsis_colour(self) -> str:
        return self._config.get_config_value(ConfigSchema.format_bbcode_colour_ellipsis)
