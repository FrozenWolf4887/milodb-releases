# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import contextlib
import tkinter as tk
from typing import TYPE_CHECKING
from milodb_client.view.gui import general_style
from milodb_client.view.gui.styled_text import StyledText
from milodb_client.view.gui.tk_interceptor import TkInterceptor
if TYPE_CHECKING:
    from collections.abc import Sequence

_TK_INSERT_ARG_COUNT: int = 2
_TK_INSERT_TEXT_ARG_INDEX: int = 1

class TextEx(StyledText):
    CARET_MOVED_BINDING: str = '<<CaretMoved>>'
    TEXT_CHANGED_BINDING: str = '<<TextChanged>>'

    def __init__(self, master: tk.Misc, *, style: str=general_style.TEXT, width: int=80) -> None:
        super().__init__(master, style=style, width=width, height=1, wrap='none')

        self._style: str = style
        self._caret_index: int = 0
        self._change_theme_event_id: str | None = None

        self.bind('<Return>', lambda _event: 'break')
        self.bind('<Tab>', self._on_tab)
        self.bind('<<Paste>>', self._on_paste)
        self.bind('<<PasteSelection>>', self._on_paste)

        self.event_add(self.CARET_MOVED_BINDING, 'None')
        self.event_add(self.TEXT_CHANGED_BINDING, 'None')

        interceptor: TkInterceptor = TkInterceptor(self)
        self._original_tk_mark: TkInterceptor.Handler = interceptor.intercept("mark", self._on_tk_mark)
        self._original_tk_insert: TkInterceptor.Handler = interceptor.intercept("insert", self._on_tk_insert)
        self._original_tk_delete: TkInterceptor.Handler = interceptor.intercept("delete", self._on_tk_delete)

        self.tag_config('err', foreground='#000', background='#F88', selectforeground='#800', underline=True, underlinefg='#FFF')

    def get_text(self) -> str:
        text: str = self.get('1.0', tk.END)
        return text[:-1]

    def get_caret_index(self) -> int:
        return self._caret_index

    def clear_error(self) -> None:
        self.tag_remove('err', '1.0', tk.END)

    def show_error(self, begin_index: int, end_index: int | None = None) -> None:
        self.clear_error()
        self.tag_add('err', f'1.{begin_index}', f'1.{end_index if end_index is not None else begin_index+1}')

    def _on_tk_mark(self, *args: object) -> object:
        result: object = self._original_tk_mark(*args)
        self._update_caret()
        return result

    def _on_tk_insert(self, *args: object) -> object:
        result: object = self._original_tk_insert(*args)
        if len(args) == _TK_INSERT_ARG_COUNT and args[_TK_INSERT_TEXT_ARG_INDEX]:
            self.event_generate(self.TEXT_CHANGED_BINDING)
        self._update_caret()
        return result

    def _on_tk_delete(self, *args: object) -> object:
        result: object = self._original_tk_delete(*args)
        self.event_generate(self.TEXT_CHANGED_BINDING)
        self._update_caret()
        return result

    def _get_caret_index(self) -> int:
        cursor_index_text: str = self.index(tk.INSERT)
        if cursor_index_text:
            list_of_values: Sequence[str] = cursor_index_text.rsplit('.', maxsplit=1)
            if list_of_values:
                with contextlib.suppress(ValueError):
                    return int(list_of_values[-1])
        return 0

    def _update_caret(self) -> None:
        caret_index: int = self._get_caret_index()
        if caret_index != self._caret_index:
            self._caret_index = caret_index
            self.event_generate(self.CARET_MOVED_BINDING)

    def _on_tab(self, _: object) -> str:
        next_control: tk.Misc | None = self.tk_focusNext()
        if next_control:
            next_control.focus()
        return 'break'

    def _on_paste(self, _: object) -> str | None:
        text: str | None = self._get_clipboard()
        if text is not None:
            text = _cut_text_at_line_break(text)
            self._delete_selection()
            self.insert(self.index(tk.INSERT), text)
            self.see(self.index(tk.INSERT))
        return 'break'

    def _delete_selection(self) -> None:
        index_of_selection_begin: str | None = None
        index_of_selection_end: str | None = None
        try:
            index_of_selection_begin = self.index(tk.SEL_FIRST)
            index_of_selection_end = self.index(tk.SEL_LAST)
        except tk.TclError:
            pass

        if index_of_selection_begin and index_of_selection_end:
            self.delete(index_of_selection_begin, index_of_selection_end)

    def _get_clipboard(self) -> str | None:
        text: object = None
        try:
            root: tk.Tk | tk.Toplevel = self.winfo_toplevel()
            text = root.clipboard_get()
        except tk.TclError:
            pass
        if isinstance(text, str):
            return text
        return None

def _cut_text_at_line_break(text: str) -> str:
    lf_pos: int = text.find('\n')
    cr_pos: int = text.find('\r')
    break_pos: int = -1
    if lf_pos != -1:
        break_pos = lf_pos
    if cr_pos != -1 and cr_pos < break_pos:
        break_pos = cr_pos
    if break_pos != -1:
        text = text[:break_pos]
    return text
