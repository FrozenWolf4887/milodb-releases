from abc import ABC, abstractmethod
from typing import Optional

class OutputSink(ABC):
    @abstractmethod
    def write(self, text: str) -> None:
        pass

    def writeln(self, text: Optional[str] = None) -> None:
        if (text):
            self.write(text)
        self.write('\n')

class OutputWriter(ABC):
    @abstractmethod
    def writeln(self, text: str) -> None:
        pass

    @abstractmethod
    def redirect_output(self, output_sink: OutputSink):
        pass

class ErrorOutputWriter(OutputWriter):
    def __init__(self, output_sink: OutputSink):
        self._output_sink: OutputSink = output_sink

    def writeln(self, text: str) -> None:
        self._output_sink.writeln(f'Error: {text}')

    def redirect_output(self, output_sink: 'OutputSink'):
        self._output_sink = output_sink

class WarningOutputWriter(OutputWriter):
    def __init__(self, output_sink: OutputSink):
        self._output_sink: OutputSink = output_sink

    def writeln(self, text: str) -> None:
        self._output_sink.writeln(f'Warning: {text}')

    def redirect_output(self, output_sink: 'OutputSink'):
        self._output_sink = output_sink
