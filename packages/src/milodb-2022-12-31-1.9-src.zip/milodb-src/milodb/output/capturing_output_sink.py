from milodb.output.output_sink import OutputSink
from typing import List

_MAX_SMALL_CHUNKS: int = 100

class CapturingOutputSink(OutputSink):
    def __init__(self, original_output_sink: OutputSink) -> None:
        self._text: _StringBuilder = _StringBuilder()
        self._original_output_sink: OutputSink = original_output_sink

    def write(self, text: str) -> None:
        self._original_output_sink.write(text)
        self._text.put(text)

    @property
    def text(self) -> str:
        return self._text.get_text()

class _StringBuilder:
    def __init__(self) -> None:
        self._list_of_big_chunks: List[str] = []
        self._list_of_small_chunks: List[str] = []

    def put(self, text: str) -> None:
        if len(self._list_of_small_chunks) >= _MAX_SMALL_CHUNKS:
            big_chunk: str = ''.join(self._list_of_small_chunks)
            self._list_of_big_chunks.append(big_chunk)
            self._list_of_small_chunks = [text]
        else:
            self._list_of_small_chunks.append(text)

    def get_text(self) -> str:
        return ''.join(self._list_of_big_chunks) + ''.join(self._list_of_small_chunks)
