import milodb.query as query
from milodb.config import HtmlConfig, SessionConfig
from milodb.output.outputter import Outputter
from milodb.output.support import EllipsifyText, EllipsisLocation, IterateThroughMatches, get_list_of_indexed_metadata_matches, get_url_of_tease, get_url_of_author, get_list_of_metadata_matches, iterate_through_lines
from milodb.tease import Tease, TeaseProperty, TeaseStrListProperty, TotmStatus
import re
from typing import Dict, List, Optional

_MAP_OF_TOTM_STATUS_TO_IMG_TAG: Dict[TotmStatus, str] = {
    TotmStatus.NONE: '',
    TotmStatus.NOMINEE: '<img src="milodb-totm-nominee.png" alt="TOTM - Nominee!">',
    TotmStatus.WINNER: '<img src="milodb-totm-winner.png" alt="TOTM - Winner!">'
}

class HtmlOutputter(Outputter):
    def __init__(self, html_config: HtmlConfig, session_config: SessionConfig) -> None:
        self._html_config: HtmlConfig = html_config
        self._session_config: SessionConfig = session_config

    def get_name(self) -> str:
        return 'html'

    def print_list_of_teases(self, list_of_tease_matches: List[query.TeaseMatch]) -> None:
        self._session_config.normal_writer.write((
            '<div class="listTable">\n'
                '<div class="th hits">Hits</div>'
                '<div class="th teaseId">Id</div>'
                '<div class="th type">Type</div>'
                '<div class="th rating">Rating</div>'
                '<div class="th date">Date</div>'
                '<div class="th title">Title</div>'
                '<div class="th author">Author</div>\n'))
        tease_match: query.TeaseMatch
        for tease_match in list_of_tease_matches:
            self._print_oneline_of_tease(tease_match)
        self._session_config.normal_writer.write('</div>\n')

        total_text = f"{len(list_of_tease_matches)} match{'es' if len(list_of_tease_matches) != 1 else ''}"
        self._session_config.normal_writer.write(f'<div class="totalMatches">{total_text}</div>\n')

    def print_summary_of_tease(self, tease_match: query.TeaseMatch) -> None:
        hit_count: int = tease_match.get_match_count()
        tease_id: int = tease_match.tease.tease_id
        author_id: int = tease_match.tease.author_id
        url_of_tease: str = get_url_of_tease(tease_id)
        url_of_author: str = get_url_of_author(author_id)
        formatted_tease_id: str = self._highlight_metadata(tease_match, Tease.tease_id)
        formatted_tease_title: str = self._highlight_metadata(tease_match, Tease.title)
        formatted_author_link: str = 'unknown'
        formatted_author_name: str = 'unknown'
        if tease_match.tease.has_author:
            formatted_author_id: str = self._highlight_metadata(tease_match, Tease.author_id)
            formatted_author_name = self._highlight_metadata(tease_match, Tease.author_name)
            formatted_author_link = f'<a href="{url_of_author}">{formatted_author_id}</a>'
        formatted_tease_date: str = self._highlight_metadata(tease_match, Tease.date)
        formatted_tease_type: str = self._highlight_metadata(tease_match, Tease.type)
        formatted_tags: str = ', '.join(self._highlight_metadata_string_list(tease_match, Tease.list_of_tags, False, False))
        formatted_tease_rating: str = self._highlight_metadata(tease_match, Tease.rating_value)
        formatted_summary: str = self._highlight_metadata(tease_match, Tease.summary)
        totm_img_tag: str = _MAP_OF_TOTM_STATUS_TO_IMG_TAG.get(tease_match.tease.totm_status, '')
        self._session_config.normal_writer.write((
            '<div class="summaryTable">\n'
                f'<div class="td thumbnail"><a href="{url_of_tease}"><img src="{tease_match.tease.thumbnail}" alt="Thumbnail"></a></div>'
                '<div class="th hits">Hits</div>'
                '<div class="th teaseId">Tease</div>'
                '<div class="th teaseTitle">Title</div>'
                '<div class="th authorId">Author</div>'
                '<div class="th authorName">Name</div>'
                '<div class="th type">Type</div>'
                '<div class="th date">Date</div>'
                '<div class="th rating">Rating</div>'
                '<div class="th tags">Tags</div>'
                '<div class="th summary">Summary</div>\n'
                f'<div class="td hits">{hit_count}</div>'
                f'<div class="td teaseId"><a href="{url_of_tease}">{formatted_tease_id}</a></div>'
                f'<div class="td authorId">{formatted_author_link}</div>'
                f'<div class="td type">{formatted_tease_type}</div>'
                f'<div class="td rating">{formatted_tease_rating}</div>'
                f'<div class="td summary">{formatted_summary if formatted_summary else "None"}</div>'
                f'<div class="td title">{totm_img_tag}{formatted_tease_title}</div>'
                f'<div class="td authorName">{formatted_author_name}</div>'
                f'<div class="td date">{formatted_tease_date}</div>'
                f'<div class="td tags">{formatted_tags}</div>\n'
            '</div>\n'))

    def print_all_text_of_list_of_teases(self, list_of_tease_matches: List[query.TeaseMatch]) -> None:
        tease_match: query.TeaseMatch
        for tease_match in list_of_tease_matches:
            self.print_summary_of_tease(tease_match)
            self._print_all_text_of_tease(tease_match)

    def print_matching_text_of_list_of_teases(self, list_of_tease_matches: List[query.TeaseMatch]) -> None:
        tease_match: query.TeaseMatch
        for tease_match in list_of_tease_matches:
            self.print_summary_of_tease(tease_match)
            self._print_matching_text_of_tease(tease_match)

    def try_write_browse_file_of_text_matches(self, list_of_tease_matches: List[query.TeaseMatch], icon_filepath: str) -> bool:
        css: Optional[str] = self._try_load_css()
        if css:
            self._write_file_header(css, icon_filepath)
            self.print_list_of_teases(list_of_tease_matches)
            self.print_matching_text_of_list_of_teases(list_of_tease_matches)
            self._write_file_footer()
            return True
        else:
            return False

    def try_write_browse_file_of_all_text(self, list_of_tease_matches: List[query.TeaseMatch], icon_filepath: str) -> bool:
        css: Optional[str] = self._try_load_css()
        if css:
            self._write_file_header(css, icon_filepath)
            self.print_list_of_teases(list_of_tease_matches)
            self.print_all_text_of_list_of_teases(list_of_tease_matches)
            self._write_file_footer()
            return True
        else:
            return False

    def _print_oneline_of_tease(self, tease_match: query.TeaseMatch) -> None:
        hit_count: int = tease_match.get_match_count()
        tease_id: int = tease_match.tease.tease_id
        author_id: int = tease_match.tease.author_id
        url_of_tease: str = get_url_of_tease(tease_id)
        url_of_author: str = get_url_of_author(author_id)
        formatted_tease_id: str = self._highlight_metadata(tease_match, Tease.tease_id)
        formatted_tease_type: str = self._highlight_metadata(tease_match, Tease.type)
        formatted_tease_rating: str = self._highlight_metadata(tease_match, Tease.rating_value)
        formatted_tease_date: str = self._highlight_metadata(tease_match, Tease.date)
        formatted_tease_title: str = self._highlight_metadata(tease_match, Tease.title)
        formatted_author_text: str = 'unknown'
        if tease_match.tease.has_author:
            formatted_author_name: str = self._highlight_metadata(tease_match, Tease.author_name)
            formatted_author_text = f'<a href="{url_of_author}">{formatted_author_name}</a>'
        totm_img_tag: str = _MAP_OF_TOTM_STATUS_TO_IMG_TAG.get(tease_match.tease.totm_status, '')
        self._session_config.normal_writer.write((
            f'<div class="td hits">{hit_count}</div>'
            f'<div class="td teaseId"><a href="{url_of_tease}">{formatted_tease_id}</a></div>'
            f'<div class="td type">{formatted_tease_type}</div>'
            f'<div class="td rating">{formatted_tease_rating}</div>'
            f'<div class="td date">{formatted_tease_date}</div>'
            f'<div class="td title">{totm_img_tag}{formatted_tease_title}</div>'
            f'<div class="td author">{formatted_author_text}</div>\n'))

    def _print_all_text_of_tease(self, tease_match: query.TeaseMatch) -> None:
        list_of_formatted_text: List[str] = self._highlight_metadata_string_list(tease_match, Tease.list_of_text_blocks, False, False)
        if list_of_formatted_text:
            self._session_config.normal_writer.write((
                '<div class="textTable">\n'
                '<div class="th text">Text</div>\n'))

            formatted_text_block: str
            for formatted_text_block in list_of_formatted_text:
                self._session_config.normal_writer.write(f'<x-page>{formatted_text_block}</x-page>\n')

            self._session_config.normal_writer.write('</div>\n')

    def _print_matching_text_of_tease(self, tease_match: query.TeaseMatch) -> None:
        list_of_formatted_text = self._highlight_metadata_string_list(tease_match, Tease.list_of_text_blocks, True, self._session_config.is_ellipsis_enabled)
        if list_of_formatted_text:
            self._session_config.normal_writer.write((
                '<div class="textTable">\n'
                '<div class="th text">Matching text</div>\n'))

            formatted_text_block: str
            for formatted_text_block in list_of_formatted_text:
                self._session_config.normal_writer.write(f'<x-page>{formatted_text_block}</x-page>\n')

            self._session_config.normal_writer.write('</div>\n')

    def _highlight_metadata(self, tease_match: query.TeaseMatch, tease_property: TeaseProperty) -> str:
        field_value: str = tease_match.tease.get_text_of_property(tease_property)
        formatted_value: str = self._highlight_text(field_value, get_list_of_metadata_matches(tease_property, tease_match.list_of_query_matches), False)
        return formatted_value

    def _highlight_metadata_string_list(self, tease_match: query.TeaseMatch, tease_property: TeaseStrListProperty, include_matching_only: bool, use_ellipsis: bool) -> List[str]:
        list_of_formatted_text: List[str] = []

        index_of_block: int
        text_block: str
        for index_of_block, text_block in enumerate(tease_match.tease.get_str_list_property(tease_property)):
            list_of_match_details: List[query.MatchDetails] = get_list_of_indexed_metadata_matches(tease_property, index_of_block, tease_match.list_of_query_matches)
            formatted_text: Optional[str] = None
            if list_of_match_details:
                formatted_text = self._highlight_text(text_block, list_of_match_details, use_ellipsis and include_matching_only)
            elif not include_matching_only:
                formatted_text = _escape_text(text_block)
                formatted_text = _convert_lines_to_paragraphs(formatted_text)

            if formatted_text is not None:
                list_of_formatted_text.append(formatted_text)

        return list_of_formatted_text

    def _highlight_text(self, text: str, list_of_matches: List[query.MatchDetails], is_ellipsis_enabled: bool) -> str:
        formatted_text = ''

        def on_normal_text(text: str, is_first_item: bool, is_last_item: bool) -> None:
            nonlocal formatted_text
            if is_ellipsis_enabled:
                formatted_text += self._ellipsify_and_escape_text_item(text, is_first_item, is_last_item)
            else:
                formatted_text += _escape_text(text)

        def on_matched_text(text: str, is_first_item: bool, is_last_item: bool) -> None:
            nonlocal formatted_text
            if self._session_config.is_highlighting_enabled:
                iterate_through_lines(text, on_highlight_text, on_end_of_line_text)
            else:
                formatted_text += _escape_text(text)

        def on_highlight_text(text: str) -> None:
            nonlocal formatted_text
            formatted_text += '<span class="matchingText">'
            formatted_text += _escape_text(text)
            formatted_text += '</span>'

        def on_end_of_line_text(text: str) -> None:
            nonlocal formatted_text
            formatted_text += text

        IterateThroughMatches(text, list_of_matches, on_normal_text, on_matched_text)

        formatted_text = _convert_lines_to_paragraphs(formatted_text)
        return formatted_text

    def _ellipsify_and_escape_text_item(self, text, is_first_item: bool, is_last_item: bool) -> str:
        formatted_text: str = ''

        def on_text(text: str):
            nonlocal formatted_text
            formatted_text += _escape_text(text)

        def on_ellipsis():
            nonlocal formatted_text
            formatted_text += '<span class="ellipsis">&hellip;</span>'

        EllipsifyText(text, self._session_config.ellipsis_max_width, EllipsisLocation.from_position(is_first_item, is_last_item), on_text, on_ellipsis)

        return formatted_text

    def _write_file_header(self, css: str, icon_filepath: str) -> None:
        self._session_config.normal_writer.write((
            '<!DOCTYPE html>\n'
            '<html lang="en">\n'
            ' <head>\n'
            '  <meta charset="utf-8">\n'
            '  <title>MiloDB Results</title>\n'
            f'  <link rel="icon" type="image/png" href="{icon_filepath}">\n'
            '  <style>\n'
            f'{css}'
            '  </style>\n'
            ' </head>\n'
            ' <body>\n'))

    def _write_file_footer(self) -> None:
        self._session_config.normal_writer.write((
            ' </body>\n'
            '</html>\n'))

    def _try_load_css(self) -> Optional[str]:
        css: Optional[str] = None
        try:
            with open(self._html_config.css_file_path, 'rt') as file:
                css = file.read()
        except IOError as ex:
            self._session_config.error_writer.writeln(f"Failed to load CSS file '{self._html_config.css_file_path}': {ex}")
        if css:
            css = re.sub('\\${([a-zA-Z_-]+)}', self._replace_css_keyword, css)
        return css

    def _replace_css_keyword(self, match: re.Match) -> str:
        keyword: str = match.group(1)
        replacement_text: Optional[str] = self._html_config.try_get_colour_field(keyword)
        if replacement_text is None:
            self._session_config.error_writer.writeln(f"Unknown keyword '{keyword}' in CSS file '{self._html_config.css_file_path}'")
        return replacement_text or 'black'

def _escape_text(text: str) -> str:
    return text.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')

def _convert_lines_to_paragraphs(text: str) -> str:
    paragraph_text: str = ''
    line: str
    for line in text.split('\n'):
        paragraph_text += f'<div>{line}</div>'
    return paragraph_text
