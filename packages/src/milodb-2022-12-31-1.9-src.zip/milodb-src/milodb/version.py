from typing import Optional

MILODB_VERSION: Optional[str] = '1.9'
MILODB_DATE: Optional[str] = '2022-12-31'
