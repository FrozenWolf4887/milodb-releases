from milodb.commands.argument_stream import ArgumentStream
from milodb.commands.command import CommandContext
from milodb.commands.parse_results import EmptyCommandParseResult, FailedCommandParseResult, SuccessfulCommandParseResult
from milodb.commands.parser import parse as parse_command
from milodb.tokeniser import ExpandingTokenStream, ExpandedToken
from prompt_toolkit.completion import Completion # type: ignore
from typing import List, Optional, Union

class InputSuggester:
    def __init__(self, context: CommandContext) -> None:
        self._context = context

    def get_possible_completions(self, text: str, cursor_index: int) -> List[Completion]:
        list_of_completions: List[Completion] = []

        text_of_tokens_before_cursor: str = text[:cursor_index]
        token_stream: ExpandingTokenStream = ExpandingTokenStream(text_of_tokens_before_cursor, self._context.user_variables, cursor_index)
        argument_stream: ArgumentStream = ArgumentStream(token_stream)
        parse_result: Union[SuccessfulCommandParseResult, FailedCommandParseResult, EmptyCommandParseResult] = parse_command(argument_stream, self._context)
        stopped_on_token: Optional[ExpandedToken] = token_stream.get_stopped_on_token()

        if isinstance(parse_result, EmptyCommandParseResult):
            list_of_completions = self._create_completion_list(parse_result.list_of_expected_text, cursor_index, stopped_on_token)
        elif isinstance(parse_result, SuccessfulCommandParseResult):
            list_of_completions = self._create_completion_list(parse_result.list_of_possible_next_text, cursor_index, stopped_on_token)
        elif isinstance(parse_result, FailedCommandParseResult):
            if not parse_result.fault_token:
                list_of_completions = self._create_completion_list(parse_result.list_of_expected_text, cursor_index, stopped_on_token)

        if stopped_on_token and stopped_on_token.text.startswith('$') and token_stream.is_expansion_enabled():
            list_of_variable_names: List[str] = [ f'${name}' for name in self._context.user_variables.get_list_of_names() ]
            list_of_completions.extend(self._create_completion_list(list_of_variable_names, cursor_index, stopped_on_token))

        return list_of_completions

    def _create_completion_list(self, list_of_text: List[str], cursor_index: int, stopped_on_token: Optional[ExpandedToken] = None) -> List[Completion]:
        if stopped_on_token and stopped_on_token.variable_depth == 0:
            return [ Completion(text, stopped_on_token.original_token.outer_indices.start - cursor_index) for text in list_of_text if text.startswith(stopped_on_token.text) ]
        else:
            return [ Completion(text, 0) for text in list_of_text ]
