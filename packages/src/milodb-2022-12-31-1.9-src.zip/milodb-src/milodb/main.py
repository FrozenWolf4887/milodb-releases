import milodb.query as query
from milodb.commands.argument_stream import ArgumentStream
from milodb.commands.command import CommandContext
from milodb.commands.parse_results import EmptyCommandParseResult, FailedCommandParseResult, SuccessfulCommandParseResult
from milodb.commands.parser import parse as parse_command
from milodb.commands.real_command_factory import RealCommandFactory
from milodb.commands.sort_keys import OrderedSortKey, default_list_of_active_sort_keys, list_of_available_sort_keys
from milodb.config import AnsiConfig, BBCodeConfig, HtmlConfig, SessionConfig, SystemConfig
from milodb.database import Database
from milodb.input.input_suggester import InputSuggester
from milodb.input.tab_completer import TabCompleter
from milodb.output.ansi import AnsiOutputter
from milodb.output.bbcode import BBCodeOutputter
from milodb.output.html import HtmlOutputter
from milodb.output.output_sink import ErrorOutputWriter, OutputSink, WarningOutputWriter
from milodb.output.outputter import Outputter
from milodb.output.plain import PlainOutputter
from milodb.output.stdout_output_sink import StdoutOutputSink
from milodb.tokeniser import ExpandingTokenStream
from milodb.user_variables import UserVariables
from milodb.version import MILODB_VERSION, MILODB_DATE
import os
import sys
import datetime
from prompt_toolkit import PromptSession # type: ignore
from prompt_toolkit.history import InMemoryHistory # type: ignore
from prompt_toolkit.shortcuts import CompleteStyle # type: ignore
from typing import Optional, List, Union

DATABASE_FILENAME: str = 'database.mdb'
CONFIG_FILENAME: str = 'config.json'
VARIABLES_FILENAME: str = 'variables.json'
AUTOEXEC_FILENAME: str = 'autoexec.txt'

class Main:
    def __init__(self):
        print(f'Milovana Database {MILODB_VERSION or "(Development)"}, {MILODB_DATE or "(Undated)"}')

        database: Database = Database()
        output_sink: OutputSink = StdoutOutputSink()
        session_config: SessionConfig = SessionConfig(output_sink, ErrorOutputWriter(output_sink), WarningOutputWriter(output_sink))
        system_config: SystemConfig = SystemConfig(CONFIG_FILENAME)
        user_variables: UserVariables = UserVariables(VARIABLES_FILENAME)
        plain_outputter: Outputter = PlainOutputter(session_config)
        ansi_outputter: Outputter = AnsiOutputter(AnsiConfig(system_config), session_config)
        bbcode_outputter: Outputter = BBCodeOutputter(BBCodeConfig(system_config), session_config)
        html_outputter: Outputter = HtmlOutputter(HtmlConfig(system_config), session_config)
        list_of_outputters: List[Outputter] = [plain_outputter, ansi_outputter, bbcode_outputter, html_outputter]
        current_outputter: Outputter = ansi_outputter
        list_of_tease_matches: Optional[List[query.TeaseMatch]] = None
        list_of_active_sort_keys: List[OrderedSortKey] = default_list_of_active_sort_keys
        command_factory: RealCommandFactory = RealCommandFactory()

        database.load_from_file(DATABASE_FILENAME)
        oldest_tease_date: Optional[datetime.date] = database.try_get_oldest_tease_date()
        newest_tease_date: Optional[datetime.date] = database.try_get_newest_tease_date()
        print(f"{len(database.list_of_teases):,} teases loaded ranging from {oldest_tease_date or 'None'} to {newest_tease_date or 'None'}\n")

        self._context = CommandContext(
            False, database, command_factory,
            session_config, system_config, user_variables,
            list_of_tease_matches,
            list_of_available_sort_keys, list_of_active_sort_keys,
            list_of_outputters, current_outputter)

        self._run_autoexec()
        if not self._context.quit_flag:
            self._run_interactive_prompt()

    def _run_autoexec(self) -> None:
        autoexec_lines: Optional[List[str]] = None

        try:
            with open(AUTOEXEC_FILENAME) as file:
                autoexec_lines = file.readlines()
        except IOError:
            pass

        if autoexec_lines:
            print(f"Running commands from '{AUTOEXEC_FILENAME}':")
            line_index: int = 0
            while (not self._context.quit_flag) and (line_index < len(autoexec_lines)):
                line: str = autoexec_lines[line_index].strip()
                if line:
                    print(f'> {line}')
                    self._process_user_input(line)
                line_index += 1

    def _run_interactive_prompt(self) -> None:
        self._context.session_config.default_input_text = ''

        print('Enter command (or "help"):')

        if self._is_dumb_terminal():
            self._run_dumb_prompt()
        else:
            self._run_smart_prompt()

    def _is_dumb_terminal(self) -> bool:
        return not os.isatty(sys.stdin.fileno())

    def _run_dumb_prompt(self) -> None:
        while not self._context.quit_flag:
            try:
                user_input: str = input('> ')
            except EOFError:
                self._context.quit_flag = True
            else:
                self._process_user_input(user_input)

    def _run_smart_prompt(self) -> None:
        history: InMemoryHistory = InMemoryHistory()
        input_suggester: InputSuggester = InputSuggester(self._context)
        tab_completer: TabCompleter = TabCompleter(input_suggester)

        prompt_session: PromptSession = PromptSession(history=history, completer=tab_completer, complete_style=CompleteStyle.READLINE_LIKE)
        while not self._context.quit_flag:
            user_input: str = prompt_session.prompt('> ', default=self._context.session_config.default_input_text)
            self._process_user_input(user_input)

    def _process_user_input(self, user_input: str) -> None:
        self._context.session_config.default_input_text = ''
        token_stream: ExpandingTokenStream = ExpandingTokenStream(user_input, self._context.user_variables)
        argument_stream: ArgumentStream = ArgumentStream(token_stream)
        parse_result: Union[SuccessfulCommandParseResult, FailedCommandParseResult, EmptyCommandParseResult] = parse_command(argument_stream, self._context)
        if isinstance(parse_result, SuccessfulCommandParseResult):
            print()
            parse_result.command.execute()
            print()
        elif isinstance(parse_result, FailedCommandParseResult):
            print(f'\nError: {parse_result.fault_text}')
            if parse_result.command_class:
                print(f'Command: {parse_result.command_class}')
            if parse_result.fault_token:
                print(f"Faulty token: '{parse_result.fault_token.text}' starting at character #{parse_result.fault_token.inner_indices.start}")
            if parse_result.input_text:
                print(f"Input text: {parse_result.input_text}")
            if parse_result.list_of_expected_text:
                print(f'Expected: {sorted(parse_result.list_of_expected_text)}')
            print()
        elif not isinstance(parse_result, EmptyCommandParseResult):
            print('Error: Internal error: Unexpected command parse result')
