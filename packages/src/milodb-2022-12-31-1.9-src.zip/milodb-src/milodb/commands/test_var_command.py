from unittest.mock import Mock
from milodb.commands.command import Command
from milodb.commands.var_command import VarCommand
from milodb.commands.test_command_base import CommandTestBase
from typing import List, Type

COMMAND_NAME: str = 'var'
COMMAND_CLASS: Type[Command] = VarCommand
COMMAND_SET: List[str] = [COMMAND_NAME, 'set']
COMMAND_GET: List[str] = [COMMAND_NAME, 'get']
COMMAND_DELETE: List[str] = [COMMAND_NAME, 'delete']
COMMAND_RENAME: List[str] = [COMMAND_NAME, 'rename']
COMMAND_COPY: List[str] = [COMMAND_NAME, 'copy']
COMMAND_EDIT: List[str] = [COMMAND_NAME, 'edit']

class TestVarCommand:
    def test_without_arguments_returns_success(self):
        self.parse_test([COMMAND_NAME])
        self.assert_successful(COMMAND_CLASS)

    def test_unknown_action_returns_failure(self):
        self.parse_test([COMMAND_NAME, 'boo'])
        self.assert_unsuccessful(COMMAND_CLASS, 1, "Invalid parameter. Expected one of ['set', 'get', 'delete', 'rename', 'copy', 'edit']", ['set', 'get', 'delete', 'rename', 'copy', 'edit'])

class TestVarSetCommandLoad(CommandTestBase):
    def test_without_arguments_returns_failure(self):
        self.parse_test(COMMAND_SET)
        self.assert_unsuccessful(COMMAND_CLASS, None, 'Insufficient parameters. Expecting variable name', [])

        self.add_variable('honey', 'toffee')
        self.add_variable('badger', 'apple')
        self.parse_test(COMMAND_SET)
        self.assert_unsuccessful(COMMAND_CLASS, None, 'Insufficient parameters. Expecting variable name', ['honey', 'badger'])

    def test_without_value_returns_failure(self):
        self.parse_test([*COMMAND_SET, 'pear'])
        self.assert_unsuccessful(COMMAND_CLASS, None, 'Expected some text to set as the variable value', [])

        self.add_variable('honey', 'toffee')
        self.add_variable('badger', 'apple')
        self.parse_test([*COMMAND_SET, 'pear'])
        self.assert_unsuccessful(COMMAND_CLASS, None, 'Expected some text to set as the variable value', [])

    def test_with_bad_variable_name_returns_failure(self):
        self.parse_test([*COMMAND_SET, '$pear'])
        self.assert_unsuccessful(COMMAND_CLASS, 2, r"Variable name '$pear' does not match pattern '[\w\-\+]+'", [])

        self.parse_test([*COMMAND_SET, 'p%ear'])
        self.assert_unsuccessful(COMMAND_CLASS, 2, r"Variable name 'p%ear' does not match pattern '[\w\-\+]+'", [])

        self.add_variable('honey', 'toffee')
        self.add_variable('badger', 'apple')
        self.parse_test([*COMMAND_SET, 'pear#'])
        self.assert_unsuccessful(VarCommand, 2, r"Variable name 'pear#' does not match pattern '[\w\-\+]+'", ['honey', 'badger'])

class TestVarSetCommandExecute(CommandTestBase):
    def test_new_variable_with_value_sets_successfully(self):
        self.execute_test([*COMMAND_SET, 'pear'], 'something')
        self.mock_variables.set.assert_called_once_with('pear', 'something')
        self.mock_variables.try_save.assert_called_once()

    def test_existing_variable_with_value_sets_successfully(self):
        self.add_variable('honey', 'toffee')
        self.add_variable('badger', 'apple')
        self.execute_test([*COMMAND_SET, 'honey'], 'lemon')
        self.mock_variables.set.assert_called_once_with('honey', 'lemon')
        self.mock_variables.try_save.assert_called_once()

    def test_variable_with_complex_name_sets_successfully(self):
        self.execute_test([*COMMAND_SET, '012The-Qu34ick+Br56own-F78ox+Ju9mps-Over+The-L0azy+Dog'], 'something')
        self.mock_variables.set.assert_called_once_with('012The-Qu34ick+Br56own-F78ox+Ju9mps-Over+The-L0azy+Dog', 'something')
        self.mock_variables.try_save.assert_called_once()

    def test_variable_with_remaining_text_sets_verbatim_but_stripped(self):
        self.execute_test([*COMMAND_SET, 'pear'], '  this   is " some text  ;;<> that can\'t  be tokenised  ')
        self.mock_variables.set.assert_called_once_with('pear', 'this   is " some text  ;;<> that can\'t  be tokenised')
        self.mock_variables.try_save.assert_called_once()

class TestVarGetCommandLoad(CommandTestBase):
    def test_without_arguments_returns_failure(self):
        self.parse_test(COMMAND_GET)
        self.assert_unsuccessful(COMMAND_CLASS, None, 'Insufficient parameters. Expecting variable name', [])

        self.add_variable('honey', 'toffee')
        self.add_variable('badger', 'apple')
        self.parse_test(COMMAND_GET)
        self.assert_unsuccessful(COMMAND_CLASS, None, 'Insufficient parameters. Expecting variable name', ['honey', 'badger'])

    def test_with_variable_name_returns_success(self):
        self.parse_test([*COMMAND_GET, 'pear'])
        self.assert_successful(COMMAND_CLASS)

    def test_with_bad_variable_name_returns_failure(self):
        self.parse_test([*COMMAND_GET, '$pear'])
        self.assert_unsuccessful(COMMAND_CLASS, 2, r"Variable name '$pear' does not match pattern '[\w\-\+]+'", [])

        self.parse_test([*COMMAND_SET, 'p%ear'])
        self.assert_unsuccessful(COMMAND_CLASS, 2, r"Variable name 'p%ear' does not match pattern '[\w\-\+]+'", [])

        self.add_variable('honey', 'toffee')
        self.add_variable('badger', 'apple')
        self.parse_test([*COMMAND_GET, 'pear#'])
        self.assert_unsuccessful(VarCommand, 2, r"Variable name 'pear#' does not match pattern '[\w\-\+]+'", ['honey', 'badger'])

    def test_excessive_parameters_returns_failure(self):
        self.parse_test([*COMMAND_GET, 'pear', 'bar'])
        self.assert_unsuccessful(VarCommand, 3, 'Unexpected additional parameter', [])

class TestVarGetCommandExecute(CommandTestBase):
    def test_existing_variable_gets_successfully(self):
        self.add_variable('honey', 'toffee')
        self.add_variable('badger', 'apple')
        self.execute_test([*COMMAND_GET, 'badger'])
        self.normal_writer.writeln.assert_called_once_with('  badger : apple')
        self.mock_variables.try_save.assert_not_called()

    def test_unknown_variable_prints_failure(self):
        self.add_variable('honey', 'toffee')
        self.add_variable('badger', 'apple')
        self.execute_test([*COMMAND_GET, 'apple'])
        self.error_writer.writeln.assert_called_once_with("Unknown variable 'apple'")
        self.mock_variables.try_save.assert_not_called()

class TestVarDeleteCommandLoad(CommandTestBase):
    def test_without_arguments_returns_failure(self):
        self.parse_test(COMMAND_DELETE)
        self.assert_unsuccessful(COMMAND_CLASS, None, 'Insufficient parameters. Expecting variable name', [])

        self.add_variable('honey', 'toffee')
        self.add_variable('badger', 'apple')
        self.parse_test(COMMAND_DELETE)
        self.assert_unsuccessful(COMMAND_CLASS, None, 'Insufficient parameters. Expecting variable name', ['honey', 'badger'])

    def test_with_variable_name_returns_success(self):
        self.parse_test([*COMMAND_DELETE, 'pear'])
        self.assert_successful(COMMAND_CLASS)

    def test_with_bad_variable_name_returns_failure(self):
        self.parse_test([*COMMAND_DELETE, '$pear'])
        self.assert_unsuccessful(COMMAND_CLASS, 2, r"Variable name '$pear' does not match pattern '[\w\-\+]+'", [])

        self.parse_test([*COMMAND_DELETE, 'p%ear'])
        self.assert_unsuccessful(COMMAND_CLASS, 2, r"Variable name 'p%ear' does not match pattern '[\w\-\+]+'", [])

        self.add_variable('honey', 'toffee')
        self.add_variable('badger', 'apple')
        self.parse_test([*COMMAND_DELETE, 'pear#'])
        self.assert_unsuccessful(VarCommand, 2, r"Variable name 'pear#' does not match pattern '[\w\-\+]+'", ['honey', 'badger'])

    def test_excessive_parameters_returns_failure(self):
        self.parse_test([*COMMAND_DELETE, 'pear', 'bar'])
        self.assert_unsuccessful(VarCommand, 3, 'Unexpected additional parameter', [])

class TestVarDeleteCommandExecute(CommandTestBase):
    def test_existing_variable_deletes_successfully(self):
        self.add_variable('honey', 'toffee')
        self.add_variable('badger', 'apple')
        self.mock_variables.try_delete = Mock(return_value=True)
        self.execute_test([*COMMAND_DELETE, 'badger'])
        self.mock_variables.try_delete.assert_called_once_with("badger")
        self.mock_variables.try_save.assert_called_once()

    def test_unknown_variable_prints_failure(self):
        self.add_variable('honey', 'toffee')
        self.add_variable('badger', 'apple')
        self.mock_variables.try_delete = Mock(return_value=False)
        self.execute_test([*COMMAND_DELETE, 'apple'])
        self.error_writer.writeln.assert_called_once_with("Unknown variable 'apple'")
        self.mock_variables.try_save.assert_not_called()

class TestVarRenameCommandLoad(CommandTestBase):
    def test_without_arguments_returns_failure(self):
        self.parse_test(COMMAND_RENAME)
        self.assert_unsuccessful(COMMAND_CLASS, None, 'Insufficient parameters. Expecting variable name', [])

        self.add_variable('honey', 'toffee')
        self.add_variable('badger', 'apple')
        self.parse_test(COMMAND_RENAME)
        self.assert_unsuccessful(COMMAND_CLASS, None, 'Insufficient parameters. Expecting variable name', ['honey', 'badger'])

    def test_with_single_variable_name_returns_failure(self):
        self.parse_test([*COMMAND_RENAME, 'pear'])
        self.assert_unsuccessful(COMMAND_CLASS, None, 'Insufficient parameters. Expecting variable name', [])

        self.add_variable('honey', 'toffee')
        self.add_variable('badger', 'apple')
        self.parse_test([*COMMAND_RENAME, 'mango'])
        self.assert_unsuccessful(COMMAND_CLASS, None, 'Insufficient parameters. Expecting variable name', [])

    def test_with_two_variable_names_returns_success(self):
        self.parse_test([*COMMAND_RENAME, 'pear', 'mango'])
        self.assert_successful(COMMAND_CLASS)

    def test_with_bad_variable_name_returns_failure(self):
        self.parse_test([*COMMAND_RENAME, '$pear'])
        self.assert_unsuccessful(COMMAND_CLASS, 2, r"Variable name '$pear' does not match pattern '[\w\-\+]+'", [])

        self.parse_test([*COMMAND_RENAME, 'mango', 'p%ear'])
        self.assert_unsuccessful(COMMAND_CLASS, 3, r"Variable name 'p%ear' does not match pattern '[\w\-\+]+'", [])

        self.add_variable('honey', 'toffee')
        self.add_variable('badger', 'apple')
        self.parse_test([*COMMAND_RENAME, 'pear#', 'mango'])
        self.assert_unsuccessful(VarCommand, 2, r"Variable name 'pear#' does not match pattern '[\w\-\+]+'", ['honey', 'badger'])

        self.parse_test([*COMMAND_RENAME, 'pear', 'mango#'])
        self.assert_unsuccessful(VarCommand, 3, r"Variable name 'mango#' does not match pattern '[\w\-\+]+'", [])

    def test_excessive_parameters_returns_failure(self):
        self.parse_test([*COMMAND_RENAME, 'pear', 'bar', 'foo'])
        self.assert_unsuccessful(VarCommand, 4, 'Unexpected additional parameter', [])

class TestVarRenameCommandExecute(CommandTestBase):
    def test_existing_variable_renames_to_new_name_successfully(self):
        self.add_variable('honey', 'toffee')
        self.add_variable('badger', 'apple')
        self.mock_variables.try_delete = Mock(return_value=True)
        self.execute_test([*COMMAND_RENAME, 'badger', 'tree'])
        self.mock_variables.set.assert_called_once_with('tree', 'apple')
        self.mock_variables.try_delete.assert_called_once_with('badger')
        self.mock_variables.try_save.assert_called_once()

    def test_unknown_variable_prints_failure(self):
        self.add_variable('honey', 'toffee')
        self.add_variable('badger', 'apple')
        self.mock_variables.try_delete = Mock(return_value=False)
        self.execute_test([*COMMAND_RENAME, 'apple', 'tree'])
        self.error_writer.writeln.assert_called_once_with("Unknown variable 'apple'")
        self.mock_variables.try_save.assert_not_called()

    def test_existing_variable_rename_fails_when_new_name_exists(self):
        self.add_variable('honey', 'toffee')
        self.add_variable('badger', 'apple')
        self.mock_variables.try_delete = Mock(return_value=False)
        self.execute_test([*COMMAND_RENAME, 'honey', 'badger'])
        self.error_writer.writeln.assert_called_once_with("Cannot rename variable 'honey' to 'badger' because 'badger' already exists")
        self.mock_variables.try_save.assert_not_called()

    def test_existing_variable_rename_fails_when_new_name_is_the_same(self):
        self.add_variable('honey', 'toffee')
        self.add_variable('badger', 'apple')
        self.mock_variables.try_delete = Mock(return_value=False)
        self.execute_test([*COMMAND_RENAME, 'honey', 'honey'])
        self.error_writer.writeln.assert_called_once_with("Variable 'honey' cannot be renamed to itself")
        self.mock_variables.try_save.assert_not_called()

class TestVarCopyCommandLoad(CommandTestBase):
    def test_without_arguments_returns_failure(self):
        self.parse_test(COMMAND_COPY)
        self.assert_unsuccessful(COMMAND_CLASS, None, 'Insufficient parameters. Expecting variable name', [])

        self.add_variable('honey', 'toffee')
        self.add_variable('badger', 'apple')
        self.parse_test(COMMAND_COPY)
        self.assert_unsuccessful(COMMAND_CLASS, None, 'Insufficient parameters. Expecting variable name', ['honey', 'badger'])

    def test_with_single_variable_name_returns_failure(self):
        self.parse_test([*COMMAND_COPY, 'pear'])
        self.assert_unsuccessful(COMMAND_CLASS, None, 'Insufficient parameters. Expecting variable name', [])

        self.add_variable('honey', 'toffee')
        self.add_variable('badger', 'apple')
        self.parse_test([*COMMAND_COPY, 'mango'])
        self.assert_unsuccessful(COMMAND_CLASS, None, 'Insufficient parameters. Expecting variable name', [])

    def test_with_two_variable_names_returns_success(self):
        self.parse_test([*COMMAND_COPY, 'pear', 'mango'])
        self.assert_successful(COMMAND_CLASS)

    def test_with_bad_variable_name_returns_failure(self):
        self.parse_test([*COMMAND_COPY, '$pear'])
        self.assert_unsuccessful(COMMAND_CLASS, 2, r"Variable name '$pear' does not match pattern '[\w\-\+]+'", [])

        self.parse_test([*COMMAND_COPY, 'mango', 'p%ear'])
        self.assert_unsuccessful(COMMAND_CLASS, 3, r"Variable name 'p%ear' does not match pattern '[\w\-\+]+'", [])

        self.add_variable('honey', 'toffee')
        self.add_variable('badger', 'apple')
        self.parse_test([*COMMAND_COPY, 'pear#', 'mango'])
        self.assert_unsuccessful(VarCommand, 2, r"Variable name 'pear#' does not match pattern '[\w\-\+]+'", ['honey', 'badger'])

        self.parse_test([*COMMAND_COPY, 'pear', 'mango#'])
        self.assert_unsuccessful(VarCommand, 3, r"Variable name 'mango#' does not match pattern '[\w\-\+]+'", [])

    def test_excessive_parameters_returns_failure(self):
        self.parse_test([*COMMAND_COPY, 'pear', 'bar', 'foo'])
        self.assert_unsuccessful(VarCommand, 4, 'Unexpected additional parameter', [])

class TestVarCopyCommandExecute(CommandTestBase):
    def test_existing_variable_copies_to_new_name_successfully(self):
        self.add_variable('honey', 'toffee')
        self.add_variable('badger', 'apple')
        self.mock_variables.try_delete = Mock(return_value=True)
        self.execute_test([*COMMAND_COPY, 'badger', 'tree'])
        self.mock_variables.set.assert_called_once_with('tree', 'apple')
        self.mock_variables.try_save.assert_called_once()

    def test_unknown_variable_prints_failure(self):
        self.add_variable('honey', 'toffee')
        self.add_variable('badger', 'apple')
        self.mock_variables.try_delete = Mock(return_value=False)
        self.execute_test([*COMMAND_COPY, 'apple', 'tree'])
        self.error_writer.writeln.assert_called_once_with("Unknown variable 'apple'")
        self.mock_variables.try_save.assert_not_called()

    def test_existing_variable_rename_fails_when_new_name_exists(self):
        self.add_variable('honey', 'toffee')
        self.add_variable('badger', 'apple')
        self.mock_variables.try_delete = Mock(return_value=False)
        self.execute_test([*COMMAND_COPY, 'honey', 'badger'])
        self.error_writer.writeln.assert_called_once_with("Cannot copy variable 'honey' to 'badger' because 'badger' already exists")
        self.mock_variables.try_save.assert_not_called()

    def test_existing_variable_rename_fails_when_new_name_is_the_same(self):
        self.add_variable('honey', 'toffee')
        self.add_variable('badger', 'apple')
        self.mock_variables.try_delete = Mock(return_value=False)
        self.execute_test([*COMMAND_COPY, 'honey', 'honey'])
        self.error_writer.writeln.assert_called_once_with("Variable 'honey' cannot be copied to itself")
        self.mock_variables.try_save.assert_not_called()

class TestVarEditCommandLoad(CommandTestBase):
    def test_without_arguments_returns_failure(self):
        self.parse_test(COMMAND_EDIT)
        self.assert_unsuccessful(COMMAND_CLASS, None, 'Insufficient parameters. Expecting variable name', [])

        self.add_variable('honey', 'toffee')
        self.add_variable('badger', 'apple')
        self.parse_test(COMMAND_EDIT)
        self.assert_unsuccessful(COMMAND_CLASS, None, 'Insufficient parameters. Expecting variable name', ['honey', 'badger'])

    def test_with_variable_name_returns_success(self):
        self.parse_test([*COMMAND_EDIT, 'pear'])
        self.assert_successful(COMMAND_CLASS)

    def test_with_bad_variable_name_returns_failure(self):
        self.parse_test([*COMMAND_EDIT, '$pear'])
        self.assert_unsuccessful(COMMAND_CLASS, 2, r"Variable name '$pear' does not match pattern '[\w\-\+]+'", [])

        self.parse_test([*COMMAND_EDIT, 'p%ear'])
        self.assert_unsuccessful(COMMAND_CLASS, 2, r"Variable name 'p%ear' does not match pattern '[\w\-\+]+'", [])

        self.add_variable('honey', 'toffee')
        self.add_variable('badger', 'apple')
        self.parse_test([*COMMAND_EDIT, 'pear#'])
        self.assert_unsuccessful(VarCommand, 2, r"Variable name 'pear#' does not match pattern '[\w\-\+]+'", ['honey', 'badger'])

    def test_excessive_parameters_returns_failure(self):
        self.parse_test([*COMMAND_EDIT, 'pear', 'bar'])
        self.assert_unsuccessful(VarCommand, 3, 'Unexpected additional parameter', [])

class TestVarEditCommandExecute(CommandTestBase):
    def test_existing_variable_edits_successfully(self):
        self.add_variable('honey', 'toffee')
        self.add_variable('badger', 'apple')
        self.execute_test([*COMMAND_EDIT, 'badger'])
        self.assertEqual(self.context.session_config.default_input_text, 'var set badger apple')

    def test_unknown_variable_prints_failure(self):
        self.add_variable('honey', 'toffee')
        self.add_variable('badger', 'apple')
        self.execute_test([*COMMAND_EDIT, 'apple'])
        self.error_writer.writeln.assert_called_once_with("Unknown variable 'apple'")
