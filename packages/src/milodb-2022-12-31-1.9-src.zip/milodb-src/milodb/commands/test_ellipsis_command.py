from milodb.commands.ellipsis_command import EllipsisCommand
from milodb.commands.test_command_base import CommandTestBase

class TestEllipsisCommand(CommandTestBase):
    def test_without_arguments_returns_success(self):
        self.parse_test(['ellipsis'])
        self.assert_successful(EllipsisCommand)

    def test_with_off_argument_returns_success(self):
        self.parse_test(['ellipsis', 'off'])
        self.assert_successful(EllipsisCommand)

    def test_with_on_argument_returns_success(self):
        self.parse_test(['ellipsis', 'on'])
        self.assert_successful(EllipsisCommand)

    def test_with_invalid_argument_returns_failure(self):
        self.parse_test(['ellipsis', 'mango'])
        self.assert_unsuccessful(EllipsisCommand, 1, 'Unknown enumeration value', ['on', 'off'])

    def test_with_redundant_argument_returns_failure(self):
        self.parse_test(['ellipsis', 'on', 'off'])
        self.assert_unsuccessful(EllipsisCommand, 2, 'Unexpected additional parameter', [])
