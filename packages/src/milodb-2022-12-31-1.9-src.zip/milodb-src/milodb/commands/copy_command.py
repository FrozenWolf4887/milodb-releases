from milodb.commands.argument_stream import ArgumentStream
from milodb.commands.command import Command, CommandContext
from milodb.output.capturing_output_sink import CapturingOutputSink
from milodb.commands.parser import parse as parse_command
from milodb.commands.parse_results import EmptyCommandParseResult, FailedCommandParseResult, LoadDelegateError, SuccessfulCommandParseResult
from milodb.output.output_sink import OutputSink, OutputWriter
import pyperclip # type: ignore
from typing import List, Optional, Union

class CopyCommand(Command):
    def __init__(self, context: CommandContext) -> None:
        self._context = context
        self._delegate_command: Optional[Command] = None

    def load(self, argument_stream: ArgumentStream) -> List[str]:
        parse_result: Union[SuccessfulCommandParseResult, FailedCommandParseResult, EmptyCommandParseResult] = parse_command(argument_stream, self._context)
        if isinstance(parse_result, SuccessfulCommandParseResult):
            self._delegate_command = parse_result.command
            return parse_result.list_of_possible_next_text
        else:
            raise LoadDelegateError(parse_result)

    def execute(self) -> None:
        if self._delegate_command:
            previous_normal_writer: OutputSink = self._context.session_config.normal_writer
            previous_error_writer: OutputWriter = self._context.session_config.error_writer
            previous_warning_writer: OutputWriter = self._context.session_config.warning_writer
            capturing_text_output: CapturingOutputSink = CapturingOutputSink(previous_normal_writer)
            self._context.session_config.normal_writer = capturing_text_output
            self._context.session_config.error_writer.redirect_output(capturing_text_output)
            self._context.session_config.warning_writer.redirect_output(capturing_text_output)
            try:
                self._delegate_command.execute()
            finally:
                self._context.session_config.normal_writer = previous_normal_writer
                self._context.session_config.error_writer = previous_error_writer
                self._context.session_config.warning_writer = previous_warning_writer
            try:
                pyperclip.copy(capturing_text_output.text.rstrip())
            except pyperclip.PyperclipException as ex:
                print(f'Error: Unable to copy to clipboard: {ex}')

    @classmethod
    def get_one_line_summary(cls) -> str:
        return "Copies the output of the subsequent command to the clipboard"

    @classmethod
    def get_detailed_summary(cls, context: CommandContext) -> str:
        return (
            "Arguments: <subsequent command...>\n"
            "The output of the subsequent command is copied to the clipboard in the currently"
            " selected format.\n"
            "Example:\r"
            "  \tList the current query results and copy the list to the clipboard\r"
            "  > \tcopy list\n"
            "Example:\r"
            "  \tCopy the url of the author of match #3 to the clipboard\r"
            "  > \tcopy urlauthor 3\n"
            "See also:\r"
            "  \tformat, ellipsis, highlight\n"
        )
