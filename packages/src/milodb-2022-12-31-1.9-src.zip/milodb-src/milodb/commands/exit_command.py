from milodb.commands.argument_stream import ArgumentStream
from milodb.commands.command import Command, CommandContext
from typing import List, Optional

class ExitCommand(Command):
    def __init__(self, context: CommandContext) -> None:
        self._context = context

    def load(self, argument_stream: ArgumentStream) -> List[str]:
        argument_stream.fail_if_not_empty()
        return []

    def execute(self) -> None:
        self._context.quit_flag = True

    @classmethod
    def get_one_line_summary(cls) -> str:
        return "Exits the application"

    @classmethod
    def get_detailed_summary(cls, context: CommandContext) -> str:
        return (
            "Arguments: none\n"
            "Exits the application.\n"
            "Example:\r"
            "  > \texit\n"
        )
