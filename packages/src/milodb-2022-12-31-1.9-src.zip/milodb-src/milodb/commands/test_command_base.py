import milodb.query as query
from milodb.commands.argument_stream import ArgumentStream
from milodb.commands.parse_results import EmptyCommandParseResult, FailedCommandParseResult, SuccessfulCommandParseResult
from milodb.commands.parser import parse as parse_command
from milodb.commands.real_command_factory import RealCommandFactory
from milodb.commands.command import Command, CommandContext, CommandFactory
from milodb.commands.sort_keys import OrderedSortKey, default_list_of_active_sort_keys, list_of_available_sort_keys
from milodb.config import SessionConfig, SystemConfig
from milodb.database import Database
from milodb.output.output_sink import ErrorOutputWriter, OutputSink, WarningOutputWriter
from milodb.output.outputter import Outputter
from milodb.tokeniser import ExpandingTokenStream, StartEnd, Token
from milodb.user_variables import UserVariables
from unittest import TestCase
from unittest.mock import MagicMock, Mock
from typing import Dict, List, Optional, Type, Union

class CommandTestBase(TestCase):
    def setUp(self):
        self.result: Union[SuccessfulCommandParseResult, FailedCommandParseResult, EmptyCommandParseResult]
        database = Mock(Database)
        command_factory: CommandFactory = RealCommandFactory()
        self.normal_writer = MagicMock(OutputSink)
        self.error_writer = MagicMock(ErrorOutputWriter)
        self.warning_writer = MagicMock(WarningOutputWriter)
        self.session_config = SessionConfig(self.normal_writer, self.error_writer, self.warning_writer)
        self._dictionary_of_variables: Dict[str, str] = {}
        self.mock_variables = Mock(UserVariables)
        self.mock_variables.try_retrieve = lambda name: self._dictionary_of_variables.get(name)
        self.mock_variables.get_list_of_names = lambda: list(self._dictionary_of_variables.keys())
        self.mock_variables.set = Mock()
        system_config = Mock(SystemConfig)
        list_of_tease_matches: Optional[List[query.TeaseMatch]] = None
        list_of_active_sort_keys: List[OrderedSortKey] = default_list_of_active_sort_keys.copy()
        self.mock_outputter = Mock(Outputter)
        list_of_outputters: List[Outputter] = [self.mock_outputter]
        self.context: CommandContext = CommandContext(
            False, database, command_factory,
            self.session_config, system_config, self.mock_variables,
            list_of_tease_matches,
            list_of_available_sort_keys, list_of_active_sort_keys,
            list_of_outputters, self.mock_outputter)
        self.list_of_tokens: List[Optional[Token]] = []
        self.list_of_command_names: List[str] = self.context.command_factory.get_list_of_command_names()
        self.mock_token_stream = Mock(ExpandingTokenStream)

    def add_variable(self, name: str, value: str) -> None:
        self._dictionary_of_variables[name] = value

    def parse_test(self, list_of_token_text: Optional[List[str]], remaining_raw_text: Optional[str] = None, expanded_raw_text: Optional[str] = None) -> None:
        if not list_of_token_text:
            self.mock_token_stream.next = Mock(return_value=None)
            self.mock_token_stream.get_remaining_raw_text = Mock(return_value='')
            self.result = parse_command(ArgumentStream(self.mock_token_stream), self.context)
        else:
            self.list_of_tokens = self.create_fake_tokens(list_of_token_text)
            self.mock_token_stream.next = Mock()
            self.mock_token_stream.next.side_effect = self.list_of_tokens
            self.mock_token_stream.get_expanded_raw_text = Mock(return_value=(expanded_raw_text or ''))
            self.mock_token_stream.get_remaining_raw_text = Mock(return_value=(remaining_raw_text or ''))
            self.result = parse_command(ArgumentStream(self.mock_token_stream), self.context)

    def execute_test(self, list_of_token_text: Optional[List[str]], remaining_raw_text: Optional[str] = None, expanded_raw_text: Optional[str] = None) -> None:
        self.parse_test(list_of_token_text, remaining_raw_text, expanded_raw_text)
        if isinstance(self.result, SuccessfulCommandParseResult):
            self.result.command.execute()
        else:
            self.fail("Parsing should have been successful but wasn't")

    def create_fake_tokens(self, list_of_token_text: List[str]) -> List[Optional[Token]]:
        list_of_tokens: List[Optional[Token]] = []
        token_number: int = 0
        token_start_index: int = 0
        for token_text in list_of_token_text:
            token_end_index: int = token_start_index + len(token_text)
            outer_indices: StartEnd = StartEnd(token_start_index, token_end_index)
            inner_indices: StartEnd = StartEnd(token_start_index, token_end_index)
            if token_text and token_text[0] in ['"\'']:
                inner_indices.start += 1
                inner_indices.end -= 1
            list_of_tokens.append(Token(token_text, token_number, outer_indices, inner_indices))
            token_start_index = token_end_index + 1
            token_number += 1
        list_of_tokens.append(None)
        return list_of_tokens

    def assert_successful(self, command_class: Type[Command]) -> None:
        if isinstance(self.result, SuccessfulCommandParseResult):
            self.assertIsInstance(self.result.command, command_class,
                'Incorrect class type returned from parsing')
        else:
            self.fail("Parsing should have been successful but wasn't")

    def assert_empty(self, list_of_expected_text: List[str]) -> None:
        if isinstance(self.result, EmptyCommandParseResult):
            if list_of_expected_text is not None:
                if self.result.list_of_expected_text is not None:
                    self.assert_lists_contain_same(list_of_expected_text, self.result.list_of_expected_text)
                else:
                    self.fail(f'List of expected text is missing when it should be {list_of_expected_text}')
            else:
                self.assertIsNone(self.result.list_of_expected_text,
                    'Got a list of expected next text when none was expected')
        else:
            self.fail("Parse result should have been empty but wasn't")

    def assert_unsuccessful(self, command_class: Optional[Type[Command]], fault_token_index: Optional[int], fault_text: str, list_of_expected_text: List[str]) -> None:
        if isinstance(self.result, FailedCommandParseResult):
            self.assertEquals(command_class, self.result.command_class)

            if fault_token_index is not None:
                self.assertEqual(self.list_of_tokens[fault_token_index], self.result.fault_token,
                    f'Unexpected fault token reported')
            else:
                self.assertEqual(None, self.result.fault_token,
                    f'Unexpected fault token reported')

            self.assertEqual(fault_text, self.result.fault_text,
                f"Expected error message of '{fault_text}' but got '{self.result.fault_text}'")

            self.assert_lists_contain_same(list_of_expected_text, self.result.list_of_expected_text)
        else:
            self.fail("Tokenisation should have failed but was successful")

    def assert_lists_contain_same(self, list_expected: List[str], list_actual: List[str]):
        self.assertEqual(len(list_expected), len(list_actual),
            f'Two lists are of different lengths; expected {list_expected} but got {list_actual}')
        for expected in list_expected:
            if expected not in list_actual:
                self.fail(f"Expected to find '{expected}' in list but it is missing")
