from milodb.commands.enums import EnumEx
from milodb.commands.parse_results import LoadError
from milodb.ref_id import RefId, MatchIndex, TeaseId, AuthorId
from milodb.tokeniser import ExpandingTokenStream, Token
from milodb.user_variables import VARIABLE_NAME_PATTERN
from typing import Dict, List, Optional, Tuple, Type, TypeVar

T = TypeVar("T")
E = TypeVar("E", bound=EnumEx)

class ArgumentStream:
    def __init__(self, token_stream: ExpandingTokenStream):
        self._token_stream: ExpandingTokenStream = token_stream

    def disable_expansion(self) -> None:
        self._token_stream.disable_expansion()

    def get_remaining_raw_text(self) -> str:
        return self._token_stream.get_remaining_raw_text()

    def get_expanded_raw_text(self) -> str:
        return self._token_stream.get_expanded_raw_text()

    def pop_token(self) -> Token:
        token: Optional[Token] = self._token_stream.next()
        if token:
            return token
        else:
            raise self._create_load_error(f'Insufficient parameters.', None)

    def pop_optional_token(self) -> Optional[Token]:
        return self._token_stream.next()

    def pop_optional_ref_id(self) -> Optional[RefId]:
        ref_id: Optional[RefId] = None
        token: Optional[Token] = self._token_stream.next()
        if token:
            value: int
            if token.text.startswith('#'):
                value = self._parse_uint(token, token.text[1:], 'TeaseId is not a positive integer')
                ref_id = TeaseId(value)
            elif token.text.startswith('@'):
                value = self._parse_uint(token, token.text[1:], 'AuthorId is not a positive integer')
                ref_id = AuthorId(value)
            elif token.text[0:1].isdigit():
                value = self._parse_uint(token, token.text, 'Match index is not a positive integer')
                ref_id = MatchIndex(value)
            else:
                raise self._create_load_error('Invalid RefId; expecting value, #value, or @value', token)

        return ref_id

    def pop_list_of_ref_ids(self, minimum_number=0) -> List[RefId]:
        list_of_ref_ids: List[RefId] = []

        end_of_input: bool = False
        while not end_of_input:
            ref_id: Optional[RefId] = self.pop_optional_ref_id()
            if ref_id:
                list_of_ref_ids.append(ref_id)
            else:
                end_of_input = True

        if len(list_of_ref_ids) < minimum_number:
            plural_text: str = 's' if minimum_number != 1 else ''
            raise self._create_load_error(f'Insufficient parameters. Expecting at least {minimum_number} RefId{plural_text}', None)

        return list_of_ref_ids

    def pop_ref_id(self) -> RefId:
        ref_id: Optional[RefId] = self.pop_optional_ref_id()
        if ref_id is None:
            raise self._create_load_error('Insufficient parameters. Expecting RefId', None)
        return ref_id

    def pop_dict_value(self, dictionary: Dict[str, T]) -> T:
        value: Optional[T] = self.pop_optional_dict_value(dictionary)
        if value is None:
            list_of_keys = list(dictionary.keys())
            raise self._create_load_error(f'Insufficient parameters. Expected one of {list_of_keys}', None, list_of_keys)
        return value

    def pop_optional_dict_value(self, dictionary: Dict[str, T]) -> Optional[T]:
        value_and_token: Optional[Tuple[T, Token]] = self.pop_optional_dict_value_and_token(dictionary)
        if value_and_token:
            return value_and_token[0]
        else:
            return None

    def pop_optional_dict_value_and_token(self, dictionary: Dict[str, T]) -> Optional[Tuple[T, Token]]:
        token: Optional[Token] = self._token_stream.next()
        if token:
            try:
                return dictionary[token.text], token
            except KeyError:
                list_of_keys = list(dictionary.keys())
                raise self._create_load_error(f'Invalid parameter. Expected one of {list_of_keys}', token, list_of_keys)
        return None

    def pop_enum(self, enum_class: Type[E]) -> E:
        enum: Optional[E] = self.pop_optional_enum(enum_class)
        if enum:
            return enum
        else:
            raise self._create_load_error(f'Insufficient parameters. Expected one of {enum_class.lowercase_names()}', None, enum_class.lowercase_names())

    def pop_optional_enum(self, enum_class: Type[E]) -> Optional[E]:
        enum_and_token: Optional[Tuple[E, Token]] = self.pop_optional_enum_and_token(enum_class)
        if enum_and_token:
            return enum_and_token[0]
        else:
            return None

    def pop_optional_enum_and_token(self, enum_class: Type[E]) -> Optional[Tuple[E, Token]]:
        token: Optional[Token] = self._token_stream.next()
        if token:
            try:
                return enum_class[token.text.upper()], token
            except KeyError:
                raise self._create_load_error(f'Unknown enumeration value', token, enum_class.lowercase_names())
        return None

    def pop_variable_name(self, list_of_variable_names: List[str]) -> str:
        variable_name: Optional[str] = self.pop_optional_variable_name(list_of_variable_names)
        if not variable_name:
            raise self._create_load_error('Insufficient parameters. Expecting variable name', None, list_of_variable_names)
        return variable_name

    def pop_optional_variable_name(self, list_of_variable_names: List[str]) -> Optional[str]:
        token: Optional[Token] = self._token_stream.next()
        if token:
            if VARIABLE_NAME_PATTERN.fullmatch(token.text):
                return token.text
            else:
                raise self._create_load_error(f"Variable name '{token.text}' does not match pattern '{VARIABLE_NAME_PATTERN.pattern}'", token, list_of_variable_names)
        return None

    def fail_if_not_empty(self) -> None:
        token: Optional[Token] = self._token_stream.next()
        if token is not None:
            raise self._create_load_error('Unexpected additional parameter', token)

    def _parse_int(self, token: Token, text: str, error_text: str) -> int:
        try:
            value = int(text)
            return value
        except ValueError:
            raise self._create_load_error(error_text, token)

    def _parse_uint(self, token: Token, text: str, error_text: str) -> int:
        value: int = self._parse_int(token, text, error_text)
        if value < 0:
            raise self._create_load_error(error_text, token)
        return value

    def _create_load_error(self, message, token: Optional[Token], list_of_expected_text: List[str] = []) -> LoadError:
        return LoadError(message, token, list_of_expected_text)
