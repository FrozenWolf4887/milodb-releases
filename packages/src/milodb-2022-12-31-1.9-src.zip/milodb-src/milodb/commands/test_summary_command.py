from milodb.commands.command import Command
from milodb.commands.summary_command import SummaryCommand
from milodb.commands.test_command_base import CommandTestBase
from typing import Type

COMMAND_NAME: str = 'summary'
COMMAND_CLASS: Type[Command] = SummaryCommand

class TestSummaryCommand(CommandTestBase):
    def test_without_arguments_returns_success(self):
        self.parse_test([COMMAND_NAME])
        self.assert_successful(COMMAND_CLASS)

    def test_with_one_index_returns_success(self):
        self.parse_test([COMMAND_NAME, '1234'])
        self.assert_successful(COMMAND_CLASS)

    def test_with_three_indices_returns_success(self):
        self.parse_test([COMMAND_NAME, '1234', '5678', '9012'])
        self.assert_successful(COMMAND_CLASS)

    def test_with_signed_index_returns_failure(self):
        self.parse_test([COMMAND_NAME, '1234', '-5678', '9012'])
        self.assert_unsuccessful(COMMAND_CLASS, 2, 'Invalid RefId; expecting value, #value, or @value', [])

    def test_with_one_teaseid_returns_success(self):
        self.parse_test([COMMAND_NAME, '#1234'])
        self.assert_successful(COMMAND_CLASS)

    def test_with_three_teaseids_returns_success(self):
        self.parse_test([COMMAND_NAME, '#1234', '#5678', '#9012'])
        self.assert_successful(COMMAND_CLASS)

    def test_with_signed_teaseid_returns_failure(self):
        self.parse_test([COMMAND_NAME, '#1234', '#-5678', '#9012'])
        self.assert_unsuccessful(COMMAND_CLASS, 2, 'TeaseId is not a positive integer', [])

    def test_with_one_authorid_returns_success(self):
        self.parse_test([COMMAND_NAME, '@1234'])
        self.assert_successful(COMMAND_CLASS)

    def test_with_three_authorids_returns_success(self):
        self.parse_test([COMMAND_NAME, '@1234', '@5678', '@9012'])
        self.assert_successful(COMMAND_CLASS)

    def test_with_signed_authorid_returns_failure(self):
        self.parse_test([COMMAND_NAME, '@1234', '@-5678', '@9012'])
        self.assert_unsuccessful(COMMAND_CLASS, 2, 'AuthorId is not a positive integer', [])

    def test_with_mixed_refids_returns_success(self):
        self.parse_test([COMMAND_NAME, '@1234', '5678', '#9012'])
        self.assert_successful(COMMAND_CLASS)

    def test_with_non_refid_returns_failure(self):
        self.parse_test([COMMAND_NAME, 'mango', '5678', '9012'])
        self.assert_unsuccessful(COMMAND_CLASS, 1, 'Invalid RefId; expecting value, #value, or @value', [])
