from typing import Optional

MILODB_VERSION: Optional[str] = '1.11'
MILODB_DATE: Optional[str] = '2023-02-28'
