import datetime
import operator
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Callable, Dict, List, Optional, Type
from milodb import query
from milodb.command_framework.argument_stream import ArgumentStream
from milodb.database.tease import Tease, TeaseDateProperty, TeaseFloatProperty, TeaseIntProperty, TeaseStrListProperty, TeaseStrProperty, TeaseTypeProperty
from milodb.parser.token import Token

@dataclass
class PostfixError(Exception):
    message: str
    fault_token: Optional[Token]
    list_of_expected_text: List[str]

@dataclass
class PostfixResult:
    postfix_query_chain: List[query.QueryBase]
    list_of_expected_next_text: List[str]

class FieldVerb(ABC):
    @abstractmethod
    def create_query(self, argument_stream: ArgumentStream) -> query.QueryBase:
        pass

class FieldFloatVerb(FieldVerb):
    def __init__(self, tease_property: TeaseFloatProperty, field_predicate: Type[query.FieldFloatPredicate], compare_func: Callable[[float, float], bool]) -> None:
        self._tease_property: TeaseFloatProperty = tease_property
        self._field_predicate: Type[query.FieldFloatPredicate] = field_predicate
        self._compare_func: Callable[[float, float], bool] = compare_func

    def create_query(self, argument_stream: ArgumentStream) -> query.QueryBase:
        return self._field_predicate(self._tease_property, argument_stream, self._compare_func)

class FieldIntVerb(FieldVerb):
    def __init__(self, tease_property: TeaseIntProperty, field_predicate: Type[query.FieldIntPredicate], compare_func: Callable[[int, int], bool]) -> None:
        self._tease_property: TeaseIntProperty = tease_property
        self._field_predicate = field_predicate
        self._compare_func: Callable[[int, int], bool] = compare_func

    def create_query(self, argument_stream: ArgumentStream) -> query.QueryBase:
        return self._field_predicate(self._tease_property, argument_stream, self._compare_func)

class FieldStrVerb(FieldVerb):
    def __init__(self, tease_property: TeaseStrProperty, field_predicate: Type[query.FieldStrPredicate]) -> None:
        self._tease_property: TeaseStrProperty = tease_property
        self._field_predicate: Type[query.FieldStrPredicate] = field_predicate

    def create_query(self, argument_stream: ArgumentStream) -> query.QueryBase:
        return self._field_predicate(self._tease_property, argument_stream)

class FieldStrListVerb(FieldVerb):
    def __init__(self, tease_property: TeaseStrListProperty, field_predicate: Type[query.FieldStrListPredicate]) -> None:
        self._tease_property: TeaseStrListProperty = tease_property
        self._field_predicate: Type[query.FieldStrListPredicate] = field_predicate

    def create_query(self, argument_stream: ArgumentStream) -> query.QueryBase:
        return self._field_predicate(self._tease_property, argument_stream)

class FieldTypeVerb(FieldVerb):
    def __init__(self, tease_property: TeaseTypeProperty, field_predicate: Type[query.FieldTypePredicate]) -> None:
        self._tease_property: TeaseTypeProperty = tease_property
        self._field_predicate: Type[query.FieldTypePredicate] = field_predicate

    def create_query(self, argument_stream: ArgumentStream) -> query.QueryBase:
        return self._field_predicate(self._tease_property, argument_stream)

class FieldDateVerb(FieldVerb):
    def __init__(self, tease_property: TeaseDateProperty, field_predicate: Type[query.FieldDatePredicate], compare_func: Callable[[datetime.date, datetime.date], bool]) -> None:
        self._tease_property: TeaseDateProperty = tease_property
        self._field_predicate: Type[query.FieldDatePredicate] = field_predicate
        self._compare_func: Callable[[datetime.date, datetime.date], bool] = compare_func

    def create_query(self, argument_stream: ArgumentStream) -> query.QueryBase:
        return self._field_predicate(self._tease_property, argument_stream, self._compare_func)

class FieldTotmVerb(FieldVerb):
    def __init__(self, field_predicate: Type[query.FieldTotmPredicate]) -> None:
        self._field_predicate: Type[query.FieldTotmPredicate] = field_predicate

    def create_query(self, argument_stream: ArgumentStream) -> query.QueryBase:
        return self._field_predicate(argument_stream)

_MAP_OF_TEASE_FIELDNAMES_TO_PROPERTIES: Dict[str, Dict[str, FieldVerb]] = {
    'teaseId': {
        '=': FieldIntVerb(Tease.tease_id, query.FieldUnsignedIntCompare, operator.eq),
        '>': FieldIntVerb(Tease.tease_id, query.FieldUnsignedIntCompare, operator.gt),
        '<': FieldIntVerb(Tease.tease_id, query.FieldUnsignedIntCompare, operator.lt),
        '>=': FieldIntVerb(Tease.tease_id, query.FieldUnsignedIntCompare, operator.ge),
        '<=': FieldIntVerb(Tease.tease_id, query.FieldUnsignedIntCompare, operator.le)
    },
    'authorId': {
        '=': FieldIntVerb(Tease.author_id, query.FieldUnsignedIntCompare, operator.eq),
        '>': FieldIntVerb(Tease.author_id, query.FieldUnsignedIntCompare, operator.gt),
        '<': FieldIntVerb(Tease.author_id, query.FieldUnsignedIntCompare, operator.lt),
        '>=': FieldIntVerb(Tease.author_id, query.FieldUnsignedIntCompare, operator.ge),
        '<=': FieldIntVerb(Tease.author_id, query.FieldUnsignedIntCompare, operator.le)
    },
    'type': {
        'is': FieldTypeVerb(Tease.type, query.FieldTypeIs),
    },
    'title': {
        'is': FieldStrVerb(Tease.title, query.FieldStrIs),
        'contains': FieldStrVerb(Tease.title, query.FieldStrContains),
        'matches': FieldStrVerb(Tease.title, query.FieldStrMatches)
    },
    'summary': {
        'is': FieldStrVerb(Tease.summary, query.FieldStrIs),
        'contains': FieldStrVerb(Tease.summary, query.FieldStrContains),
        'matches': FieldStrVerb(Tease.summary, query.FieldStrMatches)
    },
    'author': {
        'is': FieldStrVerb(Tease.author_name, query.FieldStrIs),
        'contains': FieldStrVerb(Tease.author_name, query.FieldStrContains),
        'matches': FieldStrVerb(Tease.author_name, query.FieldStrMatches)
    },
    'tag': {
        'is': FieldStrListVerb(Tease.list_of_tags, query.FieldStrListIs),
        'contains': FieldStrListVerb(Tease.list_of_tags, query.FieldStrListContains),
        'matches': FieldStrListVerb(Tease.list_of_tags, query.FieldStrListMatches)
    },
    'date': {
        '=': FieldDateVerb(Tease.date, query.FieldDateCompare, operator.eq),
        '>': FieldDateVerb(Tease.date, query.FieldDateCompare, operator.gt),
        '<': FieldDateVerb(Tease.date, query.FieldDateCompare, operator.lt),
        '>=': FieldDateVerb(Tease.date, query.FieldDateCompare, operator.ge),
        '<=': FieldDateVerb(Tease.date, query.FieldDateCompare, operator.le)
    },
    'rating': {
        '=': FieldFloatVerb(Tease.rating_value, query.FieldUnsignedFloatCompare, operator.eq),
        '>': FieldFloatVerb(Tease.rating_value, query.FieldUnsignedFloatCompare, operator.gt),
        '<': FieldFloatVerb(Tease.rating_value, query.FieldUnsignedFloatCompare, operator.lt),
        '>=': FieldFloatVerb(Tease.rating_value, query.FieldUnsignedFloatCompare, operator.ge),
        '<=': FieldFloatVerb(Tease.rating_value, query.FieldUnsignedFloatCompare, operator.le)
    },
    'text': {
        'contains': FieldStrListVerb(Tease.list_of_text_blocks, query.FieldStrListContains),
        'matches': FieldStrListVerb(Tease.list_of_text_blocks, query.FieldStrListMatches)
    },
    'totm': {
        'is': FieldTotmVerb(query.FieldTotmIs)
    }
}

_MAP_OF_BINARY_OPERATORS_TO_QUERY_CLASS: Dict[str, Type[query.QueryBase]] = {
    'and': query.And,
    'or': query.Or
}

_MAP_OF_UNARY_OPERATORS_TO_QUERY_CLASS: Dict[str, Type[query.QueryBase]] = {
    'not': query.Not
}

def get_list_of_field_names() -> List[str]:
    return list(_MAP_OF_TEASE_FIELDNAMES_TO_PROPERTIES.keys())

def get_list_of_verb_names() -> List[str]:
    list_of_verb_names: List[str] = []
    verb_dictionary: Dict[str, FieldVerb]
    for verb_dictionary in _MAP_OF_TEASE_FIELDNAMES_TO_PROPERTIES.values():
        list_of_verb_names.extend(verb_dictionary.keys())
    return list(set(list_of_verb_names))

def get_list_of_operators() -> List[str]:
    return list(_MAP_OF_BINARY_OPERATORS_TO_QUERY_CLASS.keys()) + list(_MAP_OF_UNARY_OPERATORS_TO_QUERY_CLASS.keys()) + ['(', ')']

def convert(argument_stream: ArgumentStream) -> PostfixResult:
    converter = _InfixToPostfixQueryConverter(argument_stream)
    return converter.get_result()

class _InfixToPostfixQueryConverter:
    def __init__(self, argument_stream: ArgumentStream) -> None:
        self._argument_stream: ArgumentStream = argument_stream
        self._stack_of_operators: List[Optional[query.QueryBase]] = []
        self._expecting_query: bool = True
        self._expecting_verb_list: Optional[List[str]] = None
        self._expecting_binary_operator: bool = False
        self._expecting_unary_operator: bool = True
        self._expecting_open: bool = True
        self._expecting_close: bool = False
        self._postfix_query_chain: List[query.QueryBase] = []

        self._process_queue_of_tokens()

    def get_result(self) -> PostfixResult:
        return PostfixResult(self._postfix_query_chain, self._get_list_of_expected_next_text())

    def _get_list_of_expected_next_text(self) -> List[str]:
        list_of_expected_next_text: List[str] = []
        if self._expecting_query:
            list_of_expected_next_text.extend(_MAP_OF_TEASE_FIELDNAMES_TO_PROPERTIES.keys())
        if self._expecting_binary_operator:
            list_of_expected_next_text.extend(_MAP_OF_BINARY_OPERATORS_TO_QUERY_CLASS.keys())
        if self._expecting_unary_operator:
            list_of_expected_next_text.extend(_MAP_OF_UNARY_OPERATORS_TO_QUERY_CLASS.keys())
        if self._expecting_verb_list:
            list_of_expected_next_text.extend(self._expecting_verb_list)
        if self._expecting_open:
            list_of_expected_next_text.append('(')
        if self._expecting_close:
            list_of_expected_next_text.append(')')
        return list_of_expected_next_text

    def _process_queue_of_tokens(self) -> None:
        ArgumentStream.for_each(self._argument_stream.pop_optional_token, self._process_token)

        if self._expecting_query:
            raise PostfixError('Unexpected end of input when expecting a query', None, self._get_list_of_expected_next_text())

        while self._stack_of_operators:
            the_operator: Optional[query.QueryBase] = self._stack_of_operators.pop()
            if the_operator:
                self._postfix_query_chain.append(the_operator)
            else:
                raise PostfixError('No matching closing parenthesis for opening parenthesis', None, self._get_list_of_expected_next_text())

    def _process_token(self, token: Token) -> None:
        if not (self._try_process_query_field(token) or
                self._try_process_binary_operator(token) or
                self._try_process_unary_operator(token) or
                self._try_process_parenthesis(token)):
            raise PostfixError('Unknown field name or operator', token, self._get_list_of_expected_next_text())

    def _try_process_query_field(self, token: Token) -> bool:
        verb_dictionary: Optional[Dict[str, FieldVerb]] = _MAP_OF_TEASE_FIELDNAMES_TO_PROPERTIES.get(token.text)
        if verb_dictionary:
            if not self._expecting_query:
                raise PostfixError('Not expecting field query', token, self._get_list_of_expected_next_text())
            self._process_query_field(token, verb_dictionary)
            return True
        return False

    def _try_process_binary_operator(self, token: Token) -> bool:
        query_class: Optional[Type[query.QueryBase]] = _MAP_OF_BINARY_OPERATORS_TO_QUERY_CLASS.get(token.text)
        if query_class:
            if not self._expecting_binary_operator:
                raise PostfixError('Not expecting binary operator', token, self._get_list_of_expected_next_text())
            self._process_binary_operator(token, query_class)
            return True
        return False

    def _try_process_unary_operator(self, token: Token) -> bool:
        query_class: Optional[Type[query.QueryBase]] = _MAP_OF_UNARY_OPERATORS_TO_QUERY_CLASS.get(token.text)
        if query_class:
            if not self._expecting_unary_operator:
                raise PostfixError('Not expecting unary operator', token, self._get_list_of_expected_next_text())
            self._process_unary_operator(token, query_class)
            return True
        return False

    def _try_process_parenthesis(self, token: Token) -> bool:
        token_text = token.text
        if token_text == '(':
            if not self._expecting_open:
                raise PostfixError('Not expecting opening parenthesis', token, self._get_list_of_expected_next_text())
            self._process_open_parenthesis(token)
            return True
        if token_text == ')':
            if not self._expecting_close:
                raise PostfixError('Not expecting closing parenthesis', token, self._get_list_of_expected_next_text())
            self._process_close_parenthesis(token)
            return True
        return False

    def _process_query_field(self, _: Token, verb_dictionary: Dict[str, FieldVerb]) -> None:
        self._expecting_query = False
        self._expecting_verb_list = list(verb_dictionary.keys())
        self._expecting_binary_operator = False
        self._expecting_unary_operator = False
        self._expecting_open = False
        self._expecting_close = False

        field_verb: FieldVerb = self._argument_stream.pop_dict_value(verb_dictionary)

        self._expecting_query = False
        self._expecting_verb_list = None
        self._expecting_binary_operator = False
        self._expecting_unary_operator = False
        self._expecting_open = False
        self._expecting_close = False

        query_object: query.QueryBase = field_verb.create_query(self._argument_stream)

        self._postfix_query_chain.append(query_object)
        self._pop_unary_operators_to_postfix_query_chain()

        self._expecting_query = False
        self._expecting_verb_list = None
        self._expecting_binary_operator = True
        self._expecting_unary_operator = False
        self._expecting_open = False
        self._expecting_close = self._has_any_stacked_open_parenthesis()

    def _process_binary_operator(self, _: Token, query_class: Type[query.QueryBase]) -> None:
        self._stack_of_operators.append(query_class())

        self._expecting_query = True
        self._expecting_verb_list = None
        self._expecting_binary_operator = False
        self._expecting_unary_operator = True
        self._expecting_open = True
        self._expecting_close = False

    def _process_unary_operator(self, _: Token, query_class: Type[query.QueryBase]) -> None:
        self._stack_of_operators.append(query_class())

        self._expecting_query = True
        self._expecting_verb_list = None
        self._expecting_binary_operator = False
        self._expecting_unary_operator = False
        self._expecting_open = True
        self._expecting_close = False

    def _process_open_parenthesis(self, _: Token) -> None:
        self._stack_of_operators.append(None)

        self._expecting_query = True
        self._expecting_verb_list = None
        self._expecting_binary_operator = False
        self._expecting_unary_operator = True
        self._expecting_open = True
        self._expecting_close = False

    def _process_close_parenthesis(self, token: Token) -> None:
        while self._stack_of_operators:
            the_operator: Optional[query.QueryBase] = self._stack_of_operators.pop()
            if not the_operator:
                break
            self._postfix_query_chain.append(the_operator)
        else:
            raise PostfixError('No matching opening parenthesis for closing parenthesis', token, self._get_list_of_expected_next_text())

        self._expecting_query = False
        self._expecting_verb_list = None
        self._expecting_binary_operator = True
        self._expecting_unary_operator = False
        self._expecting_open = False
        self._expecting_close = self._has_any_stacked_open_parenthesis()

    def _pop_unary_operators_to_postfix_query_chain(self) -> None:
        while self._stack_of_operators:
            the_operator: Optional[query.QueryBase] = self._stack_of_operators[-1]
            if isinstance(the_operator, query.Not):
                self._stack_of_operators.pop()
                self._postfix_query_chain.append(the_operator)
            else:
                break

    def _has_any_stacked_open_parenthesis(self) -> bool:
        return any(the_operator is None for the_operator in self._stack_of_operators)
