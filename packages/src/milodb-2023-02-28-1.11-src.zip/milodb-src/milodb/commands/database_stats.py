from dataclasses import dataclass
from typing import Dict, List, Optional
from milodb.commands.command_support import count_words
from milodb.database.tease import Tease, TotmStatus

@dataclass
class TeaseContentStats:
    tease: Tease
    word_count: int
    text_size: int

@dataclass
class TotmStats:
    author_name: str
    wins: int
    nominations: int

class DatabaseStats:
    def __init__(self, list_of_teases: List[Tease]) -> None:
        self._list_of_teases: List[Tease] = list_of_teases
        self._map_of_tag_to_occurrence_count: Optional[Dict[str, int]] = None
        self._map_of_author_to_tease_count: Optional[Dict[str, int]] = None
        self._count_of_missing_authors: Optional[int] = None
        self._total_count_of_words: Optional[int] = None
        self._list_of_content_stats: Optional[List[TeaseContentStats]] = None
        self._map_of_author_to_word_count: Optional[Dict[str, int]] = None
        self._map_of_author_to_totm_stats: Optional[Dict[str, TotmStats]] = None
        self._count_of_totm_winners: Optional[int] = None
        self._count_of_totm_nominees: Optional[int] = None

    @property
    def map_of_tag_to_occurrence_count(self) -> Dict[str, int]:
        if self._map_of_tag_to_occurrence_count is None:
            self._gather_tag_stats()
        return self._map_of_tag_to_occurrence_count or {}

    @property
    def map_of_author_to_tease_count(self) -> Dict[str, int]:
        if self._map_of_author_to_tease_count is None:
            self._gather_author_stats()
        return self._map_of_author_to_tease_count or {}

    @property
    def count_of_missing_authors(self) -> int:
        if self._count_of_missing_authors is None:
            self._gather_author_stats()
        return self._count_of_missing_authors or 0

    @property
    def total_count_of_words(self) -> int:
        if self._total_count_of_words is None:
            self._gather_content_stats()
        return self._total_count_of_words or 0

    @property
    def list_of_content_stats(self) -> List[TeaseContentStats]:
        if self._list_of_content_stats is None:
            self._gather_content_stats()
        return self._list_of_content_stats or []

    @property
    def map_of_author_to_word_count(self) -> Dict[str, int]:
        if self._map_of_author_to_word_count is None:
            self._gather_content_stats()
        return self._map_of_author_to_word_count or {}

    @property
    def map_of_author_to_totm_stats(self) -> Dict[str, TotmStats]:
        if self._map_of_author_to_totm_stats is None:
            self._gather_totm_stats()
        return self._map_of_author_to_totm_stats or {}

    @property
    def count_of_totm_winners(self) -> int:
        if self._count_of_totm_winners is None:
            self._gather_totm_stats()
        return self._count_of_totm_winners or 0

    @property
    def count_of_totm_nominees(self) -> int:
        if self._count_of_totm_nominees is None:
            self._gather_totm_stats()
        return self._count_of_totm_nominees or 0

    def _gather_tag_stats(self) -> None:
        self._map_of_tag_to_occurrence_count = {}
        tease: Tease
        for tease in self._list_of_teases:
            tag: str
            for tag in tease.list_of_tags():
                try:
                    value: int = self._map_of_tag_to_occurrence_count[tag]
                except KeyError:
                    self._map_of_tag_to_occurrence_count[tag] = 1
                else:
                    self._map_of_tag_to_occurrence_count[tag] = value + 1

    def _gather_author_stats(self) -> None:
        self._map_of_author_to_tease_count = {}
        self._count_of_missing_authors = 0
        tease: Tease
        for tease in self._list_of_teases:
            if not tease.has_author():
                self._count_of_missing_authors += 1
            else:
                try:
                    value: int = self._map_of_author_to_tease_count[tease.author_name()]
                except KeyError:
                    self._map_of_author_to_tease_count[tease.author_name()] = 1
                else:
                    self._map_of_author_to_tease_count[tease.author_name()] = value + 1

    def _gather_content_stats(self) -> None:
        self._list_of_content_stats = []
        self._map_of_author_to_word_count = {}
        self._total_count_of_words = 0

        tease: Tease
        for tease in self._list_of_teases:
            tease_count_of_words: int = 0
            tease_text_size: int = 0
            text: str
            for text in tease.list_of_text_blocks():
                tease_count_of_words += count_words(text)
                tease_text_size += len(text)
            self._list_of_content_stats.append(TeaseContentStats(tease, tease_count_of_words, tease_text_size))
            self._total_count_of_words += tease_count_of_words
            if tease.has_author():
                try:
                    value: int = self._map_of_author_to_word_count[tease.author_name()]
                except KeyError:
                    self._map_of_author_to_word_count[tease.author_name()] = tease_count_of_words
                else:
                    self._map_of_author_to_word_count[tease.author_name()] = value + tease_count_of_words

    def _gather_totm_stats(self) -> None:
        self._map_of_author_to_totm_stats = {}
        self._count_of_totm_winners = 0
        self._count_of_totm_nominees = 0
        tease: Tease
        for tease in self._list_of_teases:
            delta_wins: int = 0
            delta_nominations: int = 0
            if tease.totm_status() == TotmStatus.WINNER:
                delta_wins = 1
            elif tease.totm_status() == TotmStatus.NOMINEE:
                delta_nominations = 1

            self._count_of_totm_winners += delta_wins
            self._count_of_totm_nominees += delta_nominations

            if tease.has_author() and (delta_wins or delta_nominations):
                try:
                    stats: TotmStats = self._map_of_author_to_totm_stats[tease.author_name()]
                except KeyError:
                    self._map_of_author_to_totm_stats[tease.author_name()] = TotmStats(tease.author_name(), delta_wins, delta_nominations)
                else:
                    stats.wins += delta_wins
                    stats.nominations += delta_nominations
