from dataclasses import dataclass
from typing import List
from milodb import query
from milodb.command_framework.i_command_factory import ICommandFactory
from milodb.command_framework.quit_flag import QuitFlag
from milodb.commands.database_stats import DatabaseStats
from milodb.commands.sort_keys import OrderedSortKey, SortKey
from milodb.config.framework import IConfig
from milodb.config.session_config import SessionConfig
from milodb.database.tease import Tease
from milodb.output.outputter import Outputter
from milodb.user_variables import UserVariables

@dataclass
class CommandContext:
    quit_flag: QuitFlag
    command_factory: ICommandFactory
    session_config: SessionConfig
    system_config: IConfig
    user_variables: UserVariables
    database_stats: DatabaseStats
    list_of_teases: List[Tease]
    list_of_tease_matches: List[query.TeaseMatch]
    list_of_available_sort_keys: List[SortKey]
    list_of_active_sort_keys: List[OrderedSortKey]
    list_of_outputters: List[Outputter]
    current_outputter: Outputter
