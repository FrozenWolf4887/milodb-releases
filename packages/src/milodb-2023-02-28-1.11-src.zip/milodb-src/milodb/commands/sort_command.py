from typing import Dict, List, Optional, Tuple
from milodb.command_framework.argument_stream import ArgumentStream
from milodb.commands.command import Command
from milodb.commands.command_context import CommandContext
from milodb.commands.command_support import sort_tease_matches
from milodb.commands.help_info import HelpInfo
from milodb.commands.sort_keys import OrderedSortKey, SortKey
from milodb.parser.token import Token

class SortCommand(Command):
    def __init__(self, context: CommandContext) -> None:
        self._context = context
        self._new_list_of_active_sort_keys: List[OrderedSortKey] = []

    def load(self, argument_stream: ArgumentStream) -> List[str]:
        map_of_names_to_sort_keys: Dict[str, SortKey] = {}
        sort_key: SortKey
        for sort_key in self._context.list_of_available_sort_keys:
            map_of_names_to_sort_keys[sort_key.get_name()] = sort_key
            map_of_names_to_sort_keys['-' + sort_key.get_name()] = sort_key

        def accumulate_sort_key() -> Optional[OrderedSortKey]:
            ordered_sort_key: Optional[OrderedSortKey] = None
            sort_key_and_token: Optional[Tuple[SortKey, Token]] = argument_stream.pop_optional_dict_value_and_token(map_of_names_to_sort_keys)
            if sort_key_and_token:
                sort_key = sort_key_and_token[0]
                token: Token = sort_key_and_token[1]
                map_of_names_to_sort_keys.pop(sort_key.get_name())
                map_of_names_to_sort_keys.pop('-' + sort_key.get_name())
                is_ascending: bool = token.text[0] != '-'
                ordered_sort_key = OrderedSortKey(sort_key, is_ascending)
            return ordered_sort_key

        self._new_list_of_active_sort_keys = ArgumentStream.pop_list(accumulate_sort_key)

        return list(map_of_names_to_sort_keys.keys())

    def execute(self) -> None:
        if self._new_list_of_active_sort_keys:
            self._context.list_of_active_sort_keys = self._new_list_of_active_sort_keys
            self._context.session_config.normal_writer.writeln(f"Changed sorting keys to {[ ('' if sort_key.is_ascending() else '-') + sort_key.get_name() for sort_key in self._context.list_of_active_sort_keys ]}")
            self._context.list_of_tease_matches = sort_tease_matches(self._context.list_of_tease_matches, self._context.list_of_active_sort_keys)
        else:
            self._context.session_config.normal_writer.writeln(f"Current sorting keys are {[ ('' if sort_key.is_ascending() else '-') + sort_key.get_name() for sort_key in self._context.list_of_active_sort_keys ]}")
            self._context.session_config.normal_writer.writeln(f"Available keys are {sorted([ sort_key.get_name() for sort_key in self._context.list_of_available_sort_keys ])}")

    class Help(HelpInfo):
        def __init__(self, context: CommandContext) -> None:
            self._context = context

        def get_one_line_summary(self) -> str:
            return "Sorts the list of teases by specific fields"

        def get_detailed_summary(self) -> str:
            sort_key_help_text: str = ''
            sort_key: SortKey
            for sort_key in self._context.list_of_available_sort_keys:
                if sort_key_help_text:
                    sort_key_help_text += '\r'
                sort_key_help_text += f'  {sort_key.get_name():<8} : \t{sort_key.get_description()}'

            return (
                "Arguments: [list of sort keys]\n"
                "Sets the sorting order for the display of teases. More than one key can be"
                " specified to determine secondary, tertiary, etc. ordering.\n"
                "Keys:\r"
                f'{sort_key_help_text}\n'
                "Keys can be prefixed with '-' to indicate a descending order, otherwise the"
                " order defaults to ascending.\n"
                "When used without arguments, the current sorting keys are shown.\n"
                "Example:\r"
                "  \tSort by teaseId\r"
                "  > \tsort teaseId\r"
                "Example:\r"
                "  \tSort by rating (ascending) and date (descending)\r"
                "  > \tsort rating -date\n"
                "See also:\r"
                "  \tlist\n"
            )
