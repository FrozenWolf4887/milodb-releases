import functools
from typing import List
from milodb import query
from milodb.commands.sort_keys import CompareResult, OrderedSortKey, default_sort_key

_LINEFEED_CHAR: str = '\n'
_SPACE_CHAR: str = ' '
_TAB_CHAR: str = '\t'

def sort_tease_matches(list_of_matching_teases: List[query.TeaseMatch], list_of_sort_keys: List[OrderedSortKey]) -> List[query.TeaseMatch]:
    if not list_of_matching_teases:
        return []

    def custom_comparer(left: query.TeaseMatch, right: query.TeaseMatch) -> int:
        for sort_key in list_of_sort_keys + [default_sort_key]:
            compare_result: CompareResult = sort_key.compare(left, right)
            if compare_result != CompareResult.BOTH_ARE_SAME:
                return compare_result.value
        return CompareResult.BOTH_ARE_SAME.value

    sorted_list_of_matching_teases: List[query.TeaseMatch] = sorted(list_of_matching_teases, key=functools.cmp_to_key(custom_comparer))
    index: int
    tease_match: query.TeaseMatch
    for index, tease_match in enumerate(sorted_list_of_matching_teases):
        tease_match.index_of_match = index + 1

    return sorted_list_of_matching_teases

def count_words(text: str) -> int:
    return len(text.split())

class WordWrapper:
    def __init__(self, text: str, max_line_length: int) -> None:
        self._max_line_length: int = max_line_length
        self._result_text = ""
        self._line_length: int = 0
        self._indent_length: int = 0
        self._current_word: str = ""
        self._is_in_space: bool = False
        self._number_of_spaces: int = 0

        char: str
        for char in text:
            self._process_char(char)

        if self._line_length + self._number_of_spaces + len(self._current_word) > max_line_length:
            self._result_text += _LINEFEED_CHAR
            self._result_text += ' ' * self._indent_length
            self._result_text += self._current_word
        else:
            self._result_text += ' ' * self._number_of_spaces
            self._result_text += self._current_word

    @property
    def text(self) -> str:
        return self._result_text

    def _process_char(self, char: str) -> None:
        if char == _LINEFEED_CHAR:
            self._process_linefeed()
        elif char == _SPACE_CHAR:
            self._process_space()
        elif char == _TAB_CHAR:
            self._process_indent()
        else:
            self._is_in_space = False
            self._current_word += char

    def _process_linefeed(self) -> None:
        if self._line_length + self._number_of_spaces + len(self._current_word) >= self._max_line_length:
            self._result_text += _LINEFEED_CHAR
            self._result_text += ' ' * self._indent_length
            self._result_text += self._current_word
        else:
            self._result_text += ' ' * self._number_of_spaces
            self._result_text += self._current_word
        self._result_text += _LINEFEED_CHAR
        self._line_length = 0
        self._indent_length = 0
        self._current_word = ""
        self._is_in_space = False
        self._number_of_spaces = 0

    def _process_space(self) -> None:
        if self._is_in_space:
            self._number_of_spaces += 1
        else:
            self._is_in_space = True
            if self._line_length + self._number_of_spaces + len(self._current_word) > self._max_line_length:
                self._result_text += _LINEFEED_CHAR
                self._result_text += ' ' * self._indent_length
                self._result_text += self._current_word
                self._line_length = self._indent_length + len(self._current_word)
                self._current_word = ""
                self._number_of_spaces = 0
            else:
                self._result_text += ' ' * self._number_of_spaces
                self._result_text += self._current_word
                self._line_length += self._number_of_spaces + len(self._current_word)
            self._number_of_spaces = 1
            self._current_word = ""

    def _process_indent(self) -> None:
        self._indent_length = self._line_length + self._number_of_spaces
