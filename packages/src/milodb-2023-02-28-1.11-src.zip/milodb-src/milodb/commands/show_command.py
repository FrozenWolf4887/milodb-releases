from typing import List, Optional
from milodb import query
from milodb.command_framework.argument_stream import ArgumentStream
from milodb.command_framework.ref_id import RefId
from milodb.commands.command import Command
from milodb.commands.command_context import CommandContext
from milodb.commands.database_support import try_create_list_of_tease_matches_from_ref_ids
from milodb.commands.help_info import HelpInfo

class ShowCommand(Command):
    def __init__(self, context: CommandContext) -> None:
        self._context = context
        self._list_of_ref_ids: List[RefId] = []

    def load(self, argument_stream: ArgumentStream) -> List[str]:
        self._list_of_ref_ids = ArgumentStream.pop_list(argument_stream.pop_optional_ref_id)
        return []

    def execute(self) -> None:
        list_of_tease_matches: Optional[List[query.TeaseMatch]] = None
        if self._list_of_ref_ids:
            list_of_tease_matches = try_create_list_of_tease_matches_from_ref_ids(self._context, self._list_of_ref_ids)
        else:
            list_of_tease_matches = self._context.list_of_tease_matches

        if list_of_tease_matches:
            self._context.current_outputter.print_matching_text_of_list_of_teases(list_of_tease_matches)
        else:
            self._context.session_config.error_writer.writeln("No teases available to list")

    class Help(HelpInfo):
        def __init__(self, context: CommandContext) -> None:
            self._context = context

        def get_one_line_summary(self) -> str:
            return "Prints the summary and text matches for the current results"

        def get_detailed_summary(self) -> str:
            return (
                "Arguments: [list of RefIds]\n"
                "Shows details for each tease including the matching text paragraphs if"
                " appropriate. The formatting used for the details can be controlled with the "
                " format command.\n"
                "When used without arguments, all teases that were found from the last query are"
                " included. When one or more RefIds are specified, only those teases are included.\n"
                "RefIds can be an index into the list of matches such as '3', a teaseId such as"
                " '#38664', or an authorId such as '@43937'.\n"
                "Matching fields and text may be highlighted which can be controlled with the"
                " highlight command.\n"
                "The text paragraphs may be abbreviated with an ellipsis which can be controlled"
                " with the ellipsis command.\n"
                "Example:\r"
                "  \tShow details of the last query results\r"
                "  > \tshow\r"
                "Example:\r"
                "  \tShow details of some matched teases by index\r"
                "  > \tshow 3 7\r"
                "Example:\r"
                "  \tShow details of some specific teaseIds\r"
                "  > \tshow #16830 #1465 #38664\r"
                "Example:\r"
                "  \tShow details of teases from a specific authorId\r"
                "  > \tshow @43937\n"
                "See also:\r"
                "  \tshowall, summary, format, ellipsis, highlight\n"
            )
