from typing import List, Optional
from milodb import query
from milodb.command_framework.ref_id import MatchIndex, RefId, TeaseId
from milodb.commands.command_context import CommandContext
from milodb.database.database import get_teases_by_author_id, try_get_tease
from milodb.database.tease import Tease

def try_create_list_of_tease_matches_from_ref_ids(context: CommandContext, list_of_ref_ids: List[RefId]) -> Optional[List[query.TeaseMatch]]:
    list_of_tease_matches: List[query.TeaseMatch] = []
    any_fault: bool = False
    tease_match: Optional[query.TeaseMatch] = None
    ref_id: RefId
    for ref_id in list_of_ref_ids:
        if isinstance(ref_id, MatchIndex):
            tease_match = _try_find_tease_by_match_index(context, ref_id.match_index)
            if tease_match:
                list_of_tease_matches.append(tease_match)
            else:
                context.session_config.error_writer.writeln(f"Match index '{ref_id.match_index}' is out of range")
                any_fault = True
        elif isinstance(ref_id, TeaseId):
            tease_match = _try_find_tease_by_tease_id(context, ref_id.tease_id)
            if tease_match:
                list_of_tease_matches.append(tease_match)
            else:
                context.session_config.error_writer.writeln(f"Unable to find tease for tease id '{ref_id.tease_id}'")
                any_fault = True
        else:
            author_tease_matches: List[query.TeaseMatch] = _find_teases_by_author_id(context, ref_id.author_id)
            if author_tease_matches:
                list_of_tease_matches.extend(author_tease_matches)
            else:
                context.session_config.error_writer.writeln(f"Unable to find author id '{ref_id.author_id}'")
                any_fault = True

    return list_of_tease_matches if not any_fault else None

def try_get_tease_id_from_ref_id(context: CommandContext, ref_id: RefId) -> Optional[query.TeaseMatch]:
    tease_match: Optional[query.TeaseMatch] = None

    if isinstance(ref_id, MatchIndex):
        tease_match = _try_find_tease_by_match_index(context, ref_id.match_index)
        if not tease_match:
            context.session_config.error_writer.writeln(f"Match index '{ref_id.match_index}' is out of range")
    elif isinstance(ref_id, TeaseId):
        tease_match = _try_find_tease_by_tease_id(context, ref_id.tease_id)
        if not tease_match:
            context.session_config.error_writer.writeln(f"Unable to find tease for tease id '{ref_id.tease_id}'")

    return tease_match

def _try_find_tease_by_match_index(context: CommandContext, match_index: int) -> Optional[query.TeaseMatch]:
    if context.list_of_tease_matches:
        for tease_match in context.list_of_tease_matches:
            if tease_match.index_of_match == match_index:
                return tease_match
    return None

def _try_find_tease_by_tease_id(context: CommandContext, tease_id: int) -> Optional[query.TeaseMatch]:
    tease_match: Optional[query.TeaseMatch] = None

    if context.list_of_tease_matches:
        search_tease_match: query.TeaseMatch
        for search_tease_match in context.list_of_tease_matches:
            if search_tease_match.tease.tease_id() == tease_id:
                tease_match = search_tease_match
                break

    if not tease_match:
        tease: Optional[Tease] = try_get_tease(tease_id, context.list_of_teases)
        if tease:
            tease_match = query.TeaseMatch(None, tease, [])

    return tease_match

def _find_teases_by_author_id(context: CommandContext, author_id: int) -> List[query.TeaseMatch]:
    list_of_tease_matches: List[query.TeaseMatch] = []

    if context.list_of_tease_matches:
        tease_match: query.TeaseMatch
        for tease_match in context.list_of_tease_matches:
            if tease_match.tease.author_id() == author_id:
                list_of_tease_matches.append(tease_match)

    list_of_all_author_teases: List[Tease] = get_teases_by_author_id(author_id, context.list_of_teases)
    tease: Tease
    for tease in list_of_all_author_teases:
        is_already_captured: bool = False
        for tease_match in list_of_tease_matches:
            if tease_match.tease.tease_id() == tease.tease_id():
                is_already_captured = True
                break
        if not is_already_captured:
            list_of_tease_matches.append(query.TeaseMatch(None, tease, []))

    return list_of_tease_matches
