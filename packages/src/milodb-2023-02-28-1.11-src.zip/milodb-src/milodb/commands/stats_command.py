from typing import Callable, Dict, List, Optional, Tuple
from milodb.command_framework.argument_stream import ArgumentStream
from milodb.commands.command import Command
from milodb.commands.command_context import CommandContext
from milodb.commands.database_stats import TeaseContentStats, TotmStats
from milodb.commands.help_info import HelpInfo
from milodb.database.tease import Tease

class StatsCommand(Command):
    def __init__(self, context: CommandContext) -> None:
        self._context = context
        self._stats_delegate: Callable[[CommandContext], None] = _display_general

    def load(self, argument_stream: ArgumentStream) -> List[str]:
        stats_delegate: Optional[Callable[[CommandContext], None]] = argument_stream.pop_optional_dict_value(_MAP_OF_CHOICES_TO_DELEGATE)
        if stats_delegate:
            self._stats_delegate = stats_delegate
            argument_stream.fail_if_not_empty()
            return []
        return list(_MAP_OF_CHOICES_TO_DELEGATE.keys())

    def execute(self) -> None:
        self._stats_delegate(self._context)

    class Help(HelpInfo):
        def __init__(self, context: CommandContext) -> None:
            self._context = context

        def get_one_line_summary(self) -> str:
            return "Show some database related statistics (just for fun)"

        def get_detailed_summary(self) -> str:
            return (
                f"Arguments: [{'|'.join(list(_MAP_OF_CHOICES_TO_DELEGATE.keys()))}]\n"
                "When used without arguments, general statistics are shown.\n"
                "Note that the tags associated with each tease are known to be an incomplete list, therefore"
                " the statistics are probably not very accurate. The number of words found in a tease doesn't"
                " include all of the cleverness of page navigation, scripting, etc.; the words themselves"
                " are counted by finding stuff separated by whitespace.\n"
                "Example:\r"
                "  \tDisplay some general statistics\r"
                "  > \tstats\r"
                "Example:\r"
                "  \tDisplay statistics for content\r"
                "  > \tstats content\r"
            )

def _display_general(context: CommandContext) -> None:
    context.session_config.normal_writer.writeln(f'{len(context.list_of_teases):>12,}  teases')
    context.session_config.normal_writer.writeln(f'{context.database_stats.count_of_missing_authors:>12,}  teases by unknown authors')
    context.session_config.normal_writer.writeln(f'{len(context.database_stats.map_of_author_to_tease_count.keys()):>12,}  authors')
    context.session_config.normal_writer.writeln(f'{len(context.database_stats.map_of_tag_to_occurrence_count.keys()):>12,}  unique tags')
    context.session_config.normal_writer.writeln(f'{context.database_stats.count_of_totm_winners:>12,}  TOTM winners')
    context.session_config.normal_writer.writeln(f'{context.database_stats.count_of_totm_nominees:>12,}  TOTM nominees')
    context.session_config.normal_writer.writeln(f'{context.database_stats.total_count_of_words:>12,}  total content words')

def _display_tags(context: CommandContext) -> None:
    context.session_config.normal_writer.writeln('Top occurrences of tags:')
    sorted_list_of_tags_and_occurrence_count: List[Tuple[str, int]] = sorted(context.database_stats.map_of_tag_to_occurrence_count.items(), key=lambda x: x[1], reverse=True)
    tag: str
    count: int
    for tag, count in sorted_list_of_tags_and_occurrence_count[:20]:
        context.session_config.normal_writer.writeln(f'{count:>8,}  {tag}')

def _display_authors(context: CommandContext) -> None:
    context.session_config.normal_writer.writeln('Top number of teases by author:')
    sorted_list_of_authors_and_tease_count: List[Tuple[str, int]] = sorted(context.database_stats.map_of_author_to_tease_count.items(), key=lambda x: x[1], reverse=True)
    author: str
    tease_count: int
    for author, tease_count in sorted_list_of_authors_and_tease_count[:20]:
        context.session_config.normal_writer.writeln(f'{tease_count:>8,}  {author}')

    context.session_config.normal_writer.writeln('\nTop TOTM awards by author:')
    sorted_list_of_authors_and_totm_stats: List[Tuple[str, TotmStats]] = sorted(context.database_stats.map_of_author_to_totm_stats.items(), key=lambda x: (x[1].wins, x[1].nominations), reverse=True)
    totm_stats: TotmStats
    for author, totm_stats in sorted_list_of_authors_and_totm_stats[:20]:
        context.session_config.normal_writer.writeln(f'{totm_stats.wins:>6,} wins  {totm_stats.nominations:>4,} nominations  {author}')

def _display_content(context: CommandContext) -> None:
    context.session_config.normal_writer.writeln('Top word count by tease:')
    sorted_list_of_content_stats: List[TeaseContentStats] = sorted(context.database_stats.list_of_content_stats, key=lambda stat: stat.word_count, reverse=True)
    content_stats: TeaseContentStats
    for content_stats in sorted_list_of_content_stats[:20]:
        tease_id_text: str = '#' + str(content_stats.tease.tease_id())
        context.session_config.normal_writer.writeln(f'{content_stats.word_count:>12,}  {tease_id_text:>7}  {content_stats.tease.title()} : [{_get_author_text(content_stats.tease)}]')

    context.session_config.normal_writer.writeln('\nTop word count by author:')
    sorted_list_of_authors_and_word_count: List[Tuple[str, int]] = sorted(context.database_stats.map_of_author_to_word_count.items(), key=lambda x: x[1], reverse=True)
    author: str
    word_count: int
    for author, word_count in sorted_list_of_authors_and_word_count[:20]:
        context.session_config.normal_writer.writeln(f'{word_count:>12,}  {author}')

def _display_images(context: CommandContext) -> None:
    context.session_config.normal_writer.writeln('Top count of unique images by tease:')
    sorted_list_of_teases_by_image_count: List[Tease] = sorted(context.list_of_teases, key=lambda tease: (tease.count_of_unique_images(), tease.count_of_images()), reverse=True)
    tease: Tease
    for tease in sorted_list_of_teases_by_image_count[:20]:
        tease_id_text: str = '#' + str(tease.tease_id())
        context.session_config.normal_writer.writeln(f'{tease.count_of_unique_images():>11,}  {tease_id_text:>7}  {tease.title()} : [{_get_author_text(tease)}]')

def _get_author_text(tease: Tease) -> str:
    if tease.has_author():
        return f"{tease.author_name()}, @{tease.author_id()}"
    return 'unknown author'

_MAP_OF_CHOICES_TO_DELEGATE: Dict[str, Callable[[CommandContext], None]] = {
    'tags': _display_tags,
    'authors': _display_authors,
    'content': _display_content,
    'images': _display_images
}
