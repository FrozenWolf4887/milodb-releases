import os
import tempfile
import webbrowser
from typing import IO, List, Optional
from milodb import query
from milodb.command_framework.argument_stream import ArgumentStream
from milodb.command_framework.ref_id import RefId
from milodb.commands.command import Command
from milodb.commands.command_context import CommandContext
from milodb.commands.database_support import try_create_list_of_tease_matches_from_ref_ids
from milodb.commands.help_info import HelpInfo
from milodb.config.html_config import HtmlConfig
from milodb.config.session_config import SessionConfig
from milodb.output.file_output_sink import FileOutputSink
from milodb.output.html import HtmlOutputter
from milodb.resources import resource_path, try_copy_file

class BrowseCommand(Command):
    def __init__(self, context: CommandContext) -> None:
        self._context = context
        self._list_of_ref_ids: List[RefId] = []

    def load(self, argument_stream: ArgumentStream) -> List[str]:
        self._list_of_ref_ids = ArgumentStream.pop_list(argument_stream.pop_optional_ref_id)
        return []

    def execute(self) -> None:
        list_of_tease_matches: Optional[List[query.TeaseMatch]] = None
        if self._list_of_ref_ids:
            list_of_tease_matches = try_create_list_of_tease_matches_from_ref_ids(self._context, self._list_of_ref_ids)
        else:
            list_of_tease_matches = self._context.list_of_tease_matches

        if list_of_tease_matches:
            self._generate_html_and_open(list_of_tease_matches)
        else:
            self._context.session_config.error_writer.writeln("No teases available to browse")

    def _generate_html_and_open(self, list_of_tease_matches: List[query.TeaseMatch]) -> None:
        icon_filename: str = 'milodb-search-icon.png'
        icon_resource_filepath: str = resource_path(icon_filename)
        icon_filepath: str = os.path.join(tempfile.gettempdir(), icon_filename)
        if try_copy_file(icon_resource_filepath, icon_filepath) and \
           try_copy_file(resource_path('milodb-totm-winner.png'), os.path.join(tempfile.gettempdir(), 'milodb-totm-winner.png')) and \
           try_copy_file(resource_path('milodb-totm-nominee.png'), os.path.join(tempfile.gettempdir(), 'milodb-totm-nominee.png')):
            file: IO[str]
            was_successful: bool = False
            try:
                with tempfile.NamedTemporaryFile(mode='w+t', suffix='.html', encoding='utf-8', delete=False) as file:
                    temp_session_config: SessionConfig = self._context.session_config.copy()
                    temp_session_config.normal_writer = FileOutputSink(file)
                    html_config: HtmlConfig = HtmlConfig(self._context.system_config)
                    html_outputter: HtmlOutputter = HtmlOutputter(html_config, temp_session_config)
                    was_successful = html_outputter.try_write_browse_file_of_text_matches(list_of_tease_matches, icon_filename)
            except IOError as ex:
                self._context.session_config.error_writer.writeln(f'Unable to create temporary file: {ex}')
            else:
                if was_successful:
                    self._context.session_config.normal_writer.writeln(f"Opening '{file.name}'")
                    webbrowser.open(file.name)

    class Help(HelpInfo):
        def __init__(self, context: CommandContext) -> None:
            self._context = context

        def get_one_line_summary(self) -> str:
            return "Opens a webpage for the results with the matching paragraphs of text"

        def get_detailed_summary(self) -> str:
            return (
                "Arguments: [list of RefIds]\n"
                "Generates a webpage that contains details for each tease including the matching"
                " text paragraphs if appropriate.\n"
                "When used without arguments, all teases that were found from the last query are"
                " included. When one or more RefIds are specified, only those teases are included.\n"
                "RefIds can be an index into the list of matches such as '3', a teaseId such as"
                " '#38664', or an authorId such as '@43937'.\n"
                "Matching fields and text may be highlighted which can be controlled with the"
                " highlight command.\n"
                "The text paragraphs may be abbreviated with an ellipsis which can be controlled"
                " with the ellipsis command.\n"
                "Example:\r"
                "  \tOpen a webpage with the last query results\r"
                "  > \tbrowse\r"
                "Example:\r"
                "  \tOpen a webpage for matched teases by index\r"
                "  > \tbrowse 3 7\r"
                "Example:\r"
                "  \tOpen a webpage for some specific teaseIds\r"
                "  > \tbrowse #16830 #1465 #38664\r"
                "Example:\r"
                "  \tOpen a webpage for teases from some specific authorId\r"
                "  > \tbrowse @43937\n"
                "See also:\r"
                "  \tbrowseall, ellipsis, highlight\n"
            )
