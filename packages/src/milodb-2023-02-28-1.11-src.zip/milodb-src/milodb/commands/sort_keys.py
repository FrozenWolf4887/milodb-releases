import datetime
from abc import ABC, abstractmethod
from enum import IntEnum
from typing import List, TypeVar
from milodb import query
from milodb.database.tease import Tease, TeaseDateProperty, TeaseFloatProperty, TeaseIntProperty, TeaseStrProperty, TeaseTypeProperty

class CompareResult(IntEnum):
    LEFT_IS_LESS = -1
    BOTH_ARE_SAME = 0
    LEFT_IS_MORE = 1

    def invert(self) -> 'CompareResult':
        return CompareResult(self.value * -1)

class SortKey(ABC):
    @abstractmethod
    def get_name(self) -> str:
        pass
    @abstractmethod
    def get_description(self) -> str:
        pass
    @abstractmethod
    def compare(self, left: query.TeaseMatch, right: query.TeaseMatch) -> CompareResult:
        pass

class IntegerFieldSortKey(SortKey):
    def __init__(self, name: str, tease_property: TeaseIntProperty, description: str) -> None:
        self._name: str = name
        self._tease_property: TeaseIntProperty = tease_property
        self._description = description

    def get_name(self) -> str:
        return self._name

    def get_description(self) -> str:
        return self._description

    def compare(self, left: query.TeaseMatch, right: query.TeaseMatch) -> CompareResult:
        left_value: int = self._tease_property(left.tease)
        right_value: int = self._tease_property(right.tease)
        return _diff(left_value, right_value)

class FloatFieldSortKey(SortKey):
    def __init__(self, name: str, tease_property: TeaseFloatProperty, description: str) -> None:
        self._name: str = name
        self._tease_property: TeaseFloatProperty = tease_property
        self._description = description

    def get_name(self) -> str:
        return self._name

    def get_description(self) -> str:
        return self._description

    def compare(self, left: query.TeaseMatch, right: query.TeaseMatch) -> CompareResult:
        left_value: float = self._tease_property(left.tease)
        right_value: float = self._tease_property(right.tease)
        return _diff(left_value, right_value)

class StringFieldSortKey(SortKey):
    def __init__(self, name: str, tease_property: TeaseStrProperty, description: str) -> None:
        self._name: str = name
        self._tease_property: TeaseStrProperty = tease_property
        self._description = description

    def get_name(self) -> str:
        return self._name

    def get_description(self) -> str:
        return self._description

    def compare(self, left: query.TeaseMatch, right: query.TeaseMatch) -> CompareResult:
        left_value: str = self._tease_property(left.tease)
        right_value: str = self._tease_property(right.tease)
        return _diff(left_value, right_value)

class TeaseTypeSortKey(SortKey):
    def __init__(self, name: str, tease_property: TeaseTypeProperty, description: str) -> None:
        self._name: str = name
        self._tease_property: TeaseTypeProperty = tease_property
        self._description = description

    def get_name(self) -> str:
        return self._name

    def get_description(self) -> str:
        return self._description

    def compare(self, left: query.TeaseMatch, right: query.TeaseMatch) -> CompareResult:
        left_value: str = self._tease_property(left.tease).value
        right_value: str = self._tease_property(right.tease).value
        return _diff(left_value, right_value)

class DateFieldSortKey(SortKey):
    def __init__(self, name: str, tease_property: TeaseDateProperty, description: str) -> None:
        self._name: str = name
        self._tease_property: TeaseDateProperty = tease_property
        self._description = description

    def get_name(self) -> str:
        return self._name

    def get_description(self) -> str:
        return self._description

    def compare(self, left: query.TeaseMatch, right: query.TeaseMatch) -> CompareResult:
        left_value: datetime.date = self._tease_property(left.tease)
        right_value: datetime.date = self._tease_property(right.tease)
        return _diff(left_value, right_value)

class TotmTagSortKey(SortKey):
    def __init__(self, name: str, description: str) -> None:
        self._name: str = name
        self._description = description

    def get_name(self) -> str:
        return self._name

    def get_description(self) -> str:
        return self._description

    def compare(self, left: query.TeaseMatch, right: query.TeaseMatch) -> CompareResult:
        left_value: int = left.tease.totm_status().value
        right_value: int = right.tease.totm_status().value
        return _diff(left_value, right_value)

class MatchCountSortKey(SortKey):
    def __init__(self, name: str, description: str) -> None:
        self._name: str = name
        self._description = description

    def get_name(self) -> str:
        return self._name

    def get_description(self) -> str:
        return self._description

    def compare(self, left: query.TeaseMatch, right: query.TeaseMatch) -> CompareResult:
        left_value: int = left.get_match_count()
        right_value: int = right.get_match_count()
        return _diff(left_value, right_value)

class OrderedSortKey(SortKey):
    def __init__(self, data_sort_key: SortKey, is_ascending: bool) -> None:
        self._data_sort_key: SortKey = data_sort_key
        self._is_ascending: bool = is_ascending

    def get_name(self) -> str:
        return self._data_sort_key.get_name()

    def get_description(self) -> str:
        return self._data_sort_key.get_description()

    def is_ascending(self) -> bool:
        return self._is_ascending

    def compare(self, left: query.TeaseMatch, right: query.TeaseMatch) -> CompareResult:
        compare_result: CompareResult = self._data_sort_key.compare(left, right)
        if self._is_ascending:
            return compare_result
        return compare_result.invert()

T = TypeVar("T", int, float, str, datetime.date)
def _diff(left: T, right: T) -> CompareResult:
    if left < right:
        return CompareResult.LEFT_IS_LESS
    if left > right:
        return CompareResult.LEFT_IS_MORE
    return CompareResult.BOTH_ARE_SAME

list_of_available_sort_keys: List[SortKey] = [
    IntegerFieldSortKey('teaseId', Tease.tease_id, 'Numerical id of the tease'),
    IntegerFieldSortKey('authorId', Tease.author_id, 'Numerical id of the author'),
    DateFieldSortKey('date', Tease.date, 'Published date of the tease'),
    StringFieldSortKey('title', Tease.title, 'Title of the tease'),
    FloatFieldSortKey('rating', Tease.rating_value, 'Value rating of the tease'),
    TeaseTypeSortKey('type', Tease.type, 'EOS, regular, audio, etc. tease type'),
    TotmTagSortKey('totm', 'Tease-Of-The-Month nominees and winners'),
    MatchCountSortKey('hits', 'Number of tease field matches from the last query')
]

default_sort_key: OrderedSortKey = OrderedSortKey(list_of_available_sort_keys[0], True)

default_list_of_active_sort_keys: List[OrderedSortKey] = [
    default_sort_key
]
