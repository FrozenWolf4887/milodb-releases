import datetime
import json
import lzma
from typing import Any, Dict, List, Optional
from milodb.database.tease import Tease
from milodb.print_timed_activity import PrintTimedActivity

def load_teases_from_database_file(database_filepath: str) -> List[Tease]:
    with PrintTimedActivity('Load database\n', 'Load completed: '):
        try:
            return _load_from_file(database_filepath)
        except _LoadError as ex:
            print(ex)
        return []

def try_get_oldest_tease_date(list_of_teases: List[Tease]) -> Optional[datetime.date]:
    oldest_tease_date: Optional[datetime.date] = None
    tease: Tease
    for tease in list_of_teases:
        if oldest_tease_date is not None:
            if tease.date() < oldest_tease_date:
                oldest_tease_date = tease.date()
        else:
            oldest_tease_date = tease.date()
    return oldest_tease_date

def try_get_newest_tease_date(list_of_teases: List[Tease]) -> Optional[datetime.date]:
    newest_tease_date: Optional[datetime.date] = None
    tease: Tease
    for tease in list_of_teases:
        if newest_tease_date is not None:
            if tease.date() > newest_tease_date:
                newest_tease_date = tease.date()
        else:
            newest_tease_date = tease.date()
    return newest_tease_date

def try_get_tease(tease_id: int, list_of_teases: List[Tease]) -> Optional[Tease]:
    tease: Tease
    for tease in list_of_teases:
        if tease_id == tease.tease_id():
            return tease
    return None

def get_teases_by_author_id(author_id: int, list_of_teases: List[Tease]) -> List[Tease]:
    return [ tease for tease in list_of_teases if author_id == tease.author_id() ]

class _LoadError(Exception):
    pass

def _load_from_file(database_filepath: str) -> List[Tease]:
    raw_file_contents: bytes = _read_file(database_filepath)
    file_contents: bytes = _unpack_contents(raw_file_contents)
    json_list: List[Any] = _parse_json(file_contents)
    return _build_tease_list(json_list)

def _read_file(database_filepath: str) -> bytes:
    with PrintTimedActivity('  Read', '     : '):
        try:
            with open(database_filepath, 'rb') as file:
                return file.read()
        except IOError as ex:
            raise _LoadError(f"\nFile access error: {ex}") from ex

def _unpack_contents(raw_file_contents: bytes) -> bytes:
    with PrintTimedActivity('  Unpack', '   : '):
        try:
            return lzma.decompress(raw_file_contents)
        except lzma.LZMAError as ex:
            raise _LoadError(f"\nUnpack error: {ex}") from ex

def _parse_json(file_contents: bytes) -> List[Any]:
    with PrintTimedActivity('  Parse', '    : '):
        try:
            json_root: Any = json.loads(file_contents)
        except json.JSONDecodeError as ex:
            raise _LoadError(f"\nJSON decode error: {ex}") from ex

        if not isinstance(json_root, list):
            raise _LoadError('\nAssembly error: Database root is not a list')

        json_list: List[Any] = json_root
        return json_list

def _build_tease_list(json_list: List[Any]) -> List[Tease]:
    list_of_teases: List[Tease] = []

    with PrintTimedActivity('  Assemble', ' : '):
        tease_obj: Any
        for tease_obj in json_list:
            tease_dict: Dict[Any, Any] = tease_obj
            try:
                tease: Tease = Tease(tease_dict)
            except Tease.LoadError as ex:
                raise _LoadError(f"\nTease error: {ex}") from ex
            list_of_teases.append(tease)

    return list_of_teases
