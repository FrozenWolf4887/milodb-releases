import datetime
import re
from dataclasses import dataclass
from typing import Callable, Dict, List, Optional, Pattern, Tuple, Type, TypeVar
from milodb.command_framework.ref_id import AuthorId, MatchIndex, RefId, TeaseId
from milodb.commands.enums import EnumEx
from milodb.parser.expanding_token_stream import ExpandingTokenStream
from milodb.parser.token import Token
from milodb.user_variables import VARIABLE_NAME_PATTERN

_DATE_FORMAT: str = 'yyyy-mm-dd'
_MSG_INSUFFICIENT_PARAMETERS: str = 'Insufficient parameters'

ArgumentT = TypeVar('ArgumentT')
T = TypeVar("T")
E = TypeVar("E", bound=EnumEx)

@dataclass
class ArgumentStreamError(Exception):
    message: str
    fault_token: Optional[Token]
    list_of_expected_text: List[str]

class ArgumentStream:
    def __init__(self, token_stream: ExpandingTokenStream) -> None:
        self._token_stream: ExpandingTokenStream = token_stream

    def disable_expansion(self) -> None:
        self._token_stream.disable_expansion()

    def get_remaining_raw_text(self) -> str:
        return self._token_stream.get_remaining_raw_text()

    def get_expanded_raw_text(self) -> str:
        return self._token_stream.get_expanded_raw_text()

    @staticmethod
    def pop_list(pop_optional_handler: Callable[[], Optional[ArgumentT]]) -> List[ArgumentT]:
        list_of_arguments: List[ArgumentT] = []

        end_of_input: bool = False
        while not end_of_input:
            argument: Optional[ArgumentT] = pop_optional_handler()
            if argument:
                list_of_arguments.append(argument)
            else:
                end_of_input = True

        return list_of_arguments

    @staticmethod
    def pop_minimum_list(minimum_number: int, pop_handler: Callable[[], ArgumentT], pop_optional_handler: Callable[[], Optional[ArgumentT]]) -> List[ArgumentT]:
        list_of_arguments: List[ArgumentT] = []

        for _ in range(minimum_number):
            list_of_arguments.append(pop_handler())
        list_of_arguments.extend(ArgumentStream.pop_list(pop_optional_handler))
        return list_of_arguments

    @staticmethod
    def for_each(pop_optional_handler: Callable[[], Optional[ArgumentT]], argument_handler: Callable[[ArgumentT], None]) -> None:
        end_of_input: bool = False
        while not end_of_input:
            argument: Optional[ArgumentT] = pop_optional_handler()
            if argument:
                argument_handler(argument)
            else:
                end_of_input = True

    def pop_token(self) -> Token:
        token: Optional[Token] = self._token_stream.next()
        if token:
            return token
        raise ArgumentStreamError(
            message = _MSG_INSUFFICIENT_PARAMETERS,
            fault_token = None,
            list_of_expected_text = [])

    def pop_optional_token(self) -> Optional[Token]:
        return self._token_stream.next()

    def pop_optional_ref_id(self) -> Optional[RefId]:
        ref_id: Optional[RefId] = None
        token: Optional[Token] = self._token_stream.next()
        if token:
            value: int
            if token.text.startswith('#'):
                value = _parse_uint(token, token.text[1:], 'TeaseId is not a positive integer')
                ref_id = TeaseId(value)
            elif token.text.startswith('@'):
                value = _parse_uint(token, token.text[1:], 'AuthorId is not a positive integer')
                ref_id = AuthorId(value)
            elif token.text[0:1].isdigit():
                value = _parse_uint(token, token.text, 'Match index is not a positive integer')
                ref_id = MatchIndex(value)
            else:
                raise ArgumentStreamError(
                    message = "Invalid RefId. Expecting 'value', '#value', or '@value'",
                    fault_token = token,
                    list_of_expected_text = [])

        return ref_id

    def pop_ref_id(self) -> RefId:
        ref_id: Optional[RefId] = self.pop_optional_ref_id()
        if ref_id is None:
            raise ArgumentStreamError(
                message = f'{_MSG_INSUFFICIENT_PARAMETERS}. Expecting a RefId',
                fault_token = None,
                list_of_expected_text = [])
        return ref_id

    def pop_dict_value(self, dictionary: Dict[str, T]) -> T:
        value: Optional[T] = self.pop_optional_dict_value(dictionary)
        if value is None:
            list_of_keys = list(dictionary.keys())
            raise ArgumentStreamError(
                message = _MSG_INSUFFICIENT_PARAMETERS,
                fault_token = None,
                list_of_expected_text = list_of_keys)
        return value

    def pop_optional_dict_value(self, dictionary: Dict[str, T]) -> Optional[T]:
        value_and_token: Optional[Tuple[T, Token]] = self.pop_optional_dict_value_and_token(dictionary)
        if value_and_token:
            return value_and_token[0]
        return None

    def pop_optional_dict_value_and_token(self, dictionary: Dict[str, T]) -> Optional[Tuple[T, Token]]:
        token: Optional[Token] = self._token_stream.next()
        if token:
            try:
                return dictionary[token.text], token
            except KeyError as ex:
                list_of_keys = list(dictionary.keys())
                raise ArgumentStreamError(
                    message = 'Invalid parameter',
                    fault_token = token,
                    list_of_expected_text = list_of_keys) from ex
        return None

    def pop_enum(self, enum_class: Type[E]) -> E:
        enum: Optional[E] = self.pop_optional_enum(enum_class)
        if enum:
            return enum
        raise ArgumentStreamError(
            message = _MSG_INSUFFICIENT_PARAMETERS,
            fault_token = None,
            list_of_expected_text = enum_class.lowercase_names())

    def pop_optional_enum(self, enum_class: Type[E]) -> Optional[E]:
        enum_and_token: Optional[Tuple[E, Token]] = self.pop_optional_enum_and_token(enum_class)
        if enum_and_token:
            return enum_and_token[0]
        return None

    def pop_optional_enum_and_token(self, enum_class: Type[E]) -> Optional[Tuple[E, Token]]:
        token: Optional[Token] = self._token_stream.next()
        if token:
            try:
                return enum_class[token.text.upper()], token
            except KeyError as ex:
                raise ArgumentStreamError(
                    message = 'Unknown keyword or value',
                    fault_token = token,
                    list_of_expected_text = enum_class.lowercase_names()) from ex
        return None

    def pop_enum_by_value(self, enum_class: Type[E]) -> E:
        enum: Optional[E] = self.pop_optional_enum_by_value(enum_class)
        if enum:
            return enum
        raise ArgumentStreamError(
            message = _MSG_INSUFFICIENT_PARAMETERS,
            fault_token = None,
            list_of_expected_text = enum_class.values())

    def pop_optional_enum_by_value(self, enum_class: Type[E]) -> Optional[E]:
        enum_and_token: Optional[Tuple[E, Token]] = self.pop_optional_enum_and_token_by_value(enum_class)
        if enum_and_token:
            return enum_and_token[0]
        return None

    def pop_optional_enum_and_token_by_value(self, enum_class: Type[E]) -> Optional[Tuple[E, Token]]:
        token: Optional[Token] = self._token_stream.next()
        if token:
            try:
                return enum_class(token.text), token
            except ValueError as ex:
                raise ArgumentStreamError(
                    message = 'Unknown keyword or value',
                    fault_token = token,
                    list_of_expected_text = enum_class.values()) from ex
        return None

    def pop_variable_name(self, list_of_variable_names: List[str]) -> str:
        variable_name: Optional[str] = self.pop_optional_variable_name(list_of_variable_names)
        if not variable_name:
            raise ArgumentStreamError(
                message = f'{_MSG_INSUFFICIENT_PARAMETERS}. Expecting a variable name',
                fault_token = None,
                list_of_expected_text = list_of_variable_names)
        return variable_name

    def pop_optional_variable_name(self, list_of_variable_names: List[str]) -> Optional[str]:
        token: Optional[Token] = self._token_stream.next()
        if token:
            if VARIABLE_NAME_PATTERN.fullmatch(token.text):
                return token.text
            raise ArgumentStreamError(
                message = f"Variable name '{token.text}' does not match pattern '{VARIABLE_NAME_PATTERN.pattern}'",
                fault_token = token,
                list_of_expected_text = list_of_variable_names)
        return None

    def pop_date(self) -> datetime.date:
        date: Optional[datetime.date] = self.pop_optional_date()
        if date:
            return date
        raise ArgumentStreamError(
            message = f'{_MSG_INSUFFICIENT_PARAMETERS}. Expecting a date',
            fault_token = None,
            list_of_expected_text = [])

    def pop_optional_date(self) -> Optional[datetime.date]:
        token: Optional[Token] = self._token_stream.next()
        if token:
            try:
                return datetime.date.fromisoformat(token.text)
            except ValueError as ex:
                raise ArgumentStreamError(
                    message = f"Invalid date. Expected format '{_DATE_FORMAT}'",
                    fault_token = token,
                    list_of_expected_text = []) from ex
        return None

    def pop_optional_fixed_text(self, expected_text: str) -> bool:
        token: Optional[Token] = self._token_stream.next()
        if token:
            if token.text != expected_text:
                raise ArgumentStreamError(
                    message = f"Expecting fixed text '{expected_text}'",
                    fault_token = token,
                    list_of_expected_text = [expected_text])
            return True
        return False

    def pop_int(self) -> int:
        value: Optional[int] = self.pop_optional_int()
        if value is not None:
            return value
        raise ArgumentStreamError(
            message = f'{_MSG_INSUFFICIENT_PARAMETERS}. Expecting an integer value',
            fault_token = None,
            list_of_expected_text = [])

    def pop_optional_int(self) -> Optional[int]:
        token: Optional[Token] = self._token_stream.next()
        if token:
            return _parse_int(token, token.text, 'Expecting an integer value')
        return None

    def pop_uint(self) -> int:
        value: Optional[int] = self.pop_optional_uint()
        if value is not None:
            return value
        raise ArgumentStreamError(
            message = f'{_MSG_INSUFFICIENT_PARAMETERS}. Expecting an unsigned integer value',
            fault_token = None,
            list_of_expected_text = [])

    def pop_optional_uint(self) -> Optional[int]:
        token: Optional[Token] = self._token_stream.next()
        if token:
            return _parse_uint(token, token.text, 'Expecting an unsigned integer value')
        return None

    def pop_float(self) -> float:
        value: Optional[float] = self.pop_optional_float()
        if value is not None:
            return value
        raise ArgumentStreamError(
            message = f'{_MSG_INSUFFICIENT_PARAMETERS}. Expecting an integer or decimal value',
            fault_token = None,
            list_of_expected_text = [])

    def pop_optional_float(self) -> Optional[float]:
        token: Optional[Token] = self._token_stream.next()
        if token:
            return _parse_float(token, token.text, 'Expecting an integer or decimal value')
        return None

    def pop_ufloat(self) -> float:
        value: Optional[float] = self.pop_optional_ufloat()
        if value is not None:
            return value
        raise ArgumentStreamError(
            message = f'{_MSG_INSUFFICIENT_PARAMETERS}. Expecting an unsigned integer or decimal value',
            fault_token = None,
            list_of_expected_text = [])

    def pop_optional_ufloat(self) -> Optional[float]:
        token: Optional[Token] = self._token_stream.next()
        if token:
            return _parse_ufloat(token, token.text, 'Expecting an unsigned integer or decimal value')
        return None

    def pop_text(self) -> str:
        token: Optional[Token] = self._token_stream.next()
        if token:
            return token.text
        raise ArgumentStreamError(
            message = f'{_MSG_INSUFFICIENT_PARAMETERS}. Expecting some text',
            fault_token = None,
            list_of_expected_text = [])

    def pop_optional_text(self) -> Optional[str]:
        token: Optional[Token] = self._token_stream.next()
        if token:
            return token.text
        return None

    def pop_regex(self, flags: int) -> Pattern[str]:
        pattern: Optional[Pattern[str]] = self.pop_optional_regex(flags)
        if pattern:
            return pattern
        raise ArgumentStreamError(
            message = f'{_MSG_INSUFFICIENT_PARAMETERS}. Expecting a regular expression',
            fault_token = None,
            list_of_expected_text = [])

    def pop_optional_regex(self, flags: int) -> Optional[Pattern[str]]:
        token: Optional[Token] = self._token_stream.next()
        if token:
            try:
                return re.compile(token.text, flags)
            except re.error as ex:
                raise ArgumentStreamError(
                    message = f"Invalid regular expression: {ex}",
                    fault_token = token,
                    list_of_expected_text = []) from ex
        return None

    def fail_if_not_empty(self) -> None:
        token: Optional[Token] = self._token_stream.next()
        if token is not None:
            raise ArgumentStreamError(
                message = 'Unexpected additional parameter',
                fault_token = token,
                list_of_expected_text = [])

def _parse_int(token: Token, text: str, error_text: str) -> int:
    try:
        return int(text)
    except ValueError as ex:
        raise ArgumentStreamError(
            message = error_text,
            fault_token = token,
            list_of_expected_text = []) from ex

def _parse_uint(token: Token, text: str, error_text: str) -> int:
    value: int = _parse_int(token, text, error_text)
    if value < 0:
        raise ArgumentStreamError(
            message = error_text,
            fault_token = token,
            list_of_expected_text = [])
    return value

def _parse_float(token: Token, text: str, error_text: str) -> float:
    try:
        return float(text)
    except ValueError as ex:
        raise ArgumentStreamError(
            message = error_text,
            fault_token = token,
            list_of_expected_text = []) from ex

def _parse_ufloat(token: Token, text: str, error_text: str) -> float:
    value: float = _parse_float(token, text, error_text)
    if value < 0:
        raise ArgumentStreamError(
            message = error_text,
            fault_token = token,
            list_of_expected_text = [])
    return value
