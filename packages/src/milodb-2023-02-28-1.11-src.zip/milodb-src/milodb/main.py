import datetime
from typing import List, Optional
from milodb.command_framework.quit_flag import QuitFlag
from milodb.commands.command_context import CommandContext
from milodb.commands.command_factory import CommandFactory
from milodb.commands.database_stats import DatabaseStats
from milodb.commands.sort_keys import default_list_of_active_sort_keys, list_of_available_sort_keys
from milodb.config.ansi_config import AnsiConfig
from milodb.config.bbcode_config import BBCodeConfig
from milodb.config.config_schema import ConfigSchema
from milodb.config.framework import IConfig
from milodb.config.html_config import HtmlConfig
from milodb.config.json_config_file import JsonConfigFile
from milodb.config.session_config import SessionConfig
from milodb.database.database import load_teases_from_database_file, try_get_newest_tease_date, try_get_oldest_tease_date
from milodb.database.tease import Tease
from milodb.input.autoexec import run_autoexec
from milodb.input.prompt import run_interactive_prompt
from milodb.output.ansi import AnsiOutputter
from milodb.output.bbcode import BBCodeOutputter
from milodb.output.html import HtmlOutputter
from milodb.output.output_sink import ErrorOutputWriter, OutputSink, WarningOutputWriter
from milodb.output.outputter import Outputter
from milodb.output.plain import PlainOutputter
from milodb.output.stdout_output_sink import StdoutOutputSink
from milodb.user_variables import UserVariables
from milodb.version import MILODB_DATE, MILODB_VERSION

DATABASE_FILENAME: str = 'database.mdb'
CONFIG_FILENAME: str = 'config.json'
VARIABLES_FILENAME: str = 'variables.json'
AUTOEXEC_FILENAME: str = 'autoexec.txt'

class Main:
    def __init__(self) -> None:
        print(f'Milovana Database {MILODB_VERSION or "(Development)"}, {MILODB_DATE or "(Undated)"}')

        output_sink: OutputSink = StdoutOutputSink()
        session_config: SessionConfig = SessionConfig(output_sink, ErrorOutputWriter(output_sink), WarningOutputWriter(output_sink))
        system_config: IConfig = JsonConfigFile(CONFIG_FILENAME, ConfigSchema.root)
        user_variables: UserVariables = UserVariables(VARIABLES_FILENAME)
        plain_outputter: Outputter = PlainOutputter(session_config)
        ansi_outputter: Outputter = AnsiOutputter(AnsiConfig(system_config), session_config)
        bbcode_outputter: Outputter = BBCodeOutputter(BBCodeConfig(system_config), session_config)
        html_outputter: Outputter = HtmlOutputter(HtmlConfig(system_config), session_config)
        list_of_outputters: List[Outputter] = [plain_outputter, ansi_outputter, bbcode_outputter, html_outputter]
        command_factory: CommandFactory = CommandFactory()
        quit_flag: QuitFlag = QuitFlag()

        list_of_teases: List[Tease] = load_teases_from_database_file(DATABASE_FILENAME)
        oldest_tease_date: Optional[datetime.date] = try_get_oldest_tease_date(list_of_teases)
        newest_tease_date: Optional[datetime.date] = try_get_newest_tease_date(list_of_teases)
        print(f"{len(list_of_teases):,} teases loaded ranging from {oldest_tease_date or 'None'} to {newest_tease_date or 'None'}\n")

        database_stats: DatabaseStats = DatabaseStats(list_of_teases)

        self._context = CommandContext(
            quit_flag = quit_flag,
            command_factory = command_factory,
            session_config = session_config,
            system_config = system_config,
            user_variables = user_variables,
            database_stats = database_stats,
            list_of_teases = list_of_teases,
            list_of_tease_matches = [],
            list_of_available_sort_keys = list_of_available_sort_keys,
            list_of_active_sort_keys = default_list_of_active_sort_keys,
            list_of_outputters = list_of_outputters,
            current_outputter = ansi_outputter)

        command_factory.set_command_context(self._context)

    def run(self) -> None:
        run_autoexec(AUTOEXEC_FILENAME, self._context.command_factory, self._context.user_variables, self._context.quit_flag)
        if not self._context.quit_flag:
            run_interactive_prompt(self._context.command_factory, self._context.user_variables,self._context.session_config.default_input_text,self._context.quit_flag)
