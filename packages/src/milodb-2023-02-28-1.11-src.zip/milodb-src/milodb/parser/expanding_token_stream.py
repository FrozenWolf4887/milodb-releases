from dataclasses import dataclass
from typing import List, Optional
from milodb.parser.token import StartEnd, Token
from milodb.parser.token_stream import TokenStream, TokenStreamError
from milodb.user_variables import UserVariables, VARIABLE_FULL_NAME_PATTERN

@dataclass
class _ActiveStream:
    variable_token: Optional[Token]
    token_stream: TokenStream
    begin_expansion_char_index: int = 0
    last_expanded_end_char_index: int = 0

@dataclass
class ExpandedToken(Token):
    original_token: Token
    variable_depth: int

class ExpandingTokenStream:
    def __init__(self, text: str, variables: UserVariables, stop_before_character_index: Optional[int] = None) -> None:
        self._variables: UserVariables = variables
        self._stop_before_character_index: Optional[int] = stop_before_character_index

        self._stack_of_active_streams: List[_ActiveStream] = [_ActiveStream(None, TokenStream(text))]
        self._is_expansion_enabled = True
        self._token_number: int = 0
        self._offset_character_index: int = 0
        self._expanded_text: str = ''
        self._stopped_on_token: Optional[ExpandedToken] = None

    def next(self) -> Optional[Token]:
        token: Optional[Token] = None

        while token is None and not self._stopped_on_token and self._stack_of_active_streams:
            token = self._load_next_token()

        if token:
            token = self._convert_to_expanded_token(token)
            self._token_number += 1

        return token

    def get_remaining_raw_text(self) -> str:
        text: str = ''
        active_stream: _ActiveStream

        if self._stopped_on_token:
            active_stream = self._stack_of_active_streams[-1]
            text = active_stream.token_stream.get_all_text()[active_stream.last_expanded_end_char_index:self._stopped_on_token.original_token.outer_indices.end]

        for active_stream in reversed(self._stack_of_active_streams):
            text += active_stream.token_stream.get_remaining_raw_text()

        return text

    def get_expanded_raw_text(self) -> str:
        return self._expanded_text

    def disable_expansion(self) -> None:
        self._is_expansion_enabled = False

    def is_expansion_enabled(self) -> bool:
        return self._is_expansion_enabled

    def get_stopped_on_token(self) -> Optional[ExpandedToken]:
        return self._stopped_on_token

    def _load_next_token(self) -> Optional[Token]:
        token: Optional[Token] = None

        active_stream: _ActiveStream = self._stack_of_active_streams[-1]

        try:
            token = active_stream.token_stream.next()
        except TokenStreamError as ex:
            ex.cause_of_fault_character_index += self._offset_character_index
            if ex.cause_of_fault_token:
                ex.cause_of_fault_token = self._convert_to_expanded_token(ex.cause_of_fault_token)
            raise ex

        if token:
            if (self._stop_before_character_index is not None) and (token.outer_indices.end + self._offset_character_index >= self._stop_before_character_index):
                self._stopped_on_token = self._convert_to_expanded_token(token)
                token = None
            elif self._try_expand_token(token):
                self._expanded_text += active_stream.token_stream.get_all_text()[active_stream.last_expanded_end_char_index:token.outer_indices.start]
                active_stream.last_expanded_end_char_index = token.outer_indices.end
                token = None
            else:
                self._expanded_text += active_stream.token_stream.get_all_text()[active_stream.last_expanded_end_char_index:token.outer_indices.end]
                active_stream.last_expanded_end_char_index = token.outer_indices.end
        else:
            self._expanded_text += active_stream.token_stream.get_all_text()[active_stream.last_expanded_end_char_index:]
            self._pop_active_stream()

        return token

    def _try_expand_token(self, token: Token) -> bool:
        did_expand: bool = False

        if self._is_expansion_enabled and token.text.startswith('$') and not token.text.startswith('$$'):
            if VARIABLE_FULL_NAME_PATTERN.fullmatch(token.text):
                self._check_for_recursive_variable_reference(token)
                self._handle_variable_expansion(token)
                did_expand = True
            else:
                list_of_variables: List[str] = [f'${variable_name}' for variable_name in self._variables.get_list_of_names()]
                active_stream: _ActiveStream = self._stack_of_active_streams[-1]
                self._expanded_text += active_stream.token_stream.get_all_text()[active_stream.last_expanded_end_char_index:token.outer_indices.end]
                raise TokenStreamError(
                    f"Invalid variable reference '{token.text}' does not match pattern '{VARIABLE_FULL_NAME_PATTERN.pattern}'",
                    token.inner_indices.start + self._offset_character_index,
                    self._convert_to_expanded_token(token),
                    list_of_variables)

        return did_expand

    def _check_for_recursive_variable_reference(self, token: Token) -> None:
        active_stream: _ActiveStream
        for active_stream in self._stack_of_active_streams:
            if active_stream.variable_token and token.text == active_stream.variable_token.text:
                variable_chain: List[str] = [f"'{entry.variable_token.text}'" for entry in self._stack_of_active_streams if entry.variable_token] + [f"'{token.text}'"]
                self._expanded_text += active_stream.token_stream.get_all_text()[active_stream.last_expanded_end_char_index:token.outer_indices.end]
                raise TokenStreamError(
                    f"Recursive variable reference detected: {' -> '.join(variable_chain)}",
                    token.inner_indices.start + self._offset_character_index,
                    self._convert_to_expanded_token(token))

    def _handle_variable_expansion(self, token: Token) -> None:
        variable_name: str = token.text[1:]
        variable_value: Optional[str] = self._variables.try_retrieve(variable_name)
        if variable_value is not None:
            self._stack_of_active_streams.append(_ActiveStream(token, TokenStream(variable_value)))
            self._offset_character_index += token.outer_indices.start
            if self._stop_before_character_index is not None and self._stop_before_character_index >= token.outer_indices.start:
                self._stop_before_character_index -= (token.outer_indices.end - token.outer_indices.start)
                self._stop_before_character_index += len(variable_value)
        else:
            list_of_variables: List[str] = [f'${variable_name}' for variable_name in self._variables.get_list_of_names()]
            active_stream: _ActiveStream = self._stack_of_active_streams[-1]
            self._expanded_text += active_stream.token_stream.get_all_text()[active_stream.last_expanded_end_char_index:token.outer_indices.end]
            raise TokenStreamError(
                f"Unknown variable reference '${variable_name}'",
                token.inner_indices.start + self._offset_character_index,
                self._convert_to_expanded_token(token),
                list_of_variables)

    def _pop_active_stream(self) -> None:
        active_stream: _ActiveStream = self._stack_of_active_streams[-1]

        self._offset_character_index += len(active_stream.token_stream.get_all_text())
        variable_token: Optional[Token] = active_stream.variable_token
        if variable_token:
            self._offset_character_index -= variable_token.outer_indices.end

        self._stack_of_active_streams.pop()

    def _convert_to_expanded_token(self, token: Token) -> ExpandedToken:
        return ExpandedToken(
            token.text,
            self._token_number,
            StartEnd(token.outer_indices.start + self._offset_character_index, token.outer_indices.end + self._offset_character_index),
            StartEnd(token.inner_indices.start + self._offset_character_index, token.inner_indices.end + self._offset_character_index),
            token,
            len(self._stack_of_active_streams) - 1)
