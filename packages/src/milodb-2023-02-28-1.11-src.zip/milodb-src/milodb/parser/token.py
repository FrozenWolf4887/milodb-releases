from dataclasses import dataclass

@dataclass
class StartEnd:
    start: int
    end: int

@dataclass
class Token:
    text: str
    token_number: int
    outer_indices: StartEnd
    inner_indices: StartEnd
