# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from abc import abstractmethod
from milodb.command_framework.argument_stream import ArgumentStream
from milodb.command_framework.i_command import ICommand
from milodb.command_framework.i_help_info import IHelpInfo
from milodb.command_framework.ref_id import RefId
from milodb.commands.database_support import try_create_list_of_tease_matches_from_ref_ids
from milodb.database.tease import Tease
from milodb.output.format.i_formatter import IFormatter
from milodb.output.print.i_printer import IPrinter
from milodb.query.tease_match import TeaseMatch

class _ShowCommandCommon(ICommand):
    def __init__(self, list_of_teases: list[Tease], list_of_tease_matches: list[TeaseMatch], formatter: IFormatter, use_highlighting: bool, show_pagerefs: bool, normal_printer: IPrinter, error_printer: IPrinter) -> None:
        self._list_of_teases: list[Tease] = list_of_teases
        self._list_of_tease_matches: list[TeaseMatch] = list_of_tease_matches
        self._formatter: IFormatter = formatter
        self._use_highlighting: bool = use_highlighting
        self._show_pagerefs: bool = show_pagerefs
        self._normal_printer: IPrinter = normal_printer
        self._error_printer: IPrinter = error_printer
        self._list_of_ref_ids: list[RefId] = []

    def load(self, argument_stream: ArgumentStream) -> list[str]:
        self._list_of_ref_ids = ArgumentStream.pop_list(argument_stream.pop_optional_ref_id)
        return []

    def execute(self) -> None:
        list_of_tease_matches: (list[TeaseMatch] | None) = None
        if self._list_of_ref_ids:
            list_of_tease_matches = try_create_list_of_tease_matches_from_ref_ids(self._list_of_teases, self._list_of_tease_matches, self._list_of_ref_ids, self._error_printer)
        else:
            list_of_tease_matches = self._list_of_tease_matches

        if list_of_tease_matches:
            self._print_from_list(list_of_tease_matches)
        else:
            self._error_printer.writeln("No teases available to show")

    @abstractmethod
    def _print_from_list(self, list_of_tease_matches: list[TeaseMatch]) -> None:
        pass

class ShowCommand(_ShowCommandCommon):
    def __init__(self, list_of_teases: list[Tease], list_of_tease_matches: list[TeaseMatch], formatter: IFormatter, use_highlighting: bool, use_ellipsis: bool, ellipsis_max_width: int, show_pagerefs: bool, normal_printer: IPrinter, error_printer: IPrinter) -> None:
        super().__init__(list_of_teases, list_of_tease_matches, formatter, use_highlighting, show_pagerefs, normal_printer, error_printer)
        self._use_ellipsis: bool = use_ellipsis
        self._ellipsis_max_width: int = ellipsis_max_width

    def _print_from_list(self, list_of_tease_matches: list[TeaseMatch]) -> None:
        self._formatter.print_matching_text_of_list_of_teases(list_of_tease_matches, self._use_highlighting, self._ellipsis_max_width if self._use_ellipsis else None, self._show_pagerefs, self._normal_printer)

    class Help(IHelpInfo):
        def get_one_line_summary(self) -> str:
            return "Prints the summary and text matches for the current results"

        def get_detailed_summary(self) -> str:
            return (
                "Arguments: [list of RefIds]\n"
                "Shows details for each tease including the matching text paragraphs if"
                " appropriate. The formatting used for the details can be controlled with the "
                " format command.\n"
                "When used without arguments, all teases that were found from the last query are"
                " included. When one or more RefIds are specified, only those teases are included.\n"
                "RefIds can be an index into the list of matches such as '3', a teaseId such as"
                " '#38664', or an authorId such as '@43937'.\n"
                "Matching fields and text may be highlighted which can be controlled with the"
                " highlight command.\n"
                "The text paragraphs may be abbreviated with an ellipsis which can be controlled"
                " with the ellipsis command.\n"
                "Example:\r"
                "  \tShow details of the last query results\r"
                "  > \tshow\r"
                "Example:\r"
                "  \tShow details of some matched teases by index\r"
                "  > \tshow 3 7\r"
                "Example:\r"
                "  \tShow details of some specific teaseIds\r"
                "  > \tshow #16830 #1465 #38664\r"
                "Example:\r"
                "  \tShow details of teases from a specific authorId\r"
                "  > \tshow @43937\n"
                "See also:\r"
                "  \tshowall, summary, format, ellipsis, highlight\n"
            )

class ShowAllCommand(_ShowCommandCommon):
    def _print_from_list(self, list_of_tease_matches: list[TeaseMatch]) -> None:
        self._formatter.print_all_text_of_list_of_teases(list_of_tease_matches, self._use_highlighting, self._show_pagerefs, self._normal_printer)

    class Help(IHelpInfo):
        def get_one_line_summary(self) -> str:
            return "Prints the summary and all text paragraphs for the current results"

        def get_detailed_summary(self) -> str:
            return (
                "Arguments: [list of RefIds]\n"
                "Shows details for each tease with all text paragraphs. The formatting used for the"
                " details can be controlled with the format command.\n"
                "When used without arguments, all teases that were found from the last query are"
                " included. When one or more RefIds are specified, only those teases are included.\n"
                "RefIds can be an index into the list of matches such as '3', a teaseId such as"
                " '#38664', or an authorId such as '@43937'.\n"
                "Matching fields and text may be highlighted which can be controlled with the"
                " highlight command.\n"
                "The ellipsis setting is ignored with this command so that all of the text is"
                " shown regardless of whether it matched or not.\n"
                "Example:\r"
                "  \tShow details of the last query results\r"
                "  > \tshowall\r"
                "Example:\r"
                "  \tShow details of some matched teases by index\r"
                "  > \tshowall 3 7\r"
                "Example:\r"
                "  \tShow details of some specific teaseIds\r"
                "  > \tshowall #16830 #1465 #38664\r"
                "Example:\r"
                "  \tShow details of teases from a specific authorId\r"
                "  > \tshowall @43937\n"
                "See also:\r"
                "  \tshow, summary, format, ellipsis, highlight\n"
            )
