# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from collections.abc import Callable
from milodb.command_framework.argument_stream import ArgumentStream
from milodb.command_framework.i_command import CommandLoadError, ICommand
from milodb.command_framework.i_help_info import IHelpInfo
from milodb.config.config_schema import CONFIG_SCHEMA
from milodb.config.framework import IConfig, IConfigGroup, IConfigLeaf
from milodb.output.print.i_printer import IPrinter
from milodb.parser.token import Token

class ConfigCommand(ICommand):
    def __init__(self, config: IConfig, normal_printer: IPrinter) -> None:
        self._config: IConfig = config
        self._normal_printer: IPrinter = normal_printer
        self._subcommand: ICommand | None = None

    def load(self, argument_stream: ArgumentStream) -> list[str]:
        map_of_action_to_subcommand_creator: dict[str, Callable[[], ICommand]] = {
            'get': lambda: _GetSubcommand(self._config, self._normal_printer)
        }
        self._subcommand = argument_stream.pop_dict_value(map_of_action_to_subcommand_creator)()
        return self._subcommand.load(argument_stream)

    def execute(self) -> None:
        if self._subcommand:
            self._subcommand.execute()

    class Help(IHelpInfo):
        def get_one_line_summary(self) -> str:
            return "Views and edits configuration"

        def get_detailed_summary(self) -> str:
            return (
                "Arguments: get <path to config item>\n"
            )

class _GetSubcommand(ICommand):
    def __init__(self, config: IConfig, normal_printer: IPrinter) -> None:
        self._config: IConfig = config
        self._normal_printer: IPrinter = normal_printer
        self._current_group: IConfigGroup = CONFIG_SCHEMA
        self._leaf_to_print: IConfigLeaf | None = None

    def load(self, argument_stream: ArgumentStream) -> list[str]:
        argument_stream.for_each(argument_stream.pop_optional_token, self.seek)
        argument_stream.fail_if_not_empty()
        if self._leaf_to_print:
            return []
        return list(self._current_group.list_of_child_names)

    def seek(self, token: Token) -> bool:
        name_of_group_or_leaf: str = token.text
        leaf: IConfigLeaf | None = self._current_group.try_find_child_leaf(name_of_group_or_leaf)
        if leaf:
            self._leaf_to_print = leaf
            return False
        group: IConfigGroup | None = self._current_group.try_find_child_group(name_of_group_or_leaf)
        if group:
            self._current_group = group
        else:
            raise CommandLoadError(
                f"Unrecognised config group or leaf '{name_of_group_or_leaf}' within '{self._current_group.full_path}'",
                token,
                list(self._current_group.list_of_child_names))
        return True

    def execute(self) -> None:
        self.print_item(self._current_group, self._leaf_to_print)

    def print_item(self, group: IConfigGroup, leaf: IConfigLeaf | None) -> None:
        if leaf:
            self._normal_printer.writeln(f" Leaf: {leaf.full_path} = '{leaf.fetch_value_or_default(self._config)}'")
        else:
            self._normal_printer.writeln(f'Group: {group.full_path}')
            child_leaf: IConfigLeaf
            for child_leaf in group.list_of_child_leaves:
                self.print_item(group, child_leaf)
            child_group: IConfigGroup
            for child_group in group.list_of_child_groups:
                self.print_item(child_group, None)
