# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from abc import ABC, abstractmethod
from milodb.config.config_schema import CONFIG_SCHEMA, CommandLaunchOption
from milodb.config.framework import IConfig

class ILaunchConfig(ABC):
    @property
    @abstractmethod
    def launch_option(self) -> CommandLaunchOption:
        pass

    @property
    @abstractmethod
    def custom_launch_command(self) -> str:
        pass

class CommandBrowseLaunchConfig(ILaunchConfig):
    def __init__(self, config: IConfig) -> None:
        self._config = config

    @property
    def launch_option(self) -> CommandLaunchOption:
        return CONFIG_SCHEMA.commands.browse.launch_option.fetch_enum_value_or_default(self._config)

    @property
    def custom_launch_command(self) -> str:
        return CONFIG_SCHEMA.commands.browse.custom_launch_command.fetch_value_or_default(self._config)

class CommandOpenLaunchConfig(ILaunchConfig):
    def __init__(self, config: IConfig) -> None:
        self._config = config

    @property
    def launch_option(self) -> CommandLaunchOption:
        return CONFIG_SCHEMA.commands.open.launch_option.fetch_enum_value_or_default(self._config)

    @property
    def custom_launch_command(self) -> str:
        return CONFIG_SCHEMA.commands.open.custom_launch_command.fetch_value_or_default(self._config)
