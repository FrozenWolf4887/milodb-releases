# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
MILODB_VERSION: str | None = '1.15'
MILODB_DATE: str | None = '2023-06-30'
