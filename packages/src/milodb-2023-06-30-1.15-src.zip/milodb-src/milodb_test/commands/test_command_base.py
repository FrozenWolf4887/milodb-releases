# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
import re
from abc import ABC, abstractmethod
from typing import Any
from unittest import TestCase
from unittest.mock import Mock
from milodb.command_framework.argument_stream import ArgumentStream, ArgumentStreamError
from milodb.command_framework.i_command import CommandLoadError, ICommand
from milodb.command_framework.i_command_loader import CommandLoadDelegateError
from milodb.database.tease import Tease
from milodb.parser.expanding_token_stream import ExpandingTokenStream
from milodb.parser.token import StartEnd, Token
from milodb.query.field_match import FieldItemMatch, FieldListMatch, FieldPageListMatch, IFieldMatch
from milodb.query.tease_match import TeaseMatch

_SET_OF_QUOTE_CHARS: set[str] = {'"', "'"}

def create_fake_tokens(list_of_token_text: list[str]) -> list[(Token | None)]:
    list_of_tokens: list[(Token | None)] = []
    token_number: int = 1
    token_start_index: int = 0
    for token_text in list_of_token_text:
        token_end_index: int = token_start_index + len(token_text)
        outer_indices: StartEnd = StartEnd(token_start_index, token_end_index)
        inner_indices: StartEnd = StartEnd(token_start_index, token_end_index)
        if token_text and token_text[0] in _SET_OF_QUOTE_CHARS:
            inner_indices.start += 1
            inner_indices.end -= 1
        list_of_tokens.append(Token(token_text, token_number, outer_indices, inner_indices))
        token_start_index = token_end_index + 1
        token_number += 1
    list_of_tokens.append(None)
    return list_of_tokens

class NonIndexedTeaseMatch:
    def __init__(self, expected_tease: Tease):
        self._expected_tease: Tease = expected_tease

    def __eq__(self, other: object) -> bool:
        return isinstance(other, TeaseMatch) and other.index_of_match is None and len(other.list_of_field_matches) == 0 and other.tease == self._expected_tease

    def __hash__(self) -> int:
        return hash(self._expected_tease)

    def __repr__(self) -> str:
        return f"TeaseMatch(None, {self._expected_tease}, [])"

class RegexStringMatch:
    def __init__(self, expected_pattern: (re.Pattern[str] | str), flags: int = 0):
        if isinstance(expected_pattern, str):
            expected_pattern = re.compile(expected_pattern, flags=flags)
        self._expected_pattern: re.Pattern[str] = expected_pattern

    def __eq__(self, other: object) -> bool:
        return isinstance(other, str) and self._expected_pattern.fullmatch(other) is not None

    def __hash__(self) -> int:
        return hash(self._expected_pattern)

    def __repr__(self) -> str:
        return f"<String Pattern> '{self._expected_pattern.pattern}'"

class RegexSubstringMatch:
    def __init__(self, expected_pattern: (re.Pattern[str] | str), flags: int = 0):
        if isinstance(expected_pattern, str):
            expected_pattern = re.compile(expected_pattern, flags=flags)
        self._expected_pattern: re.Pattern[str] = expected_pattern

    def __eq__(self, other: object) -> bool:
        return isinstance(other, str) and self._expected_pattern.search(other) is not None

    def __hash__(self) -> int:
        return hash(self._expected_pattern)

    def __repr__(self) -> str:
        return f"<Substring Pattern> '{self._expected_pattern.pattern}'"

class MultiSubstringMatch:
    def __init__(self, list_of_expected_text: list[str]):
        self._list_of_expected_text: list[str] = list_of_expected_text

    def __eq__(self, other: object) -> bool:
        return isinstance(other, str) and all(text in other for text in self._list_of_expected_text)

    def __hash__(self) -> int:
        return hash(self._list_of_expected_text)

    def __repr__(self) -> str:
        return f"<Substring List> '{self._list_of_expected_text}'"

class ListOfTeaseMatchesMatch:
    def __init__(self, list_of_expected_tease_matches: list[TeaseMatch], debug: bool = False):
        self._list_of_expected_tease_matches: list[TeaseMatch] = list_of_expected_tease_matches
        self._debug: bool = debug

    def __eq__(self, other: object) -> bool:
        is_equal: bool = True

        if isinstance(other, list) and len(other) == len(self._list_of_expected_tease_matches):
            index: int
            expected_tease_match: TeaseMatch
            for index, expected_tease_match in enumerate(self._list_of_expected_tease_matches):
                actual_tease_match: (TeaseMatch | Any) = other[index]
                if isinstance(actual_tease_match, TeaseMatch):
                    if not is_equal_tease_match(expected_tease_match, actual_tease_match, self._debug):
                        is_equal = False
                else:
                    is_equal = False
        else:
            is_equal = False

        return is_equal

    def __hash__(self) -> int:
        return hash(self._list_of_expected_tease_matches)

    def __repr__(self) -> str:
        return f"<TeaseMatch List> '{self._list_of_expected_tease_matches}'"

def is_equal_list_of_tease_matches(left: list[TeaseMatch], right: list[TeaseMatch], debug: bool = False) -> bool:
    if left is right:
        return True

    is_equal: bool = True

    if len(left) == len(right):
        index: int
        left_tease_match: TeaseMatch
        for index, left_tease_match in enumerate(left):
            right_tease_match: TeaseMatch = right[index]
            if not is_equal_tease_match(left_tease_match, right_tease_match, debug):
                if debug:
                    print(f'Mismatched TeaseMatch[{index}]')
                is_equal = False
    else:
        if debug:
            print(f'Mismatched len(list[TeaseMatch]): left={len(left)}, right={len(right)}')
        is_equal = False

    return is_equal

def is_equal_tease_match(left: TeaseMatch, right: TeaseMatch, debug: bool = False) -> bool:
    if left is right:
        return True

    is_equal: bool = True

    if left.index_of_match != right.index_of_match:
        if debug:
            print(f'Mismatched TeaseMatch.index_of_match: left={left.index_of_match}, right={right.index_of_match}')
        is_equal = False

    if left.tease is not right.tease:
        if debug:
            print(f'Mismatched TeaseMatch.tease: left={left.tease}, right={right.tease}')
        is_equal = False

    if not is_equal_list_of_field_matches(left.list_of_field_matches, right.list_of_field_matches, debug):
        if debug:
            print('Mismatched TeaseMatch.list_of_field_matches')
        is_equal = False

    return is_equal

def is_equal_list_of_field_matches(left: list[IFieldMatch], right: list[IFieldMatch], debug: bool = False) -> bool:
    if left is right:
        return True

    is_equal: bool = True

    if len(left) == len(right):
        index: int
        left_field_match: IFieldMatch
        for index, left_field_match in enumerate(left):
            right_field_match: IFieldMatch = right[index]
            if not is_equal_field_match(left_field_match, right_field_match, debug):
                if debug:
                    print(f'Mismatched IFieldMatch[{index}]')
                is_equal = False
    else:
        if debug:
            print(f'Mismatched len(list[IFieldMatch]): left={len(left)}, right={len(right)}')
        is_equal = False

    return is_equal

def is_equal_field_match(left: IFieldMatch, right: IFieldMatch, debug: bool = False) -> bool: # pylint: disable=too-complex
    if left is right:
        return True

    is_equal: bool = True

    if isinstance(right, type(left)):
        if isinstance(left, FieldItemMatch | FieldItemMatch | FieldListMatch) and isinstance(right, FieldItemMatch | FieldItemMatch | FieldListMatch):
            if left.tease_property != right.tease_property:
                is_equal = False
                if debug:
                    print(f'Mismatched FieldItemMatch.tease_property: left={left.tease_property}, right={right.tease_property}')
        elif isinstance(left, FieldPageListMatch) and isinstance(right, FieldPageListMatch):
            if left.index_of_page != right.index_of_page or left.page is not right.page:
                is_equal = False
                if debug:
                    print(f'Mismatched FieldPageListMatch: left={left.page}, {left.index_of_page}, right={right.page}, {right.index_of_page}')
    else:
        is_equal = False
        if debug:
            print(f'Mismatched Type[IFieldMatch]: left={type(left)}, right={type(right)}')

    if not is_equal_list_of_indices(left.list_of_indices, right.list_of_indices, debug):
        is_equal = False
        if debug:
            print('Mismatched IFieldMatch.list_of_indices')

    return is_equal

def is_equal_list_of_indices(left: list[IFieldMatch.Indices], right: list[IFieldMatch.Indices], debug: bool = False) -> bool:
    if left is right:
        return True

    is_equal: bool = True

    if len(left) == len(right):
        index: int
        left_indices: IFieldMatch.Indices
        for index, left_indices in enumerate(left):
            right_indices: IFieldMatch.Indices = right[index]
            if not is_equal_indices(left_indices, right_indices, debug):
                if debug:
                    print(f'Mismatched IFieldMatch.Indices[{index}]')
                is_equal = False
    else:
        if debug:
            print(f'Mismatched len(list[IFieldMatch.Indices]): left={len(left)}, right={len(right)}')
        is_equal = False

    return is_equal

def is_equal_indices(left: IFieldMatch.Indices, right: IFieldMatch.Indices, debug: bool = False) -> bool:
    if left is right:
        return True

    is_equal: bool = True

    if left.start_index != right.start_index:
        if debug:
            print(f'Mismatched IFieldMatch.Indices.start_index: left={left.start_index}, right={right.start_index}')
        is_equal = False

    if left.end_index != right.end_index:
        if debug:
            print(f'Mismatched IFieldMatch.Indices.end_index: left={left.end_index}, right={right.end_index}')
        is_equal = False

    return is_equal

class CommandTestBase(ABC, TestCase):
    def setUp(self) -> None:
        self.list_of_tokens: list[(Token | None)] = []
        self.mock_token_stream = Mock(ExpandingTokenStream)
        self.argument_stream: (ArgumentStream | None) = None

        self._command_under_test: (ICommand | None) = None
        self._load_exception: (ArgumentStreamError | CommandLoadError | CommandLoadDelegateError | None) = None
        self._list_of_next_text: list[str] = []

    @abstractmethod
    def create_command(self) -> ICommand:
        pass

    def command_load(self, list_of_token_text: (list[str] | None), remaining_raw_text: (str | None) = None, expanded_raw_text: (str | None) = None) -> None:
        self._command_under_test = self.create_command()
        stub_command_token: (Token | None) = None
        self.list_of_tokens = [stub_command_token]
        if not list_of_token_text:
            self.mock_token_stream.next = Mock(return_value=None)
            self.mock_token_stream.get_remaining_raw_text = Mock(return_value='')
        else:
            self.list_of_tokens.extend(create_fake_tokens(list_of_token_text))
            self.mock_token_stream.next = Mock(side_effect=self.list_of_tokens[1:])
            self.mock_token_stream.get_expanded_raw_text = Mock(return_value=(expanded_raw_text or ''))
            self.mock_token_stream.get_remaining_raw_text = Mock(return_value=(remaining_raw_text or ''))
        self.argument_stream = ArgumentStream(self.mock_token_stream)
        try:
            self._list_of_next_text = self._command_under_test.load(self.argument_stream)
        except (ArgumentStreamError, CommandLoadError, CommandLoadDelegateError) as ex:
            self._load_exception = ex

    def command_load_and_execute(self, list_of_token_text: (list[str] | None), remaining_raw_text: (str | None) = None, expanded_raw_text: (str | None) = None) -> None:
        self.command_load(list_of_token_text, remaining_raw_text, expanded_raw_text)
        if self._load_exception is None:
            if self._command_under_test is not None:
                self._command_under_test.execute()
        else:
            self.fail(f"Load should have been successful but wasn't\nException was: {self._load_exception}")

    def assert_next_text(self, list_of_next_text: list[str]) -> None:
        self.assertListEqual(list_of_next_text, self._list_of_next_text, 'Mismatch in expected next text')

    def assert_argument_error(self, fault_token_index: (int | None), fault_text: str, list_of_expected_text: list[str]) -> None:
        self.assertIsInstance(self._load_exception, ArgumentStreamError)
        if isinstance(self._load_exception, ArgumentStreamError):
            if fault_token_index is not None:
                self.assertEqual(
                    self.list_of_tokens[fault_token_index], self._load_exception.fault_token,
                    'Unexpected fault token reported')
            else:
                self.assertIsNone(
                    self._load_exception.fault_token,
                    'Unexpected fault token reported')

            self.assertEqual(
                fault_text, self._load_exception.message,
                f"Expected error message of '{fault_text}' but got '{self._load_exception.message}'")

            self.assertListEqual(sorted(list_of_expected_text), sorted(self._load_exception.list_of_expected_text))

    def assert_load_error(self, fault_token_index: (int | None), fault_text: str, list_of_expected_text: list[str]) -> None:
        self.assertIsInstance(self._load_exception, CommandLoadError)
        if isinstance(self._load_exception, CommandLoadError):
            if fault_token_index is not None:
                self.assertEqual(
                    self.list_of_tokens[fault_token_index], self._load_exception.fault_token,
                    'Unexpected fault token reported')
            else:
                self.assertIsNone(
                    self._load_exception.fault_token,
                    'Unexpected fault token reported')

            self.assertEqual(
                fault_text, self._load_exception.message,
                f"Expected error message of '{fault_text}' but got '{self._load_exception.message}'")

            self.assertListEqual(sorted(list_of_expected_text), sorted(self._load_exception.list_of_expected_text))
