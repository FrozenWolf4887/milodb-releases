# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit http://creativecommons.org/publicdomain/zero/1.0
from milodb.database.tease import Tease

FAKE_THUMBNAIL: str = "https://media.milovana.com/timg/tb_s/73d0969cdbccbf0aa37a5dd2ac1c8962e53ff7a4.jpg"

TEASE_ID_1000_AUTHOR_ID_4567: Tease = Tease(
    {
        "aid": 4567,
        "anm": "Placebo",
        "dat": "2019-04-27",
        "rvl": 4.2,
        "sum": "Cutting paper and cardboard with scissors",
        "tgs": ":totm-nominee:paper:card:scissors:fabric:",
        "thm": FAKE_THUMBNAIL,
        "tid": 1000,
        "ttl": "Cutting paper",
        "txt": [ {
            "ref": "page1",
            "txt": '\n'.join([
                "Take an A4 sheet",
                "Draw a line down the middle",
                "Cut it in half"])
            }
        ],
        "typ": 1
    })

TEASE_ID_1234_AUTHOR_ID_6431: Tease = Tease(
    {
        "aid": 6431,
        "anm": "Forest",
        "dat": "2020-01-18",
        "rvl": 4.0,
        "sum": "Bake a nice cookie",
        "tgs": ":food:cooking:totm:",
        "thm": FAKE_THUMBNAIL,
        "tid": 1234,
        "ttl": "Baking cookies",
        "txt": [ {
            "ref": "page1",
            "txt": '\n'.join([
                "Get some flour, eggs, and chocolate",
                "Mix it all together in a dough",
                "Put it in a baking tray",
                "Bake for 30 minutes"])
            }
        ],
        "typ": 2
    })

TEASE_ID_5678_AUTHOR_ID_4567: Tease = Tease(
    {
        "aid": 4567,
        "anm": "Placebo",
        "dat": "2018-09-02",
        "rvl": 3.8,
        "sum": "Learn to drive a car",
        "tgs": ":driving:car:",
        "thm": FAKE_THUMBNAIL,
        "tid": 5678,
        "ttl": "Driving lessons",
        "txt": [ {
            "ref": "page1",
            "txt": '\n'.join([
                "Seatbelt on",
                "Put into neutral",
                "Ensure handbrake is on",
                "Start engine",
                "Pass test"])
            }
        ],
        "typ": 0
    })

TEASE_ID_2000_AUTHOR_ID_6431: Tease = Tease(
    {
        "aid": 6431,
        "anm": "Forest",
        "dat": "2021-11-15",
        "rvl": 4.4,
        "sum": "Clean those dishes",
        "tgs": ":washing:totm-nominee:cleaning:chores:",
        "thm": FAKE_THUMBNAIL,
        "tid": 2000,
        "ttl": "Washing up",
        "typ": 3
    })

TEASE_ID_8721_AUTHOR_ID_7213: Tease = Tease(
    {
        "aid": 7213,
        "anm": "Curtains",
        "dat": "2022-12-31",
        "rvl": 3.0,
        "sum": "Vacuum the living room and bedroom",
        "tgs": ":vacuuming:chores:clean:",
        "thm": FAKE_THUMBNAIL,
        "tid": 8721,
        "ttl": "Vacuuming",
        "txt": [ {
            "ref": "page1",
            "txt": '\n'.join([
                "Turn on the vacuum cleaner",
                "Move the vacuum cleaner around the living room",
                "Now the bedroom",
                "Sit down and relax"])
            }
        ],
        "typ": 2
    })
