# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
from typing import TYPE_CHECKING
from unittest import TestCase
from unittest.mock import ANY, Mock, call
from milodb_client.view.gui.util.datum import Datum, IValueDatum, SuppressingDatum, ValueDatum
from milodb_common_test.test.strict_mock import InterfaceMock
if TYPE_CHECKING:
    from collections.abc import Callable

class TestDatum(TestCase):
    @staticmethod
    def test_add_listener_with_call_immediately_causes_listener_to_be_called() -> None:
        listener = Mock()
        datum1 = Datum()
        datum1.add_listener(listener, call_immediately=True)
        listener.assert_called_once_with()

    @staticmethod
    def test_add_listener_with_call_immediately_causes_only_new_listener_to_be_called() -> None:
        listener1 = Mock()
        listener2 = Mock()
        datum1 = Datum()
        datum1.add_listener(listener1)
        datum1.add_listener(listener2, call_immediately=True)
        listener1.assert_not_called()

    @staticmethod
    def test_add_listener_without_call_immediately_does_not_call_listener() -> None:
        listener = Mock()
        datum1 = Datum()
        datum1.add_listener(listener)
        listener.assert_not_called()

    @staticmethod
    def test_notify_with_no_listeners_has_no_side_effects() -> None:
        Datum().notify()

    @staticmethod
    def test_notify_with_one_listener_calls_listener() -> None:
        listener = Mock()
        datum1 = Datum()
        datum1.add_listener(listener)
        datum1.notify()
        listener.assert_called_once_with()

    @staticmethod
    def test_notify_with_two_listeners_calls_both_listeners() -> None:
        listener1 = Mock()
        listener2 = Mock()
        datum1 = Datum()
        datum1.add_listener(listener1)
        datum1.add_listener(listener2)
        datum1.notify()
        listener1.assert_called_once_with()
        listener2.assert_called_once_with()

    @staticmethod
    def test_notify_with_removed_listener_calls_remaining_listeners() -> None:
        listener1 = Mock()
        listener2 = Mock()
        listener3 = Mock()
        datum1 = Datum()
        datum1.add_listener(listener1)
        datum1.add_listener(listener2)
        datum1.add_listener(listener3)
        datum1.remove_listener(listener2)
        datum1.notify()
        listener1.assert_called_once_with()
        listener2.assert_not_called()
        listener3.assert_called_once_with()

    @staticmethod
    def test_notify_with_all_removed_listeners_has_no_side_effects() -> None:
        listener1 = Mock()
        listener2 = Mock()
        listener3 = Mock()
        datum1 = Datum()
        datum1.add_listener(listener1)
        datum1.add_listener(listener2)
        datum1.add_listener(listener3)
        datum1.remove_listener(listener2)
        datum1.remove_listener(listener1)
        datum1.remove_listener(listener3)
        datum1.notify()
        listener1.assert_not_called()
        listener2.assert_not_called()
        listener3.assert_not_called()

class TestValueDatum(TestCase):
    def test_get_returns_default_value(self) -> None:
        self.assertEqual(None, ValueDatum(None).get())
        self.assertEqual('Frog', ValueDatum('Frog').get())
        self.assertEqual(True, ValueDatum(True).get())
        self.assertEqual(False, ValueDatum(False).get())

    def test_get_returns_set_value(self) -> None:
        datum1 = ValueDatum('Frog')
        datum1.set('Cat')
        self.assertEqual('Cat', datum1.get())

        datum2 = ValueDatum(True)
        datum2.set(False)
        self.assertEqual(False, datum2.get())

    @staticmethod
    def test_add_listener_with_call_immediately_causes_listener_to_be_called() -> None:
        listener = Mock()
        datum1 = ValueDatum('Frog')
        datum1.add_listener(listener, call_immediately=True)
        listener.assert_called_once_with()

    @staticmethod
    def test_add_listener_with_call_immediately_causes_only_new_listener_to_be_called() -> None:
        listener1 = Mock()
        listener2 = Mock()
        datum1 = ValueDatum('Frog')
        datum1.add_listener(listener1)
        datum1.add_listener(listener2, call_immediately=True)
        listener1.assert_not_called()

    @staticmethod
    def test_add_listener_without_call_immediately_does_not_call_listener() -> None:
        listener = Mock()
        datum1 = ValueDatum('Frog')
        datum1.add_listener(listener)
        listener.assert_not_called()

    @staticmethod
    def test_add_value_listener_with_call_immediately_causes_listener_to_be_called() -> None:
        listener = Mock()
        datum1 = ValueDatum('Frog')
        datum1.add_value_listener(listener, call_immediately=True)
        listener.assert_called_once_with('Frog')

    @staticmethod
    def test_add_value_listener_with_call_immediately_causes_only_new_listener_to_be_called() -> None:
        listener1 = Mock()
        listener2 = Mock()
        datum1 = ValueDatum('Frog')
        datum1.add_value_listener(listener1)
        datum1.add_value_listener(listener2, call_immediately=True)
        listener1.assert_not_called()

    @staticmethod
    def test_add_value_listener_without_call_immediately_does_not_call_listener() -> None:
        listener = Mock()
        datum1 = ValueDatum('Frog')
        datum1.add_value_listener(listener)
        listener.assert_not_called()

    @staticmethod
    def test_set_causes_listener_to_be_called() -> None:
        listener = Mock()
        datum = ValueDatum('Frog')
        datum.add_listener(listener)
        datum.set('Cat')
        listener.assert_called_once_with()

    @staticmethod
    def test_set_causes_value_listener_to_be_called() -> None:
        listener = Mock()
        datum = ValueDatum('Frog')
        datum.add_value_listener(listener)
        datum.set('Cat')
        listener.assert_called_once_with('Cat')

    @staticmethod
    def test_set_causes_all_listeners_to_be_called() -> None:
        listener1 = Mock()
        listener2 = Mock()
        listener3 = Mock()
        datum = ValueDatum('Frog')
        datum.add_listener(listener1)
        datum.add_value_listener(listener2)
        datum.add_listener(listener3)
        datum.set('Cat')
        listener1.assert_called_once_with()
        listener2.assert_called_once_with('Cat')
        listener3.assert_called_once_with()

    @staticmethod
    def test_set_with_same_default_value_does_not_call_listeners() -> None:
        listener = Mock()
        datum = ValueDatum('Frog')
        datum.add_listener(listener)
        datum.set('Frog')
        listener.assert_not_called()

    @staticmethod
    def test_set_with_new_value_does_not_call_listeners() -> None:
        listener = Mock()
        datum = ValueDatum('Frog')
        datum.add_listener(listener)
        datum.set('Cat')
        datum.set('Cat')
        listener.assert_called_once_with()

    @staticmethod
    def test_set_with_two_new_values_calls_listeners() -> None:
        listener = Mock()
        datum = ValueDatum('Frog')
        datum.add_listener(listener)
        datum.set('Cat')
        datum.set('Frog')
        listener.assert_has_calls([call(), call()])

    @staticmethod
    def test_removing_listener_prevents_call() -> None:
        listener1 = Mock()
        listener2 = Mock()
        listener3 = Mock()
        datum = ValueDatum('Frog')
        datum.add_value_listener(listener1)
        datum.add_listener(listener2)
        datum.add_listener(listener3)
        datum.remove_listener(listener2)
        datum.set('Cat')
        listener1.assert_called_once_with('Cat')
        listener2.assert_not_called()
        listener3.assert_called_once_with()

    @staticmethod
    def test_removing_non_existant_listener_is_harmless() -> None:
        listener1 = Mock()
        listener2 = Mock()
        listener3 = Mock()
        datum = ValueDatum('Frog')
        datum.add_listener(listener1)
        datum.add_value_listener(listener2)
        datum.remove_listener(listener3)
        datum.set('Cat')
        listener1.assert_called_once_with()
        listener2.assert_called_once_with('Cat')
        listener3.assert_not_called()

    @staticmethod
    def test_removing_all_listeners_causes_no_callbacks() -> None:
        listener1 = Mock()
        listener2 = Mock()
        listener3 = Mock()
        datum = ValueDatum('Frog')
        datum.add_listener(listener1)
        datum.add_value_listener(listener2)
        datum.add_value_listener(listener3)
        datum.remove_listener(listener2)
        datum.remove_listener(listener1)
        datum.remove_listener(listener3)
        datum.set('Cat')
        listener1.assert_not_called()
        listener2.assert_not_called()
        listener3.assert_not_called()

class TestSuppressingDatum(TestCase):
    def test_get_calls_proxy(self) -> None:
        proxy_datum = InterfaceMock(IValueDatum)
        proxy_datum.get = Mock(return_value=1234)
        datum: SuppressingDatum[int] = SuppressingDatum(proxy_datum)
        self.assertEqual(1234, datum.get())

    @staticmethod
    def test_set_calls_proxy() -> None:
        proxy_datum = InterfaceMock(IValueDatum)
        proxy_datum.set = Mock()
        datum: SuppressingDatum[int] = SuppressingDatum(proxy_datum)
        datum.set(5678)
        proxy_datum.set.assert_called_once_with(5678)

    @staticmethod
    def test_add_listener_attaches_to_proxy() -> None:
        proxy_datum = InterfaceMock(IValueDatum)
        proxy_datum.add_value_listener = Mock()
        listener = Mock()
        datum: SuppressingDatum[int] = SuppressingDatum(proxy_datum)
        datum.add_listener(listener)
        proxy_datum.add_value_listener.assert_called_once()

    @staticmethod
    def test_add_value_listener_attaches_to_proxy() -> None:
        proxy_datum = InterfaceMock(IValueDatum)
        proxy_datum.add_value_listener = Mock()
        listener = Mock()
        datum: SuppressingDatum[int] = SuppressingDatum(proxy_datum)
        datum.add_value_listener(listener)
        proxy_datum.add_value_listener.assert_called_once()

    @staticmethod
    def test_add_listener_multiple_times_attaches_to_proxy_once() -> None:
        proxy_datum = InterfaceMock(IValueDatum)
        proxy_datum.add_value_listener = Mock()
        listener1 = Mock()
        listener2 = Mock()
        listener3 = Mock()
        datum: SuppressingDatum[int] = SuppressingDatum(proxy_datum)
        datum.add_listener(listener1)
        datum.add_listener(listener2)
        datum.add_listener(listener3)
        proxy_datum.add_value_listener.assert_called_once()

    @staticmethod
    def test_add_value_listener_multiple_times_attaches_to_proxy_once() -> None:
        proxy_datum = InterfaceMock(IValueDatum)
        proxy_datum.add_value_listener = Mock()
        listener1 = Mock()
        listener2 = Mock()
        listener3 = Mock()
        datum: SuppressingDatum[int] = SuppressingDatum(proxy_datum)
        datum.add_value_listener(listener1)
        datum.add_value_listener(listener2)
        datum.add_value_listener(listener3)
        proxy_datum.add_value_listener.assert_called_once()

    @staticmethod
    def test_add_mixed_listeners_multiple_times_attaches_to_proxy_once() -> None:
        proxy_datum = InterfaceMock(IValueDatum)
        proxy_datum.add_value_listener = Mock()
        listener1 = Mock()
        listener2 = Mock()
        listener3 = Mock()
        datum: SuppressingDatum[int] = SuppressingDatum(proxy_datum)
        datum.add_listener(listener1)
        datum.add_value_listener(listener2)
        datum.add_listener(listener3)
        proxy_datum.add_value_listener.assert_called_once()

    @staticmethod
    def test_remove_listener_detaches_from_proxy() -> None:
        proxy_datum = InterfaceMock(IValueDatum)
        proxy_datum.add_value_listener = Mock()
        proxy_datum.remove_listener = Mock()
        listener = Mock()
        datum: SuppressingDatum[int] = SuppressingDatum(proxy_datum)
        datum.add_listener(listener)
        datum.remove_listener(listener)
        proxy_datum.remove_listener.assert_called_once()

    @staticmethod
    def test_remove_value_listener_detaches_from_proxy() -> None:
        proxy_datum = InterfaceMock(IValueDatum)
        proxy_datum.add_value_listener = Mock()
        proxy_datum.remove_listener = Mock()
        listener = Mock()
        datum: SuppressingDatum[int] = SuppressingDatum(proxy_datum)
        datum.add_value_listener(listener)
        datum.remove_listener(listener)
        proxy_datum.remove_listener.assert_called_once()

    @staticmethod
    def test_remove_subset_of_listeners_does_not_detach_from_proxy() -> None:
        proxy_datum = InterfaceMock(IValueDatum)
        proxy_datum.add_value_listener = Mock()
        proxy_datum.remove_listener = Mock()
        listener1 = Mock()
        listener2 = Mock()
        listener3 = Mock()
        datum: SuppressingDatum[int] = SuppressingDatum(proxy_datum)
        datum.add_listener(listener1)
        datum.add_listener(listener2)
        datum.add_listener(listener3)
        datum.remove_listener(listener3)
        datum.remove_listener(listener1)
        proxy_datum.remove_listener.assert_not_called()

    @staticmethod
    def test_remove_subset_of_value_listeners_does_not_detach_from_proxy() -> None:
        proxy_datum = InterfaceMock(IValueDatum)
        proxy_datum.add_value_listener = Mock()
        proxy_datum.remove_listener = Mock()
        listener1 = Mock()
        listener2 = Mock()
        listener3 = Mock()
        datum: SuppressingDatum[int] = SuppressingDatum(proxy_datum)
        datum.add_value_listener(listener1)
        datum.add_value_listener(listener2)
        datum.add_value_listener(listener3)
        datum.remove_listener(listener3)
        datum.remove_listener(listener1)
        proxy_datum.remove_listener.assert_not_called()

    @staticmethod
    def test_remove_subset_of_mixed_listeners_does_not_detach_from_proxy() -> None:
        proxy_datum = InterfaceMock(IValueDatum)
        proxy_datum.add_value_listener = Mock()
        proxy_datum.remove_listener = Mock()
        listener1 = Mock()
        listener2 = Mock()
        listener3 = Mock()
        datum: SuppressingDatum[int] = SuppressingDatum(proxy_datum)
        datum.add_value_listener(listener1)
        datum.add_listener(listener2)
        datum.add_value_listener(listener3)
        datum.remove_listener(listener2)
        datum.remove_listener(listener1)
        proxy_datum.remove_listener.assert_not_called()

    @staticmethod
    def test_remove_all_listeners_detaches_from_proxy() -> None:
        proxy_datum = InterfaceMock(IValueDatum)
        proxy_datum.add_value_listener = Mock()
        proxy_datum.remove_listener = Mock()
        listener1 = Mock()
        listener2 = Mock()
        listener3 = Mock()
        datum: SuppressingDatum[int] = SuppressingDatum(proxy_datum)
        datum.add_listener(listener1)
        datum.add_listener(listener2)
        datum.add_listener(listener3)
        datum.remove_listener(listener3)
        datum.remove_listener(listener1)
        datum.remove_listener(listener2)
        proxy_datum.remove_listener.assert_called_once()

    @staticmethod
    def test_remove_all_value_listeners_detaches_from_proxy() -> None:
        proxy_datum = InterfaceMock(IValueDatum)
        proxy_datum.add_value_listener = Mock()
        proxy_datum.remove_listener = Mock()
        listener1 = Mock()
        listener2 = Mock()
        listener3 = Mock()
        datum: SuppressingDatum[int] = SuppressingDatum(proxy_datum)
        datum.add_value_listener(listener1)
        datum.add_value_listener(listener2)
        datum.add_value_listener(listener3)
        datum.remove_listener(listener3)
        datum.remove_listener(listener1)
        datum.remove_listener(listener2)
        proxy_datum.remove_listener.assert_called_once()

    @staticmethod
    def test_remove_all_mixed_listeners_detaches_from_proxy() -> None:
        proxy_datum = InterfaceMock(IValueDatum)
        proxy_datum.add_value_listener = Mock()
        proxy_datum.remove_listener = Mock()
        listener1 = Mock()
        listener2 = Mock()
        listener3 = Mock()
        datum: SuppressingDatum[int] = SuppressingDatum(proxy_datum)
        datum.add_listener(listener1)
        datum.add_value_listener(listener2)
        datum.add_value_listener(listener3)
        datum.remove_listener(listener3)
        datum.remove_listener(listener1)
        datum.remove_listener(listener2)
        proxy_datum.remove_listener.assert_called_once()

    @staticmethod
    def test_remove_and_add_listener_reattaches_to_proxy() -> None:
        proxy_datum = InterfaceMock(IValueDatum)
        proxy_datum.add_value_listener = Mock()
        proxy_datum.remove_listener = Mock()
        listener = Mock()
        datum: SuppressingDatum[int] = SuppressingDatum(proxy_datum)
        datum.add_listener(listener)
        datum.remove_listener(listener)
        datum.add_listener(listener)
        proxy_datum.add_value_listener.assert_has_calls([call(ANY), call(ANY)])

    @staticmethod
    def test_remove_and_add_value_listener_reattaches_to_proxy() -> None:
        proxy_datum = InterfaceMock(IValueDatum)
        proxy_datum.add_value_listener = Mock()
        proxy_datum.remove_listener = Mock()
        listener = Mock()
        datum: SuppressingDatum[int] = SuppressingDatum(proxy_datum)
        datum.add_listener(listener)
        datum.remove_listener(listener)
        datum.add_value_listener(listener)
        proxy_datum.add_value_listener.assert_has_calls([call(ANY), call(ANY)])

    @staticmethod
    def test_set_does_not_call_listeners() -> None:
        proxy_datum = InterfaceMock(IValueDatum)
        proxy_datum.add_value_listener = Mock()
        listener = Mock()

        datum: SuppressingDatum[int] = SuppressingDatum(proxy_datum)
        datum.add_listener(listener)

        proxy_listener: Callable[[IValueDatum[int]], None] = proxy_datum.add_value_listener.call_args[0][0]
        proxy_datum.set = Mock(side_effect=lambda _: proxy_listener(proxy_datum))

        datum.set(1234)

        listener.assert_not_called()

    @staticmethod
    def test_set_does_not_call_value_listeners() -> None:
        proxy_datum = InterfaceMock(IValueDatum)
        proxy_datum.add_value_listener = Mock()
        listener = Mock()

        datum: SuppressingDatum[int] = SuppressingDatum(proxy_datum)
        datum.add_value_listener(listener)

        proxy_listener: Callable[[IValueDatum[int]], None] = proxy_datum.add_value_listener.call_args[0][0]
        proxy_datum.set = Mock(side_effect=lambda _: proxy_listener(proxy_datum))

        datum.set(1234)

        listener.assert_not_called()

    @staticmethod
    def test_call_to_proxy_listener_calls_listeners() -> None:
        proxy_datum = InterfaceMock(IValueDatum)
        proxy_datum.add_value_listener = Mock()
        listener = Mock()

        datum: SuppressingDatum[int] = SuppressingDatum(proxy_datum)
        datum.add_listener(listener)

        proxy_listener: Callable[[int], None] = proxy_datum.add_value_listener.call_args[0][0]
        proxy_listener(34)

        listener.assert_called_once_with()

    @staticmethod
    def test_call_to_proxy_listener_calls_value_listeners() -> None:
        proxy_datum = InterfaceMock(IValueDatum)
        proxy_datum.add_value_listener = Mock()
        listener = Mock()

        datum: SuppressingDatum[int] = SuppressingDatum(proxy_datum)
        datum.add_value_listener(listener)

        proxy_listener: Callable[[int], None] = proxy_datum.add_value_listener.call_args[0][0]
        proxy_listener(18)

        listener.assert_called_once_with(18)

    @staticmethod
    def test_call_to_proxy_listener_calls_multiple_listeners() -> None:
        proxy_datum = InterfaceMock(IValueDatum)
        proxy_datum.add_value_listener = Mock()
        listener1 = Mock()
        listener2 = Mock()
        listener3 = Mock()

        datum: SuppressingDatum[int] = SuppressingDatum(proxy_datum)
        datum.add_listener(listener1)
        datum.add_value_listener(listener2)
        datum.add_listener(listener3)

        proxy_listener: Callable[[int], None] = proxy_datum.add_value_listener.call_args[0][0]
        proxy_listener(123)

        listener1.assert_called_once_with()
        listener2.assert_called_once_with(123)
        listener3.assert_called_once_with()
