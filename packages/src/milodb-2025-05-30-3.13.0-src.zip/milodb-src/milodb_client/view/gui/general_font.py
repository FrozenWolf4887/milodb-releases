# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
NORMAL_FONT_TUPLE: tuple[str, int] = ('Arial', 10)
EDIT_FONT_TUPLE: tuple[str, int] = ('Arial', 10)
ITALIC_FONT_TUPLE: tuple[str, int, str] = ('Arial', 10, 'italic')
BANNER_FONT_TUPLE: tuple[str, int, str] = ('Arial', 14, 'italic')
NORMAL_FONT_NAME: str = ' '.join(str(part) for part in NORMAL_FONT_TUPLE)
EDIT_FONT_NAME: str = ' '.join(str(part) for part in EDIT_FONT_TUPLE)
ITALIC_FONT_NAME: str = ' '.join(str(part) for part in ITALIC_FONT_TUPLE)
BANNER_FONT_NAME: str = ' '.join(str(part) for part in BANNER_FONT_TUPLE)
