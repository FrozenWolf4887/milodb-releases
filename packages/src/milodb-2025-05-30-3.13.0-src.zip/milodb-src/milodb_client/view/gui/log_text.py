# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import tkinter as tk
import tkinter.font as tkfont
from tkinter import ttk
from typing import override
from milodb_client.view.gui import general_colours, general_font, general_layout
from milodb_client.view.gui.tk_interceptor import TkInterceptor
from milodb_common.output.print.debug_printer import DebugPrinter
from milodb_common.output.print.i_printer import IPrinter
from milodb_common.output.print.prefix_printer import PrefixPrinter

# spell-checker: ignore borderwidth highlightthickness padx pady tkfont yscrollcommand

_COL_PANEL_BACK: str = general_colours.PANEL_BACK
_COL_LOG_TEXT_BACK: str = general_colours.LOG_TEXT_BACK
_COL_LOG_TEXT_FORE: str = general_colours.LOG_TEXT_FORE

_LAYOUT_PADDING_X: int = general_layout.PANEL_PADDING_X
_LAYOUT_PADDING_Y: int = general_layout.PANEL_PADDING_Y

class LogText(tk.Frame):
    def __init__(self, master: tk.Misc) -> None:
        super().__init__(master, background=_COL_PANEL_BACK, relief=tk.FLAT, padx=_LAYOUT_PADDING_X, pady=_LAYOUT_PADDING_Y, borderwidth=0)
        self._scrollbar: ttk.Scrollbar = ttk.Scrollbar(self, orient=tk.VERTICAL)
        self._textbox: tk.Text = tk.Text(self, height=3, border=0, highlightthickness=0, background=_COL_LOG_TEXT_BACK, foreground=_COL_LOG_TEXT_FORE, font=tkfont.Font(self, general_font.NORMAL_FONT_NAME), yscrollcommand=self._scrollbar.set)
        self._scrollbar.config(command=self._textbox.yview)

        self._scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self._textbox.pack(side=tk.LEFT, fill=tk.BOTH)
        _set_text_readonly(self._textbox)

        self._text_widget_printer: _TextWidgetPrinter = _TextWidgetPrinter(self._textbox)
        self._warning_printer: _CountingPrinter = _CountingPrinter(PrefixPrinter('Warning: ', self._text_widget_printer))
        self._error_printer: _CountingPrinter = _CountingPrinter(PrefixPrinter('Error: ', self._text_widget_printer))
        self._fatal_printer: _CountingPrinter = _CountingPrinter(PrefixPrinter('FATAL: ', self._text_widget_printer))
        self._debug_printer: DebugPrinter = DebugPrinter(self._text_widget_printer)

    @property
    def normal_printer(self) -> IPrinter:
        return self._text_widget_printer

    @property
    def warning_printer(self) -> IPrinter:
        return self._warning_printer

    @property
    def error_printer(self) -> IPrinter:
        return self._error_printer

    @property
    def fatal_printer(self) -> IPrinter:
        return self._fatal_printer

    @property
    def debug_printer(self) -> DebugPrinter:
        return self._debug_printer

    @property
    def any_warnings_or_errors(self) -> bool:
        return any([self._warning_printer.count, self._error_printer.count, self._fatal_printer.count])

class _CountingPrinter(IPrinter):
    def __init__(self, delegate: IPrinter) -> None:
        self._delegate: IPrinter = delegate
        self._count: int = 0

    @property
    def count(self) -> int:
        return self._count

    @override
    def write(self, text: str) -> None:
        self._count += 1
        self._delegate.write(text)

    @override
    def writeln(self, text: str | None = None) -> None:
        self._count += 1
        self._delegate.writeln(text)

    @property
    @override
    def is_on_new_line(self) -> bool:
        return self._delegate.is_on_new_line

class _TextWidgetPrinter(IPrinter):
    def __init__(self, textbox: tk.Text) -> None:
        self._textbox: tk.Text = textbox
        self._is_on_newline: bool = True

    @override
    def write(self, text: str) -> None:
        if text:
            self._textbox.insert(tk.END, text)
            self._is_on_newline = text[-1] == '\n'
            self._textbox.see(tk.END)
            self._textbox.update()

    @override
    def writeln(self, text: str | None = None) -> None:
        if text:
            self._textbox.insert(tk.END, text + '\n')
        else:
            self._textbox.insert(tk.END, '\n')
        self._is_on_newline = True
        self._textbox.see(tk.END)
        self._textbox.update()

    @property
    @override
    def is_on_new_line(self) -> bool:
        return self._is_on_newline

def _set_text_readonly(widget: tk.Widget) -> None:
    def do_nothing(*_args: object) -> None:
        ...
    def on_tk_insert_call(*args: object) -> object:
        return original_tk_insert(*args)
    def on_tk_delete_call(*args: object) -> object:
        return original_tk_delete(*args)
    interceptor: TkInterceptor = TkInterceptor(widget)
    original_tk_insert: TkInterceptor.Handler = interceptor.intercept('insert', do_nothing, on_tk_insert_call)
    original_tk_delete: TkInterceptor.Handler = interceptor.intercept('delete', do_nothing, on_tk_delete_call)
