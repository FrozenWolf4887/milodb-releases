# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import tkinter as tk
from typing import Literal
from milodb_client.view.gui import general_style
from milodb_client.view.gui.theme import apply_text_style

# spell-checker: ignore autoseparators exportselection maxundo setgrid startline tabstyle takefocus wordprocessor xscrollcommand yscrollcommand

type ScreenUnits = tk._ScreenUnits # pylint: disable=protected-access, no-member # type: ignore[reportPrivateUsage] # noqa: SLF001 Private member accessed
type TakeFocusValue = tk._TakeFocusValue # pylint: disable=protected-access, no-member # type: ignore[reportPrivateUsage] # noqa: SLF001 Private member accessed
type XYScrollCommand = tk._XYScrollCommand # pylint: disable=protected-access, no-member # type: ignore[reportPrivateUsage] # noqa: SLF001 Private member accessed

class StyledText(tk.Text):
    def __init__(
            self, master: tk.Misc,
            style: str = general_style.TEXT,
            *,
            autoseparators: bool = True,
            endline: int | Literal[''] = '',
            exportselection: bool = True,
            height: ScreenUnits = 24,
            maxundo: int = 0,
            name: str = '',
            setgrid: bool = False,
            startline: int | Literal[''] = '',
            state: Literal['normal', 'disabled'] = tk.NORMAL,
            tabs: ScreenUnits | tuple[ScreenUnits, ...] = '',
            tabstyle: Literal['tabular', 'wordprocessor'] = 'tabular',
            takefocus: TakeFocusValue = '',
            undo: bool = False,
            width: int = 80,
            wrap: Literal['none', 'char', 'word'] = tk.CHAR,
            xscrollcommand: XYScrollCommand = '',
            yscrollcommand: XYScrollCommand = '',
        ) -> None:
        super().__init__(
            master,
            autoseparators = autoseparators,
            endline = endline,
            exportselection = exportselection,
            height = height,
            maxundo = maxundo,
            name = name,
            setgrid = setgrid,
            startline = startline,
            state = state,
            tabs = tabs,
            tabstyle = tabstyle,
            takefocus = takefocus,
            undo = undo,
            width = width,
            wrap = wrap,
            xscrollcommand = xscrollcommand,
            yscrollcommand = yscrollcommand,
        )

        self._style_name: str = style
        self._change_theme_event_id: str | None = None

        apply_text_style(self, self._style_name)
        self.bind('<<ThemeChanged>>', self._on_theme_changed)

    def _on_theme_changed(self, _event: object) -> None:
        if self._change_theme_event_id is None:
            self._change_theme_event_id = self.after_idle(self._on_idle_update_theme)

    def _on_idle_update_theme(self) -> None:
        self._change_theme_event_id = None
        apply_text_style(self, self._style_name)
