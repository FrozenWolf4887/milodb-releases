# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import tkinter as tk
from collections.abc import Sequence
from tkinter import font as tkfont, ttk
from milodb_client.view.gui import general_colours, general_font, general_layout, general_style

# spell-checker: ignore arrowcolor arrowsize blockcursor bordercolor borderwidth darkcolor gripcount
# spell-checker: ignore highlightbackground highlightcolor highlightthickness inactiveselectbackground inactiveselectedbackground insertbackground
# spell-checker: ignore insertborderwidth insertofftime insertontime insertunfocussed insertwidth lightcolor
# spell-checker: ignore padx pady selectbackground selectborderwidth selectedbackground selectedborderwidth selectedforeground selectforeground
# spell-checker: ignore tkfont troughcolor xterm

_COL_PROGRESSBAR_FORE: str = general_colours.HEADER_FORE
_COL_PROGRESSBAR_BACK: str = general_colours.HEADER_BACK
_COL_PANED_WINDOW_FORE: str = '#222'
_COL_PANED_WINDOW_BACK: str = '#DDD'
_COL_OPTIONMENU_BACK: str = general_colours.VALUE_BACK
_COL_OPTIONMENU_FORE: str = general_colours.VALUE_FORE
_COL_OPTIONMENU_HOVER_BACK: str = general_colours.VALUE_HOVER_BACK
_COL_OPTIONMENU_HOVER_FORE: str = general_colours.VALUE_HOVER_FORE
_COL_OPTIONMENU_SELECTED_BACK: str = general_colours.VALUE_SELECTED_BACK
_COL_OPTIONMENU_SELECTED_FORE: str = general_colours.VALUE_SELECTED_FORE
_COL_OPTIONMENU_DISABLED_BACK: str = '#444'
_COL_OPTIONMENU_DISABLED_FORE: str = '#333'
_COL_LABEL_BACK: str = general_colours.PANEL_BACK
_COL_LABEL_FORE: str = general_colours.PANEL_TEXT_FORE
_COL_LABEL_TABLE_VALUE_BACK: str = general_colours.VALUE_BACK
_COL_LABEL_TABLE_VALUE_FORE: str = general_colours.VALUE_FORE
_COL_LABEL_TABLE_NEW_VALUE_FORE: str = '#CFC'
_COL_LABEL_TABLE_NEW_VALUE_BACK: str = '#141'
_COL_LABEL_TABLE_HEADER_BACK: str = general_colours.HEADER_BACK
_COL_LABEL_TABLE_HEADER_FORE: str = general_colours.HEADER_FORE
_COL_LABEL_TABLE_SUBHEADER_BACK: str = '#434'
_COL_LABEL_TABLE_SUBHEADER_FORE: str = general_colours.HEADER_FORE
_COL_TEXT_BACK: str = general_colours.VALUE_BACK
_COL_TEXT_FORE: str = general_colours.VALUE_FORE
_COL_TEXT_SELECTED_BACK: str = '#CCC'
_COL_TEXT_SELECTED_FORE: str = '#000'
_COL_TEXT_SELECTED_INACTIVE_BACK: str = '#AAA'
_COL_TEXT_CARET: str = '#CCC'
_COL_TEXT_ACTIVE_BORDER: str = '#FFF'
_COL_TEXT_INACTIVE_BORDER: str = '#888'
_COL_STATUS_TEXT_FORE: str = general_colours.STATUS_TEXT_FORE
_COL_STATUS_TEXT_OKAY_BACK: str = general_colours.STATUS_TEXT_OKAY_BACK
_COL_STATUS_TEXT_READY_BACK: str = general_colours.STATUS_TEXT_READY_BACK
_COL_STATUS_TEXT_ERROR_BACK: str = general_colours.STATUS_TEXT_ERROR_BACK

def configure_ttk_styles(master: tk.Tk) -> ttk.Style:
    style = ttk.Style(master=master)
    style.theme_use('clam')
    style.configure(general_style.PANED_WINDOW, background=_COL_PANED_WINDOW_BACK, foreground=_COL_PANED_WINDOW_FORE)
    style.configure(general_style.PROGRESSBAR, background=_COL_PROGRESSBAR_BACK, foreground=_COL_PROGRESSBAR_FORE)
    _configure_ttk_label_style(style)
    _configure_ttk_text_style(style)
    _configure_ttk_button_style(style)
    _configure_ttk_optionmenu_style(style)
    _configure_ttk_scrollbar_style(style)
    _configure_ttk_checkbutton_style(style)
    _configure_ttk_notebook_style(style)
    return style

def _configure_ttk_label_style(style: ttk.Style) -> None:
    style.layout(
        general_style.LABEL, [ (
        'Label.padding', {
            'sticky': tk.NSEW,
            'children': [ (
                    'Label.label', {
                        'sticky': tk.NSEW,
                    },
                ),
            ],
        },
    ) ] )
    style.configure(
        general_style.LABEL,
        font = general_font.NORMAL_FONT_TUPLE,
        foreground = _COL_LABEL_FORE,
        background = _COL_LABEL_BACK,
        padding = (general_layout.LABEL_PADDING_X, general_layout.LABEL_PADDING_Y),
    )
    style.configure(
        general_style.LABEL_TABLE,
        padding = (general_layout.TABLE_CELL_PADDING_X, general_layout.TABLE_CELL_PADDING_Y),
    )
    style.configure(
        general_style.LABEL_TABLE_VALUE,
        foreground = _COL_LABEL_TABLE_VALUE_FORE,
        background = _COL_LABEL_TABLE_VALUE_BACK,
    )
    style.configure(
        general_style.LABEL_TABLE_NEW_VALUE,
        foreground = _COL_LABEL_TABLE_NEW_VALUE_FORE,
        background = _COL_LABEL_TABLE_NEW_VALUE_BACK,
    )
    style.configure(
        general_style.LABEL_TABLE_HEADER,
        foreground = _COL_LABEL_TABLE_HEADER_FORE,
        background = _COL_LABEL_TABLE_HEADER_BACK,
    )
    style.configure(
        general_style.LABEL_TABLE_SUBHEADER,
        foreground = _COL_LABEL_TABLE_SUBHEADER_FORE,
        background = _COL_LABEL_TABLE_SUBHEADER_BACK,
    )
    style.configure(
        general_style.LABEL_STATUS_OKAY,
        font = general_font.NORMAL_FONT_TUPLE,
        foreground = _COL_STATUS_TEXT_FORE,
        background = _COL_STATUS_TEXT_OKAY_BACK,
    )
    style.configure(
        general_style.LABEL_STATUS_READY,
        font = general_font.NORMAL_FONT_TUPLE,
        foreground = _COL_STATUS_TEXT_FORE,
        background = _COL_STATUS_TEXT_READY_BACK,
    )
    style.configure(
        general_style.LABEL_STATUS_ERROR,
        font = general_font.NORMAL_FONT_TUPLE,
        foreground = _COL_STATUS_TEXT_FORE,
        background = _COL_STATUS_TEXT_ERROR_BACK,
    )

def _configure_ttk_text_style(style: ttk.Style) -> None:
    style.configure(
        general_style.TEXT,
        font = general_font.EDIT_FONT_TUPLE,
        foreground = _COL_TEXT_FORE,
        background = _COL_TEXT_BACK,
        selectedborderwidth = 0,
        selectedforeground = _COL_TEXT_SELECTED_FORE,
        selectedbackground  =_COL_TEXT_SELECTED_BACK,
        inactiveselectedbackground = _COL_TEXT_SELECTED_INACTIVE_BACK,
        highlightbackground = _COL_TEXT_INACTIVE_BORDER,
        highlightcolor = _COL_TEXT_ACTIVE_BORDER,
        highlightthickness = 1,
        insertbackground = _COL_TEXT_CARET,
        insertborderwidth = 0,
        insertofftime = 300,
        insertontime = 600,
        insertunfocussed = 'none',
        insertwidth = 2,
        cursor = "xterm",
        blockcursor = False,
        borderwidth = 0,
        padx = general_layout.LABEL_PADDING_X,
        pady = general_layout.LABEL_PADDING_Y,
        relief = tk.SOLID,
    )
    style.configure(
        general_style.TEXT_TABLE,
        padx = general_layout.TABLE_CELL_PADDING_X,
        pady = general_layout.TABLE_CELL_PADDING_Y,
    )
    style.configure(
        general_style.TEXT_BORDERLESS,
        highlightthickness = 0,
        relief = tk.FLAT,
    )

def apply_text_style(widget: tk.Text, style_name: str) -> None:
    style: ttk.Style = ttk.Style(widget)
    kwargs: dict[str, object] = {}

    def fetch_attribute(name: str, list_of_types: Sequence[type], *, allow_empty: bool=False, arg_name: str | None=None, state: Sequence[str] | None=None) -> None:
        if not arg_name:
            arg_name = name
        value: object = style.lookup(style_name, name, state)
        if any(isinstance(value, possible_type) for possible_type in list_of_types) and (allow_empty or value):
            kwargs[arg_name] = value

    fetch_attribute('font', (str, tuple, tkfont.Font))
    fetch_attribute('foreground', (str,))
    fetch_attribute('background', (str,))
    fetch_attribute('selectedborderwidth', (int,), allow_empty=True, arg_name='selectborderwidth')
    fetch_attribute('selectedforeground', (str,), arg_name='selectforeground')
    fetch_attribute('selectedbackground', (str,), arg_name='selectbackground')
    fetch_attribute('inactiveselectedbackground', (str,), arg_name='inactiveselectbackground')
    fetch_attribute('highlightbackground', (str,))
    fetch_attribute('highlightcolor', (str,))
    fetch_attribute('highlightthickness', (int,), allow_empty=True)
    fetch_attribute('insertbackground', (str,))
    fetch_attribute('insertborderwidth', (int,), allow_empty=True)
    fetch_attribute('insertofftime', (int,), allow_empty=True)
    fetch_attribute('insertontime', (int,), allow_empty=True)
    fetch_attribute('insertunfocussed', (str,))
    fetch_attribute('insertwidth', (int,), allow_empty=True)
    fetch_attribute('cursor', (str,))
    fetch_attribute('blockcursor', (bool,), allow_empty=True)
    fetch_attribute('borderwidth', (int,), allow_empty=True)
    fetch_attribute('padx', (int,), allow_empty=True)
    fetch_attribute('pady', (int,), allow_empty=True)
    fetch_attribute('relief', (str,))

    widget.configure(**kwargs) # type: ignore[call-overload]

def _configure_ttk_button_style(style: ttk.Style) -> None:
    style.configure(
        general_style.BUTTON,
        font = general_font.NORMAL_FONT_TUPLE,
        foreground = general_colours.BUTTON_FORE,
        background = general_colours.BUTTON_BACK,
        padding = (general_layout.BUTTON_PADDING_X, general_layout.BUTTON_PADDING_Y),
        relief = general_layout.BUTTON_BORDER_RELIEF,
        bordercolor = general_colours.BUTTON_BORDER_FORE,
    )
    style.map(
        general_style.BUTTON,
        background = [ ("pressed", general_colours.BUTTON_SELECTED_BACK), ("active", general_colours.BUTTON_HOVER_BACK), ("disabled", general_colours.BUTTON_DISABLED_BACK) ],
        foreground = [ ("pressed", general_colours.BUTTON_SELECTED_FORE), ("active", general_colours.BUTTON_HOVER_FORE), ("disabled", general_colours.BUTTON_DISABLED_FORE) ],
        embossed = [ ("disabled", True) ],
    )

def _configure_ttk_optionmenu_style(style: ttk.Style) -> None:
    style.configure(
        general_style.OPTIONMENU,
        font = general_font.NORMAL_FONT_TUPLE,
        foreground = _COL_OPTIONMENU_FORE,
        background = _COL_OPTIONMENU_BACK,
        arrowcolor = _COL_OPTIONMENU_FORE,
    )
    style.map(
        general_style.OPTIONMENU,
        background = [ ("pressed", _COL_OPTIONMENU_SELECTED_BACK), ("active", _COL_OPTIONMENU_HOVER_BACK), ("disabled", _COL_OPTIONMENU_DISABLED_BACK) ],
        foreground = [ ("pressed", _COL_OPTIONMENU_SELECTED_FORE), ("active", _COL_OPTIONMENU_HOVER_FORE), ("disabled", _COL_OPTIONMENU_DISABLED_FORE) ],
        arrowcolor = [ ("pressed", _COL_OPTIONMENU_SELECTED_FORE), ("active", _COL_OPTIONMENU_HOVER_FORE) ],
    )

def _configure_ttk_scrollbar_style(style: ttk.Style) -> None:
    style.configure(
        general_style.SCROLLBAR,
        font = general_font.NORMAL_FONT_TUPLE,
        background = general_colours.SCROLLBAR_FORE,
        bordercolor = general_colours.SCROLLBAR_BACK,
        troughcolor = general_colours.SCROLLBAR_BACK,
        lightcolor = general_colours.SCROLLBAR_FORE,
        darkcolor = general_colours.SCROLLBAR_FORE,
        arrowcolor = general_colours.SCROLLBAR_BACK,
        arrowsize = general_layout.SCROLLBAR_WIDTH,
        gripcount = 0,
    )
    style.map(
        general_style.SCROLLBAR,
        background = [ ("pressed", general_colours.SCROLLBAR_SELECTED_FORE), ("active", general_colours.SCROLLBAR_HOVER_FORE) ],
    )

def _configure_ttk_checkbutton_style(style: ttk.Style) -> None:
    style.configure(
        general_style.CHECKBOX,
        font = general_font.NORMAL_FONT_TUPLE,
        foreground = general_colours.CHECKBOX_FORE,
        background = general_colours.CHECKBOX_BACK,
        borderwidth = 0,
        highlightthickness = 0,
    )
    style.configure(
        general_style.CHECKBOX_TABLE,
        padding = (general_layout.TABLE_CELL_PADDING_X, general_layout.TABLE_CELL_PADDING_Y),
    )
    style.configure(
        general_style.CHECKBOX_TABLE_VALUE,
        foreground = _COL_LABEL_TABLE_VALUE_FORE,
        background = _COL_LABEL_TABLE_VALUE_BACK,
        padding = (general_layout.TABLE_CELL_PADDING_X, general_layout.TABLE_CELL_PADDING_Y),
    )
    style.configure(
        general_style.CHECKBOX_HEADER,
        foreground = general_colours.CHECKBOX_HEADER_FORE,
        background = general_colours.CHECKBOX_HEADER_BACK,
    )
    style.map(
        general_style.CHECKBOX_TABLE_VALUE,
        foreground = [ ("pressed", general_colours.CHECKBOX_TABLE_VALUE_PRESSED_FORE), ("active", general_colours.CHECKBOX_TABLE_VALUE_HOVER_FORE), ("disabled", general_colours.CHECKBOX_TABLE_VALUE_DISABLED_FORE) ],
        background = [ ("pressed", general_colours.CHECKBOX_TABLE_VALUE_PRESSED_BACK), ("active", general_colours.CHECKBOX_TABLE_VALUE_HOVER_BACK), ("disabled", general_colours.CHECKBOX_TABLE_VALUE_DISABLED_BACK) ],
        embossed = [ ("disabled", True) ],
    )
    style.map(
        general_style.CHECKBOX,
        foreground = [ ("pressed", general_colours.CHECKBOX_PRESSED_FORE), ("active", general_colours.CHECKBOX_HOVER_FORE), ("disabled", general_colours.CHECKBOX_DISABLED_FORE) ],
        background = [ ("pressed", general_colours.CHECKBOX_PRESSED_BACK), ("active", general_colours.CHECKBOX_HOVER_BACK), ("disabled", general_colours.CHECKBOX_DISABLED_BACK) ],
        embossed = [ ("disabled", True) ],
    )
    style.map(
        general_style.CHECKBOX_HEADER,
        foreground = [ ("pressed", general_colours.CHECKBOX_HEADER_PRESSED_FORE), ("active", general_colours.CHECKBOX_HEADER_HOVER_FORE), ("disabled", general_colours.CHECKBOX_HEADER_DISABLED_FORE) ],
        background = [ ("pressed", general_colours.CHECKBOX_HEADER_PRESSED_BACK), ("active", general_colours.CHECKBOX_HEADER_HOVER_BACK), ("disabled", general_colours.CHECKBOX_HEADER_DISABLED_BACK) ],
        embossed = [ ("disabled", True) ],
    )

def _configure_ttk_notebook_style(style: ttk.Style) -> None:
    style.configure(
        general_style.NOTEBOOK,
        background = general_colours.NOTEBOOK_BACK,
        bordercolor = general_colours.NOTEBOOK_TAB_BORDER,
        darkcolor = general_colours.NOTEBOOK_TAB_BORDER,
        lightcolor = general_colours.NOTEBOOK_TAB_BORDER,
        relief = tk.FLAT,
    )
    style.configure(
        general_style.NOTEBOOK_TAB,
        font = general_font.NORMAL_FONT_TUPLE,
        foreground = general_colours.NOTEBOOK_TAB_INACTIVE_FORE,
        background = general_colours.NOTEBOOK_TAB_INACTIVE_BACK,
        relief = tk.FLAT,
    )
    style.map(
        general_style.NOTEBOOK_TAB,
        foreground = [ ("active", general_colours.NOTEBOOK_TAB_HOVER_FORE), ("selected", general_colours.NOTEBOOK_TAB_ACTIVE_FORE), ("disabled", general_colours.NOTEBOOK_TAB_DISABLED_FORE) ],
        background = [ ("active", general_colours.NOTEBOOK_TAB_HOVER_BACK), ("selected", general_colours.NOTEBOOK_TAB_ACTIVE_BACK), ("disabled", general_colours.NOTEBOOK_TAB_DISABLED_BACK) ],
        bordercolor = [ ('', general_colours.NOTEBOOK_TAB_BORDER) ],
        darkcolor = [ ('', general_colours.NOTEBOOK_TAB_BORDER) ],
        lightcolor = [ ('', general_colours.NOTEBOOK_TAB_BORDER) ],
        embossed = [ ("disabled", True) ],
    )
