# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import tkinter as tk
from collections.abc import Callable
from tkinter import ttk
from typing import Any, Literal
from milodb_common.view.gui.metrics import Size

# spell-checker: ignore borderwidth highlightthickness scrollregion yscrollcommand

_LINUX_AND_OSX_MOUSEWHEEL_UP_BUTTON: int = 5
_LINUX_AND_OSX_MOUSEWHEEL_DOWN_BUTTON: int = 4
_SCROLL_PAGE_UNITS: int = 10

class ScrollableCanvas(tk.Frame):
    def __init__(self, master: tk.Misc, canvas_resized_callback: Callable[[Size], None] | None, *args: Any, background: str, **kwargs: Any) -> None: # noqa: ANN401 Dynamically typed expressions (typing.Any) are disallowed
        super().__init__(master, *args, background=background, **kwargs)

        self._canvas_resized_callback: Callable[[Size], None] | None = canvas_resized_callback
        self._current_canvas_size: Size | None = None
        self._content_height: int = 0

        self._canvas: tk.Canvas = tk.Canvas(self, background=background, borderwidth=0, highlightthickness=0)
        self._canvas.grid(row=1, column=0, sticky=tk.NSEW)
        if self._canvas_resized_callback:
            self._canvas.bind('<Configure>', self._on_canvas_changed)

        scrollbar: ttk.Scrollbar = ttk.Scrollbar(self, orient=tk.VERTICAL, command=self._on_vertical_scroll)
        scrollbar.grid(row=1, column=1, sticky=tk.NS)
        self._canvas.config(yscrollcommand=scrollbar.set)

        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=1)

        self._canvas.bind("<MouseWheel>", lambda event: self._scroll_vertically(_get_scroll_direction_from_event(event)))
        self._canvas.bind("<Button-4>", lambda event: self._scroll_vertically(_get_scroll_direction_from_event(event)))
        self._canvas.bind("<Button-5>", lambda event: self._scroll_vertically(_get_scroll_direction_from_event(event)))
        self._canvas.bind("<Control-MouseWheel>", lambda event: self._scroll_vertically(_get_scroll_direction_from_event(event) * _SCROLL_PAGE_UNITS))
        self._canvas.bind("<Control-Button-4>", lambda event: self._scroll_vertically(_get_scroll_direction_from_event(event) * _SCROLL_PAGE_UNITS))
        self._canvas.bind("<Control-Button-5>", lambda event: self._scroll_vertically(_get_scroll_direction_from_event(event) * _SCROLL_PAGE_UNITS))

    @property
    def canvas(self) -> tk.Canvas:
        return self._canvas

    def set_content_height(self, height: int) -> None:
        self._content_height = height
        self._canvas.configure(scrollregion=(0, 0, 0, self._content_height))

    def reset_scroll(self) -> None:
        self._canvas.yview(tk.MOVETO, 0)

    def _on_canvas_changed(self, _event: object) -> None:
        if self._canvas_resized_callback:
            new_size: Size = Size(self._canvas.winfo_width(), self._canvas.winfo_height())
            if self._current_canvas_size is None or self._current_canvas_size != new_size:
                self._current_canvas_size = new_size
                self._canvas_resized_callback(self._current_canvas_size)

    def _on_scroll(self, action: Literal['scroll', 'moveto'], *args: object) -> None:
        if self._canvas.yview() != (0.0, 1.0):
            self._canvas.yview(action, *args)

    def _on_vertical_scroll(self, *args: object) -> None:
        if self._canvas.yview() != (0.0, 1.0):
            self._canvas.yview(*args)

    def _scroll_vertically(self, scroll_value: int) -> None:
        if scroll_value and self._canvas.yview() != (0.0, 1.0):
            self._canvas.yview_scroll(scroll_value, tk.UNITS)

def _get_scroll_direction_from_event(event: tk.Event) -> int: # type: ignore[type-arg]
    if event.num == _LINUX_AND_OSX_MOUSEWHEEL_UP_BUTTON or event.delta < 0:
        return 1
    if event.num == _LINUX_AND_OSX_MOUSEWHEEL_DOWN_BUTTON or event.delta > 0:
        return -1
    return 0
