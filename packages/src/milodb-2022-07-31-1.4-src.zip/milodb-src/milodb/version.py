from typing import Optional

MILODB_VERSION: Optional[str] = '1.4'
MILODB_DATE: Optional[str] = '2022-07-31'
