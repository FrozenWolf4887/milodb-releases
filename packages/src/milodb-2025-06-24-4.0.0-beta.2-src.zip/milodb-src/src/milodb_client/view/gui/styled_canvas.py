# MiloDB by FrozenWolf is marked with CC0 1.0.
# To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/
import tkinter as tk
from typing import Literal
from milodb_client.view.gui import general_style, tk_type
from milodb_client.view.gui.theme import apply_canvas_style

# spell-checker: ignore closeenough scrollregion takefocus xscrollcommand xscrollincrement yscrollcommand yscrollincrement

class StyledCanvas(tk.Canvas):
    def __init__(
            self, master: tk.Misc,
            style: str = general_style.CANVAS,
            *,
            closeenough: float = 1,
            confine: bool = True,
            height: tk_type.ScreenUnits = 0,
            scrollregion: tuple[tk_type.ScreenUnits, tk_type.ScreenUnits, tk_type.ScreenUnits, tk_type.ScreenUnits] | tuple[()] = (),
            state: Literal['normal', 'disabled'] = "normal",
            takefocus: tk_type.TakeFocusValue = "",
            width: tk_type.ScreenUnits = 0,
            xscrollcommand: tk_type.XYScrollCommand = "",
            xscrollincrement: tk_type.ScreenUnits = 0,
            yscrollcommand: tk_type.XYScrollCommand = "",
            yscrollincrement: tk_type.ScreenUnits = 0,
        ) -> None:
        super().__init__(
            master,
            closeenough = closeenough,
            confine = confine,
            height = height,
            scrollregion = scrollregion,
            state = state,
            takefocus = takefocus,
            width = width,
            xscrollcommand = xscrollcommand,
            xscrollincrement = xscrollincrement,
            yscrollcommand = yscrollcommand,
            yscrollincrement = yscrollincrement,
        )

        self._style_name: str = style
        self._change_theme_event_id: str | None = None

        apply_canvas_style(self, self._style_name)
        self.bind('<<ThemeChanged>>', self._on_theme_changed)

    def _on_theme_changed(self, _event: object) -> None:
        if self._change_theme_event_id is None:
            self._change_theme_event_id = self.after_idle(self._on_idle_update_theme)

    def _on_idle_update_theme(self) -> None:
        self._change_theme_event_id = None
        apply_canvas_style(self, self._style_name)
